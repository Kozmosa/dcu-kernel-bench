import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_run(
    torch::Tensor x,
    torch::Tensor w,
    torch::Tensor pairs,
    torch::Tensor counts,
    torch::Tensor out);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &pyramid_run);
}
"""

HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>

__global__ void pyramid_kernel(
    const float* __restrict__ x,
    const float* __restrict__ w,
    const int* __restrict__ pairs,
    const int* __restrict__ counts,
    float* __restrict__ out,
    int n,
    int ci,
    int co,
    int kv)
{
    int slot = static_cast<int>(blockIdx.x);
    int k = slot / n;
    int j = slot - k * n;

    if (k >= kv || j >= counts[k]) {
        return;
    }

    int base = k * n + j;
    int ii = pairs[base];
    int oo = pairs[kv * n + base];

    const float* xin = x + static_cast<long long>(ii) * ci;

    for (int o = static_cast<int>(threadIdx.x); o < co; o += static_cast<int>(blockDim.x)) {
        const float* ww = w + (static_cast<long long>(o) * kv + k) * ci;
        float acc = 0.0f;

        for (int i = 0; i < ci; ++i) {
            acc += xin[i] * ww[i];
        }

        atomicAdd(out + static_cast<long long>(oo) * co + o, acc);
    }
}

torch::Tensor pyramid_run(
    torch::Tensor x,
    torch::Tensor w,
    torch::Tensor pairs,
    torch::Tensor counts,
    torch::Tensor out)
{
    const int n = static_cast<int>(x.size(0));
    const int ci = static_cast<int>(x.size(1));
    const int co = static_cast<int>(w.size(0));
    const int kv = static_cast<int>(w.size(2));

    const long long slots = static_cast<long long>(n) * kv;
    if (slots == 0) {
        return out;
    }

    const dim3 block(256);
    const dim3 grid(static_cast<unsigned int>(slots));
    hipStream_t stream = at::cuda::getCurrentCUDAStream().stream();

    hipLaunchKernelGGL(
        pyramid_kernel,
        grid,
        block,
        0,
        stream,
        x.data_ptr<float>(),
        w.data_ptr<float>(),
        pairs.data_ptr<int>(),
        counts.data_ptr<int>(),
        out.data_ptr<float>(),
        n,
        ci,
        co,
        kv);

    return out;
}
"""

def _extension_name():
    h = hashlib.sha1((CPP_SRC + HIP_SRC).encode("utf-8")).hexdigest()[:12]
    return "pyramidkernel_hip_" + h

def _get_extension():
    global _EXT
    if _EXT is None:
        _EXT = load_inline(
            name=_extension_name(),
            cpp_sources=CPP_SRC,
            cuda_sources=HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, features, filters, indice_pairs, indice_num_per_loc, num_act_out):
        num_act_out = int(num_act_out)
        co, ci, kv = filters.shape
        dtype = features.dtype

        x = features.to(dtype=torch.float32)
        w = filters.to(dtype=torch.float32)
        pairs = indice_pairs.to(dtype=torch.int32)
        counts = indice_num_per_loc.to(dtype=torch.int32)

        out = torch.zeros(
            (num_act_out, co),
            dtype=torch.float32,
            device=features.device,
        )

        _get_extension().run(x, w, pairs, counts, out)
        return out.to(dtype=dtype)
