import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXTENSION = None

_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_attention(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor starts,
    torch::Tensor lengths,
    double scale,
    bool causal);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pyramid_attention", &pyramid_attention, "Fused ragged attention");
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cmath>

template <typename T>
__device__ __forceinline__ T dmax(T a, T b) {
    return a > b ? a : b;
}

__global__ void attention_block_kernel(
    const float* __restrict__ q,
    const float* __restrict__ k,
    const float* __restrict__ v,
    float* __restrict__ out,
    const int* __restrict__ starts,
    const int* __restrict__ lengths,
    int total,
    int hq,
    int hkv,
    int d,
    float scale,
    int causal,
    int num_seqs)
{
    extern __shared__ float shared[];
    float* red = shared;
    float* ctl = shared + blockDim.x;

    int bid = blockIdx.x;
    int token = bid / hq;
    int head = bid - token * hq;
    if (token >= total) return;

    int seq = 0;
    while (seq + 1 < num_seqs && token >= starts[seq + 1]) ++seq;

    int begin = starts[seq];
    int len = lengths[seq];
    int t = token - begin;
    int last = causal ? (t + 1) : len;
    int kvhead = head / (hq / hkv);

    const float* qrow = q + ((size_t)token * hq + head) * d;
    float* orow = out + ((size_t)token * hq + head) * d;

    float accum = 0.0f;
    int tid = threadIdx.x;

    if (tid < d) accum = 0.0f;

    __syncthreads();

    float m = -CUDART_INF_F;
    float l = 0.0f;

    for (int j = 0; j < last; ++j) {
        const float* krow = k + ((size_t)(begin + j) * hkv + kvhead) * d;

        float part = 0.0f;
        for (int x = tid; x < d; x += blockDim.x)
            part += qrow[x] * krow[x];

        red[tid] = part;
        __syncthreads();

        for (int stride = blockDim.x >> 1; stride > 0; stride >>= 1) {
            if (tid < stride) red[tid] += red[tid + stride];
            __syncthreads();
        }

        if (tid == 0) {
            float z = red[0] * scale;
            float oldm = m;
            float newm = dmax(oldm, z);
            float factor = (oldm == -CUDART_INF_F) ? 0.0f : expf(oldm - newm);
            float w = expf(z - newm);
            l = l * factor + w;
            m = newm;
            ctl[0] = factor;
            ctl[1] = w;
        }
        __syncthreads();

        if (tid < d) {
            const float* vrow = v + ((size_t)(begin + j) * hkv + kvhead) * d;
            accum = accum * ctl[0] + ctl[1] * vrow[tid];
        }
        __syncthreads();
    }

    if (tid < d) {
        orow[tid] = accum / l;
    }
}

__global__ void attention_scalar_kernel(
    const float* __restrict__ q,
    const float* __restrict__ k,
    const float* __restrict__ v,
    float* __restrict__ out,
    const int* __restrict__ starts,
    const int* __restrict__ lengths,
    int total,
    int hq,
    int hkv,
    int d,
    float scale,
    int causal,
    int num_seqs)
{
    int index = blockIdx.x * blockDim.x + threadIdx.x;
    int count = total * hq * d;
    if (index >= count) return;

    int ch = index % d;
    int x = index / d;
    int head = x % hq;
    int token = x / hq;

    int seq = 0;
    while (seq + 1 < num_seqs && token >= starts[seq + 1]) ++seq;

    int begin = starts[seq];
    int len = lengths[seq];
    int t = token - begin;
    int last = causal ? (t + 1) : len;
    int kvhead = head / (hq / hkv);

    const float* qrow = q + ((size_t)token * hq + head) * d;
    float m = -CUDART_INF_F;
    float denom = 0.0f;
    float result = 0.0f;

    for (int j = 0; j < last; ++j) {
        const float* krow = k + ((size_t)(begin + j) * hkv + kvhead) * d;
        float dot = 0.0f;
        for (int z = 0; z < d; ++z)
            dot += qrow[z] * krow[z];

        float score = dot * scale;
        float newm = m > score ? m : score;
        float factor = (m == -CUDART_INF_F) ? 0.0f : expf(m - newm);
        float w = expf(score - newm);

        const float* vrow = v + ((size_t)(begin + j) * hkv + kvhead) * d;
        result = result * factor + w * vrow[ch];
        denom = denom * factor + w;
        m = newm;
    }

    out[index] = result / denom;
}

torch::Tensor pyramid_attention(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor starts,
    torch::Tensor lengths,
    double scale,
    bool causal)
{
    TORCH_CHECK(q.is_cuda(), "q must be on accelerator");
    TORCH_CHECK(k.is_cuda() && v.is_cuda(), "k and v must be on accelerator");
    TORCH_CHECK(starts.is_cuda() && lengths.is_cuda(), "metadata must be on accelerator");
    TORCH_CHECK(q.scalar_type() == at::kFloat, "q must be float32");
    TORCH_CHECK(k.scalar_type() == at::kFloat && v.scalar_type() == at::kFloat,
                "k and v must be float32");
    TORCH_CHECK(starts.scalar_type() == at::kInt && lengths.scalar_type() == at::kInt,
                "metadata must be int32");
    TORCH_CHECK(q.is_contiguous() && k.is_contiguous() && v.is_contiguous(),
                "q, k and v must be contiguous");

    const int total = (int)q.size(0);
    const int hq = (int)q.size(1);
    const int hkv = (int)k.size(1);
    const int d = (int)q.size(2);
    const int num_seqs = (int)lengths.size(0);

    auto out = torch::empty_like(q);
    hipStream_t stream = at::cuda::getCurrentCUDAStream();

    int threads = 1;
    while (threads < d && threads < 1024) threads <<= 1;

    if (d <= 1024) {
        int blocks = total * hq;
        size_t smem = (size_t)(threads + 4) * sizeof(float);
        hipLaunchKernelGGL(
            attention_block_kernel,
            dim3(blocks), dim3(threads), smem, stream,
            q.data_ptr<float>(),
            k.data_ptr<float>(),
            v.data_ptr<float>(),
            out.data_ptr<float>(),
            starts.data_ptr<int>(),
            lengths.data_ptr<int>(),
            total, hq, hkv, d,
            (float)scale, causal ? 1 : 0, num_seqs);
    } else {
        int count = total * hq * d;
        int blocks = (count + 255) / 256;
        hipLaunchKernelGGL(
            attention_scalar_kernel,
            dim3(blocks), dim3(256), 0, stream,
            q.data_ptr<float>(),
            k.data_ptr<float>(),
            v.data_ptr<float>(),
            out.data_ptr<float>(),
            starts.data_ptr<int>(),
            lengths.data_ptr<int>(),
            total, hq, hkv, d,
            (float)scale, causal ? 1 : 0, num_seqs);
    }

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP_SRC + _HIP_SRC).encode("utf-8")).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="pyramidkernel_hip_" + digest,
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)

    def forward(self, q, k, v, b_start_loc, b_seq_len):
        b_start_loc = b_start_loc.to(dtype=torch.int32)
        b_seq_len = b_seq_len.to(dtype=torch.int32)

        total, hq, d = q.shape
        hkv = k.shape[1]

        assert hq % hkv == 0
        assert k.shape[-1] == d and v.shape[-1] == d

        scale = self.sm_scale if self.sm_scale is not None else 1.0 / math.sqrt(d)

        return _get_extension().pyramid_attention(
            q.contiguous(),
            k.contiguous(),
            v.contiguous(),
            b_start_loc.contiguous(),
            b_seq_len.contiguous(),
            float(scale),
            self.causal,
        )
