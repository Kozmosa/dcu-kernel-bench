import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_forward(torch::Tensor q, torch::Tensor k,
                                torch::Tensor v, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &attention_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <algorithm>

template<class T>
__global__ void causal_attention(
    const T* __restrict__ q, const T* __restrict__ k,
    const T* __restrict__ v, T* __restrict__ out,
    int Hq, int Hkv, int L, int D, float scale,
    int64_t qb, int64_t qh, int64_t qr, int64_t qd,
    int64_t kb, int64_t kh, int64_t kr, int64_t kd,
    int64_t vb, int64_t vh, int64_t vr, int64_t vd,
    float* __restrict__ workspace, int shared_capacity)
{
    const int row = blockIdx.x;
    const int h = blockIdx.y % Hq;
    const int b = blockIdx.y / Hq;
    const int hk = h / (Hq / Hkv);
    const int t = threadIdx.x;
    const int lane = t & 15;
    const int group = t >> 4;
    extern __shared__ float sm[];
    float* reduction = sm;
    float* qs = sm + 256;
    float* p = shared_capacity ? qs + D :
        workspace + (int64_t(blockIdx.y) * L + row) * L;

    q += b * qb + h * qh + row * qr;
    k += b * kb + hk * kh;
    v += b * vb + hk * vh;
    out += (int64_t(blockIdx.y) * L + row) * D;

    if (row == 0) {
        for (int d = t; d < D; d += 256)
            out[d] = v[d * vd];
        return;
    }

    for (int d = t; d < D; d += 256)
        qs[d] = float(q[d * qd]) * scale;
    __syncthreads();

    for (int j = group; j <= row; j += 16) {
        float dot = 0.0f;
        for (int d = lane; d < D; d += 16)
            dot = fmaf(qs[d], float(k[int64_t(j) * kr + d * kd]), dot);
        dot += __shfl_down(dot, 8, 16);
        dot += __shfl_down(dot, 4, 16);
        dot += __shfl_down(dot, 2, 16);
        dot += __shfl_down(dot, 1, 16);
        if (lane == 0) p[j] = dot;
    }
    __syncthreads();

    float mx = -INFINITY;
    for (int j = t; j <= row; j += 256) mx = fmaxf(mx, p[j]);
    reduction[t] = mx;
    __syncthreads();
    for (int stride = 128; stride; stride >>= 1) {
        if (t < stride) reduction[t] = fmaxf(reduction[t], reduction[t + stride]);
        __syncthreads();
    }
    mx = reduction[0];
    float sum = 0.0f;
    for (int j = t; j <= row; j += 256) {
        float e = expf(p[j] - mx);
        p[j] = e;
        sum += e;
    }
    __syncthreads();
    reduction[t] = sum;
    __syncthreads();
    for (int stride = 128; stride; stride >>= 1) {
        if (t < stride) reduction[t] += reduction[t + stride];
        __syncthreads();
    }
    const float inv = 1.0f / reduction[0];

    // Multiple independent partial sums improve both latency and accuracy.
    for (int d = t; d < D; d += 256) {
        float a0 = 0, a1 = 0, a2 = 0, a3 = 0;
        int j = 0;
        for (; j + 3 <= row; j += 4) {
            a0 = fmaf(p[j], float(v[int64_t(j) * vr + d * vd]), a0);
            a1 = fmaf(p[j+1], float(v[int64_t(j+1) * vr + d * vd]), a1);
            a2 = fmaf(p[j+2], float(v[int64_t(j+2) * vr + d * vd]), a2);
            a3 = fmaf(p[j+3], float(v[int64_t(j+3) * vr + d * vd]), a3);
        }
        for (; j <= row; ++j)
            a0 = fmaf(p[j], float(v[int64_t(j) * vr + d * vd]), a0);
        out[d] = T(((a0 + a1) + (a2 + a3)) * inv);
    }
}

torch::Tensor attention_forward(torch::Tensor q, torch::Tensor k,
                                torch::Tensor v, double scale) {
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda(), "GPU inputs required");
    TORCH_CHECK(q.dim() == 4 && k.dim() == 4 && v.dim() == 4, "Expected HND inputs");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type(), "Dtypes must match");
    TORCH_CHECK(q.device() == k.device() && q.device() == v.device(),
                "Devices must match");
    int B = q.size(0), Hq = q.size(1), L = q.size(2), D = q.size(3);
    int Hkv = k.size(1);
    TORCH_CHECK(Hkv > 0 && Hq % Hkv == 0, "Invalid head grouping");
    TORCH_CHECK(k.size(0) == B && k.size(2) == L && k.size(3) == D &&
                v.sizes() == k.sizes(), "Invalid shapes");
    c10::cuda::CUDAGuard guard(q.device());
    auto out = torch::empty(q.sizes(), q.options());
    if (!out.numel()) return out;
    bool use_shared = (int64_t(L) + D + 256) * 4 <= 60000;
    torch::Tensor workspace;
    float* wp = nullptr;
    if (!use_shared) {
        workspace = torch::empty({int64_t(B) * Hq, L, L},
                                 q.options().dtype(torch::kFloat32));
        wp = workspace.data_ptr<float>();
    }
    size_t bytes = (256 + D + (use_shared ? L : 0)) * sizeof(float);
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                   q.scalar_type(), "causal_attention", [&] {
        causal_attention<scalar_t><<<dim3(L, B * Hq), 256, bytes, stream>>>(
            q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
            out.data_ptr<scalar_t>(), Hq, Hkv, L, D, float(scale),
            q.stride(0), q.stride(1), q.stride(2), q.stride(3),
            k.stride(0), k.stride(1), k.stride(2), k.stride(3),
            v.stride(0), v.stride(1), v.stride(2), v.stride(3),
            wp, int(use_shared));
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "causal_hnd_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)

    def forward(self, q, k, v):
        return _get_extension().forward(q, k, v, self.sm_scale)
