import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
#include <vector>

torch::Tensor pyramid_build(
    torch::Tensor indices,
    int64_t batch_size,
    std::vector<int64_t> input_dims,
    std::vector<int64_t> ksize,
    std::vector<int64_t> stride,
    std::vector<int64_t> padding,
    std::vector<int64_t> dilation);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pyramid_build", &pyramid_build);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <stdint.h>
#include <vector>

__device__ __forceinline__ int64_t coord_key(
    int b, const int* q, const int* od, int ndim) {
    int64_t key = b;
    for (int d = 0; d < ndim; ++d)
        key = key * (int64_t)od[d] + q[d];
    return key;
}

__device__ __forceinline__ uint64_t key_hash(uint64_t x) {
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

__global__ void pyramid_kernel(
    const float* __restrict__ in,
    int32_t* __restrict__ out,
    int32_t* __restrict__ hkeys,
    int32_t* __restrict__ hvals,
    int ndim,
    int B,
    int n,
    int kv,
    int cap,
    int hash_cap,
    int D0, int D1, int D2,
    int K0, int K1, int K2,
    int S0, int S1, int S2,
    int P0, int P1, int P2,
    int L0, int L1, int L2,
    int O0, int O1, int O2) {
    if (blockIdx.x != 0 || threadIdx.x != 0)
        return;

    int D[3] = {D0, D1, D2};
    int K[3] = {K0, K1, K2};
    int S[3] = {S0, S1, S2};
    int P[3] = {P0, P1, P2};
    int L[3] = {L0, L1, L2};
    int OD[3] = {O0, O1, O2};

    int64_t out_part = (int64_t)cap * (ndim + 1);
    int64_t pair_part = (int64_t)kv * n;
    int64_t total = out_part + 2 * pair_part + kv;

    for (int64_t i = 0; i < total; ++i)
        out[i] = -1;

    for (int i = 0; i < hash_cap; ++i) {
        hkeys[i] = 0;
        hvals[i] = -1;
    }

    int m = 0;

    for (int k = 0; k < kv; ++k) {
        int off[3] = {0, 0, 0};
        int t = k;
        for (int d = ndim - 1; d >= 0; --d) {
            off[d] = t % K[d];
            t /= K[d];
        }

        int cnt = 0;
        int64_t pair_base = (int64_t)k * n;

        for (int i = 0; i < n; ++i) {
            const float* row = in + (int64_t)i * (ndim + 1);
            int b = (int)row[0];

            if (b < 0 || b >= B)
                continue;

            int q[3] = {0, 0, 0};
            bool valid = true;

            for (int d = 0; d < ndim; ++d) {
                int x = (int)row[d + 1];
                int v = x + P[d] - off[d] * L[d];

                if (v % S[d] != 0) {
                    valid = false;
                    break;
                }

                int qd = v / S[d];
                if (qd < 0 || qd >= OD[d]) {
                    valid = false;
                    break;
                }
                q[d] = qd;
            }

            if (!valid)
                continue;

            int64_t key = coord_key(b, q, OD, ndim);
            int64_t stored = key + 1;
            int slot = (int)(key_hash((uint64_t)stored) &
                             (uint64_t)(hash_cap - 1));
            int r = -1;

            for (;;) {
                int32_t hk = hkeys[slot];
                if (hk == 0) {
                    hkeys[slot] = (int32_t)stored;
                    hvals[slot] = m;
                    r = m;

                    int base = m * (ndim + 1);
                    out[base] = b;
                    for (int d = 0; d < ndim; ++d)
                        out[base + 1 + d] = q[d];

                    ++m;
                    break;
                }
                if ((int64_t)(uint32_t)hk == stored) {
                    r = hvals[slot];
                    break;
                }
                slot = (slot + 1) & (hash_cap - 1);
            }

            out[pair_base + cnt + out_part] = i;
            out[pair_base + cnt + out_part + pair_part] = r;
            ++cnt;
        }

        out[out_part + 2 * pair_part + k] = cnt;
    }
}

torch::Tensor pyramid_build(
    torch::Tensor indices,
    int64_t batch_size,
    std::vector<int64_t> input_dims,
    std::vector<int64_t> ksize,
    std::vector<int64_t> stride,
    std::vector<int64_t> padding,
    std::vector<int64_t> dilation) {
    TORCH_CHECK(indices.is_cuda(), "indices must be on accelerator");
    TORCH_CHECK(indices.scalar_type() == at::kFloat,
                "indices must be float32");
    TORCH_CHECK(indices.dim() == 2 && indices.is_contiguous(),
                "indices must be contiguous 2D");

    const int ndim = (int)input_dims.size();
    const int n = (int)indices.size(0);

    int64_t kv64 = 1;
    int64_t outvol64 = batch_size;
    int od[3] = {1, 1, 1};

    for (int d = 0; d < ndim; ++d) {
        kv64 *= ksize[d];
        od[d] = (int)((input_dims[d] + 2 * padding[d]
                      - dilation[d] * (ksize[d] - 1) - 1) / stride[d] + 1);
        outvol64 *= od[d];
    }

    int64_t cap64 = kv64 * n;
    if (outvol64 < cap64)
        cap64 = outvol64;

    int64_t hash64 = 1;
    while (hash64 < cap64 * 2)
        hash64 <<= 1;

    int64_t total = cap64 * (ndim + 1) + 2 * kv64 * n + kv64;
    auto options = indices.options().dtype(at::kInt);
    auto result = at::empty({total}, options);
    auto hash_keys = at::empty({hash64}, options);
    auto hash_vals = at::empty({hash64}, options);

    int D[3] = {1, 1, 1};
    int K[3] = {1, 1, 1};
    int S[3] = {1, 1, 1};
    int P[3] = {0, 0, 0};
    int L[3] = {1, 1, 1};

    for (int d = 0; d < ndim; ++d) {
        D[d] = (int)input_dims[d];
        K[d] = (int)ksize[d];
        S[d] = (int)stride[d];
        P[d] = (int)padding[d];
        L[d] = (int)dilation[d];
    }

    hipLaunchKernelGGL(
        pyramid_kernel,
        dim3(1), dim3(1), 0, 0,
        indices.data_ptr<float>(),
        result.data_ptr<int32_t>(),
        hash_keys.data_ptr<int32_t>(),
        hash_vals.data_ptr<int32_t>(),
        ndim,
        (int)batch_size,
        n,
        (int)kv64,
        (int)cap64,
        (int)hash64,
        D[0], D[1], D[2],
        K[0], K[1], K[2],
        S[0], S[1], S[2],
        P[0], P[1], P[2],
        L[0], L[1], L[2],
        od[0], od[1], od[2]);

    return result;
}
"""

def _get_extension():
    global _EXT
    if _EXT is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode("utf-8")
        ).hexdigest()[:16]
        _EXT = load_inline(
            name="pyramidkernel_" + digest,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(
        self,
        batch_size: int = 2,
        input_dims=None,
        ksize=None,
        stride=None,
        padding=None,
        dilation=None,
    ):
        super().__init__()
        self.batch_size = int(batch_size)
        self.input_dims = list(
            input_dims if input_dims is not None else [4, 32, 32]
        )
        self.ksize = list(ksize if ksize is not None else [3, 3, 3])
        self.stride = list(stride if stride is not None else [1, 1, 1])
        self.padding = list(padding if padding is not None else [1, 1, 1])
        self.dilation = list(dilation if dilation is not None else [1, 1, 1])

        assert self.batch_size >= 1
        ndim = len(self.input_dims)
        assert 1 <= ndim <= 3
        assert all(
            len(x) == ndim
            for x in (self.ksize, self.stride, self.padding, self.dilation)
        )
        for d in range(ndim):
            assert self.input_dims[d] >= 1
            assert self.ksize[d] >= 1
            assert self.stride[d] >= 1
            assert self.padding[d] >= 0
            assert self.dilation[d] >= 1
            od = (
                self.input_dims[d]
                + 2 * self.padding[d]
                - self.dilation[d] * (self.ksize[d] - 1)
                - 1
            ) // self.stride[d] + 1
            assert od >= 1

    def forward(self, indices):
        return _get_extension().pyramid_build(
            indices.contiguous(),
            self.batch_size,
            self.input_dims,
            self.ksize,
            self.stride,
            self.padding,
            self.dilation,
        )
