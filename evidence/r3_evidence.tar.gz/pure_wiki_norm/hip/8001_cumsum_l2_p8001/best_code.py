import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

_CPP_SRC = r"""
#include <torch/extension.h>
#include <cstdint>

torch::Tensor prefix_scan_cuda(
    const torch::Tensor& x,
    int64_t outer,
    int64_t length,
    int64_t inner);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("prefix_scan", &prefix_scan_cuda);
}
"""

_CUDA_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/util/BFloat16.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template <typename scalar_t>
__global__ void scan_small_kernel(
    const scalar_t* __restrict__ x,
    scalar_t* __restrict__ y,
    int64_t chains,
    int64_t length,
    int64_t inner) {
    int64_t c = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (c >= chains) return;

    int64_t q = c / inner;
    int64_t r = c - q * inner;
    int64_t base = q * length * inner + r;
    float acc = 0.0f;

    for (int64_t i = 0; i < length; ++i) {
        int64_t p = base + i * inner;
        acc += static_cast<float>(x[p]);
        y[p] = static_cast<scalar_t>(acc);
    }
}

template <typename scalar_t>
__global__ void scan_block_kernel(
    const scalar_t* __restrict__ x,
    scalar_t* __restrict__ y,
    int64_t chains,
    int64_t length,
    int64_t inner) {
    __shared__ float tile[256];

    int tid = threadIdx.x;
    int64_t c = static_cast<int64_t>(blockIdx.x);
    if (c >= chains) return;

    int64_t q = c / inner;
    int64_t r = c - q * inner;
    int64_t base = q * length * inner + r;
    float carry = 0.0f;

    for (int64_t start = 0; start < length; start += 256) {
        int64_t pos = start + tid;
        int valid = static_cast<int>(length - start);
        if (valid > 256) valid = 256;

        if (tid < valid) {
            tile[tid] = static_cast<float>(x[base + pos * inner]);
        } else {
            tile[tid] = 0.0f;
        }
        __syncthreads();

        for (int offset = 1; offset < 256; offset <<= 1) {
            float v = 0.0f;
            if (tid >= offset) v = tile[tid - offset];
            __syncthreads();
            tile[tid] += v;
            __syncthreads();
        }

        if (tid < valid) {
            float outv = tile[tid] + carry;
            y[base + pos * inner] = static_cast<scalar_t>(outv);
        }
        __syncthreads();

        if (tid == 0) {
            carry = tile[valid - 1] + carry;
            tile[0] = carry;
        }
        __syncthreads();
        carry = tile[0];
        __syncthreads();
    }
}

torch::Tensor prefix_scan_cuda(
    const torch::Tensor& x,
    int64_t outer,
    int64_t length,
    int64_t inner) {
    TORCH_CHECK(x.is_cuda(), "input must be on a CUDA/HIP device");
    TORCH_CHECK(x.is_contiguous(), "input must be contiguous");
    TORCH_CHECK(x.scalar_type() == at::kFloat ||
                x.scalar_type() == at::kHalf ||
                x.scalar_type() == at::kBFloat16,
                "unsupported input type");

    auto y = torch::empty_like(x);
    int64_t chains = outer * inner;
    if (chains == 0 || length == 0) return y;

    auto stream = at::cuda::getCurrentCUDAStream(x.device().index());

    if (length <= 32) {
        constexpr int threads = 256;
        int blocks = static_cast<int>((chains + threads - 1) / threads);

        AT_DISPATCH_FLOATING_TYPES_AND2(
            at::kHalf,
            at::kBFloat16,
            x.scalar_type(),
            "scan_small",
            [&] {
                hipLaunchKernelGGL(
                    (scan_small_kernel<scalar_t>),
                    dim3(blocks),
                    dim3(threads),
                    0,
                    stream.stream(),
                    x.data_ptr<scalar_t>(),
                    y.data_ptr<scalar_t>(),
                    chains,
                    length,
                    inner);
            });
    } else {
        int blocks = static_cast<int>(chains);

        AT_DISPATCH_FLOATING_TYPES_AND2(
            at::kHalf,
            at::kBFloat16,
            x.scalar_type(),
            "scan_block",
            [&] {
                hipLaunchKernelGGL(
                    (scan_block_kernel<scalar_t>),
                    dim3(blocks),
                    dim3(256),
                    256 * sizeof(float),
                    stream.stream(),
                    x.data_ptr<scalar_t>(),
                    y.data_ptr<scalar_t>(),
                    chains,
                    length,
                    inner);
            });
    }

    auto err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "prefix scan kernel launch failed: ",
                hipGetErrorString(err));
    return y;
}
"""

def _get_extension():
    global _EXT
    if _EXT is None:
        _EXT = load_inline(
            name="hygon_prefix_scan_gfx936",
            cpp_sources=_CPP_SRC,
            cuda_sources=_CUDA_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, dim: int = 2):
        super().__init__()
        self.dim = int(dim)

    def forward(self, x):
        ndim = x.dim()
        if self.dim < 0:
            dim = self.dim + ndim
        else:
            dim = self.dim
        if dim < 0 or dim >= ndim:
            raise IndexError("dim must point at an existing dimension of the input")

        outer = 1
        for i in range(dim):
            outer *= x.shape[i]

        length = x.shape[dim]

        inner = 1
        for i in range(dim + 1, ndim):
            inner *= x.shape[i]

        return _get_extension().prefix_scan(x, outer, length, inner)
