import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

_CPP = r"""
#include <torch/extension.h>

void pyramid_dgrad(torch::Tensor x, torch::Tensor f, torch::Tensor y,
                   torch::Tensor pairs, torch::Tensor counts,
                   torch::Tensor out);

void pyramid_wgrad(torch::Tensor x, torch::Tensor f, torch::Tensor y,
                   torch::Tensor pairs, torch::Tensor counts,
                   torch::Tensor out);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("dgrad", &pyramid_dgrad);
    m.def("wgrad", &pyramid_wgrad);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/hip/HIPStream.h>

__global__ void pyramid_dgrad_kernel(
    const float* __restrict__ x,
    const float* __restrict__ f,
    const float* __restrict__ y,
    const int* __restrict__ pairs,
    const int* __restrict__ counts,
    float* __restrict__ out,
    int n,
    int ci,
    int co,
    int kv)
{
    long long q = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    long long total = (long long)kv * n * ci;
    if (q >= total) return;

    int i = (int)(q % ci);
    long long z = q / ci;
    int j = (int)(z % n);
    int k = (int)(z / n);

    int nk = counts[k];
    if (j >= nk) return;

    long long base = ((long long)k * n) + j;
    int in_idx = pairs[base];
    int out_idx = pairs[(long long)kv * n + base];

    float acc = 0.0f;
    const float* yp = y + (long long)out_idx * co;

    for (int o = 0; o < co; ++o) {
        float a = yp[o];
        float b = f[((long long)o * kv + k) * ci + i];
        acc += a * b;
    }

    atomicAdd(out + (long long)in_idx * ci + i, acc);
}

__global__ void pyramid_wgrad_kernel(
    const float* __restrict__ x,
    const float* __restrict__ y,
    const int* __restrict__ pairs,
    const int* __restrict__ counts,
    float* __restrict__ out,
    int n,
    int ci,
    int co,
    int kv)
{
    long long q = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    long long total = (long long)kv * n * co * ci;
    if (q >= total) return;

    int i = (int)(q % ci);
    long long z = q / ci;
    int o = (int)(z % co);
    z /= co;
    int j = (int)(z % n);
    int k = (int)(z / n);

    int nk = counts[k];
    if (j >= nk) return;

    long long base = ((long long)k * n) + j;
    int in_idx = pairs[base];
    int out_idx = pairs[(long long)kv * n + base];

    float a = y[(long long)out_idx * co + o];
    float b = x[(long long)in_idx * ci + i];
    float v = a * b;

    long long dst = ((long long)o * kv + k) * ci + i;
    atomicAdd(out + dst, v);
}

void pyramid_dgrad(
    torch::Tensor x,
    torch::Tensor f,
    torch::Tensor y,
    torch::Tensor pairs,
    torch::Tensor counts,
    torch::Tensor out)
{
    int n = (int)x.size(0);
    int ci = (int)x.size(1);
    int co = (int)y.size(1);
    int kv = (int)f.size(2);

    long long total = (long long)n * ci * kv;
    int threads = 256;
    int blocks = (int)((total + threads - 1) / threads);

    hipStream_t stream = c10::hip::getCurrentHIPStream().stream();
    hipLaunchKernelGGL(
        pyramid_dgrad_kernel,
        dim3(blocks),
        dim3(threads),
        0,
        stream,
        x.data_ptr<float>(),
        f.data_ptr<float>(),
        y.data_ptr<float>(),
        pairs.data_ptr<int>(),
        counts.data_ptr<int>(),
        out.data_ptr<float>(),
        n, ci, co, kv);
}

void pyramid_wgrad(
    torch::Tensor x,
    torch::Tensor f,
    torch::Tensor y,
    torch::Tensor pairs,
    torch::Tensor counts,
    torch::Tensor out)
{
    int n = (int)x.size(0);
    int ci = (int)x.size(1);
    int co = (int)y.size(1);
    int kv = (int)f.size(2);

    long long total = (long long)n * co * ci * kv;
    int threads = 256;
    int blocks = (int)((total + threads - 1) / threads);

    hipStream_t stream = c10::hip::getCurrentHIPStream().stream();
    hipLaunchKernelGGL(
        pyramid_wgrad_kernel,
        dim3(blocks),
        dim3(threads),
        0,
        stream,
        x.data_ptr<float>(),
        y.data_ptr<float>(),
        pairs.data_ptr<int>(),
        counts.data_ptr<int>(),
        out.data_ptr<float>(),
        n, ci, co, kv);
}
"""

def _get_extension():
    global _EXT
    if _EXT is None:
        key = hashlib.sha1((_CPP + _HIP).encode("utf-8")).hexdigest()[:16]
        _EXT = load_inline(
            name="pyramidkernel_hip_" + key,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dgrad"):
        super().__init__()
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant

    def forward(self, features, filters, out_bp, indice_pairs, indice_num_per_loc):
        dt = features.dtype
        x = features.to(dtype=torch.float32)
        f = filters.to(dtype=torch.float32)
        y = out_bp.to(dtype=torch.float32)

        n = int(features.shape[0])
        ci = int(features.shape[1])
        co = int(filters.shape[0])
        kv = int(filters.shape[2])

        pairs = indice_pairs
        counts = indice_num_per_loc

        ext = _get_extension()

        if self.variant == "dgrad":
            out = torch.zeros(
                (n, ci),
                dtype=torch.float32,
                device=features.device,
            )
            ext.dgrad(x, f, y, pairs, counts, out)
        else:
            out = torch.zeros(
                (co, ci, kv),
                dtype=torch.float32,
                device=features.device,
            )
            ext.wgrad(x, f, y, pairs, counts, out)

        return out.to(dtype=dt)
