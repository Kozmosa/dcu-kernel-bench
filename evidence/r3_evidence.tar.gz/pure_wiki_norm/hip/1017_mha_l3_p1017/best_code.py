import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_forward(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor alibi,
    double sm_scale,
    bool causal);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pyramid_forward", &pyramid_forward, "Pyramid attention forward");
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/ATen.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAStream.h>
#include <hip/hip_runtime.h>
#include <cmath>

template <typename scalar_t>
__global__ void pyramid_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k,
    const scalar_t* __restrict__ v,
    const float* __restrict__ alibi,
    float* __restrict__ packed,
    int B,
    int Sq,
    int Sk,
    int Hq,
    int Hkv,
    int D,
    float sm_scale,
    int causal)
{
    const int row = blockIdx.x;
    const int tid = threadIdx.x;
    const int rows_per_batch = Hq * Sq;
    const int b = row / rows_per_batch;
    const int rem = row - b * rows_per_batch;
    const int h = rem / Sq;
    const int i = rem - h * Sq;
    const int kvh = h / (Hq / Hkv);

    __shared__ float red[256];

    if (tid == 0) {
        red[2] = -CUDART_INF_F;
        red[3] = 0.0f;
    }
    __syncthreads();

    float acc = 0.0f;
    float m = -CUDART_INF_F;
    float l = 0.0f;

    const long long qbase =
        (((long long)b * Sq + i) * Hq + h) * D;
    const long long kbase0 =
        ((long long)b * Sk * Hkv + kvh) * D;
    const long long vbase0 = kbase0;

    const float slope = alibi[(long long)b * Hq + h];
    const int causal_limit = i + Sk - Sq;

    for (int j = 0; j < Sk; ++j) {
        const bool valid = (!causal) || (j <= causal_limit);

        float part = 0.0f;
        if (valid && tid < D) {
            part = static_cast<float>(q[qbase + tid]) *
                   static_cast<float>(k[kbase0 + (long long)j * Hkv * D + tid]);
        }
        red[tid] = part;
        __syncthreads();

        for (int stride = 128; stride > 0; stride >>= 1) {
            if (tid < stride)
                red[tid] += red[tid + stride];
            __syncthreads();
        }

        if (tid == 0) {
            if (valid) {
                const float rel = fabsf(static_cast<float>(i + Sk - Sq - j));
                const float score = red[0] * sm_scale - slope * rel;
                const float old_m = red[2];
                const float old_l = red[3];
                const float new_m = fmaxf(old_m, score);
                const float old_scale =
                    (old_m == -CUDART_INF_F) ? 0.0f : expf(old_m - new_m);
                const float p = expf(score - new_m);
                red[0] = p;
                red[1] = old_scale;
                red[2] = new_m;
                red[3] = old_l * old_scale + p;
            } else {
                red[0] = 0.0f;
                red[1] = 1.0f;
            }
        }
        __syncthreads();

        if (valid && tid < D) {
            const float p = red[0];
            const float old_scale = red[1];
            const float vv = static_cast<float>(
                v[vbase0 + (long long)j * Hkv * D + tid]);
            acc = acc * old_scale + p * vv;
        }
        __syncthreads();
    }

    const float final_l = red[3];
    const float final_m = red[2];

    if (tid < D) {
        float result = 0.0f;
        if (final_l > 0.0f)
            result = acc / final_l;

        const long long out_index =
            (((long long)b * Sq + i) * Hq + h) * D + tid;
        scalar_t converted = static_cast<scalar_t>(result);
        packed[out_index] = static_cast<float>(converted);
    }

    if (tid == 0) {
        const long long out_elements = (long long)B * Sq * Hq * D;
        const long long lse_index =
            (long long)B * Sq * Hq * D +
            ((long long)b * Hq + h) * Sq + i;
        packed[lse_index] =
            (final_l == 0.0f) ? 0.0f : (final_m + logf(final_l));
    }
}

torch::Tensor pyramid_forward(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor alibi,
    double sm_scale,
    bool causal)
{
    TORCH_CHECK(q.is_cuda(), "q must be on accelerator");
    TORCH_CHECK(k.is_cuda() && v.is_cuda() && alibi.is_cuda(),
                "all tensors must be on accelerator");
    TORCH_CHECK(q.dim() == 4 && k.dim() == 4 && v.dim() == 4,
                "q, k, v must be 4D");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type(),
                "q, k, v must have the same dtype");
    TORCH_CHECK(q.scalar_type() == at::kHalf ||
                q.scalar_type() == at::kBFloat16,
                "only float16 and bfloat16 are supported");
    TORCH_CHECK(alibi.scalar_type() == at::kFloat,
                "alibi must be float32");

    const int B = q.size(0);
    const int Sq = q.size(1);
    const int Hq = q.size(2);
    const int D = q.size(3);
    const int Sk = k.size(1);
    const int Hkv = k.size(2);

    TORCH_CHECK(k.size(0) == B && v.size(0) == B,
                "batch dimensions must match");
    TORCH_CHECK(k.size(3) == D && v.size(3) == D,
                "head dimensions must match");
    TORCH_CHECK(v.size(1) == Sk && v.size(2) == Hkv,
                "k and v shapes must match");
    TORCH_CHECK(Hkv > 0 && Hq % Hkv == 0,
                "num_q_heads must be divisible by num_kv_heads");
    TORCH_CHECK(alibi.size(0) == B && alibi.size(1) == Hq,
                "invalid alibi shape");
    TORCH_CHECK(D >= 1 && D <= 256, "head dimension must be <= 256");

    auto out = torch::empty(
        {(long long)B * Sq * Hq * (D + 1)},
        q.options().dtype(torch::kFloat));

    const dim3 grid((unsigned int)((long long)B * Hq * Sq));
    const dim3 block(256);
    hipStream_t stream =
        c10::cuda::getDefaultCUDAStream(q.get_device()).stream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::kHalf, at::kBFloat16, q.scalar_type(), "pyramid_forward", [&] {
            hipLaunchKernelGGL(
                (pyramid_kernel<scalar_t>),
                grid,
                block,
                0,
                stream,
                q.data_ptr<scalar_t>(),
                k.data_ptr<scalar_t>(),
                v.data_ptr<scalar_t>(),
                alibi.data_ptr<float>(),
                out.data_ptr<float>(),
                B, Sq, Sk, Hq, Hkv, D,
                static_cast<float>(sm_scale),
                causal ? 1 : 0);
        });

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

def _pyramidkernel_extension_name():
    digest = hashlib.sha1(
        (CUDA_CPP_SRC + CUDA_CU_SRC).encode("utf-8")
    ).hexdigest()[:12]
    return "pyramidkernel_hip_" + digest

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

class ModelNew(nn.Module):
    def __init__(self, head_dim: int, sm_scale=None):
        super().__init__()
        self.sm_scale = (
            float(sm_scale)
            if sm_scale is not None
            else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v, causal, alibi_slopes):
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal, device=q.device)
        is_causal = bool(int(causal.to(torch.int32)))
        q = q.contiguous()
        k = k.contiguous()
        v = v.contiguous()
        alibi_slopes = alibi_slopes.to(
            device=q.device, dtype=torch.float32
        ).contiguous()
        return _pyramidkernel_get_extension().pyramid_forward(
            q, k, v, alibi_slopes, self.sm_scale, is_causal
        )
