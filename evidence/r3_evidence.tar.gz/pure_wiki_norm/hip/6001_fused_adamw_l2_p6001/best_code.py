import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor update(torch::Tensor, torch::Tensor, torch::Tensor,
                     torch::Tensor, torch::Tensor, bool,
                     double, double, double, double, double);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("update", &update);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>

template<typename T, bool Bias>
__global__ void adam_update(
    const T* __restrict__ p,
    const T* __restrict__ g,
    const T* __restrict__ m,
    const T* __restrict__ v,
    const float* __restrict__ step,
    T* __restrict__ out,
    int64_t n, float lr, float b1, float b2,
    float c1, float c2, float eps, float decay)
{
    __shared__ float corrections[2];
    if constexpr (Bias) {
        if (threadIdx.x == 0) {
            float s = *step;
            corrections[0] = 1.0f - powf(b1, s);
            corrections[1] = 1.0f - powf(b2, s);
        }
        __syncthreads();
    }
    float bc1 = 1.0f, bc2 = 1.0f;
    if constexpr (Bias) {
        bc1 = corrections[0];
        bc2 = corrections[1];
    }
    int64_t base = int64_t(blockIdx.x) * blockDim.x * 4 + threadIdx.x;
    #pragma unroll
    for (int j = 0; j < 4; ++j) {
        int64_t i = base + j * blockDim.x;
        if (i < n) {
            float gi = float(g[i]);
            float pi = float(p[i]) * decay;
            float mi = b1 * float(m[i]) + c1 * gi;
            float vi = b2 * float(v[i]) + (c2 * gi) * gi;
            if constexpr (Bias) {
                mi = mi / bc1;
                vi = vi / bc2;
            }
            float u = mi / (sqrtf(vi) + eps);
            out[i] = T(pi - lr * u);
        }
    }
}

torch::Tensor update(
    torch::Tensor p, torch::Tensor g, torch::Tensor m,
    torch::Tensor v, torch::Tensor step, bool bias,
    double lr, double b1, double b2, double eps, double wd)
{
    c10::cuda::CUDAGuard guard(p.device());
    TORCH_CHECK(p.is_contiguous() && g.is_contiguous() &&
                m.is_contiguous() && v.is_contiguous(),
                "Inputs must be contiguous");
    TORCH_CHECK(p.scalar_type() == g.scalar_type() &&
                p.scalar_type() == m.scalar_type() &&
                p.scalar_type() == v.scalar_type(),
                "State tensor dtypes must match");
    auto out = torch::empty_like(p);
    auto s = step;
    if (!s.is_cuda())
        s = s.to(p.device(), torch::kFloat32, false, false);
    TORCH_CHECK(s.scalar_type() == torch::kFloat32 && s.numel() == 1,
                "step must be a float32 scalar");
    int64_t n = p.numel();
    if (n == 0) return out;
    auto stream = c10::cuda::getCurrentCUDAStream(p.get_device()).stream();
    dim3 block(256), grid((n + 1023) / 1024);
    AT_DISPATCH_FLOATING_TYPES_AND_HALF(p.scalar_type(), "adam_update", [&] {
        if (bias) {
            adam_update<scalar_t, true><<<grid, block, 0, stream>>>(
                p.data_ptr<scalar_t>(), g.data_ptr<scalar_t>(),
                m.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                s.data_ptr<float>(), out.data_ptr<scalar_t>(), n,
                float(lr), float(b1), float(b2), float(1.0-b1),
                float(1.0-b2), float(eps), float(1.0-lr*wd));
        } else {
            adam_update<scalar_t, false><<<grid, block, 0, stream>>>(
                p.data_ptr<scalar_t>(), g.data_ptr<scalar_t>(),
                m.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                s.data_ptr<float>(), out.data_ptr<scalar_t>(), n,
                float(lr), float(b1), float(b2), float(1.0-b1),
                float(1.0-b2), float(eps), float(1.0-lr*wd));
        }
    });
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "adam_map_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "adamw", lr: float = 1e-3, beta1: float = 0.9, beta2: float = 0.999, eps: float = 1e-8, weight_decay: float = 0.01):
        super().__init__()
        assert variant in ("adamw", "transformer_adamw"), \
            "variant must be one of adamw / transformer_adamw"
        self.variant = variant
        self.lr = float(lr)
        self.beta1 = float(beta1)
        self.beta2 = float(beta2)
        self.eps = float(eps)
        self.weight_decay = float(weight_decay)

    def forward(self, params, grads, exp_avg, exp_avg_sq, step):
        return _get_extension().update(
            params, grads, exp_avg, exp_avg_sq, step,
            self.variant == "adamw", self.lr, self.beta1, self.beta2,
            self.eps, self.weight_decay,
        )
