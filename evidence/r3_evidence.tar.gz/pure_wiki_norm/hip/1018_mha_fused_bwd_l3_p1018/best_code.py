import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_backward(torch::Tensor q, torch::Tensor k,
                                 torch::Tensor v, torch::Tensor dout, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &attention_backward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

struct Layout {
    int64_t b, s, h, d;
};
static Layout layout(const torch::Tensor& t) {
    return {t.stride(0), t.stride(1), t.stride(2), t.stride(3)};
}
__device__ inline int64_t offset(Layout t, int b, int s, int h, int d) {
    return b*t.b + s*t.s + h*t.h + d*t.d;
}

template<class T>
__global__ void products(
    const T* q, const T* k, const T* v, const T* o,
    Layout lq, Layout lk, Layout lv, Layout lo,
    float* p, float* dp, int M, int N, int H, int G, int D, float scale) {
    __shared__ float a[16][17], c[16][17], x[16][17], y[16][17];
    int tx=threadIdx.x, ty=threadIdx.y;
    int i=blockIdx.y*16+ty, j=blockIdx.x*16+tx;
    int h=blockIdx.z%H, b=blockIdx.z/H, kh=h/G;
    float s=0.f, t=0.f;
    for(int z=0; z<D; z+=16) {
        a[ty][tx]=(i<M && z+tx<D) ? float(q[offset(lq,b,i,h,z+tx)]) : 0.f;
        c[ty][tx]=(i<M && z+tx<D) ? float(o[offset(lo,b,i,h,z+tx)]) : 0.f;
        int kj=blockIdx.x*16+ty;
        x[ty][tx]=(kj<N && z+tx<D) ? float(k[offset(lk,b,kj,kh,z+tx)]) : 0.f;
        y[ty][tx]=(kj<N && z+tx<D) ? float(v[offset(lv,b,kj,kh,z+tx)]) : 0.f;
        __syncthreads();
        #pragma unroll
        for(int r=0;r<16;r++) {
            s=fmaf(a[ty][r],x[tx][r],s);
            t=fmaf(c[ty][r],y[tx][r],t);
        }
        __syncthreads();
    }
    if(i<M && j<N) {
        int64_t idx=((int64_t(blockIdx.z)*M+i)*N+j);
        p[idx]=s*scale;
        dp[idx]=t;
    }
}

__global__ void normalize(float* p, float* ds, int N) {
    __shared__ float buf[256];
    int t=threadIdx.x;
    int64_t base=int64_t(blockIdx.x)*N;
    float mx=-INFINITY;
    for(int j=t;j<N;j+=256) mx=fmaxf(mx,p[base+j]);
    buf[t]=mx;
    __syncthreads();
    for(int step=128;step;step>>=1) {
        if(t<step) buf[t]=fmaxf(buf[t],buf[t+step]);
        __syncthreads();
    }
    mx=buf[0];
    float sum=0.f;
    for(int j=t;j<N;j+=256) {
        float e=expf(p[base+j]-mx);
        p[base+j]=e;
        sum+=e;
    }
    buf[t]=sum;
    __syncthreads();
    for(int step=128;step;step>>=1) {
        if(t<step) buf[t]+=buf[t+step];
        __syncthreads();
    }
    float inv=1.f/buf[0], delta=0.f;
    for(int j=t;j<N;j+=256) {
        float prob=p[base+j]*inv;
        p[base+j]=prob;
        delta=fmaf(prob,ds[base+j],delta);
    }
    buf[t]=delta;
    __syncthreads();
    for(int step=128;step;step>>=1) {
        if(t<step) buf[t]+=buf[t+step];
        __syncthreads();
    }
    delta=buf[0];
    for(int j=t;j<N;j+=256)
        ds[base+j]=p[base+j]*(ds[base+j]-delta);
}

template<class T>
__global__ void grad_q(const float* ds, const T* k, Layout lk, T* out,
                      int M,int N,int H,int G,int D,float scale) {
    __shared__ float a[16][17], x[16][17];
    int tx=threadIdx.x,ty=threadIdx.y;
    int i=blockIdx.y*16+ty, d=blockIdx.x*16+tx;
    int h=blockIdx.z%H,b=blockIdx.z/H;
    float sum=0.f;
    for(int z=0;z<N;z+=16) {
        a[ty][tx]=(i<M && z+tx<N) ?
            ds[(int64_t(blockIdx.z)*M+i)*N+z+tx] : 0.f;
        x[ty][tx]=(z+ty<N && d<D) ?
            float(k[offset(lk,b,z+ty,h/G,d)]) : 0.f;
        __syncthreads();
        #pragma unroll
        for(int r=0;r<16;r++) sum=fmaf(a[ty][r],x[r][tx],sum);
        __syncthreads();
    }
    if(i<M && d<D) out[((int64_t(b)*M+i)*H+h)*D+d]=T(sum*scale);
}

template<class T>
__global__ void grad_kv(const float* p,const float* ds,
                       const T* q,const T* o,Layout lq,Layout lo,
                       T* dk,T* dv,int M,int N,int H,int HK,int G,int D,float scale) {
    __shared__ float a[16][17], c[16][17], x[16][17], y[16][17];
    int tx=threadIdx.x,ty=threadIdx.y;
    int j=blockIdx.y*16+ty,d=blockIdx.x*16+tx;
    int kh=blockIdx.z%HK,b=blockIdx.z/HK;
    float sk=0.f,sv=0.f;
    for(int g=0;g<G;g++) {
        int h=kh*G+g;
        float tk=0.f,tv=0.f;
        for(int z=0;z<M;z+=16) {
            int64_t idx=(int64_t(b)*H+h)*M*N+int64_t(z+tx)*N+j;
            a[ty][tx]=(j<N && z+tx<M) ? ds[idx] : 0.f;
            c[ty][tx]=(j<N && z+tx<M) ? p[idx] : 0.f;
            x[ty][tx]=(z+ty<M && d<D) ? float(q[offset(lq,b,z+ty,h,d)]) : 0.f;
            y[ty][tx]=(z+ty<M && d<D) ? float(o[offset(lo,b,z+ty,h,d)]) : 0.f;
            __syncthreads();
            #pragma unroll
            for(int r=0;r<16;r++) {
                tk=fmaf(a[ty][r],x[r][tx],tk);
                tv=fmaf(c[ty][r],y[r][tx],tv);
            }
            __syncthreads();
        }
        sk+=tk*scale;
        sv+=tv;
    }
    if(j<N && d<D) {
        int64_t idx=((int64_t(b)*N+j)*HK+kh)*D+d;
        dk[idx]=T(sk);
        dv[idx]=T(sv);
    }
}

torch::Tensor attention_backward(torch::Tensor q, torch::Tensor k,
                                 torch::Tensor v, torch::Tensor dout, double scale) {
    c10::cuda::CUDAGuard guard(q.device());
    int B=q.size(0), M=q.size(1), H=q.size(2), D=q.size(3);
    int N=k.size(1), HK=k.size(2);
    TORCH_CHECK(HK>0 && H%HK==0, "Invalid head grouping");
    int G=H/HK;
    int64_t nq=int64_t(B)*M*H*D,nk=int64_t(B)*N*HK*D;
    auto result=torch::empty({nq+2*nk},q.options());
    auto p=torch::empty({B,H,M,N},q.options().dtype(torch::kFloat32));
    auto ds=torch::empty_like(p);
    auto stream=at::cuda::getCurrentCUDAStream();
    dim3 threads(16,16);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,at::ScalarType::BFloat16,
                                  q.scalar_type(),"attention_backward",[&] {
        products<scalar_t><<<dim3((N+15)/16,(M+15)/16,B*H),threads,0,stream>>>(
            q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),
            dout.data_ptr<scalar_t>(),layout(q),layout(k),layout(v),layout(dout),
            p.data_ptr<float>(),ds.data_ptr<float>(),M,N,H,G,D,float(scale));
        normalize<<<B*H*M,256,0,stream>>>(p.data_ptr<float>(),ds.data_ptr<float>(),N);
        grad_q<scalar_t><<<dim3((D+15)/16,(M+15)/16,B*H),threads,0,stream>>>(
            ds.data_ptr<float>(),k.data_ptr<scalar_t>(),layout(k),
            result.data_ptr<scalar_t>(),M,N,H,G,D,float(scale));
        grad_kv<scalar_t><<<dim3((D+15)/16,(N+15)/16,B*HK),threads,0,stream>>>(
            p.data_ptr<float>(),ds.data_ptr<float>(),q.data_ptr<scalar_t>(),
            dout.data_ptr<scalar_t>(),layout(q),layout(dout),
            result.data_ptr<scalar_t>()+nq,result.data_ptr<scalar_t>()+nq+nk,
            M,N,H,HK,G,D,float(scale));
    });
    return result;
}
"""

_EXT = None


def _extension():
    global _EXT
    if _EXT is None:
        name = "attention_bwd_simt_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXT = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, q, k, v, do):
        return _extension().run(q, k, v, do, self.sm_scale)
