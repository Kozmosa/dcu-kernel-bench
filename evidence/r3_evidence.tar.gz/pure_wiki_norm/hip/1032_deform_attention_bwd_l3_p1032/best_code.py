import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor run(torch::Tensor, torch::Tensor, torch::Tensor,
                  torch::Tensor, torch::Tensor, torch::Tensor);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

__device__ __forceinline__ int read_index(const void* p, int i, int type) {
    if (type == 0) return (int)((const float*)p)[i];
    if (type == 1) return (int)((const int64_t*)p)[i];
    return ((const int*)p)[i];
}

__device__ __forceinline__ float reduce_wave(float v) {
    for (int offset = 32; offset; offset >>= 1)
        v += __shfl_down(v, offset, 64);
    return v;
}

__global__ void backward_kernel(
    const float* __restrict__ value,
    const void* shapes, const void* starts, int st, int bt,
    const float* __restrict__ loc,
    const float* __restrict__ scores,
    const float* __restrict__ go,
    float* __restrict__ gv,
    float* __restrict__ gl,
    float* __restrict__ ga,
    int keys, int heads, int D, int Q, int K, int P)
{
    const int row = blockIdx.x;
    const int h = row % heads;
    const int n = row / (Q * heads);
    const int lane = threadIdx.x & 63;
    const int wave = threadIdx.x >> 6;
    const int64_t sample_base = (int64_t)row * K;
    extern __shared__ float shared[];
    float* weights = shared;
    float* dots = shared + K;

    if (threadIdx.x == 0) {
        float maximum = -INFINITY;
        for (int k = 0; k < K; ++k)
            maximum = fmaxf(maximum, scores[sample_base + k]);
        float sum = 0.f;
        for (int k = 0; k < K; ++k) {
            float w = expf(scores[sample_base + k] - maximum);
            weights[k] = w;
            sum += w;
        }
        for (int k = 0; k < K; ++k)
            weights[k] /= sum;
    }
    __syncthreads();

    for (int k = wave; k < K; k += 4) {
        const int l = k / P;
        const int H = read_index(shapes, 2*l, st);
        const int W = read_index(shapes, 2*l+1, st);
        const int base = read_index(starts, l, bt);
        const int64_t si = sample_base + k;
        const float x = loc[2*si] * (float)W;
        const float y = loc[2*si+1] * (float)H;
        const int ix = (int)floorf(x), iy = (int)floorf(y);
        const float fx = x - (float)ix, fy = y - (float)iy;
        const float ax = 1.f-fx, ay = 1.f-fy;
        const float w = weights[k];
        const bool ok00 = ix >= 0 && ix < W && iy >= 0 && iy < H;
        const bool ok01 = ix+1 >= 0 && ix+1 < W && iy >= 0 && iy < H;
        const bool ok10 = ix >= 0 && ix < W && iy+1 >= 0 && iy+1 < H;
        const bool ok11 = ix+1 >= 0 && ix+1 < W && iy+1 >= 0 && iy+1 < H;
        const int64_t origin = ((int64_t)n * keys + base) * heads * D + h * D;
        const int64_t i00 = origin + ((int64_t)iy*W+ix)*heads*D;
        const int64_t i01 = i00 + heads*D;
        const int64_t i10 = i00 + (int64_t)W*heads*D;
        const int64_t i11 = i10 + heads*D;
        float dot = 0.f, dx = 0.f, dy = 0.f;
        for (int c = lane; c < D; c += 64) {
            const float v00 = ok00 ? value[i00+c] : 0.f;
            const float v01 = ok01 ? value[i01+c] : 0.f;
            const float v10 = ok10 ? value[i10+c] : 0.f;
            const float v11 = ok11 ? value[i11+c] : 0.f;
            const float g = go[(int64_t)row*D+c];
            const float gw = g*w;
            const float sample = ((v00*(ay*ax) + v01*(ay*fx))
                                   + v10*(fy*ax)) + v11*(fy*fx);
            dot += g*sample;
            dx += gw*(ay*(v01-v00)+fy*(v11-v10));
            dy += gw*(ax*(v10-v00)+fx*(v11-v01));
            if (ok00) atomicAdd(gv+i00+c, gw*(ay*ax));
            if (ok01) atomicAdd(gv+i01+c, gw*(ay*fx));
            if (ok10) atomicAdd(gv+i10+c, gw*(fy*ax));
            if (ok11) atomicAdd(gv+i11+c, gw*(fy*fx));
        }
        dot = reduce_wave(dot);
        dx = reduce_wave(dx);
        dy = reduce_wave(dy);
        if (lane == 0) {
            dots[k] = dot;
            gl[2*si] = dx*(float)W;
            gl[2*si+1] = dy*(float)H;
        }
    }
    __syncthreads();
    if (threadIdx.x == 0) {
        float mean = 0.f;
        for (int k = 0; k < K; ++k)
            mean += weights[k]*dots[k];
        for (int k = 0; k < K; ++k)
            ga[sample_base+k] = K == 1 ? 0.f : weights[k]*(dots[k]-mean);
    }
}

static int index_type(const torch::Tensor& x) {
    if (x.scalar_type() == at::kFloat) return 0;
    if (x.scalar_type() == at::kLong) return 1;
    TORCH_CHECK(x.scalar_type() == at::kInt, "Unsupported index dtype");
    return 2;
}

torch::Tensor run(torch::Tensor value, torch::Tensor shapes,
                  torch::Tensor starts, torch::Tensor loc,
                  torch::Tensor scores, torch::Tensor go) {
    c10::cuda::CUDAGuard guard(value.device());
    TORCH_CHECK(value.scalar_type() == at::kFloat, "Expected fp32 inputs");
    const int N = value.size(0), keys = value.size(1);
    const int heads = value.size(2), D = value.size(3);
    const int Q = loc.size(1), P = loc.size(4);
    const int K = loc.size(3)*P;
    const int64_t nv = value.numel();
    const int64_t ns = scores.numel();
    auto result = torch::empty({nv+3*ns}, value.options());
    auto stream = at::cuda::getCurrentCUDAStream();
    auto err = hipMemsetAsync(result.data_ptr<float>(), 0, nv*sizeof(float), stream);
    TORCH_CHECK(err == hipSuccess, hipGetErrorString(err));
    backward_kernel<<<N*Q*heads, 256, 2ull*K*sizeof(float), stream>>>(
        value.data_ptr<float>(), shapes.data_ptr(), starts.data_ptr(),
        index_type(shapes), index_type(starts),
        loc.data_ptr<float>(), scores.data_ptr<float>(), go.data_ptr<float>(),
        result.data_ptr<float>(), result.data_ptr<float>()+nv,
        result.data_ptr<float>()+nv+2*ns,
        keys, heads, D, Q, K, P);
    err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, hipGetErrorString(err));
    return result;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "deform_backward_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, value, spatial_shapes, level_start_index,
                sampling_locations, attention_weights, grad_output):
        if spatial_shapes.device != value.device:
            spatial_shapes = spatial_shapes.to(device=value.device)
        if level_start_index.device != value.device:
            level_start_index = level_start_index.to(device=value.device)
        return _get_extension().run(
            value, spatial_shapes, level_start_index,
            sampling_locations, attention_weights, grad_output
        )
