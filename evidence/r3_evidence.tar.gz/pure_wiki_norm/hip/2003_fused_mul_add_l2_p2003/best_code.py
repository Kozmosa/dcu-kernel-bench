import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor affine_forward(
    torch::Tensor x, torch::Tensor a, torch::Tensor b,
    int64_t am, int64_t bm, double av, double bv);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &affine_forward);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template<typename T, int AM, int BM>
__global__ void affine_kernel(
    const T* __restrict__ x,
    const T* __restrict__ a,
    const T* __restrict__ b,
    T* __restrict__ y,
    int64_t n, float av, float bv)
{
    constexpr int THREADS = 256;
    constexpr int ITEMS = 4;
    const int64_t base = int64_t(blockIdx.x) * THREADS * ITEMS + threadIdx.x;

    float as = av;
    float bs = bv;
    if constexpr (AM == 1) as = static_cast<float>(a[0]);
    if constexpr (BM == 1) bs = static_cast<float>(b[0]);

    #pragma unroll
    for (int j = 0; j < ITEMS; ++j) {
        const int64_t i = base + j * THREADS;
        if (i < n) {
            float aa = as;
            float bb = bs;
            if constexpr (AM == 2) aa = static_cast<float>(a[i]);
            if constexpr (BM == 2) bb = static_cast<float>(b[i]);
            const float xx = static_cast<float>(x[i]);
            const float product = aa * xx;
            y[i] = static_cast<T>(product + bb);
        }
    }
}

template<typename T, int AM>
void launch_b(
    const T* x, const T* a, const T* b, T* y,
    int64_t n, int bm, float av, float bv, hipStream_t stream)
{
    const dim3 grid((n + 1023) / 1024);
    const dim3 block(256);
    switch (bm) {
        case 0:
            hipLaunchKernelGGL((affine_kernel<T, AM, 0>),
                grid, block, 0, stream, x, a, b, y, n, av, bv);
            break;
        case 1:
            hipLaunchKernelGGL((affine_kernel<T, AM, 1>),
                grid, block, 0, stream, x, a, b, y, n, av, bv);
            break;
        default:
            hipLaunchKernelGGL((affine_kernel<T, AM, 2>),
                grid, block, 0, stream, x, a, b, y, n, av, bv);
            break;
    }
}

torch::Tensor affine_forward(
    torch::Tensor x, torch::Tensor a, torch::Tensor b,
    int64_t am, int64_t bm, double av, double bv)
{
    TORCH_CHECK(x.is_cuda() && x.is_contiguous(),
                "x must be a contiguous accelerator tensor");
    c10::cuda::CUDAGuard guard(x.device());
    auto y = torch::empty_like(x);
    const int64_t n = x.numel();
    if (n == 0) return y;

    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "affine_forward", [&] {
            const auto* xp = x.data_ptr<scalar_t>();
            const auto* ap = am ? a.data_ptr<scalar_t>() : nullptr;
            const auto* bp = bm ? b.data_ptr<scalar_t>() : nullptr;
            auto* yp = y.data_ptr<scalar_t>();
            switch (am) {
                case 0:
                    launch_b<scalar_t, 0>(
                        xp, ap, bp, yp, n, bm, float(av), float(bv), stream);
                    break;
                case 1:
                    launch_b<scalar_t, 1>(
                        xp, ap, bp, yp, n, bm, float(av), float(bv), stream);
                    break;
                default:
                    launch_b<scalar_t, 2>(
                        xp, ap, bp, yp, n, bm, float(av), float(bv), stream);
                    break;
            }
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return y;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=f"hip_affine_{digest}",
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3", "-std=c++17"],
            extra_cuda_cflags=["-O3", "-std=c++17", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x, a, b):
        if isinstance(a, torch.Tensor):
            at, am, av = a, 1 if a.numel() == 1 else 2, 0.0
        else:
            at, am, av = x, 0, float(a)

        if isinstance(b, torch.Tensor):
            bt, bm, bv = b, 1 if b.numel() == 1 else 2, 0.0
        else:
            bt, bm, bv = x, 0, float(b)

        return _get_extension().forward(x, at, bt, am, bm, av, bv)
