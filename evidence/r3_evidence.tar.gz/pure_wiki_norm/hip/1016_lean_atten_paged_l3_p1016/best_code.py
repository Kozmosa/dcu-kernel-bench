import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_forward(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                           torch::Tensor table, torch::Tensor ends,
                           int64_t page, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &paged_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <cmath>

template<class T, class I, int D>
__global__ void partial_attention(
    const T* __restrict__ q, const T* __restrict__ k,
    const T* __restrict__ v, const I* __restrict__ table,
    const int* __restrict__ ends, float* __restrict__ tmp,
    int M, int N, int U, int Q, int P, int S, float scale)
{
    constexpr int W = D < 64 ? D : 64;
    constexpr int G = 256 / W;
    const int tid = threadIdx.x;
    const int lane = tid % W;
    const int group = tid / W;
    const int rowq = blockIdx.x;
    const int h = blockIdx.y;
    const int split = blockIdx.z;
    const int b = rowq / Q;
    const int begin = b ? ends[b-1] : 0;
    const int end = ends[b];
    const int count = end - begin;
    const int lo = begin + (count * split) / S;
    const int hi = begin + (count * (split+1)) / S;
    __shared__ float scores[64];
    __shared__ float weights[64];
    __shared__ float oldfactor, norm;
    float qreg[(D+W-1)/W];
    #pragma unroll
    for (int z=0; z<D/W; ++z)
        qreg[z] = float(q[((int64_t)h*M+rowq)*D+lane+z*W]);
    float acc = 0.0f;
    float running_max = -INFINITY;
    float running_sum = 0.0f;
    for (int p=lo; p<hi; ++p) {
        int physical = int(table[(int64_t)h*U+p]);
        for (int offset=0; offset<P; offset+=64) {
            int length = min(64, P-offset);
            for (int j=group; j<64; j+=G) {
                float dot = 0.0f;
                if (j<length) {
                    const T* kp = k + ((int64_t)h*N + physical*P + offset+j)*D;
                    #pragma unroll
                    for (int z=0; z<D/W; ++z)
                        dot = fmaf(qreg[z], float(kp[lane+z*W]), dot);
                }
                #pragma unroll
                for (int delta=W/2; delta>0; delta/=2)
                    dot += __shfl_down(dot, delta, W);
                if (lane==0)
                    scores[j] = j<length ? dot*scale : -INFINITY;
            }
            __syncthreads();
            if (tid<64) {
                float score = scores[tid];
                float mx = score;
                #pragma unroll
                for (int delta=32; delta>0; delta/=2)
                    mx = fmaxf(mx, __shfl_xor(mx, delta, 64));
                float next_max = fmaxf(running_max, mx);
                float factor = expf(running_max-next_max);
                float w = expf(score-next_max);
                weights[tid] = w;
                float sum = w;
                #pragma unroll
                for (int delta=32; delta>0; delta/=2)
                    sum += __shfl_xor(sum, delta, 64);
                running_sum = running_sum*factor + sum;
                running_max = next_max;
                if (tid==0) {
                    oldfactor = factor;
                    norm = running_sum;
                }
            }
            __syncthreads();
            if (tid<D) {
                float value = 0.0f;
                for (int j=0; j<length; ++j)
                    value = fmaf(weights[j],
                        float(v[((int64_t)h*N+physical*P+offset+j)*D+tid]), value);
                acc = fmaf(acc, oldfactor, value);
            }
            __syncthreads();
        }
    }
    float* dst = tmp + (((int64_t)h*M+rowq)*S+split)*(D+2);
    if (tid<D) dst[tid] = acc;
    if (tid==0) {
        dst[D] = running_max;
        dst[D+1] = running_sum;
    }
}

template<class T, int D>
__global__ void combine(const float* __restrict__ tmp, T* __restrict__ out,
                        int S, int rows) {
    int r = blockIdx.x;
    int d = threadIdx.x;
    if (d>=D) return;
    const float* src = tmp + (int64_t)r*S*(D+2);
    float mx = -INFINITY;
    for (int s=0; s<S; ++s) mx = fmaxf(mx, src[s*(D+2)+D]);
    float sum = 0.0f, value = 0.0f;
    for (int s=0; s<S; ++s) {
        float w = expf(src[s*(D+2)+D]-mx);
        sum = fmaf(w, src[s*(D+2)+D+1], sum);
        value = fmaf(w, src[s*(D+2)+d], value);
    }
    out[(int64_t)r*D+d] = T(value/sum);
}

template<class T, class I, int D>
void launch(torch::Tensor q, torch::Tensor k, torch::Tensor v,
            torch::Tensor table, torch::Tensor ends, torch::Tensor tmp,
            torch::Tensor out, int P, int S, float scale, hipStream_t stream) {
    int H=q.size(0), M=q.size(1), N=k.size(1), U=table.size(1);
    int Q=M/ends.numel();
    partial_attention<T,I,D><<<dim3(M,H,S),256,0,stream>>>(
        q.data_ptr<T>(),k.data_ptr<T>(),v.data_ptr<T>(),table.data_ptr<I>(),
        ends.data_ptr<int>(),tmp.data_ptr<float>(),M,N,U,Q,P,S,scale);
    combine<T,D><<<H*M,256,0,stream>>>(
        tmp.data_ptr<float>(),out.data_ptr<T>(),S,H*M);
}

torch::Tensor paged_forward(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                           torch::Tensor table, torch::Tensor ends,
                           int64_t page, double scale) {
    c10::cuda::CUDAGuard guard(q.device());
    q=q.contiguous(); k=k.contiguous(); v=v.contiguous();
    table=table.contiguous();
    ends=ends.to(torch::kInt32).contiguous();
    int H=q.size(0), M=q.size(1), D=q.size(2);
    int B=ends.numel();
    int S=std::max(1, std::min(32, int((table.size(1)+B*4-1)/(B*4))));
    auto out=torch::empty_like(q);
    auto tmp=torch::empty({H,M,S,D+2},q.options().dtype(torch::kFloat32));
    auto stream=at::cuda::getCurrentCUDAStream().stream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,at::ScalarType::BFloat16,
                                   q.scalar_type(),"paged_attention",[&] {
#define RUN_DIM(I) \
    switch(D) { \
      case 16: launch<scalar_t,I,16>(q,k,v,table,ends,tmp,out,page,S,scale,stream); break; \
      case 32: launch<scalar_t,I,32>(q,k,v,table,ends,tmp,out,page,S,scale,stream); break; \
      case 64: launch<scalar_t,I,64>(q,k,v,table,ends,tmp,out,page,S,scale,stream); break; \
      case 128: launch<scalar_t,I,128>(q,k,v,table,ends,tmp,out,page,S,scale,stream); break; \
      case 256: launch<scalar_t,I,256>(q,k,v,table,ends,tmp,out,page,S,scale,stream); break; \
      default: TORCH_CHECK(false,"Unsupported head dimension"); \
    }
        if (table.scalar_type()==torch::kInt64) { RUN_DIM(int64_t); }
        else { RUN_DIM(int); }
#undef RUN_DIM
    });
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "paged_decode_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, page_size: int = 64, sm_scale=0.5):
        super().__init__()
        self.head_size = int(head_size)
        self.page_size = int(page_size)
        self.sm_scale = float(sm_scale)

    def forward(self, q, k, v, kv_block_tables, batch_num_block_n):
        return _extension().forward(
            q, k, v, kv_block_tables, batch_num_block_n,
            self.page_size, self.sm_scale
        )
