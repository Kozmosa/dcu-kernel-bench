import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_decode(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                           torch::Tensor pages, torch::Tensor lengths,
                           double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_decode", &paged_decode);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>

constexpr int TOKENS = 128;
constexpr int THREADS = 256;

__device__ __forceinline__ int read_index(const void* ptr, bool wide, int64_t i) {
    return wide ? int(static_cast<const int64_t*>(ptr)[i])
                : static_cast<const int32_t*>(ptr)[i];
}

template <typename T>
__global__ void attention_parts(
    const T* __restrict__ q, const T* __restrict__ k,
    const T* __restrict__ v, const void* pages, const void* lengths,
    bool pages64, bool lengths64,
    float* __restrict__ partial, float* __restrict__ stats,
    int H, int HK, int D, int DV, int PS, int NP, int NS, float scale)
{
    int bh = blockIdx.x, split = blockIdx.y;
    int b = bh / H, h = bh % H, kh = h / (H / HK);
    int tid = threadIdx.x;
    int lane = tid & 63, wave = tid >> 6;
    int length = read_index(lengths, lengths64, b);
    int begin = split * TOKENS;
    int count = min(TOKENS, max(0, length - begin));

    __shared__ float logits[TOKENS];
    __shared__ int64_t slots[TOKENS];
    __shared__ float reduction[THREADS];
    extern __shared__ float query[];

    for (int d = tid; d < D; d += THREADS)
        query[d] = float(q[int64_t(bh) * D + d]) * scale;

    if (tid < count) {
        int token = begin + tid;
        int page = read_index(pages, pages64, int64_t(b) * NP + token / PS);
        slots[tid] = int64_t(page) * PS + token % PS;
    }
    __syncthreads();

    for (int t = wave; t < count; t += 4) {
        const T* kp = k + (slots[t] * HK + kh) * D;
        float dot = 0.0f;
        for (int d = lane; d < D; d += 64)
            dot = fmaf(query[d], float(kp[d]), dot);
        #pragma unroll
        for (int offset = 32; offset > 0; offset >>= 1)
            dot += __shfl_down(dot, offset, 64);
        if (lane == 0) logits[t] = dot;
    }
    __syncthreads();

    reduction[tid] = tid < count ? logits[tid] : -INFINITY;
    __syncthreads();
    for (int step = THREADS / 2; step; step >>= 1) {
        if (tid < step)
            reduction[tid] = fmaxf(reduction[tid], reduction[tid + step]);
        __syncthreads();
    }
    float maximum = reduction[0];
    float weight = tid < count ? expf(logits[tid] - maximum) : 0.0f;
    __syncthreads();
    if (tid < count) logits[tid] = weight;
    reduction[tid] = weight;
    __syncthreads();
    for (int step = THREADS / 2; step; step >>= 1) {
        if (tid < step) reduction[tid] += reduction[tid + step];
        __syncthreads();
    }
    float denominator = reduction[0];
    int64_t si = int64_t(bh) * NS + split;
    if (tid == 0) {
        stats[si * 2] = maximum;
        stats[si * 2 + 1] = denominator;
    }

    for (int d = tid; d < DV; d += THREADS) {
        float acc = 0.0f;
        for (int t = 0; t < count; ++t)
            acc = fmaf(logits[t], float(v[(slots[t] * HK + kh) * DV + d]), acc);
        partial[si * DV + d] = acc;
    }
}

template <typename T>
__global__ void combine_parts(
    const float* __restrict__ partial, const float* __restrict__ stats,
    T* __restrict__ output, int NS, int DV)
{
    int bh = blockIdx.x;
    extern __shared__ float weights[];
    __shared__ float denominator;
    if (threadIdx.x == 0) {
        float mx = -INFINITY;
        for (int s = 0; s < NS; ++s)
            mx = fmaxf(mx, stats[(int64_t(bh) * NS + s) * 2]);
        float sum = 0.0f;
        for (int s = 0; s < NS; ++s) {
            int64_t i = (int64_t(bh) * NS + s) * 2;
            float w = expf(stats[i] - mx);
            weights[s] = w;
            sum = fmaf(w, stats[i + 1], sum);
        }
        denominator = sum;
    }
    __syncthreads();
    for (int d = threadIdx.x; d < DV; d += blockDim.x) {
        float val = 0.0f;
        for (int s = 0; s < NS; ++s)
            val = fmaf(weights[s], partial[(int64_t(bh) * NS + s) * DV + d], val);
        output[int64_t(bh) * DV + d] = T(val / denominator);
    }
}

torch::Tensor paged_decode(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                           torch::Tensor pages, torch::Tensor lengths,
                           double scale)
{
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda(), "GPU tensors required");
    TORCH_CHECK(pages.scalar_type() == at::kInt || pages.scalar_type() == at::kLong,
                "page_tables must be int32 or int64");
    TORCH_CHECK(lengths.scalar_type() == at::kInt || lengths.scalar_type() == at::kLong,
                "seq_lens must be int32 or int64");
    q = q.contiguous();
    k = k.contiguous();
    v = v.contiguous();
    pages = pages.contiguous();
    lengths = lengths.contiguous();

    int B = q.size(0), H = q.size(1), D = q.size(2);
    int HK = k.size(2), PS = k.size(1), DV = v.size(3);
    int NP = pages.size(1);
    int NS = (int64_t(NP) * PS + TOKENS - 1) / TOKENS;
    TORCH_CHECK(HK > 0 && H % HK == 0 && NS > 0, "Invalid attention dimensions");
    auto out = torch::empty({B, H, DV}, q.options());
    if (B == 0) return out;
    auto partial = torch::empty({B, H, NS, DV}, q.options().dtype(at::kFloat));
    auto stats = torch::empty({B, H, NS, 2}, q.options().dtype(at::kFloat));
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16, q.scalar_type(), "paged_decode", [&] {
        attention_parts<scalar_t><<<dim3(B * H, NS), THREADS, D * sizeof(float), stream>>>(
            q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
            pages.data_ptr(), lengths.data_ptr(),
            pages.scalar_type() == at::kLong, lengths.scalar_type() == at::kLong,
            partial.data_ptr<float>(), stats.data_ptr<float>(),
            H, HK, D, DV, PS, NP, NS, float(scale));
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        combine_parts<scalar_t><<<B * H, THREADS, NS * sizeof(float), stream>>>(
            partial.data_ptr<float>(), stats.data_ptr<float>(),
            out.data_ptr<scalar_t>(), NS, DV);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    });
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "paged_decode_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, page_size: int, head_dim_qk: int, head_dim_v: int, num_kv_splits: int = 8, scale=None):
        super().__init__()
        self.page_size = int(page_size)
        self.head_dim_qk = int(head_dim_qk)
        self.head_dim_v = int(head_dim_v)
        self.num_kv_splits = int(num_kv_splits)
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim_qk)

    def forward(self, q, key_cache, value_cache, page_tables, seq_lens):
        return _get_extension().paged_decode(
            q, key_cache, value_cache, page_tables, seq_lens, self.scale
        )
