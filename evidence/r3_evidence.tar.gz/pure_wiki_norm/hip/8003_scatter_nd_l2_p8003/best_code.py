import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor run(torch::Tensor data, torch::Tensor indices, torch::Tensor updates);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>
#include <cstdint>

struct Layout {
    int64_t sizes[6];
    int64_t row_stride;
    int64_t col_stride;
    int rank;
};

template<class T>
__global__ void copy_bits(const T* __restrict__ src,
                          T* __restrict__ dst, int64_t n) {
    int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    const int64_t step = (int64_t)gridDim.x * blockDim.x;
    for (; i < n; i += step)
        dst[i] = src[i];
}

template<class T, class I>
__global__ void write_values(T* __restrict__ dst,
                             const I* __restrict__ idx,
                             const T* __restrict__ values,
                             int64_t k, Layout layout) {
    int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    const int64_t step = (int64_t)gridDim.x * blockDim.x;
    for (; i < k; i += step) {
        int64_t offset = 0;
        #pragma unroll
        for (int d = 0; d < 6; ++d) {
            if (d < layout.rank) {
                offset = offset * layout.sizes[d]
                       + (int64_t)idx[i * layout.row_stride
                                      + d * layout.col_stride];
            }
        }
        dst[offset] = values[i];
    }
}

template<class T, class I>
void launch_write(torch::Tensor& out, const torch::Tensor& idx,
                  const torch::Tensor& updates, Layout layout,
                  hipStream_t stream) {
    int64_t k = updates.numel();
    int blocks = (int)((k + 255) / 256);
    if (blocks > 65535) blocks = 65535;
    if (blocks) {
        write_values<T, I><<<blocks, 256, 0, stream>>>(
            reinterpret_cast<T*>(out.data_ptr()),
            reinterpret_cast<const I*>(idx.data_ptr()),
            reinterpret_cast<const T*>(updates.data_ptr()), k, layout);
    }
}

template<class T>
void launch(torch::Tensor& out, const torch::Tensor& data,
            const torch::Tensor& idx, const torch::Tensor& updates,
            Layout layout, hipStream_t stream) {
    int64_t n = data.numel();
    // Distinct full-coordinate tuples cover the entire output when K == N.
    if (updates.numel() != n) {
        int blocks = (int)((n + 255) / 256);
        if (blocks > 65535) blocks = 65535;
        if (blocks) {
            copy_bits<T><<<blocks, 256, 0, stream>>>(
                reinterpret_cast<const T*>(data.data_ptr()),
                reinterpret_cast<T*>(out.data_ptr()), n);
        }
    }
    switch (idx.scalar_type()) {
        case at::ScalarType::Long:
            launch_write<T, int64_t>(out, idx, updates, layout, stream);
            break;
        case at::ScalarType::Int:
            launch_write<T, int32_t>(out, idx, updates, layout, stream);
            break;
        case at::ScalarType::Float:
            launch_write<T, float>(out, idx, updates, layout, stream);
            break;
        case at::ScalarType::Double:
            launch_write<T, double>(out, idx, updates, layout, stream);
            break;
        default:
            TORCH_CHECK(false, "Unsupported coordinate dtype");
    }
}

torch::Tensor run(torch::Tensor data, torch::Tensor indices,
                  torch::Tensor updates) {
    c10::cuda::CUDAGuard guard(data.device());
    TORCH_CHECK(data.is_contiguous() && updates.is_contiguous(),
                "Data and updates must be contiguous");
    TORCH_CHECK(data.scalar_type() == updates.scalar_type(),
                "Data and updates must have identical dtypes");
    TORCH_CHECK(data.dim() >= 1 && data.dim() <= 6,
                "Expected rank between one and six");
    auto out = torch::empty(data.sizes(), data.options());
    Layout layout{};
    layout.rank = data.dim();
    for (int d = 0; d < layout.rank; ++d)
        layout.sizes[d] = data.size(d);
    layout.row_stride = indices.stride(0);
    layout.col_stride = indices.stride(1);
    hipStream_t stream = c10::cuda::getCurrentCUDAStream(data.get_device()).stream();
    if (data.scalar_type() == at::ScalarType::Float) {
        launch<uint32_t>(out, data, indices, updates, layout, stream);
    } else if (data.scalar_type() == at::ScalarType::Half ||
               data.scalar_type() == at::ScalarType::BFloat16) {
        launch<uint16_t>(out, data, indices, updates, layout, stream);
    } else {
        TORCH_CHECK(false, "Unsupported data dtype");
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="coordinate_overwrite_" + digest,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, data, indices, updates):
        return _get_extension().run(data, indices, updates)
