import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_gemm(torch::Tensor x,
                           torch::Tensor w,
                           torch::Tensor xs,
                           torch::Tensor ws,
                           torch::Tensor bias,
                           int64_t out_kind,
                           bool use_bias);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pyramid_gemm", &pyramid_gemm, "Quantized scaled GEMM");
}
"""

_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

__device__ __forceinline__ float fp8_e4m3fn(uint8_t v) {
    const int s = (v >> 7) & 1;
    const int e = (v >> 3) & 15;
    const int m = v & 7;
    float r;
    if (e == 0) {
        r = ldexpf((float)m, -9);
    } else if (e == 15 && m == 7) {
        r = nanf("");
    } else if (e == 15) {
        r = ldexpf(8.0f + (float)m, 5);
    } else {
        r = ldexpf(8.0f + (float)m, e - 10);
    }
    return s ? -r : r;
}

__device__ __forceinline__ float fp8_e5m2(uint8_t v) {
    const int s = (v >> 7) & 1;
    const int e = (v >> 2) & 31;
    const int m = v & 3;
    float r;
    if (e == 0) {
        r = ldexpf((float)m, -16);
    } else if (e == 31) {
        r = (m == 0) ? INFINITY : nanf("");
    } else {
        r = ldexpf(4.0f + (float)m, e - 17);
    }
    return s ? -r : r;
}

__device__ __forceinline__ float load_code(
    const void* p, int64_t idx, int kind) {
    if (kind == 0) {
        return (float)((const int8_t*)p)[idx];
    }
    uint8_t v = ((const uint8_t*)p)[idx];
    return kind == 1 ? fp8_e4m3fn(v) : fp8_e5m2(v);
}

__device__ __forceinline__ uint16_t f32_to_bf16(float x) {
    uint32_t u = __float_as_uint(x);
    uint32_t l = u & 0xffffu;
    uint32_t r = 0x7fffu + ((u >> 16) & 1u);
    u += r;
    return (uint16_t)(u >> 16);
}

__device__ __forceinline__ uint16_t f32_to_f16(float x) {
    uint32_t u = __float_as_uint(x);
    uint32_t s = (u >> 16) & 0x8000u;
    int32_t e = (int32_t)((u >> 23) & 0xffu) - 127 + 15;
    uint32_t m = u & 0x7fffffu;

    if (e <= 0) {
        if (e < -10) return (uint16_t)s;
        m |= 0x800000u;
        int shift = 14 - e;
        uint32_t q = m >> shift;
        uint32_t rem = m & ((1u << shift) - 1u);
        uint32_t halfway = 1u << (shift - 1);
        if (rem > halfway || (rem == halfway && (q & 1u))) ++q;
        return (uint16_t)(s | q);
    }
    if (e >= 31) {
        if ((u & 0x7fffffffU) >= 0x7f800000U)
            return (uint16_t)(s | 0x7c00u | (m ? 0x0200u : 0));
        return (uint16_t)(s | 0x7c00u);
    }

    uint32_t q = m >> 13;
    uint32_t rem = m & 0x1fffu;
    if (rem > 0x1000u || (rem == 0x1000u && (q & 1u))) {
        ++q;
        if (q == 0x400u) {
            q = 0;
            ++e;
            if (e >= 31) return (uint16_t)(s | 0x7c00u);
        }
    }
    return (uint16_t)(s | ((uint32_t)e << 10) | q);
}

template<int OUT_KIND>
__global__ void gemm_kernel(
    const void* __restrict__ x,
    const void* __restrict__ w,
    const float* __restrict__ xs,
    const float* __restrict__ ws,
    const float* __restrict__ bias,
    void* __restrict__ out,
    int M, int N, int K, int in_kind, bool use_bias) {
    constexpr int TILE = 16;
    __shared__ float sx[TILE][TILE];
    __shared__ float sw[TILE][TILE];

    int row = (int)blockIdx.y * TILE + (int)threadIdx.y;
    int col = (int)blockIdx.x * TILE + (int)threadIdx.x;
    float acc = 0.0f;

    for (int kb = 0; kb < K; kb += TILE) {
        int kx = kb + (int)threadIdx.x;
        int kw = kb + (int)threadIdx.y;

        sx[threadIdx.y][threadIdx.x] =
            (row < M && kx < K) ? load_code(x, (int64_t)row * K + kx, in_kind) : 0.0f;

        sw[threadIdx.y][threadIdx.x] =
            (col < N && kw < K) ? load_code(w, (int64_t)col * K + kw, in_kind) : 0.0f;

        __syncthreads();

        int lim = min(TILE, K - kb);
        #pragma unroll
        for (int k = 0; k < TILE; ++k) {
            if (k < lim) acc = fmaf(sx[threadIdx.y][k], sw[k][threadIdx.x], acc);
        }
        __syncthreads();
    }

    if (row < M && col < N) {
        float v = acc * xs[row] * ws[col];
        if (use_bias) v += bias[col];

        uint16_t bits;
        if (OUT_KIND == 0) bits = f32_to_bf16(v);
        else bits = f32_to_f16(v);

        ((uint16_t*)out)[(int64_t)row * N + col] = bits;
    }
}

torch::Tensor pyramid_gemm(torch::Tensor x,
                           torch::Tensor w,
                           torch::Tensor xs,
                           torch::Tensor ws,
                           torch::Tensor bias,
                           int64_t out_kind,
                           bool use_bias) {
    const int M = (int)x.size(0);
    const int K = (int)x.size(1);
    const int N = (int)w.size(0);

    auto options = torch::TensorOptions()
        .device(x.device())
        .dtype(out_kind == 0 ? torch::kBFloat16 : torch::kFloat16);
    auto out = torch::empty({M, N}, options);

    int in_kind;
    if (x.scalar_type() == torch::kInt8) in_kind = 0;
    else if (x.scalar_type() == torch::kFloat8_e4m3fn) in_kind = 1;
    else in_kind = 2;

    dim3 block(16, 16);
    dim3 grid((N + 15) / 16, (M + 15) / 16);
    hipStream_t stream = at::cuda::getDefaultCUDAStream();

    if (out_kind == 0) {
        hipLaunchKernelGGL(
            (gemm_kernel<0>), grid, block, 0, stream,
            x.data_ptr(), w.data_ptr(),
            xs.data_ptr<float>(), ws.data_ptr<float>(),
            bias.data_ptr<float>(), out.data_ptr(),
            M, N, K, in_kind, use_bias);
    } else {
        hipLaunchKernelGGL(
            (gemm_kernel<1>), grid, block, 0, stream,
            x.data_ptr(), w.data_ptr(),
            xs.data_ptr<float>(), ws.data_ptr<float>(),
            bias.data_ptr<float>(), out.data_ptr(),
            M, N, K, in_kind, use_bias);
    }

    return out;
}
"""

def _get_extension():
    global _EXT
    if _EXT is None:
        _EXT = load_inline(
            name="pyramidkernel_dcu_gemm",
            cpp_sources=_CPP_SRC,
            cuda_sources=_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, in_dtype="fp8e4m3", out_dtype="bfloat16", use_bias=True):
        super().__init__()
        quant = {
            "fp8e4m3": torch.float8_e4m3fn,
            "fp8e5m2": torch.float8_e5m2,
            "int8": torch.int8,
        }
        out = {
            "bfloat16": torch.bfloat16,
            "float16": torch.float16,
        }
        self.in_dtype = quant[in_dtype]
        self.out_dtype = out[out_dtype]
        self.use_bias = bool(use_bias)
        self._out_kind = 0 if out_dtype == "bfloat16" else 1

    def forward(self, x, w, x_scale, w_scale, bias):
        x = x.to(self.in_dtype).contiguous()
        w = w.to(self.in_dtype).contiguous()
        x_scale = x_scale.to(torch.float32).contiguous()
        w_scale = w_scale.to(torch.float32).contiguous()
        bias = bias.to(torch.float32).contiguous()

        M, K = x.shape
        N = w.shape[0]
        assert K == w.shape[1], "x and w must agree on the K dimension"

        return _get_extension().pyramid_gemm(
            x, w, x_scale, w_scale, bias,
            self._out_kind, self.use_bias
        )
