import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor quantize_hip(torch::Tensor x, int64_t group_size, double eps);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("quantize", &quantize_hip);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

__device__ __forceinline__ float quant_code(float x, float scale) {
    float q = __fdiv_rn(x, scale);
    q = fminf(127.0f, fmaxf(-128.0f, q));
    return static_cast<float>(static_cast<int>(q));
}

template<int GS, int W>
__global__ void quant_fixed(
    const float* __restrict__ x,
    float* __restrict__ out,
    int64_t n, int64_t groups, float eps)
{
    constexpr int K = (GS + W - 1) / W;
    const int lane = threadIdx.x % W;
    const int64_t g = static_cast<int64_t>(blockIdx.x) * (256 / W)
                    + threadIdx.x / W;
    if (g >= groups) return;

    float values[K];
    float a = 0.0f;
    #pragma unroll
    for (int j = 0; j < K; ++j) {
        const int i = j * W + lane;
        float v = i < GS ? x[g * GS + i] : 0.0f;
        values[j] = v;
        a = fmaxf(a, fabsf(v));
    }
    #pragma unroll
    for (int d = W / 2; d > 0; d >>= 1)
        a = fmaxf(a, __shfl_xor(a, d, W));

    float scale = __fdiv_rn(fmaxf(a, eps), 127.0f);
    if (lane == 0) out[n + g] = scale;
    #pragma unroll
    for (int j = 0; j < K; ++j) {
        int i = j * W + lane;
        if (i < GS)
            out[g * GS + i] = quant_code(values[j], scale);
    }
}

__global__ void quant_generic(
    const float* __restrict__ x,
    float* __restrict__ out,
    int64_t n, int64_t groups, int64_t gs, float eps)
{
    const int lane = threadIdx.x & 63;
    const int64_t g = static_cast<int64_t>(blockIdx.x) * 4 + threadIdx.x / 64;
    if (g >= groups) return;
    const int64_t base = g * gs;
    float a = 0.0f;
    for (int64_t i = lane; i < gs; i += 64)
        a = fmaxf(a, fabsf(x[base + i]));
    #pragma unroll
    for (int d = 32; d > 0; d >>= 1)
        a = fmaxf(a, __shfl_xor(a, d, 64));
    float scale = __fdiv_rn(fmaxf(a, eps), 127.0f);
    if (lane == 0) out[n + g] = scale;
    for (int64_t i = lane; i < gs; i += 64)
        out[base + i] = quant_code(x[base + i], scale);
}

torch::Tensor quantize_hip(torch::Tensor x, int64_t gs, double eps) {
    TORCH_CHECK(x.is_cuda(), "x must reside on the accelerator");
    TORCH_CHECK(x.scalar_type() == at::kFloat, "x must be float32");
    TORCH_CHECK(x.dim() == 2 && x.is_contiguous(), "x must be contiguous and 2D");
    TORCH_CHECK(gs > 0 && x.size(1) % gs == 0, "invalid group_size");
    c10::cuda::CUDAGuard guard(x.device());
    int64_t n = x.numel();
    int64_t groups = n / gs;
    auto out = torch::empty({n + groups}, x.options());
    if (!groups) return out;
    auto stream = at::cuda::getCurrentCUDAStream();
    const float* src = x.data_ptr<float>();
    float* dst = out.data_ptr<float>();
    float e = static_cast<float>(eps);

    #define DISPATCH(G, W) \
        case G: quant_fixed<G, W><<<(groups + 256/W - 1)/(256/W), 256, 0, stream>>>( \
            src, dst, n, groups, e); break;

    switch (gs) {
        DISPATCH(1, 1)
        DISPATCH(2, 2)
        DISPATCH(4, 4)
        DISPATCH(8, 8)
        DISPATCH(16, 16)
        DISPATCH(32, 32)
        DISPATCH(64, 64)
        DISPATCH(128, 64)
        DISPATCH(256, 64)
        DISPATCH(512, 64)
        DISPATCH(1024, 64)
        DISPATCH(2048, 64)
        default:
            quant_generic<<<(groups + 3)/4, 256, 0, stream>>>(
                src, dst, n, groups, gs, e);
    }
    #undef DISPATCH
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="group_quant_hip_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-fno-fast-math", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, group_size: int = 128, eps: float = 1e-10):
        super().__init__()
        self.group_size = int(group_size)
        self.eps = float(eps)

    def forward(self, x):
        return _extension().quantize(x, self.group_size, self.eps)
