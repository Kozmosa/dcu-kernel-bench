import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor run(torch::Tensor x, torch::Tensor offset,
                  torch::Tensor weight, torch::Tensor bias, torch::Tensor mask,
                  int sh, int sw, int ph, int pw, int dh, int dw, bool mod);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template<class T>
__device__ __forceinline__ float read_corner(
    const T* x, int y, int z, int H, int W) {
    return (y >= 0 && y < H && z >= 0 && z < W)
        ? float(x[(int64_t)y * W + z]) : 0.0f;
}

template<class T, bool MOD>
__global__ void sample_kernel(
    const T* __restrict__ x, const T* __restrict__ off,
    const T* __restrict__ mask, float* __restrict__ col,
    int C, int H, int W, int R, int S, int OH, int OW,
    int sh, int sw, int ph, int pw, int dh, int dw,
    int64_t total) {
    int L = OH * OW, P = R * S;
    for (int64_t idx = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
         idx < total; idx += (int64_t)gridDim.x * blockDim.x) {
        int q = idx % L;
        int64_t t = idx / L;
        int p = t % P;
        t /= P;
        int c = t % C, n = t / C;
        int64_t o = ((int64_t)n * 2 * P + 2 * p) * L + q;
        float y = float((q / OW) * sh - ph + (p / S) * dh) + float(off[o]);
        float z = float((q % OW) * sw - pw + (p % S) * dw) + float(off[o + L]);
        float v = 0.0f;
        if (y > -1.0f && y < H && z > -1.0f && z < W) {
            int iy = (int)floorf(y), iz = (int)floorf(z);
            float wy = y - iy, wx = z - iz;
            const T* src = x + ((int64_t)n * C + c) * H * W;
            float a = read_corner(src, iy, iz, H, W) * ((1.0f-wy)*(1.0f-wx));
            float b = read_corner(src, iy, iz+1, H, W) * ((1.0f-wy)*wx);
            float d = read_corner(src, iy+1, iz, H, W) * (wy*(1.0f-wx));
            float e = read_corner(src, iy+1, iz+1, H, W) * (wy*wx);
            v = ((a+b)+d)+e;
        }
        if (MOD) v *= float(mask[((int64_t)n * P + p) * L + q]);
        col[idx] = v;
    }
}

template<class T>
__global__ __launch_bounds__(256) void product_kernel(
    const T* __restrict__ weight, const float* __restrict__ col,
    const T* __restrict__ bias, T* __restrict__ out,
    int K, int D, int L) {
    __shared__ float as[32][16];
    __shared__ float bs[16][64];
    int tid = threadIdx.x;
    int row = tid / 16;
    int lane = tid % 16;
    int m0 = blockIdx.y * 32, n0 = blockIdx.x * 64;
    int batch = blockIdx.z;
    const float* b = col + (int64_t)batch * D * L;
    float acc[2][4] = {};
    for (int d0 = 0; d0 < D; d0 += 16) {
        #pragma unroll
        for (int i = 0; i < 2; ++i) {
            int t = tid + 256 * i;
            int r = t / 16, d = t % 16;
            as[r][d] = (m0+r < K && d0+d < D)
                ? float(weight[(int64_t)(m0+r)*D+d0+d]) : 0.0f;
        }
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            int t = tid + 256*i;
            int d = t / 64, q = t % 64;
            bs[d][q] = (d0+d < D && n0+q < L)
                ? b[(int64_t)(d0+d)*L+n0+q] : 0.0f;
        }
        __syncthreads();
        #pragma unroll
        for (int d = 0; d < 16; ++d) {
            float a0 = as[row][d], a1 = as[row+16][d];
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                float v = bs[d][lane+16*j];
                acc[0][j] = fmaf(a0, v, acc[0][j]);
                acc[1][j] = fmaf(a1, v, acc[1][j]);
            }
        }
        __syncthreads();
    }
    #pragma unroll
    for (int i = 0; i < 2; ++i) {
        int m = m0+row+16*i;
        if (m < K) {
            float bv = float(bias[m]);
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                int q = n0+lane+16*j;
                if (q < L)
                    out[((int64_t)batch*K+m)*L+q] = T(acc[i][j]+bv);
            }
        }
    }
}

torch::Tensor run(torch::Tensor x, torch::Tensor offset,
                  torch::Tensor weight, torch::Tensor bias, torch::Tensor mask,
                  int sh, int sw, int ph, int pw, int dh, int dw, bool mod) {
    c10::cuda::CUDAGuard guard(x.device());
    int N=x.size(0), C=x.size(1), H=x.size(2), W=x.size(3);
    int K=weight.size(0), R=weight.size(2), S=weight.size(3);
    int OH=(H+2*ph-dh*(R-1)-1)/sh+1;
    int OW=(W+2*pw-dw*(S-1)-1)/sw+1;
    int D=C*R*S, L=OH*OW;
    auto out=torch::empty({N,K,OH,OW}, x.options());
    auto col=torch::empty({N,D,L}, x.options().dtype(torch::kFloat32));
    int64_t total=(int64_t)N*D*L;
    if (!total || !K) return out;
    int blocks=(int)std::min<int64_t>((total+255)/256,65535);
    auto stream=at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "deform_forward", [&] {
        if (mod) {
            sample_kernel<scalar_t,true><<<blocks,256,0,stream>>>(
                x.data_ptr<scalar_t>(),offset.data_ptr<scalar_t>(),
                mask.data_ptr<scalar_t>(),col.data_ptr<float>(),
                C,H,W,R,S,OH,OW,sh,sw,ph,pw,dh,dw,total);
        } else {
            sample_kernel<scalar_t,false><<<blocks,256,0,stream>>>(
                x.data_ptr<scalar_t>(),offset.data_ptr<scalar_t>(),
                nullptr,col.data_ptr<float>(),
                C,H,W,R,S,OH,OW,sh,sw,ph,pw,dh,dw,total);
        }
        product_kernel<scalar_t><<<dim3((L+63)/64,(K+31)/32,N),256,0,stream>>>(
            weight.data_ptr<scalar_t>(),col.data_ptr<float>(),
            bias.data_ptr<scalar_t>(),out.data_ptr<scalar_t>(),K,D,L);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "deform_hip_" + hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, variant: str = "modulated", stride=(1, 1), padding=(1, 1), dilation=(1, 1)):
        super().__init__()
        assert variant in ("modulated", "plain")
        self.variant = variant
        self.stride = (int(stride[0]), int(stride[1]))
        self.padding = (int(padding[0]), int(padding[1]))
        self.dilation = (int(dilation[0]), int(dilation[1]))

    def forward(self, x, offset, weight, bias, mask):
        return _get_extension().run(
            x, offset, weight, bias, mask,
            *self.stride, *self.padding, *self.dilation,
            self.variant == "modulated",
        )
