import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

_CPP = r"""
#include <torch/extension.h>

torch::Tensor run_fused(torch::Tensor x, torch::Tensor weight,
                        torch::Tensor bias, int64_t bs, bool crd);
torch::Tensor run_dts(torch::Tensor x, int64_t bs, bool crd);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run_fused", &run_fused);
    m.def("run_dts", &run_dts);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template <typename T>
__device__ __forceinline__ float to_float(T v) {
    return static_cast<float>(v);
}

template <typename T>
__device__ __forceinline__ T from_float(float v) {
    return static_cast<T>(v);
}

template <typename T>
__global__ void fused_kernel(
    const T* __restrict__ x,
    const T* __restrict__ w,
    const T* __restrict__ b,
    T* __restrict__ out,
    int64_t n,
    int64_t cin,
    int64_t h,
    int64_t wi,
    int64_t k,
    int64_t c,
    int64_t bs,
    bool crd
) {
    int64_t total = n * c * (h * bs) * (wi * bs);
    int64_t q = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (q >= total) return;

    int64_t ow = q % (wi * bs);
    q /= (wi * bs);
    int64_t oh = q % (h * bs);
    q /= (h * bs);
    int64_t cc = q % c;
    int64_t nn = q / c;

    int64_t rr = oh % bs;
    int64_t dd = ow % bs;
    int64_t iy0 = oh / bs;
    int64_t ix0 = ow / bs;

    int64_t kk;
    if (crd) {
        kk = cc * bs * bs + rr * bs + dd;
    } else {
        kk = (rr * bs + dd) * c + cc;
    }

    float acc = to_float(b[kk]);

    for (int64_t ci = 0; ci < cin; ++ci) {
        for (int64_t ky = 0; ky < 3; ++ky) {
            int64_t iy = iy0 + ky - 1;
            if (iy < 0 || iy >= h) continue;
            for (int64_t kx = 0; kx < 3; ++kx) {
                int64_t ix = ix0 + kx - 1;
                if (ix < 0 || ix >= wi) continue;

                int64_t xi = ((nn * cin + ci) * h + iy) * wi + ix;
                int64_t wi_idx = ((kk * cin + ci) * 3 + ky) * 3 + kx;
                acc += to_float(x[xi]) * to_float(w[wi_idx]);
            }
        }
    }

    out[((nn * c + cc) * (h * bs) + oh) * (wi * bs) + ow] =
        from_float<T>(acc);
}

template <typename T>
__global__ void dts_kernel(
    const T* __restrict__ x,
    T* __restrict__ out,
    int64_t n,
    int64_t k,
    int64_t h,
    int64_t wi,
    int64_t c,
    int64_t bs,
    bool crd
) {
    int64_t total = n * c * (h * bs) * (wi * bs);
    int64_t q = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (q >= total) return;

    int64_t ow = q % (wi * bs);
    q /= (wi * bs);
    int64_t oh = q % (h * bs);
    q /= (h * bs);
    int64_t cc = q % c;
    int64_t nn = q / c;

    int64_t rr = oh % bs;
    int64_t dd = ow % bs;
    int64_t iy = oh / bs;
    int64_t ix = ow / bs;

    int64_t kk;
    if (crd) {
        kk = cc * bs * bs + rr * bs + dd;
    } else {
        kk = (rr * bs + dd) * c + cc;
    }

    int64_t src = ((nn * k + kk) * h + iy) * wi + ix;
    int64_t dst = ((nn * c + cc) * (h * bs) + oh) * (wi * bs) + ow;
    out[dst] = x[src];
}

torch::Tensor run_fused(
    torch::Tensor x,
    torch::Tensor weight,
    torch::Tensor bias,
    int64_t bs,
    bool crd
) {
    TORCH_CHECK(x.is_cuda(), "x must be on accelerator");
    TORCH_CHECK(weight.is_cuda(), "weight must be on accelerator");
    TORCH_CHECK(bias.is_cuda(), "bias must be on accelerator");
    TORCH_CHECK(x.dim() == 4, "x must be four-dimensional");
    TORCH_CHECK(weight.dim() == 4, "weight must be four-dimensional");
    TORCH_CHECK(bias.dim() == 4, "bias must be four-dimensional");

    const int64_t n = x.size(0);
    const int64_t cin = x.size(1);
    const int64_t h = x.size(2);
    const int64_t wi = x.size(3);
    const int64_t k = weight.size(0);
    const int64_t c = k / (bs * bs);

    auto out = torch::empty({n, c, h * bs, wi * bs}, x.options());
    int64_t total = n * c * (h * bs) * (wi * bs);
    dim3 block(256);
    dim3 grid(static_cast<unsigned int>((total + 255) / 256));
    auto stream = at::cuda::getDefaultCUDAStream(x.device().index()).stream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "fused_kernel",
        [&] {
            hipLaunchKernelGGL(
                (fused_kernel<scalar_t>),
                grid,
                block,
                0,
                stream,
                x.data_ptr<scalar_t>(),
                weight.data_ptr<scalar_t>(),
                bias.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(),
                n, cin, h, wi, k, c, bs, crd
            );
        }
    );

    return out;
}

torch::Tensor run_dts(
    torch::Tensor x,
    int64_t bs,
    bool crd
) {
    TORCH_CHECK(x.is_cuda(), "x must be on accelerator");
    TORCH_CHECK(x.dim() == 4, "x must be four-dimensional");

    const int64_t n = x.size(0);
    const int64_t k = x.size(1);
    const int64_t h = x.size(2);
    const int64_t wi = x.size(3);
    const int64_t c = k / (bs * bs);

    auto out = torch::empty({n, c, h * bs, wi * bs}, x.options());
    int64_t total = n * c * (h * bs) * (wi * bs);
    dim3 block(256);
    dim3 grid(static_cast<unsigned int>((total + 255) / 256));
    auto stream = at::cuda::getDefaultCUDAStream(x.device().index()).stream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "dts_kernel",
        [&] {
            hipLaunchKernelGGL(
                (dts_kernel<scalar_t>),
                grid,
                block,
                0,
                stream,
                x.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(),
                n, k, h, wi, c, bs, crd
            );
        }
    );

    return out;
}
"""

def _get_extension():
    global _EXT
    if _EXT is None:
        key = hashlib.sha1((_CPP + _HIP).encode("utf-8")).hexdigest()[:12]
        _EXT = load_inline(
            name="dts_fused_" + key,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, variant: str = "conv_bias_dts",
                 mode: str = "CRD", block_size: int = 2):
        super().__init__()
        assert variant in ("conv_bias_dts", "dts")
        assert mode in ("CRD", "DCR")
        assert block_size in (2, 3, 4)
        self.variant = variant
        self.mode = mode
        self.block_size = block_size

    def forward(self, x, weight=None, bias=None):
        ext = _get_extension()
        crd = self.mode == "CRD"
        if self.variant == "conv_bias_dts":
            return ext.run_fused(x, weight, bias, self.block_size, crd)
        return ext.run_dts(x, self.block_size, crd)
