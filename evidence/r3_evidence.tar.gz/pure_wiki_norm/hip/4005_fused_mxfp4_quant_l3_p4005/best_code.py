import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor fused_mxfp4(
    torch::Tensor inp,
    torch::Tensor weight,
    torch::Tensor residual,
    double eps);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_mxfp4", &fused_mxfp4, "Fused residual RMSNorm MXFP4");
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <stdint.h>
#include <math.h>

__global__ void rmsnorm_kernel(
    const float* __restrict__ inp,
    const float* __restrict__ weight,
    const float* __restrict__ residual,
    float* __restrict__ norm,
    int64_t rows,
    int64_t cols,
    float eps)
{
    int64_t row = (int64_t)blockIdx.x;
    if (row >= rows) return;

    extern __shared__ float smem[];
    float sum = 0.0f;
    int tid = threadIdx.x;
    int nthreads = blockDim.x;
    int64_t base = row * cols;

    for (int64_t j = tid; j < cols; j += nthreads) {
        float v = inp[base + j] + residual[base + j];
        sum = fmaf(v, v, sum);
    }

    smem[tid] = sum;
    __syncthreads();

    for (int stride = nthreads >> 1; stride > 0; stride >>= 1) {
        if (tid < stride)
            smem[tid] += smem[tid + stride];
        __syncthreads();
    }

    float inv = rsqrtf(smem[0] / (float)cols + eps);

    for (int64_t j = tid; j < cols; j += nthreads) {
        float v = inp[base + j] + residual[base + j];
        norm[base + j] = v * inv * weight[j];
    }
}

__global__ void quant_kernel(
    const float* __restrict__ norm,
    uint8_t* __restrict__ out,
    int64_t rows,
    int64_t cols,
    int64_t blocks)
{
    int64_t linear = (int64_t)blockIdx.x;
    int64_t row = linear / blocks;
    int64_t block = linear - row * blocks;
    if (row >= rows) return;

    int tid = threadIdx.x;
    int64_t start = block * 32;
    int64_t base = row * cols;

    __shared__ float vmax[32];
    __shared__ int scale_exp;

    float av = 0.0f;
    int64_t idx = start + tid;
    if (idx < cols) {
        float v = norm[base + idx];
        av = fabsf(v);
    }
    vmax[tid] = av;
    __syncthreads();

    for (int stride = 16; stride > 0; stride >>= 1) {
        if (tid < stride) {
            float b = vmax[tid + stride];
            if (b > vmax[tid]) vmax[tid] = b;
        }
        __syncthreads();
    }

    if (tid == 0) {
        uint32_t bits = __float_as_uint(vmax[0]);
        bits = (bits + 0x00200000u) & 0xff800000u;
        int exponent = (int)((bits >> 23) & 0xffu);
        int e = exponent - 129;
        if (e < -127) e = -127;
        if (e > 127) e = 127;
        scale_exp = e;
        out[row * (cols / 2 + blocks) + cols / 2 + block] =
            (uint8_t)(e + 127);
    }
    __syncthreads();

    int eblock = scale_exp;
    float scale = ldexpf(1.0f, -eblock);

    if (tid < 32) {
        int64_t j = start + tid;
        uint8_t code = 0;

        if (j < cols) {
            float q = norm[base + j] * scale;
            uint32_t bits = __float_as_uint(q);
            uint32_t sign = (bits >> 28) & 0x0fu;
            uint32_t e = (bits >> 23) & 0xffu;
            uint32_t m = bits & 0x7fffffu;

            if (e < 127u) {
                uint32_t shift = 126u - e;
                uint32_t mant = 0x400000u | (m >> 1);
                m = shift >= 32u ? 0u : (mant >> shift);
            }

            uint32_t ee = e > 126u ? e : 126u;
            ee -= 126u;

            uint32_t combined = ((ee << 2) | (m >> 21)) + 1u;
            combined >>= 1;
            if (combined > 7u) combined = 7u;

            code = (uint8_t)(sign | combined);
        }

        if ((tid & 1) == 0) {
            int64_t pair = start / 2 + tid / 2;
            if (pair < cols / 2)
                out[row * (cols / 2 + blocks) + pair] = code;
        } else {
            int64_t pair = start / 2 + tid / 2;
            if (pair < cols / 2) {
                uint8_t* dst = out + row * (cols / 2 + blocks) + pair;
                *dst = (uint8_t)(*dst | (uint8_t)(code << 4));
            }
        }
    }
}

torch::Tensor fused_mxfp4(
    torch::Tensor inp,
    torch::Tensor weight,
    torch::Tensor residual,
    double eps)
{
    TORCH_CHECK(inp.is_cuda(), "inp must be on accelerator");
    TORCH_CHECK(weight.is_cuda(), "weight must be on accelerator");
    TORCH_CHECK(residual.is_cuda(), "residual must be on accelerator");
    TORCH_CHECK(inp.scalar_type() == at::kFloat, "inp must be float32");
    TORCH_CHECK(weight.scalar_type() == at::kFloat, "weight must be float32");
    TORCH_CHECK(residual.scalar_type() == at::kFloat, "residual must be float32");
    TORCH_CHECK(inp.dim() == 2, "inp must be 2D");
    TORCH_CHECK(weight.dim() == 1, "weight must be 1D");
    TORCH_CHECK(residual.sizes() == inp.sizes(), "shape mismatch");

    auto x = inp.contiguous();
    auto w = weight.contiguous();
    auto r = residual.contiguous();

    int64_t rows = x.size(0);
    int64_t cols = x.size(1);
    int64_t blocks = (cols + 31) / 32;
    int64_t out_cols = cols / 2 + blocks;

    auto norm = at::empty_like(x);
    auto out = at::empty(
        {rows, out_cols},
        x.options().dtype(at::kByte));

    auto stream = at::cuda::getDefaultCUDAStream();

    constexpr int threads = 256;
    rmsnorm_kernel<<<(unsigned)rows, threads, threads * sizeof(float), stream>>>(
        x.data_ptr<float>(),
        w.data_ptr<float>(),
        r.data_ptr<float>(),
        norm.data_ptr<float>(),
        rows,
        cols,
        (float)eps);

    quant_kernel<<<(unsigned)(rows * blocks), 32, 0, stream>>>(
        norm.data_ptr<float>(),
        out.data_ptr<uint8_t>(),
        rows,
        cols,
        blocks);

    return out;
}
"""

_EXT = None

def _get_extension():
    global _EXT
    if _EXT is None:
        name = "mxfp4_fused_" + hashlib.sha1(
            (_CPP_SRC + _HIP_SRC).encode("utf-8")
        ).hexdigest()[:16]
        _EXT = load_inline(
            name=name,
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, dtype: str = "bfloat16", eps: float = 1e-6):
        super().__init__()
        self.dtype = getattr(torch, dtype)
        self.eps = float(eps)

    def forward(self, inp1, weight1, res1):
        return _get_extension().fused_mxfp4(
            inp1,
            weight1,
            res1,
            self.eps,
        )
