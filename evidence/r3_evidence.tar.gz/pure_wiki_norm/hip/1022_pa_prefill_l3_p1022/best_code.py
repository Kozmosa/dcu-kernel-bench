import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_forward(torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor kc, torch::Tensor vc, torch::Tensor bt, torch::Tensor starts,
    torch::Tensor lens, c10::optional<torch::Tensor> slopes, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &paged_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

constexpr int TILE = 256;

template<class T, class I>
__global__ void partial_attention(
    const T* __restrict__ q, const T* __restrict__ k,
    const T* __restrict__ v, const T* __restrict__ kc,
    const T* __restrict__ vc, const I* __restrict__ bt,
    const int* __restrict__ starts, const int* __restrict__ lens,
    const float* __restrict__ slopes, float* __restrict__ work,
    int H, int HK, int D, int BS, int X, int NB, int B, int S,
    float scale)
{
    int token = blockIdx.x, h = blockIdx.y, split = blockIdx.z;
    int tid = threadIdx.x;
    int lo = 0, hi = B;
    while (lo + 1 < hi) {
        int mid = (lo + hi) / 2;
        if (starts[mid] <= token) lo = mid;
        else hi = mid;
    }
    int b = lo, start = starts[b];
    int ctx = lens[b] - (starts[b+1] - start);
    int pos = ctx + token - start;
    int base = split * TILE;
    int count = min(TILE, pos + 1 - base);
    int kh = h / (H / HK);
    long long offset = ((long long)token * H + h) * S * (D + 2)
                     + (long long)split * (D + 2);
    float* dst = work + offset;
    if (count <= 0) {
        for (int d = tid; d < D; d += 256) dst[d] = 0;
        if (tid == 0) { dst[D] = -INFINITY; dst[D+1] = 0; }
        return;
    }
    extern __shared__ float shared[];
    float* qs = shared;
    float* logits = qs + D;
    float* red = logits + TILE;
    for (int d = tid; d < D; d += 256)
        qs[d] = float(q[((long long)token * H + h)*D+d]) * scale;
    __syncthreads();

    int lane = tid & 31;
    int group = tid >> 5;
    for (int t = group; t < TILE; t += 8) {
        int l = base + t;
        float dot = 0;
        if (t < count) {
            if (l < ctx) {
                long long p = (long long)bt[(long long)b * NB + l / BS];
                long long off = (p * HK + kh) * D * BS;
                int slot = l % BS;
                for (int d = lane; d < D; d += 32)
                    dot = fmaf(qs[d], float(kc[off + (d/X)*BS*X + slot*X + d%X]), dot);
            } else {
                long long off = ((long long)(start+l-ctx)*HK+kh)*D;
                for (int d = lane; d < D; d += 32)
                    dot = fmaf(qs[d], float(k[off+d]), dot);
            }
        }
        for (int delta = 16; delta; delta >>= 1)
            dot += __shfl_down(dot, delta, 32);
        if (lane == 0) {
            if (t < count) {
                if (slopes) dot += slopes[h] * (l - pos);
                logits[t] = dot;
            } else logits[t] = -INFINITY;
        }
    }
    __syncthreads();
    red[tid] = logits[tid];
    __syncthreads();
    for (int step = 128; step; step >>= 1) {
        if (tid < step) red[tid] = fmaxf(red[tid], red[tid+step]);
        __syncthreads();
    }
    float maximum = red[0];
    float p = tid < count ? expf(logits[tid]-maximum) : 0.f;
    logits[tid] = p;
    __syncthreads();
    red[tid] = p;
    __syncthreads();
    for (int step = 128; step; step >>= 1) {
        if (tid < step) red[tid] += red[tid+step];
        __syncthreads();
    }
    if (tid == 0) { dst[D] = maximum; dst[D+1] = red[0]; }
    for (int d = tid; d < D; d += 256) {
        float acc = 0;
        for (int t = 0; t < count; ++t) {
            int l = base + t;
            float val;
            if (l < ctx) {
                long long pblock = (long long)bt[(long long)b*NB+l/BS];
                val = float(vc[((pblock*HK+kh)*D+d)*BS+l%BS]);
            } else {
                val = float(v[((long long)(start+l-ctx)*HK+kh)*D+d]);
            }
            acc = fmaf(logits[t], val, acc);
        }
        dst[d] = acc;
    }
}

template<class T>
__global__ void merge_attention(const float* __restrict__ work,
    T* __restrict__ out, int D, int S)
{
    int row = blockIdx.x;
    const float* src = work + (long long)row*S*(D+2);
    extern __shared__ float weights[];
    __shared__ float denominator;
    if (threadIdx.x == 0) {
        float maximum = -INFINITY;
        for (int s = 0; s < S; ++s)
            maximum = fmaxf(maximum, src[(long long)s*(D+2)+D]);
        float sum = 0;
        for (int s = 0; s < S; ++s) {
            float w = expf(src[(long long)s*(D+2)+D]-maximum);
            weights[s] = w;
            sum += w * src[(long long)s*(D+2)+D+1];
        }
        denominator = sum;
    }
    __syncthreads();
    for (int d = threadIdx.x; d < D; d += blockDim.x) {
        float acc = 0;
        for (int s = 0; s < S; ++s)
            acc = fmaf(weights[s], src[(long long)s*(D+2)+d], acc);
        out[(long long)row*D+d] = T(acc/denominator);
    }
}

torch::Tensor paged_forward(torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor kc, torch::Tensor vc, torch::Tensor bt, torch::Tensor starts,
    torch::Tensor lens, c10::optional<torch::Tensor> slopes, double scale)
{
    c10::cuda::CUDAGuard guard(q.device());
    int N=q.size(0), H=q.size(1), D=q.size(2);
    int HK=k.size(1), BS=vc.size(3), X=kc.size(4);
    int B=lens.numel(), NB=bt.size(1);
    int S=(NB*BS+N+TILE-1)/TILE;
    auto out=torch::empty_like(q);
    if (!N) return out;
    auto work=torch::empty({N,H,S,D+2}, q.options().dtype(torch::kFloat32));
    auto stream=at::cuda::getCurrentCUDAStream();
    const float* slope=slopes.has_value() ? slopes->data_ptr<float>() : nullptr;
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "paged_attention", [&] {
        #define RUN(I) partial_attention<scalar_t,I><<<dim3(N,H,S),256,(D+512)*sizeof(float),stream>>>( \
            q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(), \
            kc.data_ptr<scalar_t>(), vc.data_ptr<scalar_t>(), bt.data_ptr<I>(), \
            starts.data_ptr<int>(), lens.data_ptr<int>(), slope, work.data_ptr<float>(), \
            H,HK,D,BS,X,NB,B,S,float(scale))
        if (bt.scalar_type()==at::kLong) { RUN(int64_t); }
        else { RUN(int32_t); }
        #undef RUN
        merge_attention<scalar_t><<<N*H,256,S*sizeof(float),stream>>>(
            work.data_ptr<float>(), out.data_ptr<scalar_t>(), D,S);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "paged_prefix_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens, alibi_slopes=None):
        return _extension().forward(
            query.contiguous(),
            key.contiguous(),
            value.contiguous(),
            key_cache.contiguous(),
            value_cache.contiguous(),
            block_tables.contiguous(),
            query_start_loc.to(dtype=torch.int32).contiguous(),
            seq_lens.to(dtype=torch.int32).contiguous(),
            None if alibi_slopes is None else alibi_slopes.to(dtype=torch.float32).contiguous(),
            self.scale,
        )
