import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
void run(torch::Tensor x, torch::Tensor scale, torch::Tensor out,
         torch::Tensor workspace, int mode, bool fp8);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>
#include <stdint.h>

__device__ __forceinline__ float divide(float a, float b) {
    return __fdiv_rn(a, b);
}

template<bool FP8>
__device__ __forceinline__ float quantize(float x) {
    if (!FP8) return nearbyintf(x);
    unsigned bits = __float_as_uint(x);
    unsigned sign = bits & 0x80000000u;
    unsigned mag = bits & 0x7fffffffu;
    if (mag < 0x3c800000u) {
        float a = __uint_as_float(mag);
        float r = nearbyintf(a * 512.0f) * 0.001953125f;
        return __uint_as_float(__float_as_uint(r) | sign);
    }
    mag = (mag + 0x7ffffu + ((mag >> 20) & 1u)) & 0xfff00000u;
    return __uint_as_float(mag | sign);
}

template<int B>
__device__ __forceinline__ float reduce_max(float v, float* sm) {
    sm[threadIdx.x] = v;
    __syncthreads();
    for (int d = B / 2; d; d >>= 1) {
        if (threadIdx.x < d)
            sm[threadIdx.x] = fmaxf(sm[threadIdx.x], sm[threadIdx.x + d]);
        __syncthreads();
    }
    return sm[0];
}

template<bool FP8, int B>
__global__ void token_kernel(const float* __restrict__ x,
                             float* __restrict__ out,
                             int64_t rows, int64_t cols) {
    __shared__ float sm[B];
    int64_t r = blockIdx.x;
    int64_t base = r * cols;
    float a = 0.0f;
    for (int64_t j = threadIdx.x; j < cols; j += B)
        a = fmaxf(a, fabsf(x[base + j]));
    a = reduce_max<B>(a, sm);
    float s = divide(fmaxf(a, 1.0e-10f), FP8 ? 448.0f : 127.0f);
    float inv = divide(1.0f, s);
    if (threadIdx.x == 0) out[rows * cols + r] = s;
    for (int64_t j = threadIdx.x; j < cols; j += B)
        out[base + j] = quantize<FP8>(x[base + j] * inv);
}

__global__ void partial_max(const float* __restrict__ x,
                            float* __restrict__ tmp, int64_t n) {
    __shared__ float sm[256];
    float a = 0.0f;
    for (int64_t i = (int64_t)blockIdx.x * 256 + threadIdx.x;
         i < n; i += (int64_t)gridDim.x * 256)
        a = fmaxf(a, fabsf(x[i]));
    a = reduce_max<256>(a, sm);
    if (threadIdx.x == 0) tmp[blockIdx.x] = a;
}

template<bool FP8>
__global__ void finish_max(const float* tmp, float* scale, int count) {
    __shared__ float sm[256];
    float a = 0.0f;
    for (int i = threadIdx.x; i < count; i += 256)
        a = fmaxf(a, tmp[i]);
    a = reduce_max<256>(a, sm);
    if (threadIdx.x == 0)
        *scale = divide(a, FP8 ? 448.0f : 127.0f);
}

template<bool FP8>
__global__ void tensor_quant(const float* __restrict__ x,
                             const float* scale, float* out, int64_t n) {
    float s = *scale;
    for (int64_t i = (int64_t)blockIdx.x * 256 + threadIdx.x;
         i < n; i += (int64_t)gridDim.x * 256)
        out[i] = quantize<FP8>(divide(x[i], s));
    if (blockIdx.x == 0 && threadIdx.x == 0) out[n] = s;
}

template<bool FP8>
void launch(const torch::Tensor& x, const torch::Tensor& scale,
            torch::Tensor& out, torch::Tensor& workspace, int mode,
            hipStream_t stream) {
    int64_t rows = x.size(0), cols = x.size(1), n = x.numel();
    const float* xp = x.data_ptr<float>();
    float* yp = out.data_ptr<float>();
    if (mode == 2) {
        if (rows) {
            if (cols <= 128)
                token_kernel<FP8,128><<<rows,128,0,stream>>>(xp,yp,rows,cols);
            else
                token_kernel<FP8,256><<<rows,256,0,stream>>>(xp,yp,rows,cols);
        }
        return;
    }
    int blocks = (int)std::min<int64_t>((n + 255) / 256, 4096);
    blocks = std::max(blocks, 1);
    const float* sp;
    if (mode == 1) {
        int parts = (int)workspace.numel();
        partial_max<<<parts,256,0,stream>>>(xp, workspace.data_ptr<float>(), n);
        finish_max<FP8><<<1,256,0,stream>>>(
            workspace.data_ptr<float>(), yp + n, parts);
        sp = yp + n;
    } else {
        sp = scale.data_ptr<float>();
    }
    tensor_quant<FP8><<<blocks,256,0,stream>>>(xp,sp,yp,n);
}

void run(torch::Tensor x, torch::Tensor scale, torch::Tensor out,
         torch::Tensor workspace, int mode, bool fp8) {
    c10::cuda::CUDAGuard guard(x.device());
    hipStream_t stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    if (fp8) launch<true>(x,scale,out,workspace,mode,stream);
    else launch<false>(x,scale,out,workspace,mode,stream);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "quant_dcu_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, mode: str = "dynamic_per_token", quant_dtype: str = "int8"):
        super().__init__()
        assert mode in ("static_per_tensor", "dynamic_per_tensor", "dynamic_per_token")
        assert quant_dtype in ("int8", "float8_e4m3")
        self.mode = mode
        self.quant_dtype = torch.int8 if quant_dtype == "int8" else torch.float8_e4m3fn

    def forward(self, x, scale=None):
        assert x.dim() == 2
        assert x.is_contiguous()
        mode = {
            "static_per_tensor": 0,
            "dynamic_per_tensor": 1,
            "dynamic_per_token": 2,
        }[self.mode]
        x = x.to(dtype=torch.float32)
        n = x.numel()
        out = torch.empty(
            n + (x.shape[0] if mode == 2 else 1),
            dtype=torch.float32, device=x.device,
        )
        parts = min(1024, max(1, (n + 2047) // 2048)) if mode == 1 else 0
        workspace = torch.empty(parts, dtype=torch.float32, device=x.device)
        if mode == 0:
            assert scale is not None
            scale_arg = scale.to(device=x.device, dtype=torch.float32).contiguous()
        else:
            scale_arg = workspace
        _extension().run(
            x, scale_arg, out, workspace, mode,
            self.quant_dtype != torch.int8,
        )
        return out
