import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_groupnorm_backward(
    torch::Tensor x,
    torch::Tensor dy,
    torch::Tensor scale,
    torch::Tensor mean,
    torch::Tensor inv_var,
    int64_t groups);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pyramid_groupnorm_backward", &pyramid_groupnorm_backward);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/AccumulateType.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template <typename scalar_t>
__global__ void reduce_group_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ dy,
    const scalar_t* __restrict__ scale,
    const float* __restrict__ mean,
    const float* __restrict__ inv_var,
    float* __restrict__ sums,
    int64_t N,
    int64_t C,
    int64_t HW,
    int64_t G,
    int64_t rep,
    int64_t D)
{
    int64_t ng = static_cast<int64_t>(blockIdx.x);
    if (ng >= N * G) return;

    int tid = threadIdx.x;
    int64_t n = ng / G;
    int64_t g = ng - n * G;
    int64_t c0 = g * rep;
    float m = mean[ng];
    float iv = inv_var[ng];

    float s = 0.0f;
    float t = 0.0f;

    for (int64_t k = tid; k < D; k += blockDim.x) {
        int64_t rc = k / HW;
        int64_t q = k - rc * HW;
        int64_t c = c0 + rc;
        int64_t idx = (n * C + c) * HW + q;
        float xv = static_cast<float>(x[idx]);
        float gv = static_cast<float>(dy[idx]);
        float sc = static_cast<float>(scale[c]);
        float xh = (xv - m) * iv;
        s += gv * sc;
        t += gv * xh * sc;
    }

    extern __shared__ float smem[];
    smem[tid] = s;
    smem[blockDim.x + tid] = t;
    __syncthreads();

    for (int stride = blockDim.x >> 1; stride > 0; stride >>= 1) {
        if (tid < stride) {
            smem[tid] += smem[tid + stride];
            smem[blockDim.x + tid] += smem[blockDim.x + tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0) {
        atomicAdd(sums + ng * 2, smem[0]);
        atomicAdd(sums + ng * 2 + 1, smem[blockDim.x]);
    }
}

template <typename scalar_t>
__global__ void dx_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ dy,
    const scalar_t* __restrict__ scale,
    const float* __restrict__ mean,
    const float* __restrict__ inv_var,
    const float* __restrict__ sums,
    float* __restrict__ out,
    int64_t total,
    int64_t C,
    int64_t HW,
    int64_t G,
    int64_t rep,
    int64_t D)
{
    int64_t stride = static_cast<int64_t>(blockDim.x) * gridDim.x;
    for (int64_t idx = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
         idx < total;
         idx += stride) {
        int64_t q = idx % HW;
        int64_t cc = idx / HW;
        int64_t c = cc % C;
        int64_t n = cc / C;
        int64_t g = c / rep;
        int64_t ng = n * G + g;

        float m = mean[ng];
        float iv = inv_var[ng];
        float xv = static_cast<float>(x[idx]);
        float gy = static_cast<float>(dy[idx]);
        float sc = static_cast<float>(scale[c]);
        float xh = (xv - m) * iv;
        float S = sums[ng * 2];
        float T = sums[ng * 2 + 1];

        out[idx] = (iv / static_cast<float>(D)) *
                   (static_cast<float>(D) * gy * sc - S - xh * T);
    }
}

template <typename scalar_t>
__global__ void parameter_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ dy,
    const float* __restrict__ mean,
    const float* __restrict__ inv_var,
    float* __restrict__ out,
    int64_t N,
    int64_t C,
    int64_t HW,
    int64_t G,
    int64_t rep,
    int64_t total)
{
    int64_t c = static_cast<int64_t>(blockIdx.x);
    if (c >= C) return;

    int tid = threadIdx.x;
    int64_t g = c / rep;
    float dg = 0.0f;
    float db = 0.0f;

    int64_t M = N * HW;
    for (int64_t k = tid; k < M; k += blockDim.x) {
        int64_t n = k / HW;
        int64_t q = k - n * HW;
        int64_t idx = (n * C + c) * HW + q;
        int64_t ng = n * G + g;

        float xv = static_cast<float>(x[idx]);
        float gy = static_cast<float>(dy[idx]);
        float xh = (xv - mean[ng]) * inv_var[ng];

        dg += gy * xh;
        db += gy;
    }

    extern __shared__ float smem[];
    smem[tid] = dg;
    smem[blockDim.x + tid] = db;
    __syncthreads();

    for (int stride = blockDim.x >> 1; stride > 0; stride >>= 1) {
        if (tid < stride) {
            smem[tid] += smem[tid + stride];
            smem[blockDim.x + tid] += smem[blockDim.x + tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0) {
        out[total + c] = smem[0];
        out[total + C + c] = smem[blockDim.x];
    }
}

torch::Tensor pyramid_groupnorm_backward(
    torch::Tensor x,
    torch::Tensor dy,
    torch::Tensor scale,
    torch::Tensor mean,
    torch::Tensor inv_var,
    int64_t groups)
{
    TORCH_CHECK(x.is_cuda(), "x must be a CUDA/HIP tensor");
    TORCH_CHECK(dy.is_cuda() && scale.is_cuda(), "inputs must be CUDA/HIP tensors");
    TORCH_CHECK(mean.is_cuda() && inv_var.is_cuda(), "statistics must be CUDA/HIP tensors");
    TORCH_CHECK(x.is_contiguous() && dy.is_contiguous() && scale.is_contiguous(),
                "x, dy, and scale must be contiguous");
    TORCH_CHECK(mean.is_contiguous() && inv_var.is_contiguous(),
                "mean and inv_var must be contiguous");
    TORCH_CHECK(x.dim() == 4, "x must be NCHW");
    TORCH_CHECK(groups >= 1, "groups must be positive");

    int64_t N = x.size(0);
    int64_t C = x.size(1);
    int64_t H = x.size(2);
    int64_t W = x.size(3);
    int64_t HW = H * W;
    int64_t total = N * C * HW;
    int64_t G = groups;
    TORCH_CHECK(C % G == 0, "groups must divide channels");
    TORCH_CHECK(mean.numel() == N * G && inv_var.numel() == N * G,
                "invalid statistics size");

    int64_t rep = C / G;
    int64_t D = rep * HW;
    int64_t ng = N * G;

    auto fopts = torch::TensorOptions().dtype(torch::kFloat32).device(x.device());
    auto sums = torch::zeros({ng, 2}, fopts);
    auto out = torch::empty({total + 2 * C}, fopts);

    constexpr int threads = 256;
    auto stream = at::cuda::getDefaultCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "pyramid_groupnorm_backward",
        [&] {
            hipLaunchKernelGGL(
                reduce_group_kernel<scalar_t>,
                dim3(static_cast<unsigned int>(ng)),
                dim3(threads),
                2 * threads * sizeof(float),
                stream.stream(),
                x.data_ptr<scalar_t>(),
                dy.data_ptr<scalar_t>(),
                scale.data_ptr<scalar_t>(),
                mean.data_ptr<float>(),
                inv_var.data_ptr<float>(),
                sums.data_ptr<float>(),
                N, C, HW, G, rep, D);

            int64_t dxblocks = (total + threads - 1) / threads;
            dxblocks = dxblocks > 65535 ? 65535 : dxblocks;
            hipLaunchKernelGGL(
                dx_kernel<scalar_t>,
                dim3(static_cast<unsigned int>(dxblocks)),
                dim3(threads),
                0,
                stream.stream(),
                x.data_ptr<scalar_t>(),
                dy.data_ptr<scalar_t>(),
                scale.data_ptr<scalar_t>(),
                mean.data_ptr<float>(),
                inv_var.data_ptr<float>(),
                sums.data_ptr<float>(),
                out.data_ptr<float>(),
                total, C, HW, G, rep, D);

            hipLaunchKernelGGL(
                parameter_kernel<scalar_t>,
                dim3(static_cast<unsigned int>(C)),
                dim3(threads),
                2 * threads * sizeof(float),
                stream.stream(),
                x.data_ptr<scalar_t>(),
                dy.data_ptr<scalar_t>(),
                mean.data_ptr<float>(),
                inv_var.data_ptr<float>(),
                out.data_ptr<float>(),
                N, C, HW, G, rep, total);
        });

    return out;
}
"""

def _get_extension():
    global _EXT
    if _EXT is None:
        digest = hashlib.sha1((CUDA_CPP_SRC + CUDA_CU_SRC).encode()).hexdigest()[:12]
        _EXT = load_inline(
            name="pyramid_groupnorm_backward_" + digest,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, groups: int = 2, eps: float = 1e-5):
        super().__init__()
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.groups = int(groups)
        self.eps = float(eps)

    def forward(self, x, dy, scale, mean, inv_var):
        n, c, h, w = x.shape
        g = self.groups
        assert 1 <= g <= c and c % g == 0
        assert mean.numel() == n * g and inv_var.numel() == n * g
        return _get_extension().pyramid_groupnorm_backward(
            x, dy, scale, mean, inv_var, g
        )
