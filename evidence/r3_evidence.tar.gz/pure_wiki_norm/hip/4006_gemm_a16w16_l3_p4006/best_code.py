import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_linear(torch::Tensor x, torch::Tensor weight);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pyramid_linear", &pyramid_linear, "FP16/BF16 row-major linear");
}
"""


_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

template <bool BF16>
__device__ __forceinline__ float load_scalar(const unsigned short v) {
    if constexpr (BF16) {
        unsigned int bits = static_cast<unsigned int>(v) << 16;
        return __uint_as_float(bits);
    } else {
        return __half2float(__ushort_as_half(v));
    }
}

template <bool BF16>
__device__ __forceinline__ unsigned short store_scalar(const float value) {
    if constexpr (BF16) {
        unsigned int bits = __float_as_uint(value);
        unsigned int upper = bits >> 16;
        unsigned int lower = bits & 0xffffu;
        if (lower > 0x8000u || (lower == 0x8000u && (upper & 1u))) {
            ++upper;
        }
        return static_cast<unsigned short>(upper);
    } else {
        return __half_as_ushort(__float2half_rn(value));
    }
}

template <bool BF16>
__global__ void linear_kernel(
    const unsigned short* __restrict__ x,
    const unsigned short* __restrict__ w,
    unsigned short* __restrict__ out,
    int64_t m,
    int64_t n,
    int64_t k)
{
    constexpr int TILE = 16;

    __shared__ unsigned short sx[TILE][TILE];
    __shared__ unsigned short sw[TILE][TILE];

    const int tx = static_cast<int>(threadIdx.x);
    const int ty = static_cast<int>(threadIdx.y);

    const int64_t row = static_cast<int64_t>(blockIdx.y) * TILE + ty;
    const int64_t col = static_cast<int64_t>(blockIdx.x) * TILE + tx;

    float acc = 0.0f;

    for (int64_t base = 0; base < k; base += TILE) {
        const int64_t xk = base + tx;
        const int64_t wk = base + tx;

        if (row < m && xk < k) {
            sx[ty][tx] = x[row * k + xk];
        } else {
            sx[ty][tx] = 0;
        }

        if (col < n && wk < k) {
            sw[ty][tx] = w[col * k + wk];
        } else {
            sw[ty][tx] = 0;
        }

        __syncthreads();

        const int remaining = static_cast<int>(
            min(static_cast<int64_t>(TILE), k - base));

        #pragma unroll
        for (int j = 0; j < TILE; ++j) {
            if (j < remaining) {
                acc += load_scalar<BF16>(sx[ty][j]) *
                       load_scalar<BF16>(sw[j][tx]);
            }
        }

        __syncthreads();
    }

    if (row < m && col < n) {
        out[row * n + col] = store_scalar<BF16>(acc);
    }
}

torch::Tensor pyramid_linear(torch::Tensor x, torch::Tensor weight) {
    TORCH_CHECK(x.is_cuda(), "x must be a CUDA/HIP tensor");
    TORCH_CHECK(weight.is_cuda(), "weight must be a CUDA/HIP tensor");
    TORCH_CHECK(x.dim() == 2, "x must be rank 2");
    TORCH_CHECK(weight.dim() == 2, "weight must be rank 2");
    TORCH_CHECK(x.is_contiguous(), "x must be contiguous");
    TORCH_CHECK(weight.is_contiguous(), "weight must be contiguous");
    TORCH_CHECK(x.scalar_type() == at::kHalf ||
                x.scalar_type() == at::kBFloat16,
                "x must be float16 or bfloat16");
    TORCH_CHECK(weight.scalar_type() == x.scalar_type(),
                "x and weight must have the same dtype");
    TORCH_CHECK(x.size(1) == weight.size(1),
                "x and weight must agree on the K dimension");

    const int64_t m = x.size(0);
    const int64_t k = x.size(1);
    const int64_t n = weight.size(0);

    auto out = torch::empty({m, n}, x.options());

    const dim3 block(16, 16, 1);
    const dim3 grid(
        static_cast<unsigned int>((n + 15) / 16),
        static_cast<unsigned int>((m + 15) / 16),
        1);

    auto stream = at::cuda::getDefaultCUDAStream().stream();

    if (x.scalar_type() == at::kBFloat16) {
        hipLaunchKernelGGL(
            (linear_kernel<true>),
            grid,
            block,
            0,
            stream,
            reinterpret_cast<const unsigned short*>(x.data_ptr()),
            reinterpret_cast<const unsigned short*>(weight.data_ptr()),
            reinterpret_cast<unsigned short*>(out.data_ptr()),
            m, n, k);
    } else {
        hipLaunchKernelGGL(
            (linear_kernel<false>),
            grid,
            block,
            0,
            stream,
            reinterpret_cast<const unsigned short*>(x.data_ptr()),
            reinterpret_cast<const unsigned short*>(weight.data_ptr()),
            reinterpret_cast<unsigned short*>(out.data_ptr()),
            m, n, k);
    }

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""


_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (_CPP_SRC + _HIP_SRC).encode("utf-8")
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"pyramid_linear_hip_{digest}",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

    def forward(self, x, weight):
        return _get_extension().pyramid_linear(x, weight)
