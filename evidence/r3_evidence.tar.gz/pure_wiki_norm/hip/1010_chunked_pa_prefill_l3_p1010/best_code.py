import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
 torch::Tensor kc, torch::Tensor vc, torch::Tensor bt, torch::Tensor starts,
 torch::Tensor lens, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
 m.def("run", &paged_attention);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAException.h>

constexpr int TILE = 128;
constexpr int NT = 128;

__global__ void partial_attention(
 const float* __restrict__ q, const float* __restrict__ k,
 const float* __restrict__ v, const float* __restrict__ kc,
 const float* __restrict__ vc, const int* __restrict__ bt,
 const int* __restrict__ starts, const int* __restrict__ lens,
 float* __restrict__ tmp, int H, int HK, int D, int BS, int X,
 int B, int M, int splits, float scale)
{
 int token = blockIdx.x, head = blockIdx.y, part = blockIdx.z;
 int tid = threadIdx.x;
 int lo = 0, hi = B;
 while (lo < hi) {
   int mid = (lo + hi) >> 1;
   if (starts[mid + 1] <= token) lo = mid + 1;
   else hi = mid;
 }
 int b = lo, start = starts[b];
 int ctx = lens[b] - (starts[b + 1] - start);
 int end = ctx + token - start + 1;
 int first = part * TILE;
 int kh = head / (H / HK);
 long long dst = (((long long)token * H + head) * splits + part) * (D + 2);
 if (first >= end) {
   if (tid == 0) { tmp[dst + D] = -INFINITY; tmp[dst + D + 1] = 0; }
   for (int d = tid; d < D; d += NT) tmp[dst + d] = 0;
   return;
 }
 __shared__ float scores[TILE];
 __shared__ float red[NT];
 extern __shared__ float qs[];
 for (int d = tid; d < D; d += NT)
   qs[d] = q[((long long)token * H + head) * D + d] * scale;
 __syncthreads();
 int lane = tid & 3;
 for (int r = 0; r < 4; ++r) {
   int i = (tid >> 2) + r * 32;
   int pos = first + i;
   float dot = 0;
   if (pos < end) {
     if (pos < ctx) {
       int pb = bt[b * M + pos / BS], slot = pos % BS;
       long long base = ((long long)pb * HK + kh) * D * BS;
       for (int d = lane; d < D; d += 4)
         dot = fmaf(qs[d], kc[base + (d / X) * BS * X + slot * X + d % X], dot);
     } else {
       long long base = ((long long)(start + pos - ctx) * HK + kh) * D;
       for (int d = lane; d < D; d += 4)
         dot = fmaf(qs[d], k[base + d], dot);
     }
   }
   dot += __shfl_down(dot, 2, 4);
   dot += __shfl_down(dot, 1, 4);
   if (lane == 0) scores[i] = pos < end ? dot : -INFINITY;
 }
 __syncthreads();
 red[tid] = scores[tid];
 __syncthreads();
 for (int s = NT / 2; s; s >>= 1) {
   if (tid < s) red[tid] = fmaxf(red[tid], red[tid + s]);
   __syncthreads();
 }
 float mx = red[0];
 float p = expf(scores[tid] - mx);
 scores[tid] = p;
 __syncthreads();
 red[tid] = p;
 __syncthreads();
 for (int s = NT / 2; s; s >>= 1) {
   if (tid < s) red[tid] += red[tid + s];
   __syncthreads();
 }
 if (tid == 0) {
   tmp[dst + D] = mx;
   tmp[dst + D + 1] = red[0];
 }
 int count = min(TILE, end - first);
 for (int d = tid; d < D; d += NT) {
   float accum = 0;
   for (int i = 0; i < count; ++i) {
     int pos = first + i;
     float val;
     if (pos < ctx) {
       int pb = bt[b * M + pos / BS];
       val = vc[(((long long)pb * HK + kh) * D + d) * BS + pos % BS];
     } else {
       val = v[((long long)(start + pos - ctx) * HK + kh) * D + d];
     }
     accum = fmaf(scores[i], val, accum);
   }
   tmp[dst + d] = accum;
 }
}

__global__ void combine(const float* __restrict__ tmp, float* __restrict__ out,
 int D, int splits) {
 int row = blockIdx.x, tid = threadIdx.x;
 long long base = (long long)row * splits * (D + 2);
 __shared__ float weights[128];
 __shared__ float maximum, denominator;
 if (tid == 0) {
   float mx = -INFINITY;
   for (int s = 0; s < splits; ++s)
     mx = fmaxf(mx, tmp[base + (long long)s * (D + 2) + D]);
   float sum = 0;
   for (int s = 0; s < splits; ++s) {
     long long off = base + (long long)s * (D + 2);
     float w = expf(tmp[off + D] - mx);
     sum += w * tmp[off + D + 1];
     if (splits <= 128) weights[s] = w;
   }
   maximum = mx;
   denominator = sum;
 }
 __syncthreads();
 for (int d = tid; d < D; d += blockDim.x) {
   float a = 0;
   for (int s = 0; s < splits; ++s) {
     long long off = base + (long long)s * (D + 2);
     float w = splits <= 128 ? weights[s] : expf(tmp[off + D] - maximum);
     a = fmaf(w, tmp[off + d], a);
   }
   out[(long long)row * D + d] = a / denominator;
 }
}

torch::Tensor paged_attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
 torch::Tensor kc, torch::Tensor vc, torch::Tensor bt, torch::Tensor starts,
 torch::Tensor lens, double scale) {
 c10::cuda::CUDAGuard guard(q.device());
 int T = q.size(0), H = q.size(1), D = q.size(2);
 int HK = kc.size(1), BS = vc.size(3), X = kc.size(4);
 int B = lens.numel(), M = bt.size(1);
 int splits = (M * BS + TILE - 1) / TILE;
 auto out = torch::empty_like(q);
 if (!T) return out;
 auto tmp = torch::empty({T, H, splits, D + 2}, q.options());
 auto stream = at::cuda::getCurrentCUDAStream();
 partial_attention<<<dim3(T,H,splits), NT, D*sizeof(float), stream>>>(
 q.data_ptr<float>(), k.data_ptr<float>(), v.data_ptr<float>(),
 kc.data_ptr<float>(), vc.data_ptr<float>(), bt.data_ptr<int>(),
 starts.data_ptr<int>(), lens.data_ptr<int>(), tmp.data_ptr<float>(),
 H, HK, D, BS, X, B, M, splits, (float)scale);
 C10_CUDA_KERNEL_LAUNCH_CHECK();
 combine<<<T*H, 128, 0, stream>>>(
 tmp.data_ptr<float>(), out.data_ptr<float>(), D, splits);
 C10_CUDA_KERNEL_LAUNCH_CHECK();
 return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "paged_attn_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens):
        return _get_extension().run(
            query.contiguous(),
            key.contiguous(),
            value.contiguous(),
            key_cache.contiguous(),
            value_cache.contiguous(),
            block_tables.to(dtype=torch.int32).contiguous(),
            query_start_loc.to(dtype=torch.int32).contiguous(),
            seq_lens.to(dtype=torch.int32).contiguous(),
            self.scale,
        )
