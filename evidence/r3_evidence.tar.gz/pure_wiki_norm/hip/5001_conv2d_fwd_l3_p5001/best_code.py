import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor pyramid_forward(torch::Tensor x, torch::Tensor w, int64_t pad);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &pyramid_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/hip/HIPException.h>

__global__ __launch_bounds__(256)
void pyramid_kernel(
    const float* __restrict__ x,
    const float* __restrict__ w,
    float* __restrict__ y,
    int C, int H, int W, int K, int R, int S,
    int OH, int OW, int pad)
{
    __shared__ float a[32][17];
    __shared__ float b[16][65];

    const int tid = threadIdx.x;
    const int row = tid / 16;
    const int col = tid % 16;
    const int kbase = blockIdx.y * 32;
    const int pbase = blockIdx.x * 64;
    const int batch = blockIdx.z;
    const int P = OH * OW;
    const int D = C * R * S;
    const int RS = R * S;
    const float* xb = x + (int64_t)batch * C * H * W;
    float acc[2][4] = {};

    for (int base = 0; base < D; base += 16) {
        #pragma unroll
        for (int z = 0; z < 2; ++z) {
            int idx = tid + z * 256;
            int ar = idx / 16;
            int d = base + idx % 16;
            a[ar][idx % 16] =
                (kbase + ar < K && d < D)
                ? w[(int64_t)(kbase + ar) * D + d] : 0.0f;
        }

        #pragma unroll
        for (int z = 0; z < 4; ++z) {
            int idx = tid + z * 256;
            int br = idx / 64;
            int bc = idx % 64;
            int d = base + br;
            int p = pbase + bc;
            float value = 0.0f;
            if (d < D && p < P) {
                int c = d / RS;
                int rem = d - c * RS;
                int u = rem / S;
                int v = rem - u * S;
                int ih = p / OW + u - pad;
                int iw = p % OW + v - pad;
                if ((unsigned)ih < (unsigned)H &&
                    (unsigned)iw < (unsigned)W)
                    value = xb[((int64_t)c * H + ih) * W + iw];
            }
            b[br][bc] = value;
        }
        __syncthreads();

        #pragma unroll
        for (int d = 0; d < 16; ++d) {
            float av0 = a[row][d];
            float av1 = a[row + 16][d];
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                float bv = b[d][col + j * 16];
                acc[0][j] = fmaf(av0, bv, acc[0][j]);
                acc[1][j] = fmaf(av1, bv, acc[1][j]);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 2; ++i) {
        int k = kbase + row + i * 16;
        if (k < K) {
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                int p = pbase + col + j * 16;
                if (p < P)
                    y[((int64_t)batch * K + k) * P + p] = acc[i][j];
            }
        }
    }
}

torch::Tensor pyramid_forward(torch::Tensor x, torch::Tensor w, int64_t pad) {
    TORCH_CHECK(x.is_cuda() && w.is_cuda(), "Inputs must be on the accelerator");
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 &&
                w.scalar_type() == torch::kFloat32, "Inputs must be float32");
    TORCH_CHECK(x.dim() == 4 && w.dim() == 4, "Inputs must be rank four");
    TORCH_CHECK(x.is_contiguous() && w.is_contiguous(), "Inputs must be contiguous");
    TORCH_CHECK(x.device() == w.device() && x.size(1) == w.size(1),
                "Incompatible inputs");
    c10::cuda::CUDAGuard guard(x.device());
    int N = x.size(0), C = x.size(1), H = x.size(2), W = x.size(3);
    int K = w.size(0), R = w.size(2), S = w.size(3);
    int OH = H - R + pad + 2;
    int OW = W - S + pad + 2;
    TORCH_CHECK(OH > 0 && OW > 0, "Invalid output dimensions");
    auto out = torch::empty({N, K, OH, OW}, x.options());
    if (N && K) {
        auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
        hipLaunchKernelGGL(pyramid_kernel,
            dim3((OH * OW + 63) / 64, (K + 31) / 32, N),
            dim3(256), 0, stream.stream(),
            x.data_ptr<float>(), w.data_ptr<float>(), out.data_ptr<float>(),
            C, H, W, K, R, S, OH, OW, (int)pad);
        TORCH_CHECK(hipGetLastError() == hipSuccess, "Kernel launch failed");
    }
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "pyramid_implicit_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _DILATION = (1, 1)
    _PAD_SYMMETRIC = (1, 1)
    _PRE_PADDING = (2, 2)
    _POST_PADDING = (1, 1)

    def __init__(self, variant: str = "standard"):
        super().__init__()
        assert variant in ("standard", "asymmetric"), (
            "variant must be either standard or asymmetric"
        )
        self.variant = variant

    def forward(self, x, weight):
        return _get_extension().forward(
            x, weight, 2 if self.variant == "asymmetric" else 1
        )
