import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor run_experts(
    torch::Tensor A, torch::Tensor B, torch::Tensor AS, torch::Tensor BS,
    torch::Tensor W, torch::Tensor IDs, bool weighted, bool quant,
    int64_t bn, int64_t bk);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run_experts);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template<class ID, bool QUANT, bool WEIGHTED>
__global__ void expert_kernel(
    const float* __restrict__ A, const float* __restrict__ B,
    const float* __restrict__ AS, const float* __restrict__ BS,
    const float* __restrict__ W, const ID* __restrict__ ids,
    float* __restrict__ out,
    int K, int N, int TK, int rows, int bn, int bk,
    int64_t a0, int64_t a1,
    int64_t b0, int64_t b1, int64_t b2,
    int64_t w0, int64_t w1, int64_t i0, int64_t i1,
    int64_t as0, int64_t as1,
    int64_t bs0, int64_t bs1, int64_t bs2)
{
    constexpr int LANES = 32;
    int lane = threadIdx.x % LANES;
    int n = blockIdx.x * 8 + threadIdx.x / LANES;
    int row = blockIdx.y;
    if (n >= N || row >= rows) return;
    int m = row / TK;
    int j = row % TK;
    int e = static_cast<int>(ids[m*i0 + j*i1]);
    const float* ap = A + m*a0;
    const float* gp = B + e*b0 + n*b1;
    const float* up = gp + N*b1;
    float g = 0.0f, u = 0.0f;
    for (int k = lane; k < K; k += LANES) {
        float a = ap[k*a1];
        float b = gp[k*b2];
        float c = up[k*b2];
        if (QUANT) {
            int q = k / bk;
            a *= AS[m*as0 + q*as1];
            b *= BS[e*bs0 + (n/bn)*bs1 + q*bs2];
            c *= BS[e*bs0 + ((n+N)/bn)*bs1 + q*bs2];
        }
        g = fmaf(a, b, g);
        u = fmaf(a, c, u);
    }
    #pragma unroll
    for (int delta = 16; delta; delta >>= 1) {
        g += __shfl_down(g, delta, LANES);
        u += __shfl_down(u, delta, LANES);
    }
    if (lane == 0) {
        if (WEIGHTED) {
            float w = W[m*w0 + j*w1];
            g *= w;
            u *= w;
        }
        out[(int64_t)row*N+n] = (g / (1.0f + expf(-g))) * u;
    }
}

template<class ID, bool Q, bool W>
void launch(torch::Tensor A, torch::Tensor B, torch::Tensor AS,
            torch::Tensor BS, torch::Tensor weights, torch::Tensor ids,
            torch::Tensor out, int bn, int bk, hipStream_t stream) {
    int N = B.size(1)/2;
    int rows = out.size(0);
    if (!rows || !N) return;
    dim3 grid((N+7)/8, rows);
    expert_kernel<ID,Q,W><<<grid,256,0,stream>>>(
        A.data_ptr<float>(), B.data_ptr<float>(),
        AS.data_ptr<float>(), BS.data_ptr<float>(),
        weights.data_ptr<float>(), ids.data_ptr<ID>(), out.data_ptr<float>(),
        A.size(1), N, ids.size(1), rows, bn, bk,
        A.stride(0), A.stride(1),
        B.stride(0), B.stride(1), B.stride(2),
        weights.stride(0), weights.stride(1), ids.stride(0), ids.stride(1),
        Q ? AS.stride(0) : 0, Q ? AS.stride(1) : 0,
        Q ? BS.stride(0) : 0, Q ? BS.stride(1) : 0,
        Q ? BS.stride(2) : 0);
}

template<class ID>
void dispatch(torch::Tensor A, torch::Tensor B, torch::Tensor AS,
              torch::Tensor BS, torch::Tensor W, torch::Tensor ids,
              torch::Tensor out, bool weighted, bool quant,
              int bn, int bk, hipStream_t stream) {
    if (quant) {
        if (weighted) launch<ID,true,true>(A,B,AS,BS,W,ids,out,bn,bk,stream);
        else launch<ID,true,false>(A,B,AS,BS,W,ids,out,bn,bk,stream);
    } else {
        if (weighted) launch<ID,false,true>(A,B,AS,BS,W,ids,out,bn,bk,stream);
        else launch<ID,false,false>(A,B,AS,BS,W,ids,out,bn,bk,stream);
    }
}

torch::Tensor run_experts(
    torch::Tensor A, torch::Tensor B, torch::Tensor AS, torch::Tensor BS,
    torch::Tensor W, torch::Tensor IDs, bool weighted, bool quant,
    int64_t bn, int64_t bk) {
    c10::cuda::CUDAGuard guard(A.device());
    TORCH_CHECK(A.scalar_type() == at::kFloat &&
                B.scalar_type() == at::kFloat &&
                W.scalar_type() == at::kFloat, "Expected fp32 inputs");
    auto out = torch::empty({A.size(0)*IDs.size(1), B.size(1)/2}, W.options());
    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    if (IDs.scalar_type() == at::kLong)
        dispatch<int64_t>(A,B,AS,BS,W,IDs,out,weighted,quant,bn,bk,stream);
    else if (IDs.scalar_type() == at::kInt)
        dispatch<int32_t>(A,B,AS,BS,W,IDs,out,weighted,quant,bn,bk,stream);
    else if (IDs.scalar_type() == at::kFloat)
        dispatch<float>(A,B,AS,BS,W,IDs,out,weighted,quant,bn,bk,stream);
    else
        TORCH_CHECK(false, "Unsupported routing index dtype");
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "fused_experts_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, mul_routed_weight=True, quant="dense", block_n=128, block_k=128):
        super().__init__()
        assert quant in ("dense", "fp8_block")
        assert block_n >= 1 and block_k >= 1
        self.mul_routed_weight = bool(mul_routed_weight)
        self.quant = quant
        self.block_n = int(block_n)
        self.block_k = int(block_k)

    def forward(self, A, B, A_scale, B_scale, topk_weights, topk_ids,
                sorted_token_ids, expert_ids, num_tokens_post_padded):
        return _get_extension().run(
            A, B, A_scale, B_scale, topk_weights, topk_ids,
            self.mul_routed_weight, self.quant == "fp8_block",
            self.block_n, self.block_k,
        )
