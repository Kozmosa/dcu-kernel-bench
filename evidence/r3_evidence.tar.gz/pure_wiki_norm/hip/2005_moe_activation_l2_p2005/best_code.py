import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
void run(torch::Tensor x, torch::Tensor y, int mode, double alpha, double limit);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>

template<int MODE, typename T>
__global__ void activate(const T* __restrict__ x, T* __restrict__ y,
                         int64_t count, int64_t n, float alpha, float limit) {
    constexpr bool gated = MODE < 7;
    for (int64_t base = (int64_t)blockIdx.x * 1024 + threadIdx.x;
         base < count; base += (int64_t)gridDim.x * 1024) {
        #pragma unroll
        for (int k = 0; k < 4; ++k) {
            int64_t i = base + k * 256;
            if (i >= count) continue;
            int64_t p = i;
            if constexpr (gated) {
                if constexpr (MODE == 6) p = 2 * i;
                else p = (i / n) * (2 * n) + i % n;
            }
            float g = (float)x[p];
            float u = 1.0f;
            if constexpr (gated) {
                if constexpr (MODE == 6) u = (float)x[p + 1];
                else u = (float)x[p + n];
            }
            if constexpr (MODE == 1 || MODE == 2 || MODE == 6) {
                g = fminf(g, limit);
                u = fminf(fmaxf(u, -limit), limit);
            }
            float a;
            if constexpr (MODE == 3 || MODE == 8) {
                a = (0.5f * g) * (1.0f + erff(g * 0.7071067811865476f));
            } else if constexpr (MODE == 4 || MODE == 9) {
                float v = 0.7978845608028654f *
                          (g + ((0.044715f * g) * g) * g);
                a = (0.5f * g) * (1.0f + tanhf(v));
            } else if constexpr (MODE == 10) {
                float v = fmaxf(g, 0.0f);
                a = v * v;
            } else {
                float v = g;
                if constexpr (MODE == 2 || MODE == 6) v = alpha * g;
                a = g * (1.0f / (1.0f + expf(-v)));
            }
            if constexpr (MODE == 5) {
                a = fminf(a, limit);
                u = fminf(fmaxf(u, -limit), limit);
            }
            if constexpr (MODE == 2 || MODE == 6) u += 1.0f;
            if constexpr (gated) a *= u;
            y[i] = (T)a;
        }
    }
}

template<typename T>
void dispatch(torch::Tensor x, torch::Tensor y, int mode, float alpha, float limit,
              hipStream_t stream) {
    int64_t count = y.numel(), n = y.size(1);
    if (!count) return;
    int blocks = (int)std::min<int64_t>((count + 1023) / 1024, 65535);
    #define LAUNCH(M) case M: \
        activate<M,T><<<blocks,256,0,stream>>>(x.data_ptr<T>(), y.data_ptr<T>(), \
                                              count,n,alpha,limit); break;
    switch(mode) {
        LAUNCH(0) LAUNCH(1) LAUNCH(2) LAUNCH(3) LAUNCH(4) LAUNCH(5)
        LAUNCH(6) LAUNCH(7) LAUNCH(8) LAUNCH(9) LAUNCH(10)
    }
    #undef LAUNCH
}

void run(torch::Tensor x, torch::Tensor y, int mode, double alpha, double limit) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous(), "Expected contiguous device input");
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "activation_dispatch", [&] {
            dispatch<scalar_t>(x, y, mode, (float)alpha, (float)limit, stream);
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
"""

_EXT = None


def _extension():
    global _EXT
    if _EXT is None:
        name = "fused_ffn_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXT = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, activation: str = "silu", alpha=None, limit=None):
        super().__init__()
        gated = ("silu", "gelu", "gelu_tanh", "swiglustep", "swiglu_interleaved")
        nomul = ("silu_no_mul", "gelu_no_mul", "gelu_tanh_no_mul", "relu2")
        name = str(activation).lower()
        assert name in gated + nomul, "Unknown activation"
        if name in ("gelu", "gelu_tanh"):
            assert alpha is None and limit is None
        if name == "swiglustep":
            assert alpha is None
            if limit is None:
                limit = 7.0
        if name == "silu" and alpha is not None:
            assert limit is not None
        if name == "swiglu_interleaved":
            alpha = 1.702 if alpha is None else alpha
            limit = 7.0 if limit is None else limit
        self.activation = name
        self.is_gated = name in gated
        self.alpha = None if alpha is None else float(alpha)
        self.limit = None if limit is None else float(limit)
        if name == "silu":
            self._mode = 2 if alpha is not None else (1 if limit is not None else 0)
        else:
            self._mode = {
                "gelu": 3, "gelu_tanh": 4, "swiglustep": 5,
                "swiglu_interleaved": 6, "silu_no_mul": 7,
                "gelu_no_mul": 8, "gelu_tanh_no_mul": 9, "relu2": 10,
            }[name]

    def forward(self, x):
        assert x.dim() == 2, "the input must be a 2D (M, n) tensor"
        if self.is_gated:
            assert x.shape[1] % 2 == 0
        n = x.shape[1] // 2 if self.is_gated else x.shape[1]
        out = torch.empty((x.shape[0], n), device=x.device, dtype=x.dtype)
        _extension().run(
            x, out, self._mode,
            1.0 if self.alpha is None else self.alpha,
            0.0 if self.limit is None else self.limit,
        )
        return out
