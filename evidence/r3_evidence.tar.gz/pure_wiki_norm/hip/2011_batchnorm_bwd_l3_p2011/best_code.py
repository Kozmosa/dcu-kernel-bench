import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor bn_backward_hip(
    torch::Tensor dy, torch::Tensor x, torch::Tensor scale,
    torch::Tensor mean, torch::Tensor inv, bool parameters);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &bn_backward_hip);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/hip/HIPException.h>
#include <algorithm>
#include <cstdint>

constexpr int THREADS = 256;
constexpr int TILE = 2048;

__device__ __forceinline__ void reduce_pair(
    float &a, float &b, float* sa, float* sb) {
    const int t = threadIdx.x;
    sa[t] = a;
    sb[t] = b;
    __syncthreads();
    for (int d = THREADS / 2; d; d >>= 1) {
        if (t < d) {
            sa[t] += sa[t + d];
            sb[t] += sb[t + d];
        }
        __syncthreads();
    }
    a = sa[0];
    b = sb[0];
}

__global__ void partial_kernel(
    const float* __restrict__ dy, const float* __restrict__ x,
    const float* __restrict__ mean, const float* __restrict__ inv,
    float* __restrict__ partial, float* __restrict__ sums,
    int64_t spatial, int64_t m, int channels, int parts) {
    const int c = blockIdx.y;
    const int p = blockIdx.x;
    const int64_t start = int64_t(p) * TILE;
    float a = 0.f, b = 0.f;
    const float mu = mean[c], iv = inv[c];
    #pragma unroll
    for (int j = 0; j < TILE / THREADS; ++j) {
        const int64_t k = start + threadIdx.x + j * THREADS;
        if (k < m) {
            const int64_t offset =
                (k / spatial * channels + c) * spatial + k % spatial;
            const float g = dy[offset];
            const float h = (x[offset] - mu) * iv;
            a += g * h;
            b += g;
        }
    }
    __shared__ float sa[THREADS], sb[THREADS];
    reduce_pair(a, b, sa, sb);
    if (threadIdx.x == 0) {
        if (parts == 1) {
            sums[c] = a;
            sums[channels + c] = b;
        } else {
            const int64_t index = int64_t(c) * parts + p;
            partial[index] = a;
            partial[int64_t(channels) * parts + index] = b;
        }
    }
}

__global__ void finish_kernel(
    const float* __restrict__ partial, float* __restrict__ sums,
    int channels, int parts) {
    const int c = blockIdx.x;
    float a = 0.f, b = 0.f;
    for (int p = threadIdx.x; p < parts; p += THREADS) {
        const int64_t i = int64_t(c) * parts + p;
        a += partial[i];
        b += partial[int64_t(channels) * parts + i];
    }
    __shared__ float sa[THREADS], sb[THREADS];
    reduce_pair(a, b, sa, sb);
    if (threadIdx.x == 0) {
        sums[c] = a;
        sums[channels + c] = b;
    }
}

__global__ void dx_kernel(
    const float* __restrict__ dy, const float* __restrict__ x,
    const float* __restrict__ scale, const float* __restrict__ mean,
    const float* __restrict__ inv, const float* __restrict__ sums,
    float* __restrict__ out, int64_t total, int64_t spatial,
    int channels, float m) {
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         i < total; i += int64_t(gridDim.x) * blockDim.x) {
        const int c = (i / spatial) % channels;
        const float h = (x[i] - mean[c]) * inv[c];
        const float factor = (scale[c] * inv[c]) / m;
        const float v = (m * dy[i] - sums[channels + c]) - h * sums[c];
        out[i] = factor * v;
    }
}

torch::Tensor bn_backward_hip(
    torch::Tensor dy, torch::Tensor x, torch::Tensor scale,
    torch::Tensor mean, torch::Tensor inv, bool parameters) {
    TORCH_CHECK(x.is_cuda() && x.scalar_type() == at::kFloat,
                "Expected accelerator float32 inputs");
    c10::cuda::CUDAGuard guard(x.device());
    const int channels = x.size(1);
    const int64_t spatial = x.size(2) * x.size(3);
    const int64_t m = x.size(0) * spatial;
    const int parts = (m + TILE - 1) / TILE;
    auto sums = torch::empty({2LL * channels}, x.options());
    auto partial = torch::empty(
        {parts > 1 ? 2LL * channels * parts : 0LL}, x.options());
    const auto stream = c10::cuda::getCurrentCUDAStream().stream();
    partial_kernel<<<dim3(parts, channels), THREADS, 0, stream>>>(
        dy.data_ptr<float>(), x.data_ptr<float>(), mean.data_ptr<float>(),
        inv.data_ptr<float>(), partial.data_ptr<float>(), sums.data_ptr<float>(),
        spatial, m, channels, parts);
    if (parts > 1) {
        finish_kernel<<<channels, THREADS, 0, stream>>>(
            partial.data_ptr<float>(), sums.data_ptr<float>(), channels, parts);
    }
    if (parameters) return sums;
    auto out = torch::empty_like(x);
    const int blocks = std::min<int64_t>((x.numel() + 255) / 256, 65535);
    dx_kernel<<<blocks, 256, 0, stream>>>(
        dy.data_ptr<float>(), x.data_ptr<float>(), scale.data_ptr<float>(),
        mean.data_ptr<float>(), inv.data_ptr<float>(), sums.data_ptr<float>(),
        out.data_ptr<float>(), x.numel(), spatial, channels, float(m));
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="bn_training_backward_" + digest,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dx"):
        super().__init__()
        assert variant in ("dx", "dgamma_dbeta"), \
            "variant must be one of dx / dgamma_dbeta"
        self.variant = variant

    def forward(self, dy, x, scale, saved_mean, saved_inv_variance):
        return _get_extension().run(
            dy, x, scale, saved_mean, saved_inv_variance,
            self.variant == "dgamma_dbeta",
        )
