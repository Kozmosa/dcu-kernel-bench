import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_backward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor o, torch::Tensor lse, torch::Tensor grad,
    double scale, bool causal);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &attention_backward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

constexpr int T = 16;

template <typename scalar_t>
__global__ void delta_kernel(
    const scalar_t* __restrict__ o,
    const scalar_t* __restrict__ grad,
    float* __restrict__ delta,
    int M, int H, int D, int rows)
{
    int row = blockIdx.x * 4 + threadIdx.y;
    int lane = threadIdx.x;
    float sum = 0.0f;
    if (row < rows) {
        int i = row % M;
        int h = (row / M) % H;
        int b = row / (M * H);
        int64_t off = ((int64_t(b) * M + i) * H + h) * D;
        for (int d = lane; d < D; d += 64)
            sum += float(o[off + d]) * float(grad[off + d]);
    }
    for (int offset = 32; offset; offset >>= 1)
        sum += __shfl_down(sum, offset, 64);
    if (lane == 0 && row < rows)
        delta[row] = sum;
}

template <typename scalar_t>
__global__ void probability_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k,
    const scalar_t* __restrict__ v,
    const scalar_t* __restrict__ grad,
    const float* __restrict__ lse,
    const float* __restrict__ delta,
    float* __restrict__ p,
    float* __restrict__ ds,
    int M, int N, int H, int K, int D, float scale, bool causal)
{
    int x = threadIdx.x, y = threadIdx.y;
    int i = blockIdx.y * T + y;
    int j = blockIdx.x * T + x;
    int h = blockIdx.z % H, b = blockIdx.z / H;
    int hk = h / (H / K);
    if (causal && int(blockIdx.x * T) > int(blockIdx.y * T + T - 1) + N - M) {
        if (i < M && j < N) {
            int64_t pos = (int64_t(blockIdx.z) * M + i) * N + j;
            p[pos] = 0.0f;
            ds[pos] = 0.0f;
        }
        return;
    }
    __shared__ float qs[T][T + 1], gs[T][T + 1];
    __shared__ float ks[T][T + 1], vs[T][T + 1];
    float score = 0.0f, dp = 0.0f;
    for (int base = 0; base < D; base += T) {
        int d = base + x;
        int jj = blockIdx.x * T + y;
        int64_t qo = ((int64_t(b) * M + i) * H + h) * D + d;
        int64_t ko = ((int64_t(b) * N + jj) * K + hk) * D + d;
        qs[y][x] = i < M && d < D ? float(q[qo]) : 0.0f;
        gs[y][x] = i < M && d < D ? float(grad[qo]) : 0.0f;
        ks[y][x] = jj < N && d < D ? float(k[ko]) : 0.0f;
        vs[y][x] = jj < N && d < D ? float(v[ko]) : 0.0f;
        __syncthreads();
        #pragma unroll
        for (int t = 0; t < T; ++t) {
            score = fmaf(qs[y][t], ks[x][t], score);
            dp = fmaf(gs[y][t], vs[x][t], dp);
        }
        __syncthreads();
    }
    if (i < M && j < N) {
        int64_t row = int64_t(blockIdx.z) * M + i;
        int64_t pos = row * N + j;
        float prob = (!causal || j <= i + N - M)
            ? expf(score * scale - lse[row]) : 0.0f;
        p[pos] = prob;
        ds[pos] = prob * (dp - delta[row]);
    }
}

template <typename scalar_t>
__global__ void dq_kernel(
    const float* __restrict__ ds,
    const scalar_t* __restrict__ k,
    float* __restrict__ out,
    int M, int N, int H, int K, int D, float scale, bool causal)
{
    int x = threadIdx.x, y = threadIdx.y;
    int i = blockIdx.y * T + y;
    int d = blockIdx.x * T + x;
    int h = blockIdx.z % H, b = blockIdx.z / H;
    int hk = h / (H / K);
    __shared__ float a[T][T + 1], w[T][T + 1];
    float sum = 0.0f;
    int end = N;
    if (causal) end = min(N, int(blockIdx.y * T + T) + N - M);
    for (int base = 0; base < end; base += T) {
        int j = base + x;
        a[y][x] = i < M && j < N
            ? ds[(int64_t(blockIdx.z) * M + i) * N + j] : 0.0f;
        j = base + y;
        w[y][x] = j < N && d < D
            ? float(k[((int64_t(b) * N + j) * K + hk) * D + d]) : 0.0f;
        __syncthreads();
        #pragma unroll
        for (int t = 0; t < T; ++t)
            sum = fmaf(a[y][t], w[t][x], sum);
        __syncthreads();
    }
    if (i < M && d < D)
        out[((int64_t(b) * M + i) * H + h) * D + d] =
            float(scalar_t(sum * scale));
}

template <typename scalar_t>
__global__ void dkv_kernel(
    const float* __restrict__ p,
    const float* __restrict__ ds,
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ grad,
    float* __restrict__ dk,
    float* __restrict__ dv,
    int M, int N, int H, int K, int D, float scale, bool causal)
{
    int x = threadIdx.x, y = threadIdx.y;
    int j = blockIdx.y * T + y;
    int d = blockIdx.x * T + x;
    int hk = blockIdx.z % K, b = blockIdx.z / K;
    int group = H / K;
    __shared__ float a[T][T + 1], ap[T][T + 1];
    __shared__ float w[T][T + 1], wg[T][T + 1];
    float sumk = 0.0f, sumv = 0.0f;
    int begin = 0;
    if (causal) begin = max(0, int(blockIdx.y * T) + M - N) / T * T;
    for (int gh = 0; gh < group; ++gh) {
        int h = hk * group + gh;
        float headk = 0.0f, headv = 0.0f;
        for (int base = begin; base < M; base += T) {
            // Transpose the probability tiles in shared memory.
            int ii = base + y;
            int jj = blockIdx.y * T + x;
            int64_t pos = ((int64_t(b) * H + h) * M + ii) * N + jj;
            a[x][y] = ii < M && jj < N ? ds[pos] : 0.0f;
            ap[x][y] = ii < M && jj < N ? p[pos] : 0.0f;
            int64_t off = ((int64_t(b) * M + ii) * H + h) * D + d;
            w[y][x] = ii < M && d < D ? float(q[off]) : 0.0f;
            wg[y][x] = ii < M && d < D ? float(grad[off]) : 0.0f;
            __syncthreads();
            #pragma unroll
            for (int t = 0; t < T; ++t) {
                headk = fmaf(a[y][t], w[t][x], headk);
                headv = fmaf(ap[y][t], wg[t][x], headv);
            }
            __syncthreads();
        }
        sumk += headk * scale;
        sumv += headv;
    }
    if (j < N && d < D) {
        int64_t off = ((int64_t(b) * N + j) * K + hk) * D + d;
        dk[off] = float(scalar_t(sumk));
        dv[off] = float(scalar_t(sumv));
    }
}

torch::Tensor attention_backward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor o, torch::Tensor lse, torch::Tensor grad,
    double scale, bool causal)
{
    c10::cuda::CUDAGuard guard(q.device());
    q = q.contiguous();
    k = k.contiguous();
    v = v.contiguous();
    o = o.contiguous();
    lse = lse.contiguous();
    grad = grad.contiguous();
    int B = q.size(0), M = q.size(1), H = q.size(2), D = q.size(3);
    int N = k.size(1), K = k.size(2);
    TORCH_CHECK(H % K == 0, "Invalid head grouping");
    auto opts = q.options().dtype(torch::kFloat32);
    auto delta = torch::empty({B, H, M}, opts);
    auto p = torch::empty({B, H, M, N}, opts);
    auto ds = torch::empty_like(p);
    int64_t nq = int64_t(B) * M * H * D;
    int64_t nk = int64_t(B) * N * K * D;
    auto out = torch::empty({nq + 2 * nk}, opts);
    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "attention_backward", [&] {
            delta_kernel<scalar_t><<<
                (B * H * M + 3) / 4, dim3(64, 4), 0, stream>>>(
                o.data_ptr<scalar_t>(), grad.data_ptr<scalar_t>(),
                delta.data_ptr<float>(), M, H, D, B * H * M);
            probability_kernel<scalar_t><<<
                dim3((N + T - 1) / T, (M + T - 1) / T, B * H),
                dim3(T, T), 0, stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(),
                v.data_ptr<scalar_t>(), grad.data_ptr<scalar_t>(),
                lse.data_ptr<float>(), delta.data_ptr<float>(),
                p.data_ptr<float>(), ds.data_ptr<float>(),
                M, N, H, K, D, float(scale), causal);
            dq_kernel<scalar_t><<<
                dim3((D + T - 1) / T, (M + T - 1) / T, B * H),
                dim3(T, T), 0, stream>>>(
                ds.data_ptr<float>(), k.data_ptr<scalar_t>(),
                out.data_ptr<float>(), M, N, H, K, D, float(scale), causal);
            dkv_kernel<scalar_t><<<
                dim3((D + T - 1) / T, (N + T - 1) / T, B * K),
                dim3(T, T), 0, stream>>>(
                p.data_ptr<float>(), ds.data_ptr<float>(),
                q.data_ptr<scalar_t>(), grad.data_ptr<scalar_t>(),
                out.data_ptr<float>() + nq, out.data_ptr<float>() + nq + nk,
                M, N, H, K, D, float(scale), causal);
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "dcu_attn_bw_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, causal: int, scale=None):
        super().__init__()
        self.head_dim = int(head_dim)
        self.causal = bool(int(causal))
        self.sm_scale = (
            float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v, o, lse, do):
        return _get_extension().run(
            q, k, v, o, lse, do, self.sm_scale, self.causal
        )
