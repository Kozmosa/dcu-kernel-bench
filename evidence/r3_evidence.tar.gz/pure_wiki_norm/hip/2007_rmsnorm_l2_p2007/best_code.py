import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor rms_forward(torch::Tensor x, torch::Tensor w,
                          torch::Tensor r, bool fused, double eps);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &rms_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/Dispatch.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

template<typename T, bool Fused, int B, int K>
__global__ void rms_cached(const T* __restrict__ x,
                           const T* __restrict__ w,
                           const T* __restrict__ r,
                           T* __restrict__ out,
                           int64_t n, float eps) {
    const int t = threadIdx.x;
    const int64_t row = blockIdx.x;
    const int64_t base = row * n;
    const int64_t obase = row * n * (Fused ? 2 : 1);
    float v[K];
    float sum = 0.0f;
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        int64_t c = t + int64_t(k) * B;
        float a = 0.0f;
        if (c < n) {
            a = float(x[base + c]);
            if (Fused) a = float(T(a + float(r[base + c])));
        }
        v[k] = a;
        sum += a * a;
    }
    #pragma unroll
    for (int d = 32; d; d >>= 1)
        sum += __shfl_down(sum, d, 64);

    __shared__ float partial[4];
    __shared__ float scale;
    if ((t & 63) == 0) partial[t >> 6] = sum;
    __syncthreads();
    if (t == 0) {
        float s = partial[0];
        #pragma unroll
        for (int i = 1; i < B / 64; ++i) s += partial[i];
        scale = rsqrtf(s / float(n) + eps);
    }
    __syncthreads();
    float inv = scale;
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        int64_t c = t + int64_t(k) * B;
        if (c < n) {
            out[obase + c] = T((v[k] * inv) * float(w[c]));
            if (Fused) out[obase + n + c] = T(v[k]);
        }
    }
}

template<typename T, bool Fused>
__global__ void rms_large(const T* __restrict__ x,
                          const T* __restrict__ w,
                          const T* __restrict__ r,
                          T* __restrict__ out,
                          int64_t n, float eps) {
    int t = threadIdx.x;
    int64_t base = int64_t(blockIdx.x) * n;
    int64_t obase = int64_t(blockIdx.x) * n * (Fused ? 2 : 1);
    float sum = 0.0f;
    for (int64_t c = t; c < n; c += 256) {
        float a = float(x[base + c]);
        if (Fused) a = float(T(a + float(r[base + c])));
        sum += a * a;
    }
    #pragma unroll
    for (int d = 32; d; d >>= 1)
        sum += __shfl_down(sum, d, 64);
    __shared__ float partial[4];
    __shared__ float scale;
    if ((t & 63) == 0) partial[t >> 6] = sum;
    __syncthreads();
    if (t == 0)
        scale = rsqrtf(((partial[0] + partial[1]) +
                        (partial[2] + partial[3])) / float(n) + eps);
    __syncthreads();
    float inv = scale;
    for (int64_t c = t; c < n; c += 256) {
        float a = float(x[base + c]);
        if (Fused) a = float(T(a + float(r[base + c])));
        out[obase + c] = T((a * inv) * float(w[c]));
        if (Fused) out[obase + n + c] = T(a);
    }
}

template<typename T, bool F>
void launch(const torch::Tensor& x, const torch::Tensor& w,
            const torch::Tensor& r, torch::Tensor& out, float eps,
            hipStream_t stream) {
    int64_t m = x.size(0), n = x.size(1);
    const T* xp = x.data_ptr<T>();
    const T* wp = w.data_ptr<T>();
    const T* rp = F ? r.data_ptr<T>() : nullptr;
    T* op = out.data_ptr<T>();
    if (!m) return;
    if (n <= 64)
        rms_cached<T,F,64,1><<<m,64,0,stream>>>(xp,wp,rp,op,n,eps);
    else if (n <= 256)
        rms_cached<T,F,64,4><<<m,64,0,stream>>>(xp,wp,rp,op,n,eps);
    else if (n <= 1024)
        rms_cached<T,F,256,4><<<m,256,0,stream>>>(xp,wp,rp,op,n,eps);
    else if (n <= 2048)
        rms_cached<T,F,256,8><<<m,256,0,stream>>>(xp,wp,rp,op,n,eps);
    else if (n <= 4096)
        rms_cached<T,F,256,16><<<m,256,0,stream>>>(xp,wp,rp,op,n,eps);
    else if (n <= 8192)
        rms_cached<T,F,256,32><<<m,256,0,stream>>>(xp,wp,rp,op,n,eps);
    else
        rms_large<T,F><<<m,256,0,stream>>>(xp,wp,rp,op,n,eps);
}

torch::Tensor rms_forward(torch::Tensor x, torch::Tensor w,
                          torch::Tensor r, bool fused, double eps) {
    c10::cuda::CUDAGuard guard(x.device());
    auto out = torch::empty({x.size(0), x.size(1) * (fused ? 2 : 1)},
                            x.options());
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,
                                   at::ScalarType::BFloat16,
                                   x.scalar_type(), "rms_forward", [&] {
        if (fused)
            launch<scalar_t,true>(x,w,r,out,float(eps),stream);
        else
            launch<scalar_t,false>(x,w,r,out,float(eps),stream);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXT = None


def _extension():
    global _EXT
    if _EXT is None:
        name = "dcu_rms_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXT = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, variant: str = "fused_add", eps: float = 1e-5):
        super().__init__()
        assert variant in ("rmsnorm", "fused_add"), "variant must be one of rmsnorm / fused_add"
        self.variant = variant
        self.eps = float(eps)

    def forward(self, x, weight, residual):
        return _extension().forward(
            x, weight, residual, self.variant == "fused_add", self.eps
        )
