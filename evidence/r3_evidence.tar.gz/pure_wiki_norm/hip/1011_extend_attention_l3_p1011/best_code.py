import math
import hashlib
import torch
from torch import nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_run(torch::Tensor,torch::Tensor,torch::Tensor,
    torch::Tensor,torch::Tensor,torch::Tensor,torch::Tensor,torch::Tensor,
    bool,double);
PYBIND11_MODULE(TORCH_EXTENSION_NAME,m) {
    m.def("run",&attention_run);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <cmath>

constexpr int SPLITS=8;
constexpr int TILE=32;

template<int NV>
__global__ void partial_attention(
    const float* __restrict__ q,
    const float* __restrict__ ke,
    const float* __restrict__ ve,
    const float* __restrict__ kb,
    const float* __restrict__ vb,
    const int* __restrict__ qp,
    const int* __restrict__ kp,
    const int64_t* __restrict__ ids,
    float* __restrict__ partial,
    float* __restrict__ lses,
    int B,int HQ,int HK,int D,int V,bool causal,float scale)
{
    int row=blockIdx.x, h=blockIdx.y, split=blockIdx.z;
    int tid=threadIdx.x, lane=tid&63, wave=tid>>6;
    int lo=0,hi=B;
    while(lo+1<hi) {
        int mid=(lo+hi)>>1;
        if(qp[mid]<=row) lo=mid; else hi=mid;
    }
    int start=qp[lo], end=qp[lo+1];
    int ps=kp[lo], plen=kp[lo+1]-ps;
    int length=plen+(causal ? row-start+1 : end-start);
    int chunk=(length+SPLITS-1)/SPLITS;
    int first=split*chunk, last=min(first+chunk,length);
    int g=h/(HQ/HK);
    long long base=((long long)row*HQ+h)*SPLITS+split;
    if(first>=last) {
        for(int d=tid;d<V;d+=256) partial[base*V+d]=0.f;
        if(tid==0) lses[base]=-INFINITY;
        return;
    }
    extern __shared__ float sq[];
    __shared__ float weights[TILE];
    __shared__ float alpha, maximum, denom;
    for(int d=tid;d<D;d+=256) sq[d]=q[((long long)row*HQ+h)*D+d];
    if(tid==0) {maximum=-INFINITY; denom=0.f;}
    float acc[NV];
    #pragma unroll
    for(int n=0;n<NV;++n) acc[n]=0.f;
    __syncthreads();
    for(int tile=first;tile<last;tile+=TILE) {
        for(int j=wave;j<TILE;j+=4) {
            int token=tile+j;
            float dot=0.f;
            if(token<last) {
                bool prefix=token<plen;
                long long r=prefix ? ids[ps+token] : start+token-plen;
                const float* k=(prefix ? kb : ke)+(r*HK+g)*D;
                for(int d=lane;d<D;d+=64) dot=fmaf(sq[d],k[d],dot);
            }
            #pragma unroll
            for(int delta=32;delta>0;delta>>=1)
                dot+=__shfl_down(dot,delta,64);
            if(lane==0) weights[j]=token<last ? dot*scale : -INFINITY;
        }
        __syncthreads();
        if(tid==0) {
            float m=maximum;
            for(int j=0;j<TILE;++j) m=fmaxf(m,weights[j]);
            alpha=expf(maximum-m);
            float sum=0.f;
            for(int j=0;j<TILE;++j) {
                float w=expf(weights[j]-m);
                weights[j]=w;
                sum+=w;
            }
            denom=denom*alpha+sum;
            maximum=m;
        }
        __syncthreads();
        #pragma unroll
        for(int n=0;n<NV;++n) {
            int d=tid+n*256;
            if(d<V) {
                float a=acc[n]*alpha;
                for(int j=0;j<TILE && tile+j<last;++j) {
                    int token=tile+j;
                    bool prefix=token<plen;
                    long long r=prefix ? ids[ps+token] : start+token-plen;
                    float v=(prefix ? vb : ve)[(r*HK+g)*V+d];
                    a=fmaf(weights[j],v,a);
                }
                acc[n]=a;
            }
        }
        __syncthreads();
    }
    #pragma unroll
    for(int n=0;n<NV;++n) {
        int d=tid+n*256;
        if(d<V) partial[base*V+d]=acc[n]/denom;
    }
    if(tid==0) lses[base]=maximum+logf(denom);
}

__global__ void combine(const float* __restrict__ p,
                        const float* __restrict__ l,
                        float* __restrict__ out,int V,int count) {
    int item=blockIdx.x;
    __shared__ float w[SPLITS];
    if(threadIdx.x==0) {
        float m=-INFINITY;
        for(int s=0;s<SPLITS;++s) m=fmaxf(m,l[(long long)item*SPLITS+s]);
        float z=0.f;
        for(int s=0;s<SPLITS;++s) {
            w[s]=expf(l[(long long)item*SPLITS+s]-m);
            z+=w[s];
        }
        for(int s=0;s<SPLITS;++s) w[s]/=z;
    }
    __syncthreads();
    for(int d=threadIdx.x;d<V;d+=blockDim.x) {
        float a=0.f;
        for(int s=0;s<SPLITS;++s)
            a=fmaf(w[s],p[((long long)item*SPLITS+s)*V+d],a);
        out[(long long)item*V+d]=a;
    }
}

torch::Tensor attention_run(
    torch::Tensor q,torch::Tensor ke,torch::Tensor ve,
    torch::Tensor kb,torch::Tensor vb,torch::Tensor qp,
    torch::Tensor kp,torch::Tensor ids,bool causal,double scale)
{
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.scalar_type()==torch::kFloat32,"Expected fp32 inputs");
    int T=q.size(0), HQ=q.size(1), D=q.size(2);
    int HK=ke.size(1), V=ve.size(2), B=qp.numel()-1;
    TORCH_CHECK(HK>0 && HQ%HK==0,"Invalid grouped query heads");
    TORCH_CHECK(V<=4096,"Value head dimension exceeds 4096");
    auto out=torch::empty({T,HQ,V},q.options());
    if(T==0) return out;
    auto p=torch::empty({T,HQ,SPLITS,V},q.options());
    auto l=torch::empty({T,HQ,SPLITS},q.options());
    auto stream=at::cuda::getCurrentCUDAStream();
    dim3 grid(T,HQ,SPLITS);
    #define LAUNCH(N) partial_attention<N><<<grid,256,D*sizeof(float),stream>>>( \
        q.data_ptr<float>(),ke.data_ptr<float>(),ve.data_ptr<float>(), \
        kb.data_ptr<float>(),vb.data_ptr<float>(),qp.data_ptr<int>(), \
        kp.data_ptr<int>(),ids.data_ptr<int64_t>(),p.data_ptr<float>(), \
        l.data_ptr<float>(),B,HQ,HK,D,V,causal,(float)scale)
    if(V<=256) { LAUNCH(1); }
    else if(V<=512) { LAUNCH(2); }
    else if(V<=1024) { LAUNCH(4); }
    else if(V<=2048) { LAUNCH(8); }
    else { LAUNCH(16); }
    #undef LAUNCH
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    combine<<<T*HQ,256,0,stream>>>(p.data_ptr<float>(),l.data_ptr<float>(),
                                  out.data_ptr<float>(),V,T*HQ);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "ragged_split_attention_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)

    def forward(self, q_extend, k_extend, v_extend, k_buffer, v_buffer,
                qo_indptr, kv_indptr, kv_indices):
        scale = self.sm_scale
        if scale is None:
            scale = 1.0 / math.sqrt(q_extend.shape[-1])
        return _get_extension().run(
            q_extend, k_extend, v_extend, k_buffer, v_buffer,
            qo_indptr.to(dtype=torch.int32),
            kv_indptr.to(dtype=torch.int32),
            kv_indices.to(dtype=torch.int64),
            self.causal, scale,
        )
