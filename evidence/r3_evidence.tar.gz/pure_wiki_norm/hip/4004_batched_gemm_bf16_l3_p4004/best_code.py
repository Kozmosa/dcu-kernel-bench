import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
void batch_gemm(torch::Tensor x, torch::Tensor w, torch::Tensor bias,
                torch::Tensor out, bool use_bias);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("batch_gemm", &batch_gemm);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

__device__ __forceinline__ float bfround(float x) {
    unsigned int u = __float_as_uint(x);
    if ((u & 0x7fffffffU) > 0x7f800000U)
        return __uint_as_float((u & 0xffff0000U) | 0x00400000U);
    u += 0x7fffU + ((u >> 16) & 1U);
    return __uint_as_float(u & 0xffff0000U);
}

template<typename O, bool BIAS>
__global__ __launch_bounds__(256)
void gemm_kernel(
    const float* __restrict__ x,
    const float* __restrict__ w,
    const float* __restrict__ bias,
    O* __restrict__ out,
    int M, int N, int K,
    int64_t xs0, int64_t xs1, int64_t xs2,
    int64_t ws0, int64_t ws1, int64_t ws2,
    int64_t bs0, int64_t bs2)
{
    __shared__ float a[64][33];
    __shared__ float b[64][33];

    int tid = threadIdx.x;
    int tx = tid & 15;
    int ty = tid >> 4;
    int row0 = blockIdx.y * 64;
    int col0 = blockIdx.x * 64;
    int batch = blockIdx.z;

    x += batch * xs0;
    w += batch * ws0;
    float sums[4][4];
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        #pragma unroll
        for (int j = 0; j < 4; ++j)
            sums[i][j] = 0.0f;

    for (int k0 = 0; k0 < K; k0 += 32) {
        #pragma unroll
        for (int q = 0; q < 8; ++q) {
            int idx = tid + q * 256;
            int r = idx >> 5;
            int k = idx & 31;
            a[r][k] = (row0 + r < M && k0 + k < K)
                ? bfround(x[(row0 + r) * xs1 + (k0 + k) * xs2]) : 0.0f;
            b[r][k] = (col0 + r < N && k0 + k < K)
                ? bfround(w[(col0 + r) * ws1 + (k0 + k) * ws2]) : 0.0f;
        }
        __syncthreads();
        #pragma unroll
        for (int k = 0; k < 32; ++k) {
            float av[4], bv[4];
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                av[i] = a[ty + 16 * i][k];
                bv[i] = b[tx + 16 * i][k];
            }
            #pragma unroll
            for (int i = 0; i < 4; ++i)
                #pragma unroll
                for (int j = 0; j < 4; ++j)
                    sums[i][j] = fmaf(av[i], bv[j], sums[i][j]);
        }
        __syncthreads();
    }
    #pragma unroll
    for (int j = 0; j < 4; ++j) {
        int n = col0 + tx + 16 * j;
        float bv = 0.0f;
        if (BIAS && n < N)
            bv = bfround(bias[batch * bs0 + n * bs2]);
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            int m = row0 + ty + 16 * i;
            if (m < M && n < N) {
                float v = sums[i][j];
                if (BIAS)
                    v = bfround(bfround(v) + bv);
                out[((int64_t)batch * M + m) * N + n] = O(v);
            }
        }
    }
}

void batch_gemm(torch::Tensor x, torch::Tensor w, torch::Tensor bias,
                torch::Tensor out, bool use_bias) {
    c10::cuda::CUDAGuard guard(x.device());
    TORCH_CHECK(x.scalar_type() == at::kFloat && w.scalar_type() == at::kFloat,
                "Expected fp32 inputs");
    TORCH_CHECK(!use_bias || bias.scalar_type() == at::kFloat,
                "Expected fp32 bias");
    int M = x.size(1), K = x.size(2), N = w.size(1);
    dim3 grid((N + 63) / 64, (M + 63) / 64, x.size(0));
    auto stream = at::cuda::getCurrentCUDAStream();
    const float* bp = use_bias ? bias.data_ptr<float>() : nullptr;
    int64_t bs0 = use_bias ? bias.stride(0) : 0;
    int64_t bs2 = use_bias ? bias.stride(2) : 0;
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  out.scalar_type(), "batch_gemm", [&] {
        if (use_bias) {
            gemm_kernel<scalar_t, true><<<grid, 256, 0, stream>>>(
                x.data_ptr<float>(), w.data_ptr<float>(), bp,
                out.data_ptr<scalar_t>(), M, N, K,
                x.stride(0), x.stride(1), x.stride(2),
                w.stride(0), w.stride(1), w.stride(2), bs0, bs2);
        } else {
            gemm_kernel<scalar_t, false><<<grid, 256, 0, stream>>>(
                x.data_ptr<float>(), w.data_ptr<float>(), bp,
                out.data_ptr<scalar_t>(), M, N, K,
                x.stride(0), x.stride(1), x.stride(2),
                w.stride(0), w.stride(1), w.stride(2), bs0, bs2);
        }
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "batch_tn_gemm_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)

    def forward(self, x, weight, bias):
        B, M, K = x.shape
        assert K == weight.shape[2], "x and weight must agree on the K dimension"
        out = torch.empty(
            (B, M, weight.shape[1]), device=x.device, dtype=self.out_dtype
        )
        _get_extension().batch_gemm(
            x, weight, bias if self.use_bias else x, out, self.use_bias
        )
        return out
