import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor routed_fp4(
    torch::Tensor a, torch::Tensor as,
    torch::Tensor b, torch::Tensor bs,
    torch::Tensor w, torch::Tensor ids);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("routed_fp4", &routed_fp4);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <c10/util/BFloat16.h>
#include <stdint.h>

__device__ __forceinline__ float decode(unsigned x) {
    unsigned m = x & 7;
    float v = m < 4 ? float(m) * 0.5f
                        : float(2 + (m & 1)) * float(1 << ((m >> 1) - 2));
    return (x & 8) ? -v : v;
}

__global__ void routed_kernel(
    const uint8_t* __restrict__ a,
    const uint8_t* __restrict__ as,
    const uint8_t* __restrict__ b,
    const uint8_t* __restrict__ bs,
    const float* __restrict__ weights,
    const int64_t* __restrict__ ids,
    c10::BFloat16* __restrict__ out,
    int N, int KH, int S, int topk)
{
    // Sixteen lanes cooperate on each output, with adjacent lanes reading
    // adjacent packed bytes. Each iteration covers one scaling block.
    int lane = threadIdx.x & 15;
    int n = blockIdx.x * 16 + (threadIdx.x >> 4);
    int slot = blockIdx.y;
    if (n >= N) return;

    int token = slot / topk;
    int64_t row = ids[slot] * int64_t(N) + n;
    const uint8_t* ap = a + int64_t(token) * KH;
    const uint8_t* bp = b + row * KH;
    const uint8_t* asp = as + int64_t(token) * S;
    const uint8_t* bsp = bs + row * S;
    float acc = 0.0f;

    for (int s = 0; s < S; ++s) {
        unsigned av = ap[s * 16 + lane];
        unsigned bv = bp[s * 16 + lane];
        float sa = exp2f(float(asp[s]) - 127.0f);
        float sb = exp2f(float(bsp[s]) - 127.0f);
        float a0 = decode(av & 15) * sa;
        float a1 = decode(av >> 4) * sa;
        float b0 = decode(bv & 15) * sb;
        float b1 = decode(bv >> 4) * sb;
        acc = fmaf(a0, b0, acc);
        acc = fmaf(a1, b1, acc);
    }
    acc += __shfl_down(acc, 8, 16);
    acc += __shfl_down(acc, 4, 16);
    acc += __shfl_down(acc, 2, 16);
    acc += __shfl_down(acc, 1, 16);
    if (lane == 0)
        out[int64_t(slot) * N + n] = c10::BFloat16(acc * weights[slot]);
}

torch::Tensor routed_fp4(
    torch::Tensor a, torch::Tensor as,
    torch::Tensor b, torch::Tensor bs,
    torch::Tensor w, torch::Tensor ids)
{
    c10::cuda::CUDAGuard guard(a.device());
    int M = a.size(0);
    int KH = a.size(1);
    int N = b.size(1);
    int topk = ids.size(1);
    auto out = torch::empty({M, topk, N},
                            a.options().dtype(torch::kBFloat16));
    if (M && N && topk) {
        auto stream = at::cuda::getCurrentCUDAStream();
        hipLaunchKernelGGL(routed_kernel,
            dim3((N + 15) / 16, M * topk), dim3(256), 0, stream,
            a.data_ptr<uint8_t>(), as.data_ptr<uint8_t>(),
            b.data_ptr<uint8_t>(), bs.data_ptr<uint8_t>(),
            w.data_ptr<float>(), ids.data_ptr<int64_t>(),
            out.data_ptr<c10::BFloat16>(), N, KH, KH / 16, topk);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "routed_fp4_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, a_q, a_scales, b_q, b_scales, topk_weights, topk_ids):
        a_q = a_q.to(torch.uint8).contiguous()
        a_scales = a_scales.to(torch.uint8).contiguous()
        b_q = b_q.to(torch.uint8).contiguous()
        b_scales = b_scales.to(torch.uint8).contiguous()
        topk_ids = topk_ids.to(torch.long).contiguous()
        topk_weights = topk_weights.to(torch.float32).contiguous()
        return _get_extension().routed_fp4(
            a_q, a_scales, b_q, b_scales, topk_weights, topk_ids
        )
