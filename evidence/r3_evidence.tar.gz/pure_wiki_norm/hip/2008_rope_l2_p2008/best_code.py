import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor rope_forward(torch::Tensor x, torch::Tensor f,
                           int style, bool nope, bool reuse);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &rope_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template<typename T, int STYLE, bool REUSE>
__global__ void rope_kernel(
    const T* __restrict__ x, const T* __restrict__ f,
    T* __restrict__ out, int D, int F, int R, int start,
    int64_t row_size, int64_t tiles)
{
    __shared__ float cs[256];
    __shared__ float sn[256];
    const int tid = threadIdx.x;
    const int64_t seq = static_cast<int64_t>(blockIdx.x) / tiles;
    const int64_t tile = static_cast<int64_t>(blockIdx.x) - seq * tiles;
    if (tid < F) {
        float angle = static_cast<float>(f[seq * F + tid]);
        sincosf(angle, &sn[tid], &cs[tid]);
    }
    __syncthreads();

    const int64_t base = seq * row_size;
    #pragma unroll
    for (int k = 0; k < 4; ++k) {
        const int64_t p = tile * 1024 + tid + k * 256;
        if (p < row_size) {
            const int d = p % D;
            const int r = d - start;
            const int64_t idx = base + p;
            float a = static_cast<float>(x[idx]);
            if (r >= 0 && r < R) {
                int partner;
                bool neg;
                int fi;
                if (STYLE == 0) {
                    neg = r < R / 2;
                    partner = neg ? r + R / 2 : r - R / 2;
                    fi = REUSE ? r % F : r;
                } else {
                    neg = (r & 1) == 0;
                    partner = r ^ 1;
                    fi = REUSE ? r / 2 : r;
                }
                float b = static_cast<float>(x[idx + partner - r]);
                if (neg) b = -b;
                float v = a * cs[fi] + b * sn[fi];
                out[idx] = static_cast<T>(v);
            } else {
                out[idx] = x[idx];
            }
        }
    }
}

torch::Tensor rope_forward(torch::Tensor x, torch::Tensor f,
                           int style, bool nope, bool reuse) {
    TORCH_CHECK(x.is_cuda() && f.is_cuda(), "Inputs must be on the accelerator");
    TORCH_CHECK(x.is_contiguous() && f.is_contiguous(), "Inputs must be contiguous");
    TORCH_CHECK(x.scalar_type() == f.scalar_type(), "Input dtypes must match");
    c10::cuda::CUDAGuard guard(x.device());
    auto out = torch::empty_like(x);
    const int D = x.size(3);
    const int F = f.size(3);
    const int R = F * (reuse ? 2 : 1);
    const int start = nope ? D - R : 0;
    const int64_t row_size = x.size(1) * x.size(2) * D;
    const int64_t tiles = (row_size + 1023) / 1024;
    const int64_t blocks = tiles * x.size(0);
    if (!blocks) return out;
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "rope_forward", [&] {
            const auto xp = x.data_ptr<scalar_t>();
            const auto fp = f.data_ptr<scalar_t>();
            auto op = out.data_ptr<scalar_t>();
            #define LAUNCH(S, U) \
                hipLaunchKernelGGL((rope_kernel<scalar_t, S, U>), \
                    dim3(blocks), dim3(256), 0, stream, \
                    xp, fp, op, D, F, R, start, row_size, tiles)
            if (style == 0) {
                if (reuse) { LAUNCH(0, true); }
                else { LAUNCH(0, false); }
            } else {
                if (reuse) { LAUNCH(1, true); }
                else { LAUNCH(1, false); }
            }
            #undef LAUNCH
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "rope_dcu_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, rotate_style: int, nope_first: bool, reuse_freqs_front_part: bool):
        super().__init__()
        self.rotate_style = int(rotate_style)
        self.nope_first = bool(nope_first)
        self.reuse_freqs_front_part = bool(reuse_freqs_front_part)

    def forward(self, x, freqs):
        return _get_extension().forward(
            x, freqs, self.rotate_style, self.nope_first,
            self.reuse_freqs_front_part,
        )
