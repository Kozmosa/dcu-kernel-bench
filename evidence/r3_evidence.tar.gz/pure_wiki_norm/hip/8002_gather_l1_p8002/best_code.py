import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

void pyramid_run(
    const at::Tensor& data,
    const at::Tensor& indices,
    const at::Tensor& output,
    int64_t axis,
    bool elementwise);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &pyramid_run);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cstdint>

struct PyramidShape {
    int64_t ndim;
    int64_t in_size[4];
    int64_t out_size[4];
    int64_t in_stride[4];
    int64_t idx_stride[4];
};

template <typename T, typename I>
__global__ void pyramid_kernel(
    const T* __restrict__ input,
    const I* __restrict__ index,
    T* __restrict__ output,
    PyramidShape shape,
    int64_t axis,
    bool elementwise,
    int64_t count) {
    int64_t linear = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (linear >= count) {
        return;
    }

    int64_t rem = linear;
    int64_t input_offset = 0;
    int64_t index_offset = 0;

    for (int d = static_cast<int>(shape.ndim) - 1; d >= 0; --d) {
        int64_t coord = rem % shape.out_size[d];
        rem /= shape.out_size[d];

        if (elementwise) {
            index_offset += coord * shape.idx_stride[d];
            if (d != axis) {
                input_offset += coord * shape.in_stride[d];
            }
        } else {
            if (d == axis) {
                index_offset = coord * shape.idx_stride[0];
            } else {
                input_offset += coord * shape.in_stride[d];
            }
        }
    }

    int64_t selected = static_cast<int64_t>(index[index_offset]);
    input_offset += selected * shape.in_stride[axis];
    output[linear] = input[input_offset];
}

template <typename T, typename I>
static void launch_typed(
    const at::Tensor& data,
    const at::Tensor& indices,
    const at::Tensor& output,
    const PyramidShape& shape,
    int64_t axis,
    bool elementwise) {
    int64_t count = output.numel();
    if (count == 0) {
        return;
    }

    dim3 block(256);
    dim3 grid(static_cast<unsigned int>((count + 255) / 256));
    auto stream = at::cuda::getCurrentCUDAStream(data.device().index()).stream();

    hipLaunchKernelGGL(
        (pyramid_kernel<T, I>),
        grid,
        block,
        0,
        stream,
        data.data_ptr<T>(),
        indices.data_ptr<I>(),
        output.data_ptr<T>(),
        shape,
        axis,
        elementwise,
        count);

    auto err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "pyramid kernel launch failed: ", hipGetErrorString(err));
}

template <typename T>
static void dispatch_index(
    const at::Tensor& data,
    const at::Tensor& indices,
    const at::Tensor& output,
    const PyramidShape& shape,
    int64_t axis,
    bool elementwise) {
    switch (indices.scalar_type()) {
        case at::kLong:
            launch_typed<T, int64_t>(data, indices, output, shape, axis, elementwise);
            break;
        case at::kInt:
            launch_typed<T, int32_t>(data, indices, output, shape, axis, elementwise);
            break;
        case at::kFloat:
            launch_typed<T, float>(data, indices, output, shape, axis, elementwise);
            break;
        case at::kHalf:
            launch_typed<T, at::Half>(data, indices, output, shape, axis, elementwise);
            break;
        case at::kBFloat16:
            launch_typed<T, at::BFloat16>(data, indices, output, shape, axis, elementwise);
            break;
        default:
            TORCH_CHECK(false, "unsupported index dtype");
    }
}

void pyramid_run(
    const at::Tensor& data,
    const at::Tensor& indices,
    const at::Tensor& output,
    int64_t axis,
    bool elementwise) {
    TORCH_CHECK(data.is_cuda(), "data must be on accelerator");
    TORCH_CHECK(indices.is_cuda(), "indices must be on accelerator");
    TORCH_CHECK(output.is_cuda(), "output must be on accelerator");
    TORCH_CHECK(data.is_contiguous(), "data must be contiguous");
    TORCH_CHECK(output.is_contiguous(), "output must be contiguous");
    TORCH_CHECK(data.dim() >= 1 && data.dim() <= 4, "invalid rank");

    PyramidShape shape{};
    shape.ndim = data.dim();

    for (int d = 0; d < shape.ndim; ++d) {
        shape.in_size[d] = data.size(d);
        shape.out_size[d] = output.size(d);
        shape.in_stride[d] = data.stride(d);
        shape.idx_stride[d] = elementwise ? indices.stride(d) : indices.stride(0);
    }

    TORCH_CHECK(
        data.scalar_type() == at::kFloat ||
        data.scalar_type() == at::kHalf ||
        data.scalar_type() == at::kBFloat16,
        "unsupported data dtype");

    switch (data.scalar_type()) {
        case at::kFloat:
            dispatch_index<float>(data, indices, output, shape, axis, elementwise);
            break;
        case at::kHalf:
            dispatch_index<at::Half>(data, indices, output, shape, axis, elementwise);
            break;
        case at::kBFloat16:
            dispatch_index<at::BFloat16>(data, indices, output, shape, axis, elementwise);
            break;
        default:
            TORCH_CHECK(false, "unsupported data dtype");
    }
}
"""

def _get_extension():
    global _EXT
    if _EXT is None:
        key = hashlib.sha1((CUDA_CPP_SRC + CUDA_CU_SRC).encode()).hexdigest()[:16]
        _EXT = load_inline(
            name="pyramidkernel_" + key,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, variant: str = "gather", axis: int = 1):
        super().__init__()
        assert variant in ("gather", "gather_elements")
        self.variant = variant
        self.axis = int(axis)

    def forward(self, data, indices):
        ndim = data.dim()
        axis = self.axis % ndim
        elementwise = self.variant == "gather_elements"

        if elementwise:
            out_shape = tuple(indices.shape)
        else:
            k = indices.shape[0]
            out_shape = tuple(data.shape[:axis]) + (k,) + tuple(data.shape[axis + 1:])

        output = torch.empty(out_shape, device=data.device, dtype=data.dtype)
        _get_extension().run(data, indices, output, axis, elementwise)
        return output
