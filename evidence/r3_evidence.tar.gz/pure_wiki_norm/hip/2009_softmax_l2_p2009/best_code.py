import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor row_softmax(torch::Tensor x);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("row_softmax", &row_softmax);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

__device__ __forceinline__ float wave_max(float v) {
    #pragma unroll
    for (int d = 32; d; d >>= 1)
        v = fmaxf(v, __shfl_xor(v, d, 64));
    return v;
}
__device__ __forceinline__ float wave_sum(float v) {
    #pragma unroll
    for (int d = 32; d; d >>= 1)
        v += __shfl_xor(v, d, 64);
    return v;
}

template<int K>
__global__ void small_softmax(const float* __restrict__ x,
                              float* __restrict__ y,
                              int64_t m, int64_t n) {
    int lane = threadIdx.x & 63;
    int64_t row = int64_t(blockIdx.x) * 4 + threadIdx.x / 64;
    if (row >= m) return;
    x += row * n;
    y += row * n;
    float v[K];
    float mx = -INFINITY;
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        int col = lane + k * 64;
        v[k] = col < n ? x[col] : -INFINITY;
        mx = fmaxf(mx, v[k]);
    }
    mx = wave_max(mx);
    float sum = 0.f;
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        v[k] = expf(v[k] - mx);
        sum += v[k];
    }
    float inv = 1.f / wave_sum(sum);
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        int col = lane + k * 64;
        if (col < n) y[col] = v[k] * inv;
    }
}

template<bool MAX>
__device__ __forceinline__ float block_reduce(float v, float* tmp) {
    int lane = threadIdx.x & 63;
    int wave = threadIdx.x >> 6;
    v = MAX ? wave_max(v) : wave_sum(v);
    if (lane == 0) tmp[wave] = v;
    __syncthreads();
    float r = lane < 4 ? tmp[lane] : (MAX ? -INFINITY : 0.f);
    r = MAX ? wave_max(r) : wave_sum(r);
    __syncthreads();
    return r;
}

template<int K>
__global__ void cached_softmax(const float* __restrict__ x,
                               float* __restrict__ y, int64_t n) {
    __shared__ float tmp[4];
    x += int64_t(blockIdx.x) * n;
    y += int64_t(blockIdx.x) * n;
    float v[K];
    float mx = -INFINITY;
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        int col = threadIdx.x + 256 * k;
        v[k] = col < n ? x[col] : -INFINITY;
        mx = fmaxf(mx, v[k]);
    }
    mx = block_reduce<true>(mx, tmp);
    float sum = 0.f;
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        v[k] = expf(v[k] - mx);
        sum += v[k];
    }
    float inv = 1.f / block_reduce<false>(sum, tmp);
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        int col = threadIdx.x + 256 * k;
        if (col < n) y[col] = v[k] * inv;
    }
}

__global__ void streaming_softmax(const float* __restrict__ x,
                                  float* __restrict__ y, int64_t n) {
    __shared__ float tmp[4];
    x += int64_t(blockIdx.x) * n;
    y += int64_t(blockIdx.x) * n;
    float mx = -INFINITY;
    for (int64_t j = threadIdx.x; j < n; j += 256)
        mx = fmaxf(mx, x[j]);
    mx = block_reduce<true>(mx, tmp);
    float sum = 0.f;
    for (int64_t j = threadIdx.x; j < n; j += 256)
        sum += expf(x[j] - mx);
    float inv = 1.f / block_reduce<false>(sum, tmp);
    for (int64_t j = threadIdx.x; j < n; j += 256)
        y[j] = expf(x[j] - mx) * inv;
}

torch::Tensor row_softmax(torch::Tensor x) {
    TORCH_CHECK(x.is_cuda() && x.scalar_type() == at::kFloat,
                "Expected a CUDA float32 tensor");
    TORCH_CHECK(x.dim() == 2 && x.is_contiguous(),
                "Expected contiguous two-dimensional input");
    c10::cuda::CUDAGuard guard(x.device());
    auto y = torch::empty_like(x);
    int64_t m = x.size(0), n = x.size(1);
    if (m == 0 || n == 0) return y;
    auto stream = at::cuda::getCurrentCUDAStream();
    const float* xp = x.data_ptr<float>();
    float* yp = y.data_ptr<float>();
    #define SMALL(K) small_softmax<K><<< (m+3)/4, 256, 0, stream >>>(xp,yp,m,n)
    #define CACHED(K) cached_softmax<K><<< m, 256, 0, stream >>>(xp,yp,n)
    if (n <= 64) { SMALL(1); }
    else if (n <= 128) { SMALL(2); }
    else if (n <= 256) { SMALL(4); }
    else if (n <= 512) { SMALL(8); }
    else if (n <= 1024) { SMALL(16); }
    else if (n <= 2048) { CACHED(8); }
    else if (n <= 4096) { CACHED(16); }
    else if (n <= 8192) { CACHED(32); }
    else if (n <= 16384) { CACHED(64); }
    else {
        streaming_softmax<<<m,256,0,stream>>>(xp,yp,n);
    }
    #undef SMALL
    #undef CACHED
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return y;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "dcu_row_softmax_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return _get_extension().row_softmax(x)
