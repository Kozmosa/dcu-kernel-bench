import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor bt, torch::Tensor lens, torch::Tensor cu, torch::Tensor sinks,
    double scale, int64_t window, double cap, bool use_sinks);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention", &paged_attention);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cmath>

constexpr int CHUNK = 256;
constexpr int THREADS = 256;

__global__ void partial_attention(
    const float* __restrict__ q, const float* __restrict__ k,
    const float* __restrict__ v, const int* __restrict__ bt,
    const int* __restrict__ lens, const int* __restrict__ cu,
    float* __restrict__ partial, int ns, int nh, int nk,
    int dim, int bs, int table_width, int splits,
    float scale, int window, float cap)
{
    int row = blockIdx.x, h = blockIdx.y, split = blockIdx.z;
    int tid = threadIdx.x;
    int lo = 0, hi = ns;
    while (lo + 1 < hi) {
        int mid = (lo + hi) >> 1;
        if (cu[mid] <= row) lo = mid;
        else hi = mid;
    }
    int s = lo;
    int end = lens[s] - (cu[s + 1] - row);
    int first = window > 0 ? max(0, end - window + 1) : 0;
    int begin = first + split * CHUNK;
    int count = min(CHUNK, end + 1 - begin);
    long long base = (((long long)row * nh + h) * splits + split) * (dim + 2);
    if (count <= 0) {
        if (tid == 0) {
            partial[base + dim] = -INFINITY;
            partial[base + dim + 1] = 0.0f;
        }
        for (int d = tid; d < dim; d += THREADS)
            partial[base + d] = 0.0f;
        return;
    }

    extern __shared__ float shared[];
    float* sq = shared;
    float* scores = sq + dim;
    float* red = scores + CHUNK;
    for (int d = tid; d < dim; d += THREADS)
        sq[d] = q[((long long)row * nh + h) * dim + d] * scale;
    __syncthreads();

    int lane = tid & 63, wave = tid >> 6;
    int g = h / (nh / nk);
    for (int t = wave; t < CHUNK; t += 4) {
        float dot = 0.0f;
        if (t < count) {
            int j = begin + t;
            int phys = bt[s * table_width + j / bs];
            long long offset = (((long long)phys * bs + j % bs) * nk + g) * dim;
            for (int d = lane; d < dim; d += 64)
                dot = fmaf(sq[d], k[offset + d], dot);
        }
        for (int delta = 32; delta > 0; delta >>= 1)
            dot += __shfl_down(dot, delta, 64);
        if (lane == 0) {
            if (cap > 0.0f) dot = cap * tanhf(dot / cap);
            scores[t] = t < count ? dot : -INFINITY;
        }
    }
    __syncthreads();
    red[tid] = scores[tid];
    __syncthreads();
    for (int step = 128; step; step >>= 1) {
        if (tid < step) red[tid] = fmaxf(red[tid], red[tid + step]);
        __syncthreads();
    }
    float m = red[0];
    float p = tid < count ? expf(scores[tid] - m) : 0.0f;
    scores[tid] = p;
    __syncthreads();
    red[tid] = p;
    __syncthreads();
    for (int step = 128; step; step >>= 1) {
        if (tid < step) red[tid] += red[tid + step];
        __syncthreads();
    }
    if (tid == 0) {
        partial[base + dim] = m;
        partial[base + dim + 1] = red[0];
    }
    for (int d = tid; d < dim; d += THREADS) {
        float acc = 0.0f;
        for (int t = 0; t < count; ++t) {
            int j = begin + t;
            int phys = bt[s * table_width + j / bs];
            long long offset = (((long long)phys * bs + j % bs) * nk + g) * dim;
            acc = fmaf(scores[t], v[offset + d], acc);
        }
        partial[base + d] = acc;
    }
}

__global__ void finish_attention(
    const float* __restrict__ partial, const float* __restrict__ sinks,
    float* __restrict__ output, int nh, int dim, int splits,
    float cap, bool use_sinks)
{
    int item = blockIdx.x;
    int h = item % nh;
    long long base = (long long)item * splits * (dim + 2);
    extern __shared__ float weights[];
    __shared__ float denominator;
    if (threadIdx.x == 0) {
        float sink = -INFINITY;
        if (use_sinks) {
            sink = sinks[h];
            if (cap > 0.0f) sink = cap * tanhf(sink / cap);
        }
        float maximum = sink;
        for (int s = 0; s < splits; ++s)
            maximum = fmaxf(maximum, partial[base + (long long)s * (dim + 2) + dim]);
        float sum = use_sinks ? expf(sink - maximum) : 0.0f;
        for (int s = 0; s < splits; ++s) {
            long long at = base + (long long)s * (dim + 2);
            float w = expf(partial[at + dim] - maximum);
            weights[s] = w;
            sum += w * partial[at + dim + 1];
        }
        denominator = sum;
    }
    __syncthreads();
    for (int d = threadIdx.x; d < dim; d += blockDim.x) {
        float acc = 0.0f;
        for (int s = 0; s < splits; ++s)
            acc = fmaf(weights[s], partial[base + (long long)s * (dim + 2) + d], acc);
        output[(long long)item * dim + d] = acc / denominator;
    }
}

torch::Tensor paged_attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor bt, torch::Tensor lens, torch::Tensor cu, torch::Tensor sinks,
    double scale, int64_t window, double cap, bool use_sinks)
{
    c10::cuda::CUDAGuard guard(q.device());
    int rows = q.size(0), nh = q.size(1), dim = q.size(2);
    int nk = k.size(2), bs = k.size(1), tw = bt.size(1);
    int maximum = tw * bs;
    if (window > 0) maximum = std::min<int64_t>(maximum, window);
    int splits = std::max(1, (maximum + CHUNK - 1) / CHUNK);
    auto out = torch::empty_like(q);
    if (rows == 0) return out;
    auto tmp = torch::empty({rows, nh, splits, dim + 2}, q.options());
    auto stream = c10::cuda::getCurrentCUDAStream().stream();
    partial_attention<<<dim3(rows, nh, splits), THREADS,
        (dim + CHUNK + THREADS) * sizeof(float), stream>>>(
        q.data_ptr<float>(), k.data_ptr<float>(), v.data_ptr<float>(),
        bt.data_ptr<int>(), lens.data_ptr<int>(), cu.data_ptr<int>(),
        tmp.data_ptr<float>(), lens.numel(), nh, nk, dim, bs, tw, splits,
        scale, window, cap);
    finish_attention<<<rows * nh, 256, splits * sizeof(float), stream>>>(
        tmp.data_ptr<float>(), sinks.data_ptr<float>(), out.data_ptr<float>(),
        nh, dim, splits, cap, use_sinks);
    return out;
}
"""

_EXT = None


def _extension():
    global _EXT
    if _EXT is None:
        name = "paged_attention_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXT = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, head_size: int, sliding_window: int = 0, softcap: float = 0.0, use_sinks: bool = True):
        super().__init__()
        self.scale = 1.0 / math.sqrt(head_size)
        self.sliding_window = int(sliding_window)
        self.softcap = float(softcap)
        self.use_sinks = bool(use_sinks)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens, cu_seqlens_q, sinks):
        return _extension().paged_attention(
            query, key_cache, value_cache,
            block_tables.to(dtype=torch.int32),
            seq_lens.to(dtype=torch.int32),
            cu_seqlens_q.to(dtype=torch.int32),
            sinks, self.scale, self.sliding_window, self.softcap, self.use_sinks,
        )
