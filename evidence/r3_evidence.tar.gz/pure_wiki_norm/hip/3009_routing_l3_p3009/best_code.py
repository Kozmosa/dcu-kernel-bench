import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
void route_hip(torch::Tensor x, torch::Tensor w, torch::Tensor tmp,
               torch::Tensor out, bool fused);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("route", &route_hip);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/hip/HIPException.h>
#include <stdint.h>
#include <limits.h>

__device__ __forceinline__ void choose(float v, int i, float &best, int &id) {
    if (v > best || (v == best && i < id)) {
        best = v;
        id = i;
    }
}

__device__ __forceinline__ void store_result(
    float* out, int row, int n, bool fused, float score, int id) {
    if (fused) {
        out[(int64_t)row * 4] = (float)id;
        out[(int64_t)row * 4 + 1] = (float)n;
        out[(int64_t)row * 4 + 2] = score;
        out[(int64_t)row * 4 + 3] = 1.0f;
    } else {
        out[(int64_t)row * 2] = (float)id;
        out[(int64_t)row * 2 + 1] = score;
    }
}

template<typename scalar_t>
__global__ __launch_bounds__(256) void tiled_route(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ w,
    float* __restrict__ tmp,
    float* __restrict__ out,
    int m, int k, int n, int tiles,
    int64_t xs0, int64_t xs1, int64_t ws0, int64_t ws1,
    bool fused) {
    __shared__ float sx[16][33];
    __shared__ float sw[32][64];

    const int t = threadIdx.x;
    const int lane = t & 63;
    const int wave = t >> 6;
    const int row0 = blockIdx.x * 16;
    const int col0 = blockIdx.y * 64;
    const int col = col0 + lane;

    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    for (int kb = 0; kb < k; kb += 32) {
        for (int a = t; a < 512; a += 256) {
            int r = a >> 5;
            int q = a & 31;
            sx[r][q] = (row0 + r < m && kb + q < k)
                ? (float)x[(int64_t)(row0 + r) * xs0 + (int64_t)(kb + q) * xs1]
                : 0.f;
        }
        for (int a = t; a < 2048; a += 256) {
            int q = a >> 6;
            int c = a & 63;
            sw[q][c] = (kb + q < k && col0 + c < n)
                ? (float)w[(int64_t)(kb + q) * ws0 + (int64_t)(col0 + c) * ws1]
                : 0.f;
        }
        __syncthreads();
        #pragma unroll
        for (int q = 0; q < 32; ++q) {
            float b = sw[q][lane];
            #pragma unroll
            for (int r = 0; r < 4; ++r)
                acc[r] = fmaf(sx[wave + 4 * r][q], b, acc[r]);
        }
        __syncthreads();
    }

    #pragma unroll
    for (int r = 0; r < 4; ++r) {
        int row = row0 + wave + 4 * r;
        float score = col < n ? 1.f / (1.f + expf(-acc[r])) : -1.f;
        int id = col < n ? col : INT_MAX;
        #pragma unroll
        for (int offset = 32; offset > 0; offset >>= 1) {
            float other = __shfl_down(score, offset, 64);
            int oi = __shfl_down(id, offset, 64);
            choose(other, oi, score, id);
        }
        if (lane == 0 && row < m) {
            if (tiles == 1) {
                store_result(out, row, n, fused, score, id);
            } else {
                int64_t pos = ((int64_t)row * tiles + blockIdx.y) * 2;
                tmp[pos] = score;
                tmp[pos + 1] = (float)id;
            }
        }
    }
}

__global__ __launch_bounds__(128) void finish_route(
    const float* __restrict__ tmp, float* __restrict__ out,
    int tiles, int n, bool fused) {
    __shared__ float scores[128];
    __shared__ int ids[128];
    int t = threadIdx.x;
    int row = blockIdx.x;
    float best = -1.f;
    int id = INT_MAX;
    for (int j = t; j < tiles; j += 128) {
        int64_t p = ((int64_t)row * tiles + j) * 2;
        choose(tmp[p], (int)tmp[p + 1], best, id);
    }
    scores[t] = best;
    ids[t] = id;
    __syncthreads();
    for (int step = 64; step > 0; step >>= 1) {
        if (t < step) {
            float v = scores[t];
            int i = ids[t];
            choose(scores[t + step], ids[t + step], v, i);
            scores[t] = v;
            ids[t] = i;
        }
        __syncthreads();
    }
    if (t == 0)
        store_result(out, row, n, fused, scores[0], ids[0]);
}

void route_hip(torch::Tensor x, torch::Tensor w, torch::Tensor tmp,
               torch::Tensor out, bool fused) {
    c10::cuda::CUDAGuard guard(x.device());
    int m = x.size(0), k = x.size(1), n = w.size(1);
    if (!m) return;
    int tiles = (n + 63) / 64;
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(),
        "tiled_route", [&] {
            tiled_route<scalar_t><<<dim3((m + 15) / 16, tiles), 256, 0, stream.stream()>>>(
                x.data_ptr<scalar_t>(), w.data_ptr<scalar_t>(),
                tmp.data_ptr<float>(), out.data_ptr<float>(),
                m, k, n, tiles, x.stride(0), x.stride(1),
                w.stride(0), w.stride(1), fused);
        });
    if (tiles > 1)
        finish_route<<<m, 128, 0, stream.stream()>>>(
            tmp.data_ptr<float>(), out.data_ptr<float>(), tiles, n, fused);
    C10_HIP_CHECK(hipGetLastError());
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "sigmoid_route_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, fused_shared_experts: bool = True):
        super().__init__()
        self.fused_shared_experts = bool(fused_shared_experts)

    def forward(self, x, w):
        assert x.dim() == 2 and w.dim() == 2
        m, k = x.shape
        assert w.shape[0] == k
        assert x.is_cuda and w.is_cuda and x.device == w.device
        assert x.dtype == w.dtype
        n = w.shape[1]
        assert k >= 1 and n >= 1
        tiles = (n + 63) // 64
        out = torch.empty(
            (m, 4 if self.fused_shared_experts else 2),
            device=x.device, dtype=torch.float32,
        )
        tmp = torch.empty(
            (m, tiles, 2) if tiles > 1 else (0,),
            device=x.device, dtype=torch.float32,
        )
        _extension().route(x, w, tmp, out, self.fused_shared_experts)
        return out
