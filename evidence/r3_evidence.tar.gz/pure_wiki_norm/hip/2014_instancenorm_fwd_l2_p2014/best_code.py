import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_EXTENSION = None


CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor instance_norm_forward(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    double eps);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("instance_norm_forward", &instance_norm_forward);
}
"""


CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/Dispatch.h>
#include <c10/cuda/CUDAStream.h>
#include <hip/hip_runtime.h>

template <typename scalar_t>
__global__ void instance_norm_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ scale,
    const scalar_t* __restrict__ bias,
    scalar_t* __restrict__ out,
    int64_t planes,
    int64_t spatial,
    float eps) {
    const int64_t plane = static_cast<int64_t>(blockIdx.x);
    if (plane >= planes) {
        return;
    }

    const int tid = threadIdx.x;
    __shared__ float red[256];
    __shared__ float mean_value;
    __shared__ float inv_std_value;

    const int64_t base = plane * spatial;

    float sum = 0.0f;
    for (int64_t i = tid; i < spatial; i += blockDim.x) {
        sum += static_cast<float>(x[base + i]);
    }

    red[tid] = sum;
    __syncthreads();

    for (int stride = 128; stride > 0; stride >>= 1) {
        if (tid < stride) {
            red[tid] += red[tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0) {
        mean_value = red[0] / static_cast<float>(spatial);
    }
    __syncthreads();

    const float mean = mean_value;
    float var_sum = 0.0f;
    for (int64_t i = tid; i < spatial; i += blockDim.x) {
        const float d = static_cast<float>(x[base + i]) - mean;
        var_sum += d * d;
    }

    red[tid] = var_sum;
    __syncthreads();

    for (int stride = 128; stride > 0; stride >>= 1) {
        if (tid < stride) {
            red[tid] += red[tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0) {
        const float variance = red[0] / static_cast<float>(spatial);
        inv_std_value = rsqrtf(variance + eps);
    }
    __syncthreads();

    const int64_t channel = plane % static_cast<int64_t>(gridDim.y == 0 ? 1 : gridDim.y);
    const float sf = static_cast<float>(scale[channel]);
    const float bf = static_cast<float>(bias[channel]);
    const float inv_std = inv_std_value;

    for (int64_t i = tid; i < spatial; i += blockDim.x) {
        const float v = (static_cast<float>(x[base + i]) - mean) * inv_std;
        out[base + i] = static_cast<scalar_t>(v * sf + bf);
    }
}


template <typename scalar_t>
static void launch_instance_norm(
    const torch::Tensor& x,
    const torch::Tensor& scale,
    const torch::Tensor& bias,
    torch::Tensor& out,
    float eps,
    int64_t planes,
    int64_t channels,
    int64_t spatial,
    hipStream_t stream) {
    dim3 grid(static_cast<unsigned int>(planes), 1, 1);
    dim3 block(256, 1, 1);

    hipLaunchKernelGGL(
        (instance_norm_kernel<scalar_t>),
        grid,
        block,
        0,
        stream,
        x.data_ptr<scalar_t>(),
        scale.data_ptr<scalar_t>(),
        bias.data_ptr<scalar_t>(),
        out.data_ptr<scalar_t>(),
        planes,
        spatial,
        eps);

    TORCH_CHECK(
        hipGetLastError() == hipSuccess,
        "instance_norm kernel launch failed");
}


torch::Tensor instance_norm_forward(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    double eps) {
    TORCH_CHECK(x.is_cuda(), "x must be on a CUDA/HIP device");
    TORCH_CHECK(scale.is_cuda(), "scale must be on a CUDA/HIP device");
    TORCH_CHECK(bias.is_cuda(), "bias must be on a CUDA/HIP device");

    TORCH_CHECK(x.is_contiguous(), "x must be contiguous");
    TORCH_CHECK(scale.is_contiguous(), "scale must be contiguous");
    TORCH_CHECK(bias.is_contiguous(), "bias must be contiguous");

    TORCH_CHECK(x.dim() == 4, "x must be 4D");
    TORCH_CHECK(scale.dim() == 4 && bias.dim() == 4, "parameters must be 4D");
    TORCH_CHECK(x.scalar_type() == scale.scalar_type(), "dtype mismatch");
    TORCH_CHECK(x.scalar_type() == bias.scalar_type(), "dtype mismatch");

    const int64_t n = x.size(0);
    const int64_t c = x.size(1);
    const int64_t h = x.size(2);
    const int64_t w = x.size(3);
    const int64_t spatial = h * w;
    const int64_t planes = n * c;

    TORCH_CHECK(scale.numel() >= c, "invalid scale shape");
    TORCH_CHECK(bias.numel() >= c, "invalid bias shape");
    TORCH_CHECK(planes > 0 && spatial > 0, "empty tensors are unsupported");

    auto out = torch::empty_like(x);
    const auto stream = at::cuda::getCurrentCUDAStream(x.get_device()).stream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::Half,
        at::BFloat16,
        x.scalar_type(),
        "instance_norm_forward",
        [&] {
            launch_instance_norm<scalar_t>(
                x,
                scale,
                bias,
                out,
                static_cast<float>(eps),
                planes,
                c,
                spatial,
                stream);
        });

    return out;
}
"""


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((CPP_SRC + CU_SRC).encode("utf-8")).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="instance_norm_hip_" + digest,
            cpp_sources=CPP_SRC,
            cuda_sources=CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        assert eps > 0, "eps must be positive"
        self.eps = float(eps)

    def forward(self, x, scale, bias):
        return _get_extension().instance_norm_forward(
            x, scale, bias, self.eps
        )
