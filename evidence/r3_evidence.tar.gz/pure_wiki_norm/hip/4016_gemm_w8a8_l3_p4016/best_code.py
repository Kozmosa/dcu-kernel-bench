import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
void block_gemm(torch::Tensor a, torch::Tensor b,
                torch::Tensor sa, torch::Tensor sb, torch::Tensor out);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("block_gemm", &block_gemm);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template<typename T, typename O>
__global__ __launch_bounds__(128)
void gemm_kernel(
    const T* __restrict__ a, const T* __restrict__ b,
    const float* __restrict__ sa, const float* __restrict__ sb,
    O* __restrict__ out,
    int M, int N, int K,
    int64_t a0, int64_t a1, int64_t b0, int64_t b1,
    int64_t sa0, int64_t sa1, int64_t sb0, int64_t sb1)
{
    __shared__ int aa[32][33];
    __shared__ int bb[64][33];
    const int tid = threadIdx.x;
    const int rm = tid / 16;
    const int rn = tid % 16;
    const int mb = blockIdx.y * 32;
    const int nb = blockIdx.x * 64;
    float total[4][4] = {};
    const int groups = (K + 127) / 128;

    for (int g = 0; g < groups; ++g) {
        int dot[4][4] = {};
        for (int chunk = 0; chunk < 4; ++chunk) {
            const int kb = g * 128 + chunk * 32;
            for (int p = tid; p < 32 * 32; p += 128) {
                const int r = p / 32, k = p % 32;
                aa[r][k] = (mb + r < M && kb + k < K)
                    ? static_cast<int>(a[(mb + r) * a0 + (kb + k) * a1]) : 0;
            }
            for (int p = tid; p < 64 * 32; p += 128) {
                const int r = p / 32, k = p % 32;
                bb[r][k] = (nb + r < N && kb + k < K)
                    ? static_cast<int>(b[(nb + r) * b0 + (kb + k) * b1]) : 0;
            }
            __syncthreads();
            #pragma unroll
            for (int k = 0; k < 32; ++k) {
                int av[4], bv[4];
                #pragma unroll
                for (int i = 0; i < 4; ++i) {
                    av[i] = aa[rm + i * 8][k];
                    bv[i] = bb[rn + i * 16][k];
                }
                #pragma unroll
                for (int i = 0; i < 4; ++i)
                    #pragma unroll
                    for (int j = 0; j < 4; ++j)
                        dot[i][j] += av[i] * bv[j];
            }
            __syncthreads();
        }
        const float bs = sb[(nb / 128) * sb0 + g * sb1];
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            const int m = mb + rm + i * 8;
            const float scale = m < M ? sa[m * sa0 + g * sa1] * bs : 0.0f;
            #pragma unroll
            for (int j = 0; j < 4; ++j)
                total[i][j] = fmaf(static_cast<float>(dot[i][j]), scale, total[i][j]);
        }
    }
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const int m = mb + rm + i * 8;
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int n = nb + rn + j * 16;
            if (m < M && n < N)
                out[(int64_t)m * N + n] = static_cast<O>(total[i][j]);
        }
    }
}

template<typename T, typename O>
void launch(torch::Tensor a, torch::Tensor b, torch::Tensor sa,
            torch::Tensor sb, torch::Tensor out) {
    int M = a.size(0), N = b.size(0), K = a.size(1);
    if (!M || !N) return;
    gemm_kernel<T,O><<<dim3((N+63)/64, (M+31)/32),128,0,
        at::cuda::getCurrentCUDAStream()>>>(
        a.data_ptr<T>(), b.data_ptr<T>(),
        sa.data_ptr<float>(), sb.data_ptr<float>(), out.data_ptr<O>(),
        M,N,K,a.stride(0),a.stride(1),b.stride(0),b.stride(1),
        sa.stride(0),sa.stride(1),sb.stride(0),sb.stride(1));
}

template<typename T>
void select_output(torch::Tensor a, torch::Tensor b, torch::Tensor sa,
                   torch::Tensor sb, torch::Tensor out) {
    if (out.scalar_type() == at::kBFloat16)
        launch<T,at::BFloat16>(a,b,sa,sb,out);
    else if (out.scalar_type() == at::kHalf)
        launch<T,at::Half>(a,b,sa,sb,out);
    else
        launch<T,float>(a,b,sa,sb,out);
}

void block_gemm(torch::Tensor a, torch::Tensor b,
                torch::Tensor sa, torch::Tensor sb, torch::Tensor out) {
    c10::cuda::CUDAGuard guard(a.device());
    TORCH_CHECK(a.scalar_type() == b.scalar_type(), "Input types must match");
    TORCH_CHECK(sa.scalar_type() == at::kFloat && sb.scalar_type() == at::kFloat,
                "Scales must be float32");
    if (a.scalar_type() == at::kFloat)
        select_output<float>(a,b,sa,sb,out);
    else if (a.scalar_type() == at::kChar)
        select_output<int8_t>(a,b,sa,sb,out);
    else
        TORCH_CHECK(false, "Code words must be float32 or int8");
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "block_quant_gemm_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, out_dtype: str = "bfloat16"):
        super().__init__()
        self.out_dtype = getattr(torch, out_dtype)
        self.block_n = 128
        self.block_k = 128

    def forward(self, aq, bq, a_scale, b_scale):
        M, K = aq.shape
        N = bq.shape[0]
        assert K == bq.shape[1], "the K dimension of aq and bq must match"
        out = torch.empty((M, N), device=aq.device, dtype=self.out_dtype)
        _extension().block_gemm(aq, bq, a_scale, b_scale, out)
        return out
