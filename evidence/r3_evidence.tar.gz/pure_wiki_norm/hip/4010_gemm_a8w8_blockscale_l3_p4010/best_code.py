import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXTENSION = None

_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_forward(
    torch::Tensor x,
    torch::Tensor w,
    torch::Tensor xs,
    torch::Tensor ws,
    int64_t group_k,
    int64_t group_n,
    bool output_half);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pyramid_forward", &pyramid_forward);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <hip/hip_fp16.h>
#include <hip/hip_bfloat16.h>
#include <cmath>

__device__ __forceinline__ float decode_e4m3fn(unsigned char v) {
    const int sign = (v >> 7) & 1;
    const int exponent = (v >> 3) & 15;
    const int mantissa = v & 7;
    float result;
    if (exponent == 0) {
        result = static_cast<float>(mantissa) * 0.001953125f;
    } else {
        result = (1.0f + static_cast<float>(mantissa) * 0.125f) *
                 ldexpf(1.0f, exponent - 7);
    }
    return sign ? -result : result;
}

template <bool HALF_OUTPUT>
__global__ void pyramid_kernel(
    const unsigned char* __restrict__ x,
    const unsigned char* __restrict__ w,
    const float* __restrict__ xs,
    const float* __restrict__ ws,
    void* __restrict__ out,
    int M,
    int N,
    int K,
    int SK,
    int group_k,
    int group_n) {
    constexpr int BM = 16;
    constexpr int BN = 16;
    constexpr int BK = 32;

    __shared__ float sx[BM][BK];
    __shared__ float sw[BN][BK];

    const int tx = static_cast<int>(threadIdx.x);
    const int ty = static_cast<int>(threadIdx.y);
    const int tid = ty * BN + tx;

    const int row = static_cast<int>(blockIdx.y) * BM + ty;
    const int col = static_cast<int>(blockIdx.x) * BN + tx;

    float acc = 0.0f;

    for (int k0 = 0; k0 < K; k0 += BK) {
        const int kx = k0 + (tid & (BK - 1));
        const int rx = tid >> 5;
        const int kw = k0 + (tid & (BK - 1));
        const int rw = tid >> 5;

        if (rx < BM && kx < K) {
            const int block_k = kx / group_k;
            const int xr = static_cast<int>(blockIdx.y) * BM + rx;
            if (xr < M) {
                sx[rx][kx - k0] =
                    decode_e4m3fn(x[xr * K + kx]) *
                    xs[xr * SK + block_k];
            } else {
                sx[rx][kx - k0] = 0.0f;
            }
        } else if (rx < BM) {
            sx[rx][kx - k0] = 0.0f;
        }

        if (rw < BN && kw < K) {
            const int block_k = kw / group_k;
            const int wr = static_cast<int>(blockIdx.x) * BN + rw;
            if (wr < N) {
                const int block_n = wr / group_n;
                sw[rw][kw - k0] =
                    decode_e4m3fn(w[wr * K + kw]) *
                    ws[block_n * SK + block_k];
            } else {
                sw[rw][kw - k0] = 0.0f;
            }
        } else if (rw < BN) {
            sw[rw][kw - k0] = 0.0f;
        }

        __syncthreads();

        if (row < M && col < N) {
            const int remaining = K - k0;
            const int count = remaining < BK ? remaining : BK;
            for (int kk = 0; kk < count; ++kk) {
                acc += sx[ty][kk] * sw[tx][kk];
            }
        }

        __syncthreads();
    }

    if (row < M && col < N) {
        const int index = row * N + col;
        if constexpr (HALF_OUTPUT) {
            reinterpret_cast<__half*>(out)[index] = __float2half(acc);
        } else {
            reinterpret_cast<__hip_bfloat16*>(out)[index] =
                __float2bfloat16(acc);
        }
    }
}

torch::Tensor pyramid_forward(
    torch::Tensor x,
    torch::Tensor w,
    torch::Tensor xs,
    torch::Tensor ws,
    int64_t group_k,
    int64_t group_n,
    bool output_half) {
    TORCH_CHECK(x.is_cuda(), "x must be on accelerator");
    TORCH_CHECK(w.is_cuda(), "w must be on accelerator");
    TORCH_CHECK(xs.is_cuda(), "xs must be on accelerator");
    TORCH_CHECK(ws.is_cuda(), "ws must be on accelerator");
    TORCH_CHECK(x.scalar_type() == at::ScalarType::Float8_e4m3fn,
                "x must be float8_e4m3fn");
    TORCH_CHECK(w.scalar_type() == at::ScalarType::Float8_e4m3fn,
                "w must be float8_e4m3fn");
    TORCH_CHECK(xs.scalar_type() == at::ScalarType::Float,
                "xs must be float32");
    TORCH_CHECK(ws.scalar_type() == at::ScalarType::Float,
                "ws must be float32");

    const int M = static_cast<int>(x.size(0));
    const int K = static_cast<int>(x.size(1));
    const int N = static_cast<int>(w.size(0));
    const int SK = (K + static_cast<int>(group_k) - 1) /
                   static_cast<int>(group_k);

    auto dtype = output_half ? at::ScalarType::Half
                             : at::ScalarType::BFloat16;
    auto out = torch::empty({M, N}, x.options().dtype(dtype));

    dim3 block(16, 16, 1);
    dim3 grid((N + 15) / 16, (M + 15) / 16, 1);
    hipStream_t stream = at::cuda::getDefaultCUDAStream();

    if (output_half) {
        hipLaunchKernelGGL(
            (pyramid_kernel<true>),
            grid,
            block,
            0,
            stream,
            x.data_ptr<unsigned char>(),
            w.data_ptr<unsigned char>(),
            xs.data_ptr<float>(),
            ws.data_ptr<float>(),
            out.data_ptr(),
            M,
            N,
            K,
            SK,
            static_cast<int>(group_k),
            static_cast<int>(group_n));
    } else {
        hipLaunchKernelGGL(
            (pyramid_kernel<false>),
            grid,
            block,
            0,
            stream,
            x.data_ptr<unsigned char>(),
            w.data_ptr<unsigned char>(),
            xs.data_ptr<float>(),
            ws.data_ptr<float>(),
            out.data_ptr(),
            M,
            N,
            K,
            SK,
            static_cast<int>(group_k),
            static_cast<int>(group_n));
    }

    auto err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "pyramid kernel launch failed: ",
                hipGetErrorString(err));
    return out;
}
"""

def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        _EXTENSION = load_inline(
            name="pyramidkernel_hip_fast",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, group_k=128, group_n=128, out_dtype="bfloat16"):
        super().__init__()
        if isinstance(group_k, (list, tuple)):
            group_k, group_n, out_dtype = group_k
        self.group_k = int(group_k)
        self.group_n = int(group_n)
        self.out_dtype = getattr(torch, out_dtype)

    def forward(self, x, w, x_scale, w_scale):
        x = x.to(torch.float8_e4m3fn).contiguous()
        w = w.to(torch.float8_e4m3fn).contiguous()
        x_scale = x_scale.contiguous()
        w_scale = w_scale.contiguous()

        gk = self.group_k
        gn = self.group_n
        M, K = x.shape
        N = w.shape[0]

        if K != w.shape[1]:
            raise AssertionError("the K dimension of x and w must match")

        scale_k = (K + gk - 1) // gk
        scale_n = (N + gn - 1) // gn

        if tuple(x_scale.shape) != (M, scale_k):
            raise AssertionError(
                f"x_scale shape should be ({M}, {scale_k}), "
                f"got {tuple(x_scale.shape)}"
            )
        if tuple(w_scale.shape) != (scale_n, scale_k):
            raise AssertionError(
                f"w_scale shape should be ({scale_n}, {scale_k}), "
                f"got {tuple(w_scale.shape)}"
            )

        output_half = self.out_dtype == torch.float16
        return _get_extension().pyramid_forward(
            x,
            w,
            x_scale,
            w_scale,
            gk,
            gn,
            output_half,
        )
