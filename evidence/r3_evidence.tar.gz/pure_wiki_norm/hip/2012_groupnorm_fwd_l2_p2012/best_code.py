import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor run(torch::Tensor x, torch::Tensor s, torch::Tensor b,
                  int64_t groups, double eps, bool swish);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) { m.def("run", &run); }
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/hip/HIPException.h>

constexpr int B = 256;

__device__ float reduce_sum(float v, float* sm) {
    int t = threadIdx.x;
    sm[t] = v;
    __syncthreads();
    for (int stride = B / 2; stride; stride >>= 1) {
        if (t < stride) sm[t] += sm[t + stride];
        __syncthreads();
    }
    return sm[0];
}

template<bool SW>
__global__ void small_kernel(const float* x, const float* scale,
                             const float* bias, float* out,
                             int64_t D, int64_t spatial, int C,
                             int64_t total, int rows, float eps) {
    __shared__ float sm[B];
    int r = blockIdx.x;
    int t = threadIdx.x;
    int64_t base = (int64_t)r * D;
    float sum = 0;
    for (int64_t j = t; j < D; j += B) sum += x[base+j];
    float mean = reduce_sum(sum, sm) / (float)D;
    __syncthreads();
    float sq = 0;
    for (int64_t j = t; j < D; j += B) {
        float d = x[base+j] - mean;
        sq += d*d;
    }
    float inv = rsqrtf(reduce_sum(sq, sm) / (float)D + eps);
    if (t == 0) {
        out[total+r] = mean;
        out[total+rows+r] = inv;
    }
    for (int64_t j = t; j < D; j += B) {
        int c = ((base+j) / spatial) % C;
        float y = ((x[base+j]-mean)*inv)*scale[c]+bias[c];
        if (SW) y = y / (1.0f + expf(-y));
        out[base+j] = y;
    }
}

// Each tile computes stable, centered local statistics.
__global__ void partial_kernel(const float* x, float* tmp,
                               int64_t D, int tiles) {
    __shared__ float sm[B];
    int r = blockIdx.y, tile = blockIdx.x, t = threadIdx.x;
    int64_t start = (int64_t)tile * 4096;
    int count = (int)((D-start < 4096) ? D-start : 4096);
    int64_t base = (int64_t)r*D + start;
    float sum = 0;
    for (int j=t; j<count; j+=B) sum += x[base+j];
    float mean = reduce_sum(sum,sm)/(float)count;
    __syncthreads();
    float sq=0;
    for (int j=t; j<count; j+=B) {
        float d=x[base+j]-mean;
        sq += d*d;
    }
    float m2=reduce_sum(sq,sm);
    if (!t) {
        int64_t p=((int64_t)r*tiles+tile)*2;
        tmp[p]=mean;
        tmp[p+1]=m2;
    }
}

__global__ void finish_kernel(const float* tmp, float* out,
                             int64_t D, int tiles, int rows,
                             int64_t total, float eps) {
    __shared__ float sm[B];
    int r=blockIdx.x, t=threadIdx.x;
    float sum=0;
    for (int k=t; k<tiles; k+=B) {
        int count=(int)(((D-(int64_t)k*4096)<4096) ?
                         D-(int64_t)k*4096 : 4096);
        sum += tmp[((int64_t)r*tiles+k)*2]*count;
    }
    float mean=reduce_sum(sum,sm)/(float)D;
    __syncthreads();
    float sq=0;
    for (int k=t; k<tiles; k+=B) {
        int count=(int)(((D-(int64_t)k*4096)<4096) ?
                         D-(int64_t)k*4096 : 4096);
        int64_t p=((int64_t)r*tiles+k)*2;
        float d=tmp[p]-mean;
        sq += tmp[p+1]+d*d*count;
    }
    float inv=rsqrtf(reduce_sum(sq,sm)/(float)D+eps);
    if (!t) {
        out[total+r]=mean;
        out[total+rows+r]=inv;
    }
}

template<bool SW>
__global__ void apply_kernel(const float* x, const float* s,
                             const float* b, float* out,
                             int64_t D, int64_t spatial, int C,
                             int64_t total, int rows) {
    int64_t i=(int64_t)blockIdx.x*B*4+threadIdx.x;
    #pragma unroll
    for (int k=0;k<4;++k,i+=B) {
        if (i<total) {
            int r=i/D;
            int c=(i/spatial)%C;
            float y=((x[i]-out[total+r])*out[total+rows+r])*s[c]+b[c];
            if (SW) y=y/(1.0f+expf(-y));
            out[i]=y;
        }
    }
}

torch::Tensor run(torch::Tensor x, torch::Tensor s, torch::Tensor b,
                  int64_t groups, double eps, bool swish) {
    c10::cuda::CUDAGuard guard(x.device());
    TORCH_CHECK(x.scalar_type()==torch::kFloat32 &&
                s.scalar_type()==torch::kFloat32 &&
                b.scalar_type()==torch::kFloat32, "Expected float32 inputs");
    TORCH_CHECK(x.is_contiguous() && s.is_contiguous() && b.is_contiguous(),
                "Expected contiguous inputs");
    int C=x.size(1);
    int64_t spatial=x.size(2)*x.size(3);
    int64_t D=(C/groups)*spatial, total=x.numel();
    int rows=x.size(0)*groups;
    auto out=torch::empty({total+2*rows}, x.options());
    auto stream=c10::cuda::getCurrentCUDAStream().stream();
    const float *xp=x.data_ptr<float>(), *sp=s.data_ptr<float>(),
                *bp=b.data_ptr<float>();
    float* op=out.data_ptr<float>();
    if (D<=4096) {
        if (swish)
            small_kernel<true><<<rows,B,0,stream>>>(
                xp,sp,bp,op,D,spatial,C,total,rows,(float)eps);
        else
            small_kernel<false><<<rows,B,0,stream>>>(
                xp,sp,bp,op,D,spatial,C,total,rows,(float)eps);
    } else {
        int tiles=(D+4095)/4096;
        auto tmp=torch::empty({(int64_t)rows*tiles*2},x.options());
        partial_kernel<<<dim3(tiles,rows),B,0,stream>>>(
            xp,tmp.data_ptr<float>(),D,tiles);
        finish_kernel<<<rows,B,0,stream>>>(
            tmp.data_ptr<float>(),op,D,tiles,rows,total,(float)eps);
        int blocks=(total+B*4-1)/(B*4);
        if (swish)
            apply_kernel<true><<<blocks,B,0,stream>>>(
                xp,sp,bp,op,D,spatial,C,total,rows);
        else
            apply_kernel<false><<<blocks,B,0,stream>>>(
                xp,sp,bp,op,D,spatial,C,total,rows);
    }
    C10_HIP_CHECK(hipGetLastError());
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "fast_packed_gn_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "groupnorm", groups: int = 2, eps: float = 1e-5):
        super().__init__()
        assert variant in ("groupnorm", "groupnorm_swish")
        assert int(groups) >= 1
        assert eps > 0
        self.variant = variant
        self.groups = int(groups)
        self.eps = float(eps)

    def forward(self, x, scale, bias):
        n, c, h, w = x.shape
        assert 1 <= self.groups <= c and c % self.groups == 0
        return _extension().run(
            x, scale, bias, self.groups, self.eps,
            self.variant == "groupnorm_swish",
        )
