import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_EXTENSION = None


CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_forward(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor cu_q,
    torch::Tensor cu_k,
    torch::Tensor causal,
    double scale);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &pyramid_forward, "Varlen attention forward");
}
"""


CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/ATen.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>

template <typename scalar_t>
__device__ __forceinline__ float load_as_float(const scalar_t* p) {
    return static_cast<float>(*p);
}

template <typename scalar_t>
__device__ __forceinline__ scalar_t store_from_float(float x) {
    return static_cast<scalar_t>(x);
}

template <typename scalar_t>
__global__ void varlen_attention_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k,
    const scalar_t* __restrict__ v,
    scalar_t* __restrict__ out,
    const int32_t* __restrict__ cu_q,
    const int32_t* __restrict__ cu_k,
    const int32_t* __restrict__ causal_ptr,
    int32_t num_seqs,
    int32_t num_q_heads,
    int32_t num_kv_heads,
    int32_t head_dim,
    float scale)
{
    int64_t linear = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    int64_t total_q = static_cast<int64_t>(cu_q[num_seqs]);
    int64_t total_work = total_q * num_q_heads * head_dim;
    if (linear >= total_work) {
        return;
    }

    int32_t d = static_cast<int32_t>(linear % head_dim);
    int64_t tmp = linear / head_dim;
    int32_t hq = static_cast<int32_t>(tmp % num_q_heads);
    int32_t iq_global = static_cast<int32_t>(tmp / num_q_heads);

    int32_t seq = 0;
    while (seq + 1 < num_seqs && iq_global >= cu_q[seq + 1]) {
        ++seq;
    }

    int32_t q_start = cu_q[seq];
    int32_t q_end = cu_q[seq + 1];
    int32_t k_start = cu_k[seq];
    int32_t k_end = cu_k[seq + 1];

    int32_t lq = q_end - q_start;
    int32_t lk = k_end - k_start;
    int32_t iq = iq_global - q_start;

    int32_t group = num_q_heads / num_kv_heads;
    int32_t hk = hq / group;
    int32_t causal = *causal_ptr;

    int32_t max_j = lk;
    if (causal) {
        max_j = iq + (lk - lq) + 1;
        if (max_j > lk) {
            max_j = lk;
        }
    }

    const int64_t q_base =
        (static_cast<int64_t>(iq_global) * num_q_heads + hq) * head_dim;

    float max_score = -CUDART_INF_F;

    for (int32_t j = 0; j < max_j; ++j) {
        int64_t k_base =
            (static_cast<int64_t>(k_start + j) * num_kv_heads + hk) * head_dim;

        float dot = 0.0f;
        for (int32_t x = 0; x < head_dim; ++x) {
            dot += load_as_float(q + q_base + x) *
                   load_as_float(k + k_base + x);
        }

        float score = dot * scale;
        if (score > max_score) {
            max_score = score;
        }
    }

    float denom = 0.0f;
    for (int32_t j = 0; j < max_j; ++j) {
        int64_t k_base =
            (static_cast<int64_t>(k_start + j) * num_kv_heads + hk) * head_dim;

        float dot = 0.0f;
        for (int32_t x = 0; x < head_dim; ++x) {
            dot += load_as_float(q + q_base + x) *
                   load_as_float(k + k_base + x);
        }

        denom += expf(dot * scale - max_score);
    }

    float result = 0.0f;
    for (int32_t j = 0; j < max_j; ++j) {
        int64_t k_base =
            (static_cast<int64_t>(k_start + j) * num_kv_heads + hk) * head_dim;
        int64_t v_base = k_base;

        float dot = 0.0f;
        for (int32_t x = 0; x < head_dim; ++x) {
            dot += load_as_float(q + q_base + x) *
                   load_as_float(k + k_base + x);
        }

        float prob = expf(dot * scale - max_score) / denom;
        result += prob * load_as_float(v + v_base + d);
    }

    out[linear] = store_from_float<scalar_t>(result);
}


torch::Tensor pyramid_forward(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor cu_q,
    torch::Tensor cu_k,
    torch::Tensor causal,
    double scale)
{
    TORCH_CHECK(q.is_cuda(), "q must be on a CUDA/HIP device");
    TORCH_CHECK(k.is_cuda(), "k must be on a CUDA/HIP device");
    TORCH_CHECK(v.is_cuda(), "v must be on a CUDA/HIP device");
    TORCH_CHECK(cu_q.is_cuda(), "cu_q must be on a CUDA/HIP device");
    TORCH_CHECK(cu_k.is_cuda(), "cu_k must be on a CUDA/HIP device");
    TORCH_CHECK(causal.is_cuda(), "causal must be on a CUDA/HIP device");

    TORCH_CHECK(q.dim() == 3, "q must be rank 3");
    TORCH_CHECK(k.dim() == 3, "k must be rank 3");
    TORCH_CHECK(v.dim() == 3, "v must be rank 3");
    TORCH_CHECK(q.scalar_type() == k.scalar_type(), "q and k dtype mismatch");
    TORCH_CHECK(q.scalar_type() == v.scalar_type(), "q and v dtype mismatch");
    TORCH_CHECK(q.size(2) == k.size(2), "head dimension mismatch");
    TORCH_CHECK(q.size(2) == v.size(2), "head dimension mismatch");

    auto out = torch::empty_like(q);

    int32_t num_seqs = static_cast<int32_t>(cu_q.numel() - 1);
    int32_t num_q_heads = static_cast<int32_t>(q.size(1));
    int32_t num_kv_heads = static_cast<int32_t>(k.size(1));
    int32_t head_dim = static_cast<int32_t>(q.size(2));
    int64_t total_work = q.size(0) * q.size(1) * q.size(2);

    constexpr int threads = 256;
    int blocks = static_cast<int>((total_work + threads - 1) / threads);

    auto stream = at::cuda::getDefaultCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        q.scalar_type(),
        "varlen_attention_kernel",
        [&] {
            hipLaunchKernelGGL(
                (varlen_attention_kernel<scalar_t>),
                dim3(blocks),
                dim3(threads),
                0,
                stream.stream(),
                q.data_ptr<scalar_t>(),
                k.data_ptr<scalar_t>(),
                v.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(),
                cu_q.data_ptr<int32_t>(),
                cu_k.data_ptr<int32_t>(),
                causal.data_ptr<int32_t>(),
                num_seqs,
                num_q_heads,
                num_kv_heads,
                head_dim,
                static_cast<float>(scale));
        });

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""


def _extension_name():
    digest = hashlib.sha1(
        (CUDA_CPP_SRC + CUDA_CU_SRC).encode("utf-8")
    ).hexdigest()[:16]
    return "varlen_attention_hip_" + digest


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        _EXTENSION = load_inline(
            name=_extension_name(),
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            with_cuda=True,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = (
            float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v, cu_seqlens_q, cu_seqlens_k, causal):
        if q.device.type != "cuda":
            raise RuntimeError("q must be on a CUDA/HIP device")

        if q.shape[1] % k.shape[1] != 0:
            raise AssertionError(
                "num_q_heads must be an integer multiple of num_kv_heads"
            )

        cu_q = cu_seqlens_q.to(device=q.device, dtype=torch.int32).contiguous()
        cu_k = cu_seqlens_k.to(device=q.device, dtype=torch.int32).contiguous()

        if not torch.is_tensor(causal):
            causal = torch.tensor(
                int(causal), device=q.device, dtype=torch.int32
            )
        else:
            causal = causal.to(device=q.device, dtype=torch.int32)
        causal = causal.contiguous()

        q_work = q.contiguous()
        k_work = k.contiguous()
        v_work = v.contiguous()

        return _get_extension().forward(
            q_work,
            k_work,
            v_work,
            cu_q,
            cu_k,
            causal,
            self.sm_scale,
        )
