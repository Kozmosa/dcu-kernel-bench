import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor swiglu_fused(torch::Tensor base, torch::Tensor delta,
                          torch::Tensor grad_out);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &swiglu_fused);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template <typename T>
__global__ void fused_kernel(const T* __restrict__ base,
                             const T* __restrict__ delta,
                             const T* __restrict__ grad,
                             T* __restrict__ out,
                             int64_t n, int64_t d) {
    const int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x
                    + threadIdx.x;
    if (i >= n) return;
    const int64_t row = i / d;
    const int64_t b = i + row * d;
    const int64_t o = i + row * (2 * d);

    const float gate = float(base[b]) + float(delta[b]);
    const float up = float(base[b + d]) + float(delta[b + d]);
    const float g = float(grad[i]);
    const float sig = 1.0f / (1.0f + expf(-gate));
    const float silu = gate * sig;
    const float deriv = sig + silu * (1.0f - sig);
    out[o] = T(silu * up);
    out[o + d] = T((g * up) * deriv);
    out[o + 2 * d] = T(g * silu);
}

torch::Tensor swiglu_fused(torch::Tensor base, torch::Tensor delta,
                          torch::Tensor grad_out) {
    TORCH_CHECK(base.is_cuda() && delta.is_cuda() && grad_out.is_cuda(),
                "Inputs must be device tensors");
    TORCH_CHECK(base.dim() == 2 && base.size(1) > 0 &&
                base.size(1) % 2 == 0, "Invalid base shape");
    TORCH_CHECK(delta.sizes() == base.sizes(), "Invalid delta shape");
    TORCH_CHECK(grad_out.dim() == 2 &&
                grad_out.size(0) == base.size(0) &&
                grad_out.size(1) == base.size(1) / 2,
                "Invalid grad_out shape");
    TORCH_CHECK(base.scalar_type() == delta.scalar_type() &&
                base.scalar_type() == grad_out.scalar_type(),
                "Input dtypes must match");
    TORCH_CHECK(base.device() == delta.device() &&
                base.device() == grad_out.device(), "Input devices must match");

    const c10::cuda::CUDAGuard guard(base.device());
    auto a = base.contiguous();
    auto b = delta.contiguous();
    auto g = grad_out.contiguous();
    const int64_t d = base.size(1) / 2;
    const int64_t n = base.size(0) * d;
    auto out = torch::empty({base.size(0), 3 * d}, base.options());
    if (!n) return out;

    const auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,
                                    at::ScalarType::BFloat16,
                                    base.scalar_type(), "fused_swiglu", [&] {
        fused_kernel<scalar_t><<<(n + 255) / 256, 256, 0, stream>>>(
            a.data_ptr<scalar_t>(), b.data_ptr<scalar_t>(),
            g.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), n, d);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "add_swiglu_fb_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, base, delta, grad_out):
        return _get_extension().run(base, delta, grad_out)
