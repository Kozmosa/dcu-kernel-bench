import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_run(
    torch::Tensor x,
    torch::Tensor w,
    torch::Tensor xs,
    torch::Tensor ws,
    torch::Tensor bias,
    bool use_bias,
    bool use_bfloat16);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &pyramid_run, "Quantized transposed GEMM");
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/AccumulateType.h>
#include <hip/hip_runtime.h>

template <typename out_t>
__global__ void pyramid_kernel(
    const int8_t* __restrict__ x,
    const int8_t* __restrict__ w,
    const float* __restrict__ xs,
    const float* __restrict__ ws,
    const out_t* __restrict__ bias,
    out_t* __restrict__ out,
    int64_t B,
    int64_t M,
    int64_t N,
    int64_t K,
    bool use_bias)
{
    int64_t linear = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    int64_t total = B * M * N;
    if (linear >= total) {
        return;
    }

    int64_t n = linear % N;
    int64_t t = linear / N;
    int64_t m = t % M;
    int64_t b = t / M;

    int64_t xbase = (b * M + m) * K;
    int64_t wbase = (b * N + n) * K;

    float acc = 0.0f;
    for (int64_t k = 0; k < K; ++k) {
        acc = fmaf(
            static_cast<float>(x[xbase + k]),
            static_cast<float>(w[wbase + k]),
            acc);
    }

    acc *= xs[b * M + m];
    acc *= ws[b * N + n];

    out_t q = static_cast<out_t>(acc);
    if (use_bias) {
        float qf = static_cast<float>(q);
        float bf = static_cast<float>(bias[b * N + n]);
        q = static_cast<out_t>(qf + bf);
    }
    out[linear] = q;
}

torch::Tensor pyramid_run(
    torch::Tensor x,
    torch::Tensor w,
    torch::Tensor xs,
    torch::Tensor ws,
    torch::Tensor bias,
    bool use_bias,
    bool use_bfloat16)
{
    TORCH_CHECK(x.is_cuda(), "x must be on accelerator");
    TORCH_CHECK(w.is_cuda(), "w must be on accelerator");
    TORCH_CHECK(xs.is_cuda(), "xs must be on accelerator");
    TORCH_CHECK(ws.is_cuda(), "ws must be on accelerator");

    const auto B = x.size(0);
    const auto M = x.size(1);
    const auto K = x.size(2);
    const auto N = w.size(1);

    TORCH_CHECK(w.size(0) == B, "batch dimensions must match");
    TORCH_CHECK(w.size(2) == K, "K dimensions must match");

    auto dtype = use_bfloat16 ? torch::kBFloat16 : torch::kFloat16;
    auto out = torch::empty(
        {B, M, N},
        x.options().dtype(dtype));

    constexpr int threads = 256;
    int64_t total = B * M * N;
    dim3 block(threads);
    dim3 grid(static_cast<unsigned int>((total + threads - 1) / threads));

    if (use_bfloat16) {
        const auto* bp = use_bias
            ? bias.data_ptr<at::BFloat16>()
            : static_cast<const at::BFloat16*>(nullptr);

        hipLaunchKernelGGL(
            (pyramid_kernel<at::BFloat16>),
            grid,
            block,
            0,
            0,
            x.data_ptr<int8_t>(),
            w.data_ptr<int8_t>(),
            xs.data_ptr<float>(),
            ws.data_ptr<float>(),
            bp,
            out.data_ptr<at::BFloat16>(),
            B, M, N, K,
            use_bias);
    } else {
        const auto* bp = use_bias
            ? bias.data_ptr<at::Half>()
            : static_cast<const at::Half*>(nullptr);

        hipLaunchKernelGGL(
            (pyramid_kernel<at::Half>),
            grid,
            block,
            0,
            0,
            x.data_ptr<int8_t>(),
            w.data_ptr<int8_t>(),
            xs.data_ptr<float>(),
            ws.data_ptr<float>(),
            bp,
            out.data_ptr<at::Half>(),
            B, M, N, K,
            use_bias);
    }

    auto err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "pyramid kernel launch failed: ", hipGetErrorString(err));
    return out;
}
"""

def _get_extension():
    global _EXT
    if _EXT is None:
        _EXT = load_inline(
            name="pyramidkernel_hip_gfx936_int8_gemm",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        self._use_bfloat16 = self.out_dtype == torch.bfloat16

    def forward(self, xq, wq, x_scale, w_scale, bias):
        xq = xq.to(torch.int8).contiguous()
        wq = wq.to(torch.int8).contiguous()
        x_scale = x_scale.to(torch.float32).contiguous()
        w_scale = w_scale.to(torch.float32).contiguous()

        if self.use_bias:
            bias = bias.to(self.out_dtype).contiguous()
        else:
            bias = bias.contiguous()

        return _get_extension().run(
            xq,
            wq,
            x_scale,
            w_scale,
            bias,
            self.use_bias,
            self._use_bfloat16,
        )
