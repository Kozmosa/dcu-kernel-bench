import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor schedule(torch::Tensor x, int64_t experts, int64_t block_size);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("schedule", &schedule);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

constexpr int THREADS = 256;
constexpr int CHUNK = 2048;

template<class T>
__global__ void count_chunks(const T* __restrict__ x, int* __restrict__ counts,
                             int n, int chunks) {
    int e = blockIdx.y;
    int c = blockIdx.x;
    int t = threadIdx.x;
    int sum = 0;
    for (int i = c * CHUNK + t; i < n && i < (c + 1) * CHUNK; i += THREADS)
        sum += (int(x[i]) == e);
    __shared__ int partial[THREADS];
    partial[t] = sum;
    __syncthreads();
    for (int d = THREADS / 2; d; d >>= 1) {
        if (t < d) partial[t] += partial[t + d];
        __syncthreads();
    }
    if (!t) counts[e * chunks + c] = partial[0];
}

__global__ void prefix_chunks(int* counts, int* totals, int chunks, int experts) {
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= experts) return;
    int sum = 0;
    for (int c = 0; c < chunks; ++c) {
        int v = counts[e * chunks + c];
        counts[e * chunks + c] = sum;
        sum += v;
    }
    totals[e] = sum;
}

__global__ void initialize(float* out, const int* totals, int* starts,
                           int n, int ecount, int b, int l1, int l2) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int stride = gridDim.x * blockDim.x;
    for (int p = i; p < l1 + l2; p += stride)
        out[p] = p < l1 ? float(n) : -1.0f;
    if (i == 0) {
        int s = 0;
        for (int e = 0; e < ecount; ++e) {
            starts[e] = s;
            s += ((totals[e] + b - 1) / b) * b;
        }
        starts[ecount] = s;
        out[l1 + l2] = float(s);
    }
}

template<class T>
__global__ void scatter_chunks(const T* __restrict__ x,
                               const int* __restrict__ counts,
                               const int* __restrict__ starts,
                               float* __restrict__ out,
                               int n, int chunks, int b, int l1) {
    const int e = blockIdx.y;
    const int c = blockIdx.x;
    const int t = threadIdx.x;
    const int lane = t % warpSize;
    const int wave = t / warpSize;
    const int waves = THREADS / warpSize;
    __shared__ int wave_counts[8];
    __shared__ int carry;
    if (!t) carry = starts[e] + counts[e * chunks + c];
    __syncthreads();

    for (int base = c * CHUNK; base < n && base < (c + 1) * CHUNK;
         base += THREADS) {
        int i = base + t;
        bool match = i < n && int(x[i]) == e;
        unsigned long long mask = __ballot(match);
        unsigned long long lower = lane == 0 ? 0ULL : ((1ULL << lane) - 1ULL);
        int rank = __popcll(mask & lower);
        if (lane == 0) wave_counts[wave] = __popcll(mask);
        __syncthreads();
        int prior = 0;
        for (int w = 0; w < wave; ++w) prior += wave_counts[w];
        if (match) out[carry + prior + rank] = float(i);
        __syncthreads();
        if (!t) {
            int total = 0;
            for (int w = 0; w < waves; ++w) total += wave_counts[w];
            carry += total;
        }
        __syncthreads();
    }
    if (c == 0) {
        int begin = starts[e] / b;
        int end = starts[e + 1] / b;
        for (int p = begin + t; p < end; p += THREADS)
            out[l1 + p] = float(e);
    }
}

torch::Tensor schedule(torch::Tensor x, int64_t experts, int64_t block_size) {
    TORCH_CHECK(x.is_cuda(), "Expected a device tensor");
    TORCH_CHECK(x.is_contiguous(), "Expected contiguous input");
    TORCH_CHECK(x.scalar_type() == at::kFloat ||
                x.scalar_type() == at::kInt ||
                x.scalar_type() == at::kLong,
                "Expected float32, int32, or int64");
    c10::cuda::CUDAGuard guard(x.device());
    int n = x.numel();
    int e = experts;
    int b = block_size;
    int chunks = (n + CHUNK - 1) / CHUNK;
    int l1 = n + e * (b - 1);
    int l2 = (l1 + b - 1) / b;
    auto out = torch::empty({int64_t(l1) + l2 + 1},
                            x.options().dtype(at::kFloat));
    auto counts = torch::empty({int64_t(e) * chunks},
                               x.options().dtype(at::kInt));
    auto totals = torch::empty({e}, x.options().dtype(at::kInt));
    auto starts = torch::empty({e + 1}, x.options().dtype(at::kInt));
    auto stream = at::cuda::getCurrentCUDAStream();
    dim3 grid(chunks, e);

    #define COUNT(T) count_chunks<T><<<grid, THREADS, 0, stream>>>( \
        x.data_ptr<T>(), counts.data_ptr<int>(), n, chunks)
    if (x.scalar_type() == at::kFloat) { COUNT(float); }
    else if (x.scalar_type() == at::kInt) { COUNT(int); }
    else { COUNT(int64_t); }
    #undef COUNT

    prefix_chunks<<<(e + 255) / 256, 256, 0, stream>>>(
        counts.data_ptr<int>(), totals.data_ptr<int>(), chunks, e);
    int init_grid = (l1 + l2 + 255) / 256;
    if (init_grid > 4096) init_grid = 4096;
    initialize<<<init_grid, 256, 0, stream>>>(
        out.data_ptr<float>(), totals.data_ptr<int>(), starts.data_ptr<int>(),
        n, e, b, l1, l2);

    #define SCATTER(T) scatter_chunks<T><<<grid, THREADS, 0, stream>>>( \
        x.data_ptr<T>(), counts.data_ptr<int>(), starts.data_ptr<int>(), \
        out.data_ptr<float>(), n, chunks, b, l1)
    if (x.scalar_type() == at::kFloat) { SCATTER(float); }
    else if (x.scalar_type() == at::kInt) { SCATTER(int); }
    else { SCATTER(int64_t); }
    #undef SCATTER
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "stable_expert_layout_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, num_experts: int, block_size: int):
        super().__init__()
        self.num_experts = int(num_experts)
        self.block_size = int(block_size)

    def forward(self, topk_ids):
        return _get_extension().schedule(
            topk_ids, self.num_experts, self.block_size
        )
