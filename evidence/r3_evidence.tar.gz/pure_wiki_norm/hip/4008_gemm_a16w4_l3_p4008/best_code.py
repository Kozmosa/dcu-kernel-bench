import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor awq_forward(torch::Tensor a, torch::Tensor w,
                          torch::Tensor s, torch::Tensor z);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &awq_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>

template<class T, class S>
__global__ void tiled_awq(const T* __restrict__ a,
                         const unsigned char* __restrict__ w,
                         const S* __restrict__ s,
                         const unsigned char* __restrict__ z,
                         T* __restrict__ out,
                         int M, int N, int K, int G) {
    __shared__ float aa[16][32];
    __shared__ float bb[32][64];
    int t = threadIdx.x;
    int col = t & 63;
    int row = t >> 6;
    int mb = blockIdx.y * 16;
    int nb = blockIdx.x * 64;
    float c0=0, c1=0, c2=0, c3=0;
    for (int kb=0; kb<K; kb+=32) {
        for (int i=t; i<512; i+=256) {
            int r=i/32, k=i%32;
            aa[r][k] = mb+r<M && kb+k<K ?
                float(a[(int64_t)(mb+r)*K+kb+k]) : 0.0f;
        }
        // Adjacent threads read consecutive packed weight bytes.
        for (int i=t; i<2048; i+=256) {
            int n=nb+i/32, k=kb+i%32;
            float v=0;
            if (n<N && k<K) {
                int g=k/G;
                int q=(w[(int64_t)n*(K/2)+k/2] >> ((k&1)*4))&15;
                int zz=(z[(int64_t)g*(N/2)+n/2] >> ((n&1)*4))&15;
                v=float(q-zz)*float(s[(int64_t)g*N+n]);
            }
            bb[i%32][i/32]=v;
        }
        __syncthreads();
        #pragma unroll
        for (int k=0; k<32; ++k) {
            float b=bb[k][col];
            c0=fmaf(aa[row][k],b,c0);
            c1=fmaf(aa[row+4][k],b,c1);
            c2=fmaf(aa[row+8][k],b,c2);
            c3=fmaf(aa[row+12][k],b,c3);
        }
        __syncthreads();
    }
    int n=nb+col, m=mb+row;
    if(n<N) {
        if(m<M) out[(int64_t)m*N+n]=T(c0);
        if(m+4<M) out[(int64_t)(m+4)*N+n]=T(c1);
        if(m+8<M) out[(int64_t)(m+8)*N+n]=T(c2);
        if(m+12<M) out[(int64_t)(m+12)*N+n]=T(c3);
    }
}

template<class T, class S>
__global__ void small_awq(const T* __restrict__ a,
                         const unsigned char* __restrict__ w,
                         const S* __restrict__ s,
                         const unsigned char* __restrict__ z,
                         T* __restrict__ out,
                         int M, int N, int K, int G) {
    int lane=threadIdx.x&63;
    int n=blockIdx.x*4+(threadIdx.x>>6);
    int m=blockIdx.y;
    float acc=0;
    if(n<N) {
        for(int k=lane; k<K; k+=64) {
            int g=k/G;
            int q=(w[(int64_t)n*(K/2)+k/2]>>((k&1)*4))&15;
            int zz=(z[(int64_t)g*(N/2)+n/2]>>((n&1)*4))&15;
            float b=float(q-zz)*float(s[(int64_t)g*N+n]);
            acc=fmaf(float(a[(int64_t)m*K+k]),b,acc);
        }
    }
    #pragma unroll
    for(int d=32; d>0; d>>=1)
        acc+=__shfl_down(acc,d,64);
    if(lane==0 && n<N) out[(int64_t)m*N+n]=T(acc);
}

template<class T, class S>
void launch(torch::Tensor a, torch::Tensor w, torch::Tensor s,
            torch::Tensor z, torch::Tensor out, hipStream_t stream) {
    int M=a.size(0), K=a.size(1), N=w.size(0), G=K/z.size(0);
    if(M==0 || N==0) return;
    const auto* wp=reinterpret_cast<const unsigned char*>(w.data_ptr());
    const auto* zp=reinterpret_cast<const unsigned char*>(z.data_ptr());
    if(M<=4) {
        small_awq<T,S><<<dim3((N+3)/4,M),256,0,stream>>>(
            a.data_ptr<T>(),wp,s.data_ptr<S>(),zp,out.data_ptr<T>(),M,N,K,G);
    } else {
        tiled_awq<T,S><<<dim3((N+63)/64,(M+15)/16),256,0,stream>>>(
            a.data_ptr<T>(),wp,s.data_ptr<S>(),zp,out.data_ptr<T>(),M,N,K,G);
    }
}

torch::Tensor awq_forward(torch::Tensor a, torch::Tensor w,
                          torch::Tensor s, torch::Tensor z) {
    c10::cuda::CUDAGuard guard(a.device());
    TORCH_CHECK(a.is_contiguous() && w.is_contiguous() &&
                s.is_contiguous() && z.is_contiguous(), "Contiguous tensors required");
    TORCH_CHECK(w.scalar_type()==torch::kInt8 && z.scalar_type()==torch::kInt8,
                "Packed weights and zeros must be int8");
    auto out=torch::empty({a.size(0),w.size(0)},a.options());
    auto stream=at::cuda::getCurrentCUDAStream();
    if(a.scalar_type()==torch::kFloat32) {
        if(s.scalar_type()==torch::kFloat32)
            launch<float,float>(a,w,s,z,out,stream);
        else
            launch<float,at::Half>(a,w,s,z,out,stream);
    } else {
        TORCH_CHECK(a.scalar_type()==torch::kFloat16,"Expected fp16 or fp32");
        if(s.scalar_type()==torch::kFloat32)
            launch<at::Half,float>(a,w,s,z,out,stream);
        else
            launch<at::Half,at::Half>(a,w,s,z,out,stream);
    }
    auto error=hipGetLastError();
    TORCH_CHECK(error==hipSuccess,hipGetErrorString(error));
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "awq_tiled_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int, group_size: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.group_size = group_size

    def forward(self, input, qweight, scales, qzeros):
        return _get_extension().forward(input, qweight, scales, qzeros)
