import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor pyramid_topk(torch::Tensor x, int64_t k);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &pyramid_topk);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/hip/HIPException.h>
#include <algorithm>
#include <climits>

struct Item {
    float v;
    int i;
};

__device__ __forceinline__ Item padding() {
    return Item{-INFINITY, INT_MAX};
}

__device__ __forceinline__ bool before(Item a, Item b) {
    return a.v > b.v || (a.v == b.v && a.i < b.i);
}

template<int N>
__global__ void local_sort(const float* __restrict__ x,
                           Item* __restrict__ out,
                           int m, int chunks, int keep) {
    __shared__ Item data[N];
    int chunk = blockIdx.x % chunks;
    int row = blockIdx.x / chunks;
    int t = threadIdx.x;
    for (int p = t; p < N; p += blockDim.x) {
        int col = chunk * N + p;
        data[p] = col < m ? Item{x[(int64_t)row * m + col], col}
                         : Item{-INFINITY, col};
    }
    __syncthreads();
    for (int width = 2; width <= N; width <<= 1) {
        for (int stride = width >> 1; stride; stride >>= 1) {
            for (int p = t; p < N; p += blockDim.x) {
                int q = p ^ stride;
                if (q > p) {
                    Item a = data[p], b = data[q];
                    bool descending = (p & width) == 0;
                    if (descending ? before(b, a) : before(a, b)) {
                        data[p] = b;
                        data[q] = a;
                    }
                }
            }
            __syncthreads();
        }
    }
    int64_t base = (int64_t)blockIdx.x * keep;
    for (int p = t; p < keep; p += blockDim.x)
        out[base + p] = data[p];
}

__global__ void merge_lists(const Item* __restrict__ src,
                            Item* __restrict__ dst,
                            int rows, int old_count, int old_len,
                            int new_count, int new_len) {
    int64_t tid = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    int64_t total = (int64_t)rows * new_count * new_len;
    if (tid >= total) return;
    int rank = tid % new_len;
    int64_t list = tid / new_len;
    int pair = list % new_count;
    int row = list / new_count;
    const Item* a = src + ((int64_t)row * old_count + 2 * pair) * old_len;
    if (2 * pair + 1 >= old_count) {
        dst[tid] = rank < old_len ? a[rank] : padding();
        return;
    }
    const Item* b = a + old_len;
    int lo = max(0, rank - old_len);
    int hi = min(rank, old_len);
    while (lo <= hi) {
        int i = (lo + hi) >> 1;
        int j = rank - i;
        if (i > 0 && j < old_len && before(b[j], a[i - 1])) {
            hi = i - 1;
        } else if (j > 0 && i < old_len && !before(b[j - 1], a[i])) {
            lo = i + 1;
        } else {
            Item av = i < old_len ? a[i] : padding();
            Item bv = j < old_len ? b[j] : padding();
            dst[tid] = before(bv, av) ? bv : av;
            return;
        }
    }
    dst[tid] = padding();
}

__global__ void pack_result(const Item* __restrict__ src,
                            float* __restrict__ out, int rows, int k) {
    int64_t p = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= (int64_t)rows * k) return;
    int row = p / k;
    int col = p % k;
    Item a = src[p];
    out[(int64_t)row * (2 * k) + col] = a.v;
    out[(int64_t)row * (2 * k) + k + col] = (float)a.i;
}

torch::Tensor pyramid_topk(torch::Tensor x, int64_t k64) {
    TORCH_CHECK(x.is_cuda() && x.scalar_type() == torch::kFloat32,
                "Expected a device float32 tensor");
    TORCH_CHECK(x.dim() == 2 && x.is_contiguous(),
                "Expected a contiguous matrix");
    int rows = x.size(0), m = x.size(1), k = k64;
    TORCH_CHECK(k64 >= 1 && k64 <= m, "Invalid k");
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    auto out = torch::empty({rows, 2 * k}, x.options());
    if (rows == 0) return out;
    int tile = m <= 64 ? 64 : (m <= 256 ? 256 : 1024);
    int count = (m + tile - 1) / tile;
    int len = std::min(k, tile);
    auto opts = x.options().dtype(torch::kInt64);
    auto cur = torch::empty({(int64_t)rows * count * len}, opts);
    int blocks = rows * count;
    Item* ptr = reinterpret_cast<Item*>(cur.data_ptr<int64_t>());
    if (tile == 64)
        local_sort<64><<<blocks, 64, 0, stream>>>(
            x.data_ptr<float>(), ptr, m, count, len);
    else if (tile == 256)
        local_sort<256><<<blocks, 256, 0, stream>>>(
            x.data_ptr<float>(), ptr, m, count, len);
    else
        local_sort<1024><<<blocks, 256, 0, stream>>>(
            x.data_ptr<float>(), ptr, m, count, len);
    while (count > 1) {
        int next_count = (count + 1) / 2;
        int next_len = std::min(k, 2 * len);
        int64_t total = (int64_t)rows * next_count * next_len;
        auto next = torch::empty({total}, opts);
        merge_lists<<<(total + 255) / 256, 256, 0, stream>>>(
            reinterpret_cast<const Item*>(cur.data_ptr<int64_t>()),
            reinterpret_cast<Item*>(next.data_ptr<int64_t>()),
            rows, count, len, next_count, next_len);
        cur = next;
        count = next_count;
        len = next_len;
    }
    int64_t total = (int64_t)rows * k;
    pack_result<<<(total + 255) / 256, 256, 0, stream>>>(
        reinterpret_cast<const Item*>(cur.data_ptr<int64_t>()),
        out.data_ptr<float>(), rows, k);
    C10_HIP_CHECK(hipGetLastError());
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="pyramid_select_" + digest,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, k: int = 8):
        super().__init__()
        assert k >= 1, "k must be >= 1"
        self.k = int(k)

    def forward(self, x):
        return _get_extension().run(x, self.k)
