import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor fused_forward(torch::Tensor x, torch::Tensor w,
                            torch::Tensor b, torch::Tensor s, int variant);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &fused_forward);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>

template<int ACT>
__global__ __launch_bounds__(256)
void implicit_conv(const float* __restrict__ x,
                   const float* __restrict__ w,
                   const float* __restrict__ bias,
                   const float* __restrict__ slope,
                   float* __restrict__ out,
                   int C, int H, int W, int K, int R, int S,
                   int OH, int OW) {
    __shared__ float aa[32][17];
    __shared__ float bb[16][65];

    const int tid = threadIdx.x;
    const int px = tid & 31;
    const int ky = tid >> 5;
    const int spatial = OH * OW;
    const int pbase = blockIdx.x * 64;
    const int kbase = blockIdx.y * 32;
    const int batch = blockIdx.z;
    const int reduction = C * R * S;
    const int RS = R * S;
    float acc[4][2] = {};

    for (int base = 0; base < reduction; base += 16) {
        #pragma unroll
        for (int j = 0; j < 2; ++j) {
            int t = tid + j * 256;
            int row = t >> 4;
            int q = t & 15;
            int k = kbase + row;
            aa[row][q] = (k < K && base + q < reduction)
                ? w[(int64_t)k * reduction + base + q] : 0.0f;
        }

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            int t = tid + j * 256;
            int q = t >> 6;
            int col = t & 63;
            int p = pbase + col;
            int rr = base + q;
            float v = 0.0f;
            if (p < spatial && rr < reduction) {
                int c = rr / RS;
                int uv = rr - c * RS;
                int u = uv / S;
                int vcol = uv - u * S;
                int ih = p / OW + u - 1;
                int iw = p % OW + vcol - 1;
                if ((unsigned)ih < (unsigned)H &&
                    (unsigned)iw < (unsigned)W) {
                    v = x[((int64_t)batch * C + c) * H * W
                          + ih * W + iw];
                }
            }
            bb[q][col] = v;
        }
        __syncthreads();

        #pragma unroll
        for (int q = 0; q < 16; ++q) {
            float b0 = bb[q][px];
            float b1 = bb[q][px + 32];
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                float a = aa[ky + i * 8][q];
                acc[i][0] = fmaf(a, b0, acc[i][0]);
                acc[i][1] = fmaf(a, b1, acc[i][1]);
            }
        }
        __syncthreads();
    }

    float sl = 0.0f;
    if (ACT == 2) sl = slope[0];
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        int k = kbase + ky + i * 8;
        if (k < K) {
            float b = bias[k];
            #pragma unroll
            for (int j = 0; j < 2; ++j) {
                int p = pbase + px + j * 32;
                if (p < spatial) {
                    float z = acc[i][j] + b;
                    if (ACT == 0) z = fmaxf(z, 0.0f);
                    if (ACT == 1) z = z / (1.0f + expf(-z));
                    if (ACT == 2) z = z > 0.0f ? z : sl * z;
                    out[((int64_t)batch * K + k) * spatial + p] = z;
                }
            }
        }
    }
}

torch::Tensor fused_forward(torch::Tensor x, torch::Tensor w,
                            torch::Tensor b, torch::Tensor s, int variant) {
    c10::cuda::CUDAGuard guard(x.device());
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 &&
                w.scalar_type() == torch::kFloat32 &&
                b.scalar_type() == torch::kFloat32 &&
                s.scalar_type() == torch::kFloat32, "Expected float32 inputs");
    int N = x.size(0), C = x.size(1), H = x.size(2), W = x.size(3);
    int K = w.size(0), R = w.size(2), S = w.size(3);
    int OH = H - R + 3, OW = W - S + 3;
    TORCH_CHECK(OH > 0 && OW > 0, "Invalid output dimensions");
    auto out = torch::empty({N, K, OH, OW}, x.options());
    dim3 grid((OH * OW + 63) / 64, (K + 31) / 32, N);
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    #define LAUNCH(A) \
        hipLaunchKernelGGL(implicit_conv<A>, grid, dim3(256), 0, stream, \
            x.data_ptr<float>(), w.data_ptr<float>(), b.data_ptr<float>(), \
            s.data_ptr<float>(), out.data_ptr<float>(), C,H,W,K,R,S,OH,OW)
    if (variant == 0) { LAUNCH(0); }
    else if (variant == 1) { LAUNCH(1); }
    else { LAUNCH(2); }
    #undef LAUNCH
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="fused_implicit_conv_" + digest,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)

    def __init__(self, variant: str = "relu"):
        super().__init__()
        assert variant in ("relu", "swish", "prelu"), \
            "variant must be one of relu / swish / prelu"
        self.variant = variant

    def forward(self, x, weight, bias, slope):
        return _get_extension().forward(
            x, weight, bias, slope,
            {"relu": 0, "swish": 1, "prelu": 2}[self.variant],
        )
