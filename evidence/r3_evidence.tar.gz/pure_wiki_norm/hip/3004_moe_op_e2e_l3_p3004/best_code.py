import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor moe_forward(torch::Tensor a, torch::Tensor w1,
                          torch::Tensor w2, torch::Tensor weights,
                          torch::Tensor ids);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &moe_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

template<class T>
__device__ __forceinline__ float read_float(const T* p) {
    return static_cast<float>(*p);
}

__device__ __forceinline__ int read_id(const void* p, int type, int64_t i) {
    if (type == 0) return static_cast<int>(static_cast<const int64_t*>(p)[i]);
    if (type == 1) return static_cast<const int32_t*>(p)[i];
    if (type == 2) return static_cast<int>(static_cast<const float*>(p)[i]);
    return static_cast<int>(static_cast<float>(
        static_cast<const at::BFloat16*>(p)[i]));
}

__device__ __forceinline__ float sum_wave(float v) {
    #pragma unroll
    for (int offset = 32; offset; offset >>= 1)
        v += __shfl_down(v, offset, 64);
    return v;
}

template<class T>
__global__ void first_layer(
    const T* __restrict__ a, const T* __restrict__ w,
    const void* __restrict__ ids, float* __restrict__ hidden,
    int K, int H, int topk, int id_type)
{
    const int lane = threadIdx.x & 63;
    const int n = blockIdx.x * 4 + (threadIdx.x >> 6);
    const int64_t pair = blockIdx.y;
    if (n >= H) return;
    const int e = read_id(ids, id_type, pair);
    const T* x = a + (pair / topk) * K;
    const T* gate_w = w + (static_cast<int64_t>(e) * 2 * H + n) * K;
    const T* up_w = gate_w + static_cast<int64_t>(H) * K;

    float g0 = 0.f, g1 = 0.f, u0 = 0.f, u1 = 0.f;
    for (int k = lane; k < K; k += 128) {
        float x0 = read_float(x + k);
        g0 = fmaf(x0, read_float(gate_w + k), g0);
        u0 = fmaf(x0, read_float(up_w + k), u0);
        if (k + 64 < K) {
            float x1 = read_float(x + k + 64);
            g1 = fmaf(x1, read_float(gate_w + k + 64), g1);
            u1 = fmaf(x1, read_float(up_w + k + 64), u1);
        }
    }
    float g = sum_wave(g0 + g1);
    float u = sum_wave(u0 + u1);
    if (lane == 0)
        hidden[pair * H + n] = (g * (1.f / (1.f + expf(-g)))) * u;
}

template<class T>
__global__ void second_layer(
    const float* __restrict__ hidden, const T* __restrict__ w,
    const T* __restrict__ weights, const void* __restrict__ ids,
    T* __restrict__ out, int K, int H, int id_type)
{
    const int lane = threadIdx.x & 63;
    const int k = blockIdx.x * 4 + (threadIdx.x >> 6);
    const int64_t pair = blockIdx.y;
    if (k >= K) return;
    const int e = read_id(ids, id_type, pair);
    const float* x = hidden + pair * H;
    const T* row = w + (static_cast<int64_t>(e) * K + k) * H;
    float v0 = 0.f, v1 = 0.f;
    for (int n = lane; n < H; n += 128) {
        v0 = fmaf(x[n], read_float(row + n), v0);
        if (n + 64 < H)
            v1 = fmaf(x[n + 64], read_float(row + n + 64), v1);
    }
    float v = sum_wave(v0 + v1);
    if (lane == 0)
        out[pair * K + k] = static_cast<T>(v * read_float(weights + pair));
}

torch::Tensor moe_forward(torch::Tensor a, torch::Tensor w1,
                          torch::Tensor w2, torch::Tensor weights,
                          torch::Tensor ids) {
    c10::cuda::CUDAGuard guard(a.device());
    const int64_t M = a.size(0);
    const int K = a.size(1);
    const int H = w1.size(1) / 2;
    const int topk = ids.size(1);
    const int64_t pairs = M * topk;
    auto out = torch::empty({M, topk, static_cast<int64_t>(K)}, a.options());
    auto hidden = torch::empty({pairs, static_cast<int64_t>(H)},
                               a.options().dtype(torch::kFloat32));
    if (pairs == 0) return out;

    int id_type;
    if (ids.scalar_type() == at::kLong) id_type = 0;
    else if (ids.scalar_type() == at::kInt) id_type = 1;
    else if (ids.scalar_type() == at::kFloat) id_type = 2;
    else {
        TORCH_CHECK(ids.scalar_type() == at::kBFloat16, "Unsupported routing ID dtype");
        id_type = 3;
    }

    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND(at::ScalarType::BFloat16, a.scalar_type(),
                                  "moe_forward", [&] {
        // Chunk the pair dimension to respect the grid-y launch limit.
        for (int64_t start = 0; start < pairs; ) {
            // Keep each chunk aligned to token boundaries.
            int64_t count = std::min<int64_t>(pairs - start, (65535 / topk) * topk);
            TORCH_CHECK(count > 0, "top_k exceeds supported launch size");
            const char* id_ptr = static_cast<const char*>(ids.data_ptr())
                                + start * ids.element_size();
            first_layer<scalar_t><<<dim3((H + 3) / 4, count), 256, 0, stream>>>(
                a.data_ptr<scalar_t>() + (start / topk) * K,
                w1.data_ptr<scalar_t>(), id_ptr,
                hidden.data_ptr<float>() + start * H, K, H, topk, id_type);
            second_layer<scalar_t><<<dim3((K + 3) / 4, count), 256, 0, stream>>>(
                hidden.data_ptr<float>() + start * H, w2.data_ptr<scalar_t>(),
                weights.data_ptr<scalar_t>() + start, id_ptr,
                out.data_ptr<scalar_t>() + start * K, K, H, id_type);
            start += count;
        }
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "routed_swiglu_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, top_k: int, num_experts: int):
        super().__init__()
        self.top_k = top_k
        self.num_experts = num_experts

    def forward(self, a, w1, w2, topk_weights, topk_ids):
        return _get_extension().forward(a, w1, w2, topk_weights, topk_ids)
