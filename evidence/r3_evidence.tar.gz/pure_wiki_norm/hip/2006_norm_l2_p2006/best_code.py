import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXTENSION = None

_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor fused_residual_layernorm(
    torch::Tensor x,
    torch::Tensor residual,
    torch::Tensor weight,
    torch::Tensor bias,
    double eps);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_residual_layernorm", &fused_residual_layernorm,
          "Fused residual add and LayerNorm");
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <c10/util/BFloat16.h>
#include <c10/util/Half.h>

namespace {

template <typename scalar_t>
__global__ void fused_residual_layernorm_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ residual,
    const scalar_t* __restrict__ weight,
    const scalar_t* __restrict__ bias,
    scalar_t* __restrict__ out,
    int64_t rows,
    int64_t cols,
    float eps) {
    constexpr int BLOCK = 256;
    __shared__ float reduce[BLOCK];

    const int tid = threadIdx.x;
    const int64_t row = static_cast<int64_t>(blockIdx.x);
    if (row >= rows) {
        return;
    }

    const int64_t base = row * cols;
    float sum = 0.0f;

    for (int64_t j = tid; j < cols; j += BLOCK) {
        const int64_t idx = base + j;
        const float s = static_cast<float>(x[idx]) +
                        static_cast<float>(residual[idx]);
        const scalar_t rounded = static_cast<scalar_t>(s);
        out[cols * row * 2 + j + cols] = rounded;
        sum += static_cast<float>(rounded);
    }

    reduce[tid] = sum;
    __syncthreads();

    for (int stride = BLOCK / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            reduce[tid] += reduce[tid + stride];
        }
        __syncthreads();
    }

    const float mean = reduce[0] / static_cast<float>(cols);
    float var_sum = 0.0f;

    for (int64_t j = tid; j < cols; j += BLOCK) {
        const int64_t idx = base + j;
        const float z = static_cast<float>(
            out[cols * row * 2 + j + cols]);
        const float d = z - mean;
        var_sum += d * d;
    }

    reduce[tid] = var_sum;
    __syncthreads();

    for (int stride = BLOCK / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            reduce[tid] += reduce[tid + stride];
        }
        __syncthreads();
    }

    const float var = reduce[0] / static_cast<float>(cols);
    const float rstd = rsqrtf(var + eps);

    for (int64_t j = tid; j < cols; j += BLOCK) {
        const int64_t idx = base + j;
        const float z = static_cast<float>(
            out[cols * row * 2 + j + cols]);
        const float w = static_cast<float>(weight[j]);
        const float b = static_cast<float>(bias[j]);
        const float y = ((z - mean) * rstd) * w + b;
        out[cols * row * 2 + j] = static_cast<scalar_t>(y);
    }
}

}  // namespace

torch::Tensor fused_residual_layernorm(
    torch::Tensor x,
    torch::Tensor residual,
    torch::Tensor weight,
    torch::Tensor bias,
    double eps) {
    TORCH_CHECK(x.is_cuda(), "x must be a device tensor");
    TORCH_CHECK(residual.is_cuda(), "residual must be a device tensor");
    TORCH_CHECK(weight.is_cuda(), "weight must be a device tensor");
    TORCH_CHECK(bias.is_cuda(), "bias must be a device tensor");
    TORCH_CHECK(x.is_contiguous(), "x must be contiguous");
    TORCH_CHECK(residual.is_contiguous(), "residual must be contiguous");
    TORCH_CHECK(weight.is_contiguous(), "weight must be contiguous");
    TORCH_CHECK(bias.is_contiguous(), "bias must be contiguous");
    TORCH_CHECK(x.dim() == 2, "x must be 2D");
    TORCH_CHECK(residual.sizes() == x.sizes(), "residual shape mismatch");
    TORCH_CHECK(weight.dim() == 1 && bias.dim() == 1, "weight and bias must be 1D");
    TORCH_CHECK(weight.size(0) == x.size(1), "weight shape mismatch");
    TORCH_CHECK(bias.size(0) == x.size(1), "bias shape mismatch");
    TORCH_CHECK(x.scalar_type() == residual.scalar_type(), "dtype mismatch");
    TORCH_CHECK(x.scalar_type() == weight.scalar_type(), "dtype mismatch");
    TORCH_CHECK(x.scalar_type() == bias.scalar_type(), "dtype mismatch");
    TORCH_CHECK(
        x.scalar_type() == at::kFloat ||
        x.scalar_type() == at::kHalf ||
        x.scalar_type() == at::kBFloat16,
        "unsupported dtype");

    const int64_t rows = x.size(0);
    const int64_t cols = x.size(1);
    auto out = torch::empty({rows, cols * 2}, x.options());

    const dim3 block(256);
    const dim3 grid(static_cast<unsigned int>(rows));
    auto stream = at::cuda::getCurrentCUDAStream().stream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "fused_residual_layernorm",
        [&] {
            fused_residual_layernorm_kernel<scalar_t>
                <<<grid, block, 0, stream>>>(
                    x.data_ptr<scalar_t>(),
                    residual.data_ptr<scalar_t>(),
                    weight.data_ptr<scalar_t>(),
                    bias.data_ptr<scalar_t>(),
                    out.data_ptr<scalar_t>(),
                    rows,
                    cols,
                    static_cast<float>(eps));
        });

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP_SRC + _HIP_SRC).encode("utf-8")).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="fused_residual_layernorm_" + digest,
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        self.eps = float(eps)

    def forward(self, x, residual, weight, bias):
        return _get_extension().fused_residual_layernorm(
            x, residual, weight, bias, self.eps
        )
