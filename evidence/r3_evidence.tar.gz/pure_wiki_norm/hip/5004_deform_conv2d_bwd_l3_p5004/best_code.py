import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor run(torch::Tensor dy, torch::Tensor w, torch::Tensor x,
                  torch::Tensor o, torch::Tensor mask, bool wrw,
                  int sh, int sw, int ph, int pw, int dh, int dw);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAGuard.h>

struct D {
    int N,C,H,W,K,M,S,P,OW,sh,sw,ph,pw,dh,dw;
};

__device__ __forceinline__ float read_pixel(
    const float* x, int y, int z, int h, int w) {
    return (y >= 0 && y < h && z >= 0 && z < w) ? x[y*w+z] : 0.0f;
}

__device__ __forceinline__ void coords(
    const float* o, D d, int b, int m, int p,
    int &y, int &z, float &ty, float &tx) {
    float fy = float((p/d.OW)*d.sh-d.ph+(m/d.S)*d.dh)
               + o[((b*2*d.M+2*m)*d.P)+p];
    float fx = float((p%d.OW)*d.sw-d.pw+(m%d.S)*d.dw)
               + o[((b*2*d.M+2*m+1)*d.P)+p];
    float iy = floorf(fy), ix = floorf(fx);
    y = (int)iy; z = (int)ix;
    ty = fy-iy; tx = fx-ix;
}

__global__ void sample_kernel(const float* x, const float* o,
    const float* mask, float* v, D d) {
    long t = (long)blockIdx.x*blockDim.x+threadIdx.x;
    long total = (long)d.N*d.M*d.C*d.P;
    if(t >= total) return;
    int p=t%d.P, c=(t/d.P)%d.C, m=(t/d.P/d.C)%d.M;
    int b=t/d.P/d.C/d.M;
    int y,z; float ty,tx;
    coords(o,d,b,m,p,y,z,ty,tx);
    const float* a=x+((long)b*d.C+c)*d.H*d.W;
    float a00=read_pixel(a,y,z,d.H,d.W);
    float a01=read_pixel(a,y,z+1,d.H,d.W);
    float a10=read_pixel(a,y+1,z,d.H,d.W);
    float a11=read_pixel(a,y+1,z+1,d.H,d.W);
    v[t]=((1-ty)*(1-tx)*a00+(1-ty)*tx*a01+
          ty*(1-tx)*a10+ty*tx*a11);
}

// Each tile computes a correlation for one kernel position.
__global__ void weight_kernel(const float* dy, const float* v,
    const float* mask, float* out, D d) {
    __shared__ float a[16][16];
    __shared__ float b[16][16];
    int tx=threadIdx.x, ty=threadIdx.y;
    int c=blockIdx.x*16+tx, k=blockIdx.y*16+ty;
    int m=blockIdx.z;
    float sum=0;
    int L=d.N*d.P;
    for(int q=0;q<L;q+=16) {
        int qa=q+tx, qb=q+ty;
        float av=0,bv=0;
        if(k<d.K && qa<L) {
            int n=qa/d.P,p=qa%d.P;
            av=dy[((long)n*d.K+k)*d.P+p]
                *mask[((long)n*d.M+m)*d.P+p];
        }
        if(c<d.C && qb<L) {
            int n=qb/d.P,p=qb%d.P;
            bv=v[(((long)n*d.M+m)*d.C+c)*d.P+p];
        }
        a[ty][tx]=av; b[ty][tx]=bv;
        __syncthreads();
        #pragma unroll
        for(int j=0;j<16;++j) sum+=a[ty][j]*b[j][tx];
        __syncthreads();
    }
    if(k<d.K && c<d.C) out[((long)k*d.C+c)*d.M+m]=sum;
}

// Produce both the masked input-sampling gradient and the unmasked
// contraction used for the modulation gradient.
__global__ void contraction(const float* dy, const float* w,
    const float* mask, float* g, float* u, D d) {
    int p=blockIdx.x*16+threadIdx.x;
    int c=blockIdx.y*16+threadIdx.y;
    int n=blockIdx.z/d.M, m=blockIdx.z%d.M;
    __shared__ float a[16][16];
    __shared__ float b[16][16];
    float val=0, raw=0;
    float mod=p<d.P ? mask[((long)n*d.M+m)*d.P+p] : 0;
    for(int q=0;q<d.K;q+=16) {
        int ka=q+threadIdx.x, kb=q+threadIdx.y;
        a[threadIdx.y][threadIdx.x]=(c<d.C && ka<d.K)
            ? w[((long)ka*d.C+c)*d.M+m] : 0;
        b[threadIdx.y][threadIdx.x]=(p<d.P && kb<d.K)
            ? dy[((long)n*d.K+kb)*d.P+p] : 0;
        __syncthreads();
        #pragma unroll
        for(int j=0;j<16;++j) {
            float ww=a[threadIdx.y][j], yy=b[j][threadIdx.x];
            val+=ww*(yy*mod);
            raw+=ww*yy;
        }
        __syncthreads();
    }
    if(c<d.C && p<d.P) {
        long idx=(((long)n*d.M+m)*d.C+c)*d.P+p;
        g[idx]=val; u[idx]=raw;
    }
}

__device__ __forceinline__ void scatter(
    float* x,int y,int z,int h,int w,float v) {
    if(y>=0 && y<h && z>=0 && z<w) atomicAdd(x+y*w+z,v);
}

__global__ void backward_sample(const float* x,const float* o,
    const float* g,const float* u,float* out,D d) {
    long t=(long)blockIdx.x*blockDim.x+threadIdx.x;
    if(t>=(long)d.N*d.M*d.P) return;
    int p=t%d.P,m=(t/d.P)%d.M,n=t/d.P/d.M;
    int y,z; float ty,tx;
    coords(o,d,n,m,p,y,z,ty,tx);
    float gy=0,gx=0,gm=0;
    float w00=(1-ty)*(1-tx),w01=(1-ty)*tx;
    float w10=ty*(1-tx),w11=ty*tx;
    for(int c=0;c<d.C;++c) {
        long base=((long)n*d.C+c)*d.H*d.W;
        const float* a=x+base;
        float a00=read_pixel(a,y,z,d.H,d.W);
        float a01=read_pixel(a,y,z+1,d.H,d.W);
        float a10=read_pixel(a,y+1,z,d.H,d.W);
        float a11=read_pixel(a,y+1,z+1,d.H,d.W);
        long j=(((long)n*d.M+m)*d.C+c)*d.P+p;
        float v=g[j];
        float t00=v*a00,t01=v*a01,t10=v*a10,t11=v*a11;
        gy+=(-((1-tx)*t00)-tx*t01)+(1-tx)*t10+tx*t11;
        gx+=(-(1-ty)*t00+(1-ty)*t01)-ty*t10+ty*t11;
        gm+=u[j]*(w00*a00+w01*a01+w10*a10+w11*a11);
        scatter(out+base,y,z,d.H,d.W,v*w00);
        scatter(out+base,y,z+1,d.H,d.W,v*w01);
        scatter(out+base,y+1,z,d.H,d.W,v*w10);
        scatter(out+base,y+1,z+1,d.H,d.W,v*w11);
    }
    long off=(long)d.N*d.C*d.H*d.W;
    out[off+((long)n*2*d.M+2*m)*d.P+p]=gy;
    out[off+((long)n*2*d.M+2*m+1)*d.P+p]=gx;
    out[off+(long)d.N*2*d.M*d.P+t]=gm;
}

torch::Tensor run(torch::Tensor dy, torch::Tensor w, torch::Tensor x,
                  torch::Tensor o, torch::Tensor mask, bool wrw,
                  int sh,int sw,int ph,int pw,int dh,int dw) {
    c10::cuda::CUDAGuard guard(x.device());
    D d;
    d.N=x.size(0);d.C=x.size(1);d.H=x.size(2);d.W=x.size(3);
    d.K=w.size(0);d.M=w.size(2)*w.size(3);d.S=w.size(3);
    d.P=dy.size(2)*dy.size(3);d.OW=dy.size(3);
    d.sh=sh;d.sw=sw;d.ph=ph;d.pw=pw;d.dh=dh;d.dw=dw;
    auto stream=c10::cuda::getCurrentCUDAStream().stream();
    long len=(long)d.N*d.M*d.C*d.P;
    auto v=torch::empty({len},x.options());
    torch::Tensor out;
    if(wrw) {
        out=torch::empty(w.sizes(),x.options());
        sample_kernel<<<(len+255)/256,256,0,stream>>>(
            x.data_ptr<float>(),o.data_ptr<float>(),mask.data_ptr<float>(),
            v.data_ptr<float>(),d);
        weight_kernel<<<dim3((d.C+15)/16,(d.K+15)/16,d.M),
                           dim3(16,16),0,stream>>>(
            dy.data_ptr<float>(),v.data_ptr<float>(),mask.data_ptr<float>(),
            out.data_ptr<float>(),d);
    } else {
        long nx=(long)d.N*d.C*d.H*d.W;
        out=torch::empty({nx+(long)d.N*3*d.M*d.P},x.options());
        hipMemsetAsync(out.data_ptr<float>(),0,nx*sizeof(float),stream);
        auto u=torch::empty({len},x.options());
        contraction<<<dim3((d.P+15)/16,(d.C+15)/16,d.N*d.M),
                        dim3(16,16),0,stream>>>(
            dy.data_ptr<float>(),w.data_ptr<float>(),mask.data_ptr<float>(),
            v.data_ptr<float>(),u.data_ptr<float>(),d);
        long points=(long)d.N*d.M*d.P;
        backward_sample<<<(points+255)/256,256,0,stream>>>(
            x.data_ptr<float>(),o.data_ptr<float>(),v.data_ptr<float>(),
            u.data_ptr<float>(),out.data_ptr<float>(),d);
    }
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "dcu_sampling_" + hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dgrad", stride_h: int = 1,
                 stride_w: int = 1, pad_h: int = 1, pad_w: int = 1,
                 dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        assert variant in ("dgrad", "wrw")
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)

    def forward(self, dy, weight, x, offset, mask):
        return _get_extension().run(
            dy, weight, x, offset, mask, self.variant == "wrw",
            self.stride_h, self.stride_w, self.pad_h, self.pad_w,
            self.dil_h, self.dil_w,
        )
