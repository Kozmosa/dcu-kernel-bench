import math
import hashlib
import torch
from torch import nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                        torch::Tensor lens, torch::Tensor causal, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("attention", &attention);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cmath>

__global__ void offsets_kernel(const int* lens, int* offsets, int n) {
    int b = blockIdx.x * blockDim.x + threadIdx.x;
    if (b < n) {
        int s = 0;
        for (int i = 0; i < b; ++i) s += lens[i];
        offsets[b] = s;
    }
}

template<typename T>
__global__ void partial_kernel(
    const T* __restrict__ q, const T* __restrict__ k,
    const T* __restrict__ v, const int* lens, const int* offsets,
    const int* causal, float* partial, float* stats,
    int H, int D, int QL, int splits, float scale,
    int64_t qs0, int64_t qs1, int64_t qs2,
    int64_t ks0, int64_t ks1, int64_t ks2,
    int64_t vs0, int64_t vs1, int64_t vs2) {
    int row = blockIdx.x, split = blockIdx.y, t = threadIdx.x;
    int h = row % H, qi = row / H;
    int b = qi / QL, pos = qi % QL;
    int length = lens[b];
    if (*causal) length = min(length, pos + 1);
    int begin = (int)((int64_t)length * split / splits);
    int end = (int)((int64_t)length * (split + 1) / splits);
    int offset = offsets[b];
    int64_t base = ((int64_t)row * splits + split);
    __shared__ float scores[128];
    __shared__ float red[256];
    __shared__ float query[256];
    __shared__ float alpha, norm, maximum;
    float acc = 0.0f;
    if (t < D) query[t] = (float)q[qi * qs0 + h * qs1 + t * qs2];
    if (t == 0) {
        norm = 0.0f;
        maximum = -INFINITY;
    }
    __syncthreads();
    int lane = t & 15;
    int group = t >> 4;
    for (int tile = begin; tile < end; tile += 128) {
        for (int j = group; j < 128; j += 16) {
            float dot = 0.0f;
            int key = tile + j;
            if (key < end) {
                for (int d = lane; d < D; d += 16)
                    dot += query[d] * (float)k[(int64_t)(offset + key) * ks0 + h * ks1 + d * ks2];
            }
            for (int delta = 8; delta; delta >>= 1)
                dot += __shfl_down(dot, delta, 16);
            if (!lane) scores[j] = key < end ? dot * scale : -INFINITY;
        }
        __syncthreads();
        red[t] = t < 128 ? scores[t] : -INFINITY;
        __syncthreads();
        for (int step = 128; step; step >>= 1) {
            if (t < step) red[t] = fmaxf(red[t], red[t + step]);
            __syncthreads();
        }
        if (t == 0) {
            float next = fmaxf(maximum, red[0]);
            alpha = expf(maximum - next);
            maximum = next;
        }
        __syncthreads();
        float p = t < 128 ? expf(scores[t] - maximum) : 0.0f;
        if (t < 128) scores[t] = p;
        red[t] = p;
        __syncthreads();
        for (int step = 128; step; step >>= 1) {
            if (t < step) red[t] += red[t + step];
            __syncthreads();
        }
        if (t == 0) norm = norm * alpha + red[0];
        if (t < D) {
            acc *= alpha;
            int count = min(128, end - tile);
            for (int j = 0; j < count; ++j)
                acc += scores[j] * (float)v[(int64_t)(offset + tile + j) * vs0 + h * vs1 + t * vs2];
        }
        __syncthreads();
    }
    if (t < D) partial[base * D + t] = acc;
    if (t == 0) {
        stats[base * 2] = maximum;
        stats[base * 2 + 1] = norm;
    }
}

template<typename T>
__global__ void merge_kernel(const float* partial, const float* stats,
                             T* out, int D, int splits) {
    int row = blockIdx.x, d = threadIdx.x;
    __shared__ float weights[32], denominator;
    if (d == 0) {
        float m = -INFINITY;
        for (int s = 0; s < splits; ++s)
            m = fmaxf(m, stats[((int64_t)row * splits + s) * 2]);
        float n = 0;
        for (int s = 0; s < splits; ++s) {
            int64_t idx = ((int64_t)row * splits + s) * 2;
            weights[s] = expf(stats[idx] - m);
            n += weights[s] * stats[idx + 1];
        }
        denominator = n;
    }
    __syncthreads();
    if (d < D) {
        float a = 0;
        for (int s = 0; s < splits; ++s)
            a += weights[s] * partial[((int64_t)row * splits + s) * D + d];
        out[(int64_t)row * D + d] = (T)(a / denominator);
    }
}

torch::Tensor attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                        torch::Tensor lens, torch::Tensor causal, double scale) {
    c10::cuda::CUDAGuard guard(q.device());
    int B = lens.numel(), H = q.size(1), D = q.size(2);
    int QL = q.size(0) / B, rows = q.size(0) * H;
    TORCH_CHECK(D <= 256 && D > 0, "Unsupported head dimension");
    int average = (k.size(0) + B - 1) / B;
    int splits = std::min(32, std::max(1, (average + 511) / 512));
    if (rows >= 2048) splits = 1;
    auto out = torch::empty(q.sizes(), q.options());
    auto partial = torch::empty({rows, splits, D}, q.options().dtype(torch::kFloat32));
    auto stats = torch::empty({rows, splits, 2}, q.options().dtype(torch::kFloat32));
    auto offsets = torch::empty({B}, q.options().dtype(torch::kInt32));
    auto stream = at::cuda::getCurrentCUDAStream();
    offsets_kernel<<<(B + 255) / 256, 256, 0, stream>>>(
        lens.data_ptr<int>(), offsets.data_ptr<int>(), B);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  q.scalar_type(), "ragged_attention", [&] {
        partial_kernel<scalar_t><<<dim3(rows, splits), 256, 0, stream>>>(
            q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
            lens.data_ptr<int>(), offsets.data_ptr<int>(), causal.data_ptr<int>(),
            partial.data_ptr<float>(), stats.data_ptr<float>(), H, D, QL, splits,
            (float)scale, q.stride(0), q.stride(1), q.stride(2),
            k.stride(0), k.stride(1), k.stride(2),
            v.stride(0), v.stride(1), v.stride(2));
        merge_kernel<scalar_t><<<rows, 256, 0, stream>>>(
            partial.data_ptr<float>(), stats.data_ptr<float>(),
            out.data_ptr<scalar_t>(), D, splits);
    });
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "ragged_hip_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)

    def forward(self, q, k, v, kv_lens, causal):
        kv_lens = kv_lens.to(device=q.device, dtype=torch.int32).contiguous()
        if isinstance(causal, torch.Tensor):
            causal = causal.to(device=q.device, dtype=torch.int32).contiguous()
        else:
            causal = torch.tensor(causal, device=q.device, dtype=torch.int32)
        return _extension().attention(q, k, v, kv_lens, causal, self.sm_scale)
