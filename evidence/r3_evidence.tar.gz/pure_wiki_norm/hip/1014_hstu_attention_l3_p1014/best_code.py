import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor run(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                  torch::Tensor offsets, torch::Tensor targets,
                  int64_t n, double alpha, bool causal, int64_t window, int64_t context);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

template<typename T>
__global__ void weights_kernel(
    const T* __restrict__ q, const T* __restrict__ k,
    const int64_t* __restrict__ offsets, const int* __restrict__ targets,
    float* __restrict__ w, int H, int D, int N,
    float alpha, bool causal, int window, int context)
{
    const int h = blockIdx.z % H, b = blockIdx.z / H;
    const int64_t s = offsets[b];
    const int L = int(offsets[b + 1] - s);
    const int r0 = blockIdx.y * 32, c0 = blockIdx.x * 32;
    if (r0 >= L || c0 >= L) return;

    const int x = threadIdx.x, y = threadIdx.y;
    const int tid = y * 16 + x;
    __shared__ float qs[32][33];
    __shared__ float ks[32][33];
    float a00 = 0, a01 = 0, a10 = 0, a11 = 0;
    for (int base = 0; base < D; base += 32) {
        #pragma unroll
        for (int z = 0; z < 4; ++z) {
            int t = tid + z * 256;
            int row = t / 32, col = t % 32;
            qs[row][col] = r0 + row < L && base + col < D
                ? float(q[((s + r0 + row) * H + h) * D + base + col]) : 0.f;
            ks[row][col] = c0 + row < L && base + col < D
                ? float(k[((s + c0 + row) * H + h) * D + base + col]) : 0.f;
        }
        __syncthreads();
        #pragma unroll
        for (int d = 0; d < 32; ++d) {
            float u0 = qs[y][d], u1 = qs[y + 16][d];
            float v0 = ks[x][d], v1 = ks[x + 16][d];
            a00 = fmaf(u0, v0, a00);
            a01 = fmaf(u0, v1, a01);
            a10 = fmaf(u1, v0, a10);
            a11 = fmaf(u1, v1, a11);
        }
        __syncthreads();
    }
    const int cap = (context ? L - context + 1 : L) - targets[b];
    #pragma unroll
    for (int ry = 0; ry < 2; ++ry) {
        int i = r0 + y + ry * 16;
        int mi = min(context ? max(i - context + 1, 0) : i, cap);
        #pragma unroll
        for (int cx = 0; cx < 2; ++cx) {
            int j = c0 + x + cx * 16;
            if (i < L && j < L) {
                int mj = min(context ? max(j - context + 1, 0) : j, cap);
                int dist = mi - mj;
                if (!causal) dist = abs(dist);
                bool valid = (i == j || dist > 0);
                if (window > 0) valid = valid && dist <= window;
                if (context > 0) valid = valid || (mi == 0 && mj < cap);
                float a = ry ? (cx ? a11 : a10) : (cx ? a01 : a00);
                a *= alpha;
                float value = valid ? (a / (1.f + expf(-a))) / float(N) : 0.f;
                w[((s + i) * H + h) * N + j] = value;
            }
        }
    }
}

template<typename T>
__global__ void output_kernel(
    const float* __restrict__ w, const T* __restrict__ v,
    const int64_t* __restrict__ offsets, T* __restrict__ out,
    int H, int D, int N)
{
    const int h = blockIdx.z % H, b = blockIdx.z / H;
    const int64_t s = offsets[b];
    const int L = int(offsets[b + 1] - s);
    const int r0 = blockIdx.y * 32, c0 = blockIdx.x * 32;
    if (r0 >= L) return;
    const int x = threadIdx.x, y = threadIdx.y;
    const int tid = y * 16 + x;
    __shared__ float ws[32][33];
    __shared__ float vs[32][33];
    float a00 = 0, a01 = 0, a10 = 0, a11 = 0;
    for (int base = 0; base < L; base += 32) {
        #pragma unroll
        for (int z = 0; z < 4; ++z) {
            int t = tid + z * 256;
            int row = t / 32, col = t % 32;
            ws[row][col] = r0 + row < L && base + col < L
                ? w[((s + r0 + row) * H + h) * N + base + col] : 0.f;
            vs[row][col] = base + row < L && c0 + col < D
                ? float(v[((s + base + row) * H + h) * D + c0 + col]) : 0.f;
        }
        __syncthreads();
        #pragma unroll
        for (int d = 0; d < 32; ++d) {
            float u0 = ws[y][d], u1 = ws[y + 16][d];
            float v0 = vs[d][x], v1 = vs[d][x + 16];
            a00 = fmaf(u0, v0, a00);
            a01 = fmaf(u0, v1, a01);
            a10 = fmaf(u1, v0, a10);
            a11 = fmaf(u1, v1, a11);
        }
        __syncthreads();
    }
    #pragma unroll
    for (int ry = 0; ry < 2; ++ry) {
        int i = r0 + y + ry * 16;
        #pragma unroll
        for (int cx = 0; cx < 2; ++cx) {
            int j = c0 + x + cx * 16;
            if (i < L && j < D) {
                float a = ry ? (cx ? a11 : a10) : (cx ? a01 : a00);
                out[((s + i) * H + h) * D + j] = T(a);
            }
        }
    }
}

torch::Tensor run(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                  torch::Tensor offsets, torch::Tensor targets,
                  int64_t n, double alpha, bool causal, int64_t window, int64_t context)
{
    c10::cuda::CUDAGuard guard(q.device());
    auto out = torch::empty(v.sizes(), v.options());
    if (v.numel() == 0) return out;
    const int H = q.size(1), D = q.size(2), V = v.size(2);
    const int B = offsets.numel() - 1, N = n;
    auto w = torch::empty({q.size(0), int64_t(H), n},
                         q.options().dtype(torch::kFloat32));
    auto stream = at::cuda::getCurrentCUDAStream();
    dim3 threads(16, 16);
    dim3 wg((N + 31) / 32, (N + 31) / 32, B * H);
    dim3 og((V + 31) / 32, (N + 31) / 32, B * H);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  q.scalar_type(), "hstu_forward", [&] {
        weights_kernel<scalar_t><<<wg, threads, 0, stream>>>(
            q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(),
            offsets.data_ptr<int64_t>(), targets.data_ptr<int>(),
            w.data_ptr<float>(), H, D, N, float(alpha), causal, window, context);
        output_kernel<scalar_t><<<og, threads, 0, stream>>>(
            w.data_ptr<float>(), v.data_ptr<scalar_t>(),
            offsets.data_ptr<int64_t>(), out.data_ptr<scalar_t>(), H, V, N);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "hstu_tiled_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, max_seq_len: int, alpha=None, causal=True, max_attn_len=0, contextual_seq_len=0):
        super().__init__()
        self.max_seq_len = int(max_seq_len)
        self.alpha = float(alpha) if alpha is not None else None
        self.causal = bool(causal)
        self.max_attn_len = int(max_attn_len)
        self.contextual_seq_len = int(contextual_seq_len)

    def forward(self, q, k, v, seq_offsets, num_targets):
        alpha = self.alpha if self.alpha is not None else 1.0 / math.sqrt(q.shape[2])
        return _extension().run(
            q.contiguous(), k.contiguous(), v.contiguous(),
            seq_offsets.to(device=q.device, dtype=torch.int64).contiguous(),
            num_targets.to(device=q.device, dtype=torch.int32).contiguous(),
            self.max_seq_len, alpha, self.causal,
            self.max_attn_len, self.contextual_seq_len,
        )
