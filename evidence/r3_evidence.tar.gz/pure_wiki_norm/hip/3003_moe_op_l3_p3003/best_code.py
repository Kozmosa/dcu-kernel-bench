import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor routed_gemm(
    torch::Tensor a, torch::Tensor b, torch::Tensor w,
    torch::Tensor sorted, torch::Tensor experts, torch::Tensor padded,
    int64_t top_k);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("routed_gemm", &routed_gemm);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template<class T>
__global__ __launch_bounds__(256)
void routed_kernel(
    const T* __restrict__ a, const T* __restrict__ b,
    const float* __restrict__ w,
    const int32_t* __restrict__ sorted,
    const int32_t* __restrict__ experts,
    const int32_t* __restrict__ padded,
    T* __restrict__ out,
    int slots, int top_k, int N, int K,
    int64_t as0, int64_t as1,
    int64_t bs0, int64_t bs1, int64_t bs2,
    int64_t ws0, int64_t ws1)
{
    int start = blockIdx.x * 16;
    if (start >= padded[0]) return;

    __shared__ float sa[16][32];
    __shared__ float sb[32][64];
    __shared__ int ids[16];

    int tid = threadIdx.x;
    if (tid < 16) ids[tid] = sorted[start + tid];
    int e = experts[start / 64];
    int col = blockIdx.y * 64 + tid % 64;
    int row = tid / 64;
    float accum0 = 0.f, accum1 = 0.f;
    float accum2 = 0.f, accum3 = 0.f;
    __syncthreads();

    for (int base = 0; base < K; base += 32) {
        #pragma unroll
        for (int i = 0; i < 2; ++i) {
            int q = tid + i * 256;
            int r = q / 32;
            int k = base + q % 32;
            int p = ids[r];
            sa[r][q % 32] = (p < slots && k < K)
                ? static_cast<float>(a[(int64_t)(p / top_k) * as0 + k * as1])
                : 0.f;
        }
        #pragma unroll
        for (int i = 0; i < 8; ++i) {
            int q = tid + i * 256;
            int n = blockIdx.y * 64 + q / 32;
            int k = base + q % 32;
            sb[q % 32][q / 32] = (n < N && k < K)
                ? static_cast<float>(b[(int64_t)e * bs0 + n * bs1 + k * bs2])
                : 0.f;
        }
        __syncthreads();
        #pragma unroll
        for (int k = 0; k < 32; ++k) {
            float bv = sb[k][tid % 64];
            accum0 = fmaf(sa[row][k], bv, accum0);
            accum1 = fmaf(sa[row + 4][k], bv, accum1);
            accum2 = fmaf(sa[row + 8][k], bv, accum2);
            accum3 = fmaf(sa[row + 12][k], bv, accum3);
        }
        __syncthreads();
    }

    if (col < N) {
        float vals[4] = {accum0, accum1, accum2, accum3};
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            int p = ids[row + i * 4];
            if (p < slots) {
                float weight = w[(int64_t)(p / top_k) * ws0 + (p % top_k) * ws1];
                out[(int64_t)p * N + col] = static_cast<T>(vals[i] * weight);
            }
        }
    }
}

torch::Tensor routed_gemm(
    torch::Tensor a, torch::Tensor b, torch::Tensor w,
    torch::Tensor sorted, torch::Tensor experts, torch::Tensor padded,
    int64_t top_k)
{
    c10::cuda::CUDAGuard guard(a.device());
    const int M = a.size(0), K = a.size(1), N = b.size(1);
    auto out = torch::empty({M, top_k, N}, a.options());
    if (M == 0 || N == 0) return out;
    TORCH_CHECK(sorted.scalar_type() == at::kInt &&
                experts.scalar_type() == at::kInt &&
                padded.scalar_type() == at::kInt,
                "Routing layout must use int32");
    dim3 grid((sorted.numel() + 15) / 16, (N + 63) / 64);
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        a.scalar_type(), "routed_gemm", [&] {
            routed_kernel<scalar_t><<<grid, 256, 0, stream>>>(
                a.data_ptr<scalar_t>(), b.data_ptr<scalar_t>(),
                w.data_ptr<float>(), sorted.data_ptr<int32_t>(),
                experts.data_ptr<int32_t>(), padded.data_ptr<int32_t>(),
                out.data_ptr<scalar_t>(), M * top_k, top_k, N, K,
                a.stride(0), a.stride(1),
                b.stride(0), b.stride(1), b.stride(2),
                w.stride(0), w.stride(1));
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "routed_gemm_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, num_experts: int, top_k: int):
        super().__init__()
        self.num_experts = num_experts
        self.top_k = top_k

    def forward(self, A, B, topk_weights, topk_ids, sorted_token_ids,
                expert_ids, num_tokens_post_padded):
        return _get_extension().routed_gemm(
            A, B, topk_weights, sorted_token_ids, expert_ids,
            num_tokens_post_padded, topk_ids.shape[1]
        )
