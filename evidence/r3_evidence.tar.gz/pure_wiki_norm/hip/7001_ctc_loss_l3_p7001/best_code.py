import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor run_ctc(torch::Tensor p, torch::Tensor labels,
                      torch::Tensor lengths, torch::Tensor times, int64_t blank);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run_ctc);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>
#include <cmath>

__device__ __forceinline__ float lse(float a, float b, float c) {
    float m = fmaxf(a, fmaxf(b,c));
    if (m == -INFINITY) return m;
    return m + logf((expf(a-m) + expf(b-m)) + expf(c-m));
}

__global__ void logs_kernel(const float* p, float* lp, int64_t count) {
    for (int64_t i = int64_t(blockIdx.x)*blockDim.x+threadIdx.x;
         i<count; i+=int64_t(blockDim.x)*gridDim.x)
        lp[i] = logf(p[i]);
}

__device__ __forceinline__ int symbol(
    const int64_t* labels, int offset, int s, int blank) {
    return (s & 1) ? int(labels[offset+s/2]) : blank;
}

__global__ void recurrence(
    const float* lp, const int64_t* labels, const int64_t* lengths,
    const int64_t* times, float* alpha, float* beta, float* out,
    int T, int N, int C, int stride, int blank) {
    int n = blockIdx.x / 2;
    bool backward = blockIdx.x & 1;
    int L = lengths[n], S = 2*L+1, tb = times[n];
    int offset = 0;
    for (int j=0; j<n; ++j) offset += lengths[j];
    extern __shared__ float sh[];
    float* prev = sh;
    float* cur = sh + stride;
    float* table = (backward ? beta : alpha) + int64_t(n)*T*stride;
    int t0 = backward ? tb-1 : 0;
    for (int s=threadIdx.x; s<S; s+=blockDim.x) {
        int k = symbol(labels,offset,s,blank);
        float emission = lp[(int64_t(t0)*N+n)*C+k];
        float v = backward ? (s>=S-2 ? 0.0f : -INFINITY)
                           : (s<2 ? emission : -INFINITY);
        table[int64_t(t0)*stride+s] = v;
        prev[s] = backward ? v+emission : v;
    }
    __syncthreads();
    for (int step=1; step<tb; ++step) {
        int t = backward ? tb-1-step : step;
        for (int s=threadIdx.x; s<S; s+=blockDim.x) {
            int k = symbol(labels,offset,s,blank);
            float a = prev[s], b = -INFINITY, c = -INFINITY;
            if (backward) {
                if (s+1<S) b = prev[s+1];
                if (s+2<S && k!=blank &&
                    k!=symbol(labels,offset,s+2,blank)) c=prev[s+2];
            } else {
                if (s>0) b=prev[s-1];
                if (s>1 && k!=blank &&
                    k!=symbol(labels,offset,s-2,blank)) c=prev[s-2];
            }
            float emission = lp[(int64_t(t)*N+n)*C+k];
            float v = lse(a,b,c);
            if (!backward) v += emission;
            table[int64_t(t)*stride+s] = v;
            cur[s] = backward ? v+emission : v;
        }
        __syncthreads();
        float* tmp=prev; prev=cur; cur=tmp;
    }
    if (!backward && threadIdx.x==0)
        out[n] = -lse(prev[S-1], S>1 ? prev[S-2] : -INFINITY, -INFINITY);
}

__global__ void gradients(
    const float* p, const int64_t* labels, const int64_t* lengths,
    const int64_t* times, const float* alpha, const float* beta,
    float* out, int T, int N, int C, int stride, int blank) {
    int n = blockIdx.x / T, t = blockIdx.x % T;
    int L=lengths[n], S=2*L+1, offset=0;
    for (int j=0; j<n; ++j) offset+=lengths[j];
    extern __shared__ float gamma[];
    const int64_t base=(int64_t(n)*T+t)*stride;
    if (t<times[n]) {
        for (int s=threadIdx.x; s<S; s+=blockDim.x)
            gamma[s]=expf((alpha[base+s]+beta[base+s])+out[n]);
    }
    __syncthreads();
    for (int k=threadIdx.x; k<C; k+=blockDim.x) {
        float total=0;
        if (t<times[n]) {
            if (k==blank) {
                for (int s=0; s<S; s+=2) total+=gamma[s];
            } else {
                for (int j=0; j<L; ++j)
                    if (labels[offset+j]==k) total+=gamma[2*j+1];
            }
            total=-total/p[(int64_t(t)*N+n)*C+k];
        }
        out[N+(int64_t(n)*T+t)*C+k]=total;
    }
}

torch::Tensor run_ctc(torch::Tensor p, torch::Tensor labels,
                     torch::Tensor lengths, torch::Tensor times, int64_t blank) {
    c10::cuda::CUDAGuard guard(p.device());
    int T=p.size(0), N=p.size(1), C=p.size(2);
    int stride=2*std::min<int64_t>(T,labels.numel())+1;
    auto out=torch::empty({int64_t(N)+int64_t(N)*T*C},p.options());
    auto lp=torch::empty_like(p);
    auto a=torch::empty({N,T,stride},p.options());
    auto b=torch::empty_like(a);
    auto stream=c10::cuda::getCurrentCUDAStream();
    int blocks=std::min<int64_t>((p.numel()+255)/256,65535);
    logs_kernel<<<blocks,256,0,stream>>>(p.data_ptr<float>(),lp.data_ptr<float>(),p.numel());
    recurrence<<<2*N,256,2*stride*sizeof(float),stream>>>(
        lp.data_ptr<float>(),labels.data_ptr<int64_t>(),lengths.data_ptr<int64_t>(),
        times.data_ptr<int64_t>(),a.data_ptr<float>(),b.data_ptr<float>(),
        out.data_ptr<float>(),T,N,C,stride,blank);
    gradients<<<N*T,256,stride*sizeof(float),stream>>>(
        p.data_ptr<float>(),labels.data_ptr<int64_t>(),lengths.data_ptr<int64_t>(),
        times.data_ptr<int64_t>(),a.data_ptr<float>(),b.data_ptr<float>(),
        out.data_ptr<float>(),T,N,C,stride,blank);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXT = None


def _extension():
    global _EXT
    if _EXT is None:
        name = "ctc_fb_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXT = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self, blank: int = 0):
        super().__init__()
        self.blank = int(blank)

    def forward(self, probs, labels, label_lengths, input_lengths):
        labels = labels.to(device=probs.device, dtype=torch.long).contiguous()
        label_lengths = label_lengths.to(device=probs.device, dtype=torch.long).contiguous()
        input_lengths = input_lengths.to(device=probs.device, dtype=torch.long).contiguous()
        p = probs.to(dtype=torch.float32).contiguous()
        return _extension().run(
            p, labels, label_lengths, input_lengths, self.blank
        ).to(dtype=probs.dtype)
