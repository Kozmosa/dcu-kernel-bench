import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_forward(torch::Tensor, torch::Tensor, torch::Tensor,
                            torch::Tensor, torch::Tensor, double);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &paged_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

constexpr int TILE = 256;
struct Layout {
    int H, D, K, BS, M, P;
    int64_t q0,q1,q2,k0,k1,k2,k3,v0,v1,v2,v3,b0,b1,l0;
};

template<class T, class I, class L>
__global__ void partial_kernel(
    const T* __restrict__ q, const T* __restrict__ k,
    const T* __restrict__ v, const I* __restrict__ bt,
    const L* __restrict__ lens, float* __restrict__ tmp,
    float* __restrict__ stats, Layout a, float scale)
{
    const int t = threadIdx.x;
    const int h = blockIdx.x % a.H;
    const int s = blockIdx.x / a.H;
    const int p = blockIdx.y;
    const int begin = p * TILE;
    const int n = int(lens[s*a.l0]);
    const int count = min(TILE, n-begin);
    const int64_t part = int64_t(blockIdx.x)*a.P+p;
    if (count <= 0) {
        if (t == 0) {
            stats[part*2] = -INFINITY;
            stats[part*2+1] = 0;
        }
        for (int d=t; d<a.D; d+=256) tmp[part*a.D+d]=0;
        return;
    }

    __shared__ float logits[TILE];
    __shared__ float reduce[256];
    __shared__ float maximum;
    const int lane=t%32, team=t/32;
    const int kh=h/(a.H/a.K);
    for (int i=team; i<TILE; i+=8) {
        float dot=0;
        if (i<count) {
            int pos=begin+i;
            int physical=int(bt[s*a.b0+(pos/a.BS)*a.b1]);
            int64_t kb=physical*a.k0+kh*a.k1+(pos%a.BS)*a.k2;
            for (int d=lane; d<a.D; d+=32) {
                float qs=float(q[s*a.q0+h*a.q1+d*a.q2])*scale;
                dot=fmaf(qs,float(k[kb+d*a.k3]),dot);
            }
        }
        for (int offset=16; offset>0; offset>>=1)
            dot += __shfl_down(dot,offset,32);
        if (lane==0) logits[i]=(i<count ? dot : -INFINITY);
    }
    __syncthreads();
    reduce[t]=logits[t];
    __syncthreads();
    for (int stride=128; stride; stride>>=1) {
        if(t<stride) reduce[t]=fmaxf(reduce[t],reduce[t+stride]);
        __syncthreads();
    }
    if(t==0) maximum=reduce[0];
    __syncthreads();
    float weight=t<count ? expf(logits[t]-maximum) : 0.0f;
    logits[t]=weight;
    reduce[t]=weight;
    __syncthreads();
    for(int stride=128;stride;stride>>=1) {
        if(t<stride) reduce[t]+=reduce[t+stride];
        __syncthreads();
    }
    if(t==0) {
        stats[part*2]=maximum;
        stats[part*2+1]=reduce[0];
    }
    for(int d=t;d<a.D;d+=256) {
        float sum=0;
        for(int i=0;i<count;++i) {
            int pos=begin+i;
            int physical=int(bt[s*a.b0+(pos/a.BS)*a.b1]);
            int64_t vb=physical*a.v0+kh*a.v1+(pos%a.BS)*a.v2;
            sum=fmaf(logits[i],float(v[vb+d*a.v3]),sum);
        }
        tmp[part*a.D+d]=sum;
    }
}

template<class T>
__global__ void merge_kernel(const float* __restrict__ tmp,
                             const float* __restrict__ stats,
                             T* __restrict__ out, int D, int P) {
    __shared__ float reduction[256];
    __shared__ float maximum, denominator;
    int t=threadIdx.x;
    int64_t base=int64_t(blockIdx.x)*P;
    float m=-INFINITY;
    for(int p=t;p<P;p+=256) m=fmaxf(m,stats[(base+p)*2]);
    reduction[t]=m;
    __syncthreads();
    for(int step=128;step;step>>=1) {
        if(t<step) reduction[t]=fmaxf(reduction[t],reduction[t+step]);
        __syncthreads();
    }
    if(t==0) maximum=reduction[0];
    __syncthreads();
    float den=0;
    for(int p=t;p<P;p+=256)
        den+=expf(stats[(base+p)*2]-maximum)*stats[(base+p)*2+1];
    reduction[t]=den;
    __syncthreads();
    for(int step=128;step;step>>=1) {
        if(t<step) reduction[t]+=reduction[t+step];
        __syncthreads();
    }
    if(t==0) denominator=reduction[0];
    __syncthreads();
    for(int d=t;d<D;d+=256) {
        float val=0;
        for(int p=0;p<P;++p)
            val=fmaf(expf(stats[(base+p)*2]-maximum),tmp[(base+p)*D+d],val);
        out[int64_t(blockIdx.x)*D+d]=T(val/denominator);
    }
}

torch::Tensor paged_forward(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                            torch::Tensor bt, torch::Tensor lens, double scale) {
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim()==3 && k.dim()==4);
    TORCH_CHECK(q.size(1)%k.size(1)==0);
    TORCH_CHECK(q.scalar_type()==k.scalar_type() && q.scalar_type()==v.scalar_type());
    Layout a;
    a.H=q.size(1); a.D=q.size(2); a.K=k.size(1);
    a.BS=k.size(2); a.M=bt.size(1);
    a.P=(a.M*a.BS+TILE-1)/TILE;
    a.q0=q.stride(0);a.q1=q.stride(1);a.q2=q.stride(2);
    a.k0=k.stride(0);a.k1=k.stride(1);a.k2=k.stride(2);a.k3=k.stride(3);
    a.v0=v.stride(0);a.v1=v.stride(1);a.v2=v.stride(2);a.v3=v.stride(3);
    a.b0=bt.stride(0);a.b1=bt.stride(1);a.l0=lens.stride(0);
    int rows=q.size(0)*a.H;
    auto out=torch::empty(q.sizes(),q.options());
    if(rows==0) return out;
    auto tmp=torch::empty({rows,a.P,a.D},q.options().dtype(torch::kFloat32));
    auto stats=torch::empty({rows,a.P,2},q.options().dtype(torch::kFloat32));
    auto stream=at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,at::ScalarType::BFloat16,
                                  q.scalar_type(),"paged_attention",[&] {
        using T=scalar_t;
        #define LAUNCH(I,L) \
            partial_kernel<T,I,L><<<dim3(rows,a.P),256,0,stream>>>( \
                q.data_ptr<T>(),k.data_ptr<T>(),v.data_ptr<T>(), \
                bt.data_ptr<I>(),lens.data_ptr<L>(),tmp.data_ptr<float>(), \
                stats.data_ptr<float>(),a,float(scale));
        if(bt.scalar_type()==at::kLong) {
            if(lens.scalar_type()==at::kLong) { LAUNCH(int64_t,int64_t) }
            else { LAUNCH(int64_t,int32_t) }
        } else {
            if(lens.scalar_type()==at::kLong) { LAUNCH(int32_t,int64_t) }
            else { LAUNCH(int32_t,int32_t) }
        }
        #undef LAUNCH
        merge_kernel<T><<<rows,256,0,stream>>>(
            tmp.data_ptr<float>(),stats.data_ptr<float>(),out.data_ptr<T>(),a.D,a.P);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "paged_decode_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        return _extension().forward(
            query, key_cache, value_cache, block_tables, seq_lens, self.scale
        )
