import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor mla_run(torch::Tensor q, torch::Tensor kv, torch::Tensor cs,
                     torch::Tensor pos, torch::Tensor ptr, torch::Tensor idx,
                     int64_t c, int64_t rd, double scale, bool neox);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &mla_run);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>

struct Ind {
    const void* p;
    bool wide;
    __device__ __forceinline__ int64_t operator[](int64_t i) const {
        return wide ? ((const int64_t*)p)[i] : ((const int32_t*)p)[i];
    }
};

template<typename T>
__device__ __forceinline__ float rotate(const T* x, int d, const T* cs,
                                        int rd, bool neox) {
    float v = float(x[d]);
    if (d >= rd) return v;
    int half = rd / 2;
    bool second = neox ? d >= half : (d & 1);
    int j = neox ? d % half : d / 2;
    int other = neox ? (second ? d-half : d+half) : (d ^ 1);
    float co = float(cs[j]), si = float(cs[half+j]);
    float a = v * co;
    float z = float(x[other]) * si;
    return second ? a + z : a - z;
}

constexpr int TILE = 128;

template<typename T>
__global__ void partial(const T* __restrict__ q, const T* __restrict__ kv,
                        const T* __restrict__ cs, Ind pos, Ind ptr, Ind idx,
                        float* __restrict__ tmp, T* __restrict__ out,
                        int H, int D, int C, int RD, int P,
                        float scale, bool neox, int B) {
    int bh = blockIdx.x, part = blockIdx.y;
    int b = bh / H;
    int t = threadIdx.x;
    int lane = t & 63, wave = t >> 6;
    int64_t start = ptr[b], end = ptr[b+1];
    int64_t lo = start + int64_t(part) * TILE;
    int n = int(min(int64_t(TILE), max(int64_t(0), end-lo)));
    float* dst = tmp + (int64_t(bh)*P + part)*(C+2);
    if (n == 0) {
        for (int d=t; d<C; d+=256) dst[d] = 0.f;
        if (t==0) { dst[C]=-INFINITY; dst[C+1]=0.f; }
        return;
    }
    extern __shared__ float shared[];
    float* qr = shared;
    float* scores = qr + D;
    float* weights = scores + TILE;
    const T* trig = cs + pos[b]*RD;
    const T* query = q + int64_t(bh)*D;
    for (int d=t; d<D; d+=256) {
        qr[d] = d<C ? float(query[d]) : rotate(query+C,d-C,trig,RD,neox);
    }
    if (part==0 && bh%H==0) {
        const T* last = kv + idx[end-1]*D + C;
        for (int d=t; d<D-C; d+=256)
            out[int64_t(B)*H*C + int64_t(b)*(D-C)+d] =
                T(rotate(last,d,trig,RD,neox));
    }
    __syncthreads();
    for (int j=wave; j<n; j+=4) {
        int64_t logical = lo+j;
        const T* key = kv + idx[logical]*D;
        float a=0.f, z=0.f;
        for (int d=lane; d<C; d+=64)
            a = fmaf(qr[d], float(key[d]), a);
        for (int d=lane; d<D-C; d+=64) {
            float k = logical==end-1 ? rotate(key+C,d,trig,RD,neox) : float(key[C+d]);
            z = fmaf(qr[C+d], k, z);
        }
        for (int off=32; off; off>>=1) {
            a += __shfl_down(a,off,64);
            z += __shfl_down(z,off,64);
        }
        if (lane==0) scores[j]=(a+z)*scale;
    }
    __syncthreads();
    if (t==0) {
        float m=-INFINITY;
        for (int j=0;j<n;++j) m=fmaxf(m,scores[j]);
        float s=0.f;
        for (int j=0;j<n;++j) {
            float w=expf(scores[j]-m);
            weights[j]=w;
            s+=w;
        }
        dst[C]=m;
        dst[C+1]=s;
    }
    __syncthreads();
    for (int d=t; d<C; d+=256) {
        float v=0.f;
        for (int j=0;j<n;++j)
            v=fmaf(weights[j],float(kv[idx[lo+j]*D+d]),v);
        dst[d]=v;
    }
}

template<typename T>
__global__ void finish(const float* __restrict__ tmp, T* __restrict__ out,
                       int C, int P) {
    int bh=blockIdx.x, t=threadIdx.x;
    const float* base=tmp+int64_t(bh)*P*(C+2);
    extern __shared__ float w[];
    __shared__ float denom;
    if (t==0) {
        float m=-INFINITY;
        for (int p=0;p<P;++p) m=fmaxf(m,base[p*(C+2)+C]);
        float s=0.f;
        for (int p=0;p<P;++p) {
            float v=expf(base[p*(C+2)+C]-m);
            w[p]=v;
            s+=v*base[p*(C+2)+C+1];
        }
        denom=s;
    }
    __syncthreads();
    for (int d=t;d<C;d+=256) {
        float v=0.f;
        for (int p=0;p<P;++p) v=fmaf(w[p],base[p*(C+2)+d],v);
        out[int64_t(bh)*C+d]=T(v/denom);
    }
}

torch::Tensor mla_run(torch::Tensor q, torch::Tensor kv, torch::Tensor cs,
                     torch::Tensor pos, torch::Tensor ptr, torch::Tensor idx,
                     int64_t c, int64_t rd, double scale, bool neox) {
    c10::cuda::CUDAGuard guard(q.device());
    int B=q.size(0), H=q.size(1), D=q.size(2), C=c;
    // The total logical token count provides a host-known upper bound on every sequence.
    int P=(idx.numel()+TILE-1)/TILE;
    auto out=torch::empty({int64_t(B)*H*C+int64_t(B)*(D-C)},q.options());
    auto temp=torch::empty({int64_t(B)*H*P*(C+2)},q.options().dtype(torch::kFloat32));
    Ind ipos{pos.data_ptr(),pos.scalar_type()==torch::kInt64};
    Ind iptr{ptr.data_ptr(),ptr.scalar_type()==torch::kInt64};
    Ind iidx{idx.data_ptr(),idx.scalar_type()==torch::kInt64};
    auto stream=at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  q.scalar_type(), "mla_decode", [&] {
        partial<scalar_t><<<dim3(B*H,P),256,(D+2*TILE)*sizeof(float),stream>>>(
            q.data_ptr<scalar_t>(),kv.data_ptr<scalar_t>(),cs.data_ptr<scalar_t>(),
            ipos,iptr,iidx,temp.data_ptr<float>(),out.data_ptr<scalar_t>(),
            H,D,C,rd,P,float(scale),neox,B);
        finish<scalar_t><<<B*H,256,P*sizeof(float),stream>>>(
            temp.data_ptr<float>(),out.data_ptr<scalar_t>(),C,P);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "mla_decode_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, kv_lora_rank: int, qk_rope_head_dim: int, rotary_dim: int, sm_scale=None, is_neox_style=True):
        super().__init__()
        self.kv_lora_rank = int(kv_lora_rank)
        self.qk_rope_head_dim = int(qk_rope_head_dim)
        self.rotary_dim = int(rotary_dim)
        self.sm_scale = float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(self.kv_lora_rank + self.qk_rope_head_dim)
        self.is_neox_style = bool(is_neox_style)

    def forward(self, q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices):
        return _extension().run(
            q.contiguous(), kv_cache.contiguous(), cos_sin_cache.contiguous(),
            positions.contiguous(), kv_indptr.contiguous(), kv_indices.contiguous(),
            self.kv_lora_rank, self.rotary_dim, self.sm_scale, self.is_neox_style,
        )
