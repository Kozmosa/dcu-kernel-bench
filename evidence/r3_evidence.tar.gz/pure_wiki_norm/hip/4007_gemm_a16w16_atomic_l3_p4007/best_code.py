import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor linear_hip(torch::Tensor x, torch::Tensor w);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("linear_hip", &linear_hip);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

template<class T>
__global__ void tiled_linear(
    const T* __restrict__ x, const T* __restrict__ w,
    T* __restrict__ y, int M, int N, int K,
    int64_t xs0, int64_t xs1, int64_t ws0, int64_t ws1)
{
    __shared__ float a[32][65];
    __shared__ float b[32][65];
    int tid = threadIdx.x;
    int mr = blockIdx.y * 64;
    int nr = blockIdx.x * 64;
    int tm = tid / 16;
    int tn = tid % 16;
    float acc[4][4] = {};

    for (int kb = 0; kb < K; kb += 32) {
        #pragma unroll
        for (int z = 0; z < 8; ++z) {
            int p = tid + z * 256;
            int r = p / 32;
            int k = p % 32;
            a[k][r] = (mr+r < M && kb+k < K)
                ? float(x[int64_t(mr+r)*xs0 + int64_t(kb+k)*xs1]) : 0.0f;
            b[k][r] = (nr+r < N && kb+k < K)
                ? float(w[int64_t(nr+r)*ws0 + int64_t(kb+k)*ws1]) : 0.0f;
        }
        __syncthreads();
        #pragma unroll
        for (int k = 0; k < 32; ++k) {
            float av[4], bv[4];
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                av[i] = a[k][tm + i*16];
                bv[i] = b[k][tn + i*16];
            }
            #pragma unroll
            for (int i = 0; i < 4; ++i)
                #pragma unroll
                for (int j = 0; j < 4; ++j)
                    acc[i][j] = fmaf(av[i], bv[j], acc[i][j]);
        }
        __syncthreads();
    }
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        int m = mr + tm + i*16;
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            int n = nr + tn + j*16;
            if (m < M && n < N)
                y[int64_t(m)*N+n] = T(acc[i][j]);
        }
    }
}

template<class T>
__global__ void dot_linear(
    const T* __restrict__ x, const T* __restrict__ w,
    T* __restrict__ y, int M, int N, int K,
    int64_t xs0, int64_t xs1, int64_t ws0, int64_t ws1)
{
    int lane = threadIdx.x & 63;
    int64_t idx = int64_t(blockIdx.x)*4 + threadIdx.x/64;
    if (idx >= int64_t(M)*N) return;
    int m = idx/N, n = idx%N;
    float s0 = 0, s1 = 0, s2 = 0, s3 = 0;
    for (int k = lane; k < K; k += 256) {
        s0 = fmaf(float(x[int64_t(m)*xs0+int64_t(k)*xs1]),
                  float(w[int64_t(n)*ws0+int64_t(k)*ws1]), s0);
        if (k+64 < K)
            s1 = fmaf(float(x[int64_t(m)*xs0+int64_t(k+64)*xs1]),
                      float(w[int64_t(n)*ws0+int64_t(k+64)*ws1]), s1);
        if (k+128 < K)
            s2 = fmaf(float(x[int64_t(m)*xs0+int64_t(k+128)*xs1]),
                      float(w[int64_t(n)*ws0+int64_t(k+128)*ws1]), s2);
        if (k+192 < K)
            s3 = fmaf(float(x[int64_t(m)*xs0+int64_t(k+192)*xs1]),
                      float(w[int64_t(n)*ws0+int64_t(k+192)*ws1]), s3);
    }
    float s = (s0+s1)+(s2+s3);
    #pragma unroll
    for (int d = 32; d; d >>= 1)
        s += __shfl_down(s, d, 64);
    if (lane == 0) y[idx] = T(s);
}

torch::Tensor linear_hip(torch::Tensor x, torch::Tensor w) {
    TORCH_CHECK(x.is_cuda() && w.is_cuda(), "Expected accelerator tensors");
    TORCH_CHECK(x.device() == w.device(), "Device mismatch");
    TORCH_CHECK(x.dim()==2 && w.dim()==2, "Expected matrices");
    TORCH_CHECK(x.size(1)==w.size(1), "K dimension mismatch");
    TORCH_CHECK(x.scalar_type()==w.scalar_type(), "Dtype mismatch");
    c10::cuda::CUDAGuard guard(x.device());
    int M=x.size(0), N=w.size(0), K=x.size(1);
    auto y = torch::empty({M,N}, x.options());
    if (M==0 || N==0) return y;
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,
                                  at::ScalarType::BFloat16,
                                  x.scalar_type(), "linear_hip", [&] {
        if (M < 8 || N < 8 || int64_t(M)*N <= 1024) {
            dot_linear<scalar_t><<<
                (int64_t(M)*N+3)/4, 256, 0, stream>>>(
                x.data_ptr<scalar_t>(), w.data_ptr<scalar_t>(),
                y.data_ptr<scalar_t>(), M,N,K,
                x.stride(0),x.stride(1),w.stride(0),w.stride(1));
        } else {
            tiled_linear<scalar_t><<<
                dim3((N+63)/64,(M+63)/64),256,0,stream>>>(
                x.data_ptr<scalar_t>(), w.data_ptr<scalar_t>(),
                y.data_ptr<scalar_t>(), M,N,K,
                x.stride(0),x.stride(1),w.stride(0),w.stride(1));
        }
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return y;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "custom_linear_" + hashlib.sha256(
            (_CPP + _HIP).encode()
        ).hexdigest()[:16]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

    def forward(self, x, weight):
        return _get_extension().linear_hip(x, weight)
