import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXT = None

CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor msda_forward(
    torch::Tensor value,
    torch::Tensor spatial_shapes,
    torch::Tensor level_start_index,
    torch::Tensor sampling_locations,
    torch::Tensor attention_weights);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("msda_forward", &msda_forward, "Fused multi-scale deformable attention forward");
}
"""

HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/Dispatch.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

template <typename T>
__device__ __forceinline__ float as_float(T x) {
    return static_cast<float>(x);
}

template <typename scalar_t>
__global__ void msda_kernel(
    const scalar_t* __restrict__ value,
    const int64_t* __restrict__ shapes,
    const int64_t* __restrict__ starts,
    const scalar_t* __restrict__ locations,
    const scalar_t* __restrict__ weights,
    scalar_t* __restrict__ output,
    int64_t N,
    int64_t Q,
    int64_t Hds,
    int64_t D,
    int64_t L,
    int64_t P,
    int64_t nkeys)
{
    int64_t bhq = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    int64_t total = N * Q * Hds;
    if (bhq >= total) return;

    const int64_t h = bhq % Hds;
    const int64_t tq = bhq / Hds;
    const int64_t q = tq % Q;
    const int64_t n = tq / Q;

    int64_t count = L * P;
    float max_w = -CUDART_INF_F;

    for (int64_t lp = 0; lp < count; ++lp) {
        int64_t l = lp / P;
        int64_t p = lp - l * P;
        int64_t wi = ((((n * Q + q) * Hds + h) * L + l) * P + p);
        float w = as_float(weights[wi]);
        if (w > max_w) max_w = w;
    }

    float sum_w = 0.0f;
    for (int64_t lp = 0; lp < count; ++lp) {
        int64_t l = lp / P;
        int64_t p = lp - l * P;
        int64_t wi = ((((n * Q + q) * Hds + h) * L + l) * P + p);
        float e = expf(as_float(weights[wi]) - max_w);
        sum_w += e;
    }
    float inv_sum = 1.0f / sum_w;

    for (int64_t d = 0; d < D; ++d) {
        float result = 0.0f;

        for (int64_t lp = 0; lp < count; ++lp) {
            int64_t l = lp / P;
            int64_t p = lp - l * P;

            int64_t li = (((((n * Q + q) * Hds + h) * L + l) * P + p) * 2);
            float x = as_float(locations[li]);
            float y = as_float(locations[li + 1]);

            int64_t H = shapes[l * 2];
            int64_t W = shapes[l * 2 + 1];
            int64_t base = starts[l];

            float sx = x * static_cast<float>(W);
            float sy = y * static_cast<float>(H);
            float fx = floorf(sx);
            float fy = floorf(sy);
            int64_t ix = static_cast<int64_t>(fx);
            int64_t iy = static_cast<int64_t>(fy);
            float dx = sx - fx;
            float dy = sy - fy;

            float sampled = 0.0f;

            int64_t x0 = ix;
            int64_t x1 = ix + 1;
            int64_t y0 = iy;
            int64_t y1 = iy + 1;

            float c00 = (1.0f - dy) * (1.0f - dx);
            float c01 = (1.0f - dy) * dx;
            float c10 = dy * (1.0f - dx);
            float c11 = dy * dx;

            if (y0 >= 0 && y0 < H && x0 >= 0 && x0 < W) {
                int64_t vi = (((n * nkeys + base + y0 * W + x0) * Hds + h) * D + d);
                sampled += c00 * as_float(value[vi]);
            }
            if (y0 >= 0 && y0 < H && x1 >= 0 && x1 < W) {
                int64_t vi = (((n * nkeys + base + y0 * W + x1) * Hds + h) * D + d);
                sampled += c01 * as_float(value[vi]);
            }
            if (y1 >= 0 && y1 < H && x0 >= 0 && x0 < W) {
                int64_t vi = (((n * nkeys + base + y1 * W + x0) * Hds + h) * D + d);
                sampled += c10 * as_float(value[vi]);
            }
            if (y1 >= 0 && y1 < H && x1 >= 0 && x1 < W) {
                int64_t vi = (((n * nkeys + base + y1 * W + x1) * Hds + h) * D + d);
                sampled += c11 * as_float(value[vi]);
            }

            int64_t wi = ((((n * Q + q) * Hds + h) * L + l) * P + p);
            float aw = expf(as_float(weights[wi]) - max_w) * inv_sum;
            result += aw * sampled;
        }

        int64_t oi = ((n * Q + q) * Hds + h) * D + d;
        output[oi] = static_cast<scalar_t>(result);
    }
}

torch::Tensor msda_forward(
    torch::Tensor value,
    torch::Tensor spatial_shapes,
    torch::Tensor level_start_index,
    torch::Tensor sampling_locations,
    torch::Tensor attention_weights)
{
    TORCH_CHECK(value.is_cuda(), "value must be on the accelerator");
    TORCH_CHECK(value.is_contiguous(), "value must be contiguous");
    TORCH_CHECK(spatial_shapes.scalar_type() == at::kLong, "spatial_shapes must be int64");
    TORCH_CHECK(level_start_index.scalar_type() == at::kLong, "level_start_index must be int64");
    TORCH_CHECK(spatial_shapes.is_contiguous(), "spatial_shapes must be contiguous");
    TORCH_CHECK(level_start_index.is_contiguous(), "level_start_index must be contiguous");
    TORCH_CHECK(sampling_locations.is_contiguous(), "sampling_locations must be contiguous");
    TORCH_CHECK(attention_weights.is_contiguous(), "attention_weights must be contiguous");
    TORCH_CHECK(value.scalar_type() == sampling_locations.scalar_type(), "dtype mismatch");
    TORCH_CHECK(value.scalar_type() == attention_weights.scalar_type(), "dtype mismatch");

    const auto N = value.size(0);
    const auto nkeys = value.size(1);
    const auto Hds = value.size(2);
    const auto D = value.size(3);
    const auto Q = sampling_locations.size(1);
    const auto L = sampling_locations.size(3);
    const auto P = sampling_locations.size(4);

    auto output = torch::empty_like(value);
    auto stream = at::cuda::getCurrentCUDAStream(value.device().index()).stream();

    int64_t total = N * Q * Hds;
    dim3 block(256);
    dim3 grid((total + block.x - 1) / block.x);

    AT_DISPATCH_FLOATING_TYPES_AND_HALF(
        value.scalar_type(), "msda_forward_cuda", [&] {
            msda_kernel<scalar_t><<<grid, block, 0, stream>>>(
                value.data_ptr<scalar_t>(),
                spatial_shapes.data_ptr<int64_t>(),
                level_start_index.data_ptr<int64_t>(),
                sampling_locations.data_ptr<scalar_t>(),
                attention_weights.data_ptr<scalar_t>(),
                output.data_ptr<scalar_t>(),
                N, Q, Hds, D, L, P, nkeys);
        });

    auto err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "msda kernel launch failed: ", hipGetErrorString(err));
    return output;
}
"""

def _get_extension():
    global _EXT
    if _EXT is None:
        key = hashlib.sha1((CPP_SRC + HIP_SRC).encode("utf-8")).hexdigest()[:16]
        _EXT = load_inline(
            name="msda_hip_" + key,
            cpp_sources=CPP_SRC,
            cuda_sources=HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXT


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, value, spatial_shapes, level_start_index,
                sampling_locations, attention_weights):
        spatial_shapes = spatial_shapes.to(dtype=torch.long).contiguous()
        level_start_index = level_start_index.to(dtype=torch.long).contiguous()

        n, n_keys, num_heads, d = value.shape
        n_levels = spatial_shapes.shape[0]
        n_queries = sampling_locations.shape[1]
        n_points = sampling_locations.shape[4]

        assert sampling_locations.dim() == 6
        assert sampling_locations.shape[0] == n
        assert sampling_locations.shape[2] == num_heads
        assert sampling_locations.shape[3] == n_levels
        assert sampling_locations.shape[5] == 2
        assert attention_weights.shape == (
            n, n_queries, num_heads, n_levels, n_points
        )

        expected_keys = int((spatial_shapes[:, 0] * spatial_shapes[:, 1]).sum().item())
        assert n_keys == expected_keys

        value = value.contiguous()
        sampling_locations = sampling_locations.contiguous()
        attention_weights = attention_weights.contiguous()

        return _get_extension().msda_forward(
            value,
            spatial_shapes,
            level_start_index,
            sampling_locations,
            attention_weights,
        )
