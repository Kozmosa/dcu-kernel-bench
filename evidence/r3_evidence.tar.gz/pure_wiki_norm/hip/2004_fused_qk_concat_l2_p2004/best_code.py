import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
void packed_rope(torch::Tensor qn, torch::Tensor qp,
                 torch::Tensor kn, torch::Tensor kp,
                 torch::Tensor pos, torch::Tensor cs, torch::Tensor sn,
                 torch::Tensor out, bool neox, bool rope);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("packed_rope", &packed_rope);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

__device__ __forceinline__ int64_t read_position(
    const void* p, int b, int type) {
    if (type == 0) return static_cast<const int64_t*>(p)[b];
    if (type == 1) return static_cast<const int32_t*>(p)[b];
    if (type == 2) return (int64_t)static_cast<const float*>(p)[b];
    if (type == 3) return (int64_t)static_cast<const double*>(p)[b];
    if (type == 4) return (int64_t)(float)static_cast<const at::Half*>(p)[b];
    return (int64_t)(float)static_cast<const at::BFloat16*>(p)[b];
}

template<class T, bool NEOX, bool ROPE>
__global__ void packed_kernel(
    const T* __restrict__ qn, const T* __restrict__ qp,
    const T* __restrict__ kn, const T* __restrict__ kp,
    const void* __restrict__ pos,
    const T* __restrict__ cs, const T* __restrict__ sn,
    T* __restrict__ out,
    int qh, int kh, int dn, int dp, int df,
    int64_t count, int pos_type) {
    int64_t index = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (index >= count) return;

    const int width = dn + dp;
    const int heads = qh + kh;
    const int d = index % width;
    const int64_t row = index / width;
    const int h = row % heads;
    const int b = row / heads;
    const bool isq = h < qh;
    const int64_t source_row = isq
        ? (int64_t)b * qh + h
        : (int64_t)b * kh + h - qh;

    if (d < dn) {
        const T* src = isq ? qn : kn;
        out[index] = src[source_row * dn + d];
        return;
    }

    const T* src = (isq ? qp : kp) + source_row * dp;
    const int j = d - dn;
    if (!ROPE) {
        out[index] = src[j];
        return;
    }

    const int half = dp / 2;
    const bool negative = NEOX ? (j < half) : ((j & 1) == 0);
    const int partner = NEOX ? (negative ? j + half : j - half) : (j ^ 1);
    const int freq = df == dp ? j : (NEOX ? (j < half ? j : j - half) : j / 2);
    const int64_t table_index = read_position(pos, b, pos_type) * df + freq;
    const float x = (float)src[j];
    const float y = negative ? -(float)src[partner] : (float)src[partner];
    const float a = x * (float)cs[table_index];
    const float z = y * (float)sn[table_index];
    out[index] = (T)(a + z);
}

void packed_rope(torch::Tensor qn, torch::Tensor qp,
                 torch::Tensor kn, torch::Tensor kp,
                 torch::Tensor pos, torch::Tensor cs, torch::Tensor sn,
                 torch::Tensor out, bool neox, bool rope) {
    c10::cuda::CUDAGuard guard(qn.device());
    const int qh = qn.size(1), kh = kn.size(1);
    const int dn = qn.size(2), dp = qp.size(2), df = cs.size(-1);
    const int64_t count = out.numel();
    if (!count) return;
    int pt = 0;
    switch (pos.scalar_type()) {
        case at::kLong: pt = 0; break;
        case at::kInt: pt = 1; break;
        case at::kFloat: pt = 2; break;
        case at::kDouble: pt = 3; break;
        case at::kHalf: pt = 4; break;
        case at::kBFloat16: pt = 5; break;
        default: TORCH_CHECK(false, "Unsupported position dtype");
    }
    auto stream = at::cuda::getCurrentCUDAStream();
    const dim3 grid((count + 255) / 256);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16,
                                  qn.scalar_type(), "packed_rope", [&] {
        const auto launch = [&](auto n, auto r) {
            packed_kernel<scalar_t, decltype(n)::value, decltype(r)::value>
                <<<grid, 256, 0, stream>>>(
                    qn.data_ptr<scalar_t>(), qp.data_ptr<scalar_t>(),
                    kn.data_ptr<scalar_t>(), kp.data_ptr<scalar_t>(),
                    pos.data_ptr(), cs.data_ptr<scalar_t>(), sn.data_ptr<scalar_t>(),
                    out.data_ptr<scalar_t>(), qh, kh, dn, dp, df, count, pt);
        };
        if (!rope) launch(std::false_type{}, std::false_type{});
        else if (neox) launch(std::true_type{}, std::true_type{});
        else launch(std::false_type{}, std::true_type{});
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "packed_rope_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, is_neox: bool = True, apply_rope: bool = True):
        super().__init__()
        self.is_neox = bool(is_neox)
        self.apply_rope = bool(apply_rope)

    def forward(self, q_nope, q_pe, k_nope, k_pe, pos, cos, sin):
        b, qh, dn = q_nope.shape
        kh = k_nope.shape[1]
        dp = q_pe.shape[2]
        out = torch.empty(
            (b, qh + kh, dn + dp),
            dtype=q_nope.dtype,
            device=q_nope.device,
        )
        _extension().packed_rope(
            q_nope, q_pe, k_nope, k_pe, pos, cos, sin,
            out, self.is_neox, self.apply_rope,
        )
        return out
