import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor run(torch::Tensor dy, torch::Tensor w, torch::Tensor x,
                  bool wg, int sh, int sw, int ph, int pw, int dh, int dw);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

struct Params {
    int B,C,H,W,K,R,S,P,Q;
    int sh,sw,ph,pw,dh,dw;
};

template<bool WG>
__global__ void product(const float* __restrict__ dy,
                        const float* __restrict__ w,
                        const float* __restrict__ x,
                        float* __restrict__ out,
                        Params p, int M, int N, int reduction, int chunk) {
    __shared__ float a[32][17];
    __shared__ float b[16][33];
    int tx=threadIdx.x & 15, ty=threadIdx.x >> 4;
    int row=blockIdx.y*32+ty;
    int col=blockIdx.x*32+tx;
    int batch=WG ? 0 : blockIdx.z;
    int first=WG ? blockIdx.z*chunk : 0;
    int last=WG ? min(first+chunk,reduction) : reduction;
    float v00=0, v01=0, v10=0, v11=0;
    for(int base=first;base<last;base+=16) {
        #pragma unroll
        for(int t=0;t<2;++t) {
            int i=threadIdx.x+t*256;
            int ar=i/16, ak=i%16;
            int m=blockIdx.y*32+ar, k=base+ak;
            float av=0;
            if(m<M && k<last) {
                if(WG) {
                    av=dy[((int64_t)(k/(p.P*p.Q))*p.K+m)*(p.P*p.Q)+k%(p.P*p.Q)];
                } else {
                    int oc=k/(p.R*p.S), rs=k%(p.R*p.S);
                    av=w[((int64_t)oc*p.C+m)*(p.R*p.S)+rs];
                }
            }
            a[ar][ak]=av;

            int bk=i/32, bc=i%32;
            int n=blockIdx.x*32+bc;
            k=base+bk;
            float bv=0;
            if(n<N && k<last) {
                if(WG) {
                    int ic=n/(p.R*p.S);
                    int rs=n%(p.R*p.S);
                    int spatial=k%(p.P*p.Q);
                    int ih=(spatial/p.Q)*p.sh-p.ph+(rs/p.S)*p.dh;
                    int iw=(spatial%p.Q)*p.sw-p.pw+(rs%p.S)*p.dw;
                    if((unsigned)ih<(unsigned)p.H && (unsigned)iw<(unsigned)p.W)
                        bv=x[(((int64_t)(k/(p.P*p.Q))*p.C+ic)*p.H+ih)*p.W+iw];
                } else {
                    int oc=k/(p.R*p.S), rs=k%(p.R*p.S);
                    int oh=n/p.W+p.ph-(rs/p.S)*p.dh;
                    int ow=n%p.W+p.pw-(rs%p.S)*p.dw;
                    if(oh>=0 && ow>=0 && oh%p.sh==0 && ow%p.sw==0) {
                        oh/=p.sh; ow/=p.sw;
                        if(oh<p.P && ow<p.Q)
                            bv=dy[(((int64_t)batch*p.K+oc)*p.P+oh)*p.Q+ow];
                    }
                }
            }
            b[bk][bc]=bv;
        }
        __syncthreads();
        #pragma unroll
        for(int k=0;k<16;++k) {
            float a0=a[ty][k], a1=a[ty+16][k];
            float b0=b[k][tx], b1=b[k][tx+16];
            v00=fmaf(a0,b0,v00);
            v01=fmaf(a0,b1,v01);
            v10=fmaf(a1,b0,v10);
            v11=fmaf(a1,b1,v11);
        }
        __syncthreads();
    }
    int64_t offset=(int64_t)blockIdx.z*M*N;
    if(row<M && col<N) out[offset+(int64_t)row*N+col]=v00;
    if(row<M && col+16<N) out[offset+(int64_t)row*N+col+16]=v01;
    if(row+16<M && col<N) out[offset+(int64_t)(row+16)*N+col]=v10;
    if(row+16<M && col+16<N) out[offset+(int64_t)(row+16)*N+col+16]=v11;
}

__global__ void finish(const float* __restrict__ partial,
                       float* __restrict__ out, int64_t size, int splits) {
    int64_t i=(int64_t)blockIdx.x*256+threadIdx.x;
    if(i<size) {
        float sum=0;
        for(int s=0;s<splits;++s) sum+=partial[(int64_t)s*size+i];
        out[i]=sum;
    }
}

torch::Tensor run(torch::Tensor dy, torch::Tensor w, torch::Tensor x,
                  bool wg, int sh, int sw, int ph, int pw, int dh, int dw) {
    c10::cuda::CUDAGuard guard(dy.device());
    Params p;
    p.B=x.size(0); p.C=x.size(1); p.H=x.size(2); p.W=x.size(3);
    p.K=w.size(0); p.R=w.size(2); p.S=w.size(3);
    p.P=dy.size(2); p.Q=dy.size(3);
    p.sh=sh; p.sw=sw; p.ph=ph; p.pw=pw; p.dh=dh; p.dw=dw;
    auto out=torch::empty(wg?w.sizes():x.sizes(), x.options());
    auto stream=at::cuda::getCurrentCUDAStream();
    if(wg) {
        int M=p.K, N=p.C*p.R*p.S, reduction=p.B*p.P*p.Q;
        int chunk=512;
        int splits=(reduction+chunk-1)/chunk;
        // Bound scratch space while preserving ample parallelism.
        int64_t size=(int64_t)M*N;
        while(splits>1 && size*splits>33554432) {
            chunk*=2;
            splits=(reduction+chunk-1)/chunk;
        }
        if(splits==1) {
            product<true><<<dim3((N+31)/32,(M+31)/32,1),256,0,stream>>>(
                dy.data_ptr<float>(),w.data_ptr<float>(),x.data_ptr<float>(),
                out.data_ptr<float>(),p,M,N,reduction,chunk);
        } else {
            auto temp=torch::empty({splits,M,N},x.options());
            product<true><<<dim3((N+31)/32,(M+31)/32,splits),256,0,stream>>>(
                dy.data_ptr<float>(),w.data_ptr<float>(),x.data_ptr<float>(),
                temp.data_ptr<float>(),p,M,N,reduction,chunk);
            finish<<<(size+255)/256,256,0,stream>>>(
                temp.data_ptr<float>(),out.data_ptr<float>(),size,splits);
        }
    } else {
        int M=p.C, N=p.H*p.W, reduction=p.K*p.R*p.S;
        product<false><<<dim3((N+31)/32,(M+31)/32,p.B),256,0,stream>>>(
            dy.data_ptr<float>(),w.data_ptr<float>(),x.data_ptr<float>(),
            out.data_ptr<float>(),p,M,N,reduction,reduction);
    }
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "direct_grad_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1, pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        assert variant in ("dgrad", "wgrad")
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)

    def forward(self, dy, weight, x):
        return _get_extension().run(
            dy, weight, x, self.variant == "wgrad",
            self.stride_h, self.stride_w,
            self.pad_h, self.pad_w,
            self.dil_h, self.dil_w,
        )
