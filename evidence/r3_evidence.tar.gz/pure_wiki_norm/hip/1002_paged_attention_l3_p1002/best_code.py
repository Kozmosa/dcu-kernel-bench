import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_decode(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                           torch::Tensor tables, torch::Tensor lengths, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_decode", &paged_decode);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cmath>
#include <cstdint>

constexpr int NT = 128;
constexpr int CHUNK = 256;

struct Layout {
    int H, D, HK, BS, P;
    int64_t q0, q1, q2;
    int64_t k0, k1, k2, k3;
    int64_t v0, v1, v2, v3;
    int64_t t0, t1, l0;
};

__device__ __forceinline__ int64_t index_read(const void* p, int64_t i, bool wide) {
    return wide ? static_cast<const int64_t*>(p)[i]
                : static_cast<const int32_t*>(p)[i];
}

__global__ void partial_attention(
    const float* __restrict__ q, const float* __restrict__ k,
    const float* __restrict__ v, const void* tables, const void* lengths,
    float* __restrict__ tmp, Layout a, float scale, bool twide, bool lwide)
{
    int h = blockIdx.x;
    int s = blockIdx.y;
    int part = blockIdx.z;
    int tid = threadIdx.x;
    int lane = tid & 63;
    int wave = tid >> 6;
    int len = (int)index_read(lengths, (int64_t)s * a.l0, lwide);
    int begin = part * CHUNK;
    int count = min(CHUNK, max(0, len - begin));
    int kh = h / (a.H / a.HK);
    int64_t base = ((int64_t(s) * a.H + h) * a.P + part) * (a.D + 2);

    if (count == 0) {
        for (int d = tid; d < a.D; d += NT) tmp[base + d] = 0.0f;
        if (tid == 0) {
            tmp[base + a.D] = -INFINITY;
            tmp[base + a.D + 1] = 0.0f;
        }
        return;
    }

    extern __shared__ float storage[];
    float* qs = storage;
    float* scores = qs + a.D;
    float* red = scores + CHUNK;
    for (int d = tid; d < a.D; d += NT)
        qs[d] = q[(int64_t)s*a.q0 + (int64_t)h*a.q1 + (int64_t)d*a.q2] * scale;
    __syncthreads();

    for (int t = wave; t < count; t += 2) {
        int pos = begin + t;
        int64_t page = index_read(tables, (int64_t)s*a.t0 +
                                  (int64_t)(pos / a.BS)*a.t1, twide);
        int64_t kb = page*a.k0 + (int64_t)kh*a.k1 + (pos % a.BS)*a.k2;
        float dot = 0.0f;
        for (int d = lane; d < a.D; d += 64)
            dot = fmaf(qs[d], k[kb + (int64_t)d*a.k3], dot);
        for (int delta = 32; delta; delta >>= 1)
            dot += __shfl_down(dot, delta, 64);
        if (lane == 0) scores[t] = dot;
    }
    __syncthreads();

    float mx = -INFINITY;
    for (int t = tid; t < count; t += NT) mx = fmaxf(mx, scores[t]);
    red[tid] = mx;
    __syncthreads();
    for (int stride = NT/2; stride; stride >>= 1) {
        if (tid < stride) red[tid] = fmaxf(red[tid], red[tid + stride]);
        __syncthreads();
    }
    mx = red[0];
    float sum = 0.0f;
    for (int t = tid; t < count; t += NT) {
        float e = expf(scores[t] - mx);
        scores[t] = e;
        sum += e;
    }
    __syncthreads();
    red[tid] = sum;
    __syncthreads();
    for (int stride = NT/2; stride; stride >>= 1) {
        if (tid < stride) red[tid] += red[tid + stride];
        __syncthreads();
    }
    if (tid == 0) {
        tmp[base + a.D] = mx;
        tmp[base + a.D + 1] = red[0];
    }
    for (int d = tid; d < a.D; d += NT) {
        float acc = 0.0f;
        for (int t = 0; t < count; ++t) {
            int pos = begin + t;
            int64_t page = index_read(tables, (int64_t)s*a.t0 +
                                      (int64_t)(pos / a.BS)*a.t1, twide);
            int64_t vb = page*a.v0 + (int64_t)kh*a.v1 +
                         (pos % a.BS)*a.v2 + (int64_t)d*a.v3;
            acc = fmaf(scores[t], v[vb], acc);
        }
        tmp[base + d] = acc;
    }
}

__global__ void combine(const float* __restrict__ tmp, float* __restrict__ out,
                        int D, int P) {
    int row = blockIdx.x;
    int tid = threadIdx.x;
    extern __shared__ float weights[];
    __shared__ float inv;
    int64_t base = (int64_t)row * P * (D + 2);
    if (tid == 0) {
        float mx = -INFINITY;
        for (int p = 0; p < P; ++p)
            mx = fmaxf(mx, tmp[base + (int64_t)p*(D+2) + D]);
        float den = 0.0f;
        for (int p = 0; p < P; ++p) {
            int64_t off = base + (int64_t)p*(D+2);
            float z = tmp[off + D + 1];
            float w = z > 0.0f ? expf(tmp[off + D] - mx) : 0.0f;
            weights[p] = w;
            den += w * z;
        }
        inv = den > 0.0f ? 1.0f / den : 0.0f;
    }
    __syncthreads();
    for (int d = tid; d < D; d += blockDim.x) {
        float acc = 0.0f;
        for (int p = 0; p < P; ++p)
            acc = fmaf(weights[p], tmp[base + (int64_t)p*(D+2) + d], acc);
        out[(int64_t)row*D+d] = acc * inv;
    }
}

torch::Tensor paged_decode(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                           torch::Tensor tables, torch::Tensor lengths, double scale) {
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.scalar_type() == at::kFloat && k.scalar_type() == at::kFloat &&
                v.scalar_type() == at::kFloat, "Expected float32 Q/K/V");
    TORCH_CHECK((tables.scalar_type() == at::kInt || tables.scalar_type() == at::kLong) &&
                (lengths.scalar_type() == at::kInt || lengths.scalar_type() == at::kLong),
                "Expected int32 or int64 indexing tensors");
    int B=q.size(0), H=q.size(1), D=q.size(2);
    TORCH_CHECK(k.size(1) > 0 && H % k.size(1) == 0, "Invalid GQA head count");
    int P = std::max<int64_t>(1, (tables.size(1)*k.size(2)+CHUNK-1)/CHUNK);
    Layout a{H,D,(int)k.size(1),(int)k.size(2),P,
             q.stride(0),q.stride(1),q.stride(2),
             k.stride(0),k.stride(1),k.stride(2),k.stride(3),
             v.stride(0),v.stride(1),v.stride(2),v.stride(3),
             tables.stride(0),tables.stride(1),lengths.stride(0)};
    auto out = torch::empty({B,H,D}, q.options());
    if (!B || !H || !D) return out;
    auto tmp = torch::empty({B,H,P,D+2}, q.options());
    auto stream = at::cuda::getCurrentCUDAStream();
    partial_attention<<<dim3(H,B,P),NT,(D+CHUNK+NT)*sizeof(float),stream>>>(
        q.data_ptr<float>(), k.data_ptr<float>(), v.data_ptr<float>(),
        tables.data_ptr(), lengths.data_ptr(), tmp.data_ptr<float>(), a,
        (float)scale, tables.scalar_type()==at::kLong, lengths.scalar_type()==at::kLong);
    combine<<<B*H,NT,P*sizeof(float),stream>>>(
        tmp.data_ptr<float>(),out.data_ptr<float>(),D,P);
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "paged_decode_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        return _get_extension().paged_decode(
            query, key_cache, value_cache, block_tables, seq_lens, self.scale
        )
