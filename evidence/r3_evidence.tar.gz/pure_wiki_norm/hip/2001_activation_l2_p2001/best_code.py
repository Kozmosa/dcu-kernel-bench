import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor gated_fp4(torch::Tensor x, int64_t activation);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("gated_fp4", &gated_fp4);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>

template<int A>
__device__ __forceinline__ float activate(float x) {
    if constexpr (A == 0) {
        return x / (1.0f + expf(-x));
    } else if constexpr (A == 1) {
        return (x * 0.5f) *
               (1.0f + erff(x * 0.70710678118654752440f));
    } else {
        const float cube = (x * x) * x;
        const float inner = 0.79788456080286535588f *
                            (x + 0.044715f * cube);
        return (0.5f * x) * (1.0f + tanhf(inner));
    }
}

__device__ __forceinline__ unsigned quantize(float q) {
    const unsigned bits = __float_as_uint(q);
    const unsigned e = (bits >> 23) & 255u;
    unsigned m = bits & 0x7fffffu;
    if (e < 127u) {
        unsigned shift = 126u - e;
        m = shift >= 32u ? 0u : ((0x400000u | (m >> 1)) >> shift);
    }
    unsigned ep = e > 126u ? e - 126u : 0u;
    unsigned code = (((ep << 2) | (m >> 21)) + 1u) >> 1;
    return ((bits >> 28) & 8u) | (code < 7u ? code : 7u);
}

template<typename T, int A>
__global__ void fused(const T* __restrict__ x,
                      unsigned char* __restrict__ y,
                      int64_t d, int64_t nb, int64_t total) {
    const int lane = threadIdx.x & 31;
    const int64_t group =
        (static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x) >> 5;
    if (group >= total) return;
    const int64_t row = group / nb;
    const int64_t block = group - row * nb;
    const int64_t col = block * 32 + lane;
    float value = 0.0f;
    if (col < d) {
        float a = static_cast<float>(x[row * (2 * d) + col]);
        float b = static_cast<float>(x[row * (2 * d) + d + col]);
        value = activate<A>(a) * b;
    }
    float mx = fabsf(value);
    #pragma unroll
    for (int delta = 16; delta > 0; delta >>= 1)
        mx = fmaxf(mx, __shfl_xor(mx, delta, 32));

    unsigned rounded = (__float_as_uint(mx) + 0x200000u) & 0xff800000u;
    int scale = static_cast<int>((rounded >> 23) & 255u) - 129;
    scale = scale < -127 ? -127 : (scale > 127 ? 127 : scale);
    float multiplier = scale == 127
        ? __uint_as_float(0x00400000u)
        : __uint_as_float(static_cast<unsigned>(127 - scale) << 23);
    unsigned code = quantize(value * multiplier);
    unsigned other = __shfl_down(code, 1, 32);
    int64_t stride = d / 2 + nb;
    if ((lane & 1) == 0 && col < d)
        y[row * stride + col / 2] =
            static_cast<unsigned char>(code | (other << 4));
    if (lane == 0)
        y[row * stride + d / 2 + block] =
            static_cast<unsigned char>(scale + 127);
}

template<typename T>
void dispatch(const torch::Tensor& x, torch::Tensor& out,
              int activation, int64_t d, int64_t nb,
              hipStream_t stream) {
    int64_t total = x.size(0) * nb;
    if (!total) return;
    dim3 grid((total + 7) / 8);
    dim3 threads(256);
    const T* ptr = x.data_ptr<T>();
    auto dst = out.data_ptr<unsigned char>();
    if (activation == 0)
        fused<T, 0><<<grid, threads, 0, stream>>>(ptr, dst, d, nb, total);
    else if (activation == 1)
        fused<T, 1><<<grid, threads, 0, stream>>>(ptr, dst, d, nb, total);
    else
        fused<T, 2><<<grid, threads, 0, stream>>>(ptr, dst, d, nb, total);
}

torch::Tensor gated_fp4(torch::Tensor x, int64_t activation) {
    TORCH_CHECK(x.is_cuda() && x.dim() == 2 && x.is_contiguous(),
                "Expected a contiguous device matrix");
    TORCH_CHECK(x.size(1) % 4 == 0, "N must be a multiple of 4");
    c10::cuda::CUDAGuard guard(x.device());
    int64_t d = x.size(1) / 2;
    int64_t nb = (d + 31) / 32;
    auto out = torch::empty({x.size(0), d / 2 + nb},
                           x.options().dtype(torch::kUInt8));
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    if (x.scalar_type() == torch::kFloat32)
        dispatch<float>(x, out, activation, d, nb, stream);
    else if (x.scalar_type() == torch::kFloat16)
        dispatch<at::Half>(x, out, activation, d, nb, stream);
    else if (x.scalar_type() == torch::kBFloat16)
        dispatch<at::BFloat16>(x, out, activation, d, nb, stream);
    else
        TORCH_CHECK(false, "Unsupported dtype");
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "gated_mxfp4_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, activation: str = "silu"):
        super().__init__()
        assert activation in ("silu", "gelu", "gelu_tanh"), (
            "activation must be one of silu / gelu / gelu_tanh"
        )
        self.activation = activation

    def forward(self, x):
        return _extension().gated_fp4(
            x, {"silu": 0, "gelu": 1, "gelu_tanh": 2}[self.activation]
        )
