import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXTENSION = None

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor bn_inference(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor mean,
    torch::Tensor variance,
    double eps);

torch::Tensor bn_training(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor running_mean,
    torch::Tensor running_var,
    double eps,
    double momentum);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("bn_inference", &bn_inference);
    m.def("bn_training", &bn_training);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/ATen.h>
#include <ATen/Dispatch.h>
#include <c10/cuda/CUDAStream.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

namespace {

constexpr int THREADS = 256;

template <typename scalar_t>
__global__ void inference_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ scale,
    const scalar_t* __restrict__ bias,
    const scalar_t* __restrict__ mean,
    const scalar_t* __restrict__ variance,
    scalar_t* __restrict__ out,
    int64_t total,
    int64_t c,
    int64_t hw,
    float eps)
{
    int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    int64_t stride = static_cast<int64_t>(blockDim.x) * gridDim.x;

    for (; i < total; i += stride) {
        int64_t ch = (i / hw) % c;
        float xv = static_cast<float>(x[i]);
        float sv = static_cast<float>(scale[ch]);
        float bv = static_cast<float>(bias[ch]);
        float mv = static_cast<float>(mean[ch]);
        float vv = static_cast<float>(variance[ch]);
        float y = (xv - mv) * rsqrtf(vv + eps) * sv + bv;
        out[i] = static_cast<scalar_t>(y);
    }
}

__global__ void stats_kernel(
    const float* __restrict__ x,
    float* __restrict__ batch_mean,
    float* __restrict__ batch_var,
    int64_t n,
    int64_t c,
    int64_t hw)
{
    int ch = blockIdx.x;
    if (ch >= c) return;

    __shared__ float partial[THREADS];
    float sum = 0.0f;

    int tid = threadIdx.x;
    int64_t m = n * hw;

    for (int64_t k = tid; k < m; k += THREADS) {
        int64_t ni = k / hw;
        int64_t qi = k - ni * hw;
        int64_t idx = (ni * c + ch) * hw + qi;
        sum += x[idx];
    }

    partial[tid] = sum;
    __syncthreads();

    for (int s = THREADS / 2; s > 0; s >>= 1) {
        if (tid < s) partial[tid] += partial[tid + s];
        __syncthreads();
    }

    float mean = partial[0] / static_cast<float>(m);
    if (tid == 0) batch_mean[ch] = mean;
    __syncthreads();

    float ss = 0.0f;
    for (int64_t k = tid; k < m; k += THREADS) {
        int64_t ni = k / hw;
        int64_t qi = k - ni * hw;
        int64_t idx = (ni * c + ch) * hw + qi;
        float d = x[idx] - mean;
        ss += d * d;
    }

    partial[tid] = ss;
    __syncthreads();

    for (int s = THREADS / 2; s > 0; s >>= 1) {
        if (tid < s) partial[tid] += partial[tid + s];
        __syncthreads();
    }

    if (tid == 0) {
        batch_var[ch] = partial[0] / static_cast<float>(m);
    }
}

__global__ void training_output_kernel(
    const float* __restrict__ x,
    const float* __restrict__ scale,
    const float* __restrict__ bias,
    const float* __restrict__ running_mean,
    const float* __restrict__ running_var,
    const float* __restrict__ batch_mean,
    const float* __restrict__ batch_var,
    float* __restrict__ out,
    int64_t total,
    int64_t n,
    int64_t c,
    int64_t hw,
    float eps,
    float momentum)
{
    int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    int64_t stride = static_cast<int64_t>(blockDim.x) * gridDim.x;
    int64_t m = n * hw;
    int64_t base = total;

    for (; i < total; i += stride) {
        int64_t ch = (i / hw) % c;
        float bm = batch_mean[ch];
        float bv = batch_var[ch];
        float y = (x[i] - bm) * rsqrtf(bv + eps) * scale[ch] + bias[ch];
        out[i] = y;
    }

    for (int64_t ch = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
         ch < c;
         ch += stride) {
        float bm = batch_mean[ch];
        float bv = batch_var[ch];
        out[base + ch] = bm;
        out[base + c + ch] = rsqrtf(bv + eps);
        out[base + 2 * c + ch] =
            (1.0f - momentum) * running_mean[ch] + momentum * bm;
        out[base + 3 * c + ch] =
            (1.0f - momentum) * running_var[ch] +
            momentum * bv * (static_cast<float>(m) / static_cast<float>(m - 1));
    }
}

inline int blocks_for(int64_t elements) {
    int64_t b = (elements + THREADS - 1) / THREADS;
    if (b < 1) b = 1;
    if (b > 4096) b = 4096;
    return static_cast<int>(b);
}

} // namespace

torch::Tensor bn_inference(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor mean,
    torch::Tensor variance,
    double eps)
{
    const auto n = x.size(0);
    const auto c = x.size(1);
    const auto h = x.size(2);
    const auto w = x.size(3);
    const int64_t total = n * c * h * w;
    const int64_t hw = h * w;

    auto out = torch::empty_like(x);
    auto stream = c10::cuda::getDefaultCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::Half, at::BFloat16, x.scalar_type(), "bn_inference_hip", [&] {
            inference_kernel<scalar_t><<<blocks_for(total), THREADS, 0, stream.stream()>>>(
                x.data_ptr<scalar_t>(),
                scale.data_ptr<scalar_t>(),
                bias.data_ptr<scalar_t>(),
                mean.data_ptr<scalar_t>(),
                variance.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(),
                total, c, hw, static_cast<float>(eps));
        });

    return out;
}

torch::Tensor bn_training(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor running_mean,
    torch::Tensor running_var,
    double eps,
    double momentum)
{
    const auto n = x.size(0);
    const auto c = x.size(1);
    const auto h = x.size(2);
    const auto w = x.size(3);
    const int64_t total = n * c * h * w;
    const int64_t hw = h * w;
    const int64_t m = n * hw;

    auto opts = torch::TensorOptions().device(x.device()).dtype(torch::kFloat32);
    auto batch_mean = torch::empty({c}, opts);
    auto batch_var = torch::empty({c}, opts);
    auto out = torch::empty({total + 4 * c}, opts);

    auto stream = c10::cuda::getDefaultCUDAStream();

    stats_kernel<<<static_cast<int>(c), THREADS, 0, stream.stream()>>>(
        x.data_ptr<float>(),
        batch_mean.data_ptr<float>(),
        batch_var.data_ptr<float>(),
        n, c, hw);

    training_output_kernel<<<blocks_for(total + c), THREADS, 0, stream.stream()>>>(
        x.data_ptr<float>(),
        scale.data_ptr<float>(),
        bias.data_ptr<float>(),
        running_mean.data_ptr<float>(),
        running_var.data_ptr<float>(),
        batch_mean.data_ptr<float>(),
        batch_var.data_ptr<float>(),
        out.data_ptr<float>(),
        total, n, c, hw,
        static_cast<float>(eps),
        static_cast<float>(momentum));

    return out;
}
"""

def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((CUDA_CPP_SRC + CUDA_CU_SRC).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="bn_hip_fast_" + digest,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "training", eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        assert variant in ("inference", "training"), "variant must be one of inference / training"
        assert eps > 0, "eps must be positive"
        assert 0.0 <= momentum <= 1.0, "momentum must be in [0, 1]"
        self.variant = variant
        self.eps = float(eps)
        self.momentum = float(momentum)

    def forward(self, x, scale, bias, mean, variance):
        ext = _get_extension()
        if self.variant == "inference":
            return ext.bn_inference(
                x.contiguous(),
                scale.contiguous(),
                bias.contiguous(),
                mean.contiguous(),
                variance.contiguous(),
                self.eps,
            )

        m = x.shape[0] * x.shape[2] * x.shape[3]
        assert m >= 2, "the training variant requires N*H*W >= 2"

        return ext.bn_training(
            x.contiguous(),
            scale.contiguous(),
            bias.contiguous(),
            mean.contiguous(),
            variance.contiguous(),
            self.eps,
            self.momentum,
        )
