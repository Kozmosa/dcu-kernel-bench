import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _rmsnorm_kernel(
    inp_ptr,
    res_ptr,
    weight_ptr,
    out_ptr,
    n_elements,
    eps,
    BLOCK: tl.constexpr,
):
    pid = tl.program_id(0)
    lanes = tl.arange(0, BLOCK)

    acc = tl.zeros([BLOCK], dtype=tl.float32)
    for base in tl.range(0, n_elements, BLOCK):
        offs = pid * n_elements + base + lanes
        mask = lanes + base < n_elements
        a = tl.load(inp_ptr + offs, mask=mask, other=0.0).to(tl.float32)
        b = tl.load(res_ptr + offs, mask=mask, other=0.0).to(tl.float32)
        v = a + b
        acc += v * v

    row_sum = tl.sum(acc, axis=0)
    inv_rms = tl.rsqrt(row_sum / n_elements + eps)

    for base in tl.range(0, n_elements, BLOCK):
        offs = pid * n_elements + base + lanes
        mask = lanes + base < n_elements
        a = tl.load(inp_ptr + offs, mask=mask, other=0.0).to(tl.float32)
        b = tl.load(res_ptr + offs, mask=mask, other=0.0).to(tl.float32)
        w = tl.load(weight_ptr + base + lanes, mask=mask, other=0.0).to(tl.float32)
        v = (a + b) * inv_rms * w
        tl.store(out_ptr + offs, v, mask=mask)


@triton.jit
def _mxfp4_quant_kernel(
    norm_ptr,
    out_ptr,
    n_elements,
    n_bytes,
    n_blocks,
    BLOCK_BYTES: tl.constexpr,
):
    pid = tl.program_id(0)
    lanes = tl.arange(0, BLOCK_BYTES)

    for byte_base in tl.range(0, n_bytes, BLOCK_BYTES):
        byte_idx = byte_base + lanes
        valid_byte = byte_idx < n_bytes

        elem0 = byte_idx * 2
        block_idx = byte_idx // 16
        block_start = block_idx * 32
        block_offsets = block_start + tl.arange(0, 32)
        block_mask = block_offsets < n_elements

        block_vals = tl.load(
            norm_ptr + pid * n_elements + block_offsets,
            mask=block_mask,
            other=0.0,
        ).to(tl.float32)
        amax = tl.max(tl.abs(block_vals), axis=0)

        amax_bits = tl.cast(amax, tl.int32, bitcast=True)
        rounded_bits = (amax_bits + 0x200000) & (-0x00800000)
        rounded_exp = (rounded_bits >> 23) & 0xFF
        scale_exp = rounded_exp - 127 - 2
        scale_exp = tl.maximum(scale_exp, -127)
        scale_exp = tl.minimum(scale_exp, 127)

        scale_byte = scale_exp + 127

        x0 = tl.load(
            norm_ptr + pid * n_elements + elem0,
            mask=valid_byte & (elem0 < n_elements),
            other=0.0,
        ).to(tl.float32)
        x1 = tl.load(
            norm_ptr + pid * n_elements + elem0 + 1,
            mask=valid_byte & (elem0 + 1 < n_elements),
            other=0.0,
        ).to(tl.float32)

        scale_f = tl.exp2(-scale_exp.to(tl.float32))
        q0 = x0 * scale_f
        q1 = x1 * scale_f

        def encode(q):
            bits = tl.cast(q, tl.int32, bitcast=True)
            sign = bits & (-2147483648)
            exponent = (bits >> 23) & 0xFF
            mantissa = bits & 0x7FFFFF

            adjusted = 126 - exponent
            adjusted = tl.maximum(adjusted, 0)
            denorm_mantissa = (0x400000 | (mantissa >> 1)) >> adjusted
            mantissa = tl.where(exponent < 127, denorm_mantissa, mantissa)

            e2 = tl.where(exponent > 126, exponent, 126) - 126
            combined = ((e2 << 2) | (mantissa >> 21)) + 1
            combined = combined >> 1
            combined = tl.minimum(combined, 7)

            return ((sign >> 28) & 0xF) | combined

        c0 = encode(q0)
        c1 = encode(q1)
        packed = c0 | (c1 << 4)

        code_ptr = out_ptr + pid * (n_bytes + n_blocks) + byte_idx
        tl.store(code_ptr, packed.to(tl.uint8), mask=valid_byte)

        first_in_block = (byte_idx & 15) == 0
        scale_ptr = (
            out_ptr
            + pid * (n_bytes + n_blocks)
            + n_bytes
            + block_idx
        )
        tl.store(
            scale_ptr,
            scale_byte.to(tl.uint8),
            mask=valid_byte & first_in_block & (block_idx < n_blocks),
        )


class ModelNew(nn.Module):
    def __init__(self, dtype: str = "bfloat16", eps: float = 1e-6):
        super().__init__()
        self.dtype = getattr(torch, dtype)
        self.eps = float(eps)

    def forward(self, inp1, weight1, res1):
        m, n = inp1.shape
        n_bytes = n // 2
        n_blocks = (n + 31) // 32

        norm = torch.empty((m, n), dtype=torch.float32, device=inp1.device)
        out = torch.empty(
            (m, n_bytes + n_blocks),
            dtype=torch.uint8,
            device=inp1.device,
        )

        _rmsnorm_kernel[(m,)](
            inp1,
            res1,
            weight1,
            norm,
            n,
            self.eps,
            BLOCK=256,
            num_warps=4,
        )

        _mxfp4_quant_kernel[(m,)](
            norm,
            out,
            n,
            n_bytes,
            n_blocks,
            BLOCK_BYTES=256,
            num_warps=4,
        )

        return out
