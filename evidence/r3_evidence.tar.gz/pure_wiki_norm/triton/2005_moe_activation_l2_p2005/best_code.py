import torch
import torch.nn as nn
import triton
import triton.language as tl
import triton.language.extra.libdevice as libdevice


@triton.jit
def _activation_kernel(
    X, Y,
    N: tl.constexpr, TOTAL: tl.constexpr,
    GATED: tl.constexpr, KIND: tl.constexpr,
    ALPHA: tl.constexpr, LIMIT: tl.constexpr,
    BLOCK: tl.constexpr,
):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = i < TOTAL
    if GATED:
        if KIND == "swiglu_interleaved":
            p = 2 * i
            q = p + 1
        else:
            p = (i // N) * (2 * N) + i % N
            q = p + N
        g = tl.load(X + p, valid, other=0).to(tl.float32)
        u = tl.load(X + q, valid, other=0).to(tl.float32)
    else:
        g = tl.load(X + i, valid, other=0).to(tl.float32)

    if KIND == "gelu" or KIND == "gelu_no_mul":
        a = (0.5 * g) * (1.0 + libdevice.erf(g * 0.7071067811865476))
    elif KIND == "gelu_tanh" or KIND == "gelu_tanh_no_mul":
        z = 0.7978845608028654 * (g + ((0.044715 * g) * g) * g)
        a = (0.5 * g) * (1.0 + libdevice.tanh(z))
    elif KIND == "relu2":
        r = tl.maximum(g, 0.0)
        a = r * r
    elif KIND == "swiglustep":
        a = g * (1.0 / (1.0 + tl.exp(-g)))
        a = tl.minimum(a, LIMIT)
        u = tl.minimum(tl.maximum(u, -LIMIT), LIMIT)
    else:
        if GATED and LIMIT is not None:
            g = tl.minimum(g, LIMIT)
            u = tl.minimum(tl.maximum(u, -LIMIT), LIMIT)
        if GATED and ALPHA is not None:
            a = g * (1.0 / (1.0 + tl.exp(-(ALPHA * g))))
            u = u + 1.0
        else:
            a = g * (1.0 / (1.0 + tl.exp(-g)))
    if GATED:
        a = a * u
    tl.store(Y + i, a, valid)


class ModelNew(nn.Module):
    def __init__(self, activation: str = "silu", alpha=None, limit=None):
        super().__init__()
        gated = ("silu", "gelu", "gelu_tanh", "swiglustep", "swiglu_interleaved")
        nomul = ("silu_no_mul", "gelu_no_mul", "gelu_tanh_no_mul", "relu2")
        name = str(activation).lower()
        assert name in gated or name in nomul, (
            "activation must be one of " + "/".join(gated + nomul) + " variants"
        )
        if name in ("gelu", "gelu_tanh"):
            assert alpha is None and limit is None, (
                "gelu / gelu_tanh do not accept alpha / limit"
            )
        if name == "swiglustep":
            assert alpha is None, "swiglustep does not accept alpha"
        if name == "silu" and alpha is not None:
            assert limit is not None, "silu must set limit as well when alpha is set"
        if name == "swiglustep" and limit is None:
            limit = 7.0
        if name == "swiglu_interleaved":
            alpha = 1.702 if alpha is None else alpha
            limit = 7.0 if limit is None else limit
        self.activation = name
        self.is_gated = name in gated
        self.alpha = None if alpha is None else float(alpha)
        self.limit = None if limit is None else float(limit)

    def forward(self, x):
        assert x.dim() == 2, "the input must be a 2D (M, n) tensor"
        m, n = x.shape
        if self.is_gated:
            assert n % 2 == 0, (
                "the gated variants require the last dimension n to be even"
            )
            n //= 2
        out = torch.empty((m, n), device=x.device, dtype=x.dtype)
        total = m * n
        if total:
            block = 1024
            _activation_kernel[(triton.cdiv(total, block),)](
                x, out, n, total, self.is_gated, self.activation,
                self.alpha, self.limit, block,
                num_warps=4, enable_fp_fusion=False,
            )
        return out
