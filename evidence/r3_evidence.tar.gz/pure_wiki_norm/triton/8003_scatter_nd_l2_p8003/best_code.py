import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _copy_kernel(src, dst, n, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n
    vals = tl.load(src + offs, mask=mask)
    tl.store(dst + offs, vals, mask=mask)


@triton.jit
def _write_kernel(
    indices,
    updates,
    output,
    k,
    s0,
    s1,
    s2,
    s3,
    s4,
    s5,
    RANK: tl.constexpr,
    BLOCK: tl.constexpr,
):
    pid = tl.program_id(0)
    rows = pid * BLOCK + tl.arange(0, BLOCK)
    mask = rows < k

    linear = tl.zeros((BLOCK,), dtype=tl.int64)

    for d in tl.static_range(0, RANK):
        coord = tl.load(
            indices + rows * RANK + d,
            mask=mask,
            other=0,
        )
        if d == 0:
            stride = s0
        elif d == 1:
            stride = s1
        elif d == 2:
            stride = s2
        elif d == 3:
            stride = s3
        elif d == 4:
            stride = s4
        else:
            stride = s5
        linear += tl.cast(coord, tl.int64) * stride

    vals = tl.load(updates + rows, mask=mask, other=0)
    tl.store(output + linear, vals, mask=mask)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, data, indices, updates):
        rank = data.ndim
        n = data.numel()
        k = indices.shape[0]

        output = torch.empty_like(data)

        copy_block = 256
        _copy_kernel[(triton.cdiv(n, copy_block),)](
            data,
            output,
            n,
            BLOCK=copy_block,
        )

        strides = tuple(int(x) for x in data.stride())
        padded = strides + (0,) * (6 - rank)

        write_block = 128
        _write_kernel[(triton.cdiv(k, write_block),)](
            indices,
            updates,
            output,
            k,
            padded[0],
            padded[1],
            padded[2],
            padded[3],
            padded[4],
            padded[5],
            RANK=rank,
            BLOCK=write_block,
        )

        return output
