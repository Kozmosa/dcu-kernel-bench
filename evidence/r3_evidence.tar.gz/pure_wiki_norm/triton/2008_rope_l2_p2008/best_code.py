import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _rope_kernel(
    X, Freqs, Y,
    N: tl.constexpr,
    D: tl.constexpr,
    BH: tl.constexpr,
    F: tl.constexpr,
    R: tl.constexpr,
    START: tl.constexpr,
    STYLE: tl.constexpr,
    REUSE: tl.constexpr,
    BLOCK: tl.constexpr,
):
    idx = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = idx < N
    channel = idx % D
    sequence = idx // (BH * D)
    local = channel - START
    active = (local >= 0) & (local < R)

    if STYLE == 0:
        paired = tl.where(local < R // 2, local + R // 2, local - R // 2)
        negative = local < R // 2
    else:
        paired = local ^ 1
        negative = (local & 1) == 0

    if REUSE:
        if STYLE == 0:
            angle_idx = local % F
        else:
            angle_idx = local // 2
    else:
        angle_idx = local

    angle = tl.load(
        Freqs + sequence * F + angle_idx,
        mask=valid & active,
        other=0.0,
    ).to(tl.float32)
    value = tl.load(X + idx, mask=valid, other=0.0).to(tl.float32)
    partner = tl.load(
        X + idx - channel + START + paired,
        mask=valid & active,
        other=0.0,
    ).to(tl.float32)
    partner = tl.where(negative, -partner, partner)
    rotated = value * tl.cos(angle) + partner * tl.sin(angle)
    result = tl.where(active, rotated, value)
    tl.store(Y + idx, result, mask=valid)


class ModelNew(nn.Module):
    def __init__(self, rotate_style: int, nope_first: bool, reuse_freqs_front_part: bool):
        super().__init__()
        self.rotate_style = int(rotate_style)
        self.nope_first = bool(nope_first)
        self.reuse_freqs_front_part = bool(reuse_freqs_front_part)

    def forward(self, x, freqs):
        s, b, h, d = x.shape
        f = freqs.shape[-1]
        r = f * (2 if self.reuse_freqs_front_part else 1)
        start = d - r if self.nope_first else 0
        out = torch.empty(x.shape, dtype=x.dtype, device=x.device)
        n = s * b * h * d
        block = 512
        _rope_kernel[(triton.cdiv(n, block),)](
            x, freqs, out,
            N=n, D=d, BH=b * h, F=f, R=r, START=start,
            STYLE=self.rotate_style,
            REUSE=self.reuse_freqs_front_part,
            BLOCK=block,
            num_warps=4,
            enable_fp_fusion=False,
        )
        return out
