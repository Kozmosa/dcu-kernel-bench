import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _attention_kernel(
    q_ptr, k_ptr, v_ptr, slope_ptr,
    out_ptr, lse_ptr,
    stride_qb, stride_qq, stride_qh, stride_qd,
    stride_kb, stride_kk, stride_kh, stride_kd,
    stride_vb, stride_vk, stride_vh, stride_vd,
    stride_sb, stride_sh,
    batch, seqlen_q, seqlen_k, nheads_q, nheads_k,
    sm_scale,
    BLOCK_D: tl.constexpr,
    BLOCK_K: tl.constexpr,
    CAUSAL: tl.constexpr,
):
    pid = tl.program_id(0)
    total_rows = batch * nheads_q * seqlen_q

    if pid >= total_rows:
        return

    i = pid % seqlen_q
    t = pid // seqlen_q
    h = t % nheads_q
    b = t // nheads_q

    kvh = h // (nheads_q // nheads_k)

    q_base = (
        b * stride_qb
        + i * stride_qq
        + h * stride_qh
    )
    k_base = b * stride_kb + kvh * stride_kh
    v_base = b * stride_vb + kvh * stride_vh

    d = tl.arange(0, BLOCK_D)
    dmask = d < BLOCK_D

    qv = tl.load(
        q_ptr + q_base + d * stride_qd,
        mask=dmask,
        other=0.0,
    ).to(tl.float32)

    slope = tl.load(
        slope_ptr + b * stride_sb + h * stride_sh
    ).to(tl.float32)

    out_base = (
        b * seqlen_q * nheads_q * BLOCK_D
        + i * nheads_q * BLOCK_D
        + h * BLOCK_D
    )
    lse_base = b * nheads_q * seqlen_q + h * seqlen_q + i

    if CAUSAL:
        shift = seqlen_k - seqlen_q
        if i < -shift:
            tl.store(
                out_ptr + out_base + d,
                tl.zeros([BLOCK_D], dtype=tl.float32),
                mask=dmask,
            )
            tl.store(lse_ptr + lse_base, 0.0)
            return

    m = tl.full([], float("-inf"), tl.float32)
    l = tl.zeros([], dtype=tl.float32)
    acc = tl.zeros([BLOCK_D], dtype=tl.float32)

    num_blocks = tl.cdiv(seqlen_k, BLOCK_K)
    for block in range(0, num_blocks):
        j = block * BLOCK_K + tl.arange(0, BLOCK_K)
        jmask = j < seqlen_k

        k_offsets = (
            k_base
            + j[:, None] * stride_kk
            + d[None, :] * stride_kd
        )
        kval = tl.load(
            k_ptr + k_offsets,
            mask=jmask[:, None] & dmask[None, :],
            other=0.0,
        ).to(tl.float32)

        score = tl.sum(kval * qv[None, :], axis=1) * sm_scale

        rel = (i + seqlen_k - seqlen_q) - j
        score = score - slope * tl.abs(rel.to(tl.float32))

        valid = jmask
        if CAUSAL:
            valid = valid & (j <= i + seqlen_k - seqlen_q)

        score = tl.where(valid, score, float("-inf"))
        block_m = tl.max(score, axis=0)
        new_m = tl.maximum(m, block_m)
        safe_m = tl.where(new_m == float("-inf"), 0.0, new_m)

        alpha = tl.where(
            m == float("-inf"),
            0.0,
            tl.exp(m - safe_m),
        )
        weights = tl.where(
            valid,
            tl.exp(score - safe_m),
            0.0,
        )

        v_offsets = (
            v_base
            + j[:, None] * stride_vk
            + d[None, :] * stride_vd
        )
        vval = tl.load(
            v_ptr + v_offsets,
            mask=jmask[:, None] & dmask[None, :],
            other=0.0,
        ).to(tl.float32)

        acc = acc * alpha + tl.sum(weights[:, None] * vval, axis=0)
        l = l * alpha + tl.sum(weights, axis=0)
        m = new_m

    result = acc / l
    row_lse = m + tl.log(l)

    tl.store(
        out_ptr + out_base + d,
        result,
        mask=dmask,
    )
    tl.store(lse_ptr + lse_base, row_lse)


@triton.jit
def _pack_kernel(
    out_ptr,
    lse_ptr,
    packed_ptr,
    out_numel,
    total_numel,
    BLOCK: tl.constexpr,
):
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < total_numel

    is_out = offs < out_numel
    out_vals = tl.load(out_ptr + offs, mask=mask & is_out, other=0.0).to(tl.float32)

    lse_idx = offs - out_numel
    lse_vals = tl.load(
        lse_ptr + lse_idx,
        mask=mask & (~is_out),
        other=0.0,
    ).to(tl.float32)

    vals = tl.where(is_out, out_vals, lse_vals)
    tl.store(packed_ptr + offs, vals, mask=mask)


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, sm_scale=None):
        super().__init__()
        self.head_dim = int(head_dim)
        self.sm_scale = (
            float(sm_scale)
            if sm_scale is not None
            else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v, causal, alibi_slopes):
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal, device=q.device)

        is_causal = bool(int(causal.to(torch.int32).item()))
        alibi_slopes = alibi_slopes.to(torch.float32)

        batch, seqlen_q, nheads_q, head_dim = q.shape
        _, seqlen_k, nheads_k, _ = k.shape

        group = nheads_q // nheads_k
        assert nheads_q == nheads_k * group
        assert head_dim == self.head_dim

        out = torch.empty(
            (batch, seqlen_q, nheads_q, head_dim),
            device=q.device,
            dtype=q.dtype,
        )
        lse = torch.empty(
            (batch, nheads_q, seqlen_q),
            device=q.device,
            dtype=torch.float32,
        )

        block_d = triton.next_power_of_2(head_dim)
        block_k = 64

        grid = (batch * nheads_q * seqlen_q,)

        _attention_kernel[grid](
            q, k, v, alibi_slopes,
            out, lse,
            q.stride(0), q.stride(1), q.stride(2), q.stride(3),
            k.stride(0), k.stride(1), k.stride(2), k.stride(3),
            v.stride(0), v.stride(1), v.stride(2), v.stride(3),
            alibi_slopes.stride(0), alibi_slopes.stride(1),
            batch, seqlen_q, seqlen_k, nheads_q, nheads_k,
            self.sm_scale,
            BLOCK_D=block_d,
            BLOCK_K=block_k,
            CAUSAL=is_causal,
            num_warps=4 if head_dim <= 128 else 8,
            num_stages=2,
        )

        out_numel = batch * seqlen_q * nheads_q * head_dim
        lse_numel = batch * nheads_q * seqlen_q
        total_numel = out_numel + lse_numel

        packed = torch.empty(
            (total_numel,),
            device=q.device,
            dtype=torch.float32,
        )

        pack_grid = (triton.cdiv(total_numel, 256),)
        _pack_kernel[pack_grid](
            out,
            lse,
            packed,
            out_numel,
            total_numel,
            BLOCK=256,
            num_warps=4,
        )

        return packed
