import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _gemm(
    A, Q, S, Z, O,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr, G: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    rows = tl.program_id(0) * BM + tl.arange(0, BM)
    cols = tl.program_id(1) * BN + tl.arange(0, BN)
    ks = tl.arange(0, BK)
    acc = tl.full((BM, BN), 0, tl.float32)

    for base in range(tr.cdiv(K, BK)):
        k = base * BK + ks
        a = tl.load(
            A + rows[:, None] * K + k[None, :],
            (rows[:, None] < M) & (k[None, :] < K),
            other=0,
        ).to(tl.float32)
        packed = tl.load(
            Q + cols[None, :] * (K // 2) + k[:, None] // 2,
            (cols[None, :] < N) & (k[:, None] < K),
            other=0,
        ).to(tl.int32)
        w = (packed >> ((k[:, None] & 1) * 4)) & 15
        group = k // G
        zp = tl.load(
            Z + group[:, None] * (N // 2) + cols[None, :] // 2,
            (k[:, None] < K) & (cols[None, :] < N),
            other=0,
        ).to(tl.int32)
        z = (zp >> ((cols[None, :] & 1) * 4)) & 15
        scale = tl.load(
            S + group[:, None] * N + cols[None, :],
            (k[:, None] < K) & (cols[None, :] < N),
            other=0,
        ).to(tl.float32)
        b = (w - z).to(tl.float32) * scale
        acc = tl.dot(a, b, acc, input_precision="ieee")

    tl.store(
        O + rows[:, None] * N + cols[None, :],
        acc,
        (rows[:, None] < M) & (cols[None, :] < N),
    )


@tr.jit
def _small_gemm(
    A, Q, S, Z, O,
    N: tl.constexpr, K: tl.constexpr, G: tl.constexpr,
    BN: tl.constexpr, BK: tl.constexpr,
):
    row = tl.program_id(0)
    n = tl.program_id(1) * BN + tl.arange(0, BN)
    kk = tl.arange(0, BK)
    accum = tl.full((BN, BK), 0, tl.float32)
    for block in range(tr.cdiv(K, BK)):
        k = block * BK + kk
        mask = (n[:, None] < N) & (k[None, :] < K)
        a = tl.load(A + row * K + k, k < K, other=0).to(tl.float32)
        packed = tl.load(
            Q + n[:, None] * (K // 2) + k[None, :] // 2,
            mask, other=0,
        ).to(tl.int32)
        w = (packed >> ((k[None, :] & 1) * 4)) & 15
        zp = tl.load(
            Z + (k[None, :] // G) * (N // 2) + n[:, None] // 2,
            mask, other=0,
        ).to(tl.int32)
        z = (zp >> ((n[:, None] & 1) * 4)) & 15
        scale = tl.load(
            S + (k[None, :] // G) * N + n[:, None],
            mask, other=0,
        ).to(tl.float32)
        weight = (w - z).to(tl.float32) * scale
        accum += a[None, :] * weight
    result = tl.sum(accum, axis=1)
    tl.store(O + row * N + n, result, n < N)


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int, group_size: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.group_size = group_size

    def forward(self, input, qweight, scales, qzeros):
        M, K = input.shape
        N = qweight.shape[0]
        group = K // qzeros.shape[0]
        assert qweight.shape[1] == K // 2
        assert qzeros.shape[1] == N // 2
        assert scales.shape[0] == K // group and scales.shape[1] == N
        out = torch.empty((M, N), dtype=input.dtype, device=input.device)
        if M == 0 or N == 0:
            return out
        if M <= 4:
            _small_gemm[(M, tr.cdiv(N, 4))](
                input, qweight, scales, qzeros, out,
                N, K, group, 4, 256,
                num_warps=4, enable_fp_fusion=False,
            )
        else:
            _gemm[(tr.cdiv(M, 16), tr.cdiv(N, 32))](
                input, qweight, scales, qzeros, out,
                M, N, K, group, 16, 32, 32,
                num_warps=4,
            )
        return out
