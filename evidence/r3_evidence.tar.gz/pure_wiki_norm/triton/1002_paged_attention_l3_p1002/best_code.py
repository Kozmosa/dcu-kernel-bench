import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _paged_attention_decode_kernel(
    query_ptr,
    key_ptr,
    value_ptr,
    block_table_ptr,
    seq_lens_ptr,
    output_ptr,
    B,
    HQ,
    HKV,
    D,
    BLOCK_SIZE,
    MAX_BLOCKS,
    scale,
    q_s0,
    q_s1,
    q_s2,
    k_s0,
    k_s1,
    k_s2,
    k_s3,
    v_s0,
    v_s1,
    v_s2,
    v_s3,
    bt_s0,
    bt_s1,
    sl_s0,
    o_s0,
    o_s1,
    o_s2,
    BLOCK_D: tl.constexpr,
):
    pid = tl.program_id(0)
    s = pid // HQ
    h = pid - s * HQ

    kv_head = h // (HQ // HKV)

    d = tl.arange(0, BLOCK_D)
    d_mask = d < D

    q_ptrs = query_ptr + s * q_s0 + h * q_s1 + d * q_s2
    q = tl.load(q_ptrs, mask=d_mask, other=0.0).to(tl.float32) * scale

    seq_len = tl.load(seq_lens_ptr + s * sl_s0).to(tl.int32)

    m = tl.full((), -float("inf"), tl.float32)
    denom = tl.zeros((), dtype=tl.float32)
    acc = tl.zeros((BLOCK_D,), dtype=tl.float32)

    for token_idx in range(0, MAX_BLOCKS * BLOCK_SIZE):
        block_idx = token_idx // BLOCK_SIZE
        slot_idx = token_idx - block_idx * BLOCK_SIZE

        bt_ptr = block_table_ptr + s * bt_s0 + block_idx * bt_s1
        physical_block = tl.load(bt_ptr).to(tl.int64)

        k_ptrs = (
            key_ptr
            + physical_block * k_s0
            + kv_head * k_s1
            + slot_idx * k_s2
            + d * k_s3
        )
        v_ptrs = (
            value_ptr
            + physical_block * v_s0
            + kv_head * v_s1
            + slot_idx * v_s2
            + d * v_s3
        )

        k = tl.load(k_ptrs, mask=d_mask, other=0.0).to(tl.float32)
        v = tl.load(v_ptrs, mask=d_mask, other=0.0).to(tl.float32)

        valid = token_idx < seq_len
        logit = tl.sum(q * k, axis=0)
        logit = tl.where(valid, logit, -float("inf"))

        new_m = tl.maximum(m, logit)
        new_m_safe = tl.where(new_m == -float("inf"), 0.0, new_m)
        old_m_safe = tl.where(m == -float("inf"), 0.0, m)

        alpha = tl.exp(old_m_safe - new_m_safe)
        beta = tl.exp(logit - new_m_safe)
        beta = tl.where(valid, beta, 0.0)

        acc = acc * alpha + beta * v
        denom = denom * alpha + beta
        m = new_m

    denom_safe = tl.where(denom > 0.0, denom, 1.0)
    result = acc / denom_safe

    out_ptrs = output_ptr + s * o_s0 + h * o_s1 + d * o_s2
    tl.store(out_ptrs, result, mask=d_mask)


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        B, H_Q, D = query.shape
        H_KV = key_cache.shape[1]
        block_size = key_cache.shape[2]
        max_blocks = block_tables.shape[1]

        if H_Q % H_KV != 0:
            raise AssertionError(
                "num_q_heads must be an integer multiple of num_kv_heads"
            )

        out = torch.empty_like(query)
        block_d = triton.next_power_of_2(D)

        if D <= 64:
            num_warps = 2
        elif D <= 128:
            num_warps = 4
        else:
            num_warps = 8

        grid = (B * H_Q,)

        _paged_attention_decode_kernel[grid](
            query,
            key_cache,
            value_cache,
            block_tables,
            seq_lens,
            out,
            B,
            H_Q,
            H_KV,
            D,
            block_size,
            max_blocks,
            self.scale,
            query.stride(0),
            query.stride(1),
            query.stride(2),
            key_cache.stride(0),
            key_cache.stride(1),
            key_cache.stride(2),
            key_cache.stride(3),
            value_cache.stride(0),
            value_cache.stride(1),
            value_cache.stride(2),
            value_cache.stride(3),
            block_tables.stride(0),
            block_tables.stride(1),
            seq_lens.stride(0),
            out.stride(0),
            out.stride(1),
            out.stride(2),
            BLOCK_D=block_d,
            num_warps=num_warps,
            num_stages=2,
        )

        return out
