import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _decode(q, s, k):
    nib = (q >> ((k & 1) * 4)) & 15
    mag = nib & 7
    value = tl.where(
        mag < 4,
        mag.to(tl.float32) * 0.5,
        tl.where(mag < 6, mag.to(tl.float32) - 2.0,
                 tl.where(mag == 6, 4.0, 6.0)),
    )
    value = tl.where((nib & 8) != 0, -value, value)
    return value * tl.exp2(s.to(tl.float32) - 127.0)


@triton.jit
def _compute(
    AQ, AS, BQ, BS, IDS, W, OUT,
    N: tl.constexpr, K: tl.constexpr, TOP: tl.constexpr,
    AQ0: tl.constexpr, AQ1: tl.constexpr,
    AS0: tl.constexpr, AS1: tl.constexpr,
    BQ0: tl.constexpr, BQ1: tl.constexpr, BQ2: tl.constexpr,
    BS0: tl.constexpr, BS1: tl.constexpr, BS2: tl.constexpr,
    I0: tl.constexpr, I1: tl.constexpr,
    W0: tl.constexpr, W1: tl.constexpr,
    SPLITS: tl.constexpr, BK: tl.constexpr, BN: tl.constexpr,
):
    slot = tl.program_id(0)
    ns = tl.program_id(1) * BN + tl.arange(0, BN)
    split = tl.program_id(2)
    ks = split * BK + tl.arange(0, BK)
    m = slot // TOP
    j = slot % TOP
    expert = tl.load(IDS + m * I0 + j * I1).to(tl.int64)

    ac = tl.load(AQ + m * AQ0 + (ks // 2) * AQ1,
                 ks < K, other=0).to(tl.int32)
    asc = tl.load(AS + m * AS0 + (ks // 32) * AS1,
                  ks < K, other=127)
    a = _decode(ac, asc, ks)

    bc = tl.load(
        BQ + expert * BQ0 + ns[:, None] * BQ1
        + (ks[None, :] // 2) * BQ2,
        (ns[:, None] < N) & (ks[None, :] < K), other=0,
    ).to(tl.int32)
    bsc = tl.load(
        BS + expert * BS0 + ns[:, None] * BS1
        + (ks[None, :] // 32) * BS2,
        (ns[:, None] < N) & (ks[None, :] < K), other=127,
    )
    b = _decode(bc, bsc, ks[None, :])
    products = a[None, :] * b
    products = tl.where(ks[None, :] < K, products, 0.0)
    sums = tl.sum(products, axis=1)
    if SPLITS == 1:
        weight = tl.load(W + m * W0 + j * W1).to(tl.float32)
        tl.store(OUT + slot * N + ns, sums * weight, ns < N)
    else:
        tl.store(OUT + (slot * SPLITS + split) * N + ns, sums, ns < N)


@triton.jit
def _finish(
    PART, W, OUT,
    N: tl.constexpr, TOP: tl.constexpr, TOTAL: tl.constexpr,
    SPLITS: tl.constexpr, RS: tl.constexpr,
    W0: tl.constexpr, W1: tl.constexpr,
    BLOCK: tl.constexpr,
):
    idx = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    slot = idx // N
    n = idx % N
    r = tl.arange(0, RS)
    partial = tl.load(
        PART + (slot[:, None] * SPLITS + r[None, :]) * N + n[:, None],
        (idx[:, None] < TOTAL) & (r[None, :] < SPLITS), other=0.0,
    )
    val = tl.sum(partial, axis=1)
    weight = tl.load(
        W + (slot // TOP) * W0 + (slot % TOP) * W1,
        idx < TOTAL, other=0,
    ).to(tl.float32)
    tl.store(OUT + idx, val * weight, idx < TOTAL)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, a_q, a_scales, b_q, b_scales, topk_weights, topk_ids):
        a_q = a_q.to(torch.uint8)
        a_scales = a_scales.to(torch.uint8)
        b_q = b_q.to(torch.uint8)
        b_scales = b_scales.to(torch.uint8)
        topk_ids = topk_ids.to(torch.long)

        m, kh = a_q.shape
        k = kh * 2
        n = b_q.shape[1]
        top = topk_ids.shape[1]
        out = torch.empty((m, top, n), device=a_q.device, dtype=torch.bfloat16)
        if m == 0 or n == 0:
            return out

        bk = min(triton.next_power_of_2(k), 2048)
        splits = triton.cdiv(k, bk)
        bn = 4
        dest = out if splits == 1 else torch.empty(
            (m * top, splits, n), device=a_q.device, dtype=torch.float32
        )
        _compute[(m * top, triton.cdiv(n, bn), splits)](
            a_q, a_scales, b_q, b_scales, topk_ids, topk_weights, dest,
            n, k, top,
            *a_q.stride(), *a_scales.stride(),
            *b_q.stride(), *b_scales.stride(),
            *topk_ids.stride(), *topk_weights.stride(),
            splits, bk, bn,
            num_warps=4 if bk <= 1024 else 8,
        )
        if splits > 1:
            _finish[(triton.cdiv(m * top * n, 128),)](
                dest, topk_weights, out,
                n, top, m * top * n, splits, triton.next_power_of_2(splits),
                *topk_weights.stride(), 128,
                num_warps=4,
            )
        return out
