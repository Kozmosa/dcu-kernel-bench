import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _coords(O, b, m, p, H: tl.constexpr, W: tl.constexpr,
            P: tl.constexpr, OW: tl.constexpr, M: tl.constexpr,
            S: tl.constexpr, SH: tl.constexpr, SW: tl.constexpr,
            PH: tl.constexpr, PW: tl.constexpr, DH: tl.constexpr,
            DW: tl.constexpr):
    y = (p // OW * SH - PH + (m // S) * DH).to(tl.float32)
    z = (p % OW * SW - PW + (m % S) * DW).to(tl.float32)
    y += tl.load(O + (b * 2 * M + 2 * m) * P + p, p < P, 0)
    z += tl.load(O + (b * 2 * M + 2 * m + 1) * P + p, p < P, 0)
    yf = tl.floor(y)
    zf = tl.floor(z)
    return yf.to(tl.int32), zf.to(tl.int32), y - yf, z - zf


@tr.jit
def _pixels(X, base, y, z, valid, H: tl.constexpr, W: tl.constexpr):
    a = tl.load(X + base + y * W + z,
                valid & (y >= 0) & (y < H) & (z >= 0) & (z < W), 0)
    b = tl.load(X + base + y * W + z + 1,
                valid & (y >= 0) & (y < H) & (z + 1 >= 0) & (z + 1 < W), 0)
    c = tl.load(X + base + (y + 1) * W + z,
                valid & (y + 1 >= 0) & (y + 1 < H) & (z >= 0) & (z < W), 0)
    d = tl.load(X + base + (y + 1) * W + z + 1,
                valid & (y + 1 >= 0) & (y + 1 < H) & (z + 1 >= 0) & (z + 1 < W), 0)
    return a, b, c, d


@tr.jit
def _contract(D, Wt, G, C: tl.constexpr, K: tl.constexpr,
              P: tl.constexpr, M: tl.constexpr,
              BC: tl.constexpr = 16, BP: tl.constexpr = 32,
              BK: tl.constexpr = 16):
    ci = tl.program_id(0) * BC + tl.arange(0, BC)
    p = tl.program_id(1) * BP + tl.arange(0, BP)
    bm = tl.program_id(2)
    b, m = bm // M, bm % M
    kk = tl.arange(0, BK)
    acc = tl.full((BC, BP), 0, tl.float32)
    for start in range(tr.cdiv(K, BK)):
        k = start * BK + kk
        a = tl.load(Wt + (k[None, :] * C + ci[:, None]) * M + m,
                    (ci[:, None] < C) & (k[None, :] < K), 0)
        d = tl.load(D + (b * K + k[:, None]) * P + p[None, :],
                    (k[:, None] < K) & (p[None, :] < P), 0)
        acc += tl.dot(a, d, input_precision="ieee")
    tl.store(G + ((bm * C + ci[:, None]) * P + p[None, :]),
             acc, (ci[:, None] < C) & (p[None, :] < P))


@tr.jit
def _scatter(X, O, Mask, G, Out,
             N: tl.constexpr, C: tl.constexpr, H: tl.constexpr, W: tl.constexpr,
             P: tl.constexpr, OW: tl.constexpr, M: tl.constexpr, S: tl.constexpr,
             SH: tl.constexpr, SW: tl.constexpr, PH: tl.constexpr, PW: tl.constexpr,
             DH: tl.constexpr, DW: tl.constexpr, B: tl.constexpr):
    p = tl.program_id(0) * B + tl.arange(0, B)
    bm = tl.program_id(1)
    batch, m = bm // M, bm % M
    y, z, ty, tx = _coords(O, batch, m, p, H, W, P, OW, M, S,
                           SH, SW, PH, PW, DH, DW)
    mod = tl.load(Mask + bm * P + p, p < P, 0)
    a00 = (1 - ty) * (1 - tx)
    a01 = (1 - ty) * tx
    a10 = ty * (1 - tx)
    a11 = ty * tx
    gy = tl.full((B,), 0, tl.float32)
    gx = tl.full((B,), 0, tl.float32)
    gm = tl.full((B,), 0, tl.float32)
    for ci in range(C):
        base = (batch * C + ci) * H * W
        v00, v01, v10, v11 = _pixels(X, base, y, z, p < P, H, W)
        g = tl.load(G + (bm * C + ci) * P + p, p < P, 0)
        val = ((a00 * v00 + a01 * v01) + a10 * v10) + a11 * v11
        gm += g * val
        q = g * mod
        gy += q * ((1 - tx) * (v10 - v00) + tx * (v11 - v01))
        gx += q * ((1 - ty) * (v01 - v00) + ty * (v11 - v10))
        tl.atomic_add(Out + base + y * W + z, q * a00,
                      (p < P) & (y >= 0) & (y < H) & (z >= 0) & (z < W),
                      sem="relaxed")
        tl.atomic_add(Out + base + y * W + z + 1, q * a01,
                      (p < P) & (y >= 0) & (y < H) & (z + 1 >= 0) & (z + 1 < W),
                      sem="relaxed")
        tl.atomic_add(Out + base + (y + 1) * W + z, q * a10,
                      (p < P) & (y + 1 >= 0) & (y + 1 < H) & (z >= 0) & (z < W),
                      sem="relaxed")
        tl.atomic_add(Out + base + (y + 1) * W + z + 1, q * a11,
                      (p < P) & (y + 1 >= 0) & (y + 1 < H) & (z + 1 >= 0) & (z + 1 < W),
                      sem="relaxed")
    offbase = N * C * H * W
    tl.store(Out + offbase + (batch * 2 * M + 2 * m) * P + p, gy, p < P)
    tl.store(Out + offbase + (batch * 2 * M + 2 * m + 1) * P + p, gx, p < P)
    tl.store(Out + offbase + N * 2 * M * P + bm * P + p, gm, p < P)


@tr.jit
def _sample(X, O, Mask, V,
            C: tl.constexpr, H: tl.constexpr, W: tl.constexpr,
            P: tl.constexpr, OW: tl.constexpr, M: tl.constexpr, S: tl.constexpr,
            SH: tl.constexpr, SW: tl.constexpr, PH: tl.constexpr, PW: tl.constexpr,
            DH: tl.constexpr, DW: tl.constexpr, B: tl.constexpr):
    p = tl.program_id(0) * B + tl.arange(0, B)
    bcm = tl.program_id(1)
    m = bcm % M
    ci = bcm // M % C
    batch = bcm // (M * C)
    y, z, ty, tx = _coords(O, batch, m, p, H, W, P, OW, M, S,
                           SH, SW, PH, PW, DH, DW)
    a, b, c, d = _pixels(X, (batch * C + ci) * H * W, y, z, p < P, H, W)
    v = (((1 - ty) * (1 - tx) * a + (1 - ty) * tx * b)
         + ty * (1 - tx) * c) + ty * tx * d
    # Mask is applied to dy in the correlation kernel, matching the backward order.
    tl.store(V + bcm * P + p, v, p < P)


@tr.jit
def _wrw(D, V, Mask, Out,
         N: tl.constexpr, C: tl.constexpr, K: tl.constexpr,
         M: tl.constexpr, P: tl.constexpr,
         BO: tl.constexpr = 16, BC: tl.constexpr = 16, BT: tl.constexpr = 32):
    ko = tl.program_id(0) * BO + tl.arange(0, BO)
    ci = tl.program_id(1) * BC + tl.arange(0, BC)
    m = tl.program_id(2)
    t = tl.arange(0, BT)
    acc = tl.full((BO, BC), 0, tl.float32)
    for batch in range(N):
        for start in range(tr.cdiv(P, BT)):
            p = start * BT + t
            mod = tl.load(Mask + (batch * M + m) * P + p, p < P, 0)
            dy = tl.load(D + (batch * K + ko[:, None]) * P + p[None, :],
                         (ko[:, None] < K) & (p[None, :] < P), 0)
            a = dy * mod[None, :]
            v = tl.load(V + ((batch * C + ci[None, :]) * M + m) * P + p[:, None],
                        (ci[None, :] < C) & (p[:, None] < P), 0)
            acc += tl.dot(a, v, input_precision="ieee")
    tl.store(Out + (ko[:, None] * C + ci[None, :]) * M + m,
             acc, (ko[:, None] < K) & (ci[None, :] < C))


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1,
                 pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        assert variant in ("dgrad", "wrw")
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)

    def forward(self, dy, weight, x, offset, mask):
        n, c, h, w = x.shape
        k, _, r, s = weight.shape
        oh, ow = dy.shape[2:]
        p, m = oh * ow, r * s
        spatial = (c, h, w, p, ow, m, s, self.stride_h, self.stride_w,
                   self.pad_h, self.pad_w, self.dil_h, self.dil_w)
        if self.variant == "dgrad":
            out = torch.zeros(n * c * h * w + n * 3 * m * p,
                              device=x.device, dtype=x.dtype)
            g = torch.empty((n, m, c, p), device=x.device, dtype=x.dtype)
            _contract[(tr.cdiv(c, 16), tr.cdiv(p, 32), n * m)](
                dy, weight, g, c, k, p, m, num_warps=4)
            _scatter[(tr.cdiv(p, 128), n * m)](
                x, offset, mask, g, out, n, *spatial, 128,
                num_warps=4, enable_fp_fusion=False)
            return out
        v = torch.empty((n, c, m, p), device=x.device, dtype=x.dtype)
        out = torch.empty((k, c, r, s), device=x.device, dtype=x.dtype)
        _sample[(tr.cdiv(p, 256), n * c * m)](
            x, offset, mask, v, *spatial, 256,
            num_warps=4, enable_fp_fusion=False)
        _wrw[(tr.cdiv(k, 16), tr.cdiv(c, 16), m)](
            dy, v, mask, out, n, c, k, m, p, num_warps=4)
        return out
