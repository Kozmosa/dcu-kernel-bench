import math
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _attention_parts(
    Q, K, CS, POS, PTR, IDX, PART, STAT, OUT,
    B: tl.constexpr, H: tl.constexpr, C: tl.constexpr,
    R: tl.constexpr, RD: tl.constexpr, SCALE: tl.constexpr,
    NEOX: tl.constexpr, NS: tl.constexpr,
    QB: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
    KT: tl.constexpr, KD: tl.constexpr,
    CST: tl.constexpr, CSD: tl.constexpr,
    PS: tl.constexpr, IS: tl.constexpr, XS: tl.constexpr,
    BC: tl.constexpr, BR: tl.constexpr, BT: tl.constexpr,
):
    bh = tl.program_id(0)
    split = tl.program_id(1)
    b = bh // H
    h = bh % H
    start = tl.load(PTR + b * IS)
    end = tl.load(PTR + (b + 1) * IS)
    length = end - start
    blocks = tl.cdiv(length, BT)
    per_split = tl.cdiv(blocks, NS)
    lo = split * per_split * BT
    hi = tl.minimum(length, lo + per_split * BT)

    dc = tl.arange(0, BC)
    dr = tl.arange(0, BR)
    tt = tl.arange(0, BT)
    qc = tl.load(Q + b * QB + h * QH + dc * QD, dc < C, 0).to(tl.float32)
    qr = tl.load(Q + b * QB + h * QH + (C + dr) * QD, dr < R, 0).to(tl.float32)

    if NEOX:
        ci = dr % (RD // 2)
        first = dr < RD // 2
        partner = tl.where(first, dr + RD // 2, dr - RD // 2)
    else:
        ci = dr // 2
        first = dr % 2 == 0
        partner = dr ^ 1

    pos = tl.load(POS + b * PS)
    co = tl.load(CS + pos * CST + ci * CSD, dr < RD, 0).to(tl.float32)
    si = tl.load(CS + pos * CST + (ci + RD // 2) * CSD, dr < RD, 0).to(tl.float32)
    qp = tl.load(
        Q + b * QB + h * QH + (C + partner) * QD,
        dr < RD, 0,
    ).to(tl.float32)
    qr = tl.where(dr < RD, qr * co + tl.where(first, -qp, qp) * si, qr)

    maximum = tl.full((), -float("inf"), tl.float32)
    denom = tl.full((), 0.0, tl.float32)
    acc = tl.full((BC,), 0.0, tl.float32)

    for offset in range(lo, hi, BT):
        token = offset + tt
        valid = token < hi
        row = tl.load(IDX + (start + token) * XS, valid, 0)
        kc = tl.load(
            K + row[:, None] * KT + dc[None, :] * KD,
            valid[:, None] & (dc[None, :] < C), 0,
        ).to(tl.float32)
        kr = tl.load(
            K + row[:, None] * KT + (C + dr[None, :]) * KD,
            valid[:, None] & (dr[None, :] < R), 0,
        ).to(tl.float32)
        kp = tl.load(
            K + row[:, None] * KT + (C + partner[None, :]) * KD,
            valid[:, None] & (token[:, None] == length - 1) & (dr[None, :] < RD),
            0,
        ).to(tl.float32)
        rotated = kr * co[None, :] + tl.where(first[None, :], -kp, kp) * si[None, :]
        kr = tl.where(
            (token[:, None] == length - 1) & (dr[None, :] < RD),
            rotated, kr,
        )
        if h == 0:
            tl.store(
                OUT + B * H * C + b * R + dr[None, :],
                kr,
                valid[:, None] & (token[:, None] == length - 1) & (dr[None, :] < R),
            )

        scores = (tl.sum(kc * qc[None, :], 1) + tl.sum(kr * qr[None, :], 1)) * SCALE
        scores = tl.where(valid, scores, -float("inf"))
        new_max = tl.maximum(maximum, tl.max(scores, 0))
        correction = tl.exp(maximum - new_max)
        weights = tl.exp(scores - new_max)
        denom = denom * correction + tl.sum(weights, 0)
        acc = acc * correction + tl.sum(weights[:, None] * kc, 0)
        maximum = new_max

    base = (bh * NS + split)
    tl.store(PART + base * C + dc, acc, dc < C)
    tl.store(STAT + base * 2, maximum)
    tl.store(STAT + base * 2 + 1, denom)


@tr.jit
def _combine(PART, STAT, OUT, C: tl.constexpr, NS: tl.constexpr,
             BS: tl.constexpr, BC: tl.constexpr):
    bh = tl.program_id(0)
    block = tl.program_id(1)
    s = tl.arange(0, BS)
    c = block * BC + tl.arange(0, BC)
    base = bh * NS + s
    m = tl.load(STAT + base * 2, s < NS, -float("inf"))
    d = tl.load(STAT + base * 2 + 1, s < NS, 0)
    mx = tl.max(m, 0)
    w = tl.exp(m - mx)
    denominator = tl.sum(w * d, 0)
    a = tl.load(PART + base[:, None] * C + c[None, :],
                (s[:, None] < NS) & (c[None, :] < C), 0)
    result = tl.sum(a * w[:, None], 0) / denominator
    tl.store(OUT + bh * C + c, result, c < C)


class ModelNew(nn.Module):
    def __init__(self, kv_lora_rank: int, qk_rope_head_dim: int,
                 rotary_dim: int, sm_scale=None, is_neox_style=True):
        super().__init__()
        self.kv_lora_rank = int(kv_lora_rank)
        self.qk_rope_head_dim = int(qk_rope_head_dim)
        self.rotary_dim = int(rotary_dim)
        self.sm_scale = (
            float(sm_scale) if sm_scale is not None
            else 1.0 / math.sqrt(self.kv_lora_rank + self.qk_rope_head_dim)
        )
        self.is_neox_style = bool(is_neox_style)

    def forward(self, q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices):
        b, h, _ = q.shape
        c = self.kv_lora_rank
        r = self.qk_rope_head_dim
        average_length = max(1, kv_indices.numel() // b)
        splits = min(32, max(1, tr.cdiv(average_length, 128)))
        out = torch.empty((b * h * c + b * r,), device=q.device, dtype=q.dtype)
        parts = torch.empty((b * h, splits, c), device=q.device, dtype=torch.float32)
        stats = torch.empty((b * h, splits, 2), device=q.device, dtype=torch.float32)
        _attention_parts[(b * h, splits)](
            q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices,
            parts, stats, out,
            b, h, c, r, self.rotary_dim, self.sm_scale, self.is_neox_style, splits,
            q.stride(0), q.stride(1), q.stride(2),
            kv_cache.stride(0), kv_cache.stride(1),
            cos_sin_cache.stride(0), cos_sin_cache.stride(1),
            positions.stride(0), kv_indptr.stride(0), kv_indices.stride(0),
            tr.next_power_of_2(c), tr.next_power_of_2(r), 32,
            num_warps=4, enable_fp_fusion=False,
        )
        _combine[(b * h, tr.cdiv(c, 128))](
            parts, stats, out, c, splits, tr.next_power_of_2(splits), 128,
            num_warps=4,
        )
        return out
