import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _residual_partial_kernel(
    x_ptr,
    r_ptr,
    out_ptr,
    partial_ptr,
    n_elements,
    n_tiles,
    out_stride,
    BLOCK: tl.constexpr,
    ROUND: tl.constexpr,
):
    row = tl.program_id(0)
    tile = tl.program_id(1)
    offs = tile * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n_elements

    base = row * n_elements
    xv = tl.load(x_ptr + base + offs, mask=mask, other=0.0).to(tl.float32)
    rv = tl.load(r_ptr + base + offs, mask=mask, other=0.0).to(tl.float32)
    s = xv + rv

    if ROUND == 1:
        z = s.to(tl.float16)
    elif ROUND == 2:
        z = s.to(tl.bfloat16)
    else:
        z = s

    out_base = row * out_stride + n_elements
    tl.store(out_ptr + out_base + offs, z, mask=mask)

    zf = z.to(tl.float32)
    part = tl.sum(tl.where(mask, zf, 0.0), axis=0)
    tl.store(partial_ptr + row * n_tiles + tile, part)


@triton.jit
def _stats_kernel(
    out_ptr,
    partial_ptr,
    stats_ptr,
    n_elements,
    n_tiles,
    out_stride,
    BLOCK: tl.constexpr,
):
    row = tl.program_id(0)

    partial_offsets = tl.arange(0, BLOCK)
    partial_mask = partial_offsets < n_tiles
    partial_base = row * n_tiles
    partial_values = tl.load(
        partial_ptr + partial_base + partial_offsets,
        mask=partial_mask,
        other=0.0,
    ).to(tl.float32)
    total = tl.sum(tl.where(partial_mask, partial_values, 0.0), axis=0)
    mean = total / n_elements

    variance = tl.zeros((), dtype=tl.float32)
    out_base = row * out_stride + n_elements

    for tile in tl.range(0, n_tiles):
        offs = tile * BLOCK + tl.arange(0, BLOCK)
        mask = offs < n_elements
        z = tl.load(out_ptr + out_base + offs, mask=mask, other=0.0).to(tl.float32)
        d = z - mean
        variance += tl.sum(tl.where(mask, d * d, 0.0), axis=0)

    variance = variance / n_elements
    tl.store(stats_ptr + row * 2, mean)
    tl.store(stats_ptr + row * 2 + 1, variance)


@triton.jit
def _normalize_kernel(
    out_ptr,
    stats_ptr,
    weight_ptr,
    bias_ptr,
    n_elements,
    out_stride,
    BLOCK: tl.constexpr,
):
    row = tl.program_id(0)
    tile = tl.program_id(1)

    offs = tile * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n_elements

    stats = tl.load(stats_ptr + row * 2 + tl.arange(0, 2))
    mean = stats[0]
    variance = stats[1]
    rstd = tl.rsqrt(variance + 1.0e-5)

    out_base = row * out_stride
    s_base = out_base + n_elements

    z = tl.load(out_ptr + s_base + offs, mask=mask, other=0.0).to(tl.float32)
    w = tl.load(weight_ptr + offs, mask=mask, other=0.0).to(tl.float32)
    b = tl.load(bias_ptr + offs, mask=mask, other=0.0).to(tl.float32)

    y = ((z - mean) * rstd) * w + b
    tl.store(out_ptr + out_base + offs, y, mask=mask)


class ModelNew(nn.Module):
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        self.eps = float(eps)

    def forward(self, x, residual, weight, bias):
        m, n = x.shape
        block = 1024
        n_tiles = (n + block - 1) // block

        if x.dtype == torch.float16:
            round_mode = 1
        elif x.dtype == torch.bfloat16:
            round_mode = 2
        else:
            round_mode = 0

        out = torch.empty((m, 2 * n), device=x.device, dtype=x.dtype)
        partial = torch.empty((m, n_tiles), device=x.device, dtype=torch.float32)
        stats = torch.empty((m, 2), device=x.device, dtype=torch.float32)

        _residual_partial_kernel[(m, n_tiles)](
            x,
            residual,
            out,
            partial,
            n,
            n_tiles,
            2 * n,
            BLOCK=block,
            ROUND=round_mode,
            num_warps=8,
        )

        _stats_kernel[(m,)](
            out,
            partial,
            stats,
            n,
            n_tiles,
            2 * n,
            BLOCK=block,
            num_warps=8,
        )

        _normalize_kernel[(m, n_tiles)](
            out,
            stats,
            weight,
            bias,
            n,
            2 * n,
            BLOCK=block,
            num_warps=8,
        )

        return out
