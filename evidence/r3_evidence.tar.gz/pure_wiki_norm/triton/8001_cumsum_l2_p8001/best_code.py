import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _add_pair(ah, al, bh, bl):
    s = ah + bh
    v = s - ah
    e = (ah - (s - v)) + (bh - v)
    e = e + (al + bl)
    h = s + e
    l = e - (h - s)
    return h, l


@tr.jit
def _local_scan(X, Y, H, E, TH, TE,
                L: tl.constexpr, I: tl.constexpr, C: tl.constexpr,
                N: tl.constexpr, B: tl.constexpr, W: tl.constexpr):
    block = tl.program_id(0)
    chains = tl.program_id(1) * W + tl.arange(0, W)
    rows = block * B + tl.arange(0, B)
    offsets = ((chains[None, :] // I) * L + rows[:, None]) * I + chains[None, :] % I
    mask = (rows[:, None] < L) & (chains[None, :] < C)
    val = tl.load(X + offsets, mask, 0).to(tl.float32)
    hi, lo = tl.associative_scan(
        (val, tl.full((B, W), 0, tl.float32)), 0, _add_pair
    )
    if N == 1:
        tl.store(Y + offsets, hi + lo, mask)
    else:
        tl.store(H + offsets, hi, mask)
        tl.store(E + offsets, lo, mask)
        last_hi = tl.sum(tl.where(tl.arange(0, B)[:, None] == B - 1, hi, 0), 0)
        last_lo = tl.sum(tl.where(tl.arange(0, B)[:, None] == B - 1, lo, 0), 0)
        tl.store(TH + block * C + chains, last_hi, chains < C)
        tl.store(TE + block * C + chains, last_lo, chains < C)


@tr.jit
def _scan_totals(TH, TE, CH, CE,
                 C: tl.constexpr, N: tl.constexpr,
                 R: tl.constexpr, W: tl.constexpr):
    chains = tl.program_id(0) * W + tl.arange(0, W)
    rows = tl.arange(0, R)
    offsets = rows[:, None] * C + chains[None, :]
    mask = (rows[:, None] < N) & (chains[None, :] < C)
    h = tl.load(TH + offsets, mask, 0)
    e = tl.load(TE + offsets, mask, 0)
    h, e = tl.associative_scan((h, e), 0, _add_pair)
    tl.store(CH + offsets, h, mask)
    tl.store(CE + offsets, e, mask)


@tr.jit
def _finish(H, E, CH, CE, Y,
            SIZE: tl.constexpr, L: tl.constexpr, I: tl.constexpr,
            C: tl.constexpr, B: tl.constexpr, T: tl.constexpr):
    idx = tl.program_id(0) * T + tl.arange(0, T)
    valid = idx < SIZE
    axis = (idx // I) % L
    chain = (idx // (L * I)) * I + idx % I
    block = axis // B
    carry_idx = (block - 1) * C + chain
    ch = tl.load(CH + carry_idx, valid & (block > 0), 0)
    ce = tl.load(CE + carry_idx, valid & (block > 0), 0)
    h = tl.load(H + idx, valid, 0)
    e = tl.load(E + idx, valid, 0)
    h, e = _add_pair(ch, ce, h, e)
    tl.store(Y + idx, h + e, valid)


class ModelNew(nn.Module):
    def __init__(self, dim: int = 2):
        super().__init__()
        self.dim = int(dim)

    def forward(self, x):
        ndim = x.dim()
        assert -ndim <= self.dim < ndim, "dim must point at an existing dimension of the input"
        dim = self.dim % ndim
        length = x.shape[dim]
        if length == 1:
            return x

        inner = 1
        for size in x.shape[dim + 1:]:
            inner *= size
        count = x.numel()
        chains = count // length
        if inner == 1:
            width = 1
            block = min(2048, tr.next_power_of_2(length))
        else:
            width = min(16, tr.next_power_of_2(inner))
            block = min(256, tr.next_power_of_2(length))
        tiles = tr.cdiv(length, block)
        out = torch.empty_like(x)

        if tiles == 1:
            _local_scan[(1, tr.cdiv(chains, width))](
                x, out, out, out, out, out,
                length, inner, chains, tiles, block, width,
                num_warps=4, enable_fp_fusion=False,
            )
            return out

        h = torch.empty(x.shape, device=x.device, dtype=torch.float32)
        e = torch.empty_like(h)
        th = torch.empty((tiles, chains), device=x.device, dtype=torch.float32)
        te = torch.empty_like(th)
        ch = torch.empty_like(th)
        ce = torch.empty_like(th)

        _local_scan[(tiles, tr.cdiv(chains, width))](
            x, out, h, e, th, te,
            length, inner, chains, tiles, block, width,
            num_warps=4, enable_fp_fusion=False,
        )
        total_width = min(16, tr.next_power_of_2(chains))
        _scan_totals[(tr.cdiv(chains, total_width),)](
            th, te, ch, ce, chains, tiles,
            tr.next_power_of_2(tiles), total_width,
            num_warps=4, enable_fp_fusion=False,
        )
        _finish[(tr.cdiv(count, 1024),)](
            h, e, ch, ce, out,
            count, length, inner, chains, block, 1024,
            num_warps=4, enable_fp_fusion=False,
        )
        return out
