import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _moe_grouped_gemm_kernel(
    A,
    B,
    W,
    SORTED,
    EXPERT,
    NUM_PADDED,
    OUT,
    M,
    K,
    N,
    TOP_K,
    stride_am,
    stride_ak,
    stride_be,
    stride_bn,
    stride_bk,
    stride_wm,
    stride_wk,
    stride_sorted,
    stride_expert,
    stride_outm,
    stride_outk,
    stride_num_padded,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    row = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    col = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    kk = tl.arange(0, BLOCK_K)

    num_padded = tl.load(NUM_PADDED + stride_num_padded * 0)
    block_valid = pid_m * BLOCK_M < num_padded

    sorted_id = tl.load(
        SORTED + row * stride_sorted,
        mask=block_valid,
        other=0,
    )
    token_valid = block_valid & (sorted_id < M * TOP_K)

    token = sorted_id // TOP_K
    slot = sorted_id - token * TOP_K

    expert = tl.load(
        EXPERT + pid_m * stride_expert,
        mask=block_valid,
        other=0,
    )

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k0 in range(0, tl.cdiv(K, BLOCK_K)):
        k = k0 * BLOCK_K + kk
        k_valid = k < K

        a = tl.load(
            A
            + token[:, None] * stride_am
            + k[None, :] * stride_ak,
            mask=token_valid[:, None] & k_valid[None, :],
            other=0.0,
        ).to(tl.float32)

        b = tl.load(
            B
            + expert * stride_be
            + col[:, None] * stride_bn
            + k[None, :] * stride_bk,
            mask=(col[:, None] < N) & k_valid[None, :],
            other=0.0,
        ).to(tl.float32)

        acc += tl.dot(a, tl.trans(b))

    weight = tl.load(
        W
        + token * stride_wm
        + slot * stride_wk,
        mask=token_valid,
        other=0.0,
    ).to(tl.float32)

    result = acc * weight[:, None]

    tl.store(
        OUT
        + sorted_id[:, None] * stride_outm
        + col[None, :] * stride_outk,
        result,
        mask=token_valid[:, None] & (col[None, :] < N),
    )


class ModelNew(nn.Module):
    def __init__(self, num_experts: int, top_k: int):
        super().__init__()
        self.num_experts = num_experts
        self.top_k = top_k

    def forward(
        self,
        A,
        B,
        topk_weights,
        topk_ids,
        sorted_token_ids,
        expert_ids,
        num_tokens_post_padded,
    ):
        M, K = A.shape
        E, N, _ = B.shape
        top_k = topk_ids.shape[1]

        out = torch.empty(
            (M, top_k, N),
            device=A.device,
            dtype=A.dtype,
        )

        block_m = 64
        block_n = 128 if N >= 128 else 64
        num_m_blocks = (sorted_token_ids.shape[0] + block_m - 1) // block_m
        num_n_blocks = (N + block_n - 1) // block_n

        grid = (num_m_blocks, num_n_blocks)

        _moe_grouped_gemm_kernel[grid](
            A,
            B,
            topk_weights,
            sorted_token_ids,
            expert_ids,
            num_tokens_post_padded,
            out.view(M * top_k, N),
            M,
            K,
            N,
            top_k,
            A.stride(0),
            A.stride(1),
            B.stride(0),
            B.stride(1),
            B.stride(2),
            topk_weights.stride(0),
            topk_weights.stride(1),
            sorted_token_ids.stride(0),
            expert_ids.stride(0),
            out.stride(0),
            out.stride(1),
            num_tokens_post_padded.stride(0),
            BLOCK_M=block_m,
            BLOCK_N=block_n,
            BLOCK_K=32,
            num_warps=8 if block_n >= 128 else 4,
            num_stages=2,
        )

        return out
