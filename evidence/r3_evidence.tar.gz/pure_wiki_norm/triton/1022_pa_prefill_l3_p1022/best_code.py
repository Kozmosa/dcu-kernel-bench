import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _paged_attention_kernel(
    query_ptr,
    key_ptr,
    value_ptr,
    key_cache_ptr,
    value_cache_ptr,
    block_tables_ptr,
    query_start_ptr,
    seq_lens_ptr,
    slopes_ptr,
    out_ptr,
    num_heads: tl.constexpr,
    num_kv_heads: tl.constexpr,
    head_size: tl.constexpr,
    block_size: tl.constexpr,
    x: tl.constexpr,
    max_seq_len: tl.constexpr,
    max_q_len: tl.constexpr,
    BLOCK_D: tl.constexpr,
    HAS_ALIBI: tl.constexpr,
    SCALE: tl.constexpr,
):
    b = tl.program_id(0)
    q_idx = tl.program_id(1)
    h = tl.program_id(2)

    q_start = tl.load(query_start_ptr + b)
    q_end = tl.load(query_start_ptr + b + 1)
    q_len = q_end - q_start
    seq_len = tl.load(seq_lens_ptr + b)
    ctx_len = seq_len - q_len

    valid_q = q_idx < q_len
    token_idx = q_start + q_idx
    pos = ctx_len + q_idx

    kv_h = h // (num_heads // num_kv_heads)

    d = tl.arange(0, BLOCK_D)
    d_mask = d < head_size

    q_base = (token_idx * num_heads + h) * head_size
    q = tl.load(query_ptr + q_base + d, mask=valid_q & d_mask, other=0.0).to(tl.float32)
    q = q * SCALE

    m = tl.full((), -float("inf"), tl.float32)
    norm = tl.zeros((), dtype=tl.float32)
    acc = tl.zeros((BLOCK_D,), dtype=tl.float32)

    slope = tl.load(slopes_ptr + h) if HAS_ALIBI else tl.zeros((), dtype=tl.float32)

    for l in tl.range(0, max_seq_len):
        valid_l = valid_q & (l <= pos) & (l < seq_len)
        is_ctx = l < ctx_len
        is_new = ~is_ctx

        logical_block = l // block_size
        slot = l % block_size
        physical_block = tl.load(
            block_tables_ptr + b * max_seq_len + logical_block,
            mask=valid_l & is_ctx,
            other=0,
        )

        d8 = d // x
        r8 = d % x

        cache_k_offset = (
            physical_block * num_kv_heads * (head_size // x) * block_size * x
            + kv_h * (head_size // x) * block_size * x
            + d8 * block_size * x
            + slot * x
            + r8
        )
        cache_v_offset = (
            physical_block * num_kv_heads * head_size * block_size
            + kv_h * head_size * block_size
            + d * block_size
            + slot
        )

        new_token = q_start + l
        new_k_offset = (new_token * num_kv_heads + kv_h) * head_size + d
        new_v_offset = (new_token * num_kv_heads + kv_h) * head_size + d

        k_ctx = tl.load(
            key_cache_ptr + cache_k_offset,
            mask=valid_l & is_ctx & d_mask,
            other=0.0,
        ).to(tl.float32)
        k_new = tl.load(
            key_ptr + new_k_offset,
            mask=valid_l & is_new & d_mask,
            other=0.0,
        ).to(tl.float32)
        k = tl.where(is_ctx, k_ctx, k_new)

        v_ctx = tl.load(
            value_cache_ptr + cache_v_offset,
            mask=valid_l & is_ctx & d_mask,
            other=0.0,
        ).to(tl.float32)
        v_new = tl.load(
            value_ptr + new_v_offset,
            mask=valid_l & is_new & d_mask,
            other=0.0,
        ).to(tl.float32)
        v = tl.where(is_ctx, v_ctx, v_new)

        dot = tl.sum(q * k, axis=0)
        bias = (l - pos) * slope if HAS_ALIBI else tl.zeros((), dtype=tl.float32)
        logits = dot + bias
        logits = tl.where(valid_l, logits, -float("inf"))

        new_m = tl.maximum(m, logits)
        old_scale = tl.exp(m - new_m)
        cur_scale = tl.exp(logits - new_m)

        acc = acc * old_scale + v * cur_scale
        norm = norm * old_scale + cur_scale
        m = new_m

    inv_norm = tl.where(norm > 0.0, 1.0 / norm, 0.0)
    result = acc * inv_norm

    out_base = (token_idx * num_heads + h) * head_size
    tl.store(
        out_ptr + out_base + d,
        result,
        mask=valid_q & d_mask,
    )


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.head_size = int(head_size)
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(
        self,
        query,
        key,
        value,
        key_cache,
        value_cache,
        block_tables,
        query_start_loc,
        seq_lens,
        alibi_slopes=None,
    ):
        num_tokens, num_heads, head_size = query.shape
        num_kv_heads = key_cache.shape[1]
        block_size = value_cache.shape[3]
        x = key_cache.shape[4]
        num_seqs = seq_lens.shape[0]

        assert num_heads % num_kv_heads == 0
        assert head_size % x == 0

        max_q_len = int(
            (query_start_loc[1:] - query_start_loc[:-1]).max().item()
        )
        max_seq_len = int(seq_lens.max().item())

        out = torch.empty_like(query)

        slopes = (
            alibi_slopes
            if alibi_slopes is not None
            else torch.empty((1,), device=query.device, dtype=torch.float32)
        )

        block_d = 1
        while block_d < head_size:
            block_d *= 2

        grid = (num_seqs, max_q_len, num_heads)

        _paged_attention_kernel[grid](
            query,
            key,
            value,
            key_cache,
            value_cache,
            block_tables,
            query_start_loc,
            seq_lens,
            slopes,
            out,
            num_heads=num_heads,
            num_kv_heads=num_kv_heads,
            head_size=head_size,
            block_size=block_size,
            x=x,
            max_seq_len=max_seq_len,
            max_q_len=max_q_len,
            BLOCK_D=block_d,
            HAS_ALIBI=alibi_slopes is not None,
            SCALE=self.scale,
            num_warps=4 if head_size <= 128 else 8,
            num_stages=2,
        )

        return out
