import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _attn_stats_kernel(
    q_ptr, k_ptr, v_ptr, do_ptr, m_ptr, inv_ptr, delta_ptr,
    B, SQ, SK, HQ, HK, D, GROUP, SCALE,
    q_sb, q_ss, q_sh, q_sd,
    k_sb, k_ss, k_sh, k_sd,
    v_sb, v_ss, v_sh, v_sd,
    do_sb, do_ss, do_sh, do_sd,
    BLOCK_D: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    pid = tl.program_id(0)
    i = pid % SQ
    t = pid // SQ
    h = t % HQ
    b = t // HQ
    hk = h // GROUP

    offs_d = tl.arange(0, BLOCK_D)
    dmask = offs_d < D

    q_base = q_ptr + b * q_sb + i * q_ss + h * q_sh
    qv = tl.load(q_base + offs_d * q_sd, mask=dmask, other=0.0).to(tl.float32)

    row_max = tl.full((), -float("inf"), tl.float32)
    for js in tl.range(0, SK, BLOCK_N):
        offs_j = js + tl.arange(0, BLOCK_N)
        jmask = offs_j < SK
        k_base = k_ptr + b * k_sb + hk * k_sh
        kptrs = (
            k_base
            + offs_j[:, None] * k_ss
            + offs_d[None, :] * k_sd
        )
        kval = tl.load(
            kptrs,
            mask=jmask[:, None] & dmask[None, :],
            other=0.0,
        ).to(tl.float32)
        scores = tl.sum(kval * qv[None, :], axis=1) * SCALE
        scores = tl.where(jmask, scores, -float("inf"))
        row_max = tl.maximum(row_max, tl.max(scores, axis=0))

    norm = tl.zeros((), tl.float32)
    oval = tl.zeros((BLOCK_D,), tl.float32)

    for js in tl.range(0, SK, BLOCK_N):
        offs_j = js + tl.arange(0, BLOCK_N)
        jmask = offs_j < SK
        k_base = k_ptr + b * k_sb + hk * k_sh
        v_base = v_ptr + b * v_sb + hk * v_sh

        kptrs = (
            k_base
            + offs_j[:, None] * k_ss
            + offs_d[None, :] * k_sd
        )
        vptrs = (
            v_base
            + offs_j[:, None] * v_ss
            + offs_d[None, :] * v_sd
        )

        kval = tl.load(
            kptrs,
            mask=jmask[:, None] & dmask[None, :],
            other=0.0,
        ).to(tl.float32)
        vval = tl.load(
            vptrs,
            mask=jmask[:, None] & dmask[None, :],
            other=0.0,
        ).to(tl.float32)

        scores = tl.sum(kval * qv[None, :], axis=1) * SCALE
        scores = tl.where(jmask, scores, -float("inf"))
        weights = tl.exp(scores - row_max)
        weights = tl.where(jmask, weights, 0.0)

        norm += tl.sum(weights, axis=0)
        oval += tl.sum(weights[:, None] * vval, axis=0)

    inv_norm = 1.0 / norm
    oval *= inv_norm

    do_base = do_ptr + b * do_sb + i * do_ss + h * do_sh
    dov = tl.load(do_base + offs_d * do_sd, mask=dmask, other=0.0).to(tl.float32)
    delta = tl.sum(dov * oval, axis=0)

    out_idx = (b * HQ + h) * SQ + i
    tl.store(m_ptr + out_idx, row_max)
    tl.store(inv_ptr + out_idx, inv_norm)
    tl.store(delta_ptr + out_idx, delta)


@triton.jit
def _dq_kernel(
    q_ptr, k_ptr, v_ptr, do_ptr, m_ptr, inv_ptr, delta_ptr, dq_ptr,
    B, SQ, SK, HQ, HK, D, GROUP, SCALE,
    q_sb, q_ss, q_sh, q_sd,
    k_sb, k_ss, k_sh, k_sd,
    v_sb, v_ss, v_sh, v_sd,
    do_sb, do_ss, do_sh, do_sd,
    BLOCK_D: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    pid = tl.program_id(0)
    i = pid % SQ
    t = pid // SQ
    h = t % HQ
    b = t // HQ
    hk = h // GROUP

    offs_d = tl.arange(0, BLOCK_D)
    dmask = offs_d < D

    q_base = q_ptr + b * q_sb + i * q_ss + h * q_sh
    qv = tl.load(q_base + offs_d * q_sd, mask=dmask, other=0.0).to(tl.float32)

    do_base = do_ptr + b * do_sb + i * do_ss + h * do_sh
    dov = tl.load(do_base + offs_d * do_sd, mask=dmask, other=0.0).to(tl.float32)

    row_idx = (b * HQ + h) * SQ + i
    row_max = tl.load(m_ptr + row_idx)
    inv_norm = tl.load(inv_ptr + row_idx)
    delta = tl.load(delta_ptr + row_idx)

    dqv = tl.zeros((BLOCK_D,), tl.float32)

    for js in tl.range(0, SK, BLOCK_N):
        offs_j = js + tl.arange(0, BLOCK_N)
        jmask = offs_j < SK

        k_base = k_ptr + b * k_sb + hk * k_sh
        v_base = v_ptr + b * v_sb + hk * v_sh

        kptrs = (
            k_base
            + offs_j[:, None] * k_ss
            + offs_d[None, :] * k_sd
        )
        vptrs = (
            v_base
            + offs_j[:, None] * v_ss
            + offs_d[None, :] * v_sd
        )

        kval = tl.load(
            kptrs,
            mask=jmask[:, None] & dmask[None, :],
            other=0.0,
        ).to(tl.float32)
        vval = tl.load(
            vptrs,
            mask=jmask[:, None] & dmask[None, :],
            other=0.0,
        ).to(tl.float32)

        scores = tl.sum(kval * qv[None, :], axis=1) * SCALE
        scores = tl.where(jmask, scores, -float("inf"))
        p = tl.exp(scores - row_max) * inv_norm
        p = tl.where(jmask, p, 0.0)

        dp = tl.sum(vval * dov[None, :], axis=1)
        ds = p * (dp - delta)
        dqv += tl.sum(ds[:, None] * kval, axis=0)

    out_base = dq_ptr + ((b * SQ + i) * HQ + h) * D
    tl.store(out_base + offs_d, dqv * SCALE, mask=dmask)


@triton.jit
def _dkdv_kernel(
    q_ptr, k_ptr, v_ptr, do_ptr, m_ptr, inv_ptr, delta_ptr,
    dk_ptr, dv_ptr,
    B, SQ, SK, HQ, HK, D, GROUP, SCALE,
    q_sb, q_ss, q_sh, q_sd,
    k_sb, k_ss, k_sh, k_sd,
    v_sb, v_ss, v_sh, v_sd,
    do_sb, do_ss, do_sh, do_sd,
    BLOCK_D: tl.constexpr,
):
    pid = tl.program_id(0)
    dblock = pid % tl.cdiv(D, BLOCK_D)
    t = pid // tl.cdiv(D, BLOCK_D)
    j = t % SK
    u = t // SK
    hk = u % HK
    b = u // HK

    offs_d = dblock * BLOCK_D + tl.arange(0, BLOCK_D)
    dmask = offs_d < D

    k_base = k_ptr + b * k_sb + j * k_ss + hk * k_sh
    v_base = v_ptr + b * v_sb + j * v_ss + hk * v_sh
    kv = tl.load(k_base + offs_d * k_sd, mask=dmask, other=0.0).to(tl.float32)
    vv = tl.load(v_base + offs_d * v_sd, mask=dmask, other=0.0).to(tl.float32)

    dkv = tl.zeros((BLOCK_D,), tl.float32)
    dvv = tl.zeros((BLOCK_D,), tl.float32)

    hstart = hk * GROUP
    for gh in tl.range(0, GROUP):
        h = hstart + gh
        for i in tl.range(0, SQ):
            q_base = q_ptr + b * q_sb + i * q_ss + h * q_sh
            do_base = do_ptr + b * do_sb + i * do_ss + h * do_sh

            qv = tl.load(q_base + tl.arange(0, BLOCK_D) * q_sd,
                         mask=tl.arange(0, BLOCK_D) < D,
                         other=0.0).to(tl.float32)
            dov = tl.load(do_base + tl.arange(0, BLOCK_D) * do_sd,
                          mask=tl.arange(0, BLOCK_D) < D,
                          other=0.0).to(tl.float32)

            row_idx = (b * HQ + h) * SQ + i
            row_max = tl.load(m_ptr + row_idx)
            inv_norm = tl.load(inv_ptr + row_idx)
            delta = tl.load(delta_ptr + row_idx)

            score = tl.sum(qv * tl.load(
                k_base + tl.arange(0, BLOCK_D) * k_sd,
                mask=tl.arange(0, BLOCK_D) < D,
                other=0.0,
            ).to(tl.float32), axis=0) * SCALE
            p = tl.exp(score - row_max) * inv_norm
            dp = tl.sum(dov * vv, axis=0)
            ds = p * (dp - delta)

            dkv += ds * qv
            dvv += p * dov

    out_base = dk_ptr + ((b * SK + j) * HK + hk) * D
    out_vbase = dv_ptr + ((b * SK + j) * HK + hk) * D
    tl.store(out_base + offs_d, dkv * SCALE, mask=dmask)
    tl.store(out_vbase + offs_d, dvv, mask=dmask)


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, q, k, v, do):
        B, SQ, HQ, D = q.shape
        _, SK, HK, _ = k.shape
        assert HQ % HK == 0
        GROUP = HQ // HK

        dq = torch.empty_like(q)
        dk = torch.empty_like(k)
        dv = torch.empty_like(v)

        stats_shape = (B, HQ, SQ)
        row_max = torch.empty(stats_shape, device=q.device, dtype=torch.float32)
        inv_norm = torch.empty_like(row_max)
        delta = torch.empty_like(row_max)

        qsb, qss, qsh, qsd = q.stride()
        ksb, kss, ksh, ksd = k.stride()
        vsb, vss, vsh, vsd = v.stride()
        dosb, doss, dosh, dosd = do.stride()

        block_d = min(256, 1 << (D - 1).bit_length())
        block_n = 64

        _attn_stats_kernel[(B * HQ * SQ,)](
            q, k, v, do, row_max, inv_norm, delta,
            B, SQ, SK, HQ, HK, D, GROUP, self.sm_scale,
            qsb, qss, qsh, qsd,
            ksb, kss, ksh, ksd,
            vsb, vss, vsh, vsd,
            dosb, doss, dosh, dosd,
            BLOCK_D=block_d, BLOCK_N=block_n,
            num_warps=4,
        )

        _dq_kernel[(B * HQ * SQ,)](
            q, k, v, do, row_max, inv_norm, delta, dq,
            B, SQ, SK, HQ, HK, D, GROUP, self.sm_scale,
            qsb, qss, qsh, qsd,
            ksb, kss, ksh, ksd,
            vsb, vss, vsh, vsd,
            dosb, doss, dosh, dosd,
            BLOCK_D=block_d, BLOCK_N=block_n,
            num_warps=4,
        )

        grid_dkdv = (B * HK * SK * triton.cdiv(D, block_d),)
        _dkdv_kernel[grid_dkdv](
            q, k, v, do, row_max, inv_norm, delta, dk, dv,
            B, SQ, SK, HQ, HK, D, GROUP, self.sm_scale,
            qsb, qss, qsh, qsd,
            ksb, kss, ksh, ksd,
            vsb, vss, vsh, vsd,
            dosb, doss, dosh, dosd,
            BLOCK_D=block_d,
            num_warps=4,
        )

        return torch.cat((dq.reshape(-1), dk.reshape(-1), dv.reshape(-1)))
