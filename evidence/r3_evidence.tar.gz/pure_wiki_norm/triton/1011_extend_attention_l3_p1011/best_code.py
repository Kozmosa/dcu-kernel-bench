import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _ragged_attention_kernel(
    q_ptr,
    k_ext_ptr,
    v_ext_ptr,
    k_buf_ptr,
    v_buf_ptr,
    qo_ptr,
    kv_ptr,
    idx_ptr,
    out_ptr,
    total_extend,
    hq,
    hkv,
    dq,
    dv,
    group,
    scale,
    causal,
    max_tokens,
    stride_qt,
    stride_qh,
    stride_ket,
    stride_keh,
    stride_vet,
    stride_veh,
    stride_kbp,
    stride_kbh,
    stride_vbp,
    stride_vbh,
    stride_outt,
    stride_outh,
    BLOCK_D: tl.constexpr,
    BLOCK_V: tl.constexpr,
):
    pid_h = tl.program_id(0)
    pid_b = tl.program_id(1)
    pid_t = tl.program_id(2)

    qs = tl.load(qo_ptr + pid_b)
    qe = tl.load(qo_ptr + pid_b + 1)
    ks = tl.load(kv_ptr + pid_b)
    ke = tl.load(kv_ptr + pid_b + 1)

    e_len = qe - qs
    p_len = ke - ks
    active = pid_t < e_len
    qrow = qs + pid_t
    kvh = pid_h // group

    d = tl.arange(0, BLOCK_D)
    v = tl.arange(0, BLOCK_V)

    q_offsets = qrow * stride_qt + pid_h * stride_qh + d
    q = tl.load(q_ptr + q_offsets, mask=d < dq, other=0.0).to(tl.float32)

    m_i = tl.full((), -1.0e30, tl.float32)
    l_i = tl.zeros((), dtype=tl.float32)
    acc = tl.zeros((BLOCK_V,), dtype=tl.float32)

    for j in tl.range(0, max_tokens):
        is_prefix = j < p_len
        if causal:
            key_limit = p_len + pid_t + 1
        else:
            key_limit = p_len + e_len

        key_valid = (j < key_limit) & active
        prefix_pos = ks + j
        ext_pos = qs + j - p_len

        pool_row = tl.load(
            idx_ptr + prefix_pos,
            mask=is_prefix & (j < p_len),
            other=0,
        )

        k_prefix_offsets = (
            pool_row * stride_kbp
            + kvh * stride_kbh
            + d
        )
        k_extend_offsets = (
            ext_pos * stride_ket
            + kvh * stride_keh
            + d
        )

        k_prefix = tl.load(
            k_buf_ptr + k_prefix_offsets,
            mask=is_prefix & (d < dq) & (j < p_len),
            other=0.0,
        ).to(tl.float32)
        k_extend = tl.load(
            k_ext_ptr + k_extend_offsets,
            mask=(~is_prefix) & (d < dq) & (ext_pos >= qs) & (ext_pos < qe),
            other=0.0,
        ).to(tl.float32)

        k = tl.where(is_prefix, k_prefix, k_extend)
        logit = tl.sum(q * k, axis=0) * scale
        logit = tl.where(key_valid, logit, -1.0e30)

        new_m = tl.maximum(m_i, logit)
        alpha = tl.exp(m_i - new_m)
        beta = tl.exp(logit - new_m)

        v_prefix_offsets = (
            pool_row * stride_vbp
            + kvh * stride_vbh
            + v
        )
        v_extend_offsets = (
            ext_pos * stride_vet
            + kvh * stride_veh
            + v
        )

        val_prefix = tl.load(
            v_buf_ptr + v_prefix_offsets,
            mask=is_prefix & (v < dv) & (j < p_len),
            other=0.0,
        ).to(tl.float32)
        val_extend = tl.load(
            v_ext_ptr + v_extend_offsets,
            mask=(~is_prefix) & (v < dv) & (ext_pos >= qs) & (ext_pos < qe),
            other=0.0,
        ).to(tl.float32)

        val = tl.where(is_prefix, val_prefix, val_extend)
        acc = acc * alpha + val * beta
        l_i = l_i * alpha + beta
        m_i = new_m

    acc = acc / l_i
    out_offsets = qrow * stride_outt + pid_h * stride_outh + v
    tl.store(
        out_ptr + out_offsets,
        acc,
        mask=active & (v < dv),
    )


class ModelNew(nn.Module):
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)

    def forward(
        self,
        q_extend,
        k_extend,
        v_extend,
        k_buffer,
        v_buffer,
        qo_indptr,
        kv_indptr,
        kv_indices,
    ):
        qo_indptr = qo_indptr.to(torch.int32)
        kv_indptr = kv_indptr.to(torch.int32)
        kv_indices = kv_indices.to(torch.long)

        total_extend, hq, dq = q_extend.shape
        hkv = k_extend.shape[1]
        dv = v_extend.shape[-1]
        group = hq // hkv

        assert hq == hkv * group, "num_q_heads must be an integer multiple of num_kv_heads"

        scale = self.sm_scale
        if scale is None:
            scale = 1.0 / math.sqrt(dq)

        batch = qo_indptr.shape[0] - 1
        out = torch.empty(
            (total_extend, hq, dv),
            dtype=q_extend.dtype,
            device=q_extend.device,
        )

        block_d = triton.next_power_of_2(dq)
        block_v = triton.next_power_of_2(dv)
        max_tokens = int(kv_indices.numel() + total_extend)

        if dv <= 64:
            num_warps = 2
        elif dv <= 128:
            num_warps = 4
        else:
            num_warps = 8

        grid = (hq, batch, total_extend)

        _ragged_attention_kernel[grid](
            q_extend,
            k_extend,
            v_extend,
            k_buffer,
            v_buffer,
            qo_indptr,
            kv_indptr,
            kv_indices,
            out,
            total_extend,
            hq,
            hkv,
            dq,
            dv,
            group,
            scale,
            int(self.causal),
            max_tokens,
            q_extend.stride(0),
            q_extend.stride(1),
            k_extend.stride(0),
            k_extend.stride(1),
            v_extend.stride(0),
            v_extend.stride(1),
            k_buffer.stride(0),
            k_buffer.stride(1),
            v_buffer.stride(0),
            v_buffer.stride(1),
            out.stride(0),
            out.stride(1),
            BLOCK_D=block_d,
            BLOCK_V=block_v,
            num_warps=num_warps,
            num_stages=2,
        )
        return out
