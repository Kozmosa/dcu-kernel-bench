import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _affine_kernel(
    X, A, B, Y,
    N: tl.constexpr,
    A_KIND: tl.constexpr,
    B_KIND: tl.constexpr,
    BLOCK: tl.constexpr,
):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    mask = offsets < N
    x = tl.load(X + offsets, mask=mask, other=0).to(tl.float32)

    if A_KIND == 0:
        a = A.to(tl.float32)
    elif A_KIND == 1:
        a = tl.load(A).to(tl.float32)
    else:
        a = tl.load(A + offsets, mask=mask, other=0).to(tl.float32)

    if B_KIND == 0:
        b = B.to(tl.float32)
    elif B_KIND == 1:
        b = tl.load(B).to(tl.float32)
    else:
        b = tl.load(B + offsets, mask=mask, other=0).to(tl.float32)

    product = x * a
    result = product + b
    tl.store(Y + offsets, result, mask=mask)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x, a, b):
        n = x.numel()
        out = torch.empty_like(x)
        if n == 0:
            return out

        if isinstance(a, torch.Tensor):
            if a.numel() == 1 and a.device.type == "cpu":
                a = float(a.item())
                a_kind = 0
            else:
                a_kind = 1 if a.numel() == 1 else 2
        else:
            a = float(a)
            a_kind = 0

        if isinstance(b, torch.Tensor):
            if b.numel() == 1 and b.device.type == "cpu":
                b = float(b.item())
                b_kind = 0
            else:
                b_kind = 1 if b.numel() == 1 else 2
        else:
            b = float(b)
            b_kind = 0

        block = 1024
        with torch.cuda.device(x.device):
            _affine_kernel[(triton.cdiv(n, block),)](
                x, a, b, out,
                N=n,
                A_KIND=a_kind,
                B_KIND=b_kind,
                BLOCK=block,
                num_warps=4,
                enable_fp_fusion=False,
            )
        return out
