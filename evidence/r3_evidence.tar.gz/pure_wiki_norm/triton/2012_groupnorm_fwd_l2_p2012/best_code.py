import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _groupnorm_kernel(
    x_ptr,
    scale_ptr,
    bias_ptr,
    out_ptr,
    n_elements,
    d_elements,
    groups,
    channels_per_group,
    spatial,
    eps,
    apply_swish: tl.constexpr,
    BLOCK: tl.constexpr,
):
    pid = tl.program_id(0)
    ng = pid
    n = ng // groups
    g = ng - n * groups

    row_base = ng * d_elements
    y_base = row_base
    stats_base = n_elements + ng
    inv_base = n_elements + groups * (n_elements // (n * 0 + 1))  # overwritten below

    # Number of (N, G) statistics entries is known from the launch geometry.
    # The second statistics segment starts immediately after the first one.
    total_groups = tl.num_programs(0)
    inv_offset = n_elements + total_groups
    mean_ptr = out_ptr + n_elements + ng
    inv_ptr = out_ptr + inv_offset + ng

    sum_x = tl.zeros((), dtype=tl.float32)

    for start in tl.range(0, d_elements, BLOCK):
        offs = start + tl.arange(0, BLOCK)
        mask = offs < d_elements
        xv = tl.load(x_ptr + row_base + offs, mask=mask, other=0.0).to(tl.float32)
        sum_x += tl.sum(tl.where(mask, xv, 0.0), axis=0)

    mean = sum_x / d_elements
    tl.store(mean_ptr, mean)

    sum_sq = tl.zeros((), dtype=tl.float32)

    for start in tl.range(0, d_elements, BLOCK):
        offs = start + tl.arange(0, BLOCK)
        mask = offs < d_elements
        xv = tl.load(x_ptr + row_base + offs, mask=mask, other=0.0).to(tl.float32)
        dx = xv - mean
        sum_sq += tl.sum(tl.where(mask, dx * dx, 0.0), axis=0)

    var = sum_sq / d_elements
    inv_var = tl.rsqrt(var + eps)
    tl.store(inv_ptr, inv_var)

    for start in tl.range(0, d_elements, BLOCK):
        offs = start + tl.arange(0, BLOCK)
        mask = offs < d_elements

        xv = tl.load(x_ptr + row_base + offs, mask=mask, other=0.0).to(tl.float32)
        local_channel = offs // spatial
        channel = g * channels_per_group + local_channel

        sf = tl.load(scale_ptr + channel, mask=mask, other=0.0).to(tl.float32)
        bf = tl.load(bias_ptr + channel, mask=mask, other=0.0).to(tl.float32)

        gn = (xv - mean) * inv_var * sf + bf

        if apply_swish:
            y = gn / (1.0 + tl.exp(-gn))
        else:
            y = gn

        tl.store(out_ptr + y_base + offs, y, mask=mask)


class ModelNew(nn.Module):
    def __init__(self, variant: str = "groupnorm", groups: int = 2, eps: float = 1e-5):
        super().__init__()
        assert variant in ("groupnorm", "groupnorm_swish"), (
            "variant must be one of groupnorm / groupnorm_swish"
        )
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.variant = variant
        self.groups = int(groups)
        self.eps = float(eps)

    def forward(self, x, scale, bias):
        n, c, h, w = x.shape
        g = self.groups
        assert 1 <= g <= c and c % g == 0, (
            "groups must divide the number of channels and 1 <= groups <= C"
        )

        channels_per_group = c // g
        spatial = h * w
        d_elements = channels_per_group * spatial
        y_elements = n * c * spatial
        stats_elements = n * g

        out = torch.empty(
            y_elements + 2 * stats_elements,
            device=x.device,
            dtype=torch.float32,
        )

        grid = (n * g,)
        _groupnorm_kernel[grid](
            x,
            scale,
            bias,
            out,
            y_elements,
            d_elements,
            g,
            channels_per_group,
            spatial,
            self.eps,
            apply_swish=(self.variant == "groupnorm_swish"),
            BLOCK=256,
            num_warps=4,
        )
        return out
