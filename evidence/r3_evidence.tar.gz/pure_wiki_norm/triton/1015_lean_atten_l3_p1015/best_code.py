import math
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _attention(
    Q, K, V, L, C, O,
    Q0: tl.constexpr, Q1: tl.constexpr, Q2: tl.constexpr,
    K0: tl.constexpr, K1: tl.constexpr, K2: tl.constexpr,
    V0: tl.constexpr, V1: tl.constexpr, V2: tl.constexpr,
    H: tl.constexpr, D: tl.constexpr, QLEN: tl.constexpr,
    NS: tl.constexpr, LS: tl.constexpr, SCALE: tl.constexpr,
    CT: tl.constexpr, CV: tl.constexpr,
    BD: tl.constexpr, BM: tl.constexpr, BN: tl.constexpr,
):
    block = tl.program_id(0)
    h = tl.program_id(1)
    b = tl.program_id(2)
    seqs = tl.arange(0, LS)
    lengths = tl.load(L + seqs, seqs < NS, 0)
    start = tl.sum(tl.where(seqs < b, lengths, 0), 0)
    length = tl.load(L + b)
    if CT:
        causal = tl.load(C) != 0
    else:
        causal = CV

    rows = block * BM + tl.arange(0, BM)
    dims = tl.arange(0, BD)
    cols = tl.arange(0, BN)
    q = tl.load(
        Q + (b * QLEN + rows[:, None]) * Q0
        + h * Q1 + dims[None, :] * Q2,
        (rows[:, None] < QLEN) & (dims[None, :] < D), 0,
    ).to(tl.float32)
    m = tl.full((BM,), -float("inf"), tl.float32)
    z = tl.full((BM,), 0, tl.float32)
    acc = tl.full((BM, BD), 0, tl.float32)
    end = length
    if causal:
        end = tl.minimum(end, (block + 1) * BM)

    for base in range(0, end, BN):
        js = base + cols
        k = tl.load(
            K + (start + js[None, :]) * K0
            + h * K1 + dims[:, None] * K2,
            (js[None, :] < length) & (dims[:, None] < D), 0,
        ).to(tl.float32)
        s = tl.dot(q, k, input_precision="ieee") * SCALE
        valid = js[None, :] < length
        if causal:
            valid = valid & (js[None, :] <= rows[:, None])
        s = tl.where(valid, s, -float("inf"))
        new_m = tl.maximum(m, tl.max(s, 1))
        alpha = tl.exp(m - new_m)
        p = tl.exp(s - new_m[:, None])
        v = tl.load(
            V + (start + js[:, None]) * V0
            + h * V1 + dims[None, :] * V2,
            (js[:, None] < length) & (dims[None, :] < D), 0,
        ).to(tl.float32)
        acc = acc * alpha[:, None] + tl.dot(p, v, input_precision="ieee")
        z = z * alpha + tl.sum(p, 1)
        m = new_m
    result = acc / z[:, None]
    tl.store(
        O + ((b * QLEN + rows[:, None]) * H + h) * D + dims[None, :],
        result, (rows[:, None] < QLEN) & (dims[None, :] < D),
    )


@tr.jit
def _decode(
    Q, K, V, L, C, P, M, Z,
    Q0: tl.constexpr, Q1: tl.constexpr, Q2: tl.constexpr,
    K0: tl.constexpr, K1: tl.constexpr, K2: tl.constexpr,
    V0: tl.constexpr, V1: tl.constexpr, V2: tl.constexpr,
    H: tl.constexpr, D: tl.constexpr, QLEN: tl.constexpr,
    NS: tl.constexpr, LS: tl.constexpr, SCALE: tl.constexpr,
    CT: tl.constexpr, CV: tl.constexpr,
    BD: tl.constexpr, BN: tl.constexpr, SPLITS: tl.constexpr,
):
    row = tl.program_id(0)
    h = tl.program_id(1)
    split = tl.program_id(2)
    b = row // QLEN
    qi = row % QLEN
    ids = tl.arange(0, LS)
    lengths = tl.load(L + ids, ids < NS, 0)
    start = tl.sum(tl.where(ids < b, lengths, 0), 0)
    length = tl.load(L + b)
    if CT:
        causal = tl.load(C) != 0
    else:
        causal = CV
    if causal:
        length = tl.minimum(length, qi + 1)
    chunk = tl.cdiv(length, SPLITS)
    lo = split * chunk
    hi = tl.minimum(lo + chunk, length)
    ds = tl.arange(0, BD)
    js = tl.arange(0, BN)
    q = tl.load(Q + row * Q0 + h * Q1 + ds * Q2, ds < D, 0).to(tl.float32)
    m = tl.full((), -float("inf"), tl.float32)
    z = tl.full((), 0, tl.float32)
    acc = tl.full((BD,), 0, tl.float32)
    for base in range(lo, hi, BN):
        pos = base + js
        k = tl.load(
            K + (start + pos[:, None]) * K0 + h * K1 + ds[None, :] * K2,
            (pos[:, None] < hi) & (ds[None, :] < D), 0,
        ).to(tl.float32)
        s = tl.sum(k * q[None, :], 1) * SCALE
        s = tl.where(pos < hi, s, -float("inf"))
        nm = tl.maximum(m, tl.max(s, 0))
        a = tl.exp(m - nm)
        p = tl.exp(s - nm)
        v = tl.load(
            V + (start + pos[:, None]) * V0 + h * V1 + ds[None, :] * V2,
            (pos[:, None] < hi) & (ds[None, :] < D), 0,
        ).to(tl.float32)
        acc = acc * a + tl.sum(p[:, None] * v, 0)
        z = z * a + tl.sum(p, 0)
        m = nm
    index = (row * H + h) * SPLITS + split
    tl.store(P + index * D + ds, acc, ds < D)
    tl.store(M + index, m)
    tl.store(Z + index, z)


@tr.jit
def _merge(P, M, Z, O, D: tl.constexpr, BD: tl.constexpr, S: tl.constexpr):
    row = tl.program_id(0)
    ss = tl.arange(0, S)
    dd = tl.arange(0, BD)
    m = tl.load(M + row * S + ss)
    z = tl.load(Z + row * S + ss)
    top = tl.max(m, 0)
    w = tl.exp(m - top)
    p = tl.load(
        P + (row * S + ss[:, None]) * D + dd[None, :],
        dd[None, :] < D, 0,
    )
    result = tl.sum(p * w[:, None], 0) / tl.sum(z * w, 0)
    tl.store(O + row * D + dd, result, dd < D)


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)

    def forward(self, q, k, v, kv_lens, causal):
        n = kv_lens.numel()
        total, h, d = q.shape
        qlen = total // n
        out = torch.empty(q.shape, dtype=q.dtype, device=q.device)
        if kv_lens.device != q.device:
            kv_lens = kv_lens.to(device=q.device)
        ct = isinstance(causal, torch.Tensor) and causal.is_cuda
        cv = False if ct else bool(causal)
        cp = causal if ct else kv_lens
        common = dict(
            Q0=q.stride(0), Q1=q.stride(1), Q2=q.stride(2),
            K0=k.stride(0), K1=k.stride(1), K2=k.stride(2),
            V0=v.stride(0), V1=v.stride(1), V2=v.stride(2),
            H=h, D=d, QLEN=qlen, NS=n, LS=tr.next_power_of_2(n),
            SCALE=self.sm_scale, CT=ct, CV=cv, BD=tr.next_power_of_2(d),
        )
        if qlen <= 4:
            splits = 16
            p = torch.empty((total * h, splits, d), device=q.device, dtype=torch.float32)
            m = torch.empty((total * h, splits), device=q.device, dtype=torch.float32)
            z = torch.empty_like(m)
            _decode[(total, h, splits)](
                q, k, v, kv_lens, cp, p, m, z,
                **common, BN=32, SPLITS=splits, num_warps=4,
            )
            _merge[(total * h,)](
                p, m, z, out, D=d, BD=tr.next_power_of_2(d), S=splits,
                num_warps=4,
            )
        else:
            _attention[(tr.cdiv(qlen, 16), h, n)](
                q, k, v, kv_lens, cp, out,
                **common, BM=16, BN=32, num_warps=4,
            )
        return out
