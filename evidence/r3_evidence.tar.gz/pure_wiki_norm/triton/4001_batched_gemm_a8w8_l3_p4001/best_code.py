import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _quant_gemm_kernel(
    x_ptr,
    w_ptr,
    xs_ptr,
    ws_ptr,
    out_ptr,
    B,
    M,
    N,
    K,
    sx_b,
    sx_m,
    sx_k,
    sw_b,
    sw_n,
    sw_k,
    sxs_b,
    sxs_m,
    sws_b,
    sws_n,
    so_b,
    so_m,
    so_n,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    pid_b = tl.program_id(2)

    m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    k = tl.arange(0, BLOCK_K)

    m_mask = m < M
    n_mask = n < N

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k0 in range(0, K, BLOCK_K):
        kk = k0 + k
        k_mask = kk < K

        x_offsets = (
            pid_b * sx_b
            + m[:, None] * sx_m
            + kk[None, :] * sx_k
        )
        w_offsets = (
            pid_b * sw_b
            + n[:, None] * sw_n
            + kk[None, :] * sw_k
        )

        xv = tl.load(
            x_ptr + x_offsets,
            mask=m_mask[:, None] & k_mask[None, :],
            other=0,
        ).to(tl.float32)
        wv = tl.load(
            w_ptr + w_offsets,
            mask=n_mask[:, None] & k_mask[None, :],
            other=0,
        ).to(tl.float32)

        acc += tl.dot(xv, tl.trans(wv))

    xs = tl.load(
        xs_ptr + pid_b * sxs_b + m * sxs_m,
        mask=m_mask,
        other=0.0,
    )
    ws = tl.load(
        ws_ptr + pid_b * sws_b + n * sws_n,
        mask=n_mask,
        other=0.0,
    )

    result = acc * xs[:, None] * ws[None, :]

    out_offsets = (
        pid_b * so_b
        + m[:, None] * so_m
        + n[None, :] * so_n
    )
    tl.store(
        out_ptr + out_offsets,
        result,
        mask=m_mask[:, None] & n_mask[None, :],
    )


@triton.jit
def _bias_kernel(
    out_ptr,
    bias_ptr,
    B,
    M,
    N,
    so_b,
    so_m,
    so_n,
    sb_b,
    sb_n,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    pid_b = tl.program_id(2)

    m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

    m_mask = m < M
    n_mask = n < N

    out_offsets = (
        pid_b * so_b
        + m[:, None] * so_m
        + n[None, :] * so_n
    )
    bias_offsets = pid_b * sb_b + n * sb_n

    value = tl.load(
        out_ptr + out_offsets,
        mask=m_mask[:, None] & n_mask[None, :],
        other=0,
    )
    bias_value = tl.load(
        bias_ptr + bias_offsets,
        mask=n_mask,
        other=0,
    )

    tl.store(
        out_ptr + out_offsets,
        value + bias_value[None, :],
        mask=m_mask[:, None] & n_mask[None, :],
    )


class ModelNew(nn.Module):
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)

    def forward(self, xq, wq, x_scale, w_scale, bias):
        xq = xq.to(torch.int8).contiguous()
        wq = wq.to(torch.int8).contiguous()

        if self.use_bias:
            bias = bias.to(self.out_dtype).contiguous()

        x_scale = x_scale.to(torch.float32).contiguous()
        w_scale = w_scale.to(torch.float32).contiguous()

        B, M, K = xq.shape
        N = wq.shape[1]
        assert K == wq.shape[2], "xq and wq must agree on the K dimension"

        out = torch.empty(
            (B, M, N),
            device=xq.device,
            dtype=self.out_dtype,
        )

        BLOCK_M = 32
        BLOCK_N = 64
        BLOCK_K = 64

        grid = (
            (M + BLOCK_M - 1) // BLOCK_M,
            (N + BLOCK_N - 1) // BLOCK_N,
            B,
        )

        _quant_gemm_kernel[grid](
            xq,
            wq,
            x_scale,
            w_scale,
            out,
            B,
            M,
            N,
            K,
            xq.stride(0),
            xq.stride(1),
            xq.stride(2),
            wq.stride(0),
            wq.stride(1),
            wq.stride(2),
            x_scale.stride(0),
            x_scale.stride(1),
            w_scale.stride(0),
            w_scale.stride(2),
            out.stride(0),
            out.stride(1),
            out.stride(2),
            BLOCK_M=BLOCK_M,
            BLOCK_N=BLOCK_N,
            BLOCK_K=BLOCK_K,
        )

        if self.use_bias:
            bias_grid = (
                (M + BLOCK_M - 1) // BLOCK_M,
                (N + BLOCK_N - 1) // BLOCK_N,
                B,
            )
            _bias_kernel[bias_grid](
                out,
                bias,
                B,
                M,
                N,
                out.stride(0),
                out.stride(1),
                out.stride(2),
                bias.stride(0),
                bias.stride(2),
                BLOCK_M=BLOCK_M,
                BLOCK_N=BLOCK_N,
            )

        return out
