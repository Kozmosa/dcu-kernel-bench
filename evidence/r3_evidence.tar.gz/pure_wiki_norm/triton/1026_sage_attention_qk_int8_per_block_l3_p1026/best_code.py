import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _attention_kernel(
    q_ptr,
    k_ptr,
    v_ptr,
    qs_ptr,
    ks_ptr,
    mask_ptr,
    out_ptr,
    q_len,
    kv_len,
    head_dim,
    num_q_heads,
    num_kv_heads,
    q_blocks,
    k_blocks,
    group,
    stride_qb,
    stride_qh,
    stride_qi,
    stride_qd,
    stride_kb,
    stride_kh,
    stride_ki,
    stride_kd,
    stride_vb,
    stride_vh,
    stride_vi,
    stride_vd,
    stride_qsb,
    stride_qsh,
    stride_qss,
    stride_ksb,
    stride_ksh,
    stride_kss,
    stride_ob,
    stride_oh,
    stride_oi,
    stride_od,
    stride_mb,
    stride_mk,
    BLOCK_D: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_d = tl.program_id(3)
    pid_i = tl.program_id(2)
    pid_h = tl.program_id(1)
    pid_b = tl.program_id(0)

    d = pid_d * BLOCK_D + tl.arange(0, BLOCK_D)
    dmask = d < head_dim

    q_base = (
        pid_b * stride_qb
        + pid_h * stride_qh
        + pid_i * stride_qi
    )
    q = tl.load(q_ptr + q_base + d * stride_qd, mask=dmask, other=0)
    q = q.to(tl.float32)

    qsb = (
        pid_b * stride_qsb
        + pid_h * stride_qsh
        + (pid_i // 128) * stride_qss
    )
    q_scale = tl.load(qs_ptr + qsb).to(tl.float32)

    kv_head = pid_h // group
    k_head_base = pid_b * stride_kb + kv_head * stride_kh
    v_head_base = pid_b * stride_vb + kv_head * stride_vh

    neg_inf = float("-inf")
    row_max = neg_inf

    for start in range(0, kv_len, BLOCK_K):
        j = start + tl.arange(0, BLOCK_K)
        jmask = j < kv_len

        k_offsets = (
            k_head_base
            + j[:, None] * stride_ki
            + d[None, :] * stride_kd
        )
        kval = tl.load(
            k_ptr + k_offsets,
            mask=jmask[:, None] & dmask[None, :],
            other=0,
        ).to(tl.float32)

        dots = tl.sum(q[None, :] * kval, axis=1)

        ksb = (
            pid_b * stride_ksb
            + kv_head * stride_ksh
            + (j // 64) * stride_kss
        )
        k_scale = tl.load(ks_ptr + ksb, mask=jmask, other=0).to(tl.float32)

        logits = dots * q_scale * k_scale / 1.4426950408889634

        mmask = tl.load(
            mask_ptr + pid_i * stride_mb + j * stride_mk,
            mask=jmask,
            other=0,
        )
        logits = tl.where(mmask, logits, neg_inf)
        row_max = tl.maximum(row_max, tl.max(logits, axis=0))

    denom = 0.0
    for start in range(0, kv_len, BLOCK_K):
        j = start + tl.arange(0, BLOCK_K)
        jmask = j < kv_len

        k_offsets = (
            k_head_base
            + j[:, None] * stride_ki
            + d[None, :] * stride_kd
        )
        kval = tl.load(
            k_ptr + k_offsets,
            mask=jmask[:, None] & dmask[None, :],
            other=0,
        ).to(tl.float32)

        dots = tl.sum(q[None, :] * kval, axis=1)

        ksb = (
            pid_b * stride_ksb
            + kv_head * stride_ksh
            + (j // 64) * stride_kss
        )
        k_scale = tl.load(ks_ptr + ksb, mask=jmask, other=0).to(tl.float32)

        logits = dots * q_scale * k_scale / 1.4426950408889634

        mmask = tl.load(
            mask_ptr + pid_i * stride_mb + j * stride_mk,
            mask=jmask,
            other=0,
        )
        logits = tl.where(mmask, logits, neg_inf)
        weights = tl.where(mmask, tl.exp(logits - row_max), 0.0)
        denom += tl.sum(weights, axis=0)

    inv_denom = 1.0 / denom
    acc = tl.zeros((BLOCK_D,), dtype=tl.float32)

    for start in range(0, kv_len, BLOCK_K):
        j = start + tl.arange(0, BLOCK_K)
        jmask = j < kv_len

        k_offsets = (
            k_head_base
            + j[:, None] * stride_ki
            + d[None, :] * stride_kd
        )
        kval = tl.load(
            k_ptr + k_offsets,
            mask=jmask[:, None] & dmask[None, :],
            other=0,
        ).to(tl.float32)

        dots = tl.sum(q[None, :] * kval, axis=1)

        ksb = (
            pid_b * stride_ksb
            + kv_head * stride_ksh
            + (j // 64) * stride_kss
        )
        k_scale = tl.load(ks_ptr + ksb, mask=jmask, other=0).to(tl.float32)

        logits = dots * q_scale * k_scale / 1.4426950408889634

        mmask = tl.load(
            mask_ptr + pid_i * stride_mb + j * stride_mk,
            mask=jmask,
            other=0,
        )
        weights = tl.where(
            mmask,
            tl.exp(logits - row_max) * inv_denom,
            0.0,
        )
        weights = weights.to(tl.float16)

        v_offsets = (
            v_head_base
            + j[:, None] * stride_vi
            + d[None, :] * stride_vd
        )
        vval = tl.load(
            v_ptr + v_offsets,
            mask=jmask[:, None] & dmask[None, :],
            other=0,
        ).to(tl.float16)

        prod = (weights[:, None] * vval).to(tl.float32)
        acc += tl.sum(prod, axis=0)

    out_base = (
        pid_b * stride_ob
        + pid_h * stride_oh
        + pid_i * stride_oi
    )
    tl.store(
        out_ptr + out_base + d * stride_od,
        acc.to(tl.float16),
        mask=dmask,
    )


class ModelNew(nn.Module):
    def __init__(self, tensor_layout="HND"):
        super().__init__()
        assert tensor_layout in ("HND", "NHD"), "tensor_layout only supports HND / NHD"
        self.tensor_layout = tensor_layout

    def forward(self, q_int8, k_int8, v, q_scale, k_scale, attn_mask):
        q_int8 = q_int8.to(torch.int8)
        k_int8 = k_int8.to(torch.int8)
        v = v.to(torch.float16)
        q_scale = q_scale.to(torch.float32)
        k_scale = k_scale.to(torch.float32)
        attn_mask = attn_mask.to(torch.bool)

        if self.tensor_layout == "NHD":
            q = q_int8.permute(0, 2, 1, 3).contiguous()
            k = k_int8.permute(0, 2, 1, 3).contiguous()
            vv = v.permute(0, 2, 1, 3).contiguous()
        else:
            q = q_int8.contiguous()
            k = k_int8.contiguous()
            vv = v.contiguous()

        q_scale = q_scale.contiguous()
        k_scale = k_scale.contiguous()
        attn_mask = attn_mask.contiguous()

        b, hq, qo_len, head_dim = q.shape
        _, hkv, kv_len, _ = k.shape
        group = hq // hkv

        assert hq == hkv * group
        assert head_dim in (64, 128)

        out = torch.empty(
            (b, hq, qo_len, head_dim),
            device=q.device,
            dtype=torch.float16,
        )

        q_blocks = (qo_len + 127) // 128
        k_blocks = (kv_len + 63) // 64

        grid = (b, hq, qo_len, (head_dim + 127) // 128)

        _attention_kernel[grid](
            q,
            k,
            vv,
            q_scale,
            k_scale,
            attn_mask,
            out,
            qo_len,
            kv_len,
            head_dim,
            hq,
            hkv,
            q_blocks,
            k_blocks,
            group,
            q.stride(0),
            q.stride(1),
            q.stride(2),
            q.stride(3),
            k.stride(0),
            k.stride(1),
            k.stride(2),
            k.stride(3),
            vv.stride(0),
            vv.stride(1),
            vv.stride(2),
            vv.stride(3),
            q_scale.stride(0),
            q_scale.stride(1),
            q_scale.stride(2),
            k_scale.stride(0),
            k_scale.stride(1),
            k_scale.stride(2),
            out.stride(0),
            out.stride(1),
            out.stride(2),
            out.stride(3),
            attn_mask.stride(0),
            attn_mask.stride(1),
            BLOCK_D=128,
            BLOCK_K=64,
            num_warps=4,
            num_stages=2,
        )

        if self.tensor_layout == "NHD":
            out = out.permute(0, 2, 1, 3).contiguous()

        return out.to(v.dtype)
