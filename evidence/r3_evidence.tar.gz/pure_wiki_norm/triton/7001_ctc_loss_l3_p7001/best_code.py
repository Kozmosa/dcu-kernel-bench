import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _lse3(a, b, c):
    m = tl.maximum(a, tl.maximum(b, c))
    safe_m = tl.where(m == -float("inf"), 0.0, m)
    z = tl.exp(a - safe_m) + tl.exp(b - safe_m) + tl.exp(c - safe_m)
    return tl.log(z) + safe_m


@triton.jit
def _initialize(O, SIZE: tl.constexpr, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    tl.store(O + i, 0.0, i < SIZE)


@triton.jit
def _forward_backward(
    P, LABELS, LL, IL, WORK, EXT, OUT,
    T: tl.constexpr, N: tl.constexpr, C: tl.constexpr,
    S: tl.constexpr, NB: tl.constexpr, BLANK: tl.constexpr,
):
    n = tl.program_id(0)
    batch_ids = tl.arange(0, NB)
    lengths = tl.load(LL + batch_ids, batch_ids < N, 0).to(tl.int32)
    offset = tl.sum(tl.where(batch_ids < n, lengths, 0), 0)
    length = tl.load(LL + n).to(tl.int32)
    tb = tl.load(IL + n).to(tl.int32)
    states = 2 * length + 1
    s = tl.arange(0, S)
    valid = s < states

    label = tl.load(
        LABELS + offset + s // 2,
        valid & ((s & 1) == 1),
        BLANK,
    ).to(tl.int32)
    tl.store(EXT + n * S + s, tl.where(valid, label, -1))
    prev_label = tl.gather(label, tl.maximum(s - 2, 0), 0)
    next_label = tl.gather(label, tl.minimum(s + 2, S - 1), 0)
    skip_left = (s >= 2) & (label != BLANK) & (label != prev_label)
    skip_right = (s + 2 < states) & (label != BLANK) & (label != next_label)

    emission = tl.log(tl.load(P + n * C + label, valid, 1.0).to(tl.float32))
    alpha = tl.where(valid & (s < 2), emission, -float("inf"))
    tl.store(WORK + n * T * S + s, alpha)

    for t in range(1, tb):
        left = tl.gather(alpha, tl.maximum(s - 1, 0), 0)
        left = tl.where(s >= 1, left, -float("inf"))
        jump = tl.gather(alpha, tl.maximum(s - 2, 0), 0)
        jump = tl.where(skip_left, jump, -float("inf"))
        emission = tl.log(
            tl.load(P + (t * N + n) * C + label, valid, 1.0).to(tl.float32)
        )
        alpha = tl.where(valid, emission + _lse3(alpha, left, jump), -float("inf"))
        tl.store(WORK + (n * T + t) * S + s, alpha)

    last = tl.where((s == states - 1) | (s == states - 2), alpha, -float("inf"))
    maximum = tl.max(last, 0)
    log_z = maximum + tl.log(tl.sum(tl.exp(last - maximum), 0))
    tl.store(OUT + n, -log_z)

    beta = tl.where(valid & (s >= states - 2), 0.0, -float("inf"))
    gamma = tl.exp(alpha + beta - log_z)
    tl.store(WORK + (n * T + tb - 1) * S + s, gamma)

    for r in range(1, tb):
        t = tb - 1 - r
        emission = tl.log(
            tl.load(P + ((t + 1) * N + n) * C + label, valid, 1.0).to(tl.float32)
        )
        nxt = beta + emission
        right = tl.gather(nxt, tl.minimum(s + 1, S - 1), 0)
        right = tl.where(s + 1 < states, right, -float("inf"))
        jump = tl.gather(nxt, tl.minimum(s + 2, S - 1), 0)
        jump = tl.where(skip_right, jump, -float("inf"))
        beta = tl.where(valid, _lse3(nxt, right, jump), -float("inf"))
        alpha = tl.load(WORK + (n * T + t) * S + s)
        gamma = tl.exp(alpha + beta - log_z)
        tl.store(WORK + (n * T + t) * S + s, gamma)


@triton.jit
def _assemble(
    P, IL, WORK, EXT, OUT,
    T: tl.constexpr, N: tl.constexpr, C: tl.constexpr,
    S: tl.constexpr, BLANK: tl.constexpr,
):
    n = tl.program_id(0)
    t = tl.program_id(1)
    tb = tl.load(IL + n).to(tl.int32)
    if t < tb:
        s = tl.arange(0, S)
        label = tl.load(EXT + n * S + s)
        valid = label >= 0
        gamma = tl.load(WORK + (n * T + t) * S + s)
        blank_sum = tl.sum(tl.where(valid & (label == BLANK), gamma, 0.0), 0)
        blank_p = tl.load(P + (t * N + n) * C + BLANK).to(tl.float32)
        tl.store(OUT + N + (n * T + t) * C + BLANK, -blank_sum / blank_p)
        mask = valid & (label != BLANK)
        p = tl.load(P + (t * N + n) * C + label, mask, 1.0).to(tl.float32)
        tl.atomic_add(
            OUT + N + (n * T + t) * C + label,
            -gamma / p, mask, sem="relaxed",
        )


class ModelNew(nn.Module):
    def __init__(self, blank: int = 0):
        super().__init__()
        self.blank = int(blank)

    def forward(self, probs, labels, label_lengths, input_lengths):
        T, N, C = probs.shape
        S = triton.next_power_of_2(2 * min(T, labels.numel()) + 1)
        out = torch.empty(N + N * T * C, dtype=probs.dtype, device=probs.device)
        work = torch.empty((N, T, S), dtype=torch.float32, device=probs.device)
        ext = torch.empty((N, S), dtype=torch.int32, device=probs.device)
        _initialize[(triton.cdiv(out.numel(), 1024),)](
            out, out.numel(), 1024
        )
        warps = 4 if S < 2048 else 8
        _forward_backward[(N,)](
            probs, labels, label_lengths, input_lengths, work, ext, out,
            T, N, C, S, triton.next_power_of_2(N), self.blank,
            num_warps=warps, enable_fp_fusion=False,
        )
        _assemble[(N, T)](
            probs, input_lengths, work, ext, out,
            T, N, C, S, self.blank,
            num_warps=warps, enable_fp_fusion=False,
        )
        return out
