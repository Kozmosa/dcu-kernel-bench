import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _fused_forward(
    X, Weight, Bias, Slope, Out,
    C: tl.constexpr, H: tl.constexpr, W: tl.constexpr,
    K: tl.constexpr, R: tl.constexpr, S: tl.constexpr,
    OH: tl.constexpr, OW: tl.constexpr,
    ACT: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    batch = tl.program_id(2)
    channels = tl.program_id(0) * BM + tl.arange(0, BM)
    positions = tl.program_id(1) * BN + tl.arange(0, BN)
    oy = positions // OW
    ox = positions % OW
    reduction = tl.arange(0, BK)
    acc = tl.full((BM, BN), 0, tl.float32)

    for block in range(triton.cdiv(C * R * S, BK)):
        q = block * BK + reduction
        ic = q // (R * S)
        ry = (q // S) % R
        rx = q % S
        iy = oy[None, :] + ry[:, None] - 1
        ix = ox[None, :] + rx[:, None] - 1

        a = tl.load(
            Weight + channels[:, None] * (C * R * S) + q[None, :],
            (channels[:, None] < K) & (q[None, :] < C * R * S),
            other=0,
        ).to(tl.float32)
        b = tl.load(
            X + ((batch * C + ic[:, None]) * H + iy) * W + ix,
            (ic[:, None] < C)
            & (positions[None, :] < OH * OW)
            & (iy >= 0) & (iy < H)
            & (ix >= 0) & (ix < W),
            other=0,
        ).to(tl.float32)
        acc = tl.dot(a, b, acc, input_precision="ieee")

    z = acc + tl.load(Bias + channels, channels < K, other=0).to(
        tl.float32
    )[:, None]
    if ACT == 0:
        z = tl.maximum(z, 0.0)
    elif ACT == 1:
        z = z / (1.0 + tl.exp(-z))
    else:
        slope = tl.load(Slope).to(tl.float32)
        z = tl.where(z > 0.0, z, slope * z)

    tl.store(
        Out + (batch * K + channels[:, None]) * (OH * OW)
        + positions[None, :],
        z,
        (channels[:, None] < K) & (positions[None, :] < OH * OW),
    )


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)

    def __init__(self, variant: str = "relu"):
        super().__init__()
        assert variant in ("relu", "swish", "prelu"), \
            "variant must be one of relu / swish / prelu"
        self.variant = variant

    def forward(self, x, weight, bias, slope):
        n, c, h, w = x.shape
        k, _, r, s = weight.shape
        oh, ow = h - r + 3, w - s + 3
        out = torch.empty((n, k, oh, ow), device=x.device, dtype=x.dtype)
        bm, bn, bk = 16, 64, 32
        _fused_forward[
            (triton.cdiv(k, bm), triton.cdiv(oh * ow, bn), n)
        ](
            x, weight, bias, slope, out,
            c, h, w, k, r, s, oh, ow,
            {"relu": 0, "swish": 1, "prelu": 2}[self.variant],
            bm, bn, bk,
            num_warps=4,
            num_stages=2,
        )
        return out
