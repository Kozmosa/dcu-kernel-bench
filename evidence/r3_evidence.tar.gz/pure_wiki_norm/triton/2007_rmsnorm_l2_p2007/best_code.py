import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _rms_rows(
    X, W, R, Y,
    M: tl.constexpr, N: tl.constexpr,
    EPS: tl.constexpr, FUSED: tl.constexpr,
    B: tl.constexpr, ROWS: tl.constexpr,
):
    rows = tl.program_id(0) * ROWS + tl.arange(0, ROWS)
    cols = tl.arange(0, B)
    mask = (rows[:, None] < M) & (cols[None, :] < N)
    offsets = rows[:, None] * N + cols[None, :]
    v = tl.load(X + offsets, mask, 0).to(tl.float32)
    if FUSED:
        r = tl.load(R + offsets, mask, 0).to(tl.float32)
        v = (v + r).to(X.dtype.element_ty).to(tl.float32)
    ss = tl.sum(v * v, axis=1)
    scale = tl.rsqrt(ss / N + EPS)
    w = tl.load(W + cols, cols < N, 0).to(tl.float32)
    y = (v * scale[:, None]) * w[None, :]
    if FUSED:
        base = rows[:, None] * (2 * N) + cols[None, :]
        tl.store(Y + base + N, v, mask)
    else:
        base = offsets
    tl.store(Y + base, y, mask)


@triton.jit
def _partial_squares(
    X, R, P, Y,
    N: tl.constexpr, K: tl.constexpr,
    FUSED: tl.constexpr, B: tl.constexpr,
):
    row = tl.program_id(0)
    part = tl.program_id(1)
    cols = part * B + tl.arange(0, B)
    mask = cols < N
    v = tl.load(X + row * N + cols, mask, 0).to(tl.float32)
    if FUSED:
        r = tl.load(R + row * N + cols, mask, 0).to(tl.float32)
        v = (v + r).to(X.dtype.element_ty).to(tl.float32)
        tl.store(Y + row * (2 * N) + N + cols, v, mask)
    tl.store(P + row * K + part, tl.sum(v * v, 0))


@triton.jit
def _finish_large(
    X, W, P, Y,
    N: tl.constexpr, K: tl.constexpr,
    EPS: tl.constexpr, FUSED: tl.constexpr,
    B: tl.constexpr, KB: tl.constexpr,
):
    row = tl.program_id(0)
    part = tl.program_id(1)
    ki = tl.arange(0, KB)
    sums = tl.load(P + row * K + ki, ki < K, 0)
    scale = tl.rsqrt(tl.sum(sums, 0) / N + EPS)
    cols = part * B + tl.arange(0, B)
    mask = cols < N
    if FUSED:
        v = tl.load(Y + row * (2 * N) + N + cols, mask, 0).to(tl.float32)
        out_offsets = row * (2 * N) + cols
    else:
        v = tl.load(X + row * N + cols, mask, 0).to(tl.float32)
        out_offsets = row * N + cols
    w = tl.load(W + cols, mask, 0).to(tl.float32)
    tl.store(Y + out_offsets, (v * scale) * w, mask)


class ModelNew(nn.Module):
    def __init__(self, variant: str = "fused_add", eps: float = 1e-5):
        super().__init__()
        assert variant in ("rmsnorm", "fused_add"), "variant must be one of rmsnorm / fused_add"
        self.variant = variant
        self.eps = float(eps)

    def forward(self, x, weight, residual):
        m, n = x.shape
        fused = self.variant == "fused_add"
        out = torch.empty((m, n * (2 if fused else 1)), device=x.device, dtype=x.dtype)
        if n <= 16384:
            b = triton.next_power_of_2(n)
            rows = min(16, max(1, 1024 // b))
            warps = 4 if b <= 4096 else 8
            _rms_rows[(triton.cdiv(m, rows),)](
                x, weight, residual, out,
                m, n, self.eps, fused, b, rows,
                num_warps=warps, enable_fp_fusion=False,
            )
        else:
            b = 4096
            k = triton.cdiv(n, b)
            partial = torch.empty((m, k), dtype=torch.float32, device=x.device)
            _partial_squares[(m, k)](
                x, residual, partial, out, n, k, fused, b,
                num_warps=4, enable_fp_fusion=False,
            )
            _finish_large[(m, k)](
                x, weight, partial, out,
                n, k, self.eps, fused, b, triton.next_power_of_2(k),
                num_warps=4, enable_fp_fusion=False,
            )
        return out
