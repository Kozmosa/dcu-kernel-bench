import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _cross_correlation_kernel(
    x,
    weight,
    out,
    C,
    H,
    W,
    K,
    R,
    S,
    OH,
    OW,
    pad_h,
    pad_w,
    TOTAL,
    BLOCK_K: tl.constexpr,
    BLOCK_P: tl.constexpr,
):
    pid_n = tl.program_id(0)
    pid_k = tl.program_id(1)
    pid_p = tl.program_id(2)

    k = pid_k * BLOCK_K + tl.arange(0, BLOCK_K)
    p = pid_p * BLOCK_P + tl.arange(0, BLOCK_P)

    k_mask = k < K
    p_mask = p < TOTAL

    oh = p // OW
    ow = p - oh * OW

    acc = tl.zeros((BLOCK_K, BLOCK_P), dtype=tl.float32)

    x_batch_base = pid_n * C * H * W
    w_kernel_span = C * R * S

    for q in tl.range(0, w_kernel_span):
        c = q // (R * S)
        q_rs = q - c * R * S
        u = q_rs // S
        v = q_rs - u * S

        ih = oh + u - pad_h
        iw = ow + v - pad_w

        x_mask = (
            p_mask
            & (ih >= 0)
            & (ih < H)
            & (iw >= 0)
            & (iw < W)
        )

        x_offset = (
            x_batch_base
            + c * H * W
            + ih * W
            + iw
        )
        xv = tl.load(x + x_offset, mask=x_mask, other=0.0)

        w_offset = k * w_kernel_span + q
        wv = tl.load(weight + w_offset, mask=k_mask, other=0.0)

        acc += wv[:, None] * xv[None, :]

    out_offset = (
        pid_n * K * OH * OW
        + k[:, None] * OH * OW
        + p[None, :]
    )
    out_mask = k_mask[:, None] & p_mask[None, :]
    tl.store(out + out_offset, acc, mask=out_mask)


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _DILATION = (1, 1)
    _PAD_SYMMETRIC = (1, 1)
    _PRE_PADDING = (2, 2)
    _POST_PADDING = (1, 1)

    def __init__(self, variant: str = "standard"):
        super().__init__()
        assert variant in ("standard", "asymmetric"), (
            "variant must be either standard or asymmetric"
        )
        self.variant = variant

    def forward(self, x, weight):
        n, c, h, w = x.shape
        k, wc, r, s = weight.shape

        if self.variant == "asymmetric":
            pad_h = 2
            pad_w = 2
            oh = h - r + 4
            ow = w - s + 4
        else:
            pad_h = 1
            pad_w = 1
            oh = h - r + 3
            ow = w - s + 3

        out = torch.empty(
            (n, k, oh, ow),
            device=x.device,
            dtype=torch.float32,
        )

        total = oh * ow
        grid = (
            n,
            triton.cdiv(k, 8),
            triton.cdiv(total, 64),
        )

        _cross_correlation_kernel[grid](
            x,
            weight,
            out,
            c,
            h,
            w,
            k,
            r,
            s,
            oh,
            ow,
            pad_h,
            pad_w,
            total,
            BLOCK_K=8,
            BLOCK_P=64,
            num_warps=4,
            num_stages=2,
        )
        return out
