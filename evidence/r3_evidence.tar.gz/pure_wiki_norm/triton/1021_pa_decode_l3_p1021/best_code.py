import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _paged_attention_kernel(
    q_ptr,
    k_ptr,
    v_ptr,
    bt_ptr,
    sl_ptr,
    o_ptr,
    num_q_heads,
    num_kv_heads,
    head_size,
    block_size,
    max_blocks_per_seq,
    scale,
    stride_q_s,
    stride_q_h,
    stride_q_d,
    stride_k_block,
    stride_k_head,
    stride_k_slot,
    stride_k_d,
    stride_v_block,
    stride_v_head,
    stride_v_slot,
    stride_v_d,
    stride_bt_s,
    stride_o_s,
    stride_o_h,
    stride_o_d,
    BLOCK_D: tl.constexpr,
):
    pid = tl.program_id(0)
    seq_id = pid // num_q_heads
    q_head = pid - seq_id * num_q_heads

    kv_head = q_head // (num_q_heads // num_kv_heads)

    d = tl.arange(0, BLOCK_D)
    dmask = d < head_size

    q_base = (
        seq_id * stride_q_s
        + q_head * stride_q_h
        + d * stride_q_d
    )
    q = tl.load(q_ptr + q_base, mask=dmask, other=0.0).to(tl.float32)
    q = q * scale

    seq_len = tl.load(sl_ptr + seq_id).to(tl.int32)

    max_logit = -float("inf")
    for pos in tl.range(0, seq_len):
        logical_block = pos // block_size
        slot = pos - logical_block * block_size

        physical_block = tl.load(
            bt_ptr
            + seq_id * stride_bt_s
            + logical_block
        ).to(tl.int32)

        k_base = (
            physical_block * stride_k_block
            + kv_head * stride_k_head
            + slot * stride_k_slot
            + d * stride_k_d
        )
        k = tl.load(k_ptr + k_base, mask=dmask, other=0.0).to(tl.float32)
        logit = tl.sum(q * k, axis=0)
        max_logit = tl.maximum(max_logit, logit)

    denom = 0.0
    for pos in tl.range(0, seq_len):
        logical_block = pos // block_size
        slot = pos - logical_block * block_size

        physical_block = tl.load(
            bt_ptr
            + seq_id * stride_bt_s
            + logical_block
        ).to(tl.int32)

        k_base = (
            physical_block * stride_k_block
            + kv_head * stride_k_head
            + slot * stride_k_slot
            + d * stride_k_d
        )
        k = tl.load(k_ptr + k_base, mask=dmask, other=0.0).to(tl.float32)
        logit = tl.sum(q * k, axis=0)
        denom += tl.exp(logit - max_logit)

    inv_denom = 1.0 / denom
    acc = tl.zeros((BLOCK_D,), dtype=tl.float32)

    for pos in tl.range(0, seq_len):
        logical_block = pos // block_size
        slot = pos - logical_block * block_size

        physical_block = tl.load(
            bt_ptr
            + seq_id * stride_bt_s
            + logical_block
        ).to(tl.int32)

        k_base = (
            physical_block * stride_k_block
            + kv_head * stride_k_head
            + slot * stride_k_slot
            + d * stride_k_d
        )
        v_base = (
            physical_block * stride_v_block
            + kv_head * stride_v_head
            + slot * stride_v_slot
            + d * stride_v_d
        )

        k = tl.load(k_ptr + k_base, mask=dmask, other=0.0).to(tl.float32)
        v = tl.load(v_ptr + v_base, mask=dmask, other=0.0).to(tl.float32)

        logit = tl.sum(q * k, axis=0)
        weight = tl.exp(logit - max_logit) * inv_denom
        acc += weight * v

    o_base = (
        seq_id * stride_o_s
        + q_head * stride_o_h
        + d * stride_o_d
    )
    tl.store(o_ptr + o_base, acc, mask=dmask)


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        B, H_Q, D = query.shape
        H_KV = key_cache.shape[1]
        block_size = key_cache.shape[2]

        assert H_Q == H_KV * (H_Q // H_KV)

        out = torch.empty_like(query)

        block_d = 1
        while block_d < D:
            block_d <<= 1

        warps = 4
        if block_d >= 256:
            warps = 8

        _paged_attention_kernel[(B * H_Q,)](
            query,
            key_cache,
            value_cache,
            block_tables,
            seq_lens,
            out,
            H_Q,
            H_KV,
            D,
            block_size,
            block_tables.shape[1],
            self.scale,
            query.stride(0),
            query.stride(1),
            query.stride(2),
            key_cache.stride(0),
            key_cache.stride(1),
            key_cache.stride(2),
            key_cache.stride(3),
            value_cache.stride(0),
            value_cache.stride(1),
            value_cache.stride(2),
            value_cache.stride(3),
            block_tables.stride(0),
            out.stride(0),
            out.stride(1),
            out.stride(2),
            BLOCK_D=block_d,
            num_warps=warps,
            num_stages=2,
        )

        return out
