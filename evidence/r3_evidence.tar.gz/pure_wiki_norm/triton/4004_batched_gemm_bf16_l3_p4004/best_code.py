import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _batched_transposed_gemm(
    x_ptr,
    w_ptr,
    bias_ptr,
    out_ptr,
    B,
    M,
    N,
    K,
    xs_b,
    xs_m,
    xs_k,
    ws_b,
    ws_n,
    ws_k,
    bs_b,
    bs_n,
    os_b,
    os_m,
    os_n,
    USE_BIAS: tl.constexpr,
    OUT_FP16: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_b = tl.program_id(0)
    pid_m = tl.program_id(1)
    pid_n = tl.program_id(2)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for kb in range(0, tl.cdiv(K, BLOCK_K)):
        offs_k = kb * BLOCK_K + tl.arange(0, BLOCK_K)

        x = tl.load(
            x_ptr
            + pid_b * xs_b
            + offs_m[:, None] * xs_m
            + offs_k[None, :] * xs_k,
            mask=(offs_m[:, None] < M) & (offs_k[None, :] < K),
            other=0,
        )

        w = tl.load(
            w_ptr
            + pid_b * ws_b
            + offs_k[:, None] * ws_k
            + offs_n[None, :] * ws_n,
            mask=(offs_k[:, None] < K) & (offs_n[None, :] < N),
            other=0,
        )

        acc += tl.dot(x, w)

    valid = (offs_m[:, None] < M) & (offs_n[None, :] < N)

    if USE_BIAS:
        acc_bf16 = acc.to(tl.bfloat16)
        bias = tl.load(
            bias_ptr
            + pid_b * bs_b
            + offs_n[None, :] * bs_n,
            mask=offs_n[None, :] < N,
            other=0,
        )
        result = acc_bf16 + bias
    else:
        result = acc

    if OUT_FP16:
        result = result.to(tl.float16)
    else:
        result = result.to(tl.bfloat16)

    tl.store(
        out_ptr
        + pid_b * os_b
        + offs_m[:, None] * os_m
        + offs_n[None, :] * os_n,
        result,
        mask=valid,
    )


class ModelNew(nn.Module):
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)

    def forward(self, x, weight, bias):
        x = x.to(torch.bfloat16).contiguous()
        weight = weight.to(torch.bfloat16).contiguous()

        if self.use_bias:
            bias = bias.to(torch.bfloat16).contiguous()

        B, M, K = x.shape
        N = weight.shape[1]

        assert K == weight.shape[2], "x and weight must agree on the K dimension"

        out = torch.empty(
            (B, M, N),
            device=x.device,
            dtype=self.out_dtype,
        )

        if M >= 128:
            block_m = 128
        elif M >= 64:
            block_m = 64
        else:
            block_m = 32

        if N >= 128:
            block_n = 128
        elif N >= 64:
            block_n = 64
        else:
            block_n = 32

        block_k = 64
        num_warps = 8 if block_m * block_n >= 8192 else 4

        grid = (
            B,
            (M + block_m - 1) // block_m,
            (N + block_n - 1) // block_n,
        )

        _batched_transposed_gemm[grid](
            x,
            weight,
            bias if self.use_bias else x,
            out,
            B,
            M,
            N,
            K,
            x.stride(0),
            x.stride(1),
            x.stride(2),
            weight.stride(0),
            weight.stride(1),
            weight.stride(2),
            bias.stride(0) if self.use_bias else 0,
            bias.stride(2) if self.use_bias else 0,
            out.stride(0),
            out.stride(1),
            out.stride(2),
            USE_BIAS=self.use_bias,
            OUT_FP16=self.out_dtype == torch.float16,
            BLOCK_M=block_m,
            BLOCK_N=block_n,
            BLOCK_K=block_k,
            num_warps=num_warps,
            num_stages=2,
        )

        return out
