import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _rearrange(X, Y, TOTAL: tl.constexpr, K: tl.constexpr,
               H: tl.constexpr, W: tl.constexpr, BS: tl.constexpr,
               CRD: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    c_out = K // (BS * BS)
    ow = i % (W * BS)
    oh = i // (W * BS) % (H * BS)
    c = i // (W * BS * H * BS) % c_out
    n = i // (W * BS * H * BS * c_out)
    sub = (oh % BS) * BS + ow % BS
    if CRD:
        k = c * BS * BS + sub
    else:
        k = sub * c_out + c
    src = ((n * K + k) * H + oh // BS) * W + ow // BS
    value = tl.load(X + src, i < TOTAL, other=0)
    tl.store(Y + i, value, i < TOTAL)


@tr.jit
def _fused(X, WEIGHT, BIAS, Y,
           CI: tl.constexpr, K: tl.constexpr,
           H: tl.constexpr, W: tl.constexpr,
           BS: tl.constexpr, CRD: tl.constexpr,
           BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    p = tl.program_id(0) * BM + tl.arange(0, BM)
    k = tl.program_id(1) * BN + tl.arange(0, BN)
    batch = tl.program_id(2)
    r = tl.arange(0, BK)
    h = p // W
    w = p % W
    acc = tl.full((BM, BN), 0, tl.float32)
    for block in range(tr.cdiv(CI * 9, BK)):
        q = block * BK + r
        ic = q // 9
        ih = h[:, None] + (q[None, :] % 9) // 3 - 1
        iw = w[:, None] + q[None, :] % 3 - 1
        a = tl.load(
            X + ((batch * CI + ic[None, :]) * H + ih) * W + iw,
            (p[:, None] < H * W) & (ic[None, :] < CI)
            & (ih >= 0) & (ih < H) & (iw >= 0) & (iw < W),
            other=0,
        ).to(tl.float32)
        b = tl.load(
            WEIGHT + k[None, :] * (CI * 9) + q[:, None],
            (k[None, :] < K) & (q[:, None] < CI * 9),
            other=0,
        ).to(tl.float32)
        acc = tl.dot(a, b, acc, input_precision="ieee")
    bias = tl.load(BIAS + k, k < K, other=0).to(tl.float32)
    acc += bias[None, :]
    C: tl.constexpr = K // (BS * BS)
    if CRD:
        c = k // (BS * BS)
        sub = k % (BS * BS)
    else:
        c = k % C
        sub = k // C
    oh = h[:, None] * BS + sub[None, :] // BS
    ow = w[:, None] * BS + sub[None, :] % BS
    dst = ((batch * C + c[None, :]) * (H * BS) + oh) * (W * BS) + ow
    tl.store(Y + dst, acc, (p[:, None] < H * W) & (k[None, :] < K))


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)

    def __init__(self, variant: str = "conv_bias_dts", mode: str = "CRD", block_size: int = 2):
        super().__init__()
        assert variant in ("conv_bias_dts", "dts")
        assert mode in ("CRD", "DCR")
        assert block_size in (2, 3, 4)
        self.variant = variant
        self.mode = mode
        self.block_size = block_size

    def forward(self, x, weight=None, bias=None):
        n, ci, h, w = x.shape
        bs = self.block_size
        k = ci if self.variant == "dts" else weight.shape[0]
        out = torch.empty(
            (n, k // (bs * bs), h * bs, w * bs),
            device=x.device, dtype=x.dtype,
        )
        if self.variant == "dts":
            total = n * k * h * w
            _rearrange[(tr.cdiv(total, 1024),)](
                x, out, total, k, h, w, bs, self.mode == "CRD", 1024,
                num_warps=4,
            )
        else:
            _fused[(tr.cdiv(h * w, 32), tr.cdiv(k, 32), n)](
                x, weight, bias, out, ci, k, h, w, bs,
                self.mode == "CRD", 32, 32, 32, num_warps=4,
            )
        return out
