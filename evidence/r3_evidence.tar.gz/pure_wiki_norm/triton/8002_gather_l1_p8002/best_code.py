import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _select(
    Data, Indices, Out,
    N: tl.constexpr,
    A: tl.constexpr,
    K: tl.constexpr,
    INNER: tl.constexpr,
    ELEMENTS: tl.constexpr,
    SHAPE: tl.constexpr,
    STRIDES: tl.constexpr,
    INDEX_CONTIGUOUS: tl.constexpr,
    BLOCK: tl.constexpr,
):
    x = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = x < N
    if ELEMENTS:
        if INDEX_CONTIGUOUS:
            index_offset = x
        else:
            remaining = x
            index_offset = tl.full((BLOCK,), 0, tl.int32)
            for d in tl.static_range(len(SHAPE) - 1, -1, -1):
                index_offset += (remaining % SHAPE[d]) * STRIDES[d]
                remaining = remaining // SHAPE[d]
    else:
        index_offset = ((x // INNER) % K) * STRIDES[0]

    selected = tl.load(Indices + index_offset, valid, other=0).to(tl.int32)
    outer = x // (K * INNER)
    source = outer * (A * INNER) + selected * INNER + x % INNER
    value = tl.load(Data + source, valid, other=0)
    tl.store(Out + x, value, valid)


@tr.jit
def _select_slices(
    Data, Indices, Out,
    A: tl.constexpr,
    K: tl.constexpr,
    INNER: tl.constexpr,
    INDEX_STRIDE: tl.constexpr,
    BLOCK: tl.constexpr,
):
    slice_id = tl.program_id(0)
    inner = tl.program_id(1) * BLOCK + tl.arange(0, BLOCK)
    chosen = tl.load(Indices + (slice_id % K) * INDEX_STRIDE).to(tl.int32)
    source = ((slice_id // K) * A + chosen) * INNER + inner
    value = tl.load(Data + source, inner < INNER, other=0)
    tl.store(Out + slice_id * INNER + inner, value, inner < INNER)


class ModelNew(nn.Module):
    def __init__(self, variant: str = "gather", axis: int = 1):
        super().__init__()
        assert variant in ("gather", "gather_elements"), (
            "variant must be one of gather / gather_elements"
        )
        self.variant = variant
        self.axis = int(axis)

    def forward(self, data, indices):
        axis = self.axis % data.dim()
        elements = self.variant == "gather_elements"
        if elements:
            shape = tuple(indices.shape)
            k = shape[axis]
        else:
            k = indices.shape[0]
            shape = tuple(data.shape[:axis]) + (k,) + tuple(data.shape[axis + 1:])

        inner = 1
        for size in data.shape[axis + 1:]:
            inner *= size
        outer = 1
        for size in data.shape[:axis]:
            outer *= size

        out = torch.empty(shape, dtype=data.dtype, device=data.device)
        n = outer * k * inner
        if n == 0:
            return out

        if not elements and inner >= 256:
            block = 1024 if inner >= 1024 else tr.next_power_of_2(inner)
            _select_slices[(outer * k, tr.cdiv(inner, block))](
                data, indices, out,
                data.shape[axis], k, inner, indices.stride(0), block,
                num_warps=4,
            )
        else:
            block = 512
            _select[(tr.cdiv(n, block),)](
                data, indices, out,
                n, data.shape[axis], k, inner, elements,
                tuple(indices.shape), tuple(indices.stride()),
                indices.is_contiguous(), block,
                num_warps=4,
            )
        return out
