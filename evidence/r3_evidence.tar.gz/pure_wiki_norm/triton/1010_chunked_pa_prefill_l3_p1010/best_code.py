import math
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _attention_parts(
    Q, K, V, KC, VC, BT, QS, SL, TMP, LSE,
    H: tl.constexpr, HK: tl.constexpr, D: tl.constexpr,
    NS: tl.constexpr, BS: tl.constexpr, X: tl.constexpr,
    SCALE: tl.constexpr, SPLITS: tl.constexpr,
    QSTR: tl.constexpr, KSTR: tl.constexpr, VSTR: tl.constexpr,
    KCSTR: tl.constexpr, VCSTR: tl.constexpr,
    BTSTR: tl.constexpr, QSSTR: tl.constexpr, SLSTR: tl.constexpr,
    BD: tl.constexpr, BN: tl.constexpr,
):
    token = tl.program_id(0)
    head = tl.program_id(1)
    part = tl.program_id(2)

    # Upper bound search also handles empty sequences.
    lo = 0
    hi = NS
    while lo < hi:
        mid = (lo + hi) // 2
        start = tl.load(QS + mid * QSSTR)
        right = start <= token
        lo = tl.where(right, mid + 1, lo)
        hi = tl.where(right, hi, mid)
    seq = lo - 1
    first = tl.load(QS + seq * QSSTR)
    end = tl.load(QS + (seq + 1) * QSSTR)
    length = tl.load(SL + seq * SLSTR)
    context = length - (end - first)
    visible = context + token - first + 1
    kh = head // (H // HK)

    d = tl.arange(0, BD)
    n = tl.arange(0, BN)
    q = tl.load(
        Q + token * QSTR[0] + head * QSTR[1] + d * QSTR[2],
        d < D, 0,
    ).to(tl.float32) * SCALE

    tiles = tl.cdiv(visible, BN)
    tiles_per_part = tl.cdiv(tiles, SPLITS)
    begin = part * tiles_per_part * BN
    finish = tl.minimum(begin + tiles_per_part * BN, visible)

    maximum = tl.full((), -float("inf"), tl.float32)
    denominator = tl.full((), 0, tl.float32)
    numerator = tl.full((BD,), 0, tl.float32)

    for base in range(begin, finish, BN):
        pos = base + n
        valid = pos < visible
        cached = valid & (pos < context)
        fresh = valid & (pos >= context)
        block = tl.load(
            BT + seq * BTSTR[0] + (pos // BS) * BTSTR[1],
            cached, 0,
        )
        slot = pos % BS
        ck = tl.load(
            KC + block[:, None] * KCSTR[0]
            + kh * KCSTR[1]
            + (d[None, :] // X) * KCSTR[2]
            + slot[:, None] * KCSTR[3]
            + (d[None, :] % X) * KCSTR[4],
            cached[:, None] & (d[None, :] < D), 0,
        ).to(tl.float32)
        nk = tl.load(
            K + (first + pos[:, None] - context) * KSTR[0]
            + kh * KSTR[1] + d[None, :] * KSTR[2],
            fresh[:, None] & (d[None, :] < D), 0,
        ).to(tl.float32)
        logits = tl.sum((ck + nk) * q[None, :], axis=1)
        logits = tl.where(valid, logits, -float("inf"))
        next_max = tl.maximum(maximum, tl.max(logits, axis=0))
        correction = tl.exp(maximum - next_max)
        weights = tl.exp(logits - next_max)

        cv = tl.load(
            VC + block[:, None] * VCSTR[0] + kh * VCSTR[1]
            + d[None, :] * VCSTR[2] + slot[:, None] * VCSTR[3],
            cached[:, None] & (d[None, :] < D), 0,
        ).to(tl.float32)
        nv = tl.load(
            V + (first + pos[:, None] - context) * VSTR[0]
            + kh * VSTR[1] + d[None, :] * VSTR[2],
            fresh[:, None] & (d[None, :] < D), 0,
        ).to(tl.float32)
        numerator = numerator * correction + tl.sum(
            weights[:, None] * (cv + nv), axis=0
        )
        denominator = denominator * correction + tl.sum(weights, axis=0)
        maximum = next_max

    index = (token * H + head) * SPLITS + part
    norm = tl.where(denominator > 0, denominator, 1.0)
    tl.store(TMP + index * D + d, numerator / norm, d < D)
    tl.store(
        LSE + index,
        tl.where(denominator > 0, maximum + tl.log(norm), -float("inf")),
    )


@tr.jit
def _attention_merge(
    TMP, LSE, OUT,
    H: tl.constexpr, D: tl.constexpr, SPLITS: tl.constexpr,
    OSTR: tl.constexpr, BD: tl.constexpr, BP: tl.constexpr,
):
    token = tl.program_id(0)
    head = tl.program_id(1)
    p = tl.arange(0, BP)
    d = tl.arange(0, BD)
    indices = (token * H + head) * SPLITS + p
    logs = tl.load(LSE + indices, p < SPLITS, -float("inf"))
    maximum = tl.max(logs, 0)
    weights = tl.exp(logs - maximum)
    vals = tl.load(
        TMP + indices[:, None] * D + d[None, :],
        (p[:, None] < SPLITS) & (d[None, :] < D), 0,
    )
    result = tl.sum(vals * weights[:, None], axis=0) / tl.sum(weights, 0)
    tl.store(
        OUT + token * OSTR[0] + head * OSTR[1] + d * OSTR[2],
        result, d < D,
    )


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key, value, key_cache, value_cache,
                block_tables, query_start_loc, seq_lens):
        tokens, heads, dim = query.shape
        out = torch.empty_like(query)
        if tokens == 0:
            return out

        capacity = block_tables.shape[1] * value_cache.shape[3]
        splits = min(16, max(1, tr.cdiv(capacity, 512)))
        if tokens * heads >= 2048:
            splits = min(splits, 2)

        partial = torch.empty(
            (tokens, heads, splits, dim), device=query.device, dtype=torch.float32
        )
        lse = torch.empty(
            (tokens, heads, splits), device=query.device, dtype=torch.float32
        )
        bd = tr.next_power_of_2(dim)
        _attention_parts[(tokens, heads, splits)](
            query, key, value, key_cache, value_cache, block_tables,
            query_start_loc, seq_lens, partial, lse,
            heads, key_cache.shape[1], dim, seq_lens.numel(),
            value_cache.shape[3], key_cache.shape[4], self.scale, splits,
            query.stride(), key.stride(), value.stride(),
            key_cache.stride(), value_cache.stride(), block_tables.stride(),
            query_start_loc.stride(0), seq_lens.stride(0),
            bd, 32, num_warps=4,
        )
        _attention_merge[(tokens, heads)](
            partial, lse, out, heads, dim, splits, out.stride(),
            bd, tr.next_power_of_2(splits), num_warps=4,
        )
        return out
