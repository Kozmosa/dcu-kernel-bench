import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _local(X, V, I, M: tl.constexpr, K: tl.constexpr,
           C: tl.constexpr, R: tl.constexpr, S: tl.constexpr):
    row = tl.program_id(0)
    run = tl.program_id(1)
    p = tl.arange(0, S)
    col = run * S + p
    v = tl.load(X + row * M + col, col < M, other=-float("inf"))
    base = (row * R + run) * C
    if K <= 16:
        for j in range(C):
            best = tl.max(v, 0)
            ix = tl.min(tl.where((v == best) & (col < M), col, 2147483647), 0)
            tl.store(V + base + j, best)
            tl.store(I + base + j, ix)
            v = tl.where(col == ix, -float("inf"), v)
    else:
        v, ix = tl.sort_pairs(v, col, descending=True)
        tl.store(V + base + p, v, p < C)
        tl.store(I + base + p, ix, p < C)


@tr.jit
def _finish(V, I, O, M: tl.constexpr, K: tl.constexpr,
            R: tl.constexpr, C: tl.constexpr, S: tl.constexpr,
            N: tl.constexpr):
    row = tl.program_id(0)
    p = tl.arange(0, N)
    run = p // C
    pos = p % C
    valid = (p < R * C) & (pos < tl.minimum(C, M - run * S))
    v = tl.load(V + row * R * C + p, valid, other=-float("inf"))
    ix = tl.load(I + row * R * C + p, valid, other=2147483647)
    v, ix = tl.sort_pairs(v, ix, descending=True)
    tl.store(O + row * (2 * K) + p, v, p < K)
    tl.store(O + row * (2 * K) + K + p, ix.to(tl.float32), p < K)


@tr.jit
def _merge(V, I, W, J, M: tl.constexpr, K: tl.constexpr,
           R: tl.constexpr, C: tl.constexpr, S: tl.constexpr,
           NR: tl.constexpr, NC: tl.constexpr,
           T: tl.constexpr):
    row = tl.program_id(0)
    pair = tl.program_id(1)
    p = tl.program_id(2) * T + tl.arange(0, T)
    side = p // C
    pos = p % C
    run = pair * 2 + side
    other = pair * 2 + 1 - side
    length = tl.minimum(C, tl.maximum(0, M - run * S))
    olen = tl.minimum(C, tl.maximum(0, M - other * S))
    active = (p < 2 * C) & (run < R) & (pos < length)
    v = tl.load(V + (row * R + run) * C + pos, active, other=0.0)
    ix = tl.load(I + (row * R + run) * C + pos, active, other=0)
    low = tl.full((T,), 0, tl.int32)
    high = tl.where(other < R, olen, 0)
    for _ in range((C + 1).bit_length()):
        mid = (low + high) // 2
        search = active & (low < high)
        q = tl.load(V + (row * R + other) * C + mid,
                    search, other=-float("inf"))
        greater = q > v
        low = tl.where(search & greater, mid + 1, low)
        high = tl.where(search & ~greater, mid, high)
    rank = pos + low
    keep = active & (rank < NC)
    dst = (row * NR + pair) * NC + rank
    tl.store(W + dst, v, keep)
    tl.store(J + dst, ix, keep)


@tr.jit
def _pack(V, I, O, K: tl.constexpr, T: tl.constexpr):
    row = tl.program_id(0)
    p = tl.program_id(1) * T + tl.arange(0, T)
    v = tl.load(V + row * K + p, p < K, other=0)
    ix = tl.load(I + row * K + p, p < K, other=0)
    tl.store(O + row * (2 * K) + p, v, p < K)
    tl.store(O + row * (2 * K) + K + p, ix.to(tl.float32), p < K)


class ModelNew(nn.Module):
    def __init__(self, k: int = 8):
        super().__init__()
        assert k >= 1, "k must be >= 1"
        self.k = int(k)

    def forward(self, x):
        b, m = x.shape
        k = self.k
        assert k <= m
        out = torch.empty((b, 2 * k), device=x.device, dtype=torch.float32)
        s = min(tr.next_power_of_2(m), 2048 if k <= 16 else 1024)
        r = tr.cdiv(m, s)
        c = min(k, s)
        v = torch.empty((b, r, c), device=x.device, dtype=torch.float32)
        i = torch.empty((b, r, c), device=x.device, dtype=torch.int32)
        _local[(b, r)](x, v, i, m, k, c, r, s,
                        num_warps=4 if s <= 1024 else 8)
        while True:
            if r * c <= 4096:
                n = tr.next_power_of_2(r * c)
                _finish[(b,)](v, i, out, m, k, r, c, s, n,
                              num_warps=4 if n <= 1024 else 8)
                break
            if r == 1:
                _pack[(b, tr.cdiv(k, 256))](v, i, out, k, 256)
                break
            nr = tr.cdiv(r, 2)
            nc = min(k, 2 * c)
            w = torch.empty((b, nr, nc), device=x.device, dtype=torch.float32)
            j = torch.empty((b, nr, nc), device=x.device, dtype=torch.int32)
            _merge[(b, nr, tr.cdiv(2 * c, 256))](
                v, i, w, j, m, k, r, c, s, nr, nc, 256,
                num_warps=4)
            v, i = w, j
            r, c, s = nr, nc, s * 2
        return out
