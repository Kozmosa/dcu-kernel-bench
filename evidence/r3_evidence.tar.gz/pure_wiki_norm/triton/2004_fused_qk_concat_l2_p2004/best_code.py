import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _mla_preprocess_kernel(
    q_nope_ptr,
    q_pe_ptr,
    k_nope_ptr,
    k_pe_ptr,
    pos_ptr,
    cos_ptr,
    sin_ptr,
    out_ptr,
    B,
    QH,
    KH,
    D_NOPE,
    D_PE,
    D_FREQ,
    TOTAL_D,
    HALF_TABLE: tl.constexpr,
    IS_NEOX: tl.constexpr,
    APPLY_ROPE: tl.constexpr,
    BLOCK: tl.constexpr,
):
    pid_row = tl.program_id(0)
    pid_tile = tl.program_id(1)

    d = pid_tile * BLOCK + tl.arange(0, BLOCK)
    valid = d < TOTAL_D

    out_heads = QH + KH
    out_head = pid_row % out_heads
    batch = pid_row // out_heads

    is_q = out_head < QH
    q_head = out_head
    k_head = out_head - QH

    q_row = batch * QH + q_head
    k_row = batch * KH + k_head
    out_row = batch * out_heads + out_head

    nope = d < D_NOPE
    pe = (d >= D_NOPE) & (d < TOTAL_D)
    pe_d = d - D_NOPE

    q_nope_mask = valid & is_q & nope
    k_nope_mask = valid & (~is_q) & nope

    q_pe_mask = valid & is_q & pe
    k_pe_mask = valid & (~is_q) & pe

    qn = tl.load(
        q_nope_ptr + q_row * D_NOPE + d,
        mask=q_nope_mask,
        other=0,
    )
    kn = tl.load(
        k_nope_ptr + k_row * D_NOPE + d,
        mask=k_nope_mask,
        other=0,
    )

    nope_value = tl.where(is_q, qn, kn)

    if APPLY_ROPE:
        p = tl.load(pos_ptr + batch).to(tl.int64)

        if IS_NEOX:
            half = D_PE // 2
            rot_d = tl.where(pe_d < half, pe_d + half, pe_d - half)
            neg = pe_d < half
            if HALF_TABLE:
                freq_d = pe_d % half
            else:
                freq_d = pe_d
        else:
            rot_d = tl.where((pe_d & 1) == 0, pe_d + 1, pe_d - 1)
            neg = (pe_d & 1) == 0
            if HALF_TABLE:
                freq_d = pe_d // 2
            else:
                freq_d = pe_d

        table_offset = p * D_FREQ + freq_d
        cv = tl.load(
            cos_ptr + table_offset,
            mask=valid & pe,
            other=0,
        ).to(tl.float32)
        sv = tl.load(
            sin_ptr + table_offset,
            mask=valid & pe,
            other=0,
        ).to(tl.float32)

        qx = tl.load(
            q_pe_ptr + q_row * D_PE + pe_d,
            mask=q_pe_mask,
            other=0,
        ).to(tl.float32)
        qrot = tl.load(
            q_pe_ptr + q_row * D_PE + rot_d,
            mask=q_pe_mask,
            other=0,
        ).to(tl.float32)

        kx = tl.load(
            k_pe_ptr + k_row * D_PE + pe_d,
            mask=k_pe_mask,
            other=0,
        ).to(tl.float32)
        krot = tl.load(
            k_pe_ptr + k_row * D_PE + rot_d,
            mask=k_pe_mask,
            other=0,
        ).to(tl.float32)

        qrot = tl.where(neg, -qrot, qrot)
        krot = tl.where(neg, -krot, krot)

        qv = qx * cv + qrot * sv
        kv = kx * cv + krot * sv
        pe_value = tl.where(is_q, qv, kv)
    else:
        qp = tl.load(
            q_pe_ptr + q_row * D_PE + pe_d,
            mask=q_pe_mask,
            other=0,
        )
        kp = tl.load(
            k_pe_ptr + k_row * D_PE + pe_d,
            mask=k_pe_mask,
            other=0,
        )
        pe_value = tl.where(is_q, qp, kp)

    value = tl.where(nope, nope_value, pe_value)
    tl.store(out_ptr + out_row * TOTAL_D + d, value, mask=valid)


class ModelNew(nn.Module):
    def __init__(self, is_neox: bool = True, apply_rope: bool = True):
        super().__init__()
        self.is_neox = bool(is_neox)
        self.apply_rope = bool(apply_rope)

    def forward(self, q_nope, q_pe, k_nope, k_pe, pos, cos, sin):
        B, QH, D_nope = q_nope.shape
        KH = k_nope.shape[1]
        D_pe = q_pe.shape[-1]

        assert q_pe.shape[0] == B and k_nope.shape[0] == B and k_pe.shape[0] == B
        assert q_pe.shape[1] == QH and k_pe.shape[1] == KH
        assert k_nope.shape[2] == D_nope and k_pe.shape[2] == D_pe
        assert QH % KH == 0
        assert D_pe % 2 == 0

        d_freq = cos.shape[-1]
        assert d_freq in (D_pe, D_pe // 2)

        total_heads = QH + KH
        total_d = D_nope + D_pe
        out = torch.empty(
            (B, total_heads, total_d),
            dtype=q_nope.dtype,
            device=q_nope.device,
        )

        block = 256
        grid = (
            B * total_heads,
            triton.cdiv(total_d, block),
        )

        _mla_preprocess_kernel[grid](
            q_nope,
            q_pe,
            k_nope,
            k_pe,
            pos,
            cos,
            sin,
            out,
            B,
            QH,
            KH,
            D_nope,
            D_pe,
            d_freq,
            total_d,
            HALF_TABLE=(d_freq == D_pe // 2),
            IS_NEOX=self.is_neox,
            APPLY_ROPE=self.apply_rope,
            BLOCK=block,
            num_warps=4,
            num_stages=2,
        )
        return out
