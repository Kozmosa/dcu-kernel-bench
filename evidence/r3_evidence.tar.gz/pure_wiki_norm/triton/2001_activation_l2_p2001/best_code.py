import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _activation(x, mode: tl.constexpr):
    if mode == 0:
        return x / (1.0 + tl.exp(-x))
    elif mode == 1:
        return 0.5 * x * (1.0 + tl.erf(x * 0.7071067811865476))
    else:
        u3 = x * x * x
        return 0.5 * x * (
            1.0 + tl.tanh(0.7978845608028654 * (x + 0.044715 * u3))
        )


@triton.jit
def _quantize_e2m1(v, scale):
    q = v * tl.exp2(-scale)
    bits = tl.cast(q, tl.int32, bitcast=True)

    sign = bits & 0x80000000
    exponent = (bits >> 23) & 0xFF
    mantissa = bits & 0x7FFFFF

    adjusted = tl.maximum(126 - exponent, 0)
    sub_mantissa = (0x400000 | (mantissa >> 1)) >> adjusted
    mantissa = tl.where(exponent < 127, sub_mantissa, mantissa)

    exponent_adj = tl.maximum(exponent, 126) - 126
    combined = (((exponent_adj << 2) | (mantissa >> 21)) + 1) >> 1
    magnitude = tl.minimum(combined, 7)

    return ((sign >> 28) & 0xF) | magnitude


@triton.jit
def _mxfp4_kernel(
    x,
    out,
    M,
    N,
    D,
    N_BLOCKS,
    x_stride_m,
    x_stride_n,
    out_stride_m,
    mode: tl.constexpr,
    BLOCK: tl.constexpr,
):
    pid = tl.program_id(0)
    row = pid // N_BLOCKS
    block = pid - row * N_BLOCKS

    lanes = tl.arange(0, BLOCK)
    base = row * x_stride_m + block * BLOCK

    idx = block * BLOCK + lanes
    valid = idx < D

    a = tl.load(
        x + base + lanes * x_stride_n,
        mask=valid,
        other=0.0,
    )
    b = tl.load(
        x + base + D * x_stride_n + lanes * x_stride_n,
        mask=valid,
        other=0.0,
    )

    values = _activation(a, mode) * b
    amax = tl.max(tl.abs(values), axis=0)

    amax_bits = tl.cast(amax, tl.int32, bitcast=True)
    rounded_bits = (amax_bits + 0x200000) & 0xFF800000
    rounded_exp = (rounded_bits >> 23) & 0xFF

    scale_i = tl.maximum(tl.minimum(rounded_exp - 129, 127), -127)
    scale_f = scale_i.to(tl.float32)
    scale_byte = tl.cast(scale_i + 127, tl.uint8)

    out_lane = tl.arange(0, 16)
    even_idx = block * BLOCK + out_lane * 2
    odd_idx = even_idx + 1

    even_valid = even_idx < D
    odd_valid = odd_idx < D

    even_a = tl.load(
        x + row * x_stride_m + even_idx * x_stride_n,
        mask=even_valid,
        other=0.0,
    )
    even_b = tl.load(
        x + row * x_stride_m + (D + even_idx) * x_stride_n,
        mask=even_valid,
        other=0.0,
    )
    odd_a = tl.load(
        x + row * x_stride_m + odd_idx * x_stride_n,
        mask=odd_valid,
        other=0.0,
    )
    odd_b = tl.load(
        x + row * x_stride_m + (D + odd_idx) * x_stride_n,
        mask=odd_valid,
        other=0.0,
    )

    even_value = _activation(even_a, mode) * even_b
    odd_value = _activation(odd_a, mode) * odd_b

    even_code = _quantize_e2m1(even_value, scale_f)
    odd_code = _quantize_e2m1(odd_value, scale_f)

    packed = even_code | (odd_code << 4)

    out_base = row * out_stride_m
    tl.store(
        out + out_base + block * 16 + out_lane,
        packed.to(tl.uint8),
        mask=out_lane < ((D + 1) // 2 - block * 16),
    )

    tl.store(
        out + out_base + D // 2 + block,
        scale_byte,
        mask=lanes == 0,
    )


class ModelNew(nn.Module):
    def __init__(self, activation: str = "silu"):
        super().__init__()
        assert activation in ("silu", "gelu", "gelu_tanh"), (
            "activation must be one of silu / gelu / gelu_tanh"
        )
        self.activation = activation
        self._mode = {"silu": 0, "gelu": 1, "gelu_tanh": 2}[activation]

    def forward(self, x):
        x = x.to(torch.float32)
        M, N = x.shape
        assert N % 4 == 0, "N must be a multiple of 4"

        D = N // 2
        n_blocks = (D + 31) // 32
        out = torch.empty(
            (M, D // 2 + n_blocks),
            dtype=torch.uint8,
            device=x.device,
        )

        grid = (M * n_blocks,)
        _mxfp4_kernel[grid](
            x,
            out,
            M,
            N,
            D,
            n_blocks,
            x.stride(0),
            x.stride(1),
            out.stride(0),
            self._mode,
            BLOCK=32,
            num_warps=4,
            num_stages=1,
        )
        return out
