import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _single(X, S, B, Y, HW: tl.constexpr, C: tl.constexpr,
            EPS: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    i = tl.arange(0, BLOCK)
    valid = i < HW
    x = tl.load(X + row * HW + i, valid, 0).to(tl.float32)
    mean = tl.sum(x, 0) / HW
    d = x - mean
    var = tl.sum(tl.where(valid, d * d, 0.0), 0) / HW
    inv = tl.rsqrt(var + EPS)
    scale = tl.load(S + row % C).to(tl.float32)
    bias = tl.load(B + row % C).to(tl.float32)
    y = ((x - mean) * inv) * scale + bias
    tl.store(Y + row * HW + i, y, valid)


@triton.jit
def _partial(X, P, Q, HW: tl.constexpr, PARTS: tl.constexpr,
             BLOCK: tl.constexpr):
    row = tl.program_id(0)
    part = tl.program_id(1)
    i = part * BLOCK + tl.arange(0, BLOCK)
    valid = i < HW
    x = tl.load(X + row * HW + i, valid, 0).to(tl.float32)
    count = tl.minimum(BLOCK, HW - part * BLOCK)
    mean = tl.sum(x, 0) / count
    d = x - mean
    m2 = tl.sum(tl.where(valid, d * d, 0.0), 0)
    tl.store(P + row * PARTS + part, mean)
    tl.store(Q + row * PARTS + part, m2)


@triton.jit
def _stats(P, Q, M, R, HW: tl.constexpr, PARTS: tl.constexpr,
           CHUNK: tl.constexpr, EPS: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    i = tl.arange(0, BLOCK)
    valid = i < PARTS
    count = tl.where(valid, tl.minimum(CHUNK, HW - i * CHUNK), 0)
    means = tl.load(P + row * PARTS + i, valid, 0)
    m2 = tl.load(Q + row * PARTS + i, valid, 0)
    mean = tl.sum(means * count, 0) / HW
    d = means - mean
    var = tl.sum(m2 + d * d * count, 0) / HW
    tl.store(M + row, mean)
    tl.store(R + row, tl.rsqrt(var + EPS))


@triton.jit
def _apply(X, S, B, M, R, Y, HW: tl.constexpr, C: tl.constexpr,
           BLOCK: tl.constexpr):
    row = tl.program_id(0)
    i = tl.program_id(1) * BLOCK + tl.arange(0, BLOCK)
    x = tl.load(X + row * HW + i, i < HW, 0).to(tl.float32)
    mean = tl.load(M + row)
    inv = tl.load(R + row)
    scale = tl.load(S + row % C).to(tl.float32)
    bias = tl.load(B + row % C).to(tl.float32)
    y = ((x - mean) * inv) * scale + bias
    tl.store(Y + row * HW + i, y, i < HW)


class ModelNew(nn.Module):
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        assert eps > 0, "eps must be positive"
        self.eps = float(eps)

    def forward(self, x, scale, bias):
        n, c, h, w = x.shape
        hw = h * w
        rows = n * c
        out = torch.empty_like(x)
        if hw <= 8192:
            block = triton.next_power_of_2(hw)
            _single[(rows,)](
                x, scale, bias, out, hw, c, self.eps, block,
                num_warps=4 if block <= 2048 else 8,
                enable_fp_fusion=False,
            )
        else:
            chunk = 2048
            parts = triton.cdiv(hw, chunk)
            p = torch.empty((rows, parts), device=x.device, dtype=torch.float32)
            q = torch.empty_like(p)
            m = torch.empty((rows,), device=x.device, dtype=torch.float32)
            r = torch.empty_like(m)
            _partial[(rows, parts)](
                x, p, q, hw, parts, chunk,
                num_warps=4, enable_fp_fusion=False,
            )
            _stats[(rows,)](
                p, q, m, r, hw, parts, chunk, self.eps,
                triton.next_power_of_2(parts),
                num_warps=4, enable_fp_fusion=False,
            )
            _apply[(rows, triton.cdiv(hw, 1024))](
                x, scale, bias, m, r, out, hw, c, 1024,
                num_warps=4, enable_fp_fusion=False,
            )
        return out
