import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _varlen_attention(
    Q, K, V, CQ, CK, C, O,
    TOTAL_Q: tl.constexpr,
    NSEQ: tl.constexpr,
    HQ: tl.constexpr,
    GROUP: tl.constexpr,
    D: tl.constexpr,
    QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr,
    SCALE: tl.constexpr,
    CAUSAL_POINTER: tl.constexpr,
    CAUSAL_VALUE: tl.constexpr,
    BD: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
):
    tile = tl.program_id(0)
    h = tl.program_id(1)

    # Each segment owns its intersecting global query tiles, including
    # its partial boundary tiles.
    lo = 0
    hi = NSEQ
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        boundary = tl.load(CQ + mid) // BM + mid
        if boundary <= tile:
            lo = mid
        else:
            hi = mid

    b = lo
    sq = tl.load(CQ + b)
    eq = tl.load(CQ + b + 1)
    sk = tl.load(CK + b)
    ek = tl.load(CK + b + 1)
    base = (tile - b) * BM

    if base < eq:
        if CAUSAL_POINTER:
            causal = tl.load(C) != 0
        else:
            causal = CAUSAL_VALUE

        r = base + tl.arange(0, BM)
        d = tl.arange(0, BD)
        valid = (r >= sq) & (r < eq)
        kh = h // GROUP
        q = tl.load(
            Q + r[:, None] * QS0 + h * QS1 + d[None, :] * QS2,
            valid[:, None] & (d[None, :] < D),
            other=0,
        ).to(tl.float32)

        m = tl.full((BM,), -float("inf"), tl.float32)
        z = tl.zeros((BM,), tl.float32)
        acc = tl.zeros((BM, BD), tl.float32)
        lk = ek - sk
        lq = eq - sq
        stop = lk
        if causal:
            stop = tl.minimum(lk, base + BM - sq + lk - lq)

        for start in range(0, stop, BN):
            j = start + tl.arange(0, BN)
            k = tl.load(
                K + (sk + j[None, :]) * KS0
                + kh * KS1 + d[:, None] * KS2,
                (j[None, :] < lk) & (d[:, None] < D),
                other=0,
            ).to(tl.float32)
            scores = tl.dot(q, k, input_precision="ieee") * SCALE
            mask = valid[:, None] & (j[None, :] < lk)
            if causal:
                mask = mask & (
                    j[None, :] <= r[:, None] - sq + lk - lq
                )
            scores = tl.where(mask, scores, -float("inf"))
            new_m = tl.maximum(m, tl.max(scores, axis=1))
            new_m = tl.where(valid, new_m, 0.0)
            alpha = tl.exp(m - new_m)
            p = tl.exp(scores - new_m[:, None])
            z = z * alpha + tl.sum(p, axis=1)

            v = tl.load(
                V + (sk + j[:, None]) * VS0
                + kh * VS1 + d[None, :] * VS2,
                (j[:, None] < lk) & (d[None, :] < D),
                other=0,
            ).to(tl.float32)
            acc = acc * alpha[:, None]
            acc += tl.dot(p, v, input_precision="ieee")
            m = new_m

        result = acc / tl.where(valid, z, 1.0)[:, None]
        tl.store(
            O + (r[:, None] * HQ + h) * D + d[None, :],
            result,
            valid[:, None] & (d[None, :] < D),
        )


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = (
            float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v, cu_seqlens_q, cu_seqlens_k, causal):
        total_q, hq, d = q.shape
        hk = k.shape[1]
        assert hq % hk == 0
        cq = cu_seqlens_q.to(device=q.device)
        ck = cu_seqlens_k.to(device=q.device)
        nseq = cq.numel() - 1
        out = torch.empty(q.shape, dtype=q.dtype, device=q.device)

        pointer = isinstance(causal, torch.Tensor)
        if pointer:
            c = causal.to(device=q.device)
            value = False
        else:
            c = cq
            value = bool(causal)

        if total_q:
            _varlen_attention[
                (total_q // 32 + nseq, hq)
            ](
                q, k, v, cq, ck, c, out,
                total_q, nseq, hq, hq // hk, d,
                *q.stride(), *k.stride(), *v.stride(),
                self.sm_scale, pointer, value,
                max(16, triton.next_power_of_2(d)), 32, 32,
                num_warps=4,
                num_stages=1,
            )
        return out
