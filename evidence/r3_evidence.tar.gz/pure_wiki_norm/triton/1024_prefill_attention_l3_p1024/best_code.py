import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _ragged_attention(
    Q, K, V, Starts, Lengths, O,
    HQ: tl.constexpr,
    HK: tl.constexpr,
    D: tl.constexpr,
    GROUP: tl.constexpr,
    SCALE: tl.constexpr,
    CAUSAL: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BD: tl.constexpr,
):
    tile = tl.program_id(0)
    head = tl.program_id(1)
    seq = tl.program_id(2)

    length = tl.load(Lengths + seq).to(tl.int32)
    start = tl.load(Starts + seq).to(tl.int32)
    if tile * BM >= length:
        return

    rows = tile * BM + tl.arange(0, BM)
    channels = tl.arange(0, BD)
    columns = tl.arange(0, BN)
    kv_head = head // GROUP

    q = tl.load(
        Q + (start + rows[:, None]) * HQ * D
        + head * D + channels[None, :],
        mask=(rows[:, None] < length) & (channels[None, :] < D),
        other=0,
    ).to(tl.float32)

    maximum = tl.full((BM,), -float("inf"), tl.float32)
    denominator = tl.full((BM,), 0.0, tl.float32)
    accumulator = tl.full((BM, BD), 0.0, tl.float32)

    end = length
    if CAUSAL:
        end = tl.minimum(length, (tile + 1) * BM)

    for block in range(tl.cdiv(end, BN)):
        keys = block * BN + columns
        k = tl.load(
            K + (start + keys[None, :]) * HK * D
            + kv_head * D + channels[:, None],
            mask=(keys[None, :] < length) & (channels[:, None] < D),
            other=0,
        ).to(tl.float32)

        scores = tl.dot(q, k, input_precision="ieee") * SCALE
        visible = keys[None, :] < length
        if CAUSAL:
            visible = visible & (keys[None, :] <= rows[:, None])
        scores = tl.where(visible, scores, -float("inf"))

        next_maximum = tl.maximum(maximum, tl.max(scores, axis=1))
        correction = tl.exp(maximum - next_maximum)
        probabilities = tl.exp(scores - next_maximum[:, None])

        v = tl.load(
            V + (start + keys[:, None]) * HK * D
            + kv_head * D + channels[None, :],
            mask=(keys[:, None] < length) & (channels[None, :] < D),
            other=0,
        ).to(tl.float32)

        accumulator = accumulator * correction[:, None]
        accumulator += tl.dot(probabilities, v, input_precision="ieee")
        denominator = denominator * correction + tl.sum(probabilities, axis=1)
        maximum = next_maximum

    result = accumulator / denominator[:, None]
    tl.store(
        O + (start + rows[:, None]) * HQ * D
        + head * D + channels[None, :],
        result,
        mask=(rows[:, None] < length) & (channels[None, :] < D),
    )


class ModelNew(nn.Module):
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)

    def forward(self, q, k, v, b_start_loc, b_seq_len):
        total, num_q_heads, head_dim = q.shape
        num_kv_heads = k.shape[1]
        group = num_q_heads // num_kv_heads
        assert num_q_heads == num_kv_heads * group
        assert k.shape[-1] == head_dim and v.shape[-1] == head_dim

        out = torch.empty_like(q)
        if total == 0:
            return out

        max_length = int(b_seq_len.max().item())
        scale = (
            self.sm_scale
            if self.sm_scale is not None
            else 1.0 / math.sqrt(head_dim)
        )
        bm = 16
        bn = 32
        _ragged_attention[
            (triton.cdiv(max_length, bm), num_q_heads, b_seq_len.numel())
        ](
            q, k, v, b_start_loc, b_seq_len, out,
            HQ=num_q_heads,
            HK=num_kv_heads,
            D=head_dim,
            GROUP=group,
            SCALE=scale,
            CAUSAL=self.causal,
            BM=bm,
            BN=bn,
            BD=triton.next_power_of_2(head_dim),
            num_warps=4,
            num_stages=1,
        )
        return out
