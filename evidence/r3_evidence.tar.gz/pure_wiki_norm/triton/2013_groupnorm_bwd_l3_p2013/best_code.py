import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _partials(X, DY, Mean, Inv, P, Q,
              C: tl.constexpr, R: tl.constexpr, G: tl.constexpr,
              HW: tl.constexpr, K: tl.constexpr, B: tl.constexpr):
    nc = tl.program_id(0)
    k = tl.program_id(1)
    s = k * B + tl.arange(0, B)
    ng = (nc // C) * G + (nc % C) // R
    m = tl.load(Mean + ng)
    v = tl.load(Inv + ng)
    x = tl.load(X + nc * HW + s, s < HW, 0).to(tl.float32)
    dy = tl.load(DY + nc * HW + s, s < HW, 0).to(tl.float32)
    xh = (x - m) * v
    a = tl.sum(dy * xh, 0)
    b = tl.sum(dy, 0)
    tl.store(P + nc * K + k, a)
    tl.store(Q + nc * K + k, b)


@tr.jit
def _group_reduce(P, Q, Scale, ST,
                  C: tl.constexpr, R: tl.constexpr, G: tl.constexpr,
                  K: tl.constexpr, B: tl.constexpr):
    ng = tl.program_id(0)
    base = ((ng // G) * C + (ng % G) * R) * K
    ids = tl.arange(0, B)
    asum = tl.full((B,), 0, tl.float32)
    bsum = tl.full((B,), 0, tl.float32)
    for start in range(tr.cdiv(R * K, B)):
        j = start * B + ids
        mask = j < R * K
        scale = tl.load(Scale + (ng % G) * R + j // K, mask, 0).to(tl.float32)
        p = tl.load(P + base + j, mask, 0)
        q = tl.load(Q + base + j, mask, 0)
        asum += p * scale
        bsum += q * scale
    tl.store(ST + 2 * ng, tl.sum(bsum, 0))
    tl.store(ST + 2 * ng + 1, tl.sum(asum, 0))


@tr.jit
def _parameter_reduce(P, Q, Out,
                      N: tl.constexpr, C: tl.constexpr,
                      HW: tl.constexpr, K: tl.constexpr, B: tl.constexpr):
    c = tl.program_id(0)
    ids = tl.arange(0, B)
    a = tl.full((B,), 0, tl.float32)
    b = tl.full((B,), 0, tl.float32)
    for start in range(tr.cdiv(N * K, B)):
        j = start * B + ids
        offset = ((j // K) * C + c) * K + j % K
        a += tl.load(P + offset, j < N * K, 0)
        b += tl.load(Q + offset, j < N * K, 0)
    tl.store(Out + N * C * HW + c, tl.sum(a, 0))
    tl.store(Out + N * C * HW + C + c, tl.sum(b, 0))


@tr.jit
def _data_gradient(X, DY, Scale, Mean, Inv, ST, Out,
                   C: tl.constexpr, R: tl.constexpr, G: tl.constexpr,
                   HW: tl.constexpr, D: tl.constexpr, B: tl.constexpr):
    ng = tl.program_id(0)
    i = tl.program_id(1) * B + tl.arange(0, B)
    mask = i < D
    off = ng * D + i
    c = (ng % G) * R + i // HW
    m = tl.load(Mean + ng)
    v = tl.load(Inv + ng)
    s = tl.load(ST + ng * 2)
    t = tl.load(ST + ng * 2 + 1)
    x = tl.load(X + off, mask, 0).to(tl.float32)
    dy = tl.load(DY + off, mask, 0).to(tl.float32)
    scale = tl.load(Scale + c, mask, 0).to(tl.float32)
    xh = (x - m) * v
    dx = (v / D) * ((dy * scale) * D - s - xh * t)
    tl.store(Out + off, dx, mask)


class ModelNew(nn.Module):
    def __init__(self, groups: int = 2, eps: float = 1e-5):
        super().__init__()
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.groups = int(groups)
        self.eps = float(eps)

    def forward(self, x, dy, scale, mean, inv_var):
        n, c, h, w = x.shape
        g = self.groups
        assert 1 <= g <= c and c % g == 0
        assert mean.numel() == n * g and inv_var.numel() == n * g
        r = c // g
        hw = h * w
        d = r * hw
        block = min(1024, tr.next_power_of_2(hw))
        k = tr.cdiv(hw, block)
        p = torch.empty((n * c * k,), device=x.device, dtype=torch.float32)
        q = torch.empty_like(p)
        st = torch.empty((n * g * 2,), device=x.device, dtype=torch.float32)
        out = torch.empty((n * c * hw + 2 * c,), device=x.device, dtype=torch.float32)

        _partials[(n * c, k)](
            x, dy, mean, inv_var, p, q, c, r, g, hw, k, block,
            num_warps=4, enable_fp_fusion=False,
        )
        rb = min(1024, tr.next_power_of_2(r * k))
        _group_reduce[(n * g,)](
            p, q, scale, st, c, r, g, k, rb,
            num_warps=4, enable_fp_fusion=False,
        )
        pb = min(1024, tr.next_power_of_2(n * k))
        _parameter_reduce[(c,)](
            p, q, out, n, c, hw, k, pb,
            num_warps=4, enable_fp_fusion=False,
        )
        db = min(1024, tr.next_power_of_2(d))
        _data_gradient[(n * g, tr.cdiv(d, db))](
            x, dy, scale, mean, inv_var, st, out,
            c, r, g, hw, d, db,
            num_warps=4, enable_fp_fusion=False,
        )
        return out
