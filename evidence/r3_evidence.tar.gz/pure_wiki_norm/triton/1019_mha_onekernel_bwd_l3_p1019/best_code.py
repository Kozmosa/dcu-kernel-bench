import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _dq_kernel(
    q_ptr, k_ptr, o_ptr, lse_ptr, do_ptr, dq_ptr,
    sqb, sqm, sqh, sqd,
    skb, skn, skh, skd,
    sob, som, soh, sod,
    slb, slh, slm,
    sdob, sdom, sdoh, sdod,
    sdqb, sdqm, sdqh, sdqd,
    B, M, N, H,
    SCALE: tl.constexpr,
    CAUSAL: tl.constexpr,
    D: tl.constexpr,
    BM: tl.constexpr,
    BD: tl.constexpr,
):
    pid = tl.program_id(0)
    blocks_m = tl.cdiv(M, BM)
    h = pid % H
    t = pid // H
    mblock = t % blocks_m
    b = t // blocks_m

    rm = mblock * BM + tl.arange(0, BM)
    rd = tl.arange(0, BD)

    qoffs = (
        b * sqb
        + rm[:, None] * sqm
        + h * sqh
        + rd[None, :] * sqd
    )
    dooffs = (
        b * sdob
        + rm[:, None] * sdom
        + h * sdoh
        + rd[None, :] * sdod
    )
    ooffs = (
        b * sob
        + rm[:, None] * som
        + h * soh
        + rd[None, :] * sod
    )

    mm = rm < M
    dm = rd < D

    qv = tl.load(q_ptr + qoffs, mask=mm[:, None] & dm[None, :], other=0.0).to(tl.float32)
    dov = tl.load(do_ptr + dooffs, mask=mm[:, None] & dm[None, :], other=0.0).to(tl.float32)
    ov = tl.load(o_ptr + ooffs, mask=mm[:, None] & dm[None, :], other=0.0).to(tl.float32)

    delta = tl.sum(ov * dov, axis=1)
    lseoffs = b * slb + h * slh + rm * slm
    lsev = tl.load(lse_ptr + lseoffs, mask=mm, other=0.0).to(tl.float32)

    acc = tl.zeros((BM, BD), dtype=tl.float32)
    blocks_n = tl.cdiv(N, 64)

    for nb in range(0, blocks_n):
        rn = nb * 64 + tl.arange(0, 64)
        mn = rn < N

        koff = (
            b * skb
            + rn[:, None] * skn
            + (h * 0) * skh
            + rd[None, :] * skd
        )
        # The KV head is identical to the query head for this kernel's
        # logical instance after the caller has expanded the head indexing.
        # The actual grouped KV head is supplied through the flattened stride
        # offset below.
        kh = tl.load(k_ptr + koff, mask=mn[:, None] & dm[None, :], other=0.0).to(tl.float32)

        score = tl.dot(qv, tl.trans(kh)) * SCALE

        causal_mask = rn[None, :] <= (rm[:, None] + N - M)
        valid = mm[:, None] & mn[None, :]
        if CAUSAL:
            valid = valid & causal_mask

        score = tl.where(valid, score, float("-inf"))

        voff = (
            b * sdob
            + rm[:, None] * sdom
            + h * sdoh
            + rd[None, :] * sdod
        )
        # Reuse do rows to compute dp against v through the same KV layout.
        # v is passed through k_ptr's companion pointer via the argument alias
        # established by the wrapper kernel variant below.
        p = tl.exp(score - lsev[:, None])

        # This body is replaced by the grouped implementation below.
        # Keeping the kernel structurally valid permits specialization.
        acc += tl.dot(p, kh) * 0.0

    outoffs = (
        b * sdqb
        + rm[:, None] * sdqm
        + h * sdqh
        + rd[None, :] * sdqd
    )
    tl.store(dq_ptr + outoffs, acc, mask=mm[:, None] & dm[None, :])


@triton.jit
def _dq_grouped_kernel(
    q_ptr, k_ptr, v_ptr, o_ptr, lse_ptr, do_ptr, dq_ptr,
    sqb, sqm, sqh, sqd,
    skb, skn, skh, skd,
    svb, svn, svh, svd,
    sob, som, soh, sod,
    slb, slh, slm,
    sdob, sdom, sdoh, sdod,
    sdqb, sdqm, sdqh, sdqd,
    B, M, N, HQ, HK,
    SCALE: tl.constexpr,
    CAUSAL: tl.constexpr,
    D: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BD: tl.constexpr,
):
    pid = tl.program_id(0)
    blocks_m = tl.cdiv(M, BM)
    h = pid % HQ
    t = pid // HQ
    mb = t % blocks_m
    b = t // blocks_m
    hk = h // (HQ // HK)

    rm = mb * BM + tl.arange(0, BM)
    rd = tl.arange(0, BD)
    mm = rm < M
    dm = rd < D

    qoff = b * sqb + rm[:, None] * sqm + h * sqh + rd[None, :] * sqd
    doff = b * sdob + rm[:, None] * sdom + h * sdoh + rd[None, :] * sdod
    ooff = b * sob + rm[:, None] * som + h * soh + rd[None, :] * sod

    qv = tl.load(q_ptr + qoff, mask=mm[:, None] & dm[None, :], other=0.0).to(tl.float32)
    dov = tl.load(do_ptr + doff, mask=mm[:, None] & dm[None, :], other=0.0).to(tl.float32)
    ov = tl.load(o_ptr + ooff, mask=mm[:, None] & dm[None, :], other=0.0).to(tl.float32)
    delta = tl.sum(ov * dov, axis=1)

    lseoff = b * slb + h * slh + rm * slm
    lsev = tl.load(lse_ptr + lseoff, mask=mm, other=0.0).to(tl.float32)

    acc = tl.zeros((BM, BD), dtype=tl.float32)

    for nb in range(0, tl.cdiv(N, BN)):
        rn = nb * BN + tl.arange(0, BN)
        mn = rn < N

        koff = b * skb + rn[:, None] * skn + hk * skh + rd[None, :] * skd
        voff = b * svb + rn[:, None] * svn + hk * svh + rd[None, :] * svd

        kv = tl.load(k_ptr + koff, mask=mn[:, None] & dm[None, :], other=0.0).to(tl.float32)
        vv = tl.load(v_ptr + voff, mask=mn[:, None] & dm[None, :], other=0.0).to(tl.float32)

        score = tl.dot(qv, tl.trans(kv)) * SCALE
        dp = tl.dot(dov, tl.trans(vv))

        valid = mm[:, None] & mn[None, :]
        if CAUSAL:
            valid = valid & (rn[None, :] <= rm[:, None] + N - M)

        score = tl.where(valid, score, float("-inf"))
        p = tl.exp(score - lsev[:, None])
        p = tl.where(valid, p, 0.0)
        ds = p * (dp - delta[:, None])

        acc += tl.dot(ds, kv) * SCALE

    dqoff = b * sdqb + rm[:, None] * sdqm + h * sdqh + rd[None, :] * sdqd
    tl.store(dq_ptr + dqoff, acc, mask=mm[:, None] & dm[None, :])


@triton.jit
def _dkdv_kernel(
    q_ptr, k_ptr, v_ptr, o_ptr, lse_ptr, do_ptr, dk_ptr, dv_ptr,
    sqb, sqm, sqh, sqd,
    skb, skn, skh, skd,
    svb, svn, svh, svd,
    sob, som, soh, sod,
    slb, slh, slm,
    sdob, sdom, sdoh, sdod,
    sdkb, sdkn, sdkh, sdkd,
    sdvb, sdvn, sdvh, sdvd,
    B, M, N, HQ, HK,
    SCALE: tl.constexpr,
    CAUSAL: tl.constexpr,
    GROUP: tl.constexpr,
    D: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BD: tl.constexpr,
):
    pid = tl.program_id(0)
    blocks_n = tl.cdiv(N, BN)
    nb = pid % blocks_n
    t = pid // blocks_n
    hk = t % HK
    b = t // HK

    rn = nb * BN + tl.arange(0, BN)
    rd = tl.arange(0, BD)
    mn = rn < N
    dm = rd < D

    dk_acc = tl.zeros((BN, BD), dtype=tl.float32)
    dv_acc = tl.zeros((BN, BD), dtype=tl.float32)

    for g in range(0, GROUP):
        h = hk * GROUP + g

        for mb in range(0, tl.cdiv(M, BM)):
            rm = mb * BM + tl.arange(0, BM)
            mm = rm < M

            qoff = b * sqb + rm[:, None] * sqm + h * sqh + rd[None, :] * sqd
            doff = b * sdob + rm[:, None] * sdom + h * sdoh + rd[None, :] * sdod
            ooff = b * sob + rm[:, None] * som + h * soh + rd[None, :] * sod
            lseoff = b * slb + h * slh + rm * slm

            qv = tl.load(q_ptr + qoff, mask=mm[:, None] & dm[None, :], other=0.0).to(tl.float32)
            dov = tl.load(do_ptr + doff, mask=mm[:, None] & dm[None, :], other=0.0).to(tl.float32)
            ov = tl.load(o_ptr + ooff, mask=mm[:, None] & dm[None, :], other=0.0).to(tl.float32)
            delta = tl.sum(ov * dov, axis=1)
            lsev = tl.load(lse_ptr + lseoff, mask=mm, other=0.0).to(tl.float32)

            koff = b * skb + rn[:, None] * skn + hk * skh + rd[None, :] * skd
            voff = b * svb + rn[:, None] * svn + hk * svh + rd[None, :] * svd

            kv = tl.load(k_ptr + koff, mask=mn[:, None] & dm[None, :], other=0.0).to(tl.float32)
            vv = tl.load(v_ptr + voff, mask=mn[:, None] & dm[None, :], other=0.0).to(tl.float32)

            score = tl.dot(qv, tl.trans(kv)) * SCALE
            dp = tl.dot(dov, tl.trans(vv))

            valid = mm[:, None] & mn[None, :]
            if CAUSAL:
                valid = valid & (rn[None, :] <= rm[:, None] + N - M)

            score = tl.where(valid, score, float("-inf"))
            p = tl.exp(score - lsev[:, None])
            p = tl.where(valid, p, 0.0)
            ds = p * (dp - delta[:, None])

            dv_acc += tl.dot(tl.trans(p), dov)
            dk_acc += tl.dot(tl.trans(ds), qv) * SCALE

    dkoff = b * sdkb + rn[:, None] * sdkn + hk * sdkh + rd[None, :] * sdkd
    dvoff = b * sdvb + rn[:, None] * sdvn + hk * sdvh + rd[None, :] * sdvd

    tl.store(dk_ptr + dkoff, dk_acc, mask=mn[:, None] & dm[None, :])
    tl.store(dv_ptr + dvoff, dv_acc, mask=mn[:, None] & dm[None, :])


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, causal: int, scale=None):
        super().__init__()
        self.head_dim = int(head_dim)
        self.causal = bool(int(causal))
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)

    def forward(self, q, k, v, o, lse, do):
        B, M, HQ, D = q.shape
        _, N, HK, _ = k.shape
        assert HQ % HK == 0
        GROUP = HQ // HK

        bd = 1
        while bd < D:
            bd *= 2

        dq = torch.empty_like(q)
        dk = torch.empty((B, N, HK, D), device=q.device, dtype=torch.float32)
        dv = torch.empty((B, N, HK, D), device=q.device, dtype=torch.float32)

        BM = 32
        BN = 64

        _dq_grouped_kernel[
            (B * HQ * triton.cdiv(M, BM),)
        ](
            q, k, v, o, lse, do, dq,
            *q.stride(),
            *k.stride(),
            *v.stride(),
            *o.stride(),
            *lse.stride(),
            *do.stride(),
            *dq.stride(),
            B, M, N, HQ, HK,
            SCALE=self.sm_scale,
            CAUSAL=self.causal,
            D=D,
            BM=BM,
            BN=BN,
            BD=bd,
            num_warps=4,
            num_stages=2,
        )

        _dkdv_kernel[
            (B * HK * triton.cdiv(N, BN),)
        ](
            q, k, v, o, lse, do, dk, dv,
            *q.stride(),
            *k.stride(),
            *v.stride(),
            *o.stride(),
            *lse.stride(),
            *do.stride(),
            *dk.stride(),
            *dv.stride(),
            B, M, N, HQ, HK,
            SCALE=self.sm_scale,
            CAUSAL=self.causal,
            GROUP=GROUP,
            D=D,
            BM=BM,
            BN=BN,
            BD=bd,
            num_warps=4,
            num_stages=2,
        )

        return torch.cat([
            dq.reshape(-1).to(torch.float32),
            dk.to(q.dtype).reshape(-1).to(torch.float32),
            dv.to(v.dtype).reshape(-1).to(torch.float32),
        ])
