import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _extend_attention(Q, K, V, KB, VB, QP, KP, IDX, O,
                      HQ: tl.constexpr, HK: tl.constexpr,
                      DQ: tl.constexpr, DV: tl.constexpr,
                      GROUP: tl.constexpr, SCALE: tl.constexpr,
                      CAUSAL: tl.constexpr, CQ: tl.constexpr,
                      CV: tl.constexpr, N: tl.constexpr,
                      B: tl.constexpr):
    s = tl.program_id(0)
    h = tl.program_id(1)
    lo = 0
    hi = B
    while lo < hi:
        mid = (lo + hi) // 2
        boundary = tl.load(QP + mid + 1)
        advance = boundary <= s
        lo = tl.where(advance, mid + 1, lo)
        hi = tl.where(advance, hi, mid)
    seq = lo
    qs = tl.load(QP + seq)
    qe = tl.load(QP + seq + 1)
    ps = tl.load(KP + seq)
    pe = tl.load(KP + seq + 1)
    t = s - qs
    if t < qe - qs:
        g = h // GROUP
        plen = pe - ps
        length = plen + qe - qs
        if CAUSAL:
            length = plen + t + 1
        d = tl.arange(0, CQ)
        dv = tl.arange(0, CV)
        n = tl.arange(0, N)
        q = tl.load(Q + ((qs + t) * HQ + h) * DQ + d,
                    d < DQ, 0).to(tl.float32)
        m = tl.full((), -float("inf"), tl.float32)
        z = tl.full((), 0., tl.float32)
        acc = tl.full((CV,), 0., tl.float32)
        for start in range(0, length, N):
            j = start + n
            pref = j < plen
            valid = j < length
            ids = tl.load(IDX + ps + j, pref & valid, 0)
            er = qs + j - plen
            prefix_k_ptr = KB + (ids[:, None] * HK + g) * DQ + d[None, :]
            extend_k_ptr = K + (er[:, None] * HK + g) * DQ + d[None, :]
            k_ptr = tl.where(pref[:, None], prefix_k_ptr, extend_k_ptr)
            k = tl.load(k_ptr, valid[:, None] & (d < DQ)[None, :],
                        other=0).to(tl.float32)
            logits = tl.sum(k * q[None, :], 1) * SCALE
            logits = tl.where(valid, logits, -float("inf"))
            nm = tl.maximum(m, tl.max(logits, 0))
            alpha = tl.exp(m - nm)
            p = tl.exp(logits - nm)
            prefix_v_ptr = VB + (ids[:, None] * HK + g) * DV + dv[None, :]
            extend_v_ptr = V + (er[:, None] * HK + g) * DV + dv[None, :]
            v_ptr = tl.where(pref[:, None], prefix_v_ptr, extend_v_ptr)
            v = tl.load(v_ptr, valid[:, None] & (dv < DV)[None, :],
                        other=0).to(tl.float32)
            acc = acc * alpha + tl.sum(p[:, None] * v, 0)
            z = z * alpha + tl.sum(p, 0)
            m = nm
        tl.store(O + ((qs + t) * HQ + h) * DV + dv, acc / z, dv < DV)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Variable-length attention mixing the extend (incremental prefill) phase with a prefix segment (GQA, causal optional).

    Inside the batch each sequence's KV has two segments: the prefix segment is
    already written into the KV pool (k_buffer / v_buffer) and is addressed
    token by token indirectly through the row ids in kv_indices; the extend
    segment holds the tokens newly computed in this step, whose K/V are stored
    contiguously per token in k_extend / v_extend, with the query in q_extend in
    the same order. For sequence i let E_i = qo_indptr[i+1] - qo_indptr[i]
    (number of extend tokens) and P_i = kv_indptr[i+1] - kv_indptr[i] (number of
    prefix tokens). For the t-th query of the extend segment (global position
    T = P_i + t, row s = qo_indptr[i] + t) and query head h (its KV head is
    g = h // query_group_size, query_group_size = num_q_heads // num_kv_heads):
      K_full = concat(k_buffer[kv_indices[kv_indptr[i]:kv_indptr[i+1]]][:, g, :],
                      k_extend[qo_indptr[i]:qo_indptr[i+1]][:, g, :])   P_i + E_i rows
      V_full likewise (taking the head_dim_v head dimension)
      logits[j] = sm_scale * <q_extend[s, h, :], K_full[j]>
                 (sm_scale defaults to 1/sqrt(head_dim_q))
      visibility: the whole prefix is visible; the extend segment with causal=True
      sees only tokens with global position <= T (that is, the first t+1 extend
      tokens), and with causal=False everything is visible
      p = softmax(logits) (numerically stable online implementation)
      out[s, h, :] = sum_j p[j] * V_full[j]
    Under causal the query's own position is always visible, so the softmax
    denominator is always > 0. K's head dimension equals Q's head dimension
    head_dim_q; V's head dimension head_dim_v may differ from it.

    Input/output specification (evaluation dtype is float16 / bfloat16, all tensors contiguous):
      q_extend   evaluation dtype (total_extend, num_q_heads, head_dim_q)
      k_extend   evaluation dtype (total_extend, num_kv_heads, head_dim_q)
      v_extend   evaluation dtype (total_extend, num_kv_heads, head_dim_v)
      k_buffer   evaluation dtype (num_pool, num_kv_heads, head_dim_q)   prefix K pool
      v_buffer   evaluation dtype (num_pool, num_kv_heads, head_dim_v)   prefix V pool
      qo_indptr  int32 (num_seqs + 1) -- prefix sum of extend lengths (each segment >= 1)
      kv_indptr  int32 (num_seqs + 1) -- prefix sum of prefix lengths (each segment >= 0, may be all 0)
      kv_indices int32 (total_prefix) -- pool row ids of the prefix tokens, any
                 permutation is allowed; num_pool may exceed total_prefix, and the
                 unreferenced pool rows are garbage data that must not take part
                 in the computation
      returns out evaluation dtype (total_extend, num_q_heads, head_dim_v)

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - The evaluator casts every input tensor to fp32 before passing it to
        forward; the indptrs and pool row ids are small integers that fp32
        represents exactly, so .to(torch.int32) / .to(torch.long) at the entry
        recovers them losslessly.
      - The maximum extend length is not an input: the upper bound of the grid's
        third dimension can be derived inside forward from qo_indptr, or
        total_extend can be used directly as a conservative bound (inside the
        kernel, mask the out-of-range query rows with each sequence's
        cur_seq_len_extend).

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: prefix+extend mixed, variable-length (ragged) batch, GQA,
    causal/non-causal, Q/K/V head-dimension relation as above; no custom mask,
    no sliding window, no attention sink, no KV dequantization scale, the logit
    cap is not enabled (always 0), and the prefix segment gets no separate
    prefill-kernel fusion path -- those variants are left for later standalone
    tasks.
    """
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)
        # <<<END_IMPROVE>>>

    def forward(self, q_extend, k_extend, v_extend, k_buffer, v_buffer, qo_indptr, kv_indptr, kv_indices):
        # <<<IMPROVE:forward_stmt_1>>>
        qo_indptr = qo_indptr.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        kv_indptr = kv_indptr.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        kv_indices = kv_indices.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        total_extend, H_Q, Dq = q_extend.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        H_KV = k_extend.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        Dv = v_extend.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        scale = self.sm_scale if self.sm_scale is not None else 1.0 / math.sqrt(Dq)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        B = qo_indptr.shape[0] - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty((total_extend, H_Q, Dv), dtype=q_extend.dtype,
                          device=q_extend.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        _extend_attention[(total_extend, H_Q)](
            q_extend, k_extend, v_extend, k_buffer, v_buffer,
            qo_indptr, kv_indptr, kv_indices, out,
            H_Q, H_KV, Dq, Dv, group, scale, self.causal,
            triton.next_power_of_2(Dq), triton.next_power_of_2(Dv),
            64, B, num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
