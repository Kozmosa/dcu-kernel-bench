import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _paged_decode(
    Q, K, V, BT, LENS, OUT,
    QS: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
    KB: tl.constexpr, KH: tl.constexpr, KT: tl.constexpr, KD: tl.constexpr,
    VB: tl.constexpr, VH: tl.constexpr, VT: tl.constexpr, VD: tl.constexpr,
    BTS: tl.constexpr, BTT: tl.constexpr, LS: tl.constexpr,
    OS: tl.constexpr, OH: tl.constexpr, OD: tl.constexpr,
    D: tl.constexpr, BS: tl.constexpr, GROUP: tl.constexpr,
    SCALE: tl.constexpr, PAD_D: tl.constexpr,
):
    s = tl.program_id(0)
    h = tl.program_id(1)
    kv_h = h // GROUP
    length = tl.load(LENS + s * LS)
    d = tl.arange(0, PAD_D)
    q = tl.load(Q + s * QS + h * QH + d * QD, d < D, 0).to(tl.float32)
    q = q * SCALE
    numerator = tl.full((PAD_D,), 0.0, tl.float32)
    denominator = tl.full((), 0.0, tl.float32)
    maximum = tl.full((), float("-inf"), tl.float32)
    tokens = tl.arange(0, 128)

    for start in range(0, length, 128):
        positions = start + tokens
        valid = positions < length
        physical = tl.load(
            BT + s * BTS + (positions // BS) * BTT,
            mask=valid, other=0,
        )
        within = positions % BS
        k = tl.load(
            K + physical[:, None] * KB + kv_h * KH
            + within[:, None] * KT + d[None, :] * KD,
            mask=valid[:, None] & (d[None, :] < D), other=0,
        ).to(tl.float32)
        logits = tl.sum(k * q[None, :], axis=1)
        logits = tl.where(valid, logits, float("-inf"))
        new_maximum = tl.maximum(maximum, tl.max(logits, axis=0))
        alpha = tl.exp(maximum - new_maximum)
        probabilities = tl.exp(logits - new_maximum)
        v = tl.load(
            V + physical[:, None] * VB + kv_h * VH
            + within[:, None] * VT + d[None, :] * VD,
            mask=valid[:, None] & (d[None, :] < D), other=0,
        ).to(tl.float32)
        numerator = alpha * numerator + tl.sum(probabilities[:, None] * v, axis=0)
        denominator = alpha * denominator + tl.sum(probabilities, axis=0)
        maximum = new_maximum

    if length > 0:
        result = numerator / denominator
    else:
        result = tl.full((PAD_D,), 0.0, tl.float32)
    tl.store(OUT + s * OS + h * OH + d * OD, result, mask=d < D)


@triton.jit
def _paged_decode_partition(
    Q, K, V, BT, LENS, NUM, MAX, DEN,
    QS: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
    KB: tl.constexpr, KH: tl.constexpr, KT: tl.constexpr, KD: tl.constexpr,
    VB: tl.constexpr, VH: tl.constexpr, VT: tl.constexpr, VD: tl.constexpr,
    BTS: tl.constexpr, BTT: tl.constexpr, LS: tl.constexpr,
    D: tl.constexpr, BS: tl.constexpr, GROUP: tl.constexpr,
    SCALE: tl.constexpr, PAD_D: tl.constexpr,
    HEADS: tl.constexpr, N_SPLITS: tl.constexpr, PARTITION_SIZE: tl.constexpr,
):
    s = tl.program_id(0)
    h = tl.program_id(1)
    partition = tl.program_id(2)
    kv_h = h // GROUP
    length = tl.load(LENS + s * LS)
    begin = partition * PARTITION_SIZE
    end = tl.minimum(length, begin + PARTITION_SIZE)
    d = tl.arange(0, PAD_D)
    tokens = tl.arange(0, 128)
    q = tl.load(Q + s * QS + h * QH + d * QD, d < D, 0).to(tl.float32)
    q = q * SCALE
    numerator = tl.full((PAD_D,), 0.0, tl.float32)
    denominator = tl.full((), 0.0, tl.float32)
    maximum = tl.full((), float("-inf"), tl.float32)

    for start in range(begin, end, 128):
        positions = start + tokens
        valid = positions < end
        physical = tl.load(
            BT + s * BTS + (positions // BS) * BTT,
            mask=valid, other=0,
        )
        within = positions % BS
        k = tl.load(
            K + physical[:, None] * KB + kv_h * KH
            + within[:, None] * KT + d[None, :] * KD,
            mask=valid[:, None] & (d[None, :] < D), other=0,
        ).to(tl.float32)
        logits = tl.sum(k * q[None, :], axis=1)
        logits = tl.where(valid, logits, float("-inf"))
        new_maximum = tl.maximum(maximum, tl.max(logits, axis=0))
        alpha = tl.exp(maximum - new_maximum)
        probabilities = tl.exp(logits - new_maximum)
        v = tl.load(
            V + physical[:, None] * VB + kv_h * VH
            + within[:, None] * VT + d[None, :] * VD,
            mask=valid[:, None] & (d[None, :] < D), other=0,
        ).to(tl.float32)
        numerator = alpha * numerator + tl.sum(probabilities[:, None] * v, axis=0)
        denominator = alpha * denominator + tl.sum(probabilities, axis=0)
        maximum = new_maximum

    index = (s * HEADS + h) * N_SPLITS + partition
    tl.store(NUM + index * PAD_D + d, numerator)
    tl.store(MAX + index, maximum)
    tl.store(DEN + index, denominator)


@triton.jit
def _paged_decode_merge(
    NUM, MAX, DEN, OUT,
    OS: tl.constexpr, OH: tl.constexpr, OD: tl.constexpr,
    D: tl.constexpr, PAD_D: tl.constexpr,
    HEADS: tl.constexpr, N_SPLITS: tl.constexpr, PAD_SPLITS: tl.constexpr,
):
    s = tl.program_id(0)
    h = tl.program_id(1)
    partitions = tl.arange(0, PAD_SPLITS)
    d = tl.arange(0, PAD_D)
    index = (s * HEADS + h) * N_SPLITS + partitions
    denominator = tl.load(DEN + index, partitions < N_SPLITS, 0)
    maximum = tl.load(MAX + index, partitions < N_SPLITS, float("-inf"))
    nonempty = denominator > 0
    global_maximum = tl.max(tl.where(nonempty, maximum, float("-inf")), axis=0)
    any_nonempty = tl.sum(nonempty.to(tl.int32), axis=0) > 0
    global_maximum = tl.where(any_nonempty, global_maximum, 0.0)
    weights = tl.exp(tl.where(nonempty, maximum - global_maximum, float("-inf")))
    numerator = tl.load(
        NUM + index[:, None] * PAD_D + d[None, :],
        mask=(partitions[:, None] < N_SPLITS), other=0,
    )
    total_denominator = tl.sum(weights * denominator, axis=0)
    total_numerator = tl.sum(weights[:, None] * numerator, axis=0)
    result = total_numerator / tl.where(total_denominator > 0, total_denominator, 1.0)
    tl.store(OUT + s * OS + h * OH + d * OD, result, mask=d < D)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Paged attention in the decode phase (single-token query), supporting both
    MHA and GQA.

    The KV cache is stored page-wise with a fixed block_size in the physical block
    pools key_cache / value_cache, and each sequence addresses them indirectly
    through the physical block ids in block_tables; the KV length that actually
    participates in attention for each sequence is given by seq_lens[s], while the
    remaining slots in the pool hold garbage data and must not participate in the
    computation. For query head h of sequence s (whose KV head is
    h // query_group_size):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    The softmax uses an online (numerically stable) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding window.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        capacity = block_tables.shape[1] * bs
        if capacity <= 256:
            _paged_decode[(B, H_Q)](
                query, key_cache, value_cache, block_tables, seq_lens, out,
                *query.stride(),
                *key_cache.stride(),
                *value_cache.stride(),
                *block_tables.stride(),
                seq_lens.stride(0),
                *out.stride(),
                D, bs, group, self.scale, triton.next_power_of_2(D),
                num_warps=4,
                enable_fp_fusion=False,
            )
        else:
            partition_size = 256
            n_splits = triton.cdiv(capacity, partition_size)
            pad_d = triton.next_power_of_2(D)
            numerator = torch.empty(
                (B, H_Q, n_splits, pad_d), device=query.device, dtype=torch.float32
            )
            maximum = torch.empty(
                (B, H_Q, n_splits), device=query.device, dtype=torch.float32
            )
            denominator = torch.empty_like(maximum)
            _paged_decode_partition[(B, H_Q, n_splits)](
                query, key_cache, value_cache, block_tables, seq_lens,
                numerator, maximum, denominator,
                *query.stride(),
                *key_cache.stride(),
                *value_cache.stride(),
                *block_tables.stride(),
                seq_lens.stride(0),
                D, bs, group, self.scale, pad_d,
                H_Q, n_splits, partition_size,
                num_warps=4,
                enable_fp_fusion=False,
            )
            _paged_decode_merge[(B, H_Q)](
                numerator, maximum, denominator, out,
                *out.stride(),
                D, pad_d, H_Q, n_splits, triton.next_power_of_2(n_splits),
                num_warps=4,
                enable_fp_fusion=False,
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
