import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _dgrad_kernel(
    dy_ptr, w_ptr, x_ptr, off_ptr, mask_ptr,
    dx_ptr, doff_ptr, dmask_ptr,
    N, C, H, W, K, R, S, OH, OW,
    SH, SW, PH, PW, DH, DW,
    M: tl.constexpr, BC: tl.constexpr,
):
    pid = tl.program_id(0)
    total = N * OH * OW * M
    if pid >= total:
        return

    q = pid
    m = q % M
    q = q // M
    j = q % OW
    q = q // OW
    i = q % OH
    n = q // OH

    pm = m // S
    pn = m % S
    spatial = OH * OW
    off_base = ((n * (2 * M) + 2 * m) * OH + i) * OW + j

    oy = tl.load(off_ptr + off_base)
    ox = tl.load(off_ptr + off_base + spatial)
    yy = i * SH - PH + pm * DH + oy
    xx = j * SW - PW + pn * DW + ox

    y0 = tl.floor(yy).to(tl.int32)
    x0 = tl.floor(xx).to(tl.int32)
    y1 = y0 + 1
    x1 = x0 + 1
    fy = yy - y0.to(tl.float32)
    fx = xx - x0.to(tl.float32)

    vy0 = (y0 >= 0) & (y0 < H)
    vy1 = (y1 >= 0) & (y1 < H)
    vx0 = (x0 >= 0) & (x0 < W)
    vx1 = (x1 >= 0) & (x1 < W)
    v00 = vy0 & vx0
    v01 = vy0 & vx1
    v10 = vy1 & vx0
    v11 = vy1 & vx1

    cy0 = tl.where(vy0, y0, 0)
    cy1 = tl.where(vy1, y1, 0)
    cx0 = tl.where(vx0, x0, 0)
    cx1 = tl.where(vx1, x1, 0)

    c = tl.arange(0, BC)
    cmask = c < C
    b00 = ((n * C + c) * H + cy0) * W + cx0
    b01 = ((n * C + c) * H + cy0) * W + cx1
    b10 = ((n * C + c) * H + cy1) * W + cx0
    b11 = ((n * C + c) * H + cy1) * W + cx1

    x00 = tl.load(x_ptr + b00, mask=cmask & v00, other=0.0)
    x01 = tl.load(x_ptr + b01, mask=cmask & v01, other=0.0)
    x10 = tl.load(x_ptr + b10, mask=cmask & v10, other=0.0)
    x11 = tl.load(x_ptr + b11, mask=cmask & v11, other=0.0)

    wy = 1.0 - fy
    wx = 1.0 - fx
    val = wy * wx * x00 + wy * fx * x01 + fy * wx * x10 + fy * fx * x11
    gyv = wx * (x10 - x00) + fx * (x11 - x01)
    gxv = wy * (x01 - x00) + fy * (x11 - x10)

    fac = tl.load(mask_ptr + ((n * M + m) * OH + i) * OW + j)
    coeff = tl.zeros((BC,), dtype=tl.float32)
    dm = 0.0
    doy = 0.0
    dox = 0.0

    for ko in tl.range(0, K):
        dyv = tl.load(dy_ptr + ((n * K + ko) * OH + i) * OW + j)
        wi = ((ko * C + c) * R + pm) * S + pn
        wv = tl.load(w_ptr + wi, mask=cmask, other=0.0)
        coeff += dyv * wv
        dm += dyv * tl.sum(wv * val, axis=0)
        doy += dyv * tl.sum(wv * gyv, axis=0)
        dox += dyv * tl.sum(wv * gxv, axis=0)

    tl.store(doff_ptr + off_base, fac * doy)
    tl.store(doff_ptr + off_base + spatial, fac * dox)
    tl.store(dmask_ptr + ((n * M + m) * OH + i) * OW + j, dm)

    tl.atomic_add(dx_ptr + b00, coeff * fac * wy * wx, mask=cmask & v00)
    tl.atomic_add(dx_ptr + b01, coeff * fac * wy * fx, mask=cmask & v01)
    tl.atomic_add(dx_ptr + b10, coeff * fac * fy * wx, mask=cmask & v10)
    tl.atomic_add(dx_ptr + b11, coeff * fac * fy * fx, mask=cmask & v11)


@triton.jit
def _wrw_kernel(
    dy_ptr, x_ptr, off_ptr, mask_ptr, dw_ptr,
    N, C, H, W, K, R, S, OH, OW,
    SH, SW, PH, PW, DH, DW,
    M: tl.constexpr,
):
    pid = tl.program_id(0)
    total = K * C * R * S
    if pid >= total:
        return

    q = pid
    pn = q % S
    q = q // S
    pm = q % R
    q = q // R
    ci = q % C
    ko = q // C
    m = pm * S + pn

    acc = 0.0
    for z in tl.range(0, N * OH * OW):
        j = z % OW
        t = z // OW
        i = t % OH
        n = t // OH

        base = ((n * (2 * M) + 2 * m) * OH + i) * OW + j
        oy = tl.load(off_ptr + base)
        ox = tl.load(off_ptr + base + OH * OW)
        yy = i * SH - PH + pm * DH + oy
        xx = j * SW - PW + pn * DW + ox

        y0 = tl.floor(yy).to(tl.int32)
        x0 = tl.floor(xx).to(tl.int32)
        y1 = y0 + 1
        x1 = x0 + 1
        fy = yy - y0.to(tl.float32)
        fx = xx - x0.to(tl.float32)

        v00 = (y0 >= 0) & (y0 < H) & (x0 >= 0) & (x0 < W)
        v01 = (y0 >= 0) & (y0 < H) & (x1 >= 0) & (x1 < W)
        v10 = (y1 >= 0) & (y1 < H) & (x0 >= 0) & (x0 < W)
        v11 = (y1 >= 0) & (y1 < H) & (x1 >= 0) & (x1 < W)

        cy0 = tl.where((y0 >= 0) & (y0 < H), y0, 0)
        cy1 = tl.where((y1 >= 0) & (y1 < H), y1, 0)
        cx0 = tl.where((x0 >= 0) & (x0 < W), x0, 0)
        cx1 = tl.where((x1 >= 0) & (x1 < W), x1, 0)

        inp = (n * C + ci) * H * W
        x00 = tl.load(x_ptr + inp + cy0 * W + cx0, mask=v00, other=0.0)
        x01 = tl.load(x_ptr + inp + cy0 * W + cx1, mask=v01, other=0.0)
        x10 = tl.load(x_ptr + inp + cy1 * W + cx0, mask=v10, other=0.0)
        x11 = tl.load(x_ptr + inp + cy1 * W + cx1, mask=v11, other=0.0)

        val = (
            (1.0 - fy) * (1.0 - fx) * x00
            + (1.0 - fy) * fx * x01
            + fy * (1.0 - fx) * x10
            + fy * fx * x11
        )
        dyv = tl.load(dy_ptr + ((n * K + ko) * OH + i) * OW + j)
        mv = tl.load(mask_ptr + ((n * M + m) * OH + i) * OW + j)
        acc += dyv * mv * val

    tl.store(dw_ptr + ((ko * C + ci) * R + pm) * S + pn, acc)


def _run_deform_backward(
    variant, dy, weight, x, offset, mask,
    sh, sw, ph, pw, dh, dw,
):
    n, c, h, w = x.shape
    k, _, r, s = weight.shape
    oh, ow = dy.shape[2], dy.shape[3]
    m = r * s

    if variant == "wrw":
        out = torch.empty((k, c, r, s), device=x.device, dtype=torch.float32)
        _wrw_kernel[(k * c * r * s,)](
            dy, x, offset, mask, out,
            n, c, h, w, k, r, s, oh, ow,
            sh, sw, ph, pw, dh, dw, M=m,
        )
        return out

    dx = torch.zeros_like(x, dtype=torch.float32)
    doffset = torch.empty_like(offset, dtype=torch.float32)
    dmask = torch.empty_like(mask, dtype=torch.float32)
    bc = triton.next_power_of_2(c)

    _dgrad_kernel[(n * oh * ow * m,)](
        dy, weight, x, offset, mask,
        dx, doffset, dmask,
        n, c, h, w, k, r, s, oh, ow,
        sh, sw, ph, pw, dh, dw,
        M=m, BC=bc,
    )
    return torch.cat((dx.reshape(-1), doffset.reshape(-1), dmask.reshape(-1)))


# <<<END_IMPROVE>>>

def _bilinear_zero_pad(x, y_coord, x_coord):
    """Bilinear sampling (an integer coordinate is the pixel centre);
    contributions outside the boundary are 0.

    x: (n, c, h, w); y_coord / x_coord: (n, oh, ow) floating-point sampling
    coordinates (in the H/W coordinate system).
    Returns (n, c, oh, ow). Differentiable with respect to y_coord / x_coord:
    the coordinate gradient flows back only through the interpolation fractions
    (the frac terms) while the floor/index path is treated as a constant -- i.e.
    the subgradient of the standard zero-padding bilinear Theano/DCNv2
    convention.
    """
    n, c, h, w = x.shape
    oh, ow = y_coord.shape[1], y_coord.shape[2]
    y0 = torch.floor(y_coord)
    x0 = torch.floor(x_coord)
    y1 = y0 + 1
    x1 = x0 + 1
    ty = (y_coord - y0).unsqueeze(1)   # (n, 1, oh, ow)
    tx = (x_coord - x0).unsqueeze(1)

    def gather(yc, xc):
        valid = ((yc >= 0) & (yc <= h - 1) & (xc >= 0) & (xc <= w - 1)).unsqueeze(1)
        yi = yc.clamp(0, h - 1).long()
        xi = xc.clamp(0, w - 1).long()
        # The index tensors carry a batch dimension, so plain advanced indexing
        # would move the index dimensions to the front and produce 5-D;
        # flattening plus gather keeps (n, c, oh, ow) and stays differentiable
        # with respect to x
        idx = (yi * w + xi).reshape(n, 1, oh * ow).expand(n, c, oh * ow)
        got = x.reshape(n, c, h * w).gather(2, idx).reshape(n, c, oh, ow)
        return got * valid.to(x.dtype)

    return ((1 - ty) * (1 - tx) * gather(y0, x0)
            + (1 - ty) * tx * gather(y0, x1)
            + ty * (1 - tx) * gather(y1, x0)
            + ty * tx * gather(y1, x1))

class ModelNew(nn.Module):
    """
    Deformable 2D convolution backward (DCNv2, with mask modulation):
    gradient with respect to the input (dgrad) and gradient with respect to the
    weights (wrw).

    Semantics (NCHW, offset group = 1, no bias, strictly consistent with the
    standard DCNv2 forward):
        forward y = deform_conv2d(x, offset, weight, mask, stride=(sh,sw),
                               padding=(ph,pw), dilation=(dh,dw))
        output size out_h = floor((H + 2*ph - dh*(R-1) - 1) / sh) + 1 (likewise
        for out_w)
        the m-th kernel sampling point in row-major order m = pm*S + pn
        (pm = m // S, pn = m % S), at output position (i, j):
            sampling coordinate  Y = i*sh - ph + dh*pm + offset[b, 2*m,   i, j]
                                 X = j*sw - pw + dw_*pn + offset[b, 2*m+1, i, j]
            sampled value  V[b, :, i, j, m] = bilinear(x, Y, X): an integer
                coordinate is the pixel centre, interpolated bilinearly; the part
                of a sampling point that falls outside [0,H-1]x[0,W-1]
                contributes 0.
            y[b, ko, i, j] = sum_m mask[b, m, i, j] *
                                 sum_ci weight[ko, ci, pm, pn] * V[b, ci, i, j, m]
        offset channels correspond one-to-one with the kernel sampling points in
        row-major order: channel 2*m is the H-direction offset and 2*m+1 the
        W-direction offset (the only widespread DCNv2 convention; offset
        group = 1 for this task).
    Given the upstream gradient dy = dL/dy (shape (N, out_c, out_h, out_w)):
        dgrad: dx = dL/dx (N,C,H,W), doffset = dL/doffset (N,2*R*S,out_h,out_w),
               dmask = dL/dmask (N,R*S,out_h,out_w)
        wrw:   dw = dL/dw (out_c,C,R,S)
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns the three gradients packed into a single 1-D tensor by
                 the segmentation protocol;
        "wrw":   returns dw; the values of weight do not take part in the
                 output here (shape convention only).
    forward(dy, weight, x, offset, mask) has a fixed five-input signature; the
    tensors mean:
        dy     (N, out_c, out_h, out_w)     upstream gradient, consumed by both
                                            directions
        weight (out_c, C, R, S)             convolution kernel (out_c output
                                            channels / C input channels)
        x      (N, C, H, W)                 forward input
        offset (N, 2*R*S, out_h, out_w)     sampling offsets
        mask   (N, R*S, out_h, out_w)       modulation mask
    forward returns the single tensor out (float32) -- dgrad is a 1-D
    concatenated packing (segmentation protocol):
        out = cat([dx.reshape(-1), doffset.reshape(-1), dmask.reshape(-1)])
        length = N*C*H*W + N*2*R*S*out_h*out_w + N*R*S*out_h*out_w, with the
        segment order fixed as dx | doffset | dmask, each segment being the
        C-order flattening of the corresponding 4-D tensor; the segment order
        must not be swapped;
        wrw -> (out_c, C, R, S), inherently single-output with no packing.

    Input/output specification:
        dy / weight / x / offset / mask are all float32, contiguous, NCHW
        layout; every dimension >= 1; R/S may be 1 (1x1 kernel); H/W may be 1,
        odd, non-power-of-two, not 16-aligned; stride/dilation >= 1, padding
        >= 0, padding follows the forward four-sided symmetric (ph, pw)
        semantics; consistency constraint
            H + 2*ph >= dh*(R-1) + 1, W + 2*pw >= dw_*(S-1) + 1,
        and the spatial sizes of dy/offset/mask must equal out_h/out_w from the
        forward formula, offset channels = 2*R*S, mask channels = R*S.
        Input values are ordinary randn magnitude (no inf/NaN). The evaluator
        casts all inputs to fp32 before the call.

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a Triton kernel inside the
          submitted file: the backward bilinear-sampling scatter of dgrad (the
          analytic partial derivatives with respect to Y/X chained back through
          the kernel weights and the mask into dx/doffset/dmask, with
          out-of-boundary contributions set to 0) or the sampled-value
          correlation accumulation of wrw (summing the cross-correlation of the
          x sampling windows with dy); falling back to torch autograd /
          convolution primitives / grid_sample for the core computation is
          forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares a single
          output); the three dgrad segments must be packed by the segmentation
          protocol above and the segment order must not be swapped.
        - Numeric contract: float32 inputs are accumulated directly in float32,
          with no downcast to half precision; the three dgrad gradient segments
          and the wrw output are all float32.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torchvision / torch.nn.functional.conv2d / F.conv2d /
    torch.conv2d / torch.nn.Conv2d / torch.nn.functional.conv_transpose2d /
    F.conv_transpose2d / torch.nn.ConvTranspose2d /
    torch.nn.grad.conv2d_input / torch.nn.grad.conv2d_weight /
    aten.convolution_backward / deform_conv2d / deform_conv2d_backward /
    grid_sample / F.grid_sample / torch.nn.functional.grid_sample /
    torch.autograd / .backward( / unfold / F.fold /
    torch.nn.functional.fold / im2col / col2im / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1, pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wrw"), "variant must be either dgrad or wrw"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)
        # <<<END_IMPROVE>>>

    def forward(self, dy, weight, x, offset, mask):
        # <<<IMPROVE:forward_stmt_1>>>
        return _run_deform_backward(
            self.variant,
            dy,
            weight,
            x,
            offset,
            mask,
            self.stride_h,
            self.stride_w,
            self.pad_h,
            self.pad_w,
            self.dil_h,
            self.dil_w,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>

    def _deform_conv2d_forward(self, x, offset, weight, mask):
        """Handwritten DCNv2 forward (a composition of standard differentiable
        torch operators), used for the autograd backward pass."""
        n, c, h, w = x.shape
        k, _, r, s = weight.shape
        sh, sw = self.stride_h, self.stride_w
        ph, pw = self.pad_h, self.pad_w
        dh, dwl = self.dil_h, self.dil_w
        oh, ow = offset.shape[2], offset.shape[3]
        out = torch.zeros(n, k, oh, ow, dtype=x.dtype, device=x.device)
        for m in range(r * s):
            pm, pn = m // s, m % s
            base_y = torch.arange(oh, dtype=x.dtype, device=x.device) * sh - ph + dh * pm
            base_x = torch.arange(ow, dtype=x.dtype, device=x.device) * sw - pw + dwl * pn
            yo = base_y.view(1, oh, 1) + offset[:, 2 * m]      # (n, oh, ow)
            xo = base_x.view(1, 1, ow) + offset[:, 2 * m + 1]  # (n, oh, ow)
            val = _bilinear_zero_pad(x, yo, xo)                # (n, c, oh, ow)
            wc = weight[:, :, pm, pn]                          # (k, c)
            contrib = torch.einsum("oc,ncij->noij", wc, val)
            out = out + mask[:, m].unsqueeze(1) * contrib
        return out
