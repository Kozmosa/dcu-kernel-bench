import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _add_swiglu_bwd_kernel(
    base, delta, grad_out, fused, D, N, BLOCK: tl.constexpr
):
    pid = tl.program_id(0)
    offsets = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offsets < N

    row = offsets // D
    col = offsets % D
    width = 2 * D
    out_width = 3 * D

    gate_offset = row * width + col
    up_offset = row * width + D + col
    grad_offset = row * D + col
    fused_offset = row * out_width + col

    base_gate = tl.load(base + gate_offset, mask=mask, other=0.0).to(tl.float32)
    delta_gate = tl.load(delta + gate_offset, mask=mask, other=0.0).to(tl.float32)
    base_up = tl.load(base + up_offset, mask=mask, other=0.0).to(tl.float32)
    delta_up = tl.load(delta + up_offset, mask=mask, other=0.0).to(tl.float32)
    grad = tl.load(grad_out + grad_offset, mask=mask, other=0.0).to(tl.float32)

    gate = base_gate + delta_gate
    up = base_up + delta_up
    sig = 1.0 / (1.0 + tl.exp(-gate))
    silu = gate * sig
    out = silu * up
    dgate = (grad * up) * (sig + gate * sig * (1.0 - sig))
    dup = grad * silu

    tl.store(fused + fused_offset, out, mask=mask)
    tl.store(fused + fused_offset + D, dgate, mask=mask)
    tl.store(fused + fused_offset + 2 * D, dup, mask=mask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Training-oriented Add + SwiGLU fused operator: forward activation plus
    first-order analytic backward in a single call.

    Operator semantics:
      base and delta are added element-wise, then split in half along the last
      dimension (let D = width // 2):
        gate = (base + delta)[..., :D], up = (base + delta)[..., D:]
      The forward is a plain (non-clipped, non-interleaved) SwiGLU:
        out = SiLU(gate) * up, where SiLU(g) = g * sigmoid(g)
      The backward receives the upstream gradient grad_out (same shape as out);
      the derivative of SiLU is
        SiLU'(g) = sigmoid(g) * (1 + g * (1 - sigmoid(g)))
      base and delta enter the sum with the same coefficient, so their input
      gradients are element-wise identical:
        grad[..., :D] = (grad_out * up) * SiLU'(gate)
        grad[..., D:] = grad_out * SiLU(gate)
      This task merges forward and backward into a single forward call returning
      one fused tensor (3D columns):
        fused[..., 0:D)   = out (the activation output)
        fused[..., D:2D)  = the gate half of grad (the same for base and delta)
        fused[..., 2D:3D) = the up half of grad
      Boundary behaviour: width is a non-zero even number; num_rows may be 0 (an
      empty batch, output (0, 3D)); the input tensors are not modified; there is
      no broadcasting and no implicit dtype promotion; the evaluation ground truth
      is the float32 intermediate computation, and the tolerances cover the
      differences between half-precision rounding paths, so no specific eager
      rounding chain needs to be reproduced bit-for-bit.

    Input/output specification:
      base     (num_rows, width)      contiguous float16/bfloat16, width a non-zero even number
      delta    (num_rows, width)      same shape, dtype and device as base
      grad_out (num_rows, width // 2) same dtype as base, the upstream gradient of out
      returns  (num_rows, 3 * (width // 2)) same dtype as base, layout as above

    Implementation constraints (violations are scored as failures):
      - The core computation (the addition, SiLU/sigmoid, and the two gradient
        formulas) must be completed with a Triton kernel inside the submitted file;
        torch tensor operations are limited to output allocation and layout
        handling.
      - Calling ready-made implementations such as aiter /
        torch.nn.functional.silu / torch.sigmoid / torch.matmul / torch.bmm /
        torch.einsum is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, base, delta, grad_out):
        # <<<IMPROVE:forward_stmt_1>>>
        rows = base.shape[0]
        width = base.shape[1]
        D = width // 2
        N = rows * D
        fused = torch.empty(
            (rows, 3 * D), device=base.device, dtype=base.dtype
        )
        if N > 0:
            _add_swiglu_bwd_kernel[(triton.cdiv(N, 256),)](
                base, delta, grad_out, fused, D, N, BLOCK=256
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return fused
        # <<<END_IMPROVE>>>
