import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _triton_decode_attention(
    q_ptr,
    k_ptr,
    v_ptr,
    page_table_ptr,
    seq_lens_ptr,
    out_ptr,
    stride_q0,
    stride_q1,
    stride_q2,
    stride_o0,
    stride_o1,
    stride_o2,
    H_Q,
    H_KV,
    D_QK,
    D_V,
    page_size,
    max_pages_per_seq,
    group,
    scale,
    BLOCK_DQK: tl.constexpr,
    BLOCK_DV: tl.constexpr,
):
    bh = tl.program_id(0)
    dv_block = tl.program_id(1)
    b = bh // H_Q
    h = bh % H_Q
    hk = h // group

    q_offsets = tl.arange(0, BLOCK_DQK)
    q_mask = q_offsets < D_QK
    q_base = b * stride_q0 + h * stride_q1
    q = tl.load(
        q_ptr + q_base + q_offsets * stride_q2,
        mask=q_mask,
        other=0.0,
    ).to(tl.float32)

    dv_offsets = dv_block * BLOCK_DV + tl.arange(0, BLOCK_DV)
    dv_mask = dv_offsets < D_V
    acc = tl.zeros((BLOCK_DV,), dtype=tl.float32)
    seq_len = tl.load(seq_lens_ptr + b).to(tl.int32)
    BLOCK_T: tl.constexpr = 16
    token_offsets = tl.arange(0, BLOCK_T)
    m = tl.full((), -float("inf"), tl.float32)
    z = tl.full((), 0.0, tl.float32)

    for start in tl.range(0, seq_len, BLOCK_T):
        tokens = start + token_offsets
        valid = tokens < seq_len
        page_id = tl.load(
            page_table_ptr + b * max_pages_per_seq + tokens // page_size,
            mask=valid,
            other=0,
        ).to(tl.int64)
        slot = page_id * page_size + tokens % page_size
        k = tl.load(
            k_ptr + slot[:, None] * H_KV * D_QK
            + hk * D_QK + q_offsets[None, :],
            mask=valid[:, None] & q_mask[None, :],
            other=0.0,
        ).to(tl.float32)
        logits = tl.sum(q[None, :] * k, axis=1) * scale
        logits = tl.where(valid, logits, -float("inf"))
        tile_max = tl.max(logits, axis=0)
        new_m = tl.maximum(m, tile_max)
        alpha = tl.exp(m - new_m)
        weights = tl.exp(logits - new_m)
        z = z * alpha + tl.sum(weights, axis=0)
        v = tl.load(
            v_ptr + slot[:, None] * H_KV * D_V
            + hk * D_V + dv_offsets[None, :],
            mask=valid[:, None] & dv_mask[None, :],
            other=0.0,
        ).to(tl.float32)
        acc = acc * alpha + tl.sum(weights[:, None] * v, axis=0)
        m = new_m

    out_base = b * stride_o0 + h * stride_o1
    tl.store(
        out_ptr + out_base + dv_offsets * stride_o2,
        acc / z,
        mask=dv_mask,
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Decode-stage attention (single-token query) with paged KV.

    The KV cache is paged at page_size granularity: slot s of physical page p in
    key_cache / value_cache corresponds to flat slot number p * page_size + s.
    Sequence b is addressed indirectly through page_tables, and its l-th KV token
    (0 <= l < seq_lens[b]) lives in slot l % page_size of physical page
    page_tables[b, l // page_size]; slots in the page pool that are not
    referenced are garbage data and must not affect the output. Query head h
    corresponds to KV head h // query_group_size
    (query_group_size = num_q_heads // num_kv_heads, equal to 1 means MHA, equal
    to num_q_heads means MQA). For every sequence b and every query head h:
      logits[l] = scale * <q[b,h,:head_dim_qk],
                            key_flat[slot(b,l), h//group, :head_dim_qk]>
      p[l]      = exp(logits[l] - max(logits)) / sum(exp(logits - max(logits)))
      out[b,h,:head_dim_v] = sum_l p[l] * value_flat[slot(b,l), h//group, :head_dim_v]
    where key_flat / value_flat is the [num_pages*page_size, H_KV, D] flat view of
    the page pool, scale defaults to 1/sqrt(head_dim_qk), and the softmax must be
    numerically stable.

    Any implementation that is numerically equivalent within the tolerance is
    acceptable; how the work is parallelized is **not** a scoring criterion.

    Boundary behaviour:
      - Only the first seq_lens[b] KV tokens participate in the computation;
        seq_lens[b] >= 1 (an empty sequence is undefined).
      - page_size >= 1 is an arbitrary value (with page_size == 1 the page_tables
        are simply a per-token slot table).
      - head_dim_qk and head_dim_v may differ, and non-power-of-2 is allowed (for
        example 192/128, 576/512); the channels short of a power of 2 are handled
        by masking, so no out-of-bounds access occurs.
      - The page pool may be larger than what is actually used; page_tables
        entries beyond ceil(seq_lens[b]/page_size) point at valid but garbage
        pages that do not belong to this sequence.

    Inputs:
      q           [num_seqs, num_q_heads, head_dim_qk]  fp16/bf16 -- the query of
                  one new token per batch
      key_cache   [num_pages, page_size, num_kv_heads, head_dim_qk]
      value_cache [num_pages, page_size, num_kv_heads, head_dim_v]
      page_tables [num_seqs, max_pages_per_seq] int32 -- logical page -> physical page id
      seq_lens    [num_seqs] int32 -- the actually valid KV length of each sequence
    Output:
      out [num_seqs, num_q_heads, head_dim_v], dtype same as q.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV / cross-slice reduction) must
        be completed inside the submitted file; calling external attention
        operator libraries such as scaled_dot_product_attention / sdpa /
        flash_attn, as well as torch.matmul / torch.bmm / torch.einsum /
        torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, non-quantized KV, no logit_cap clamping, no
    ALiBi, no sliding window.
    """
    def __init__(self, page_size: int, head_dim_qk: int, head_dim_v: int, num_kv_splits: int = 8, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.page_size = int(page_size)
        self.head_dim_qk = int(head_dim_qk)
        self.head_dim_v = int(head_dim_v)
        self.num_kv_splits = int(num_kv_splits)
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim_qk)
        # <<<END_IMPROVE>>>

    def forward(self, q, key_cache, value_cache, page_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        page_tables = page_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D_QK = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_pages, page_size, H_KV, _ = key_cache.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        D_V = value_cache.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert page_size == self.page_size, "the key_cache page size does not match the initialized page_size"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        key_flat = key_cache.view(num_pages * page_size, H_KV, D_QK)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        value_flat = value_cache.view(num_pages * page_size, H_KV, D_V)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty(B, H_Q, D_V, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        def _next_pow2(x):
            return 1 << (int(x) - 1).bit_length()

        block_qk = _next_pow2(D_QK)
        block_dv = _next_pow2(D_V)
        max_pages_per_seq = page_tables.shape[1]
        grid = (B * H_Q, triton.cdiv(D_V, block_dv))

        _triton_decode_attention[grid](
            q,
            key_flat,
            value_flat,
            page_tables,
            seq_lens,
            out,
            q.stride(0),
            q.stride(1),
            q.stride(2),
            out.stride(0),
            out.stride(1),
            out.stride(2),
            H_Q,
            H_KV,
            D_QK,
            D_V,
            page_size,
            max_pages_per_seq,
            group,
            self.scale,
            BLOCK_DQK=block_qk,
            BLOCK_DV=block_dv,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
