import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _deform_conv2d_kernel(
    x, off, weight, bias, mask, out,
    n_total: tl.constexpr, c: tl.constexpr, h: tl.constexpr, w: tl.constexpr,
    k_out: tl.constexpr, r: tl.constexpr, s: tl.constexpr,
    h_out: tl.constexpr, w_out: tl.constexpr,
    stride_h: tl.constexpr, stride_w: tl.constexpr,
    pad_h: tl.constexpr, pad_w: tl.constexpr,
    dilation_h: tl.constexpr, dilation_w: tl.constexpr,
    modulated: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    spatial = tl.program_id(0) * BLOCK_M + tl.arange(0, BLOCK_M)
    ko = tl.program_id(1) * BLOCK_K + tl.arange(0, BLOCK_K)

    spatial_total = n_total * h_out * w_out
    spatial_mask = spatial < spatial_total
    channel_mask = ko < k_out

    t = spatial
    oj = t % w_out
    t = t // w_out
    oi = t % h_out
    ni = t // h_out

    acc = tl.zeros((BLOCK_K, BLOCK_M), dtype=tl.float32)
    for ci in tl.range(0, c, loop_unroll_factor=1):
        for p in tl.range(0, r * s, loop_unroll_factor=1):
            ri = p // s
            sj = p - ri * s
            off_y_idx = (
                (ni * (2 * r * s) + 2 * p) * h_out * w_out
                + oi * w_out + oj
            )
            off_x_idx = off_y_idx + h_out * w_out
            oy = tl.load(off + off_y_idx, mask=spatial_mask, other=0.0).to(tl.float32)
            ox = tl.load(off + off_x_idx, mask=spatial_mask, other=0.0).to(tl.float32)
            yc = oi.to(tl.float32) * stride_h + ri * dilation_h - pad_h + oy
            xc = oj.to(tl.float32) * stride_w + sj * dilation_w - pad_w + ox

            iy0 = tl.floor(yc).to(tl.int32)
            ix0 = tl.floor(xc).to(tl.int32)
            iy1 = iy0 + 1
            ix1 = ix0 + 1
            wy = yc - iy0.to(tl.float32)
            wx = xc - ix0.to(tl.float32)

            v00 = spatial_mask & (iy0 >= 0) & (iy0 < h) & (ix0 >= 0) & (ix0 < w)
            v01 = spatial_mask & (iy0 >= 0) & (iy0 < h) & (ix1 >= 0) & (ix1 < w)
            v10 = spatial_mask & (iy1 >= 0) & (iy1 < h) & (ix0 >= 0) & (ix0 < w)
            v11 = spatial_mask & (iy1 >= 0) & (iy1 < h) & (ix1 >= 0) & (ix1 < w)

            sy0 = tl.where(v00 | v01, iy0, 0)
            sy1 = tl.where(v10 | v11, iy1, 0)
            sx0 = tl.where(v00 | v10, ix0, 0)
            sx1 = tl.where(v01 | v11, ix1, 0)
            xbase = (ni * c + ci) * h * w
            a00 = tl.load(x + xbase + sy0 * w + sx0, mask=v00, other=0.0).to(tl.float32)
            a01 = tl.load(x + xbase + sy0 * w + sx1, mask=v01, other=0.0).to(tl.float32)
            a10 = tl.load(x + xbase + sy1 * w + sx0, mask=v10, other=0.0).to(tl.float32)
            a11 = tl.load(x + xbase + sy1 * w + sx1, mask=v11, other=0.0).to(tl.float32)
            sampled = (
                a00 * (1.0 - wy) * (1.0 - wx)
                + a01 * (1.0 - wy) * wx
                + a10 * wy * (1.0 - wx)
                + a11 * wy * wx
            )
            if modulated:
                mask_idx = (ni * (r * s) + p) * h_out * w_out + oi * w_out + oj
                sampled = sampled * tl.load(
                    mask + mask_idx, mask=spatial_mask, other=0.0,
                ).to(tl.float32)

            widx = ((ko * c + ci) * r + ri) * s + sj
            coeff = tl.load(
                weight + widx, mask=channel_mask, other=0.0,
            ).to(tl.float32)
            acc += coeff[:, None] * sampled[None, :]

    b = tl.load(bias + ko, mask=channel_mask, other=0.0).to(tl.float32)
    acc += b[:, None]

    out_idx = (
        (ni[None, :] * k_out + ko[:, None]) * h_out * w_out
        + oi[None, :] * w_out
        + oj[None, :]
    )
    tl.store(
        out + out_idx,
        acc,
        mask=channel_mask[:, None] & spatial_mask[None, :],
    )


def _deform_conv2d_fwd(
    x, offset, weight, bias, mask,
    n, c, h, w, k_out, r, s, h_out, w_out,
    stride, padding, dilation, modulated,
):
    out = torch.empty(
        (n, k_out, h_out, w_out),
        device=x.device,
        dtype=x.dtype,
    )
    block_m = 64
    block_k = 16
    spatial_total = n * h_out * w_out
    grid = (
        triton.cdiv(spatial_total, block_m),
        triton.cdiv(k_out, block_k),
    )
    _deform_conv2d_kernel[grid](
        x, offset, weight, bias, mask, out,
        n, c, h, w, k_out, r, s, h_out, w_out,
        stride[0], stride[1],
        padding[0], padding[1],
        dilation[0], dilation[1],
        modulated=modulated,
        BLOCK_M=block_m,
        BLOCK_K=block_k,
        num_warps=4,
    )
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Deformable 2D convolution forward (Deformable Convolution): sampling grid
    plus a handwritten bilinear interpolation.

    Semantics (NCHW, all intermediate computation in float32):
      For each output position (oi, oj) and kernel position p = i*S + j
      (i in [0,R), j in [0,S), row-major), the base sampling coordinate given by
      the regular convolutional receptive field is
          y0 = oi * stride_h + i * dilation_h - padding_h
          x0 = oj * stride_w + j * dilation_w - padding_w
      After adding the per-(output position x kernel position) offsets, the
      input map is sampled at real-valued coordinates with bilinear
      interpolation:
          yc = y0 + offset[n, 2*p,     oi, oj]     # even channel = y offset
          xc = x0 + offset[n, 2*p + 1, oi, oj]     # odd channel = x offset
          v(n, c, p, oi, oj) = bilinear(input map, yc, xc)
      The __init__ parameter variant selects one of the two paths:
          "modulated" (default, modulated form): the sampled value is
              additionally multiplied by the per-position modulation mask
              v *= mask[n, p, oi, oj]
          "plain" (mask-free form): mask does not take part in the computation
              (its contents are arbitrary, possibly garbage data).
      The output is a single tensor:
          out[n, k, oi, oj] = bias[k]
                              + sum_{c, p} v(n, c, p, oi, oj) * weight[k, c, i, j]
      After the computation it is cast back to the input dtype.

    Bilinear interpolation definition (point-wise identical to mainstream
    deformable convolution operators):
      Let iy = floor(yc), ix = floor(xc), wy = yc - iy, wx = xc - ix, and take
      the four corners (iy, ix), (iy, ix+1), (iy+1, ix), (iy+1, ix+1) with
      weights (1-wy)(1-wx), (1-wy)wx, wy(1-wx), wy*wx respectively; when either
      the row or the column of a corner is out of range (< 0 or > dim-1) that
      corner contributes 0 while the remaining corners are weighted as usual --
      i.e. zero-fill semantics: a partially out-of-range coordinate is still
      weighted by the remaining valid corners, and when it is entirely out of
      range (yc <= -1, outside the yc >= H-1 boundary band, etc.) the sampled
      value is 0. No clamp / nearest-neighbour pull-back is done anywhere.

    Input/output specification (all tensors contiguous, NCHW layout):
      x        float32 / float16 / bfloat16 (N, C, H, W)
      offset   same dtype as x (N, 2*R*S, H_out, W_out): 2 channels per kernel
               position (even channel = y offset, odd channel = x offset,
               p = i*S + j row-major)
      weight   same dtype as x (K, C, R, S)
      bias     same dtype as x (K,)
      mask     same dtype as x (N, R*S, H_out, W_out) (ignored when
               variant="plain")
      out      a single tensor, same dtype as x (N, K, H_out, W_out)
      H_out = (H + 2*padding_h - dilation_h*(R-1) - 1) // stride_h + 1, likewise
      for W_out. The evaluator casts all inputs to fp32 before the call
      (low-precision inputs are lossless).

    Implementation constraints (violations are scored as failures):
      - The core computation (sampling-grid construction, bilinear-interpolation
        sampling, mask modulation, the weighted reduction against weight) must
        be handwritten with a Triton kernel inside the submitted file.
      - forward returns the single tensor out (the evaluator compares a single
        output).
      - Interpolation and the weighted reduction are computed in float32, with
        the output cast back to the input dtype.
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torchvision (including torchvision.ops.deform_conv2d) /
    torch.nn.functional.conv2d (F.conv2d) / torch.nn.Conv2d /
    torch.nn.functional.grid_sample (F.grid_sample) /
    torch.nn.functional.unfold (F.unfold) / torch.matmul / torch.bmm /
    torch.mm / torch.einsum / torch.tensordot / miopen / hipdnn / aiter.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "modulated", stride=(1, 1), padding=(1, 1), dilation=(1, 1)):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("modulated", "plain"), "variant must be either modulated or plain"
        self.variant = variant
        self.stride = (int(stride[0]), int(stride[1]))
        self.padding = (int(padding[0]), int(padding[1]))
        self.dilation = (int(dilation[0]), int(dilation[1]))
        # <<<END_IMPROVE>>>

    def forward(self, x, offset, weight, bias, mask):
        # <<<IMPROVE:forward_stmt_1>>>
        n, c, h, w = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        k_out = weight.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        r, s = weight.shape[2], weight.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        sh, sw = self.stride
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        ph, pw = self.padding
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dh, dw = self.dilation
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        h_out = (h + 2 * ph - (dh * (r - 1) + 1)) // sh + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        w_out = (w + 2 * pw - (dw * (s - 1) + 1)) // sw + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert offset.shape[1] == 2 * r * s and mask.shape[1] == r * s, \
            "the channel counts of offset/mask must be 2*R*S / R*S"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert offset.shape[2] == h_out and offset.shape[3] == w_out \
            and mask.shape[2] == h_out and mask.shape[3] == w_out, \
            "the spatial sizes of offset/mask must be (H_out, W_out)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return _deform_conv2d_fwd(
            x, offset, weight, bias, mask,
            n, c, h, w, k_out, r, s, h_out, w_out,
            self.stride, self.padding, self.dilation,
            self.variant == "modulated",
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_27>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_28>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_29>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_30>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_31>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_32>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_33>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_34>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_35>>>
        # <<<END_IMPROVE>>>
