import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _bn_partial(DY, X, Mean, Inv, PG, PB,
                S: tl.constexpr, M: tl.constexpr, C: tl.constexpr,
                K: tl.constexpr, BLOCK: tl.constexpr):
    tile = tl.program_id(0).to(tl.int64)
    c = tl.program_id(1).to(tl.int64)
    q = tile * BLOCK + tl.arange(0, BLOCK).to(tl.int64)
    valid = q < M
    offset = (q // S) * (C * S) + c * S + q % S
    xv = tl.load(X + offset, valid, other=0).to(tl.float32)
    dyv = tl.load(DY + offset, valid, other=0).to(tl.float32)
    mean = tl.load(Mean + c).to(tl.float32)
    inv = tl.load(Inv + c).to(tl.float32)
    xhat = (xv - mean) * inv
    dg = tl.sum(tl.where(valid, dyv * xhat, 0.0), 0)
    db = tl.sum(tl.where(valid, dyv, 0.0), 0)
    tl.store(PG + c * K + tile, dg)
    tl.store(PB + c * K + tile, db)


@triton.jit
def _bn_finalize(PG, PB, Out, C: tl.constexpr, K: tl.constexpr,
                 BLOCK: tl.constexpr):
    c = tl.program_id(0).to(tl.int64)
    lanes = tl.arange(0, BLOCK).to(tl.int64)
    ag = tl.zeros((BLOCK,), tl.float32)
    ab = tl.zeros((BLOCK,), tl.float32)
    for start in range(0, K, BLOCK):
        q = start + lanes
        ag += tl.load(PG + c * K + q, q < K, other=0)
        ab += tl.load(PB + c * K + q, q < K, other=0)
    tl.store(Out + c, tl.sum(ag, 0))
    tl.store(Out + C + c, tl.sum(ab, 0))


@triton.jit
def _bn_dx(DY, X, Scale, Mean, Inv, Grad, Out,
           S: tl.constexpr, M: tl.constexpr, C: tl.constexpr,
           T: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0).to(tl.int64) * BLOCK + tl.arange(0, BLOCK).to(tl.int64)
    valid = i < T
    c = (i // S) % C
    xv = tl.load(X + i, valid, other=0).to(tl.float32)
    dyv = tl.load(DY + i, valid, other=0).to(tl.float32)
    mean = tl.load(Mean + c, valid, other=0).to(tl.float32)
    inv = tl.load(Inv + c, valid, other=0).to(tl.float32)
    scale = tl.load(Scale + c, valid, other=0).to(tl.float32)
    dg = tl.load(Grad + c, valid, other=0)
    db = tl.load(Grad + C + c, valid, other=0)
    xhat = (xv - mean) * inv
    result = ((scale * inv) / M) * ((M * dyv - db) - xhat * dg)
    tl.store(Out + i, result, valid)


@triton.jit
def _bn_small(DY, X, Scale, Mean, Inv, Out,
              S: tl.constexpr, M: tl.constexpr, C: tl.constexpr,
              BLOCK: tl.constexpr, PARAM_ONLY: tl.constexpr):
    c = tl.program_id(0).to(tl.int64)
    q = tl.arange(0, BLOCK).to(tl.int64)
    valid = q < M
    offset = (q // S) * (C * S) + c * S + q % S
    xv = tl.load(X + offset, valid, other=0).to(tl.float32)
    dyv = tl.load(DY + offset, valid, other=0).to(tl.float32)
    mean = tl.load(Mean + c).to(tl.float32)
    inv = tl.load(Inv + c).to(tl.float32)
    xhat = (xv - mean) * inv
    dg = tl.sum(tl.where(valid, dyv * xhat, 0.0), 0)
    db = tl.sum(tl.where(valid, dyv, 0.0), 0)
    if PARAM_ONLY:
        tl.store(Out + c, dg)
        tl.store(Out + C + c, db)
    else:
        scale = tl.load(Scale + c).to(tl.float32)
        result = ((scale * inv) / M) * ((M * dyv - db) - xhat * dg)
        tl.store(Out + offset, result, valid)


def _launch_bn_backward(dy, x, scale, saved_mean, saved_inv_variance, variant):
    n, c, h, w = x.shape
    s = h * w
    m = n * s
    t = x.numel()
    if m <= 1024:
        param_only = variant == "dgamma_dbeta"
        out = (torch.empty((2 * c,), device=x.device, dtype=x.dtype)
               if param_only else torch.empty_like(x))
        _bn_small[(c,)](
            dy, x, scale, saved_mean, saved_inv_variance, out,
            s, m, c, max(64, triton.next_power_of_2(m)), param_only,
            num_warps=4, enable_fp_fusion=False)
        return out
    k = triton.cdiv(m, 1024)
    pg = torch.empty((c, k), device=x.device, dtype=torch.float32)
    pb = torch.empty_like(pg)
    grad = torch.empty((2 * c,), device=x.device,
                       dtype=x.dtype if variant == "dgamma_dbeta" else torch.float32)
    _bn_partial[(k, c)](
        dy, x, saved_mean, saved_inv_variance, pg, pb,
        s, m, c, k, 1024, num_warps=4, enable_fp_fusion=False)
    _bn_finalize[(c,)](
        pg, pb, grad, c, k, 1024, num_warps=4, enable_fp_fusion=False)
    if variant == "dgamma_dbeta":
        return grad
    out = torch.empty_like(x)
    _bn_dx[(triton.cdiv(t, 256),)](
        dy, x, scale, saved_mean, saved_inv_variance, grad, out,
        s, m, c, t, 256, num_warps=4, enable_fp_fusion=False)
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    BatchNorm training backward: given the upstream gradient dy, the input x of
    the training forward, the saved statistics (saved_mean / saved_inv_variance) and
    the scale parameter, compute the gradients of the normalized forward
        y = scale * xhat + bias,  xhat = (x - saved_mean) * saved_inv_variance
    The __init__ argument variant selects which gradients are returned:
        "dx"           : returns only the data gradient dx, shape (N, C, H, W), same
                         dtype as x;
        "dgamma_dbeta" : returns only the parameter gradients; dgamma and dbeta are
                         each (1, C, 1, 1) and are emitted as a single 1-D tensor
                         (2*C,) following the "one-dimensional concatenation packing
                         protocol": the first C elements are dgamma (flattened in
                         row-major order) and the last C are dbeta.
    Both variants share the same forward signature; the return value is always a
    single tensor (the evaluator compares a single output). Mathematical definition
    (float32 intermediate computation throughout, m = N*H*W elements per channel):
        xhat         = (x - saved_mean) * saved_inv_variance
        dgamma[c]    = sum_{n,h,w} dy * xhat          (summed per channel)
        dbeta[c]     = sum_{n,h,w} dy                 (summed per channel)
        dx           = (scale * saved_inv_variance / m)
                       * (m*dy - dbeta - xhat * dgamma)
    saved_mean / saved_inv_variance are consumed verbatim as the given values: they
    are the statistics saved by the training forward (inv_variance = 1/sqrt(biased
    variance + eps); eps was already absorbed in the forward, and the backward math
    itself contains no eps) and may be any positive numbers unrelated to the true
    statistics of x -- the given values must be used directly, and recomputing the
    statistics from x is forbidden. saved_inv_variance is always positive.

    Input/output specification (NCHW, contiguous):
        dy                 float32 / float16 / bfloat16 (N, C, H, W)
        x                  same dtype as dy (N, C, H, W)
        scale              same dtype as dy (1, C, 1, 1)
        saved_mean         float32 (1, C, 1, 1) (the statistics are always float32,
                           independent of the input dtype)
        saved_inv_variance float32 (1, C, 1, 1), its elements are always positive
        out                single tensor: (N, C, H, W) with the same dtype as dy for
                           dx; (2*C,) with the same dtype as dy for dgamma_dbeta (the
                           first C are dgamma and the last C are dbeta, both computed
                           in float32 and then cast)
        The evaluator casts all inputs to fp32 before passing them in (fp16/bf16 ->
        fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (xhat reconstruction, the two channel reductions, and
          the element-wise chained multiply-add of dx) must be completed inside the
          submitted file with a Triton kernel; a channel reduction of any size (m =
          N*H*W may exceed the capacity of a single block) must be handled correctly
          with mask / tiling (block-wise) reductions, leaving out no element of the
          channel.
        - Computing the gradients through torch.autograd / autograd.grad /
          .backward() is forbidden, as is calling the batch_norm primitive family or
          any closed-source library primitive (MIOpen / hipDNN and the like).
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The reductions and the intermediate computation run in float32; the output
          is cast back to the input dtype; the packing order of dgamma_dbeta is fixed
          as the dgamma segment first and the dbeta segment last.

    Boundary behaviour: N, C, H and W may all be 1 (m may be 1, in which case
    dx = scale * inv_var * (dy - dy*xhat^2)); non-powers of two and unaligned
    dimensions are allowed; the statistics shape is always (1, C, 1, 1); the input
    value range is the usual randn magnitude (no inf/NaN).
    Forbidden: aiter / torch.batch_norm / torch.native_batch_norm /
    torch.nn.functional.batch_norm / F.batch_norm / torch.nn.BatchNorm1d /
    torch.nn.BatchNorm2d / torch.nn.BatchNorm3d /
    torch.ops.aten.batch_norm / torch.ops.aten.native_batch_norm /
    autograd / .backward(.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "dx"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dx", "dgamma_dbeta"), "variant must be one of dx / dgamma_dbeta"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, dy, x, scale, saved_mean, saved_inv_variance):
        # <<<IMPROVE:forward_stmt_1>>>
        return _launch_bn_backward(dy, x, scale, saved_mean, saved_inv_variance, self.variant)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        mean = saved_mean.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        inv_var = saved_inv_variance.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        xhat = (xf - mean) * inv_var
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dgamma_c = (dyf * xhat).sum(dim=(0, 2, 3))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        dbeta_c = dyf.sum(dim=(0, 2, 3))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if self.variant == "dgamma_dbeta":
            # single-tensor packing: the dgamma segment first and the dbeta segment
            # last, each flattened in row-major order
            return torch.cat([dgamma_c.to(x.dtype).reshape(-1),
                              dbeta_c.to(x.dtype).reshape(-1)])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        m = x.shape[0] * x.shape[2] * x.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        scalef = scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        dx = (scalef * inv_var / m) * (m * dyf - dbeta_c.reshape_as(scalef)
                                       - xhat * dgamma_c.reshape_as(scalef))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return dx.to(x.dtype)
        # <<<END_IMPROVE>>>
