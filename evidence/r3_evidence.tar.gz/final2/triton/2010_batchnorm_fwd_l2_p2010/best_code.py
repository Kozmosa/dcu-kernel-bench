import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _bn_inference(X, S, B, Mean, Var, Y,
                  TOTAL: tl.constexpr, C: tl.constexpr, HW: tl.constexpr,
                  EPS: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0).to(tl.int64) * BLOCK + tl.arange(0, BLOCK)
    valid = i < TOTAL
    c = (i // HW) % C
    x = tl.load(X + i, valid, 0).to(tl.float32)
    s = tl.load(S + c, valid, 0).to(tl.float32)
    b = tl.load(B + c, valid, 0).to(tl.float32)
    mu = tl.load(Mean + c, valid, 0).to(tl.float32)
    var = tl.load(Var + c, valid, 0).to(tl.float32)
    y = (x - mu) * tl.rsqrt(var + EPS) * s + b
    tl.store(Y + i, y, valid)


@triton.jit
def _bn_training(X, S, B, Mean, Var, Out,
                 M: tl.constexpr, C: tl.constexpr, HW: tl.constexpr,
                 EPS: tl.constexpr, MOM: tl.constexpr,
                 BLOCK: tl.constexpr):
    c = tl.program_id(0).to(tl.int64)
    lane = tl.arange(0, BLOCK).to(tl.int64)
    acc = tl.full((BLOCK,), 0, tl.float32)
    for start in range(tl.cdiv(M, BLOCK)):
        k = start * BLOCK + lane
        idx = (k // HW) * C * HW + c * HW + k % HW
        v = tl.load(X + idx, k < M, 0).to(tl.float32)
        acc += v
    mu = tl.sum(acc, 0) / M
    acc_var = tl.full((BLOCK,), 0, tl.float32)
    for start in range(tl.cdiv(M, BLOCK)):
        k = start * BLOCK + lane
        idx = (k // HW) * C * HW + c * HW + k % HW
        v = tl.load(X + idx, k < M, 0).to(tl.float32)
        d = tl.where(k < M, v - mu, 0.0)
        acc_var += d * d
    var = tl.sum(acc_var, 0) / M
    inv = tl.rsqrt(var + EPS)
    s = tl.load(S + c).to(tl.float32)
    b = tl.load(B + c).to(tl.float32)
    old_mu = tl.load(Mean + c).to(tl.float32)
    old_var = tl.load(Var + c).to(tl.float32)
    tl.store(Out + M * C + c, mu)
    tl.store(Out + M * C + C + c, inv)
    tl.store(Out + M * C + 2 * C + c, (1.0 - MOM) * old_mu + MOM * mu)
    unbiased = var * (M / (M - 1))
    tl.store(Out + M * C + 3 * C + c,
             (1.0 - MOM) * old_var + MOM * unbiased)
    for start in range(tl.cdiv(M, BLOCK)):
        k = start * BLOCK + lane
        idx = (k // HW) * C * HW + c * HW + k % HW
        v = tl.load(X + idx, k < M, 0).to(tl.float32)
        y = (v - mu) * inv * s + b
        tl.store(Out + idx, y, k < M)


@triton.jit
def _bn_training_resident(X, S, B, Mean, Var, Out,
                          M: tl.constexpr, C: tl.constexpr, HW: tl.constexpr,
                          EPS: tl.constexpr, MOM: tl.constexpr,
                          BLOCK: tl.constexpr):
    c = tl.program_id(0).to(tl.int64)
    k = tl.arange(0, BLOCK).to(tl.int64)
    idx = (k // HW) * C * HW + c * HW + k % HW
    v = tl.load(X + idx, k < M, 0).to(tl.float32)
    mu = tl.sum(v, 0) / M
    d = tl.where(k < M, v - mu, 0.0)
    var = tl.sum(d * d, 0) / M
    inv = tl.rsqrt(var + EPS)
    s = tl.load(S + c).to(tl.float32)
    b = tl.load(B + c).to(tl.float32)
    old_mu = tl.load(Mean + c).to(tl.float32)
    old_var = tl.load(Var + c).to(tl.float32)
    tl.store(Out + M * C + c, mu)
    tl.store(Out + M * C + C + c, inv)
    tl.store(Out + M * C + 2 * C + c, (1.0 - MOM) * old_mu + MOM * mu)
    unbiased = var * (M / (M - 1))
    tl.store(Out + M * C + 3 * C + c,
             (1.0 - MOM) * old_var + MOM * unbiased)
    y = (v - mu) * inv * s + b
    tl.store(Out + idx, y, k < M)


def _batchnorm_triton_forward(x, scale, bias, mean, variance, variant, eps, momentum):
    n, c, h, w = x.shape
    hw = h * w
    m = n * hw
    if variant == "inference":
        out = torch.empty_like(x)
        _bn_inference[(triton.cdiv(x.numel(), 256),)](
            x, scale, bias, mean, variance, out,
            x.numel(), c, hw, eps, 256, num_warps=4, enable_fp_fusion=False)
    else:
        assert m >= 2, "the training variant requires N*H*W >= 2 (the m/(m-1) unbiased correction factor of the running variance)"
        out = torch.empty((x.numel() + 4 * c,), device=x.device, dtype=torch.float32)
        if m <= 8192:
            _bn_training_resident[(c,)](
                x, scale, bias, mean, variance, out,
                m, c, hw, eps, momentum, triton.next_power_of_2(m),
                num_warps=4, enable_fp_fusion=False)
        else:
            training_block = 8192 if m >= 32768 else 4096
            _bn_training[(c,)](
                x, scale, bias, mean, variance, out,
                m, c, hw, eps, momentum, training_block, num_warps=4, enable_fp_fusion=False)
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    BatchNorm forward family: inference affine (inference) and training batch
    statistics (training).

    The input is x (N, C, H, W), NCHW contiguous; scale / bias / mean / variance are
    all (1, C, 1, 1) and broadcast along the channel dimension. Reduction dimension:
    per-channel, computing the statistics of every channel c over the three
    dimensions (N, H, W), with m = N*H*W elements per channel. The __init__ argument
    variant selects one of two paths (eps defaults to 1e-5 and momentum to 0.1; both
    are scalar hyper-parameters only):

        "inference": the mean and the variance are given as inputs, element-wise
                     affine (float32 intermediate computation):
            y = scale * (x - mean) / sqrt(variance + eps) + bias
        "training": batch statistics + affine + running update (float32
                    throughout):
            batch_mean_c = sum_{n,h,w} x[n,c,h,w] / m                    (biased batch mean)
            batch_var_c  = sum_{n,h,w} (x[n,c,h,w] - batch_mean_c)^2 / m (biased batch variance)
            saved_mean         = batch_mean                              (shape (1,C,1,1))
            saved_inv_variance = 1 / sqrt(batch_var + eps)               (shape (1,C,1,1))
            y = scale * (x - saved_mean) * saved_inv_variance + bias
            next_running_mean = (1 - momentum) * mean + momentum * batch_mean
            next_running_var  = (1 - momentum) * variance
                                + momentum * batch_var * m / (m - 1)
            In the training variant the 4th/5th forward arguments are the running
            statistics of the previous step (prev_running_mean / prev_running_var);
            the running variance update uses the unbiased batch variance (the
            m/(m-1) correction, hence the requirement m >= 2) -- this is the
            standard PyTorch / cuDNN / MIOpen training-BN convention.

    The forward signature is (x, scale, bias, mean, variance) for both variants: in
    inference the 4th/5th arguments are the given mean / variance, in training they
    are prev_running_mean / prev_running_var.

    Single-tensor output protocol (forward must return a single tensor; the
    evaluator compares a single output):
        "inference": returns y itself, shape (N, C, H, W), same dtype as x;
        "training" : returns a one-dimensional float32 packed tensor of length
                     N*C*H*W + 4*C; the five logical outputs are each cast to
                     float32, reshaped with reshape(-1) and torch.cat'ed in the
                     sample-output order, with the segment protocol (half-open
                     intervals):
            [0,            N*C*H*W)      y
            [N*C*H*W,      N*C*H*W + C)  saved_mean
            [N*C*H*W + C,  N*C*H*W + 2C) saved_inv_variance
            [N*C*H*W + 2C, N*C*H*W + 3C) next_running_mean
            [N*C*H*W + 3C, N*C*H*W + 4C) next_running_var

    Input/output specification:
        x        float32 (always float32 for training) / float16 / bfloat16
                 (inference only), (N, C, H, W), contiguous, N/C/H/W >= 1
        scale    same dtype as x, (1, C, 1, 1), contiguous
        bias     same dtype as x, (1, C, 1, 1), contiguous
        mean     same dtype as x, (1, C, 1, 1), contiguous (inference: the given
                 mean, any real value; training: prev_running_mean)
        variance same dtype as x, (1, C, 1, 1), contiguous, always positive
                 (inference: the given variance; training: prev_running_var)
        out      inference: (N, C, H, W), same dtype as x; training: one-dimensional
                 float32 of length N*C*H*W + 4*C (the five-segment packing protocol
                 above)
        The inputs are the usual randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-channel reduction statistics, rsqrt, the
          affine, and the running update) must be completed inside the submitted
          file with a Triton kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, the normalization and the running update all use float32
          intermediates; the y of inference is cast back to the x dtype; all five
          training segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.BatchNorm1d / torch.nn.BatchNorm2d /
    torch.nn.BatchNorm3d / torch.nn.SyncBatchNorm /
    torch.nn.functional.batch_norm / torch.batch_norm /
    torch.native_batch_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "training", eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("inference", "training"), "variant must be one of inference / training"
        assert eps > 0, "eps must be positive"
        assert 0.0 <= momentum <= 1.0, "momentum must be in [0, 1]"
        self.variant = variant
        self.eps = float(eps)
        self.momentum = float(momentum)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias, mean, variance):
        # <<<IMPROVE:forward_stmt_1>>>
        return _batchnorm_triton_forward(x, scale, bias, mean, variance, self.variant, self.eps, self.momentum)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        sf = scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        bf = bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        mf = mean.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        vf = variance.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        if self.variant == "inference":
            # element-wise affine with the given mean/variance; (1,C,1,1)
            # broadcasts along the channel dimension
            inv_std = torch.rsqrt(vf + eps)
            y = (xf - mf) * inv_std * sf + bf
            return y.to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        m = xf.shape[0] * xf.shape[2] * xf.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert m >= 2, "the training variant requires N*H*W >= 2 (the m/(m-1) unbiased correction factor of the running variance)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        batch_mean = xf.mean(dim=(0, 2, 3), keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        batch_var = ((xf - batch_mean) ** 2).mean(dim=(0, 2, 3), keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        saved_inv_variance = torch.rsqrt(batch_var + eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        y = (xf - batch_mean) * saved_inv_variance * sf + bf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        batch_var_unbiased = batch_var * (m / (m - 1))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        next_running_mean = (1.0 - self.momentum) * mf + self.momentum * batch_mean
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        next_running_var = (1.0 - self.momentum) * vf + self.momentum * batch_var_unbiased
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        return torch.cat([
            y.to(torch.float32).reshape(-1),
            batch_mean.to(torch.float32).reshape(-1),
            saved_inv_variance.to(torch.float32).reshape(-1),
            next_running_mean.to(torch.float32).reshape(-1),
            next_running_var.to(torch.float32).reshape(-1),
        ])
        # <<<END_IMPROVE>>>
