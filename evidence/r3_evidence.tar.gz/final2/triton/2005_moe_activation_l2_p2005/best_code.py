import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _moe_activation_kernel(
    x_ptr,
    out_ptr,
    m: tl.constexpr,
    input_width: tl.constexpr,
    output_width: tl.constexpr,
    mode: tl.constexpr,
    alpha: tl.constexpr,
    limit: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    offsets = tl.program_id(0) * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < m * output_width

    if mode < 4:
        u = tl.load(x_ptr + offsets, mask=mask, other=0.0).to(tl.float32)
        if mode == 0:
            y = u / (1.0 + tl.exp(-u))
        elif mode == 1:
            y = 0.5 * u * (1.0 + tl.erf(u * 0.7071067811865476))
        elif mode == 2:
            inner = 0.7978845608028654 * (u + 0.044715 * u * u * u)
            e = tl.exp(-2.0 * tl.abs(inner))
            t = (1.0 - e) / (1.0 + e)
            t = tl.where(inner >= 0.0, t, -t)
            y = 0.5 * u * (1.0 + t)
        else:
            p = tl.maximum(u, 0.0)
            y = p * p
    else:
        if mode == 10:
            gate_off = 2 * offsets
            up_off = gate_off + 1
        else:
            row = offsets // output_width
            gate_off = offsets + row * output_width
            up_off = gate_off + output_width

        gate = tl.load(x_ptr + gate_off, mask=mask, other=0.0).to(tl.float32)
        up = tl.load(x_ptr + up_off, mask=mask, other=0.0).to(tl.float32)

        if mode == 9:
            silu_gate = gate / (1.0 + tl.exp(-gate))
            gate_value = tl.minimum(silu_gate, limit)
            up_value = tl.minimum(tl.maximum(up, -limit), limit)
            y = gate_value * up_value
        elif mode == 4:
            y = gate / (1.0 + tl.exp(-gate)) * up
        elif mode == 5:
            gate_value = tl.minimum(gate, limit)
            up_value = tl.minimum(tl.maximum(up, -limit), limit)
            y = gate_value / (1.0 + tl.exp(-gate_value)) * up_value
        elif mode == 6 or mode == 10:
            gate_value = tl.minimum(gate, limit)
            up_value = tl.minimum(tl.maximum(up, -limit), limit)
            y = gate_value / (1.0 + tl.exp(-alpha * gate_value)) * (up_value + 1.0)
        elif mode == 7:
            y = 0.5 * gate * (1.0 + tl.erf(gate * 0.7071067811865476)) * up
        else:
            inner = 0.7978845608028654 * (gate + 0.044715 * gate * gate * gate)
            e = tl.exp(-2.0 * tl.abs(inner))
            t = (1.0 - e) / (1.0 + e)
            t = tl.where(inner >= 0.0, t, -t)
            y = 0.5 * gate * (1.0 + t) * up

    tl.store(out_ptr + offsets, y, mask=mask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """MoE FFN activation variant family: gated activations (SwiGLU family
    variants) and non-gated element-wise activations, dispatched by the __init__
    parameters activation / alpha / limit.

    All computation runs in float32 and the output is cast back to the input dtype.
    Define
        SiLU(u)      = u * sigmoid(u)
        GELU(u)      = 0.5 * u * (1 + erf(u * 0.7071067811865476))
        GELU_tanh(u) = 0.5 * u * (1 + tanh(0.7978845608028654
                                           * (u + 0.044715 * u^3)))
        ReLU2(u)     = max(u, 0)^2
    sigmoid / erf / tanh are all evaluated as float32 math functions.

    [gated variants] The input x has shape (M, 2N) and the output (M, N). Two data
    layouts:
        chunked (default) : gate = x[:, :N], up = x[:, N:]
        interleaved       : gate = x[:, 0::2] (even columns), up = x[:, 1::2] (odd
                            columns)
    Write the clamped quantities as gate' = min(gate, limit) (upper bound only) and
    up' = clamp(up, -limit, limit) (symmetric clamping); the output of each variant
    is:
        activation="silu", alpha=None, limit=None:
            out = SiLU(gate) * up                        (standard SwiGLU)
        activation="silu", alpha=None, limit=L:
            out = SiLU(gate') * up'                       (clamped SwiGLU)
        activation="silu", alpha=A, limit=L (A and L must be given together):
            out = gate' * sigmoid(A * gate') * (up' + 1)  (scaled clamped gate)
        activation="gelu" (does not accept alpha / limit):
            out = GELU(gate) * up
        activation="gelu_tanh" (does not accept alpha / limit):
            out = GELU_tanh(gate) * up
        activation="swiglustep" (limit defaults to 7.0, does not accept alpha):
            out = clamp(SiLU(gate), max=limit) * up'      (SiLU first, then the
                                                           upper clamp)
        activation="swiglu_interleaved" (interleaved layout; alpha defaults to
        1.702, limit defaults to 7.0):
            out = gate' * sigmoid(alpha * gate') * (up' + 1)

    [non-gated variants] The input x has shape (M, N) and the output (M, N);
    element-wise activation, alpha / limit are ignored:
        activation="silu_no_mul"      : out = SiLU(x)
        activation="gelu_no_mul"      : out = GELU(x)
        activation="gelu_tanh_no_mul" : out = GELU_tanh(x)
        activation="relu2"            : out = ReLU2(x)

    Boundary behaviour: clamping of gate is upper-bound only (nothing is clamped on
    the negative side) while clamping of up is symmetric; the clamping is applied
    before the activation, except for swiglustep, which computes SiLU first and then
    clamps the result on the upper side. Illegal parameter combinations (an unknown
    variant name; gelu / gelu_tanh with alpha or limit; swiglustep with alpha; silu
    given alpha but not limit) are rejected at construction time.

    Input/output specification:
        x    float16 / bfloat16 (M, n), contiguous, M >= 1; the gated variants
             require n to be even (N = n/2 has no alignment constraint: non-powers
             of two and sizes below the common block size are allowed); the
             non-gated variants accept any n >= 1. The evaluator casts the input to
             fp32 before passing it in; fp16/bf16 -> fp32 is lossless.
        out  same dtype as x; shape (M, n/2) for the gated variants and (M, n) for
             the non-gated ones.
        The input value range is the usual randn magnitude (no inf/NaN).

    Implementation constraints (violations are scored as failures):
        - The core computation (chunked / interleaved data selection, clamping,
          activation, gated multiply) must be completed with a Triton kernel inside
          the submitted file; intermediates are always float32.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate accumulation; cast the output back to the
          input dtype.

    (4) Forbidden list and target hardware:
    - Calling ATen shortcuts such as torch.nn.functional.silu /
      torch.nn.functional.gelu / torch.nn.SiLU / torch.nn.GELU / torch.sigmoid /
      torch.erf / torch.tanh / torch.relu / torch.clamp to complete this task's
      computation directly is forbidden; the authoritative forbidden list is the
      task.yaml forbidden list (it covers the source operator library and other
      closed-source acceleration libraries; the final static audit does substring
      matching on the code outside docstrings / comments);
    - Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, activation: str = "silu", alpha=None, limit=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        gated = ("silu", "gelu", "gelu_tanh", "swiglustep", "swiglu_interleaved")
        nomul = ("silu_no_mul", "gelu_no_mul", "gelu_tanh_no_mul", "relu2")
        name = str(activation).lower()
        assert name in gated or name in nomul, (
            "activation must be one of " + "/".join(gated + nomul) + " variants")
        if name in ("gelu", "gelu_tanh"):
            assert alpha is None and limit is None, "gelu / gelu_tanh do not accept alpha / limit"
        if name == "swiglustep":
            assert alpha is None, "swiglustep does not accept alpha"
        if name == "silu" and alpha is not None:
            assert limit is not None, "silu must set limit as well when alpha is set"
        if name == "swiglustep" and limit is None:
            limit = 7.0
        if name == "swiglu_interleaved":
            alpha = 1.702 if alpha is None else alpha
            limit = 7.0 if limit is None else limit
        self.activation = name
        self.is_gated = name in gated
        self.alpha = None if alpha is None else float(alpha)
        self.limit = None if limit is None else float(limit)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        xf = x.to(torch.float32)
        assert xf.dim() == 2, "the input must be a 2D (M, n) tensor"

        mode_map = {
            "silu_no_mul": 0,
            "gelu_no_mul": 1,
            "gelu_tanh_no_mul": 2,
            "relu2": 3,
            "silu": 4 if self.limit is None else (6 if self.alpha is not None else 5),
            "gelu": 7,
            "gelu_tanh": 8,
            "swiglustep": 9,
            "swiglu_interleaved": 10,
        }
        mode = mode_map[self.activation]
        m, input_width = xf.shape
        if self.is_gated:
            assert input_width % 2 == 0, (
                "the gated variants require the last dimension n to be even")
            output_width = input_width // 2
        else:
            output_width = input_width

        out = torch.empty(
            (m, output_width), device=x.device, dtype=x.dtype)
        alpha_value = 0.0 if self.alpha is None else self.alpha
        limit_value = 0.0 if self.limit is None else self.limit
        total = m * output_width
        grid = (triton.cdiv(total, 256),)
        _moe_activation_kernel[grid](
            xf,
            out,
            m,
            input_width,
            output_width,
            mode=mode,
            alpha=alpha_value,
            limit=limit_value,
            BLOCK_SIZE=256,
        )
        return out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert xf.dim() == 2, "the input must be a 2D (M, n) tensor"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Non-gated activations are executed by modes 0 through 3 above.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert xf.shape[-1] % 2 == 0, "the gated variants require the last dimension n to be even"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        half = xf.shape[-1] // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        interleaved = self.activation == "swiglu_interleaved"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        gate = xf[:, 0::2] if interleaved else xf[:, :half]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        up = xf[:, 1::2] if interleaved else xf[:, half:]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # SiLU followed by the upper clamp is implemented by mode 9.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # Scaled clamped SiLU is implemented by mode 6.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Clamped SwiGLU is implemented by mode 5.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Standard SwiGLU is implemented by mode 4.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Gated GELU is implemented by mode 7.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # Gated tanh GELU is implemented by mode 8.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # Interleaved scaled clamped SiLU is implemented by mode 10.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return out.to(x.dtype)
        # <<<END_IMPROVE>>>
