import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _fused_adamw_kernel(
    params_ptr,
    grads_ptr,
    exp_avg_ptr,
    exp_avg_sq_ptr,
    step_ptr,
    out_ptr,
    n_elements,
    lr,
    beta1,
    beta2,
    eps,
    weight_decay,
    standard: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < n_elements

    params = tl.load(params_ptr + offsets, mask=mask, other=0.0).to(tl.float32)
    grads = tl.load(grads_ptr + offsets, mask=mask, other=0.0).to(tl.float32)
    exp_avg = tl.load(exp_avg_ptr + offsets, mask=mask, other=0.0).to(tl.float32)
    exp_avg_sq = tl.load(exp_avg_sq_ptr + offsets, mask=mask, other=0.0).to(tl.float32)
    step_value = tl.load(step_ptr).to(tl.float32)

    p = params * (1.0 - lr * weight_decay)
    m = beta1 * exp_avg + (1.0 - beta1) * grads
    v = beta2 * exp_avg_sq + (1.0 - beta2) * grads * grads

    if standard:
        beta1_power = tl.exp(tl.log(beta1) * step_value)
        beta2_power = tl.exp(tl.log(beta2) * step_value)
        bc1 = 1.0 - beta1_power
        bc2 = 1.0 - beta2_power
        denom = tl.sqrt(v / bc2) + eps
        update = (m / bc1) / denom
    else:
        denom = tl.sqrt(v) + eps
        update = m / denom

    result = p - lr * update
    tl.store(out_ptr + offsets, result, mask=mask)


def _fused_adamw(
    params,
    grads,
    exp_avg,
    exp_avg_sq,
    step,
    lr,
    beta1,
    beta2,
    eps,
    weight_decay,
    standard,
):
    output = torch.empty_like(params)
    step_tensor = (
        step
        if torch.is_tensor(step)
        else torch.tensor(float(step), device=params.device, dtype=torch.float32)
    )
    n_elements = params.numel()
    block_size = 256 if n_elements < 65536 else 1024
    grid = lambda meta: (triton.cdiv(n_elements, meta["BLOCK_SIZE"]),)
    _fused_adamw_kernel[grid](
        params,
        grads,
        exp_avg,
        exp_avg_sq,
        step_tensor,
        output,
        n_elements,
        lr,
        beta1,
        beta2,
        eps,
        weight_decay,
        standard=standard,
        BLOCK_SIZE=block_size,
        num_warps=4,
    )
    return output
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Fused AdamW optimizer family: a single functional (out-of-place) parameter
    update for standard AdamW and for Transformer-schedule AdamW.

    (1) Operator semantics: the __init__ hyper-parameters lr, beta1, beta2, eps,
    weight_decay are construction constants, and `variant` selects one of two
    update paths. Let `step` be a 0-dimensional float32 scalar tensor (the
    current iteration count). The four state tensors params / grads / exp_avg /
    exp_avg_sq have the same shape and are element-wise aligned; the whole update
    is computed in float32 (inputs are promoted to float32 first):
        1) decoupled weight decay (the AdamW form, applied in both variants --
           equivalent to p = params - lr * weight_decay * params, not L2
           regularization):
               p = params * (1 - lr * weight_decay)
        2) first moment: m = beta1 * exp_avg + (1 - beta1) * grads
        3) second moment: v = beta2 * exp_avg_sq + (1 - beta2) * grads^2
        4) variant="adamw" (standard AdamW, bias correction ON):
               bc1 = 1 - beta1^step; bc2 = 1 - beta2^step
               out = p - lr * (m / bc1) / (sqrt(v / bc2) + eps)
           variant="transformer_adamw" (Transformer schedule, bias correction
           OFF -- the only difference between the two variants):
               out = p - lr * m / (sqrt(v) + eps)
    The two variants are line-by-line identical apart from bias correction; eps is
    added outside the sqrt (denom = sqrt(...) + eps); the power beta^step is a
    float32 scalar power.
    Boundary behaviour: at step=1, bc1 = 1 - beta1 and bc2 = 1 - beta2 take their
    minimum values (the standard AdamW path amplifies the most); for very large
    step the two variants converge numerically; exp_avg_sq is always
    non-negative (second-moment constraint, generated in [0, 0.5)) and
    denom >= eps guarantees no division by zero; this operator has no reduction
    and no indexing -- it is a pure element-wise map.

    (2) Input/output specification:
      - params / grads / exp_avg / exp_avg_sq: float32 or float16 tensors, all
        with the same shape (ndim 1-4, numel >= 1, including non-power-of-two and
        boundary sizes), contiguous;
      - step: a 0-dimensional float32 scalar tensor (numel == 1) whose value is a
        positive-integer-semantics step count (>= 1);
      - returns: the updated parameters, a new tensor with the same shape and
        dtype as params (single-tensor output, out-of-place; no input may be
        modified in place, and no state such as exp_avg / exp_avg_sq may be
        returned).

    (3) Implementation constraints (violations are scored as failures):
      - The core computation (decoupled weight decay, first/second moment update,
        bias-correction power, sqrt, element-wise update) must be completed with a
        Triton kernel inside the submitted file;
      - out-of-place: params / grads / exp_avg / exp_avg_sq must not be modified
        in place;
      - the __init__ and forward signatures of ModelNew must not be changed;
      - intermediate computation uses float32 (fp16 inputs are promoted to
        float32 as well), and the final result is cast back to the dtype of
        params;
      - step arrives as a 0-dimensional tensor and participates in the power
        operation as a scalar inside the kernel; it must not be materialized into
        a temporary tensor of the same shape as params.

    (4) Forbidden list and target hardware:
      - the whole torch.optim family is forbidden (torch.optim.AdamW / Adam /
        SGD / ... plus their _functional / _multi_tensor internal paths);
      - any fused-optimizer library and closed-source entry point is forbidden:
        apex / deepspeed / bitsandbytes / the fused_adam entry-point family /
        hipdnn / miopen;
      - completing this task via an ATen shortcut is forbidden: torch.addcdiv /
        torch.addcmul (including the .addcdiv / .addcdiv_ / .addcmul / .addcmul_
        tensor methods and in-place forms, which finish the parameter update or
        the moment update in a single call); the multi-tensor primitives
        torch._foreach_addcdiv / torch._foreach_addcmul are equally forbidden
        (including their in-place _ forms, which complete the core update step in
        a single call) (the final static audit does substring matching on code
        outside docstrings/comments);
      Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "adamw", lr: float = 1e-3, beta1: float = 0.9, beta2: float = 0.999, eps: float = 1e-8, weight_decay: float = 0.01):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("adamw", "transformer_adamw"), \
            "variant must be one of adamw / transformer_adamw"
        self.variant = variant
        self.lr = float(lr)
        self.beta1 = float(beta1)
        self.beta2 = float(beta2)
        self.eps = float(eps)
        self.weight_decay = float(weight_decay)
        # <<<END_IMPROVE>>>

    def forward(self, params, grads, exp_avg, exp_avg_sq, step):
        # <<<IMPROVE:forward_stmt_1>>>
        return _fused_adamw(
            params,
            grads,
            exp_avg,
            exp_avg_sq,
            step,
            self.lr,
            self.beta1,
            self.beta2,
            self.eps,
            self.weight_decay,
            self.variant == "adamw",
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        g = grads.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        m = exp_avg.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        v = exp_avg_sq.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        s = step.to(torch.float32) if torch.is_tensor(step) \
            else torch.tensor(float(step))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        p = p * (1.0 - self.lr * self.weight_decay)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        m = self.beta1 * m + (1.0 - self.beta1) * g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        v = self.beta2 * v + (1.0 - self.beta2) * g * g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if self.variant == "adamw":
            # standard AdamW: bias correction ON
            bc1 = 1.0 - torch.pow(self.beta1, s)
            bc2 = 1.0 - torch.pow(self.beta2, s)
            denom = torch.sqrt(v / bc2) + self.eps
            update = (m / bc1) / denom
        else:
            # transformer_adamw: bias correction OFF (the only difference)
            denom = torch.sqrt(v) + self.eps
            update = m / denom
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return (p - self.lr * update).to(params.dtype)
        # <<<END_IMPROVE>>>
