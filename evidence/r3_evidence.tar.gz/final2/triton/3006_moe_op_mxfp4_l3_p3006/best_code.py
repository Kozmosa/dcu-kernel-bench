import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _mxfp4_decode(nib):
    nib = nib.to(tl.int32)
    mag = nib & 7
    large_bits = ((126 + (mag >> 1)) << 23) | ((mag & 1) << 22)
    small_bits = tl.where(mag == 0, 0, 0x3f000000)
    mag_bits = tl.where(mag < 2, small_bits, large_bits).to(tl.uint32)
    sign_bits = ((nib & 8).to(tl.uint32) << 28)
    return (mag_bits | sign_bits).to(tl.float32, bitcast=True)


@triton.jit
def _moe_mxfp4_kernel(
    A, AS, B, BS, IDS, WEIGHTS, OUT,
    M, K, E, N, TOTAL,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid = tl.program_id(0)
    ntiles = tl.cdiv(N, BLOCK_N)
    slot = (pid // ntiles).to(tl.int64)
    n_start = (pid % ntiles) * BLOCK_N
    n = (n_start + tl.arange(0, BLOCK_N)).to(tl.int64)
    nmask = n < N

    expert = tl.load(IDS + slot).to(tl.int64)
    token = (slot // (TOTAL // M)).to(tl.int64)
    route = tl.load(WEIGHTS + slot).to(tl.float32)

    offs_k = tl.arange(0, BLOCK_K)
    acc = tl.zeros((BLOCK_N,), dtype=tl.float32)

    for k0 in tl.range(0, K, BLOCK_K):
        k = (k0 + offs_k).to(tl.int64)
        kmask = k < K
        byte_k = (k // 2).to(tl.int64)
        block_k = (k // 32).to(tl.int64)

        aq = tl.load(
            A + token * (K // 2) + byte_k,
            mask=kmask,
            other=0,
        ).to(tl.int32)
        anib = tl.where((k & 1) == 0, aq & 15, aq >> 4)
        aval = _mxfp4_decode(anib)
        ascale = tl.load(
            AS + token * (K // 32) + block_k,
            mask=kmask,
            other=0,
        ).to(tl.float32)
        aval = aval * tl.exp2(ascale - 127.0)

        bbase = expert * N * (K // 2) + n[:, None] * (K // 2)
        bq = tl.load(
            B + bbase + byte_k[None, :],
            mask=nmask[:, None] & kmask[None, :],
            other=0,
        ).to(tl.int32)
        bnib = tl.where(
            (k[None, :] & 1) == 0,
            bq & 15,
            bq >> 4,
        )
        bval = _mxfp4_decode(bnib)

        bsbase = expert * N * (K // 32) + n[:, None] * (K // 32)
        bscale = tl.load(
            BS + bsbase + block_k[None, :],
            mask=nmask[:, None] & kmask[None, :],
            other=0,
        ).to(tl.float32)
        bval = bval * tl.exp2(bscale - 127.0)

        prod = bval * aval[None, :]
        prod = tl.where(
            nmask[:, None] & kmask[None, :],
            prod,
            0.0,
        )
        acc += tl.sum(prod, axis=1)

    out = acc * route
    tl.store(
        OUT + slot * N + n,
        out.to(tl.bfloat16),
        mask=nmask,
    )
# <<<END_IMPROVE>>>

_E2M1_TABLE = torch.tensor(
    [0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0,
     -0.0, -0.5, -1.0, -1.5, -2.0, -3.0, -4.0, -6.0],
    dtype=torch.float32,
)

def _dequant_mxfp4(codes, scales):
    """mxfp4 dequantization: (..., K//2) uint8 code words plus (..., K//32) uint8
    e8m0 block scales -> (..., K) float32. In every byte the low 4 bits are the
    even-index element and the high 4 bits the odd-index element;
    x[..., k] = e2m1(nibble) * 2^(scales[..., k // 32] - 127)."""
    lo = codes & 0xF
    hi = codes >> 4
    nib = torch.stack((lo, hi), dim=-1).flatten(-2)      # (..., K)
    x = _E2M1_TABLE.to(codes.device)[nib.long()]
    scale = torch.exp2(scales.to(torch.float32) - 127.0)
    return x * scale.repeat_interleave(32, dim=-1)

class ModelNew(nn.Module):
    """MoE (Mixture of Experts) grouped GEMM: mxfp4 quantized activations x
    mxfp4 quantized expert weights.

    Routing is already done (topk_ids gives the experts selected for each
    token); this operator runs one GEMM per (token, selected expert) slot and
    multiplies by the routing weight (mul_routed_weight is always True):
      c[m, j, n] = topk_weights[m, j] * sum_k adeq[m, k] * bdeq[topk_ids[m, j], n, k]
    The sum runs along the K dimension, intermediate accumulation is float32 and
    the result is cast to bfloat16 for output.

    mxfp4 dequantization definition (the same for activation a and weight b):
      - every byte of the last dimension of the code word tensor holds 2 e2m1
        codes: the low 4 bits are the even-index element and the high 4 bits the
        odd-index element, i.e. the low/high nibble of code[..., i] correspond
        to elements 2i / 2i+1.
      - e2m1 nibble (4 bit) decoding: bit3 is the sign, the low 3 bits index the
        table {0: 0.0, 1: 0.5, 2: 1.0, 3: 1.5, 4: 2.0, 5: 3.0, 6: 4.0, 7: 6.0};
        a set sign bit negates the value (-0.0 takes part in the multiply-add as
        0).
      - e8m0 block scale: every 32 elements of the last dimension share 1 uint8
        scale byte s = scales[..., k // 32], decoded as 2^(s - 127).
      - dequantization:
        x[..., k] = e2m1(nibble(..., k)) * 2^(scales[..., k // 32] - 127).

    Input/output specification:
      a_q          (M, K//2)     uint8   activation code words (K is the logical
                                         feature dimension)
      a_scales     (M, K//32)    uint8   activation e8m0 block scales
      b_q          (E, N, K//2)  uint8   expert weight code words (E experts)
      b_scales     (E, N, K//32) uint8   expert weight e8m0 block scales
      topk_weights (M, top_k)    float16/bfloat16/float32  routing weights (>0)
      topk_ids     (M, top_k)    int64   selected expert ids, values in [0, E)
      out          (M, top_k, N) bfloat16
      Constraints: M >= 1, E >= 1, N >= 1, K % 32 == 0, 1 <= top_k <= E.
      Boundary behaviour: one expert may be selected by several tokens, and one
      token may select the same expert in several of its slots; every (m, j)
      slot is computed independently, with no reduction or weighted merge across
      experts and no dispatch-merge semantics (that belongs to a downstream
      operator).

    Implementation constraints (violations are scored as failures):
      - Core computation (nibble unpacking, e2m1/e8m0 decoding, the GEMM grouped
        by topk_ids, the routing weight multiply) must be done inside the
        submitted file; calling torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / F.linear / functional.linear /
        torch._scaled_mm is forbidden, as is using the built-in torch
        float4/mxfp4 representations and ready-made quantization conversion APIs
        (torch.float4_e2m1fn_x2, torch.quantize_per_tensor, etc.).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast to
        bfloat16.
      - The evaluator casts all inputs to fp32 before calling forward (uint8
        code words and scale bytes (0..255), int64 expert ids (small integers)
        are all exactly representable in fp32), so they must be restored
        losslessly at the entry point (.to(torch.uint8) / .to(torch.long)).

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: MoE grouped GEMM of mxfp4 activations x mxfp4 weights plus the
    routing weight multiply; the token-expert alignment scheduling metadata
    (sorted_token_ids / expert_ids / num_tokens_post_padded) is an
    implementation detail and not part of the input contract.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, a_q, a_scales, b_q, b_scales, topk_weights, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        a_q = a_q.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        a_scales = a_scales.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        b_q = b_q.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        b_scales = b_scales.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        topk_weights = topk_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        M, Kh = a_q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        K = Kh * 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        E, N, _ = b_q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        flat_ids = topk_ids.reshape(-1)
        flat_weights = topk_weights.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Quantized tensors are consumed directly by the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        flat_ids = topk_ids.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        flat_weights = topk_weights.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        fused_out = torch.empty(
            (M * top_k, N), dtype=torch.bfloat16, device=a_q.device
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        _moe_mxfp4_kernel[
            (M * top_k) * triton.cdiv(N, 64),
        ](
            a_q, a_scales, b_q, b_scales, flat_ids, flat_weights, fused_out,
            M, K, E, N, M * top_k,
            BLOCK_N=64,
            BLOCK_K=128,
            num_warps=4,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # Routing weights are applied inside the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return fused_out.reshape(M, top_k, N)
        # <<<END_IMPROVE>>>
