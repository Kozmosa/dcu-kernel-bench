import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _dts_kernel(
    x_ptr, out_ptr,
    n_elements, k, h, w, c,
    BS: tl.constexpr,
    MODE: tl.constexpr,
    TILE: tl.constexpr,
):
    pid = tl.program_id(0)
    lane = pid * TILE + tl.arange(0, TILE)
    mask = lane < n_elements

    hw_out = h * BS * w * BS
    cc = lane // hw_out
    rem = lane - cc * hw_out
    ho = rem // (w * BS)
    wo = rem - ho * (w * BS)

    rr = ho % BS
    dd = wo % BS
    hi = ho // BS
    wi = wo // BS

    if MODE == 0:
        src_c = cc * BS * BS + rr * BS + dd
    else:
        src_c = (rr * BS + dd) * c + cc

    src = ((lane // hw_out) * 0 + (lane // (c * hw_out)) * k * h * w
           + src_c * h * w + hi * w + wi)
    vals = tl.load(x_ptr + src, mask=mask, other=0.0)
    vals = vals.to(tl.float32)
    tl.store(out_ptr + lane, vals, mask=mask)


@triton.jit
def _fused_conv_dts_kernel(
    x_ptr, weight_ptr, bias_ptr, out_ptr,
    n_elements, cin, k, h, w, c,
    BS: tl.constexpr,
    MODE: tl.constexpr,
    BC: tl.constexpr,
    TILE: tl.constexpr,
):
    pid = tl.program_id(0)
    lane = pid * TILE + tl.arange(0, TILE)
    out_mask = lane < n_elements

    hw_out = h * BS * w * BS
    batch = lane // (c * hw_out)
    rem0 = lane - batch * c * hw_out
    out_c = rem0 // hw_out
    rem1 = rem0 - out_c * hw_out
    ho = rem1 // (w * BS)
    wo = rem1 - ho * (w * BS)

    rr = ho % BS
    dd = wo % BS
    oh = ho // BS
    ow = wo // BS

    if MODE == 0:
        out_k = out_c * BS * BS + rr * BS + dd
    else:
        out_k = (rr * BS + dd) * c + out_c

    ci = tl.arange(0, BC)
    acc = tl.zeros((TILE, BC), dtype=tl.float32)

    for ky in tl.static_range(0, 3):
        for kx in tl.static_range(0, 3):
            ih = oh + ky - 1
            iw = ow + kx - 1
            spatial_mask = (ih >= 0) & (ih < h) & (iw >= 0) & (iw < w)
            x_offset = (
                batch[:, None] * (cin * h * w)
                + ci[None, :] * (h * w)
                + ih[:, None] * w
                + iw[:, None]
            )
            w_offset = (
                out_k[:, None] * (cin * 9)
                + ci[None, :] * 9
                + ky * 3 + kx
            )
            valid = (
                out_mask[:, None]
                & (ci[None, :] < cin)
                & spatial_mask[:, None]
            )
            xv = tl.load(x_ptr + x_offset, mask=valid, other=0.0)
            wv = tl.load(weight_ptr + w_offset, mask=valid, other=0.0)
            acc += xv.to(tl.float32) * wv.to(tl.float32)

    b = tl.load(bias_ptr + out_k, mask=out_mask, other=0.0)
    result = tl.sum(acc, axis=1) + b.to(tl.float32)
    tl.store(out_ptr + lane, result, mask=out_mask)


def _launch_dts(x, block_size, mode):
    n, k, h, w = x.shape
    bs2 = block_size * block_size
    c = k // bs2
    out = torch.empty((n, c, h * block_size, w * block_size),
                      device=x.device, dtype=x.dtype)
    total = out.numel()
    tile = 128
    mode_id = 0 if mode == "CRD" else 1
    grid = (triton.cdiv(total, tile),)
    _dts_kernel[grid](
        x, out, total, k, h, w, c,
        BS=block_size, MODE=mode_id, TILE=tile,
        num_warps=4,
    )
    return out


def _launch_fused(x, weight, bias, block_size, mode):
    n, cin, h, w = x.shape
    k = weight.shape[0]
    bs2 = block_size * block_size
    c = k // bs2
    out = torch.empty((n, c, h * block_size, w * block_size),
                      device=x.device, dtype=x.dtype)

    bc = 1
    while bc < cin:
        bc *= 2
    total = out.numel()
    tile = 128
    mode_id = 0 if mode == "CRD" else 1
    grid = (triton.cdiv(total, tile),)
    _fused_conv_dts_kernel[grid](
        x, weight, bias, out,
        total, cin, k, h, w, c,
        BS=block_size, MODE=mode_id, BC=bc, TILE=tile,
        num_warps=4,
    )
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Conv+Bias+DepthToSpace fusion (conv_bias_dts) and pure DepthToSpace
    pixel rearrangement (dts) forward family.

    DepthToSpace (D2S) rearranges the channel dimension of an (N, K, H, W)
    feature map into the spatial dimensions: K must be divisible by
    block_size^2; writing C = K // block_size^2, the output is
    (N, C, H*bs, W*bs) (bs = block_size). The rearrangement mode is selected
    between two by the __init__ parameter mode, defined in terms of a
    six-dimensional view + transpose + reshape of v = (N, K, H, W):
        "CRD": v.reshape(N, C, bs, bs, H, W).permute(0, 1, 4, 2, 5, 3)
                .reshape(N, C, H*bs, W*bs)
                (bit-for-bit equivalent to
                torch.nn.functional.pixel_shuffle(v, bs) -- that ATen primitive
                is on the forbidden list; the equivalence is only noted here and
                it must not be called directly)
        "DCR": v.reshape(N, bs, bs, C, H, W).permute(0, 3, 4, 1, 5, 2)
                .reshape(N, C, H*bs, W*bs)
    Both modes produce the same output shape; only the channel-to-spatial-block
    mapping differs. Element-wise formula:
        out[b, c, h*bs + r, w*bs + d] = v[b, idx(c, r, d), h, w]
        CRD: idx = c*bs^2 + r*bs + d; DCR: idx = (r*bs + d)*C + c
        (c in [0, C), r/d in [0, bs), h in [0, H), w in [0, W))

    The fused path is selected between two by the __init__ parameter variant:
        "conv_bias_dts": for x (N, C_in, H, W) and the kernel weight
            (K, C_in, 3, 3), run the 2D cross-correlation forward pass (the
            deep-learning-library conv_fprop convention, not the kernel-flipped
            mathematical convolution), add the per-channel bias bias
            (1, K, 1, 1) (broadcast along the batch and spatial dimensions),
            then apply the D2S above to the convolution result. The convolution
            hyper-parameters are fixed: stride=(1, 1), symmetric zero
            padding=(1, 1) (1 added on each of the top/bottom/left/right sides;
            the padding value is always zero), dilation=(1, 1), so the
            convolution output keeps the spatial size (H, W) and the final
            output is (N, K//bs^2, H*bs, W*bs). forward(x, weight, bias) uses all
            three parameters.
        "dts": pure data rearrangement without convolution (super-resolution /
            pixel-rearrangement scenario): x itself is the (N, K, H, W) feature
            map to rearrange, forward(x) is called with a single parameter, and
            weight/bias are not passed (the optional parameters default to None;
            even if they are passed they must not affect the output); the
            rearrangement is pure index movement and bit-for-bit lossless.
    The convolution dot-product accumulation and the bias addition are computed
    in float32 intermediate precision throughout (the dts branch likewise
    promotes to float32 losslessly before the rearrangement), and the output is
    cast back to the dtype of x exactly once.

    Input/output specification:
        x      float16 / bfloat16 / float32 4D contiguous;
               (N, C_in, H, W) with C_in >= 1 for
               variant="conv_bias_dts", (N, K, H, W) with K % bs^2 == 0 for
               variant="dts"
        weight same dtype as x (K, C_in, 3, 3), contiguous (conv_bias_dts only)
        bias   same dtype as x (1, K, 1, 1), contiguous (conv_bias_dts only)
        out    a single tensor, same dtype as x (N, K//bs^2, H*bs, W*bs) (both
               the convolution and D2S are inherently single-output, so there
               are no multi-output packing segments)
        N/K/H/W >= 1 (non-powers-of-two, primes and boundary values are
        allowed, including N=1 and H=W=1); K % block_size^2 == 0; block_size in
        {2, 3, 4}; mode in {"CRD", "DCR"};
        inputs are ordinary randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before the call (fp16/bf16 -> fp32 is lossless; the
        output dtype of this task always matches the dtype of the passed x).

    Implementation constraints (violations are scored as failures):
        - The core computation (the padding-aware index/mask expansion and the
          dot-product accumulation, the bias addition, the six-dimensional
          rearrangement index mapping) must all be done and fused with a HIP
          kernel inside the submitted file; it is forbidden to replace it with
          any form of library convolution, ATen GEMM
          (matmul/mm/bmm/addmm/baddbmm/einsum/tensordot/unfold/fold/linear
          etc.), pixel_shuffle-family primitives (including a pixel_unshuffle
          round trip), or one-step equivalent routes such as a conv3d depth-axis
          unsqueeze or a conv_transpose2d kernel-flip rewrite.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The convolution dot-product accumulation and the bias addition are
          computed in float32 and the output is cast back to the input dtype
          exactly once (do not accumulate in fp16/bf16 low precision, and do not
          make repeated round-trip casts); padding must be handled inside the
          kernel with boundary masks/indices -- do not materialize a padded copy
          on the host side in place of in-kernel handling.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.nn.Conv2d / torch.nn.functional.conv2d / F.conv2d /
    torch.conv2d / aten.conv2d / aten.convolution /
    torch.nn.functional.conv3d / torch.conv3d / torch.nn.Conv3d /
    torch.nn.functional.conv_transpose2d / torch.conv_transpose2d /
    torch.nn.ConvTranspose2d /
    torch.nn.functional.unfold / torch.nn.Unfold / .unfold( /
    torch.nn.functional.fold / torch.nn.Fold / .fold( /
    torch.nn.functional.pixel_shuffle / torch.pixel_shuffle / pixel_shuffle /
    torch.nn.PixelShuffle / PixelShuffle /
    torch.nn.functional.pixel_unshuffle / torch.pixel_unshuffle /
    pixel_unshuffle / torch.nn.PixelUnshuffle / PixelUnshuffle /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear /
    miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)
    def __init__(self, variant: str = "conv_bias_dts", mode: str = "CRD", block_size: int = 2):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("conv_bias_dts", "dts"), \
            "variant must be either conv_bias_dts or dts"
        assert mode in ("CRD", "DCR"), "mode must be either CRD or DCR"
        assert block_size in (2, 3, 4), "block_size must be 2 / 3 / 4"
        self.variant = variant
        self.mode = mode
        self.block_size = block_size
        # <<<END_IMPROVE>>>

    def forward(self, x, weight=None, bias=None):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        if self.variant == "conv_bias_dts":
            return _launch_fused(
                x, weight.contiguous(), bias.contiguous(),
                self.block_size, self.mode
            )
        else:
            return _launch_dts(x, self.block_size, self.mode)
        # <<<END_IMPROVE>>>

    def _depth_to_space(self, v):
        """Six-dimensional view + transpose + reshape: a pure index
        rearrangement (no numeric operations) matching mode/block_size one to
        one; the per-dimension permutation corresponds exactly to the fused
        graph's first reshape -> transpose -> second reshape."""
        bs = self.block_size
        n, k, h, w = v.shape
        c = k // (bs * bs)
        if self.mode == "CRD":
            t = v.reshape(n, c, bs, bs, h, w).permute(0, 1, 4, 2, 5, 3)
        else:   # DCR
            t = v.reshape(n, bs, bs, c, h, w).permute(0, 3, 4, 1, 5, 2)
        return t.reshape(n, c, h * bs, w * bs)
