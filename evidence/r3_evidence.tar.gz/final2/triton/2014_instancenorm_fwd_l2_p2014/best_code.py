import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _instancenorm_small_kernel(
    x_ptr, scale_ptr, bias_ptr, out_ptr,
    hw, channels, eps,
    BLOCK: tl.constexpr,
):
    pid = tl.program_id(0)
    c = pid % channels
    offsets = tl.arange(0, BLOCK)
    mask = offsets < hw

    x = tl.load(
        x_ptr + pid * hw + offsets,
        mask=mask,
        other=0.0,
    ).to(tl.float32)

    mean = tl.sum(x, axis=0) / hw
    centered = tl.where(mask, x - mean, 0.0)
    var = tl.sum(centered * centered, axis=0) / hw
    inv_std = tl.rsqrt(var + eps)

    scale = tl.load(scale_ptr + c).to(tl.float32)
    bias = tl.load(bias_ptr + c).to(tl.float32)
    y = (x - mean) * inv_std * scale + bias

    tl.store(out_ptr + pid * hw + offsets, y, mask=mask)


@triton.jit
def _instancenorm_tile_moments_kernel(
    x_ptr, mean_ptr, m2_ptr,
    hw, num_tiles,
    BLOCK: tl.constexpr,
):
    pid_plane = tl.program_id(0)
    pid_tile = tl.program_id(1)

    offsets = pid_tile * BLOCK + tl.arange(0, BLOCK)
    mask = offsets < hw

    x = tl.load(
        x_ptr + pid_plane * hw + offsets,
        mask=mask,
        other=0.0,
    ).to(tl.float32)

    count = tl.minimum(BLOCK, hw - pid_tile * BLOCK)
    count = tl.maximum(count, 1)
    local_mean = tl.sum(x, axis=0) / count
    centered = tl.where(mask, x - local_mean, 0.0)
    local_m2 = tl.sum(centered * centered, axis=0)

    tl.store(mean_ptr + pid_plane * num_tiles + pid_tile, local_mean)
    tl.store(m2_ptr + pid_plane * num_tiles + pid_tile, local_m2)


@triton.jit
def _instancenorm_merge_kernel(
    local_mean_ptr, local_m2_ptr,
    mean_ptr, inv_std_ptr,
    hw, num_tiles, eps,
):
    pid = tl.program_id(0)
    mean_acc = tl.zeros((), dtype=tl.float32)

    for start in tl.range(0, num_tiles, 1024):
        tile_ids = start + tl.arange(0, 1024)
        tile_mask = tile_ids < num_tiles
        tile_start = tile_ids * 1024
        counts = tl.minimum(1024, hw - tile_start)
        counts = tl.where(tile_mask, counts, 0)
        counts_f = counts.to(tl.float32)

        local_means = tl.load(
            local_mean_ptr + pid * num_tiles + tile_ids,
            mask=tile_mask,
            other=0.0,
        )
        mean_acc += tl.sum(local_means * counts_f, axis=0)

    mean = mean_acc / hw.to(tl.float32)
    tl.store(mean_ptr + pid, mean)

    m2_acc = tl.zeros((), dtype=tl.float32)
    for start in tl.range(0, num_tiles, 1024):
        tile_ids = start + tl.arange(0, 1024)
        tile_mask = tile_ids < num_tiles
        tile_start = tile_ids * 1024
        counts = tl.minimum(1024, hw - tile_start)
        counts = tl.where(tile_mask, counts, 0)
        counts_f = counts.to(tl.float32)

        local_means = tl.load(
            local_mean_ptr + pid * num_tiles + tile_ids,
            mask=tile_mask,
            other=0.0,
        )
        local_m2 = tl.load(
            local_m2_ptr + pid * num_tiles + tile_ids,
            mask=tile_mask,
            other=0.0,
        )
        delta = local_means - mean
        m2_acc += tl.sum(local_m2 + counts_f * delta * delta, axis=0)

    var = m2_acc / hw.to(tl.float32)
    tl.store(inv_std_ptr + pid, tl.rsqrt(var + eps))


@triton.jit
def _instancenorm_large_output_kernel(
    x_ptr, mean_ptr, inv_std_ptr, scale_ptr, bias_ptr, out_ptr,
    hw, channels,
    BLOCK: tl.constexpr,
):
    pid_plane = tl.program_id(0)
    pid_tile = tl.program_id(1)
    c = pid_plane % channels

    offsets = pid_tile * BLOCK + tl.arange(0, BLOCK)
    mask = offsets < hw

    x = tl.load(
        x_ptr + pid_plane * hw + offsets,
        mask=mask,
        other=0.0,
    ).to(tl.float32)

    mean = tl.load(mean_ptr + pid_plane)
    inv_std = tl.load(inv_std_ptr + pid_plane)
    scale = tl.load(scale_ptr + c).to(tl.float32)
    bias = tl.load(bias_ptr + c).to(tl.float32)

    y = (x - mean) * inv_std * scale + bias
    tl.store(out_ptr + pid_plane * hw + offsets, y, mask=mask)


def _instancenorm_fwd(x, scale, bias, eps):
    n, c, h, w = x.shape
    hw = h * w
    planes = n * c
    out = torch.empty_like(x)

    if hw <= 4096:
        block = 1 << (hw - 1).bit_length()
        num_warps = 2 if block <= 128 else 4
        _instancenorm_small_kernel[(planes,)](
            x,
            scale,
            bias,
            out,
            hw,
            c,
            eps,
            BLOCK=block,
            num_warps=num_warps,
        )
        return out

    block = 1024
    num_tiles = (hw + block - 1) // block
    local_mean = torch.empty(
        (planes, num_tiles),
        device=x.device,
        dtype=torch.float32,
    )
    local_m2 = torch.empty_like(local_mean)
    mean = torch.empty(
        (planes,),
        device=x.device,
        dtype=torch.float32,
    )
    inv_std = torch.empty_like(mean)

    _instancenorm_tile_moments_kernel[(planes, num_tiles)](
        x,
        local_mean,
        local_m2,
        hw,
        num_tiles,
        BLOCK=block,
        num_warps=4,
    )
    _instancenorm_merge_kernel[(planes,)](
        local_mean,
        local_m2,
        mean,
        inv_std,
        hw,
        num_tiles,
        eps,
        num_warps=4,
    )
    _instancenorm_large_output_kernel[(planes, num_tiles)](
        x,
        mean,
        inv_std,
        scale,
        bias,
        out,
        hw,
        c,
        BLOCK=block,
        num_warps=4,
    )
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    InstanceNorm forward pass: per-(N,C) spatial-statistics normalization plus
    per-channel affine (single variant).

    The input x (N, C, H, W) is NCHW contiguous; scale / bias are the (1, C, 1, 1)
    per-channel affine parameters, broadcast along the channel dimension; eps
    defaults to 1e-5. Statistics are taken over the spatial dimensions (H, W) for
    every (n, c) plane (HW = H*W elements per plane), in float32:
        mean_nc    = sum_{h,w} x[n,c,h,w] / HW                  (biased mean)
        var_nc     = sum_{h,w} (x[n,c,h,w] - mean_nc)^2 / HW    (biased variance)
        inv_std_nc = 1 / sqrt(var_nc + eps)
        y[n,c,h,w] = scale[c] * (x[n,c,h,w] - mean_nc) * inv_std_nc + bias[c]
    Instance norm has no train / inference semantic difference: the normalization
    statistics always come from the input itself. The convention is biased (divide
    by HW rather than HW-1), and eps sits inside the rsqrt (its only purpose is the
    division-by-zero guard; it takes part in no unbiased correction).

    Boundary behaviour: when HW == 1 (a single spatial element) var = 0 and
    x - mean = 0, so inv_std = 1/sqrt(eps) and y = bias (eps guarantees no division
    by zero); N/C/H/W are arbitrary (including 1, non-powers-of-two, and unaligned
    sizes); a large HW requires a blocked reduction, and out-of-range elements at
    the row tail must not participate in the statistics.

    Input/output specification:
        x     float32 / float16 / bfloat16 (N, C, H, W), contiguous,
              N/C/H/W >= 1
        scale same dtype as x, (1, C, 1, 1), contiguous
        bias  same dtype as x, (1, C, 1, 1), contiguous
        out   a single tensor, y itself: (N, C, H, W) with the same dtype as x
              (statistics and affine run in float32 intermediates, then cast back
              to the x dtype); no packing
        The inputs are ordinary randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before calling forward (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-(N,C) spatial reduction statistics, rsqrt,
          and the per-channel affine) must be completed with a Triton kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt and affine all run in float32 intermediates; y is
          cast back to the x dtype.
        - forward returns the single tensor `out` (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden list: torch.nn.InstanceNorm1d / torch.nn.InstanceNorm2d /
    torch.nn.InstanceNorm3d / torch.nn.functional.instance_norm /
    F.instance_norm / torch.instance_norm / native_instance_norm /
    torch.nn.GroupNorm / nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm /
    torch.nn.BatchNorm1d / torch.nn.BatchNorm2d / torch.nn.BatchNorm3d /
    torch.nn.SyncBatchNorm / torch.nn.functional.batch_norm /
    F.batch_norm / torch.batch_norm / torch.native_batch_norm /
    miopen / hipdnn.
    (GroupNorm with num_groups=C and BatchNorm via a (1, N*C, H, W) reshape both
    complete this task's core computation in a single step, so they are forbidden
    alongside the instance_norm family.)
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert eps > 0, "eps must be positive"
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _instancenorm_fwd(x, scale, bias, self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return out
        # <<<END_IMPROVE>>>
