import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _routed_grouped_gemm(
    A, B, W, Sorted, Experts, Padded, C,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    TOP_K: tl.constexpr, EM: tl.constexpr,
    SA0: tl.constexpr, SA1: tl.constexpr,
    SB0: tl.constexpr, SB1: tl.constexpr, SB2: tl.constexpr,
    SW0: tl.constexpr, SW1: tl.constexpr,
    SS: tl.constexpr, SE: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    padded = tl.load(Padded).to(tl.int32)
    if pid_m * BM < padded:
        expert = tl.load(Experts + ((pid_m * BM) // 64) * SE).to(tl.int64)
        positions = pid_m * BM + tl.arange(0, BM)
        slots = tl.load(
            Sorted + positions * SS,
            mask=(positions < EM) & (positions < padded),
            other=M * TOP_K,
        ).to(tl.int64)
        valid = (slots >= 0) & (slots < M * TOP_K)
        rows = slots // TOP_K
        cols = pid_n * BN + tl.arange(0, BN)
        rk = tl.arange(0, BK)
        acc = tl.zeros((BM, BN), dtype=tl.float32)
        for block in range(tl.cdiv(K, BK)):
            ks = block * BK + rk
            av = tl.load(
                A + rows[:, None] * SA0 + ks[None, :] * SA1,
                mask=valid[:, None] & (ks[None, :] < K),
                other=0,
            )
            bv = tl.load(
                B + expert * SB0 + cols[None, :] * SB1 + ks[:, None] * SB2,
                mask=(ks[:, None] < K) & (cols[None, :] < N),
                other=0,
            )
            acc = tl.dot(av, bv, acc)
        weights = tl.load(
            W + rows * SW0 + (slots % TOP_K) * SW1,
            mask=valid,
            other=0.0,
        ).to(tl.float32)
        result = acc * weights[:, None]
        tl.store(
            C + slots[:, None] * N + cols[None, :],
            result,
            mask=valid[:, None] & (cols[None, :] < N),
        )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """MoE (Mixture-of-Experts) routed grouped GEMM: non-quantized weights, with
    routing weighting.

    Each token's feature vector A[m] (K dimensions) is dispatched by the routing
    table topk_ids to top_k of the num_experts experts; expert e owns the weight
    matrix B[e] (N x K). For each token m and its j-th routing slot (write
    e = topk_ids[m, j]), the output is defined as

        C[m, j, n] = topk_weights[m, j] * sum_k A[m, k] * B[e, n, k]

    i.e. grouped GEMM followed by a per-slot multiply by the routing weight;
    intermediate accumulation is float32 and the output is cast back to the
    input dtype. Every (m, j) slot hits a legal expert inside [0, num_experts),
    so no output is undefined.

    The inputs also carry the block-aligned layout of grouped GEMM (produced by
    the upstream router; fetching data through it is exactly equivalent to
    computing the formula above directly):
      - sorted_token_ids: int32, length EM = M*top_k + num_experts*(block_m-1),
        with block_m always 64 in this task. Number the slots flat as
        p = m*top_k + j, regroup them by ascending expert id, and pad each group
        up to a multiple of block_m; the intra-group padding positions and the
        array tail hold the sentinel value M*top_k (that is num_valid_tokens;
        offs_token >= it means padding and produces no output).
      - expert_ids: int32, length M*top_k + num_experts; the expert id owning
        block t (covering sorted_token_ids[t*block_m : (t+1)*block_m]), values
        in [0, num_experts), no -1; positions past the number of blocks implied
        by num_tokens_post_padded are sentinel fill and must not be read.
      - num_tokens_post_padded: int32 scalar (length 1), the valid length of
        sorted_token_ids (intra-block padding included), always a multiple of
        block_m.
    The kernel's BLOCK_SIZE_M must divide block_m (that is, be a factor of 64)
    so that every program block sees a single expert.

    Input/output specification:
        A                       (M, K)             float16/bfloat16
        B                       (E, N, K)          same as A (E = num_experts)
        topk_weights            (M, top_k)         float32
        topk_ids                (M, top_k)         int32
        sorted_token_ids        (EM,)              int32
        expert_ids              (M*top_k + E,)     int32
        num_tokens_post_padded  (1,)               int32
        returns C               (M, top_k, N)      dtype same as A

    Implementation constraints (violations are scored as failures):
        - Core computation (layout-driven data fetch + grouped GEMM + weighted
          routing write-out) must be done in a Triton kernel inside the
          submitted file; calling torch.matmul / torch.mm / torch.bmm /
          torch.baddbmm / torch.addmm / torch.einsum /
          torch.nn.functional.linear or any precompiled operator library for
          any matrix multiply is forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate accumulation; the output is cast back to
          the input dtype.
        - Sentinel padding slots must not contaminate any valid output.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: non-quantized fp16/bf16 weights and activations (no w8a8 / int4 /
    mxfp4 quantization), no fused activation (SiLU/GELU etc.), no bias,
    top_k <= 8, num_experts <= 256.
    """
    def __init__(self, num_experts: int, top_k: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = num_experts
        self.top_k = top_k
        # <<<END_IMPROVE>>>

    def forward(self, A, B, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        # <<<IMPROVE:forward_stmt_1>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = A.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        E, N, _ = B.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty((M, top_k, N), device=A.device, dtype=A.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        if M > 0 and N > 0 and top_k > 0:
            reduction_tile = 64 if K >= 64 else 32
            _routed_grouped_gemm[
                (triton.cdiv(sorted_token_ids.numel(), 64), triton.cdiv(N, 64))
            ](
                A, B, topk_weights, sorted_token_ids, expert_ids,
                num_tokens_post_padded, out,
                M, N, K, top_k, sorted_token_ids.numel(),
                A.stride(0), A.stride(1),
                B.stride(0), B.stride(1), B.stride(2),
                topk_weights.stride(0), topk_weights.stride(1),
                sorted_token_ids.stride(0), expert_ids.stride(0),
                BM=64, BN=64, BK=reduction_tile,
                num_warps=4, num_stages=2,
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return out
        # <<<END_IMPROVE>>>
