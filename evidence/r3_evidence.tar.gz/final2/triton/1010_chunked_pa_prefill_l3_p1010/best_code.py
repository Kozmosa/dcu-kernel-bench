import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _paged_attention(Q, K, V, KC, VC, BT, QS, SL, O,
                     SCALE: tl.constexpr, NS: tl.constexpr,
                     D: tl.constexpr, BS: tl.constexpr, X: tl.constexpr,
                     GROUP: tl.constexpr, DD: tl.constexpr,
                     Q0: tl.constexpr, Q1: tl.constexpr, Q2: tl.constexpr,
                     K0: tl.constexpr, K1: tl.constexpr, K2: tl.constexpr,
                     V0: tl.constexpr, V1: tl.constexpr, V2: tl.constexpr,
                     C0: tl.constexpr, C1: tl.constexpr, C2: tl.constexpr,
                     C3: tl.constexpr, C4: tl.constexpr,
                     W0: tl.constexpr, W1: tl.constexpr, W2: tl.constexpr, W3: tl.constexpr,
                     B0: tl.constexpr, B1: tl.constexpr,
                     S0: tl.constexpr, L0: tl.constexpr,
                     O0: tl.constexpr, O1: tl.constexpr, O2: tl.constexpr):
    t = tl.program_id(0).to(tl.int64)
    h = tl.program_id(1).to(tl.int64)

    lo = 0
    hi = NS
    while lo < hi:
        mid = (lo + hi) // 2
        start = tl.load(QS + mid * S0)
        if start <= t:
            lo = mid + 1
        else:
            hi = mid
    b = lo - 1

    start = tl.load(QS + b * S0).to(tl.int64)
    end = tl.load(QS + (b + 1) * S0)
    length = tl.load(SL + b * L0)
    ctx = length - (end - start)
    pos = ctx + t - start
    hk = h // GROUP

    d = tl.arange(0, DD)
    q = tl.load(
        Q + t * Q0 + h * Q1 + d * Q2,
        d < D,
        0
    ).to(tl.float32) * SCALE

    m = tl.full((), -float("inf"), tl.float32)
    s = tl.full((), 0.0, tl.float32)
    a = tl.full((DD,), 0.0, tl.float32)

    for base in range(0, pos + 1, 64):
        l = base + tl.arange(0, 64)
        prefix = (l < ctx) & (l <= pos)
        fresh = (l >= ctx) & (l <= pos)

        physical = tl.load(
            BT + b * B0 + (l // BS) * B1,
            prefix,
            0
        ).to(tl.int64)

        kc = tl.load(
            KC
            + physical[:, None] * C0
            + hk * C1
            + (d[None, :] // X) * C2
            + (l[:, None] % BS) * C3
            + (d[None, :] % X) * C4,
            prefix[:, None] & (d[None, :] < D),
            0
        ).to(tl.float32)

        n = start + l - ctx
        kn = tl.load(
            K + n[:, None] * K0 + hk * K1 + d[None, :] * K2,
            fresh[:, None] & (d[None, :] < D),
            0
        ).to(tl.float32)

        logits = tl.sum((kc + kn) * q[None, :], axis=1)
        logits = tl.where(l <= pos, logits, -float("inf"))

        nm = tl.maximum(m, tl.max(logits, axis=0))
        alpha = tl.exp(m - nm)
        p = tl.exp(logits - nm)

        vc = tl.load(
            VC
            + physical[:, None] * W0
            + hk * W1
            + d[None, :] * W2
            + (l[:, None] % BS) * W3,
            prefix[:, None] & (d[None, :] < D),
            0
        ).to(tl.float32)

        vn = tl.load(
            V + n[:, None] * V0 + hk * V1 + d[None, :] * V2,
            fresh[:, None] & (d[None, :] < D),
            0
        ).to(tl.float32)

        a = a * alpha + tl.sum(p[:, None] * (vc + vn), axis=0)
        s = s * alpha + tl.sum(p, axis=0)
        m = nm

    tl.store(O + t * O0 + h * O1 + d * O2, a / s, d < D)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Chunked prefill / decode mixed-batch attention over a paged KV cache (MHA and GQA, causal mask).

    The batch holds num_seqs sequences running in parallel; sequence b computes
    query_len[b] = query_start_loc[b+1] - query_start_loc[b] new query tokens
    this round, and the per-sequence slices are packed back to back along the
    token dimension according to query_start_loc (no padding). Sequence b
    currently has total length seq_lens[b], of which the first
    ctx_len[b] = seq_lens[b] - query_len[b] tokens are already-admitted prefix
    K/V that live only in the paged KV cache; the K/V of this round's new tokens
    are given separately and explicitly as key / value (consistent with the
    corresponding cache slots). A sequence with query_len[b] == 1 is decode,
    > 1 is chunked prefill, and the two kinds may be mixed in the same batch.

    Paged layout: the physical block pool has num_blocks blocks, each holding
    block_size token slots; block_tables[b] is that sequence's "logical block ->
    physical block number" table, covering the whole seq_lens[b] (including this
    round's new tokens). K uses a channel-packed layout: K[tok, h, d] lives at
    key_cache[pblk, h, d // x, tok % block_size, d % x] (x = 8, head_size is a
    multiple of 8); V is value_cache[pblk, h, d, tok % block_size]. Blocks of the
    pool that no block table references, and slots past a sequence's valid
    length, hold garbage data (magnitudes up to +/-10) and must not take part in
    the computation.

    For query head h of sequence b (its KV head is h // query_group_size, where
    query_group_size = num_heads / num_kv_heads) and its j-th new token (absolute
    position within the sequence pos = ctx_len[b] + j):

      logits[l] = scale * <query[pos, h, :], K[l]>,  l = 0 .. seq_lens[b]-1
      causal mask: logits at positions l > pos are set to -inf
      p[l] = exp(logits[l] - max_l logits) / sum_l' exp(logits[l'] - max_l logits)
      out[pos, h, :] = sum_l p[l] * V[l]

    The first ctx_len[b] K / V tokens come from the paged cache (indirectly
    addressed through the block table), the remaining query_len[b] come from
    key / value. softmax uses an online (numerically stable) implementation,
    intermediate accumulation is in float32, and the output is cast back to the
    input dtype.

    Input/output specification (forward parameter order):
      query           [num_tokens, num_heads, head_size]          fp16/bf16
      key             [num_tokens, num_kv_heads, head_size]       same as query
      value           [num_tokens, num_kv_heads, head_size]       same as query
      key_cache       [num_blocks, num_kv_heads, head_size//8, block_size, 8]  same as query
      value_cache     [num_blocks, num_kv_heads, head_size, block_size]        same as query
      block_tables    [num_seqs, max_blocks_per_seq]              int32
      query_start_loc [num_seqs+1] int32 (prefix sum of query_len, first element 0)
      seq_lens        [num_seqs] int32
      output out      [num_tokens, num_heads, head_size], dtype matches query.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / torch.matmul / torch.bmm / torch.einsum / torch.softmax is forbidden
        (the complete forbidden list is defined by the task configuration's
        forbidden field).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: chunked prefill/decode mixed batch, non-quantized KV, no ALiBi,
    no sliding window.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        query_start_loc = query_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens, num_heads, head_size = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        num_kv_heads = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        block_size = value_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        x = key_cache.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        group = num_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert num_heads == num_kv_heads * group, "num_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        if num_tokens:
            _paged_attention[(num_tokens, num_heads)](
                query, key, value, key_cache, value_cache,
                block_tables, query_start_loc, seq_lens, out,
                self.scale, seq_lens.shape[0], head_size, block_size, x,
                group, triton.next_power_of_2(head_size),
                *query.stride(), *key.stride(), *value.stride(),
                *key_cache.stride(), *value_cache.stride(),
                *block_tables.stride(), query_start_loc.stride(0),
                seq_lens.stride(0), *out.stride(),
                num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
