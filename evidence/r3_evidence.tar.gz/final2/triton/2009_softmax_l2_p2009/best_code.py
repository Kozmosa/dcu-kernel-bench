import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _row_softmax_kernel(x, y, M, N, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(0)
    base = pid.to(tl.int64) * N.to(tl.int64)
    lanes = tl.arange(0, BLOCK_SIZE)
    row_max = tl.full((), float("-inf"), tl.float32)
    row_sum = tl.full((), 0.0, tl.float32)

    for start in range(0, N, BLOCK_SIZE):
        offsets = start.to(tl.int64) + lanes
        valid = (offsets < N) & (pid < M)
        values = tl.load(x + base + offsets, mask=valid, other=float("-inf"))
        values = values.to(tl.float32)
        tile_max = tl.max(values, axis=0)
        new_max = tl.maximum(row_max, tile_max)
        tile_sum = tl.sum(tl.exp(values - new_max), axis=0)
        row_sum = row_sum * tl.exp(row_max - new_max) + tile_sum
        row_max = new_max

    for start in range(0, N, BLOCK_SIZE):
        offsets = start.to(tl.int64) + lanes
        valid = (offsets < N) & (pid < M)
        values = tl.load(x + base + offsets, mask=valid, other=float("-inf"))
        values = values.to(tl.float32)
        result = tl.exp(values - row_max) / row_sum
        tl.store(y + base + offsets, result, mask=valid)


@triton.jit
def _resident_row_softmax_kernel(
    x, y, N, BLOCK_SIZE: tl.constexpr
):
    pid = tl.program_id(0)
    base = pid.to(tl.int64) * N.to(tl.int64)
    columns = tl.arange(0, BLOCK_SIZE)
    valid = columns < N
    values = tl.load(
        x + base + columns.to(tl.int64),
        mask=valid,
        other=float("-inf"),
    ).to(tl.float32)
    row_max = tl.max(values, axis=0)
    exponentials = tl.exp(values - row_max)
    row_sum = tl.sum(tl.where(valid, exponentials, 0.0), axis=0)
    result = exponentials / row_sum
    tl.store(
        y + base + columns.to(tl.int64),
        result,
        mask=valid,
    )


@triton.jit
def _batched_short_row_softmax_kernel(
    x, y, M, N: tl.constexpr,
    BLOCK_ROWS: tl.constexpr, BLOCK_COLS: tl.constexpr,
):
    rows = tl.program_id(0).to(tl.int64) * BLOCK_ROWS + tl.arange(0, BLOCK_ROWS)
    columns = tl.arange(0, BLOCK_COLS)
    offsets = rows[:, None] * N + columns[None, :]
    valid = (rows[:, None] < M) & (columns[None, :] < N)
    values = tl.load(x + offsets, mask=valid, other=float("-inf")).to(tl.float32)
    row_max = tl.max(values, axis=1)
    row_max = tl.where(rows < M, row_max, 0.0)
    exponentials = tl.exp(values - row_max[:, None])
    exponentials = tl.where(valid, exponentials, 0.0)
    row_sum = tl.sum(exponentials, axis=1)
    row_sum = tl.where(rows < M, row_sum, 1.0)
    result = exponentials / row_sum[:, None]
    tl.store(y + offsets, result, mask=valid)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """2D row-wise softmax.

    For each row (the last dimension) of an (M, N) input, independently:
        m[i]     = max_j x[i, j]
        z[i, j]  = exp(x[i, j] - m[i])
        y[i, j]  = z[i, j] / sum_j z[i, j]
    Rows are completely independent, and after per-row normalization the elements
    of every row sum to 1. The reference implementation does max / exp / sum
    entirely in float32 and casts the output back to the input dtype.

    Boundary behaviour: N is any positive integer -- when N=1 the row's output is
    always 1; non-power-of-two N and very long rows (longer than a single block's
    capacity) must still give exact results, and out-of-range elements at the row
    tail must not participate in the max and sum reductions; the inputs are
    ordinary randn magnitude (no inf/NaN).

    Input/output specification:
        x   float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        y   same dtype as x, (M, N), the row-wise softmax result
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless); this operator has no integer tensor
        input, so nothing needs restoring.

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-row max reduction, the exp sum reduction,
          and the element-wise normalization) must be completed with a Triton
          kernel inside the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Intermediates (max / sum / exp) are computed in float32; the output is
          cast back to the input dtype.

    Forbidden list: aiter / torch.softmax / torch.nn.functional.softmax /
    torch.nn.Softmax / torch.log_softmax / torch.nn.functional.log_softmax /
    torch.nn.LogSoftmax / torch.special.softmax / torch.special.log_softmax.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        dt = x.dtype
        M, N = x.shape
        y = torch.empty_like(x)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        if N <= 256 and M >= 16:
            block_cols = triton.next_power_of_2(N)
            block_rows = min(16, max(4, 1024 // block_cols))
            _batched_short_row_softmax_kernel[(triton.cdiv(M, block_rows),)](
                x,
                y,
                M=M,
                N=N,
                BLOCK_ROWS=block_rows,
                BLOCK_COLS=block_cols,
                num_warps=4,
            )
        elif N <= 8192:
            block_size = triton.next_power_of_2(N)
            _resident_row_softmax_kernel[(M,)](
                x,
                y,
                N,
                BLOCK_SIZE=block_size,
                num_warps=4,
            )
        else:
            _row_softmax_kernel[(M,)](
                x, y, M, N, BLOCK_SIZE=1024, num_warps=4
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        return y.to(dt)
        # <<<END_IMPROVE>>>
