import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _spconv_dgrad_kernel(
    wf, yf, pairs, counts, out,
    n, c_in, c_out, kv,
    BLOCK_I: tl.constexpr,
    BLOCK_O: tl.constexpr,
):
    pid_pair = tl.program_id(0)
    pid_i = tl.program_id(1)

    k = pid_pair // n
    j = pid_pair - k * n
    count = tl.cast(tl.load(counts + k), tl.int32)
    valid = j < count

    pair_offset = tl.cast(k * n + j, tl.int32)
    second_offset = tl.cast(kv * n, tl.int32)
    in_idx = tl.cast(tl.load(pairs + pair_offset, mask=valid, other=0.0), tl.int32)
    out_idx = tl.cast(
        tl.load(pairs + second_offset + pair_offset, mask=valid, other=0.0),
        tl.int32,
    )

    i = pid_i * BLOCK_I + tl.arange(0, BLOCK_I)
    imask = i < c_in
    acc = tl.zeros((BLOCK_I,), dtype=tl.float32)

    for oo in tl.range(0, c_out, BLOCK_O):
        o = oo + tl.arange(0, BLOCK_O)
        omask = o < c_out

        y = tl.load(
            yf + out_idx * c_out + o,
            mask=valid & omask,
            other=0.0,
        )
        w = tl.load(
            wf + (o[:, None] * kv + k) * c_in + i[None, :],
            mask=valid & omask[:, None] & imask[None, :],
            other=0.0,
        )
        acc += tl.sum(y[:, None] * w, axis=0)

    tl.atomic_add(
        out + in_idx * c_in + i,
        acc,
        mask=valid & imask,
    )


@triton.jit
def _spconv_wgrad_kernel(
    xf, yf, pairs, counts, out,
    n, c_in, c_out, kv,
    BLOCK_I: tl.constexpr,
    BLOCK_O: tl.constexpr,
    BLOCK_P: tl.constexpr,
):
    pid_pair = tl.program_id(0)
    pid_o = tl.program_id(1)
    pid_i = tl.program_id(2)

    chunks_per_offset = tl.cdiv(n, BLOCK_P)
    k = pid_pair // chunks_per_offset
    start = (pid_pair % chunks_per_offset) * BLOCK_P
    count = tl.cast(tl.load(counts + k), tl.int32)

    o = pid_o * BLOCK_O + tl.arange(0, BLOCK_O)
    i = pid_i * BLOCK_I + tl.arange(0, BLOCK_I)
    omask = o < c_out
    imask = i < c_in
    acc = tl.zeros((BLOCK_O, BLOCK_I), dtype=tl.float32)

    if start < count:
        end = tl.minimum(start + BLOCK_P, count)
        for j in tl.range(start, end):
            pair_offset = tl.cast(k * n + j, tl.int32)
            second_offset = tl.cast(kv * n, tl.int32)
            in_idx = tl.cast(tl.load(pairs + pair_offset), tl.int32)
            out_idx = tl.cast(
                tl.load(pairs + second_offset + pair_offset), tl.int32
            )

            y = tl.load(
                yf + out_idx * c_out + o,
                mask=omask,
                other=0.0,
            ).to(tl.float32)
            x = tl.load(
                xf + in_idx * c_in + i,
                mask=imask,
                other=0.0,
            ).to(tl.float32)
            acc = acc + y[:, None] * x[None, :]

        offsets = (o[:, None] * kv + k) * c_in + i[None, :]
        tl.atomic_add(
            out + offsets,
            acc,
            mask=(start < count) & omask[:, None] & imask[None, :],
        )


# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Sparse convolution backward (gathered form spconv): dgrad (gradient with
    respect to the input features) and wgrad (gradient with respect to the
    weight buffer); it is the exact adjoint of the sparse convolution forward
    (gather-GEMM-scatter).

    Forward semantics (the sole authority for this task's convention; out is
    first initialized to all zeros, then accumulated by the formula below):
        for each kernel offset k in [0, kv):
            n_k = indice_num_per_loc[k]
            for each j in [0, n_k):
                in_idx  = indice_pairs[0, k, j]      # input row index in [0, n)
                out_idx = indice_pairs[1, k, j]      # output row index in [0, num_act_out)
                out[out_idx, :] += features[in_idx, :] @ W[:, :, k].T
    i.e. for each index pair, gather the input row and matrix-multiply it with
    the weight matrix of offset k ((n_k, c_in) @ (c_in, c_out)), then
    scatter-accumulate by the output row index into out.
    The mathematical weight W and the contiguous filters tensor F satisfy the
    layout mapping:
        W[o, i, k] = F.reshape(c_out, kv, c_in)[o, k, i]
    (equivalent to W = F.reshape(c_out, kv, c_in).permute(0, 2, 1), still shaped
    (c_out, c_in, kv)).

    Given the upstream gradient out_bp = dL/dy (shape (num_act_out, c_out)), the
    two directions are defined as the adjoint of that forward with respect to
    features / filters:
        dgrad: dx[in_idx, :] += out_bp[out_idx, :] @ W[:, :, k], output
               (n, c_in), i.e. dL/dfeatures;
        wgrad: dW_math[:, :, k] += out_bp[out_idx, :, None] *
               features[in_idx, None, :] (accumulated per index pair), output as
               the weight gradient dF (c_out, c_in, kv) interpreted with the same
               layout mapping as filters:
               dF.reshape(c_out, kv, c_in)[o, k, i] = dW_math[o, i, k],
               stored contiguously.
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns dx; here the values of features do not take part in the
                 output (shape convention only);
        "wgrad": returns dF; here the values of filters do not take part in the
                 output (shape convention only).
    forward(features, filters, out_bp, indice_pairs, indice_num_per_loc) has a
    fixed five-input signature; both directions are inherently single-tensor
    outputs (no concatenation packing).

    Boundary behaviour: kernel offsets with n_k = 0 are skipped entirely; when
    all n_k = 0 the output is all-zero; kv = 1 degenerates to a single offset;
    num_act_out and n are independent of each other (either may be the larger
    one). Index-pair table entries with j >= indice_num_per_loc[k] are padding
    garbage (they may hold any value, including duplicated valid row indices)
    and must be masked out according to indice_num_per_loc -- they must never be
    read into the computation. The same input/output row may be hit by any number
    of index pairs (duplicates are allowed within the same k), and all of them
    accumulate with +=.

    Input/output specification:
        features           float32 / float16 / bfloat16 (n, c_in), contiguous
        filters            same dtype as features (c_out, c_in, kv), contiguous
        out_bp             same dtype as features (num_act_out, c_out),
                           contiguous
        indice_pairs       int32 (2, kv, n), contiguous
        indice_num_per_loc int32 (kv,), contiguous
        out                a single tensor, same dtype as features: (n, c_in) for
                           dgrad, (c_out, c_in, kv) for wgrad
        Dimension domain: n, c_in, c_out, kv, num_act_out >= 1, non-powers-of-two
        allowed; indice_num_per_loc[k] in [0, n]; row indices <= 2^24. Input
        values are ordinary randn magnitude (no inf/NaN). The evaluator casts all
        input tensors to fp32 before the call (integer indices are exact up to
        2^24 and are recovered with int()/long()).

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a Triton kernel inside the
          submitted file: the scatter accumulation of dgrad (the out_bp rows
          transformed by W[:, :, k] and then scatter-accumulated by in_idx) or
          the per-index-pair outer-product correlation accumulation of wgrad;
          falling back to combinations of torch gather / matmul / scatter or to
          autograd is forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).
        - Numeric contract: accumulate in float32 throughout (fp16/bf16 inputs
          are first cast losslessly to fp32), then cast the result back to the
          dtype of features; padding table entries must not take part in the
          computation (including out-of-bounds reads).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.sparse / torch.sparse_coo_tensor /
    torch.sparse_csr_tensor / torch.sparse_csc_tensor / torch.sparse_mm /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear /
    index_add (including every spelling .index_add( / index_add_ /
    torch.index_add) / index_put / torch.index_put / scatter_add (including
    scatter_add_) / .scatter_( / torch.scatter / scatter_reduce /
    segment_reduce / torch.gather / index_select / torch.take / torch.sum /
    torch.ops.aten / torch.autograd / .backward( / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "dgrad"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, features, filters, out_bp, indice_pairs, indice_num_per_loc):
        # <<<IMPROVE:forward_stmt_1>>>
        dt = features.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        c_out, c_in, kv = filters.shape
        n = features.shape[0]
        num_act_out = out_bp.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        f32 = torch.float32
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        xf = features.to(f32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        wf0 = filters.to(f32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        yf = out_bp.to(f32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pairs = indice_pairs
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        counts = indice_num_per_loc
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        if self.variant == "dgrad":
            out = torch.zeros(
                (n, c_in), dtype=f32, device=features.device
            )
            grid = (
                kv * n,
                (c_in + 127) // 128,
            )
            _spconv_dgrad_kernel[grid](
                wf0, yf, pairs, counts, out,
                n, c_in, c_out, kv,
                BLOCK_I=128,
                BLOCK_O=32,
            )
        else:
            out = torch.zeros(
                (c_out, c_in, kv), dtype=f32, device=features.device
            )
            grid = (
                kv * ((n + 31) // 32),
                (c_out + 31) // 32,
                (c_in + 127) // 128,
            )
            _spconv_wgrad_kernel[grid](
                xf, yf, pairs, counts, out,
                n, c_in, c_out, kv,
                BLOCK_I=128,
                BLOCK_O=32,
                BLOCK_P=32,
                enable_fp_fusion=False,
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        if self.variant == "dgrad":
            return out.to(dt)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return out.to(dt)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        return out.to(dt)
        # <<<END_IMPROVE>>>
