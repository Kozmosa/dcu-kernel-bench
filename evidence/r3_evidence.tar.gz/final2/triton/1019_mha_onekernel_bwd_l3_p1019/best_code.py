import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _mha_backward_kernel(
    Q, K, V, O, LSE, DO, DQ, DK, DV,
    sq, sk, sv,
    so, sl, sg,
    sdq, sdk, sdv,
    M: tl.constexpr, N: tl.constexpr, D: tl.constexpr,
    GROUP: tl.constexpr, CAUSAL: tl.constexpr, SCALE: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BD: tl.constexpr,
):
    tile = tl.program_id(0)
    hk = tl.program_id(1)
    b = tl.program_id(2)
    d = tl.arange(0, BD)
    fd = d < D

    # Each program exclusively owns a [BN, BD] key/value gradient tile.
    if tile * BN < N:
        j = tile * BN + tl.arange(0, BN)
        kmask = (j[:, None] < N) & fd[None, :]
        kt = tl.load(
            K + b * sk[0] + j[:, None] * sk[1] + hk * sk[2] + d[None, :] * sk[3],
            kmask, other=0,
        ).to(tl.float32)
        vt = tl.load(
            V + b * sv[0] + j[:, None] * sv[1] + hk * sv[2] + d[None, :] * sv[3],
            kmask, other=0,
        ).to(tl.float32)
        ak = tl.zeros((BN, BD), tl.float32)
        av = tl.zeros((BN, BD), tl.float32)
        for gh in range(GROUP):
            h = hk * GROUP + gh
            for start in range(0, M, BM):
                i = start + tl.arange(0, BM)
                qm = (i[:, None] < M) & fd[None, :]
                qt = tl.load(
                    Q + b * sq[0] + i[:, None] * sq[1] + h * sq[2] + d[None, :] * sq[3],
                    qm, other=0,
                ).to(tl.float32)
                ot = tl.load(
                    O + b * so[0] + i[:, None] * so[1] + h * so[2] + d[None, :] * so[3],
                    qm, other=0,
                ).to(tl.float32)
                gt = tl.load(
                    DO + b * sg[0] + i[:, None] * sg[1] + h * sg[2] + d[None, :] * sg[3],
                    qm, other=0,
                ).to(tl.float32)
                ls = tl.load(LSE + b * sl[0] + h * sl[1] + i * sl[2], i < M, other=0)
                delta = tl.sum(ot * gt, axis=1)
                # [BM, BD] @ [BD, BN] -> [BM, BN].
                scores = tl.dot(qt, tl.trans(kt), input_precision="ieee") * SCALE
                valid = (i[:, None] < M) & (j[None, :] < N)
                if CAUSAL:
                    valid = valid & (j[None, :] <= i[:, None] + N - M)
                p = tl.exp(tl.where(valid, scores - ls[:, None], -float("inf")))
                p = tl.where(valid, p, 0.0)
                dp = tl.dot(gt, tl.trans(vt), input_precision="ieee")
                ds = tl.where(valid, p * (dp - delta[:, None]), 0.0)
                # [BN, BM] @ [BM, BD] -> [BN, BD].
                av += tl.dot(tl.trans(p), gt, input_precision="ieee")
                ak += tl.dot(tl.trans(ds), qt, input_precision="ieee")
        tl.store(
            DK + b * sdk[0] + j[:, None] * sdk[1] + hk * sdk[2] + d[None, :] * sdk[3],
            ak * SCALE, kmask,
        )
        tl.store(
            DV + b * sdv[0] + j[:, None] * sdv[1] + hk * sdv[2] + d[None, :] * sdv[3],
            av, kmask,
        )

    # Independent query ownership; no reads of another program's outputs.
    if tile * BM < M:
        i = tile * BM + tl.arange(0, BM)
        qm = (i[:, None] < M) & fd[None, :]
        for gh in range(GROUP):
            h = hk * GROUP + gh
            qt = tl.load(
                Q + b * sq[0] + i[:, None] * sq[1] + h * sq[2] + d[None, :] * sq[3],
                qm, other=0,
            ).to(tl.float32)
            ot = tl.load(
                O + b * so[0] + i[:, None] * so[1] + h * so[2] + d[None, :] * so[3],
                qm, other=0,
            ).to(tl.float32)
            gt = tl.load(
                DO + b * sg[0] + i[:, None] * sg[1] + h * sg[2] + d[None, :] * sg[3],
                qm, other=0,
            ).to(tl.float32)
            ls = tl.load(LSE + b * sl[0] + h * sl[1] + i * sl[2], i < M, other=0)
            delta = tl.sum(ot * gt, axis=1)
            aq = tl.zeros((BM, BD), tl.float32)
            for start in range(0, N, BN):
                j = start + tl.arange(0, BN)
                km = (j[:, None] < N) & fd[None, :]
                kt = tl.load(
                    K + b * sk[0] + j[:, None] * sk[1] + hk * sk[2] + d[None, :] * sk[3],
                    km, other=0,
                ).to(tl.float32)
                vt = tl.load(
                    V + b * sv[0] + j[:, None] * sv[1] + hk * sv[2] + d[None, :] * sv[3],
                    km, other=0,
                ).to(tl.float32)
                scores = tl.dot(qt, tl.trans(kt), input_precision="ieee") * SCALE
                valid = (i[:, None] < M) & (j[None, :] < N)
                if CAUSAL:
                    valid = valid & (j[None, :] <= i[:, None] + N - M)
                p = tl.exp(tl.where(valid, scores - ls[:, None], -float("inf")))
                p = tl.where(valid, p, 0.0)
                dp = tl.dot(gt, tl.trans(vt), input_precision="ieee")
                ds = tl.where(valid, p * (dp - delta[:, None]), 0.0)
                # [BM, BN] @ [BN, BD] -> [BM, BD].
                aq += tl.dot(ds, kt, input_precision="ieee")
            tl.store(
                DQ + b * sdq[0] + i[:, None] * sdq[1] + h * sdq[2] + d[None, :] * sdq[3],
                aq * SCALE, qm,
            )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """FlashAttention backward (one-kernel form): given the forward output o and the
    per-row log-sum-exp statistics lse, compute the gradients (dq, dk, dv) from
    (q, k, v, o, lse, do); dK/dV and dQ are produced inside the same kernel
    (dK/dV first, dQ after).

    Mathematical definition (let g = num_q_heads // num_kv_heads and the scaled
    score be s[b,h,i,j] = sm_scale * <q[b,i,h,:], k[b,j,h//g,:]>,
    with sm_scale defaulting to 1/sqrt(head_dim)):
      keep[b,i,j] = (j <= i + seqlen_k - seqlen_q) when causal=1 (bottom-right
                    aligned), always true when causal=0
      p[b,h,i,j]   = exp(s[b,h,i,j] - lse[b,h,i]), and masked positions (keep=0) are always 0
      delta[b,h,i] = sum_d o[b,i,h,d] * do[b,i,h,d]   (computed from the given o)
      dp[b,h,i,j]  = <do[b,i,h,:], v[b,j,h//g,:]>
      ds[b,h,i,j]  = p[b,h,i,j] * (dp[b,h,i,j] - delta[b,h,i])
      dv[b,j,h_k,d] = sum_{h = h_k*g .. h_k*g+g-1} sum_i p[b,h,i,j] * do[b,i,h,d]
      dk[b,j,h_k,d] = sm_scale * sum_{h in the same group} sum_i ds[b,h,i,j] * q[b,i,h,d]
      dq[b,i,h,d]   = sm_scale * sum_j ds[b,h,i,j] * k[b,j,h//g,d]
    Note that dK/dQ are multiplied by sm_scale at the end while dV is not; delta
    uses the input o (not the ideal forward output).
    Boundary behaviour: when causal=1 and i < seqlen_q - seqlen_k the row is fully
    masked -- p/ds are always 0, the dq row is all 0, and it contributes nothing to
    dk/dv (the task input convention sets o=0 and lse=0 for those rows).

    Input/output specification:
      q, o, do  [batch, seqlen_q, num_q_heads, head_dim] float16/bfloat16
      k, v      [batch, seqlen_k, num_kv_heads, head_dim] same dtype as q
      lse       [batch, num_q_heads, seqlen_q] float32 -- natural-log log-sum-exp of
                the scaled scores (0 for fully masked rows)
      returns a single 1-D tensor packed (multi-output packing protocol):
      packed = cat([dq flattened, dk flattened, dv flattened]) (each segment is
      first cast back to the input dtype, then converted to float32)
      where dq has the same shape as q and dk/dv the same shape as k; the total
      length of packed is
      (batch*seqlen_q*num_q_heads + 2*batch*seqlen_k*num_kv_heads) * head_dim.
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
      (GQA; equal means MHA); 1 <= head_dim <= 256 (need not be a power of 2);
      1 <= seqlen_q, seqlen_k; o and lse are the self-consistent forward statistics
      of (q, k, v) (guaranteed by the task's input generator).

    Implementation constraints (violations are scored as failures):
      - The core computation (all matrix multiplies and elementwise operations of
        delta / p / ds / dV / dK / dQ) must be done inside the submitted file;
        calling scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden, and so are
        automatic-differentiation shortcuts such as torch.autograd /
        autograd.grad / .backward(.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - forward must return a single 1-D float32 tensor following the packing
        protocol above (compute dq/dk/dv internally first, then flatten and
        concatenate each).

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: dense fixed-length (non-varlen), non-quantized inputs, no dropout /
    ALiBi / bias / fp8; causal and non-causal are selected by __init__'s causal
    switch.
    """
    def __init__(self, head_dim: int, causal: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.head_dim = int(head_dim)
        self.causal = bool(int(causal))
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, o, lse, do):
        # <<<IMPROVE:forward_stmt_1>>>
        B, M, H_Q, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        _, N, H_K, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        group = H_Q // H_K
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert H_Q == H_K * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        causal = bool(self.causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dq = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        dk = torch.empty(B, N, H_K, D, dtype=torch.float32, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        dv = torch.empty_like(dk)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        block_m = 32
        block_n = 32
        block_d = max(16, triton.next_power_of_2(D))
        grid = (max(triton.cdiv(M, block_m), triton.cdiv(N, block_n)), H_K, B)
        _mha_backward_kernel[grid](
            q, k, v, o, lse, do, dq, dk, dv,
            q.stride(), k.stride(), v.stride(),
            o.stride(), lse.stride(), do.stride(),
            dq.stride(), dk.stride(), dv.stride(),
            M, N, D, group, causal, self.sm_scale,
            block_m, block_n, block_d,
            num_warps=4,
            enable_fp_fusion=False,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return torch.cat([
            dq.reshape(-1).to(k.dtype).to(torch.float32),
            dk.reshape(-1).to(k.dtype).to(torch.float32),
            dv.reshape(-1).to(v.dtype).to(torch.float32),
        ])
        # <<<END_IMPROVE>>>
