import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _round_even_positive(x):
    lo = tl.floor(x)
    frac = x - lo
    odd = (lo.to(tl.int32) & 1) != 0
    return lo + ((frac > 0.5) | ((frac == 0.5) & odd)).to(tl.float32)


@triton.jit
def _quantize_value(x, INT8: tl.constexpr):
    a = tl.abs(x)
    if INT8:
        rounded = _round_even_positive(a)
        signed = tl.where(x < 0, -rounded, rounded)
        return signed.to(tl.int8).to(tl.float32)
    else:
        exponent = (a.to(tl.int32, bitcast=True) >> 23) & 255
        step_exponent = tl.maximum(exponent - 3, 118)
        step = (step_exponent << 23).to(tl.float32, bitcast=True)
        inverse = ((254 - step_exponent) << 23).to(tl.float32, bitcast=True)
        rounded = _round_even_positive(a * inverse) * step
        sign = x.to(tl.int32, bitcast=True) & (-2147483648)
        return (rounded.to(tl.int32, bitcast=True) | sign).to(
            tl.float32, bitcast=True
        )


@triton.jit
def _quant_rows(X, O, C: tl.constexpr, N: tl.constexpr,
                INT8: tl.constexpr, B: tl.constexpr):
    row = tl.program_id(0)
    cols = tl.arange(0, B)
    maximum = tl.full((B,), 0, tl.float32)
    if C <= B:
        values = tl.load(X + row * C + cols, cols < C, other=0)
        maximum = tl.abs(values)
    else:
        for start in range(0, C, B):
            values = tl.load(X + row * C + start + cols,
                             start + cols < C, other=0)
            maximum = tl.maximum(maximum, tl.abs(values))
    amax = tl.maximum(tl.max(maximum, 0), 1.0e-10)
    if INT8:
        s = amax * tl.full((), 1.0 / 127.0, tl.float32)
    else:
        s = amax * tl.full((), 1.0 / 448.0, tl.float32)
    inv = tl.div_rn(1.0, s)
    tl.store(O + N + row, s)
    if C <= B:
        codes = _quantize_value(values * inv, INT8)
        tl.store(O + row * C + cols, codes, cols < C)
    else:
        for start in range(0, C, B):
            offsets = row * C + start + cols
            values = tl.load(X + offsets, start + cols < C, other=0)
            codes = _quantize_value(values * inv, INT8)
            tl.store(O + offsets, codes, start + cols < C)


@triton.jit
def _quant_rows_batched(X, O, R: tl.constexpr, C: tl.constexpr,
                        N: tl.constexpr, INT8: tl.constexpr,
                        BR: tl.constexpr, BC: tl.constexpr):
    rows = tl.program_id(0) * BR + tl.arange(0, BR)
    cols = tl.arange(0, BC)
    offsets = rows[:, None] * C + cols[None, :]
    mask = (rows[:, None] < R) & (cols[None, :] < C)
    values = tl.load(X + offsets, mask, other=0).to(tl.float32)
    amax = tl.maximum(tl.max(tl.abs(values), axis=1), 1.0e-10)
    if INT8:
        s = amax * tl.full((), 1.0 / 127.0, tl.float32)
    else:
        s = amax * tl.full((), 1.0 / 448.0, tl.float32)
    inv = tl.div_rn(1.0, s)
    codes = _quantize_value(values * inv[:, None], INT8)
    tl.store(O + offsets, codes, mask)
    tl.store(O + N + rows, s, rows < R)


@triton.jit
def _quant_rows_batched8(X, O, R: tl.constexpr, C: tl.constexpr,
                         N: tl.constexpr, INT8: tl.constexpr,
                         BR: tl.constexpr, BC: tl.constexpr):
    rows = tl.program_id(0) * 8 + tl.arange(0, 8)
    cols = tl.arange(0, BC)
    offsets = rows[:, None] * C + cols[None, :]
    mask = (rows[:, None] < R) & (cols[None, :] < C)
    values = tl.load(X + offsets, mask, other=0).to(tl.float32)
    amax = tl.maximum(tl.max(tl.abs(values), axis=1), 1.0e-10)
    if INT8:
        s = amax * tl.full((), 1.0 / 127.0, tl.float32)
    else:
        s = amax * tl.full((), 1.0 / 448.0, tl.float32)
    inv = tl.div_rn(1.0, s)
    codes = _quantize_value(values * inv[:, None], INT8)
    tl.store(O + offsets, codes, mask)
    tl.store(O + N + rows, s, rows < R)


@triton.jit
def _partial_max(X, P, N: tl.constexpr, B: tl.constexpr):
    block = tl.program_id(0)
    offsets = block * B + tl.arange(0, B)
    values = tl.load(X + offsets, offsets < N, other=0)
    tl.store(P + block, tl.max(tl.abs(values), 0))


@triton.jit
def _finish_scale(P, O, COUNT: tl.constexpr, N: tl.constexpr,
                  INT8: tl.constexpr, B: tl.constexpr):
    offsets = tl.arange(0, B)
    values = tl.load(P + offsets, offsets < COUNT, other=0)
    amax = tl.max(values, 0)
    if INT8:
        s = amax * tl.full((), 1.0 / 127.0, tl.float32)
    else:
        s = amax * tl.full((), 1.0 / 448.0, tl.float32)
    tl.store(O + N, s)


@triton.jit
def _quant_flat(X, S, O, N: tl.constexpr, INT8: tl.constexpr,
                STATIC: tl.constexpr, B: tl.constexpr):
    block = tl.program_id(0)
    offsets = block * B + tl.arange(0, B)
    if STATIC:
        s = tl.load(S)
        if block == 0:
            tl.store(O + N, s)
    else:
        s = tl.load(O + N)
    values = tl.load(X + offsets, offsets < N, other=0)
    q = tl.div_rn(values, s)
    tl.store(O + offsets, _quantize_value(q, INT8), offsets < N)


@triton.jit
def _quant_flat_partial(X, P, O, N: tl.constexpr, COUNT: tl.constexpr,
                        INT8: tl.constexpr, B: tl.constexpr,
                        REDUCE_B: tl.constexpr):
    block = tl.program_id(0)
    partial_offsets = tl.arange(0, REDUCE_B)
    partial_values = tl.load(P + partial_offsets,
                             partial_offsets < COUNT, other=0)
    amax = tl.max(partial_values, 0)
    if INT8:
        s = amax * tl.full((), 1.0 / 127.0, tl.float32)
    else:
        s = amax * tl.full((), 1.0 / 448.0, tl.float32)
    offsets = block * B + tl.arange(0, B)
    values = tl.load(X + offsets, offsets < N, other=0)
    q = tl.div_rn(values, s)
    tl.store(O + offsets, _quantize_value(q, INT8), offsets < N)
    if block == 0:
        tl.store(O + N, s)


@triton.jit
def _quant_small_tensor(X, O, N: tl.constexpr, INT8: tl.constexpr,
                        B: tl.constexpr):
    offsets = tl.arange(0, B)
    values = tl.load(X + offsets, offsets < N, other=0).to(tl.float32)
    amax = tl.max(tl.abs(values), 0)
    if INT8:
        s = amax * tl.full((), 1.0 / 127.0, tl.float32)
    else:
        s = amax * tl.full((), 1.0 / 448.0, tl.float32)
    q = tl.div_rn(values, s)
    tl.store(O + offsets, _quantize_value(q, INT8), offsets < N)
    tl.store(O + N, s)


def _launch_quant(x_f32, scale, mode, is_int8):
    rows, cols = x_f32.shape
    n = rows * cols
    out = torch.empty(
        (n + (rows if mode == "dynamic_per_token" else 1),),
        device=x_f32.device, dtype=torch.float32
    )
    if mode == "dynamic_per_token":
        if cols <= 128 and rows >= 8:
            _quant_rows_batched8[(triton.cdiv(rows, 8),)](
                x_f32, out, rows, cols, n, is_int8,
                8, triton.next_power_of_2(cols),
                num_warps=4, enable_fp_fusion=False
            )
        elif cols <= 512 and rows >= 4:
            _quant_rows_batched[(triton.cdiv(rows, 4),)](
                x_f32, out, rows, cols, n, is_int8,
                4, triton.next_power_of_2(cols),
                num_warps=4, enable_fp_fusion=False
            )
        else:
            block = min(triton.next_power_of_2(cols), 8192)
            _quant_rows[(rows,)](
                x_f32, out, cols, n, is_int8, block,
                num_warps=8 if block == 8192 else 4, enable_fp_fusion=False
            )
    elif mode == "static_per_tensor":
        s = scale.to(torch.float32).reshape(1)
        _quant_flat[(triton.cdiv(n, 1024),)](
            x_f32, s, out, n, is_int8, True, 1024,
            num_warps=4, enable_fp_fusion=False
        )
    else:
        if n <= 2048:
            _quant_small_tensor[(1,)](
                x_f32, out, n, is_int8, triton.next_power_of_2(n),
                num_warps=4, enable_fp_fusion=False
            )
        else:
            count = triton.cdiv(n, 2048)
            partial = torch.empty(
                (count,), device=x_f32.device, dtype=torch.float32
            )
            _partial_max[(count,)](
                x_f32, partial, n, 2048, num_warps=4
            )
            if count <= 256:
                _quant_flat_partial[(triton.cdiv(n, 1024),)](
                    x_f32, partial, out, n, count, is_int8,
                    1024, triton.next_power_of_2(count),
                    num_warps=4, enable_fp_fusion=False
                )
            else:
                while count > 4096:
                    next_count = triton.cdiv(count, 2048)
                    next_partial = torch.empty(
                        (next_count,), device=x_f32.device,
                        dtype=torch.float32
                    )
                    _partial_max[(next_count,)](
                        partial, next_partial, count, 2048, num_warps=4
                    )
                    partial = next_partial
                    count = next_count
                _finish_scale[(1,)](
                    partial, out, count, n, is_int8,
                    triton.next_power_of_2(count),
                    num_warps=4, enable_fp_fusion=False
                )
                _quant_flat[(triton.cdiv(n, 1024),)](
                    x_f32, out, out, n, is_int8, False, 1024,
                    num_warps=4, enable_fp_fusion=False
                )
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """fp8(e4m3)/int8 quantization kernel family: static per-tensor / dynamic
    per-tensor / dynamic per-token.

    The input x is a contiguous 2D float tensor (rows, cols); the __init__
    hyperparameter mode selects the quantization mode and quant_dtype selects
    the target dtype (int8 or fp8 e4m3). Intermediate arithmetic is float32
    throughout. Definitions per mode (dtype_max: 127 for int8, 448 for fp8
    e4m3):

      static_per_tensor (the scale is given by the input):
          q_i  = x_i / scale                    # fp32 division, scale is (1,) fp32
          y_i  = int8: round_half_even(q_i); fp8: rne_e4m3(q_i)
          scale_out = scale (passed through as is, segment length 1)
      dynamic_per_tensor (single scale for the whole tensor, no division-by-zero guard):
          amax = max_i |x_i|                    # fp32
          s    = amax / dtype_max
          y_i  = int8: round_half_even(x_i / s); fp8: rne_e4m3(x_i / s)
          scale_out = s (segment length 1)
      dynamic_per_token (one scale per row, with a division-by-zero guard):
          amax_r = max_j |x_rj|                 # fp32
          s_r    = max(amax_r, 1e-10) / dtype_max
          y_rj   = int8: round_half_even(x_rj * (1/s_r)); fp8: rne_e4m3(x_rj * (1/s_r))
          scale_out = s (segment length rows, row-major)

    round_half_even is banker's rounding (0.5 -> 0, -0.5 -> 0, 1.5 -> 2,
    126.5 -> 126), consistent with torch.round; rne_e4m3 is rounding to the
    nearest representable e4m3 value (equivalent to .to(float8_e4m3fn)).
    Boundary behaviour: an all-zero row under per-token has amax_r = 0, the
    1e-10 guard gives s_r = 1e-10/dtype_max and every code word of that row is
    0 -- the output must be finite, producing NaN/Inf is a wrong
    implementation; per-tensor modes have no division-by-zero guard (the input
    contract guarantees amax > 0).

    Input/output specification:
      x     float16/bfloat16, contiguous (rows, cols); the evaluator casts the
            input to fp32 before passing it in -- fp16/bf16 values are exact in
            fp32, so the quantization semantics are unchanged
      scale used only in static_per_tensor mode: (1,) float32 positive number
      out   a 1-D float32 tensor of length rows*cols + S (single-tensor output
            protocol, two segments packed):
            out[:rows*cols] = quantized code words promoted to float32 (int8
                              are integers in [-127,127]; fp8 are exact e4m3
                              values)
            out[rows*cols:] = the scale segment: per-token gives rows row
                              scales (row-major), per-tensor/static gives 1
                              tensor scale
      __init__ hyperparameters: mode (str, default "dynamic_per_token"),
            quant_dtype (str, "int8" or "float8_e4m3", default "int8").
      Input contract: x is not all zero (per-tensor modes); for every mode the
      quotient/product before quantization falls inside the target dtype range
      (the cast has no overflow semantics divergence).

    Implementation constraints (violations are scored as failures):
      - The core computation (amax reduction, scale, quantized code words) must
        be completed in Triton kernels inside the submitted file; forward may
        only do input/output shaping (dtype conversion, the two-segment packing,
        etc.). Calling any ready-made quantization library / quantization
        shortcut is forbidden (including torch.quantize_per_tensor /
        torch.quantize_per_channel).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate arithmetic uses float32; the computation order of the
        scale and the quotient must match the definitions above -- per-token
        computes the reciprocal 1/s_r first and then multiplies by x, whereas
        static/per-tensor use the fp32 direct division x_i / s (reciprocal
        multiplication and direct division differ by 1 ulp, which shifts code
        words on tie boundaries); int8 rounding uses round_half_even.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: 2D contiguous input, int8 and fp8 e4m3 target dtypes, three
    modes in one operator; without the GEMM back-end computation and without
    block-scaling floating-point (mxfp4) quantization.
    """
    def __init__(self, mode: str = "dynamic_per_token", quant_dtype: str = "int8"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert mode in (
            "static_per_tensor",
            "dynamic_per_tensor",
            "dynamic_per_token",
        ), "invalid mode"
        assert quant_dtype in (
            "int8",
            "float8_e4m3",
        ), "quant_dtype must be int8 or float8_e4m3"
        self.mode = mode
        self.quant_dtype = (
            torch.int8
            if quant_dtype == "int8"
            else torch.float8_e4m3fn
        )
        # <<<END_IMPROVE>>>

    def forward(self, x, scale=None):
        # <<<IMPROVE:forward_stmt_1>>>
        assert x.dim() == 2, "x must be a 2D tensor"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert x.is_contiguous(), "x must be contiguous"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        qdt = self.quant_dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        dtype_max = (
            torch.iinfo(qdt).max
            if qdt == torch.int8
            else torch.finfo(qdt).max
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        x_f32 = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        out = _launch_quant(x_f32, scale, self.mode, qdt == torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        return out
        # <<<END_IMPROVE>>>
