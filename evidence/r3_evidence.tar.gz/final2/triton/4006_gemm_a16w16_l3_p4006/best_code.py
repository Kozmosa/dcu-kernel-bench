import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _gemm_a16w16_kernel(
    x_ptr,
    weight_ptr,
    out_ptr,
    M,
    N,
    K,
    stride_xm,
    stride_xk,
    stride_wn,
    stride_wk,
    stride_om,
    stride_on,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    GROUP_M: tl.constexpr,
):
    num_pid_m = tl.cdiv(M, BLOCK_M)
    num_pid_n = tl.cdiv(N, BLOCK_N)

    pid = tl.program_id(0)
    num_pid_in_group = GROUP_M * num_pid_n
    group_id = pid // num_pid_in_group
    first_pid_m = group_id * GROUP_M
    group_size_m = min(num_pid_m - first_pid_m, GROUP_M)
    pid_in_group = pid % num_pid_in_group
    pid_m = first_pid_m + (pid_in_group % group_size_m)
    pid_n = pid_in_group // group_size_m

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k_block in range(0, tl.cdiv(K, BLOCK_K)):
        k_offsets = k_block * BLOCK_K + offs_k

        x_ptrs = (
            x_ptr
            + offs_m[:, None] * stride_xm
            + k_offsets[None, :] * stride_xk
        )
        w_ptrs = (
            weight_ptr
            + offs_n[:, None] * stride_wn
            + k_offsets[None, :] * stride_wk
        )

        x_tile = tl.load(
            x_ptrs,
            mask=(offs_m[:, None] < M) & (k_offsets[None, :] < K),
            other=0.0,
        )
        w_tile = tl.load(
            w_ptrs,
            mask=(offs_n[:, None] < N) & (k_offsets[None, :] < K),
            other=0.0,
        )

        acc += tl.dot(x_tile, tl.trans(w_tile), out_dtype=tl.float32)

    out_ptrs = (
        out_ptr
        + offs_m[:, None] * stride_om
        + offs_n[None, :] * stride_on
    )
    tl.store(
        out_ptrs,
        acc,
        mask=(offs_m[:, None] < M) & (offs_n[None, :] < N),
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Bias-free 16-bit floating-point matrix multiplication (regular blocked
    whole-reduction variant).

    Operator semantics:
      x has shape [M, K], weight has shape [N, K] (the linear-layer weight
      layout), and the output out has shape [M, N]:
        out[m, n] = sum_{k=0}^{K-1} x[m, k] * weight[n, k]
      equivalent to torch.nn.functional.linear(x, weight, bias=None). M, N, K are
      arbitrary positive integers (including 1 and non-powers-of-two; K need not
      align with any block size, and out-of-range lanes along K contribute 0 to the
      accumulation). Reduction strategy: the full K reduction is completed inside a
      single program -- each output tile is computed and written back by exactly
      one program (M/N boundaries are handled by masking, tiles never overlap),
      with no split-K, no atomics and no cross-writes to the same output; the
      float32 accumulated result is cast back to the input dtype once, so there is
      no intermediate half-precision rounding.

    Input/output specification:
      forward(x, weight) -> out
        x      [M, K], float16 or bfloat16, row-major contiguous
        weight [N, K], same dtype as x, row-major contiguous
        out    [M, N], same dtype as x
      __init__(in_features, out_features): in_features corresponds to K and
      out_features to N; they are instance metadata only. forward always follows
      the actual shapes of the runtime tensors and does not enforce a hard match
      against the init parameters.

    Implementation constraints (violations are scored as failures):
      - The core computation (the multiply-accumulate main loop) must be completed
        with a Triton kernel inside the submitted file; calling ATen GEMM shortcuts
        such as torch.matmul / torch.bmm / torch.mm / torch.addmm / torch.einsum /
        torch.nn.functional.linear / F.linear / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: row-major TN layout, no bias, no batch dimension, single output
    tensor, float16 and bfloat16 input dtypes; the block sizes, tile-group
    scheduling and parallel strategy are left to the implementation and judged by
    the output tolerance.
    """
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.in_features = in_features
        self.out_features = out_features
        # <<<END_IMPROVE>>>

    def forward(self, x, weight):
        # <<<IMPROVE:forward_stmt_1>>>
        M, K = x.shape
        N, weight_K = weight.shape
        x_stride_m, x_stride_k = x.stride(0), x.stride(1)
        weight_stride_n, weight_stride_k = weight.stride(0), weight.stride(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        out = torch.empty((M, N), device=x.device, dtype=x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        assert K == weight_K, "x and weight must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        if M <= 16 and N <= 32:
            block_m, block_n = 16, 32
        elif M <= 16:
            block_m, block_n = 16, 64
        elif N <= 16:
            block_m, block_n = 64, 16
        elif M >= 64 and N >= 128:
            block_m, block_n = 64, 128
        else:
            block_m, block_n = 32, 32

        _gemm_a16w16_kernel[
            (triton.cdiv(M, block_m) * triton.cdiv(N, block_n),)
        ](
            x,
            weight,
            out,
            M,
            N,
            K,
            x_stride_m,
            x_stride_k,
            weight_stride_n,
            weight_stride_k,
            out.stride(0),
            out.stride(1),
            BLOCK_M=block_m,
            BLOCK_N=block_n,
            BLOCK_K=32,
            GROUP_M=8,
            num_warps=4,
            num_stages=2,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        return out
        # <<<END_IMPROVE>>>
