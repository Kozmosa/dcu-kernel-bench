import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _prefill_attention_kernel(
    q_ptr, k_ptr, v_ptr, out_ptr,
    start_ptr, len_ptr,
    H_Q, H_KV, D, GROUP, SCALE,
    MAX_LEN: tl.constexpr,
    CAUSAL: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    pid_m = tl.program_id(0)
    h = tl.program_id(1)
    seq = tl.program_id(2)

    start = tl.load(start_ptr + seq)
    seq_len = tl.load(len_ptr + seq)

    if pid_m * BLOCK_M < seq_len:
        q_pos = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
        d = tl.arange(0, BLOCK_D)

        valid_q = q_pos < seq_len
        q_token = start + q_pos
        q_offsets = (q_token[:, None] * H_Q + h) * D + d[None, :]
        q = tl.load(
            q_ptr + q_offsets,
            mask=valid_q[:, None] & (d[None, :] < D),
            other=0.0,
        )

        m = tl.full((BLOCK_M,), float("-inf"), tl.float32)
        l = tl.zeros((BLOCK_M,), dtype=tl.float32)
        acc = tl.zeros((BLOCK_M, BLOCK_D), dtype=tl.float32)

        if CAUSAL:
            key_end = tl.minimum(seq_len, (pid_m + 1) * BLOCK_M)
        else:
            key_end = seq_len

        kv_h = h // GROUP

        for key_base in tl.range(0, key_end, BLOCK_N):
            key_pos = key_base + tl.arange(0, BLOCK_N)
            valid_k = key_pos < key_end

            if CAUSAL:
                valid = (
                    valid_k[None, :]
                    & valid_q[:, None]
                    & (key_pos[None, :] <= q_pos[:, None])
                )
            else:
                valid = valid_k[None, :] & valid_q[:, None]

            k_token = start + key_pos
            k_offsets = (k_token[:, None] * H_KV + kv_h) * D + d[None, :]
            kk = tl.load(
                k_ptr + k_offsets,
                mask=valid_k[:, None] & (d[None, :] < D),
                other=0.0,
            )

            scores = tl.dot(q, tl.trans(kk), input_precision="ieee") * SCALE
            scores = tl.where(valid, scores, float("-inf"))

            row_max = tl.max(scores, axis=1)
            has_valid = row_max != float("-inf")
            m_safe = tl.where(m == float("-inf"), 0.0, m)
            row_max_safe = tl.where(has_valid, row_max, m_safe)
            m_new = tl.maximum(m_safe, row_max_safe)

            alpha = tl.where(has_valid, tl.exp(m_safe - m_new), 1.0)
            p = tl.exp(scores - m_new[:, None])
            p = tl.where(valid, p, 0.0)

            v_offsets = (k_token[:, None] * H_KV + kv_h) * D + d[None, :]
            vv = tl.load(
                v_ptr + v_offsets,
                mask=valid_k[:, None] & (d[None, :] < D),
                other=0.0,
            )

            l = alpha * l + tl.sum(p, axis=1)
            acc = alpha[:, None] * acc + tl.dot(p, vv, input_precision="ieee")
            m = m_new

        denom = tl.where(l > 0.0, l, 1.0)
        result = acc / denom[:, None]
        out_token = start + q_pos
        out_offsets = (out_token[:, None] * H_Q + h) * D + d[None, :]
        tl.store(
            out_ptr + out_offsets,
            result,
            mask=valid_q[:, None] & (d[None, :] < D),
        )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Non-paged prefill self-attention over a ragged variable-length batch (contiguous KV, GQA, causal optional).

    Operator semantics: the tokens of num_seqs sequences in the batch are stored
    flattened in dimension 0 of q/k/v; sequence i occupies the row range
    [b_start_loc[i], b_start_loc[i] + b_seq_len[i]), and b_start_loc is the
    exclusive prefix sum of the sequence lengths (b_start_loc[0] = 0,
    b_start_loc[i+1] = b_start_loc[i] + b_seq_len[i]), with no padding; the
    q/k/v of each sequence are the query/key/value of the same token batch (self
    attention). For the h-th query head (its KV head is
    g = h // query_group_size, query_group_size = num_q_heads // num_kv_heads)
    and in-sequence relative position t of sequence i
    (0 <= t < L_i, L_i = b_seq_len[i], row index s = b_start_loc[i] + t):
      logits[j] = sm_scale * <q[s, h, :], k[b_start_loc[i]+j, g, :]>
                  (sm_scale defaults to 1 / sqrt(head_dim))
      with causal=True, positions j > t are set to -inf; with causal=False all j are visible
      p[j] = softmax_j(logits[j])
      out[s, h, :] = sum_{j=0}^{L_i-1} p[j] * v[b_start_loc[i]+j, g, :]
    The softmax uses a numerically stable online implementation, intermediate
    accumulation is in float32, and the output is cast back to the input dtype.
    Boundary behaviour: b_seq_len[i] >= 1 always holds, the softmax denominator
    is always positive and there is no fully masked row (under causal masking row
    t sees at least itself); sequences do not affect each other.

    Input/output specification (evaluation dtype is float16 / bfloat16, all
    tensors contiguous):
      q            eval dtype (total_tokens, num_q_heads, head_dim)
      k            eval dtype (total_tokens, num_kv_heads, head_dim)
      v            eval dtype (total_tokens, num_kv_heads, head_dim)
      b_start_loc  int32 (num_seqs) -- exclusive prefix sum of the sequence lengths
      b_seq_len    int32 (num_seqs) -- length of each sequence (>= 1, may all differ)
      returns out  eval dtype (total_tokens, num_q_heads, head_dim)
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (GQA; equality means MHA); Q/K/V share the same head dim and it is >= 16,
    non-power-of-2 is allowed (out-of-range channels must be masked to zero by
    head_dim); total_tokens = sum(b_seq_len).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.
      - The evaluator casts every input tensor to fp32 before calling forward;
        the prefix sum and the sequence lengths are small integers that fp32
        represents exactly, so .to(torch.int32) at the entry recovers them
        losslessly.
      - The maximum sequence length is not an input: an upper bound for the grid
        along the in-sequence position dimension can be derived inside forward
        from int(b_seq_len.max()), and the kernel masks out-of-range rows/columns
        per sequence using L_i.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: contiguous non-paged KV, ragged variable-length batch, GQA,
    causal/non-causal, fp16/bf16 non-quantized inputs; no paged KV cache, no
    prefix-pool indirect addressing, no custom mask, no sliding window, no
    attention sink, no dropout, no LSE output, no MLA absorb form -- those
    variants are left as separate follow-up tasks.
    """
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, b_start_loc, b_seq_len):
        # <<<IMPROVE:forward_stmt_1>>>
        b_start_loc = b_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        b_seq_len = b_seq_len.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        total, H_Q, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = k.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert k.shape[-1] == D and v.shape[-1] == D, "the Q/K/V head dims must be identical"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        scale = self.sm_scale if self.sm_scale is not None else 1.0 / math.sqrt(D)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        B = b_seq_len.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        max_len = int(b_seq_len.max().item())
        grid = (triton.cdiv(max_len, 32), H_Q, B)
        _prefill_attention_kernel[grid](
            q,
            k,
            v,
            out,
            b_start_loc,
            b_seq_len,
            H_Q=H_Q,
            H_KV=H_KV,
            D=D,
            GROUP=group,
            SCALE=scale,
            MAX_LEN=max_len,
            CAUSAL=self.causal,
            BLOCK_M=32,
            BLOCK_N=32,
            BLOCK_D=triton.next_power_of_2(D),
            num_warps=4,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
