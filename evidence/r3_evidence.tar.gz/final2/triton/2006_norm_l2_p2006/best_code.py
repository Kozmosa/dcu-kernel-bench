import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _fused_residual_layernorm(
    x_ptr,
    residual_ptr,
    weight_ptr,
    bias_ptr,
    out_ptr,
    M,
    N,
    eps,
    BLOCK_SIZE: tl.constexpr,
):
    row = tl.program_id(0)
    offsets = tl.arange(0, BLOCK_SIZE)
    mask = offsets < N

    row_base = row * N
    x = tl.load(x_ptr + row_base + offsets, mask=mask, other=0.0).to(tl.float32)
    residual = tl.load(
        residual_ptr + row_base + offsets, mask=mask, other=0.0
    ).to(tl.float32)
    summed = x + residual
    rounded = summed.to(out_ptr.dtype.element_ty)

    out_row_base = row * (2 * N)
    residual_out_ptr = out_ptr + out_row_base + N + offsets
    tl.store(residual_out_ptr, rounded, mask=mask)

    z = rounded.to(tl.float32)
    mean = tl.sum(tl.where(mask, z, 0.0), axis=0) / N
    centered = tl.where(mask, z - mean, 0.0)
    var = tl.sum(centered * centered, axis=0) / N
    rstd = tl.rsqrt(var + eps)

    weight = tl.load(weight_ptr + offsets, mask=mask, other=0.0).to(tl.float32)
    bias = tl.load(bias_ptr + offsets, mask=mask, other=0.0).to(tl.float32)
    y = centered * rstd * weight + bias

    tl.store(out_ptr + out_row_base + offsets, y, mask=mask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Forward pass of residual-fused LayerNorm (fused add LayerNorm).

    The inputs x and residual are added element-wise to form the residual sum s
    (the addition happens in float32, then s is rounded back to the input dtype
    for storage); LayerNorm is then applied to the last dimension of s together
    with an affine transform (everything evaluated in float32):
        mean_i  = (1/N) * sum_j s[i, j]
        var_i   = (1/N) * sum_j (s[i, j] - mean_i)^2      (biased variance)
        rstd_i  = 1 / sqrt(var_i + eps)                   (eps comes from __init__)
        y[i, j] = (s[i, j] - mean_i) * rstd_i * weight[j] + bias[j]
    The statistics are taken over s as rounded back to the input dtype; y is
    finally rounded back to the input dtype as well.
    Boundary behaviour: N is any positive integer (including 1, non-power-of-two,
    and very long rows), columns outside the mask do not participate in the
    statistics; when var = 0, eps keeps rstd finite; the inputs contain no
    inf/NaN.

    The output is a single tensor out (M, 2N) with the same dtype as the inputs:
        out[:, :N] = y           the LayerNorm output
        out[:, N:] = s           residual_out (the residual sum rounded to the input dtype)

    Input/output specification:
        x        (M, N)  float16 / bfloat16 / float32, contiguous, M >= 1, N >= 1
        residual (M, N)  same as x
        weight   (N,)    same as x (per-channel scale)
        bias     (N,)    same as x (per-channel shift)
        (the evaluator casts the inputs to fp32 before calling forward;
         fp16/bf16 -> fp32 is lossless)

    Implementation constraints (violations are scored as failures):
        - The core computation (residual add, mean/var statistics, normalization,
          affine transform) must be completed with a Triton kernel inside the
          submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate intermediates in float32; both y and residual_out are
          rounded back to the input dtype.

    Forbidden list: torch.nn.functional.layer_norm / torch.layer_norm /
    torch.nn.LayerNorm.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, residual, weight, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        dt = x.dtype
        M, N = x.shape
        out = torch.empty((M, 2 * N), device=x.device, dtype=dt)
        block_size = 1 << (N - 1).bit_length()
        if block_size <= 256:
            num_warps = 4
        elif block_size <= 1024:
            num_warps = 8
        else:
            num_warps = 16
        _fused_residual_layernorm[(M,)](
            x,
            residual,
            weight,
            bias,
            out,
            M,
            N,
            self.eps,
            BLOCK_SIZE=block_size,
            num_warps=num_warps,
        )
        return out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Computation is performed in the fused Triton kernel.
        # <<<END_IMPROVE>>>
