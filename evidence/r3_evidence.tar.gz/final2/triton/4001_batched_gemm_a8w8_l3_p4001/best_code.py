import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _a8w8_batched_gemm_kernel(
    x_ptr, w_ptr, x_scale_ptr, w_scale_ptr, out_ptr, bias_ptr,
    B, M, N, K,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
    USE_BIAS: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    pid_b = tl.program_id(2)

    offs_m = pid_m.to(tl.int64) * BM + tl.arange(0, BM)
    offs_n = pid_n.to(tl.int64) * BN + tl.arange(0, BN)
    offs_m_i64 = offs_m.to(tl.int64)
    offs_n_i64 = offs_n.to(tl.int64)
    pid_b_i64 = pid_b.to(tl.int64)
    m_i64 = M.to(tl.int64)
    n_i64 = N.to(tl.int64)
    k_i64 = K.to(tl.int64)

    acc = tl.zeros((BM, BN), dtype=tl.float32)

    x_batch_base = pid_b_i64 * m_i64 * k_i64
    w_batch_base = pid_b_i64 * n_i64 * k_i64

    for k0 in range(0, K, BK):
        offs_k = (k0 + tl.arange(0, BK)).to(tl.int64)
        k_mask = offs_k < k_i64

        x_offsets = (
            x_batch_base
            + offs_m_i64[:, None] * k_i64
            + offs_k[None, :]
        )
        w_offsets = (
            w_batch_base
            + offs_n_i64[:, None] * k_i64
            + offs_k[None, :]
        )

        x_tile = tl.load(
            x_ptr + x_offsets,
            mask=(offs_m_i64[:, None] < m_i64) & k_mask[None, :],
            other=0,
        ).to(tl.float32)
        w_tile = tl.load(
            w_ptr + w_offsets,
            mask=(offs_n_i64[:, None] < n_i64) & k_mask[None, :],
            other=0,
        ).to(tl.float32)

        acc += tl.dot(x_tile, tl.trans(w_tile))

    x_scale_offsets = pid_b_i64 * m_i64 + offs_m_i64
    w_scale_offsets = pid_b_i64 * n_i64 + offs_n_i64

    row_scale = tl.load(
        x_scale_ptr + x_scale_offsets,
        mask=offs_m_i64 < m_i64,
        other=1.0,
    ).to(tl.float32)
    col_scale = tl.load(
        w_scale_ptr + w_scale_offsets,
        mask=offs_n_i64 < n_i64,
        other=1.0,
    ).to(tl.float32)

    acc = acc * row_scale[:, None] * col_scale[None, :]
    acc = acc.to(out_ptr.dtype.element_ty)

    if USE_BIAS:
        bias_offsets = pid_b_i64 * n_i64 + offs_n_i64
        bias_value = tl.load(
            bias_ptr + bias_offsets,
            mask=offs_n_i64 < n_i64,
            other=0,
        ).to(tl.float32)
        acc = (acc.to(tl.float32) + bias_value[None, :]).to(
            out_ptr.dtype.element_ty
        )

    out_offsets = (
        pid_b_i64 * m_i64 * n_i64
        + offs_m_i64[:, None] * n_i64
        + offs_n_i64[None, :]
    )
    tl.store(
        out_ptr + out_offsets,
        acc,
        mask=(offs_m_i64[:, None] < m_i64)
        & (offs_n_i64[None, :] < n_i64),
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Batch-dimension int8 quantized GEMM: int8 activations x int8 weights, with an
    outer-product scale applied for dequantization.

    Computed independently for every matrix in the batch (mathematical definition):
      acc[b, m, n] = sum_k xq[b, m, k] * wq[b, n, k]          (float32 accumulation)
      out[b, m, n] = acc[b, m, n] * xs[b, m, 0] * ws[b, 0, n] (+ bias[b, 0, n])

    i.e. out[b] = xq[b] @ wq[b]^T followed by dequantization. wq is stored
    row-major as (B, N, K), so the computation is equivalent to a transposed GEMM
    (row n of the weight is one output-channel column). xs is the per-token scale:
    one value per row of the M dimension, (B, M, 1) float32; ws is the per-channel
    scale: one value per column of the N dimension, (B, 1, N) float32; their outer
    product is the (B, M, N) dequantization matrix. bias (B, 1, N) is optional and
    has the same dtype as the output; with bias the quantized-GEMM kernel fusion
    order applies: the float32 scaled result is first cast to the output dtype, then
    the bias is added.

    Input/output specification:
      xq      int8       (B, M, K)   activation code words
      wq      int8       (B, N, K)   weight code words (row-major, transposed-GEMM
                                     equivalent)
      xs      float32    (B, M, 1)   per-token scale
      ws      float32    (B, 1, N)   per-channel scale
      bias    output dtype (B, 1, N) optional; when use_bias=False a placeholder
                                     tensor is passed and ignored
      out     output dtype (B, M, N) the dtype is set by __init__'s out_dtype
                                     (bfloat16 / float16), B/M/N/K >= 1

    Implementation constraints (violations are scored as failures):
      - The core computation (the int8 GEMM accumulation) must be completed inside
        the submitted file; calling torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / torch._int_mm / F.linear /
        functional.linear is forbidden, as is calling any ready-made operator
        library or closed-source kernel wrapper to complete this computation
        directly.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward; the code
        words are small integers in [-20, 20) and the bias values come from
        low-precision quantization, all exactly representable in fp32, so
        .to(torch.int8) / .to(out_dtype) at the entry point recovers them
        losslessly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: TN layout (x row-major (B,M,K), w row-major (B,N,K)), no split-K;
    B/M/N/K are any values >= 1 with no alignment requirement; the accumulation
    runs in float32 and must agree with the reference fp32 GEMM within tolerance.
    """
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, xq, wq, x_scale, w_scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        xq = xq.to(torch.int8).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        wq = wq.to(torch.int8).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        bias = bias.to(self.out_dtype).contiguous() if self.use_bias else None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        B, M, K = xq.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = wq.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == wq.shape[2], "xq and wq must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        a = xq
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        b = wq
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        x_scale = x_scale.contiguous()
        w_scale = w_scale.contiguous()
        acc = torch.empty((B, M, N), device=xq.device, dtype=self.out_dtype)
        grid = (triton.cdiv(M, 64), triton.cdiv(N, 64), B)
        bias_ptr = bias if self.use_bias else acc
        _a8w8_batched_gemm_kernel[grid](
            xq, wq, x_scale, w_scale, acc, bias_ptr,
            B, M, N, K, BM=64, BN=64, BK=32, USE_BIAS=self.use_bias
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        acc = acc
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        acc = acc
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        acc = acc
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        acc = acc
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return acc
        # <<<END_IMPROVE>>>
