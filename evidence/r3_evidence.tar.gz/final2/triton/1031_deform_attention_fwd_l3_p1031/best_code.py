import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _deform_attention_fwd(
    value_ptr,
    shapes_ptr,
    starts_ptr,
    loc_ptr,
    weight_ptr,
    out_ptr,
    n_keys,
    n_queries,
    num_heads,
    d,
    BLOCK_D: tl.constexpr,
    n_levels: tl.constexpr,
    n_points: tl.constexpr,
):
    row = tl.program_id(0)
    block = tl.program_id(1)
    offs_d = block * BLOCK_D + tl.arange(0, BLOCK_D)
    dmask = offs_d < d

    samples = n_levels * n_points
    qh = n_queries * num_heads
    batch = row // qh
    rem = row - batch * qh
    head = rem % num_heads

    row_i64 = row.to(tl.int64)
    d_i64 = d.to(tl.int64)
    keys_i64 = n_keys.to(tl.int64)
    heads_i64 = num_heads.to(tl.int64)

    max_score = tl.full((), -float("inf"), tl.float32)
    for s in tl.range(0, samples):
        score = tl.load(weight_ptr + row_i64 * samples + s).to(tl.float32)
        max_score = tl.maximum(max_score, score)

    denom = tl.zeros((), dtype=tl.float32)
    if samples == 1:
        denom = 1.0
    else:
        for s in tl.range(0, samples):
            score = tl.load(weight_ptr + row_i64 * samples + s).to(tl.float32)
            denom += tl.exp(score - max_score)

    acc = tl.zeros((BLOCK_D,), dtype=tl.float32)

    for s in tl.range(0, samples):
        level = s // n_points
        point = s - level * n_points

        if samples == 1:
            norm_weight = 1.0
        else:
            score = tl.load(weight_ptr + row_i64 * samples + s).to(tl.float32)
            norm_weight = tl.exp(score - max_score) / denom

        hw_offset = level * 2
        h_l = tl.load(shapes_ptr + hw_offset).to(tl.int64)
        w_l = tl.load(shapes_ptr + hw_offset + 1).to(tl.int64)
        base = tl.load(starts_ptr + level).to(tl.int64)

        loc_offset = row_i64 * samples * 2 + s * 2
        x = tl.load(loc_ptr + loc_offset).to(tl.float32)
        y = tl.load(loc_ptr + loc_offset + 1).to(tl.float32)

        sx = x * w_l.to(tl.float32)
        sy = y * h_l.to(tl.float32)
        ix0 = tl.floor(sx).to(tl.int64)
        iy0 = tl.floor(sy).to(tl.int64)
        fx = sx - ix0.to(tl.float32)
        fy = sy - iy0.to(tl.float32)

        ix1 = ix0 + 1
        iy1 = iy0 + 1

        valid00 = (iy0 >= 0) & (iy0 < h_l) & (ix0 >= 0) & (ix0 < w_l)
        valid01 = (iy0 >= 0) & (iy0 < h_l) & (ix1 >= 0) & (ix1 < w_l)
        valid10 = (iy1 >= 0) & (iy1 < h_l) & (ix0 >= 0) & (ix0 < w_l)
        valid11 = (iy1 >= 0) & (iy1 < h_l) & (ix1 >= 0) & (ix1 < w_l)

        iy0_safe = tl.where((iy0 >= 0) & (iy0 < h_l), iy0, 0)
        iy1_safe = tl.where((iy1 >= 0) & (iy1 < h_l), iy1, 0)
        ix0_safe = tl.where((ix0 >= 0) & (ix0 < w_l), ix0, 0)
        ix1_safe = tl.where((ix1 >= 0) & (ix1 < w_l), ix1, 0)

        base_batch = batch.to(tl.int64) * keys_i64 + base
        addr00 = (
            (base_batch + iy0_safe * w_l + ix0_safe) * heads_i64
            + head.to(tl.int64)
        ) * d_i64 + offs_d.to(tl.int64)
        addr01 = (
            (base_batch + iy0_safe * w_l + ix1_safe) * heads_i64
            + head.to(tl.int64)
        ) * d_i64 + offs_d.to(tl.int64)
        addr10 = (
            (base_batch + iy1_safe * w_l + ix0_safe) * heads_i64
            + head.to(tl.int64)
        ) * d_i64 + offs_d.to(tl.int64)
        addr11 = (
            (base_batch + iy1_safe * w_l + ix1_safe) * heads_i64
            + head.to(tl.int64)
        ) * d_i64 + offs_d.to(tl.int64)

        v00 = tl.load(value_ptr + addr00, mask=valid00 & dmask, other=0.0).to(tl.float32)
        v01 = tl.load(value_ptr + addr01, mask=valid01 & dmask, other=0.0).to(tl.float32)
        v10 = tl.load(value_ptr + addr10, mask=valid10 & dmask, other=0.0).to(tl.float32)
        v11 = tl.load(value_ptr + addr11, mask=valid11 & dmask, other=0.0).to(tl.float32)

        w00 = (1.0 - fy) * (1.0 - fx)
        w01 = (1.0 - fy) * fx
        w10 = fy * (1.0 - fx)
        w11 = fy * fx
        sampled = v00 * w00 + v01 * w01 + v10 * w10 + v11 * w11
        acc += sampled * norm_weight

    tl.store(out_ptr + row_i64 * d_i64 + offs_d.to(tl.int64), acc, mask=dmask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Multi-Scale Deformable Attention forward: value sampling + hand-written
    bilinear interpolation + softmax normalization of the sampling weights.

    Semantics (all intermediate computation in float32): value (N, n_keys, heads,
    D) is the concatenation of the multi-scale feature levels -- level l
    contributes spatial_shapes[l] = (H_l, W_l) keys, laid out inside the level in
    row-major order (H first, then W) over
    [level_start_index[l], level_start_index[l] + H_l*W_l), where
    level_start_index must be the prefix sum of the per-level H_l*W_l (first
    element 0) and n_keys = sum_l H_l*W_l. sampling_locations
    (N, Q, heads, L, P, 2) gives the normalized coordinates of every
    (batch, query, head) at every sampling point of every level, with the last
    dimension being (x, y): channel 0 runs along W and channel 1 along H (the
    generation domain is [0,1)), so the actual sampling coordinates are
        loc_x = x * W_l,  loc_y = y * H_l
    The sampled value goes through four-corner bilinear interpolation:
        ix0 = floor(loc_x), iy0 = floor(loc_y), fx = loc_x - ix0, fy = loc_y - iy0
        the weights of the four corners (iy0,ix0), (iy0,ix0+1), (iy0+1,ix0),
        (iy0+1,ix0+1) are, in that order,
        (1-fy)(1-fx), (1-fy)fx, fy(1-fx), fy*fx
    When a corner's row or column is out of range (< 0 or > dim-1) that corner
    contributes 0 while the other corners are weighted as usual -- i.e. zero
    padding semantics, with no clamp / nearest-neighbour pull-back anywhere in the
    computation; when the coordinates are entirely out of range the sampled value
    is 0.
    attention_weights (N, Q, heads, L, P) are non-negative unnormalized scores:
    first flatten (levels x points) into one dimension and run a numerically
    stable softmax (max subtraction) to normalize them into convex-combination
    weights, then take the weighted sum against the interpolated value of each
    sampling point:
        out[n, q, h*D + d] = sum_{l, p} w[n,q,h,l,p] * bilinear(value_l)[n,q,h,p,d]
    The output is the single tensor out (N, Q, heads*D), cast back to the value
    dtype (naturally a single output, no multi-output packing). When L*P = 1 the
    softmax weights are identically 1.

    Input/output specification (all tensors contiguous):
      value              float32 / float16 (N, n_keys, heads, D)
      spatial_shapes     int64 (L, 2), each row (H_l, W_l), H_l / W_l >= 1
      level_start_index  int64 (L,), prefix sum of the per-level key counts
      sampling_locations same dtype as value (N, Q, heads, L, P, 2), generation domain [0,1)
      attention_weights  same dtype as value (N, Q, heads, L, P), non-negative
      out                single tensor, same dtype as value (N, Q, heads*D)
      every dimension is an arbitrary positive integer (including 1, non-powers
      of 2, and non-16-aligned sizes; a single-level single-pixel (H_l, W_l) =
      (1, 1), and 1xN / Nx1 thin-strip levels are all legal boundaries). The
      evaluator casts every input to fp32 before passing it in (lossless for both
      the low precision and the int64 indices -- an index value <= 2^24 is exactly
      representable in fp32), so the implementation must restore
      spatial_shapes / level_start_index to integer indices before using them.

    Implementation constraints (violations are scored as failures):
      - The core computation (coordinate expansion, four-corner bilinear
        interpolation, softmax normalization of the weights, and the cross-level
        cross-point weighted reduction) must be hand-written as a Triton kernel
        inside the submitted file.
      - The softmax, the interpolation and the weighted reduction are done in
        float32, and the output is cast back to the value dtype.
      - forward returns the single tensor out (N, Q, heads*D) (the evaluator
        compares a single output).
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden list: torchvision (including ready-made deformable attention /
    deformable convolution primitives such as torchvision.ops.ms_deform_attn),
    mmcv, miopen, hipdnn, aiter,
    torch.nn.functional.grid_sample (F.grid_sample),
    torch.nn.functional.interpolate (F.interpolate), torch.matmul /
    torch.bmm / torch.mm / torch.einsum / torch.tensordot,
    torch.softmax / torch.nn.functional.softmax (F.softmax).
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, value, spatial_shapes, level_start_index, sampling_locations, attention_weights):
        # <<<IMPROVE:forward_stmt_1>>>
        # Metadata is converted to integer indices on load inside the Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # The original metadata tensor is passed to the Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        n, n_keys, num_heads, d = value.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        n_levels = spatial_shapes.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_queries = sampling_locations.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_points = sampling_locations.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert sampling_locations.dim() == 6 \
            and sampling_locations.shape[2] == num_heads \
            and sampling_locations.shape[3] == n_levels \
            and sampling_locations.shape[5] == 2, \
            "sampling_locations must be (N, Q, heads, L, P, 2)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert attention_weights.shape == (n, n_queries, num_heads, n_levels, n_points), \
            "attention_weights must be (N, Q, heads, L, P)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert spatial_shapes.shape == (n_levels, 2)
        assert level_start_index.shape == (n_levels,)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        vf = value
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        loc = sampling_locations
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        wf = attention_weights
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # The contiguous flattening uses s = level * n_points + point.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # Full L*P stable softmax normalization is performed inside the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # Batch indexing is decoded from the kernel program ID.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # Head indexing is decoded from the kernel program ID.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        out = torch.empty(
            (n, n_queries, num_heads * d),
            dtype=value.dtype,
            device=value.device,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        grid = (n * n_queries * num_heads, triton.cdiv(d, 32))
        _deform_attention_fwd[grid](
            vf,
            spatial_shapes,
            level_start_index,
            loc,
            wf,
            out,
            n_keys,
            n_queries,
            num_heads,
            d,
            BLOCK_D=32,
            n_levels=n_levels,
            n_points=n_points,
            num_warps=4,
            enable_fp_fusion=False,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        return out
        # <<<END_IMPROVE>>>
