import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _rmsnorm_fused_kernel(
    x_ptr,
    w_ptr,
    residual_ptr,
    out_ptr,
    M,
    N,
    eps,
    FUSED: tl.constexpr,
    BLOCK: tl.constexpr,
):
    row = tl.program_id(0)
    row_offset = row * N
    out_row_offset = row * (2 * N if FUSED else N)

    acc = tl.zeros((), dtype=tl.float32)
    for start in tl.range(0, N, BLOCK):
        offsets = start + tl.arange(0, BLOCK)
        mask = offsets < N

        x_val = tl.load(x_ptr + row_offset + offsets, mask=mask, other=0)
        if FUSED:
            residual_val = tl.load(
                residual_ptr + row_offset + offsets,
                mask=mask,
                other=0,
            )
            value = (x_val + residual_val).to(x_val.dtype)
        else:
            value = x_val

        value_f32 = value.to(tl.float32)
        acc += tl.sum(value_f32 * value_f32, axis=0)

    rsigma = tl.rsqrt(acc / N + eps)

    for start in tl.range(0, N, BLOCK):
        offsets = start + tl.arange(0, BLOCK)
        mask = offsets < N

        x_val = tl.load(x_ptr + row_offset + offsets, mask=mask, other=0)
        if FUSED:
            residual_val = tl.load(
                residual_ptr + row_offset + offsets,
                mask=mask,
                other=0,
            )
            value = (x_val + residual_val).to(x_val.dtype)
        else:
            value = x_val

        value_f32 = value.to(tl.float32)
        weight = tl.load(w_ptr + offsets, mask=mask, other=0).to(tl.float32)
        result = value_f32 * rsigma * weight

        tl.store(out_ptr + out_row_offset + offsets, result, mask=mask)
        if FUSED:
            tl.store(
                out_ptr + out_row_offset + N + offsets,
                value,
                mask=mask,
            )


@triton.jit
def _rmsnorm_single_block_kernel(
    x_ptr,
    w_ptr,
    residual_ptr,
    out_ptr,
    M,
    N,
    eps,
    FUSED: tl.constexpr,
    BLOCK: tl.constexpr,
):
    row = tl.program_id(0)
    row_offset = row * N
    out_row_offset = row * (2 * N if FUSED else N)

    offsets = tl.arange(0, BLOCK)
    mask = offsets < N

    x_val = tl.load(x_ptr + row_offset + offsets, mask=mask, other=0)
    if FUSED:
        residual_val = tl.load(
            residual_ptr + row_offset + offsets,
            mask=mask,
            other=0,
        )
        value = (x_val + residual_val).to(x_val.dtype)
    else:
        value = x_val

    value_f32 = value.to(tl.float32)
    value_f32 = tl.where(mask, value_f32, 0.0)
    mean_sq = tl.sum(value_f32 * value_f32, axis=0) / N
    rsigma = tl.rsqrt(mean_sq + eps)

    weight = tl.load(w_ptr + offsets, mask=mask, other=0).to(tl.float32)
    result = value_f32 * rsigma * weight

    tl.store(out_ptr + out_row_offset + offsets, result, mask=mask)
    if FUSED:
        tl.store(
            out_ptr + out_row_offset + N + offsets,
            value,
            mask=mask,
        )


# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """RMSNorm forward family: standard RMSNorm and residual-fused
    (fused residual-add) RMSNorm.

    For each row of an (M, N) input, the normalization is computed in float32 as
    defined below:
        mean_sq = sum_i x_i^2 / N
        rsigma  = rsqrt(mean_sq + eps)
        y_i     = x_i * rsigma * w_i
    where w is the per-channel scale vector. The __init__ parameter `variant`
    selects one of two paths:
        "fused_add": first compute residual_out = x + residual in the input dtype
        (the residual stream passes straight through to the output), then apply the
        RMSNorm above to residual_out;
        "rmsnorm"  : apply the RMSNorm directly to x; residual takes no part in the
        computation (its content is arbitrary and may be garbage data).
    forward returns a single tensor out (same dtype as x): with fused_add it is
    (M, 2N) with the first N columns equal to y and the last N columns equal to
    residual_out (the two logical outputs concatenated along the last dimension);
    with rmsnorm it is (M, N), i.e. y.
    Boundary behaviour: for an all-zero row mean_sq = 0, so rsigma = rsqrt(eps)
    (eps guarantees no division by zero); N is arbitrary (including 1,
    non-powers-of-two, sizes not multiple of 16, and large N beyond a single
    block's reduction capacity) and must all be handled correctly with masking / a
    blocked reduction, and out-of-range elements at the row tail must not
    contribute to the sum of squares.

    Input/output specification:
        x        float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        weight   same dtype as x, (N,), contiguous
        residual same dtype as x, (M, N), contiguous (ignored when variant="rmsnorm")
        out      a single tensor, same dtype as x: (M, 2N) with fused_add (first N
                 columns y, last N columns residual_out), (M, N) with rmsnorm (i.e. y)
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (residual add, per-row sum-of-squares reduction,
          rsqrt, element-wise scaling) must be completed with a Triton kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The sum-of-squares accumulation and the normalization run in float32; y is
          cast back to the input dtype; residual_out is added in the input dtype and
          written out as-is.
        - forward returns the single tensor `out` (the evaluator compares a single
          output); with fused_add the residual_out column block must be bit-identical
          to x + residual in the input dtype.

    Forbidden list: aiter / torch.rms_norm / torch.nn.functional.rms_norm /
    torch.nn.RMSNorm / torch.layer_norm / torch.nn.functional.layer_norm /
    torch.nn.LayerNorm / torch.norm / torch.linalg.norm /
    torch.linalg.vector_norm.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "fused_add", eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("rmsnorm", "fused_add"), "variant must be one of rmsnorm / fused_add"
        self.variant = variant
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, residual):
        # <<<IMPROVE:forward_stmt_1>>>
        fused = self.variant == "fused_add"
        M, N = x.shape
        out = torch.empty(
            (M, 2 * N) if fused else (M, N),
            device=x.device,
            dtype=x.dtype,
        )

        if N <= 4096:
            _rmsnorm_single_block_kernel[(M,)](
                x,
                weight,
                residual,
                out,
                M,
                N,
                self.eps,
                FUSED=fused,
                BLOCK=triton.next_power_of_2(N),
                num_warps=4,
            )
        else:
            _rmsnorm_fused_kernel[(M,)](
                x,
                weight,
                residual,
                out,
                M,
                N,
                self.eps,
                FUSED=fused,
                BLOCK=1024,
                num_warps=4,
            )
        return out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        norm_input = x + residual if fused else x
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        residual_out = norm_input
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        xf = norm_input.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        wf = weight.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        mean_sq = (xf * xf).mean(dim=-1, keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        y = (xf * torch.rsqrt(mean_sq + self.eps) * wf).to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return torch.cat([y, residual_out], dim=-1) if fused else y
        # <<<END_IMPROVE>>>
