import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _varlen_flash_attention_kernel(
    q_ptr, k_ptr, v_ptr, out_ptr,
    cu_seqlens_q_ptr, cu_seqlens_k_ptr,
    num_seqs,
    causal_ptr,
    nheads_q, nheads_k, group, head_dim,
    sm_scale,
    q_stride0, q_stride1, q_stride2,
    k_stride0, k_stride1, k_stride2,
    v_stride0, v_stride1, v_stride2,
    o_stride0, o_stride1, o_stride2,
    BLOCK_Q: tl.constexpr,
    BLOCK_K: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    pid_q = tl.program_id(0)
    head = tl.program_id(1)

    remaining = pid_q
    found = 0
    q_start = 0
    k_start = 0
    seqlen_q = 0
    seqlen_k = 0

    for seq_idx in tl.range(0, num_seqs):
        seq_q_start = tl.load(cu_seqlens_q_ptr + seq_idx)
        seq_q_end = tl.load(cu_seqlens_q_ptr + seq_idx + 1)
        seq_k_start = tl.load(cu_seqlens_k_ptr + seq_idx)
        seq_k_end = tl.load(cu_seqlens_k_ptr + seq_idx + 1)

        current_lq = seq_q_end - seq_q_start
        current_lk = seq_k_end - seq_k_start
        tile_count = (current_lq + BLOCK_Q - 1) // BLOCK_Q
        take = (found == 0) & (remaining < tile_count)

        q_start = tl.where(take, seq_q_start, q_start)
        k_start = tl.where(take, seq_k_start, k_start)
        seqlen_q = tl.where(take, current_lq, seqlen_q)
        seqlen_k = tl.where(take, current_lk, seqlen_k)
        remaining = tl.where(
            (found == 0) & ~take,
            remaining - tile_count,
            remaining,
        )
        found = found | take

    if found == 0:
        return

    causal = tl.load(causal_ptr)
    q_rows = remaining * BLOCK_Q + tl.arange(0, BLOCK_Q)
    d_offsets = tl.arange(0, BLOCK_D)
    q_mask = q_rows < seqlen_q
    d_mask = d_offsets < head_dim

    q_offsets = (
        (q_start + q_rows[:, None]) * q_stride0
        + head * q_stride1
        + d_offsets[None, :] * q_stride2
    )
    q = tl.load(
        q_ptr + q_offsets,
        mask=q_mask[:, None] & d_mask[None, :],
        other=0.0,
    )

    kv_head = head // group
    delta = seqlen_k - seqlen_q

    running_m = tl.where(
        q_mask,
        tl.full((BLOCK_Q,), float("-inf"), tl.float32),
        tl.zeros((BLOCK_Q,), tl.float32),
    )
    running_l = tl.zeros((BLOCK_Q,), tl.float32)
    accumulator = tl.zeros((BLOCK_Q, BLOCK_D), tl.float32)

    query_tile_end = tl.minimum((remaining + 1) * BLOCK_Q, seqlen_q)
    key_loop_end = tl.where(
        causal != 0,
        tl.minimum(seqlen_k, query_tile_end + delta),
        seqlen_k,
    )

    for k_block in tl.range(0, key_loop_end, BLOCK_K):
        k_cols = k_block + tl.arange(0, BLOCK_K)
        k_mask = k_cols < seqlen_k

        k_offsets = (
            (k_start + k_cols[:, None]) * k_stride0
            + kv_head * k_stride1
            + d_offsets[None, :] * k_stride2
        )
        v_offsets = (
            (k_start + k_cols[:, None]) * v_stride0
            + kv_head * v_stride1
            + d_offsets[None, :] * v_stride2
        )

        k_tile = tl.load(
            k_ptr + k_offsets,
            mask=k_mask[:, None] & d_mask[None, :],
            other=0.0,
        )
        v_tile = tl.load(
            v_ptr + v_offsets,
            mask=k_mask[:, None] & d_mask[None, :],
            other=0.0,
        ).to(tl.float32)

        logits = tl.dot(q, tl.trans(k_tile), out_dtype=tl.float32) * sm_scale
        valid = q_mask[:, None] & k_mask[None, :]
        causal_valid = k_cols[None, :] <= (q_rows[:, None] + delta)
        valid = valid & ((causal == 0) | causal_valid)
        logits = tl.where(valid, logits, float("-inf"))

        block_m = tl.max(logits, axis=1)
        has_valid = tl.max(valid, axis=1)
        block_m = tl.where(has_valid, block_m, running_m)
        new_m = tl.maximum(running_m, block_m)

        old_scale = tl.where(
            running_m == float("-inf"),
            0.0,
            tl.exp(running_m - new_m),
        )
        safe_new_m = tl.where(new_m == float("-inf"), 0.0, new_m)
        block_scale = tl.exp(logits - safe_new_m[:, None])
        block_scale = tl.where(valid, block_scale, 0.0)

        new_l = running_l * old_scale + tl.sum(block_scale, axis=1)
        accumulator = (
            accumulator * old_scale[:, None]
            + tl.dot(block_scale, v_tile, input_precision="ieee")
        )

        running_m = new_m
        running_l = new_l

    accumulator = accumulator / running_l[:, None]

    out_offsets = (
        (q_start + q_rows[:, None]) * o_stride0
        + head * o_stride1
        + d_offsets[None, :] * o_stride2
    )
    tl.store(
        out_ptr + out_offsets,
        accumulator,
        mask=q_mask[:, None] & d_mask[None, :],
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Variable-length (varlen) FlashAttention v2 forward pass: dense Q/K/V is
    segmented by cu_seqlens and each segment computes scaled dot-product attention
    independently, supporting MHA/GQA and a causal
    mask.

    Mathematical definition: for segment b of the batch (let
    L_q = cu_seqlens_q[b+1]-cu_seqlens_q[b],
    L_k = cu_seqlens_k[b+1]-cu_seqlens_k[b]; the task constrains 0 < L_q <= L_k, and
    g = num_q_heads // num_kv_heads):
      scores[h,i,j] = sm_scale * <q[start_q+i,h,:], k[start_k+j,h//g,:]>
      with causal=1 a bottom-right-aligned causal mask is applied: positions with
      j > i + (L_k - L_q) are set to -inf (i.e. query position i only attends to key
      positions j <= i + L_k - L_q); with causal=0 no mask is applied.
      p[h,i,:] = softmax_j(scores[h,i,:])
      out[start_q+i,h,:] = sum_j p[h,i,j] * v[start_k+j,h//g,:]
    The softmax uses a numerically stable formulation; intermediates are accumulated
    in float32 and the output is cast back to the input dtype.
    Boundary behaviour: the task guarantees L_q >= 1 for every segment, so the
    softmax denominator is always positive and no row is fully masked; segments
    other than the last do not affect each other.

    Input/output specification:
      q            [total_q, num_q_heads, head_dim]  float16/bfloat16
      k, v         [total_k, num_kv_heads, head_dim] same dtype as q
      cu_seqlens_q [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_q
      cu_seqlens_k [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_k
      causal       0-dim int32 tensor, 1 = causal mask, 0 = no mask
      out          [total_q, num_q_heads, head_dim], same dtype as q
    Global constraints: num_q_heads is an integer multiple of num_kv_heads (GQA;
    equality means MHA); 1 <= head_dim <= 256; for every sequence
    0 < L_q <= L_k.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: varlen forward, non-quantized inputs, no bias/ALiBi, no dropout, no
    LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, cu_seqlens_q, cu_seqlens_k, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        cu_seqlens_q = cu_seqlens_q.to(
            device=q.device, dtype=torch.int32
        ).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        cu_seqlens_k = cu_seqlens_k.to(
            device=q.device, dtype=torch.int32
        ).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal, device=q.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        is_causal = causal.to(device=q.device, dtype=torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        nheads_q = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        nheads_k = k.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        group = nheads_q // nheads_k
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert nheads_q == nheads_k * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        num_seqs = int(cu_seqlens_q.numel()) - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        head_dim = q.shape[2]
        if head_dim <= 32:
            block_d = 32
        elif head_dim <= 64:
            block_d = 64
        elif head_dim <= 128:
            block_d = 128
        else:
            block_d = 256

        q_stride0, q_stride1, q_stride2 = q.stride()
        k_stride0, k_stride1, k_stride2 = k.stride()
        v_stride0, v_stride1, v_stride2 = v.stride()
        o_stride0, o_stride1, o_stride2 = out.stride()

        grid = (
            triton.cdiv(q.shape[0], 32) + num_seqs - 1,
            nheads_q,
        )
        _varlen_flash_attention_kernel[grid](
            q, k, v, out,
            cu_seqlens_q, cu_seqlens_k,
            num_seqs,
            is_causal,
            nheads_q, nheads_k, group, head_dim,
            self.sm_scale,
            q_stride0, q_stride1, q_stride2,
            k_stride0, k_stride1, k_stride2,
            v_stride0, v_stride1, v_stride2,
            o_stride0, o_stride1, o_stride2,
            BLOCK_Q=32,
            BLOCK_K=64,
            BLOCK_D=block_d,
            num_warps=4,
            num_stages=2,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
