import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _batched_gemm_kernel(
    x_ptr,
    w_ptr,
    bias_ptr,
    out_ptr,
    B,
    M,
    N,
    K,
    stride_xb,
    stride_xm,
    stride_xk,
    stride_wb,
    stride_wn,
    stride_wk,
    stride_ob,
    stride_om,
    stride_on,
    HAS_BIAS: tl.constexpr,
    OUT_FP16: tl.constexpr,
    BLOCK_M: tl.constexpr = 64,
    BLOCK_N: tl.constexpr = 64,
    BLOCK_K: tl.constexpr = 32,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    pid_b = tl.program_id(2)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    m_mask = offs_m < M
    n_mask = offs_n < N
    mn_mask = m_mask[:, None] & n_mask[None, :]

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for k_start in tl.range(0, K, BLOCK_K):
        k = k_start + offs_k
        x_offsets = (
            pid_b * stride_xb
            + offs_m[:, None] * stride_xm
            + k[None, :] * stride_xk
        )
        w_offsets = (
            pid_b * stride_wb
            + offs_n[:, None] * stride_wn
            + k[None, :] * stride_wk
        )

        x_val = tl.load(
            x_ptr + x_offsets,
            mask=m_mask[:, None] & (k[None, :] < K),
            other=0.0,
        ).to(tl.bfloat16)
        w_val = tl.load(
            w_ptr + w_offsets,
            mask=n_mask[:, None] & (k[None, :] < K),
            other=0.0,
        ).to(tl.bfloat16)
        acc += tl.dot(x_val, tl.trans(w_val))

    if HAS_BIAS:
        bias_offsets = pid_b * N + offs_n
        bias_val = tl.load(
            bias_ptr + bias_offsets,
            mask=n_mask,
            other=0.0,
        ).to(tl.bfloat16)
        rounded_acc = acc.to(tl.bfloat16).to(tl.float32)
        rounded_bias = bias_val.to(tl.float32)
        bias_sum = rounded_acc + rounded_bias[None, :]
        result = bias_sum.to(tl.bfloat16)
        if OUT_FP16:
            result = result.to(tl.float16)
    else:
        if OUT_FP16:
            result = acc.to(tl.float16)
        else:
            result = acc.to(tl.bfloat16)

    out_offsets = (
        pid_b * stride_ob
        + offs_m[:, None] * stride_om
        + offs_n[None, :] * stride_on
    )
    tl.store(out_ptr + out_offsets, result, mask=mn_mask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Batch-dimension bf16 GEMM: computes x[b] @ weight[b]^T independently for
    every matrix in the batch.

    Mathematical definition (independent per b in the batch, B/M/N/K >= 1):
      acc[b, m, n] = sum_k x[b, m, k] * weight[b, n, k]    (float32 accumulation)
      out[b, m, n] = acc[b, m, n] + bias[b, 0, n]          (optional bias)
    weight is stored row-major as (B, N, K), so the computation is equivalent to a
    transposed GEMM (each output channel corresponds to one row of weight). The
    bias fusion order follows GEMM kernel convention: the float32 accumulated
    result is first cast to the input dtype (bfloat16), bias is then added
    (bfloat16 arithmetic), and finally the result is cast to the output dtype. With
    no bias it is cast directly. Boundary behaviour: B/M/N/K may be any value >= 1
    (including the minimal 1x1x1 size) and the dimensions may be
    non-powers-of-two, with no alignment requirement on any of them.

    Input/output specification:
      x      bfloat16  (B, M, K)  the activation matrix
      weight bfloat16  (B, N, K)  the weight matrix (row-major, transposed-GEMM semantics)
      bias   bfloat16  (B, 1, N)  optional; when use_bias=False a placeholder tensor is
                                  passed and ignored
      out    output dtype (B, M, N), where the dtype is set by __init__'s out_dtype
                                  (bfloat16 / float16)

    Implementation constraints (violations are scored as failures):
      - The core computation (the bf16 GEMM multiply-accumulate and the bias fusion)
        must be completed inside the submitted file; calling torch.matmul /
        torch.bmm / torch.mm / torch.addmm / torch.baddbmm / torch.einsum /
        F.linear / functional.linear / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; the bias branch follows the fusion
        order above; cast the output to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward; the input
        values (small integer codes and values representable in bfloat16) are all
        exactly representable in fp32, so .to(torch.bfloat16) at the entry point
        recovers them losslessly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: TN layout (x row-major (B,M,K), weight row-major (B,N,K)), no
    split-K, no quantization component at all (pure bf16 inputs, no scale
    dequantization).
    """
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        # x is converted to bfloat16 inside the Triton operand loads.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # weight is converted to bfloat16 inside the Triton operand loads.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        bias = bias if self.use_bias else None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        B, M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = weight.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == weight.shape[2], "x and weight must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        out = torch.empty((B, M, N), device=x.device, dtype=self.out_dtype)
        bias_ptr = bias if bias is not None else x
        grid = (triton.cdiv(M, 64), triton.cdiv(N, 64), B)
        _batched_gemm_kernel[grid](
            x,
            weight,
            bias_ptr,
            out,
            B,
            M,
            N,
            K,
            x.stride(0),
            x.stride(1),
            x.stride(2),
            weight.stride(0),
            weight.stride(1),
            weight.stride(2),
            out.stride(0),
            out.stride(1),
            out.stride(2),
            HAS_BIAS=self.use_bias,
            OUT_FP16=(self.out_dtype == torch.float16),
            BLOCK_M=64,
            BLOCK_N=64,
            BLOCK_K=32,
            num_warps=8,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        return out
        # <<<END_IMPROVE>>>
