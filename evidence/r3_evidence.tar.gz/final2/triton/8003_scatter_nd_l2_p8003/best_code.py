import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _copy_values(Data, Out, N: tl.constexpr, BLOCK: tl.constexpr):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    mask = offsets < N
    values = tl.load(Data + offsets, mask=mask, other=0)
    tl.store(Out + offsets, values, mask=mask)


@triton.jit
def _write_updates(
    Indices, Updates, Out,
    K: tl.constexpr,
    RANK: tl.constexpr,
    DATA_STRIDES,
    INDEX_STRIDE0: tl.constexpr,
    INDEX_STRIDE1: tl.constexpr,
    BLOCK: tl.constexpr,
):
    rows = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    mask = rows < K
    offsets = tl.full((BLOCK,), 0, tl.int32)
    for d in tl.static_range(RANK):
        coordinate = tl.load(
            Indices + rows * INDEX_STRIDE0 + d * INDEX_STRIDE1,
            mask=mask,
            other=0,
        ).to(tl.int32)
        offsets += coordinate * DATA_STRIDES[d]
    values = tl.load(Updates + rows, mask=mask, other=0)
    tl.store(Out + offsets, values, mask=mask)


@triton.jit
def _copy_with_sparse_updates(
    Data, Indices, Updates, Out,
    N: tl.constexpr,
    K: tl.constexpr,
    RANK: tl.constexpr,
    DATA_STRIDES,
    INDEX_STRIDE0: tl.constexpr,
    INDEX_STRIDE1: tl.constexpr,
    BLOCK: tl.constexpr,
):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    mask = offsets < N
    values = tl.load(Data + offsets, mask=mask, other=0)
    for k in tl.static_range(K):
        destination = tl.full((), 0, tl.int32)
        for d in tl.static_range(RANK):
            coordinate = tl.load(
                Indices + k * INDEX_STRIDE0 + d * INDEX_STRIDE1
            ).to(tl.int32)
            destination += coordinate * DATA_STRIDES[d]
        update = tl.load(Updates + k)
        values = tl.where(offsets == destination, update, values)
    tl.store(Out + offsets, values, mask=mask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    ScatterND: the index-write family that overwrites positions of `data`
    with `updates` according to integer index tuples.

    Semantics: data has shape (S_0, ..., S_{r-1}) where r is its rank; indices is
    an int64 tensor of shape (K, r) -- each row is a full coordinate tuple that
    picks exactly one position in data; updates has shape (K,) and the same dtype
    as data. The output out has the same shape and dtype as data:
        out[indices[k,0], ..., indices[k,r-1]] = updates[k]
            (hit positions: overwritten, the original value is discarded and
             replaced by the corresponding element of updates)
        all other positions out[i_0, ..., i_{r-1}] = data[i_0, ..., i_{r-1}]
            (misses: the original value is preserved bit-for-bit)
    The write semantics is overwrite, not accumulate; the K coordinate tuples are
    pairwise distinct (the generator samples without replacement), so every data
    element is written at most once. Which write wins for duplicate coordinate
    tuples is undefined behaviour (mainstream frameworks leave the write order
    for duplicate indices undefined either way), and duplicate tuples are outside
    this task's input domain -- the implementation need not define behaviour for
    them, and must not let deduplication / sorting or any other preprocessing
    change the overwrite result for distinct tuples.

    Input/output specification:
        data    float32 / float16 / bfloat16, contiguous, ndim in [1, 6],
                every dimension >= 1, total element count <= 2^23; values are
                ordinary randn magnitude (no inf/NaN)
        indices int64 (K, r) with r = data rank, 1 <= K <= the total element
                count of data; every index value lies in [0, S_d) and the K
                coordinate tuples are pairwise distinct
        updates same dtype as data, shape (K,), contiguous
        out     a single tensor, same shape / dtype as data, contiguous -- this
                operator is naturally single-output, so no multi-output packing is
                needed. forward must return a single tensor (the evaluator
                compares .shape / allclose on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (indices are small non-negative integers < 2^24 and exactly
        representable in fp32, so they are recovered losslessly; fp16/bf16 ->
        fp32 is also lossless). The offline final audit passes inputs natively in
        their declared dtype -- the implementation must be correct for both.

    Boundary behaviour: K=1, K equal to the total element count of data (a full
    permutation, every element written), ndim=1 (indices shaped (K, 1)), and
    shapes with non-power-of-two / prime lengths or axes of length 1 must all be
    handled correctly; the output must be a fresh tensor and must not modify
    data / indices / updates in place.

    Implementation constraints (violations are scored as failures):
        - The core computation (r-dimensional coordinate -> linear offset address
          computation, reading updates, and moving the original values out for
          miss positions) must be completed with a Triton kernel inside the
          submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Pure-movement contract: miss positions match data bit-for-bit and hit
          positions match updates bit-for-bit (bit patterns preserved); no
          numeric transformation may be introduced.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.scatter / .scatter( / .scatter_( / scatter_add / scatter_reduce /
    index_put / torch.put( / .put_( / index_copy / torch_scatter / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, data, indices, updates):
        # <<<IMPROVE:forward_stmt_1>>>
        N = data.numel()
        K = updates.numel()
        rank = data.ndim
        data_strides = tuple(data.stride())
        index_stride0, index_stride1 = indices.stride()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        out = torch.empty_like(data)
        use_sparse_fusion = (K < N and K <= 4)
        if use_sparse_fusion:
            _copy_with_sparse_updates[(triton.cdiv(N, 1024),)](
                data, indices, updates, out, N, K, rank, data_strides,
                index_stride0, index_stride1, BLOCK=1024, num_warps=4,
            )
        elif K < N:
            copy_block = 4096 if N >= 262144 else 1024
            _copy_values[(triton.cdiv(N, copy_block),)](
                data, out, N, BLOCK=copy_block, num_warps=4,
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        if not use_sparse_fusion:
            _write_updates[(triton.cdiv(K, 256),)](
                indices, updates, out, K, rank, data_strides,
                index_stride0, index_stride1, BLOCK=256, num_warps=4,
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return out
        # <<<END_IMPROVE>>>
