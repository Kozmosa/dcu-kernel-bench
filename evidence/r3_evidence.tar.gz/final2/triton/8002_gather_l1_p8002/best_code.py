import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _selection_kernel(
    Data, Indices, Out,
    N: tl.constexpr,
    A: tl.constexpr,
    S: tl.constexpr,
    K: tl.constexpr,
    ELEMENTS: tl.constexpr,
    BLOCK: tl.constexpr,
    USE_INT32: tl.constexpr,
):
    if USE_INT32:
        t = tl.program_id(0).to(tl.int32) * BLOCK + tl.arange(0, BLOCK)
    else:
        t = tl.program_id(0).to(tl.int64) * BLOCK + tl.arange(0, BLOCK)
    valid = t < N
    outer = t // (K * S)
    inner = t % S
    if ELEMENTS:
        index_offset = t
    else:
        index_offset = (t // S) % K
    if USE_INT32:
        selected = tl.load(Indices + index_offset, mask=valid, other=0).to(tl.int32)
    else:
        selected = tl.load(Indices + index_offset, mask=valid, other=0).to(tl.int64)
    address = outer * (A * S) + selected * S + inner
    value = tl.load(Data + address, mask=valid, other=0)
    tl.store(Out + t, value, mask=valid)


@triton.jit
def _slice_selection_kernel(
    Data, Indices, Out,
    A: tl.constexpr,
    S: tl.constexpr,
    K: tl.constexpr,
    TILES: tl.constexpr,
    BLOCK: tl.constexpr,
    USE_INT32: tl.constexpr,
):
    if USE_INT32:
        p = tl.program_id(0).to(tl.int32)
    else:
        p = tl.program_id(0).to(tl.int64)
    row = p // TILES
    tile = p % TILES
    outer = row // K
    j = row % K
    lane = tile * BLOCK + tl.arange(0, BLOCK)
    if USE_INT32:
        selected = tl.load(Indices + j).to(tl.int32)
    else:
        selected = tl.load(Indices + j).to(tl.int64)
    address = outer * (A * S) + selected * S + lane
    value = tl.load(Data + address, mask=lane < S, other=0)
    tl.store(Out + row * S + lane, value, mask=lane < S)


def _launch_selection(data, indices, axis, variant):
    a = data.shape[axis]
    s = 1
    for dimension in data.shape[axis + 1:]:
        s *= dimension
    elements = variant == "gather_elements"
    k = indices.shape[axis] if elements else indices.shape[0]
    shape = tuple(indices.shape) if elements else (
        tuple(data.shape[:axis]) + (k,) + tuple(data.shape[axis + 1:])
    )
    out = torch.empty(shape, device=data.device, dtype=data.dtype)
    n = out.numel()
    block = 256 if n < 65536 else 1024
    padded_n = triton.cdiv(n, block) * block
    use_int32 = (
        padded_n <= 2147483647
        and a * s <= 2147483647
        and k * s <= 2147483647
        and data.numel() <= 2147483647
    )
    if not elements and s >= 256:
        tiles = triton.cdiv(s, 256)
        programs = (n // s) * tiles
        slice_int32 = (
            use_int32
            and programs <= 2147483647
            and tiles * 256 <= 2147483647
            and n + 255 <= 2147483647
            and data.numel() + 255 <= 2147483647
        )
        _slice_selection_kernel[(programs,)](
            data, indices, out, a, s, k, tiles, 256,
            USE_INT32=slice_int32, num_warps=4
        )
    else:
        _selection_kernel[(triton.cdiv(n, block),)](
            data, indices, out, n, a, s, k, elements, block,
            USE_INT32=use_int32, num_warps=4
        )
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Gather / GatherElements: the index-movement family that selects elements
    along a given axis by integer index.

    The __init__ parameter `variant` selects one of two paths; their semantics
    are defined as follows:
        "gather" (select along an axis): `indices` is a 1-D integer vector of
            arbitrary length K;
            out[i_0, ..., i_{axis-1}, j, i_{axis+1}, ...] =
                data[i_0, ..., i_{axis-1}, indices[j], i_{axis+1}, ...]
            i.e. indices[j] picks one whole slice along dimension `axis` at a
            time; the output shape equals the data shape with dimension `axis`
            replaced by K.
        "gather_elements" (element-wise selection with a same-shaped index):
            `indices` has the same rank as data, with every dimension equal to
            data except dimension `axis` (whose length K may differ from data);
            out[i_0, ..., i_{n-1}] = data[i_0, ..., m, ..., i_{n-1}] where
            m = indices[i_0, ..., i_{n-1}] -- each output element takes its own
            subscript along `axis`; the output shape equals the indices shape.
    The difference: gather's index is a 1-D vector that decides how a whole
    slice along `axis` is selected at once; gather_elements' index has the same
    shape as the output and specifies the subscript along `axis` per element.
    The __init__ parameter `axis` sets the selection dimension (torch
    convention: non-negative counts from 0, negative counts from the end),
    defaulting to 1.

    Numeric contract: this operator is pure index movement with no arithmetic.
    A correct implementation produces an output bit-identical to the selected
    elements of the input (bit patterns preserved; no dtype conversion, no
    numeric operation).

    Input/output specification:
        data    float32 / float16 / bfloat16, contiguous, ndim in [1, 4],
                every dimension >= 1, total element count <= 2^23; values are
                ordinary randn magnitude (no inf/NaN)
        indices an integer tensor: for variant="gather" an int64 1-D tensor
                (length K >= 1); for variant="gather_elements" an int32 tensor
                with the same rank as data (shape constraints above); every
                index value lies in [0, data.shape[axis]) -- the input contains
                no out-of-range index
        out     a single tensor, same dtype as data, contiguous: for gather its
                shape is the data shape with dimension `axis` replaced by K;
                for gather_elements its shape is the indices shape. forward must
                return a single tensor (the evaluator compares .shape /
                allclose on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (indices are small non-negative integers < 2^24 and are exactly
        representable in fp32, so they are recovered losslessly; fp16/bf16 ->
        fp32 is also lossless). The offline final audit passes inputs natively
        in their declared dtype -- the implementation must be correct for both.

    Boundary behaviour: K=1, K different from data.shape[axis], an axis of
    length 1, non-power-of-two / prime lengths, and repeated indices hitting the
    same element must all be handled correctly; a negative `axis` follows the
    torch convention.

    Implementation constraints (violations are scored as failures):
        - The core computation (index expansion / address computation plus
          load/store at those addresses) must be completed with a Triton kernel
          inside the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Pure-movement contract: the output is bit-identical to the selected
          elements of data (including float16 / bfloat16 bit patterns); no
          numeric transformation may be introduced.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.gather / .gather( / torch.index_select /
    .index_select( / torch.take_along_dim / .take_along_dim( /
    torch.take( / .take( (including the Tensor.take method form) /
    torch.embedding / nn.Embedding / .embedding( / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "gather", axis: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("gather", "gather_elements"), "variant must be one of gather / gather_elements"
        self.variant = variant
        self.axis = int(axis)
        # <<<END_IMPROVE>>>

    def forward(self, data, indices):
        # <<<IMPROVE:forward_stmt_1>>>
        ndim = data.dim()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        axis = self.axis % ndim
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        idx = indices
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        out = _launch_selection(data, idx, axis, self.variant)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        return out
        # <<<END_IMPROVE>>>
