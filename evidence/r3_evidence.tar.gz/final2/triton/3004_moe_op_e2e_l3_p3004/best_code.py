import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _moe_dispatch(IDS, COUNT, MAP, P: tl.constexpr, B: tl.constexpr):
    p = tl.program_id(0).to(tl.int64) * B + tl.arange(0, B).to(tl.int64)
    valid = p < P
    e = tl.load(IDS + p, valid, other=0).to(tl.int64)
    slot = tl.atomic_add(COUNT + e, 1, mask=valid).to(tl.int64)
    tl.store(MAP + e * P + slot, p, valid)


@triton.jit
def _moe_first(A, W1, COUNT, MAP, S,
               P: tl.constexpr, K: tl.constexpr, H: tl.constexpr,
               TOP: tl.constexpr, BM: tl.constexpr, BN: tl.constexpr,
               BK: tl.constexpr):
    e = tl.program_id(2).to(tl.int64)
    count = tl.load(COUNT + e)
    first_row = tl.program_id(0) * BM
    row_step = tl.num_programs(0) * BM
    for row_start in range(first_row, count, row_step):
        rows = row_start + tl.arange(0, BM)
        valid_rows = rows < count
        p = tl.load(MAP + e * P + rows.to(tl.int64),
                    valid_rows, other=0)
        m = p // TOP
        h = tl.program_id(1).to(tl.int64) * BN + tl.arange(0, BN).to(tl.int64)
        r = tl.arange(0, BK).to(tl.int64)
        gate = tl.full((BM, BN), 0, tl.float32)
        up = tl.full((BM, BN), 0, tl.float32)
        for block in range(tl.cdiv(K, BK)):
            k = block * BK + r
            av = tl.load(A + m[:, None] * K + k[None, :],
                         valid_rows[:, None] & (k[None, :] < K),
                         other=0).to(tl.float32)
            offsets = e * (2 * H * K) + h[None, :] * K + k[:, None]
            mask = (k[:, None] < K) & (h[None, :] < H)
            wg = tl.load(W1 + offsets, mask, other=0).to(tl.float32)
            wu = tl.load(W1 + offsets + H * K, mask, other=0).to(tl.float32)
            gate = tl.dot(av, wg, gate, input_precision="ieee")
            up = tl.dot(av, wu, up, input_precision="ieee")
        sigmoid = 1.0 / (1.0 + tl.exp(-gate))
        hidden = (gate * sigmoid) * up
        tl.store(S + p[:, None] * H + h[None, :], hidden,
                 valid_rows[:, None] & (h[None, :] < H))


@triton.jit
def _moe_second(S, W2, WEIGHT, COUNT, MAP, OUT,
                P: tl.constexpr, K: tl.constexpr, H: tl.constexpr,
                BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    e = tl.program_id(2).to(tl.int64)
    count = tl.load(COUNT + e)
    first_row = tl.program_id(0) * BM
    row_step = tl.num_programs(0) * BM
    for row_start in range(first_row, count, row_step):
        rows = row_start + tl.arange(0, BM)
        valid_rows = rows < count
        p = tl.load(MAP + e * P + rows.to(tl.int64),
                    valid_rows, other=0)
        k = tl.program_id(1).to(tl.int64) * BN + tl.arange(0, BN).to(tl.int64)
        r = tl.arange(0, BK).to(tl.int64)
        acc = tl.full((BM, BN), 0, tl.float32)
        for block in range(tl.cdiv(H, BK)):
            h = block * BK + r
            sv = tl.load(S + p[:, None] * H + h[None, :],
                         valid_rows[:, None] & (h[None, :] < H),
                         other=0).to(tl.float32)
            wv = tl.load(W2 + e * K * H + k[None, :] * H + h[:, None],
                         (h[:, None] < H) & (k[None, :] < K),
                         other=0).to(tl.float32)
            acc = tl.dot(sv, wv, acc, input_precision="ieee")
        weight = tl.load(WEIGHT + p, valid_rows, other=0).to(tl.float32)
        result = acc * weight[:, None]
        tl.store(OUT + p[:, None] * K + k[None, :], result,
                 valid_rows[:, None] & (k[None, :] < K))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """The full fused Mixture-of-Experts (MoE) token feed-forward path: one call
    completes the whole chain "pick experts by routing -> first grouped GEMM ->
    SwiGLU activation -> second grouped GEMM -> routing weighting".

    Operator semantics (mathematical definition and boundary behaviour):
      Inputs: activation a [M, K]; expert weight w1 [E, N, K] for the first FFN
      layer (N = 2*hidden, the first N/2 channels are gate and the last N/2 are
      up), w2 [E, K, N//2] for the second FFN layer; the routing result
      topk_ids [M, top_k] holds the expert ids selected for each token and
      topk_weights [M, top_k] the matching routing weights. For each token m and
      its j-th expert e = topk_ids[m, j]:
        gate[m,j,:] = a[m,:] @ w1[e, :N//2, :].T          # [N//2]
        up[m,j,:]   = a[m,:] @ w1[e, N//2:, :].T          # [N//2]
        h[m,j,:]    = gate * sigmoid(gate) * up           # SwiGLU, SiLU(x)=x*sigmoid(x)
        out[m,j,k]  = topk_weights[m,j] * sum_{n<N//2} h[m,j,n] * w2[e,k,n]
      that is out[m,j,:] = topk_weights[m,j] * (h[m,j,:] @ w2[e].T). The (m, j)
      pairs are mutually independent; the outputs of all top_k slots are written
      to the result, with no merge, sum or normalization across experts.
      Boundary behaviour: N is even; top_k <= E and the topk_ids values lie in
      [0, E); the top_k experts of one token are generated distinct (even should
      a duplicate appear, the pair-independent computation still holds); M and K
      are arbitrary positive integers (1 included, i.e. the GEMV case); routing
      weighting is always enabled.

    Input/output specification:
      forward(a, w1, w2, topk_weights, topk_ids) -> out
        a            [M, K]        bfloat16/float32, row-major contiguous
        w1           [E, N, K]     same dtype as a, row-major contiguous
        w2           [E, K, N//2]  same dtype as a, row-major contiguous
        topk_weights [M, top_k]    same dtype as a, row-major contiguous
        topk_ids     [M, top_k]    int64 (losslessly recoverable after the
                                   evaluator's fp32 cast)
        out          [M, top_k, K] same dtype as a
      __init__(top_k, num_experts): instance metadata only; forward always goes
      by the actual runtime tensor shapes (top_k = topk_ids.shape[1],
      E = w1.shape[0]).

    Implementation constraints (violations are scored as failures):
      - Core computation (both grouped GEMMs, the SwiGLU activation, the routing
        weighting) must be done with a Triton kernel inside the submitted file;
        calling ATen shortcuts such as torch.matmul / torch.mm / torch.bmm /
        torch.baddbmm / torch.addmm / torch.einsum /
        torch.nn.functional.linear / F.linear / torch.nn.functional.silu /
        F.silu / torch.sigmoid / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: non-quantized bfloat16/float32 activations and weights; single
    card; no expert capacity limit, no shared experts, no routing weight
    normalization; the expert dispatch/scheduling strategy (sorted alignment,
    persistent grid, etc.) is up to the implementation and is judged by the
    output tolerance.
    """
    def __init__(self, top_k: int, num_experts: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.top_k = top_k
        self.num_experts = num_experts
        # <<<END_IMPROVE>>>

    def forward(self, a, w1, w2, topk_weights, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        # Dispatch converts loaded int64 or losslessly recoverable float32 IDs.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, K = a.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        E, N, _ = w1.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        H = N // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # Valid expert IDs are guaranteed by the input contract.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # Projection kernels convert operands to float32 on load.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # The second projection converts routing weights to float32 on load.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        out = torch.empty((M, top_k, K), dtype=a.dtype, device=a.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        P = M * top_k
        row_programs = min(triton.cdiv(P, 16), max(1, triton.cdiv(P, 16 * E)))
        counts = torch.zeros((E,), device=a.device, dtype=torch.int32)
        pair_map = torch.empty((E, P), device=a.device, dtype=torch.int64)
        hidden = torch.empty((P, H), device=a.device, dtype=torch.float32)
        _moe_dispatch[(triton.cdiv(P, 256),)](
            topk_ids, counts, pair_map, P, 256, num_warps=4,
        )
        _moe_first[(row_programs, triton.cdiv(H, 32), E)](
            a, w1, counts, pair_map, hidden, P, K, H, top_k, 16, 32, 32,
            num_warps=4, enable_fp_fusion=False,
        )
        _moe_second[(row_programs, triton.cdiv(K, 32), E)](
            hidden, w2, topk_weights, counts, pair_map, out, P, K, H,
            16, 32, 32, num_warps=4, enable_fp_fusion=False,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return out
        # <<<END_IMPROVE>>>
