import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _lean_attention_kernel(
    q_ptr,
    k_ptr,
    v_ptr,
    kv_lens_ptr,
    out_ptr,
    q_stride0,
    q_stride1,
    q_stride2,
    k_stride0,
    k_stride1,
    k_stride2,
    v_stride0,
    v_stride1,
    v_stride2,
    o_stride0,
    o_stride1,
    o_stride2,
    q_len,
    num_seqs,
    num_heads,
    head_dim,
    total_kv,
    sm_scale,
    causal: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    MAX_SEQS: tl.constexpr,
    HEAD_DIM: tl.constexpr,
):
    tile_m = tl.program_id(0)
    head = tl.program_id(1)
    seq = tl.program_id(2)

    q_pos = tile_m * BLOCK_M + tl.arange(0, BLOCK_M)
    d = tl.arange(0, HEAD_DIM)
    row_mask = q_pos < q_len
    q_token = seq * q_len + q_pos

    q_offsets = (
        q_token[:, None] * q_stride0
        + head * q_stride1
        + d[None, :] * q_stride2
    )
    qv = tl.load(q_ptr + q_offsets, mask=row_mask[:, None], other=0.0)

    seq_ids = tl.arange(0, MAX_SEQS)
    seq_mask = seq_ids < num_seqs
    lengths = tl.load(kv_lens_ptr + seq_ids, mask=seq_mask, other=0)
    start_k = tl.sum(tl.where(seq_ids < seq, lengths, 0), axis=0).to(tl.int64)
    kv_len = tl.load(kv_lens_ptr + seq).to(tl.int64)

    m = tl.full((BLOCK_M,), -float("inf"), tl.float32)
    l = tl.zeros((BLOCK_M,), tl.float32)
    acc = tl.zeros((BLOCK_M, HEAD_DIM), tl.float32)

    loop_end = kv_len
    if causal:
        loop_end = tl.minimum(kv_len, (tile_m + 1) * BLOCK_M)
    for key_start in tl.range(0, loop_end, BLOCK_N):
        key_pos = key_start + tl.arange(0, BLOCK_N)
        key_valid = key_pos < kv_len
        key_abs = start_k + key_pos

        k_offsets = (
            key_abs[:, None] * k_stride0
            + head * k_stride1
            + d[None, :] * k_stride2
        )
        v_offsets = (
            key_abs[:, None] * v_stride0
            + head * v_stride1
            + d[None, :] * v_stride2
        )
        kv = tl.load(
            k_ptr + k_offsets,
            mask=key_valid[:, None],
            other=0.0,
        )
        vv = tl.load(
            v_ptr + v_offsets,
            mask=key_valid[:, None],
            other=0.0,
        ).to(tl.float32)

        scores = tl.dot(qv, tl.trans(kv), out_dtype=tl.float32) * (sm_scale * 1.4426950408889634)
        allowed = key_valid[None, :] & row_mask[:, None]
        if causal:
            allowed = allowed & (key_pos[None, :] <= q_pos[:, None])
        scores = tl.where(allowed, scores, -float("inf"))

        tile_max = tl.max(scores, axis=1)
        new_m = tl.where(row_mask, tl.maximum(m, tile_max), 0.0)
        old_scale = tl.exp2(m - new_m)
        probs = tl.exp2(scores - new_m[:, None])
        new_l = l * old_scale + tl.sum(probs, axis=1)
        acc = acc * old_scale[:, None] + tl.dot(probs, vv, input_precision="ieee")
        m = new_m
        l = new_l

    denom = tl.maximum(l, 1.0e-20)
    result = acc / denom[:, None]
    result = tl.where(row_mask[:, None], result, 0.0)

    out_offsets = (
        q_token[:, None] * o_stride0
        + head * o_stride1
        + d[None, :] * o_stride2
    )
    tl.store(
        out_ptr + out_offsets,
        result,
        mask=row_mask[:, None],
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Attention forward pass over ragged batches with variable-length KV (Lean
    Attention semantics: contiguous, non-paged KV, softmax inside a single
    kernel), covering both decode (independent KV lengths per batch entry) and
    prefill (square causal self-attention) forms, with MHA (Q/K/V head counts
    equal).

    Mathematical definition: the batch holds num_seqs sequences, sequence b has an
    actually participating KV length kv_lens[b] (>= 1), and every query segment has
    the same length q_len (total_q = num_seqs * q_len, with q stored in
    sequence-major order). Let start_k = kv_lens[0] + ... + kv_lens[b-1] (k/v are
    likewise stored contiguously in sequence-major order). For every sequence b,
    head h, query position i (0 <= i < q_len) and KV position j
    (0 <= j < kv_lens[b]):
      scores[i, j] = sm_scale * <q[b*q_len+i, h, :], k[start_k+j, h, :]>
      with causal=1 (the task constrains kv_lens[b] == q_len for all b in this form)
      a square causal mask is applied: positions with j > i are set to -inf; with
      causal=0 no mask is applied;
      p[i, :] = softmax_j(scores[i, :])
      out[b*q_len+i, h, :] = sum_j p[i, j] * v[start_k+j, h, :]
    The softmax uses a numerically stable (online) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.
    Boundary behaviour: kv_lens[b] >= 1 always holds, so the softmax denominator is
    always positive and no row is fully masked; sequences do not affect each other;
    slots in k/v beyond each sequence's cumulative length boundary do not
    participate in the computation.

    Input/output specification:
      q        [num_seqs*q_len, num_heads, head_dim]  float16/bfloat16, sequence-major
      k, v     [total_kv, num_heads, head_dim]        same dtype as q, total_kv = sum(kv_lens)
      kv_lens  [num_seqs] int32 -- the KV length actually participating per sequence
      causal   0-dim int32 tensor, 1 = square causal mask, 0 = no mask
      out      [num_seqs*q_len, num_heads, head_dim]  same dtype as q
    Global constraints: Q/K/V head counts are equal (MHA, no GQA); head_dim in
    {16, 32, 64, 128, 256} and identical across Q/K/V; q_len >= 1; with causal=1,
    kv_lens[b] == q_len for all b.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: contiguous non-paged KV, variable-length ragged batch, MHA, both
    causal states, fp16/bf16 non-quantized inputs; no GQA, no dropout, no
    bias/ALiBi, no LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, kv_lens, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        kv_lens = kv_lens.to(device=q.device, dtype=torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        is_causal = bool(int(causal.to(torch.int32)))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_heads = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        assert num_heads == k.shape[1] == v.shape[1], "MHA: Q/K/V must have the same number of heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_seqs = int(kv_lens.numel())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        q_len = q.shape[0] // num_seqs
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert q_len * num_seqs == q.shape[0], "total_q must be an integer multiple of num_seqs"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if is_causal:
            assert bool((kv_lens == q_len).all()), "with causal=1 every batch entry's kv_len must equal q_len"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        head_dim = q.shape[2]
        max_seqs = max(1, 1 << (num_seqs - 1).bit_length())
        block_m = 16
        block_n = 32
        total_kv = k.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        grid = (triton.cdiv(q_len, block_m), num_heads, num_seqs)
        _lean_attention_kernel[grid](
            q,
            k,
            v,
            kv_lens,
            out,
            q.stride(0),
            q.stride(1),
            q.stride(2),
            k.stride(0),
            k.stride(1),
            k.stride(2),
            v.stride(0),
            v.stride(1),
            v.stride(2),
            out.stride(0),
            out.stride(1),
            out.stride(2),
            q_len,
            num_seqs,
            num_heads,
            head_dim,
            total_kv,
            self.sm_scale,
            int(is_causal),
            BLOCK_M=block_m,
            BLOCK_N=block_n,
            MAX_SEQS=max_seqs,
            HEAD_DIM=head_dim,
            num_warps=4,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
