import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _mla_grouped(
    Q, KV, CS, POS, IP, IX, OUT,
    B: tl.constexpr, H: tl.constexpr, C: tl.constexpr,
    R: tl.constexpr, RD: tl.constexpr, SCALE: tl.constexpr,
    NEOX: tl.constexpr,
    QB: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
    KT: tl.constexpr, KD: tl.constexpr,
    CT: tl.constexpr, CD: tl.constexpr,
    PS: tl.constexpr, IPS: tl.constexpr, IXS: tl.constexpr,
    BC: tl.constexpr, BR: tl.constexpr,
    BH: tl.constexpr, BT: tl.constexpr,
):
    b = tl.program_id(0).to(tl.int64)
    group = tl.program_id(1)
    h = group * BH + tl.arange(0, BH)
    dc = tl.arange(0, BC)
    dr = tl.arange(0, BR)
    dt = tl.arange(0, BT)
    begin = tl.load(IP + b * IPS).to(tl.int64)
    end = tl.load(IP + (b + 1) * IPS).to(tl.int64)
    pos = tl.load(POS + b * PS).to(tl.int64)

    qlat = tl.load(
        Q + b * QB + h[:, None].to(tl.int64) * QH + dc[None, :] * QD,
        (h[:, None] < H) & (dc[None, :] < C), other=0,
    ).to(tl.float32)
    qr = tl.load(
        Q + b * QB + h[:, None].to(tl.int64) * QH + (C + dr[None, :]) * QD,
        (h[:, None] < H) & (dr[None, :] < R), other=0,
    ).to(tl.float32)
    if RD > 1:
        if NEOX:
            second = dr >= RD // 2
            pair = tl.where(second, dr - RD // 2, dr + RD // 2)
            angle = dr % (RD // 2)
        else:
            second = dr % 2 == 1
            pair = dr ^ 1
            angle = dr // 2
        co = tl.load(CS + pos * CT + angle * CD, dr < RD, other=0).to(tl.float32)
        si = tl.load(CS + pos * CT + (angle + RD // 2) * CD, dr < RD, other=0).to(tl.float32)
        qp = tl.load(
            Q + b * QB + h[:, None].to(tl.int64) * QH + (C + pair[None, :]) * QD,
            (h[:, None] < H) & (dr[None, :] < RD), other=0,
        ).to(tl.float32)
        qr = tl.where(
            dr[None, :] < RD,
            qr * co[None, :] + qp * tl.where(second, si, -si)[None, :],
            qr,
        )

    m = tl.full((BH,), -float("inf"), tl.float32)
    den = tl.zeros((BH,), tl.float32)
    acc = tl.zeros((BH, BC), tl.float32)
    for start in range(begin, end, BT):
        tok = start + dt
        rows = tl.load(IX + tok * IXS, tok < end, other=0).to(tl.int64)
        latent = tl.load(
            KV + rows[:, None] * KT + dc[None, :] * KD,
            (tok[:, None] < end) & (dc[None, :] < C), other=0,
        ).to(tl.float32)
        kr = tl.load(
            KV + rows[:, None] * KT + (C + dr[None, :]) * KD,
            (tok[:, None] < end) & (dr[None, :] < R), other=0,
        ).to(tl.float32)
        if RD > 1:
            kp = tl.load(
                KV + rows[:, None] * KT + (C + pair[None, :]) * KD,
                (tok[:, None] == end - 1) & (dr[None, :] < RD), other=0,
            ).to(tl.float32)
            kr = tl.where(
                (tok[:, None] == end - 1) & (dr[None, :] < RD),
                kr * co[None, :] + kp * tl.where(second, si, -si)[None, :],
                kr,
            )
        scores_lat = tl.sum(qlat[:, None, :] * latent[None, :, :], axis=2)
        scores_rope = tl.sum(qr[:, None, :] * kr[None, :, :], axis=2)
        scores = (scores_lat + scores_rope) * SCALE
        scores = tl.where(tok[None, :] < end, scores, -float("inf"))
        new_m = tl.maximum(m, tl.max(scores, axis=1))
        alpha = tl.exp(m - new_m)
        p = tl.exp(scores - new_m[:, None])
        den = den * alpha + tl.sum(p, axis=1)
        acc = acc * alpha[:, None] + tl.sum(
            p[:, :, None] * latent[None, :, :], axis=1
        )
        m = new_m

    tl.store(
        OUT + (b * H + h[:, None].to(tl.int64)) * C + dc[None, :],
        acc / den[:, None],
        (h[:, None] < H) & (dc[None, :] < C),
    )
    if group == 0:
        last = tl.load(IX + (end - 1) * IXS).to(tl.int64)
        kr_last = tl.load(
            KV + last * KT + (C + dr) * KD, dr < R, other=0
        ).to(tl.float32)
        if RD > 1:
            kp_last = tl.load(
                KV + last * KT + (C + pair) * KD, dr < RD, other=0
            ).to(tl.float32)
            kr_last = tl.where(
                dr < RD,
                kr_last * co + kp_last * tl.where(second, si, -si),
                kr_last,
            )
        tl.store(OUT + B * H * C + b * R + dr, kr_last, dr < R)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """DeepSeek MLA decode-phase attention with a single-token query, fusing the RoPE
    rotation, page size = 1.

    Semantics: q is the current decode step's query [B, H, c + r] (c =
    kv_lora_rank compressed nope part first, r = qk_rope_head_dim rope part q_pe
    after it). The KV cache is stored per token (page size 1): kv_cache has
    total_tokens rows, each row = [compressed latent vector (first c dims) | k_pe
    (last r dims)]; the j-th logical token of batch b lives at physical row
    kv_indices[kv_indptr[b] + j] (kv_indptr is the cumulative sum of the sequence
    lengths, starting at 0); unreferenced rows of the row pool are garbage data and
    must not take part in the computation. Value is exactly the first c columns of
    that row: the compressed part of K shares the same latent vector with V (the
    MLA structure -- every query head shares one per-token compressed KV, there is
    no separate KV head).

    For every batch b (let pos = positions[b], rd = rotary_dim, half = rd // 2):
      1. RoPE rotation: take the row [cos(half) | sin(half)] of cos_sin_cache by
         position pos. The first rd dims of q_pe are rotated and the dims after rd
         pass through unchanged; the k_pe of the last logical token
         (j = seq_len_b - 1) is likewise rotated only in its first rd dims (dims
         after rd pass through), while the k_pe of the other tokens is treated as
         already rotated and used as the raw cache value. The rotation style is
         chosen by is_neox_style:
           NEOX (rotate-half): (x1, x2) = (first half dims, last half dims)
           GPT-J (interleaved): (x1, x2) = (even dims, odd dims)
           rotation output = concat(x1*cos - x2*sin, x2*cos + x1*sin) (scattered
           back in their own order).
      2. Attention (softmax over all j = 0..seq_len_b-1):
           s[h, j] = sm_scale * ( <q_nope[b,h,:], k_lat[b,j,:]>
                                + <q_pe'[b,h,:], k_pe'[b,j,:]> )
         where ' denotes after rotation; k_pe' is the rotated value only for the
         last token and the raw cache value for the others.
           p[h, :] = softmax_j(s[h, :])
           attn_out[b, h, :] = sum_j p[h, j] * k_lat[b, j, :]
      3. k_pe_tokens[b, :] = the full rotated k_pe of the last token (r dims, for
         writing back to the cache).
    softmax is numerically stable, intermediate accumulation is float32, and the
    output is cast back to the input dtype.
    Boundary behaviour: seq_len_b >= 1 (when it equals 1 that token is "the last
    token" and its k_pe takes part in the rotation); how the KV reduction is
    organized is only an implementation detail -- any implementation numerically
    equivalent to the full softmax is acceptable; there is no logit cap, no causal
    mask (decode naturally attends the whole cache), and no quantization.

    Input/output specification:
      q              [B, H, c + r] float16/bfloat16
      kv_cache       [total_tokens, c + r] same dtype as q (token-level KV row pool)
      cos_sin_cache  [max_positions, rd] same dtype as q (first half columns cos,
                     last half columns sin; row t corresponds to position
                     t = 0,1,...)
      positions      [B] int32 (sequence position of the current query; values
                     < max_positions, independent of seq_len)
      kv_indptr      [B+1] int32 (cumulative sum of the sequence lengths: first
                     element 0, monotonically non-decreasing)
      kv_indices     [total_kv] int32 (logical token -> physical row id; values
                     < total_tokens; total_kv == kv_indptr[-1])
      out            1-D flat concatenation, length B*H*c + B*r, same dtype as q:
                     the first B*H*c entries = attn_out ([B, H, c] flattened in
                     row-major order), the last B*r entries = k_pe_tokens
                     ([B, r] flattened in row-major order)
    Global-domain constraints: rd is a power of 2 and rd <= r;
    total_tokens >= kv_indptr[-1]; each sequence seq_len_b >= 1; B, H, c, r,
    max_positions are given by the shape family.

    Implementation constraints (violations are scored as failures):
      - The core computation (RoPE rotation / KV gathering / QK^T / softmax / PV)
        must be done inside the submitted file; calling
        scaled_dot_product_attention / sdpa / flash_attn / aiter / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - The 1-D concatenation layout of the output must match the specification
        above (the evaluator compares element by element).

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, use_rope always true, non-quantized
    fp16/bf16, no logit cap, no causal mask / ALiBi / sliding window.
    """
    def __init__(self, kv_lora_rank: int, qk_rope_head_dim: int, rotary_dim: int, sm_scale=None, is_neox_style=True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.kv_lora_rank = int(kv_lora_rank)
        self.qk_rope_head_dim = int(qk_rope_head_dim)
        self.rotary_dim = int(rotary_dim)
        self.sm_scale = float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(self.kv_lora_rank + self.qk_rope_head_dim)
        self.is_neox_style = bool(is_neox_style)
        # <<<END_IMPROVE>>>

    def forward(self, q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices):
        # <<<IMPROVE:forward_stmt_1>>>
        positions = positions.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        c, rd = self.kv_lora_rank, self.rotary_dim
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        half = rd // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        B, H, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        r = D - c
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert r == self.qk_rope_head_dim, "q's last dim must equal kv_lora_rank + qk_rope_head_dim"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty(B * H * c + B * r, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        _mla_grouped[(B, triton.cdiv(H, 2))](
            q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices, out,
            B, H, c, r, rd, self.sm_scale, self.is_neox_style,
            q.stride(0), q.stride(1), q.stride(2),
            kv_cache.stride(0), kv_cache.stride(1),
            cos_sin_cache.stride(0), cos_sin_cache.stride(1),
            positions.stride(0), kv_indptr.stride(0), kv_indices.stride(0),
            triton.next_power_of_2(c),
            triton.next_power_of_2(r),
            2, 16,
            num_warps=4, enable_fp_fusion=False,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
