import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl
import triton.language.extra.libdevice as libdevice


@triton.jit
def _activation_mxfp4(X, Y, N: tl.constexpr, D: tl.constexpr,
                      W: tl.constexpr, MODE: tl.constexpr):
    row = tl.program_id(0)
    pair = tl.program_id(1)

    lanes = tl.arange(0, 64)
    cols = pair * 64 + lanes
    valid = cols < D

    a = tl.load(X + row * N + cols, mask=valid, other=0.0).to(tl.float32)
    b = tl.load(X + row * N + D + cols, mask=valid, other=0.0).to(tl.float32)

    if MODE == 0:
        act = a / (1.0 + libdevice.exp(-a))
    elif MODE == 1:
        act = (0.5 * a) * (1.0 + libdevice.erf(a * 0.7071067811865476))
    else:
        cube = (a * a) * a
        inner = 0.7978845608028654 * (a + 0.044715 * cube)
        act = (0.5 * a) * (1.0 + libdevice.tanh(inner))

    values = tl.where(valid, act * b, 0.0)
    values = tl.reshape(values, (2, 32))
    peaks = tl.max(tl.abs(values), axis=1)

    peak_bits = peaks.to(tl.uint32, bitcast=True)
    rounded_bits = (peak_bits + 0x00200000) & 0xFF800000
    rounded_exponent = ((rounded_bits >> 23) & 0xFF).to(tl.int32)

    scale = rounded_exponent - 129
    scale = tl.minimum(tl.maximum(scale, -127), 127)
    scale = tl.where(rounded_exponent == 0, -127, scale)
    scale = tl.where(rounded_exponent == 255, 127, scale)
    scale = scale.to(tl.float32)

    scale_bytes = (scale + 127.0).to(tl.uint8)
    scale_cols = D // 2 + pair * 2 + tl.arange(0, 2)
    tl.store(
        Y + row * W + scale_cols,
        scale_bytes,
        mask=(pair * 2 + tl.arange(0, 2)) < ((D + 31) // 32),
    )

    q = values * libdevice.exp2(-scale[:, None])
    bits = q.to(tl.uint32, bitcast=True)

    exponent = (bits >> 23) & 0xFF
    mantissa = bits & 0x7FFFFF

    shift = tl.maximum(126 - exponent.to(tl.int32), 0)
    sub_mantissa = (
        (0x400000 | (mantissa >> 1))
        >> tl.minimum(shift, 31)
    )
    mantissa = tl.where(exponent < 127, sub_mantissa, mantissa)

    exponent = tl.maximum(exponent, 126) - 126
    code = ((((exponent << 2) | (mantissa >> 21)) + 1) >> 1)
    code = tl.minimum(code, 7)
    code = code | ((bits >> 28) & 8)

    code = tl.reshape(code, (2, 32))
    code_pairs = tl.reshape(code, (2, 16, 2))
    packed = tl.sum(
        code_pairs << (tl.arange(0, 2)[None, None, :] * 4),
        axis=2,
    )

    packed = tl.reshape(packed, (32,))
    out_cols = pair * 32 + tl.arange(0, 32)
    tl.store(
        Y + row * W + out_cols,
        packed.to(tl.uint8),
        mask=out_cols < D // 2,
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Gated activation x SwiGLU split-half multiply x dynamic MXFP4 quantization
    fused operator.

    Input x has shape (M, N) (N is a multiple of 4). Split the last dimension in
    half: a = x[:, :N/2], b = x[:, N/2:], then first compute the gated product in
    float32 as out = act(a) * b, where act is selected by the __init__ argument
    activation (mathematical definition, all evaluated in float32):
        silu      : u * sigmoid(u)
        gelu      : 0.5 * u * (1 + erf(u * 0.7071067811865476))
        gelu_tanh : 0.5 * u * (1 + tanh(0.7978845608028654 * (u + 0.044715 * u^3)))

    Then split out along the last dimension into contiguous 32-element blocks and
    dynamically quantize each block to MXFP4 (float32 bit manipulation throughout):
      1. When N/2 is not a multiple of 32, zero-pad the right end of the last block
         up to 32 elements; the padding participates in amax.
      2. amax = max|block|; apply (bits + 0x200000) & 0xFF800000 to the float32 bit
         pattern of amax (even_round: clear the mantissa and round up to the power
         of two grid).
      3. Unbiased scale = clamp(floor(log2(amax)) - 2, -127, 127); the e8m0 byte =
         unbiased scale + 127, landing in [0, 254] (meaning 2^(byte - 127)). A
         fully zero block (including a zero-pad segment that makes amax 0) goes
         through log2(0) = -inf, is clamped to -127, and gets byte 0.
      4. q = block * 2^(-unbiased scale), each element rounded to the e2m1 grid
         {0, +-0.5, +-1, +-1.5, +-2, +-3, +-4, +-6}. Bit-level formula: take the
         float32 fields of q -- s (sign bit) / e (biased exponent) / m (23-bit
         mantissa):
             e' = max(e, 126) - 126
             m' = (e < 127) ? (0x400000 | (m >> 1)) >> (126 - e) : m (subnormal
                  rescaling)
             code = (((e' << 2) | (m' >> 21)) + 1) >> 1, then saturated to 0x7
             e2m1 code word (4 bits) = (s ? 8 : 0) | code
      5. Two adjacent e2m1 code words are packed into one uint8: the even index
         occupies the low 4 bits, the odd index the high 4 bits.

    The output is a single uint8 tensor (two segments concatenated along the last
    dimension):
        out (M, N/4 + ceil(N/64)) uint8
        first N/4 columns       : MXFP4 packed code words (two e2m1 values per byte)
        last ceil(N/64) columns : the e8m0 scale byte of each 32-element block
    Both segments are integer code words and must match exactly.

    Input/output specification:
        x    float16 / bfloat16 (M, N), contiguous, N % 4 == 0, M >= 1
             (the evaluator casts the input to fp32 before calling forward;
             fp16/bf16 -> fp32 is lossless)
        out  uint8 (M, N/4 + ceil(N/64))

    Implementation constraints (violations are scored as failures):
        - The core computation (activation, split-half multiply, per-block scale
          and e2m1 quantization, code-word packing) must be completed with a
          Triton kernel inside the submitted file; the output is uint8 code words
          with no floating-point output.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The activation, the multiply and the quantization bit manipulation all
          run in float32 and must be bit-identical to this reference implementation
          (code words and scale bytes exactly equal, no tolerance).
        - When N/2 is not a multiple of 32, handle the block tail with the zero-pad
          semantics described above.

    Forbidden: torch.nn.functional.silu / torch.nn.functional.gelu /
    torch.nn.SiLU / torch.nn.GELU / torch.sigmoid / torch.erf / torch.tanh.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, activation: str = "silu"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert activation in ("silu", "gelu", "gelu_tanh"), "activation must be one of silu / gelu / gelu_tanh"
        self.activation = activation
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, N = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        assert N % 4 == 0, "N must be a multiple of 4"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        d = N // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # The fused Triton kernel reads both input halves directly from x.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_blocks = (d + 31) // 32
        n_pairs = (n_blocks + 1) // 2
        width = d // 2 + n_blocks
        out = torch.empty((M, width), dtype=torch.uint8, device=x.device)
        mode = {"silu": 0, "gelu": 1, "gelu_tanh": 2}[self.activation]
        _activation_mxfp4[(M, n_pairs)](
            x, out, N, d, width, mode, num_warps=1, enable_fp_fusion=False
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_27>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_28>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_29>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_30>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_31>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_32>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_33>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_34>>>
        return out
        # <<<END_IMPROVE>>>
