import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _topk_one_kernel(
    x_ptr,
    values_ptr,
    indices_ptr,
    m,
    stride_x,
    stride_values,
    stride_indices,
    BLOCK: tl.constexpr,
    NUM_TILES: tl.constexpr,
):
    pid = tl.program_id(0)
    x_row = x_ptr + pid * stride_x
    values_row = values_ptr + pid * stride_values
    indices_row = indices_ptr + pid * stride_indices

    offsets = tl.arange(0, BLOCK)
    best_value = tl.full((), -float("inf"), tl.float32)
    best_index = tl.zeros((), dtype=tl.int32)

    for tile in range(NUM_TILES):
        cols = tile * BLOCK + offsets
        mask = cols < m
        vals = tl.load(x_row + cols, mask=mask, other=-float("inf"))
        tile_value = tl.max(vals, axis=0)
        tile_offset = tl.argmax(vals, axis=0)
        tile_index = tile * BLOCK + tile_offset
        choose = tile_value > best_value
        best_value = tl.where(choose, tile_value, best_value)
        best_index = tl.where(choose, tile_index, best_index)

    tl.store(values_row, best_value)
    tl.store(indices_row, best_index.to(tl.float32))


@triton.jit
def _topk_short_kernel(
    x_ptr,
    values_ptr,
    indices_ptr,
    m,
    k,
    stride_x,
    stride_values,
    stride_indices,
    BLOCK: tl.constexpr,
    K_CONST: tl.constexpr,
):
    pid = tl.program_id(0)
    x_row = x_ptr + pid * stride_x
    values_row = values_ptr + pid * stride_values
    indices_row = indices_ptr + pid * stride_indices

    offsets = tl.arange(0, BLOCK)
    mask = offsets < m
    vals = tl.load(x_row + offsets, mask=mask, other=-float("inf"))
    active = mask

    for rank in range(K_CONST):
        candidates = tl.where(active, vals, -float("inf"))
        selected_value = tl.max(candidates, axis=0)
        selected_offset = tl.argmax(candidates, axis=0)

        tl.store(values_row + rank, selected_value)
        tl.store(indices_row + rank, selected_offset.to(tl.float32))

        active = active & (offsets != selected_offset)


@triton.jit
def _topk_local_kernel(
    x_ptr,
    candidate_values_ptr,
    candidate_indices_ptr,
    m,
    num_chunks,
    k,
    stride_x,
    stride_candidate_row,
    stride_candidate_chunk,
    BLOCK: tl.constexpr,
    K_CONST: tl.constexpr,
):
    pid = tl.program_id(0)
    batch_id = pid // num_chunks
    chunk_id = pid - batch_id * num_chunks

    x_row = x_ptr + batch_id * stride_x
    chunk_values = (
        candidate_values_ptr
        + batch_id * stride_candidate_row
        + chunk_id * stride_candidate_chunk
    )
    chunk_indices = (
        candidate_indices_ptr
        + batch_id * stride_candidate_row
        + chunk_id * stride_candidate_chunk
    )

    offsets = tl.arange(0, BLOCK)
    cols = chunk_id * BLOCK + offsets
    mask = cols < m
    vals = tl.load(x_row + cols, mask=mask, other=-float("inf"))
    active = mask

    for rank in range(K_CONST):
        candidates = tl.where(active, vals, -float("inf"))
        selected_value = tl.max(candidates, axis=0)
        selected_offset = tl.argmax(candidates, axis=0)
        selected_index = chunk_id * BLOCK + selected_offset

        tl.store(chunk_values + rank, selected_value)
        tl.store(chunk_indices + rank, selected_index.to(tl.int32))

        active = active & (offsets != selected_offset)


@triton.jit
def _topk_merge_kernel(
    candidate_values_ptr,
    candidate_indices_ptr,
    values_ptr,
    indices_ptr,
    num_candidates,
    k,
    stride_candidate_row,
    stride_values,
    stride_indices,
    BLOCK: tl.constexpr,
    NUM_TILES: tl.constexpr,
    K_CONST: tl.constexpr,
):
    pid = tl.program_id(0)
    candidate_values_row = candidate_values_ptr + pid * stride_candidate_row
    candidate_indices_row = candidate_indices_ptr + pid * stride_candidate_row
    values_row = values_ptr + pid * stride_values
    indices_row = indices_ptr + pid * stride_indices

    offsets = tl.arange(0, BLOCK)
    limit = tl.full((), float("inf"), tl.float32)

    for rank in range(K_CONST):
        best_value = tl.full((), -float("inf"), tl.float32)
        best_index = tl.zeros((), dtype=tl.int32)

        for tile in range(NUM_TILES):
            candidate_offset = tile * BLOCK + offsets
            mask = candidate_offset < num_candidates
            vals = tl.load(
                candidate_values_row + candidate_offset,
                mask=mask,
                other=-float("inf"),
            )
            eligible = mask & (vals < limit)
            candidates = tl.where(eligible, vals, -float("inf"))
            tile_value = tl.max(candidates, axis=0)
            tile_offset = tl.argmax(candidates, axis=0)
            tile_index = tl.load(
                candidate_indices_row + tile * BLOCK + tile_offset,
                mask=tile_value != -float("inf"),
                other=0,
            )

            choose = tile_value > best_value
            best_value = tl.where(choose, tile_value, best_value)
            best_index = tl.where(choose, tile_index, best_index)

        tl.store(values_row + rank, best_value)
        tl.store(indices_row + rank, best_index.to(tl.float32))
        limit = best_value


def _triton_topk(x, k):
    batch, width = x.shape
    out = torch.empty((batch, 2 * k), device=x.device, dtype=torch.float32)
    values = out[:, :k]
    indices = out[:, k:]

    if k == 1:
        block = 1024
        num_tiles = (width + block - 1) // block
        _topk_one_kernel[(batch,)](
            x,
            values,
            indices,
            width,
            x.stride(0),
            values.stride(0),
            indices.stride(0),
            BLOCK=block,
            NUM_TILES=num_tiles,
            num_warps=4,
        )
        return out

    if width <= 1024:
        block = 1
        while block < width:
            block *= 2
        _topk_short_kernel[(batch,)](
            x,
            values,
            indices,
            width,
            k,
            x.stride(0),
            values.stride(0),
            indices.stride(0),
            BLOCK=block,
            K_CONST=k,
            num_warps=4 if block <= 512 else 8,
        )
        return out

    chunk_size = 1024
    num_chunks = (width + chunk_size - 1) // chunk_size
    candidate_values = torch.empty(
        (batch, num_chunks, k), device=x.device, dtype=torch.float32
    )
    candidate_indices = torch.empty(
        (batch, num_chunks, k), device=x.device, dtype=torch.int32
    )

    _topk_local_kernel[(batch * num_chunks,)](
        x,
        candidate_values,
        candidate_indices,
        width,
        num_chunks,
        k,
        x.stride(0),
        candidate_values.stride(0),
        candidate_values.stride(1),
        BLOCK=chunk_size,
        K_CONST=k,
        num_warps=8,
    )

    num_candidates = num_chunks * k
    merge_block = 1024
    merge_tiles = (num_candidates + merge_block - 1) // merge_block
    _topk_merge_kernel[(batch,)](
        candidate_values,
        candidate_indices,
        values,
        indices,
        num_candidates,
        k,
        candidate_values.stride(0),
        values.stride(0),
        indices.stride(0),
        BLOCK=merge_block,
        NUM_TILES=merge_tiles,
        K_CONST=k,
        num_warps=8,
    )
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """In-row Top-K selection: for every row of a 2-D score matrix take the k
    largest values (strictly descending) together with their original column
    indices. This operator is the selection stage of MoE gating, where top-k
    routing is applied to the expert logits.

    Operator semantics: the input x has shape (B, M) and, independently for every
    row b:
        (values[b, :], indices[b, :]) = TopK(x[b, :], k)
    values[b, :] are the k largest elements of x[b, :] in strictly descending
    order; indices[b, j] is the column index of values[b, j] inside that row
    (0 <= indices[b, j] < M, distinct within a row), that is out[b, k + j]
    satisfies x[b, out[b, k + j]] == out[b, j]. Mathematically this equals a full
    descending sort of each row followed by taking the first k values and their
    original column positions. Boundary behaviour: k = 1 degenerates to the row
    maximum and its argmax; k = M degenerates to a descending argsort of the whole
    row; with M = 1 the output is that row's only element and index 0. The
    evaluation inputs guarantee that the elements of each row are mutually
    unequal (built as a random permutation of a set of distinct values), so the
    Top-K result is uniquely determined -- the tie order of equal values is not
    part of this task's semantics.

    Implementation path hints (free choice):
      - short rows (M <= 1024): a single kernel selecting the maximum round by
        round -- each round takes the current maximum and the column index of its
        first occurrence, writes them out and then masks that position with the
        smallest float32 value, for exactly k rounds;
      - long rows (M > 1024): two stages -- cut the row into fixed-length chunks,
        run a local Top-K per chunk to obtain chunk_num*k candidates (values plus
        global column indices), then merge-sort the candidates and take the first
        k.

    Input/output specification:
        x   (B, M) float32 (the evaluator casts all inputs to fp32 before passing
            them in), contiguous, row elements mutually unequal; B >= 1,
            M >= 1 and < 2^24 (column indices are exactly representable in the
            fp32 packing), non powers of two allowed; the task scale domain is
            M in [16, 131072].
        k   constructor hyperparameter (passed via __init__), 1 <= k <= M.
        out (B, 2*k) a single float32 tensor (evaluation protocol: single-tensor
            output):
            out[:, :k]   = values (strictly descending, a bit-exact copy of the
                           input values)
            out[:, k:]   = indices (integer column indices, < 2^24, exactly
                           representable in fp32)
        The output is a pure selection result (no arithmetic), so any single bit
        of deviation is a semantic error.

    Implementation constraints (violations are scored as failures):
      - The core Top-K selection (scan / tiling / merge) must be done with a
        Triton kernel inside the submitted file, with both values and indices
        written by the kernel; numeric comparison happens in float32.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - The first k output columns must be strictly descending; the last k
        columns must be the original column indices (not chunk-local indices and
        not sort ranks).

    Disallowed list: aiter / torch.topk / torch.sort / torch.argsort /
    torch.kthvalue / torch.mode, plus the Tensor method forms of the shortcuts
    above .topk( / .sort( / .argsort( / .kthvalue( -- calling a selection
    operator directly and doing a full sort to take the first k are the same
    shortcut, so any appearance in any form fails (Triton primitives are
    unrestricted).
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, k: int = 8):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert k >= 1, "k must be >= 1"
        self.k = int(k)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        out = _triton_topk(x, self.k)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        return out
        # <<<END_IMPROVE>>>
