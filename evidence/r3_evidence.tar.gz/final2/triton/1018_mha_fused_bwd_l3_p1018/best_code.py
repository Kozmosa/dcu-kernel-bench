import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """FlashAttention backward (fused form): given the forward inputs Q/K/V and the
    upstream gradient dO, a single call computes the gradients dQ/dK/dV of the
    scaled dot-product attention forward O = softmax(scale·QK^T)·V with respect to
    Q, K and V. Supports MHA/GQA, dense fixed-length
    [batch, seqlen, heads, head_dim] (bshd) layout, non-causal (seqlen_q and
    seqlen_k may differ).

    Mathematical definition (g = num_q_heads // num_kv_heads,
    scale = 1/sqrt(head_dim), S_q/S_k are the sequence lengths of q/k, the KV head
    index for query head h is h_kv = h // g):
      S[b,h,i,j]     = scale * <q[b,i,h,:], k[b,j,h_kv,:]>
      P[b,h,i,j]     = softmax_j(S[b,h,i,:])     (non-causal, no mask)
      O[b,h,i,:]     = sum_j P[b,h,i,j] * v[b,j,h_kv,:]
      delta[b,h,i]   = <dO[b,i,h,:], O[b,h,i,:]> (= rowsum(dP∘P))
      dP[b,h,i,j]    = <dO[b,i,h,:], v[b,j,h_kv,:]>
      dS[b,h,i,j]    = P[b,h,i,j] * (dP[b,h,i,j] - delta[b,h,i])
      dQ[b,i,h,:]    = scale * sum_j dS[b,h,i,j] * k[b,j,h_kv,:]
      dK[b,j,h_kv,:] = scale * sum_{i, h: h//g = h_kv} dS[b,h,i,j] * q[b,i,h,:]
      dV[b,j,h_kv,:] = sum_{i, h: h//g = h_kv} P[b,h,i,j] * dO[b,i,h,:]
    i.e. dQ = scale·(dS·K), dK = scale·(dS^T·Q) (summed over the query heads inside
    each group of g), dV = P^T·dO (summed over the query heads inside each group of
    g). Intermediates are computed in float32 (numerically stable softmax), and
    each of the three gradients is cast back to the input dtype.
    Boundary behaviour: softmax normalizes along the k dimension, so the
    denominator is always positive; under GQA, dK/dV are the sum of the gradients
    over all query heads belonging to the same KV head, with a shape matching K/V.

    Input/output specification:
      q, do [batch, seqlen_q, num_q_heads, head_dim]  float16/bfloat16
      k, v  [batch, seqlen_k, num_kv_heads, head_dim] same dtype as q
      output: a 1-D tensor with the same dtype as q: dQ, dK, dV flattened in that
              order in their own bshd row-major layouts and then concatenated,
              length = batch*seqlen_q*num_q_heads*head_dim
                       + 2*batch*seqlen_k*num_kv_heads*head_dim
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (equal means MHA, otherwise GQA); 1 <= head_dim <= 256; seqlen_q >= 1,
    seqlen_k >= 1.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / recomputation of P and delta / chained
        gradient products) must be completed inside the submitted file; calling
        scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden, as is obtaining the
        gradients through torch.autograd or .backward().
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: non-causal, dense fixed-length batch layout, no dropout, no
    bias/ALiBi, non-quantized inputs (fp16/bf16).
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, do):
        # <<<IMPROVE:forward_stmt_1>>>
        B, seqlen_q, num_q_heads, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        _, seqlen_k, num_kv_heads, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        group = num_q_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert num_q_heads == num_kv_heads * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        qf = q.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        kf = k.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        vf = v.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        dof = do.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        kf = kf.repeat_interleave(group, dim=1) if group > 1 else kf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        vf = vf.repeat_interleave(group, dim=1) if group > 1 else vf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        scores = torch.matmul(qf, kf.transpose(-2, -1)) * self.sm_scale
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        p = torch.softmax(scores, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        o = torch.matmul(p, vf)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        delta = (dof * o).sum(dim=-1, keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        dp = torch.matmul(dof, vf.transpose(-2, -1))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        ds = p * (dp - delta)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        dq = torch.matmul(ds, kf) * self.sm_scale
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        dk_full = torch.matmul(ds.transpose(-2, -1), qf) * self.sm_scale
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        dv_full = torch.matmul(p.transpose(-2, -1), dof)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        dk = dk_full.reshape(B, num_kv_heads, group, seqlen_k, head_dim).sum(dim=2) if group > 1 else dk_full
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        dv = dv_full.reshape(B, num_kv_heads, group, seqlen_k, head_dim).sum(dim=2) if group > 1 else dv_full
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        dq_flat = dq.transpose(1, 2).to(q.dtype).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        dk_flat = dk.transpose(1, 2).to(k.dtype).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        dv_flat = dv.transpose(1, 2).to(k.dtype).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        return torch.cat([dq_flat, dk_flat, dv_flat])
        # <<<END_IMPROVE>>>
