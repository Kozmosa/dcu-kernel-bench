import torch
import torch.nn as nn
import torch.nn.functional as F

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _decode_e4m3(bits):
    bits = bits.to(tl.uint32)
    exponent = (bits >> 3) & 15
    mantissa = bits & 7
    normal_bits = ((exponent + 120) << 23) | (mantissa << 20)
    magnitude = tl.where(
        exponent == 0,
        mantissa.to(tl.float32) * 0.001953125,
        normal_bits.to(tl.float32, bitcast=True),
    )
    value_bits = magnitude.to(tl.uint32, bitcast=True) | ((bits & 128) << 24)
    value = value_bits.to(tl.float32, bitcast=True)
    return tl.where((bits & 127) == 127, float("nan"), value)


@triton.jit
def _blockscale_gemm(
    X, W, XS, WS, Y,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    GK: tl.constexpr, GN: tl.constexpr,
    SXM: tl.constexpr, SXK: tl.constexpr,
    SWN: tl.constexpr, SWK: tl.constexpr,
    SXSM: tl.constexpr, SXSK: tl.constexpr,
    SWSN: tl.constexpr, SWSK: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    m = (tl.program_id(0) * BM + tl.arange(0, BM)).to(tl.int64)
    n = (tl.program_id(1) * BN + tl.arange(0, BN)).to(tl.int64)
    rk = tl.arange(0, BK).to(tl.int64)
    acc = tl.zeros((BM, BN), dtype=tl.float32)

    for tile in range(tl.cdiv(K, BK)):
        k = tile * BK + rk
        kg = k // GK
        xm = (m[:, None] < M) & (k[None, :] < K)
        wm = (k[:, None] < K) & (n[None, :] < N)

        a = _decode_e4m3(
            tl.load(
                X.to(tl.pointer_type(tl.uint8))
                + m[:, None] * SXM
                + k[None, :] * SXK,
                mask=xm,
                other=0,
            )
        )
        b = _decode_e4m3(
            tl.load(
                W.to(tl.pointer_type(tl.uint8))
                + n[None, :] * SWN
                + k[:, None] * SWK,
                mask=wm,
                other=0,
            )
        )

        if GK % BK == 0:
            tile_kg = (tile * BK) // GK
            sa = tl.load(
                XS + m * SXSM + tile_kg * SXSK,
                mask=(m < M) & ((tile * BK) < K),
                other=0,
            ).to(tl.float32)[:, None]

            if GN % BN == 0:
                tile_n = tl.program_id(1).to(tl.int64) * BN
                sb = tl.load(
                    WS + (tile_n // GN) * SWSN + tile_kg * SWSK,
                    mask=(tile_n < N) & ((tile * BK) < K),
                    other=0,
                ).to(tl.float32)
            else:
                sb = tl.load(
                    WS + (n // GN) * SWSN + tile_kg * SWSK,
                    mask=(n < N) & ((tile * BK) < K),
                    other=0,
                ).to(tl.float32)[None, :]
        else:
            sa = tl.load(
                XS + m[:, None] * SXSM + kg[None, :] * SXSK,
                mask=xm,
                other=0,
            ).to(tl.float32)
            sb = tl.load(
                WS + (n[None, :] // GN) * SWSN + kg[:, None] * SWSK,
                mask=wm,
                other=0,
            ).to(tl.float32)

        a = a * sa
        b = b * sb
        acc = tl.dot(a, b, acc, input_precision="ieee")

    tl.store(
        Y + m[:, None] * N + n[None, :],
        acc,
        mask=(m[:, None] < M) & (n[None, :] < N),
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """8bit GEMM with 2D block-scale dequantization (fp8 activations x fp8
    weights).

    Mathematical definition: given the fp8(e4m3) code-word matrices xq (M, K),
    wq (N, K) and the float32 block scales x_scale (M, ceil(K/gk)),
    w_scale (ceil(N/gn), ceil(K/gk)), the output is
      dq_x[m, k] = xq[m, k] * x_scale[m, k // gk]
      dq_w[n, k] = wq[n, k] * w_scale[n // gn, k // gk]
      acc[m, n]  = sum_k dq_x[m, k] * dq_w[n, k]     (float32 accumulation)
      out[m, n]  = cast(acc[m, n], out_dtype)
    That is, every element is first dequantized with the block scale it belongs
    to ((m, k//gk) / (n//gn, k//gk)), then a float32 GEMM is performed
    (equivalent to the transposed GEMM xq @ wq^T, with wq row-major (N, K)).
    Scale ownership is decided element by element and is independent of the
    K-direction tile partition; when K is not divisible by gk / N is not
    divisible by gn, elements of the tail block still use the scale of the
    block they belong to (the scale count is the ceil division result); M/N/K
    >= 1, non-powers of two allowed. The dequantization multiply and the GEMM
    accumulation run in float32 throughout, and the output is finally cast to
    out_dtype.

    Input/output specification:
      x       float8_e4m3fn (M, K)             activation code words (row-major, TN layout)
      w       float8_e4m3fn (N, K)             weight code words (row-major, transposed GEMM)
      x_scale float32 (M, ceil(K/gk))          activation scale: per-M-row, K in gk blocks
      w_scale float32 (ceil(N/gn), ceil(K/gk)) weight 2D block scale (rows = N blocks, cols = K blocks)
      out     out_dtype (M, N)                 bfloat16 / float16, set by __init__
    The online evaluator casts every input to fp32 before calling forward; the
    finite values of fp8(e4m3) are exact in fp32, so the
    .to(torch.float8_e4m3fn) at the entry point recovers the code words
    losslessly.

    Final-audit compatible form: the offline final-audit harness constructs the
    model with a single argument Model(case["head_size"])
    (case["head_size"] = [group_k, group_n, out_dtype]), so the first __init__
    argument also accepts a [group_k, group_n, out_dtype] sequence and unpacks
    it in order; ModelNew must keep the same dual-form compatibility
    (constructible with either three arguments or a single sequence).

    Implementation constraints (violations are scored as failures):
      - The core computation (8bit GEMM accumulation + block-scale
        dequantization) must be completed inside the submitted file, and
        calling any ATen matmul shortcut is forbidden: torch.matmul /
        torch.bmm / torch.mm / torch.addmm / torch.einsum / torch._int_mm /
        torch._scaled_mm / F.linear / functional.linear, together with their
        torch.ops.aten.* fully qualified names and tensor-method forms
        (torch.ops.aten.mm, .mm( / .bmm( / .matmul( / .addmm( / .einsum( /
        ._int_mm( / ._scaled_mm( etc.), the matmul operator @ and the tensor
        transpose method .t() (x @ w.t() is the typical disguised form; the
        transpose should be handled with strides inside the kernel). The
        final-audit static audit scans the submitted file for those literal
        strings (docstrings excluded).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast to
        out_dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: a single matrix (no batch dimension), no bias, no splitK; the
    code-word and scale value ranges follow the task generator (code words are
    fp8 values in [0, 0.1), scales are float32 in [0, 1)).
    """
    def __init__(self, group_k=128, group_n=128, out_dtype="bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        if isinstance(group_k, (list, tuple)):
            group_k, group_n, out_dtype = group_k
        self.group_k = int(group_k)
        self.group_n = int(group_n)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, x, w, x_scale, w_scale):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.to(torch.float8_e4m3fn)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        w = w.to(torch.float8_e4m3fn)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        gk, gn = self.group_k, self.group_n
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = w.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == w.shape[1], "the K dimension of x and w must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        scale_k = (K + gk - 1) // gk
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        scale_n = (N + gn - 1) // gn
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert x_scale.shape == (M, scale_k), \
            f"x_scale shape should be ({M}, {scale_k}), got {tuple(x_scale.shape)}"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert w_scale.shape == (scale_n, scale_k), \
            f"w_scale shape should be ({scale_n}, {scale_k}), got {tuple(w_scale.shape)}"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty((M, N), device=x.device, dtype=self.out_dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        _blockscale_gemm[(triton.cdiv(M, 32), triton.cdiv(N, 32))](
            x, w, x_scale, w_scale, out,
            M, N, K, gk, gn,
            x.stride(0), x.stride(1),
            w.stride(0), w.stride(1),
            x_scale.stride(0), x_scale.stride(1),
            w_scale.stride(0), w_scale.stride(1),
            BM=32, BN=32, BK=32,
            num_warps=4,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return out
        # <<<END_IMPROVE>>>
