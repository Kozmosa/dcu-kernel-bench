import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Sigmoid top-1 routing of MoE (Mixture of Experts) gating: pick the expert
    with the highest routing score for each token out of N experts (top_k is
    always 1).

    Operator semantics: given the gating input x ([M, K], M tokens and K gating
    features) and the routing weight w ([K, N], one column per expert), for each
    token m and expert n:
        score[m, n] = sigmoid( sum_k x[m, k] * w[k, n] )
        sigmoid(z)  = 1 / (1 + exp(-z))
    top-1 routing output:
        topk_ids[m]     = argmax_n score[m, n], ties resolved to the smallest
                          expert index
        topk_weights[m] = max_n score[m, n]
    The inner product (matrix multiply) is evaluated with float32 accumulation;
    with top_k = 1 the normalization coefficient is always 1, so the weight is
    the raw sigmoid score and there is no need to divide by a sum.

    Fused shared expert column: with fused_shared_experts=True one fixed shared
    expert column is appended after the top-1 result -- the id column gets N
    (= the number of experts, outside the real expert id range) and the weight
    column gets 1.0. With False nothing is appended and the output has a single
    column.

    Input/output specification:
        x   [M, K] float16/bfloat16, contiguous; M/K/N >= 1, non powers of two
            allowed
        w   [K, N] same dtype as x, contiguous
        output  a single float32 tensor [M, 2*C], C = 1 + fused_shared_experts:
            out[:, :C] = the integers of topk_ids represented in fp32 (< 2^24,
                         exact)
            out[:, C:] = topk_weights (fp32 sigmoid scores; the fused column is
                         always 1.0)
        The evaluator casts all inputs to fp32 before passing them in (all
        inputs of this operator are floating point, so this is lossless).

    Implementation constraints (violations are scored as failures):
      - Core computation (the block-wise x * w matrix multiply, sigmoid, the
        top-1 selection and tie-break, writing back the fused shared expert
        column) must be done in a Triton kernel inside the submitted file; the
        official implementation fully fuses everything into a single kernel (the
        score matrix is never materialized), splitting it into several Triton
        kernels is not scored as a failure, but calling ATen shortcuts is.
      - Accumulation inside the matrix multiply is always float32 (inputs may be
        fp16/bf16/fp32).
      - The output is strictly float32 per the single-tensor packing protocol
        above.
      - The __init__ and forward signatures of ModelNew must not be changed.

    Disallowed list: aiter / torch.matmul / torch.bmm / torch.einsum /
    torch.nn.functional.linear / torch.topk / torch.argmax / torch.sigmoid.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, fused_shared_experts: bool = True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.fused_shared_experts = bool(fused_shared_experts)
        # <<<END_IMPROVE>>>

    def forward(self, x, w):
        # <<<IMPROVE:forward_stmt_1>>>
        assert x.dim() == 2 and w.dim() == 2, "x / w must be 2-D tensors"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        Kb, N = w.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert K == Kb, "the last dimension of x must equal the number of rows of w"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        scores = torch.sigmoid(
            torch.matmul(x.to(torch.float32), w.to(torch.float32)))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        top1_weights, top1_ids = torch.max(scores, dim=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        ids = top1_ids.to(torch.int32).unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        weights = top1_weights.unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if self.fused_shared_experts:
            # Fused shared expert column: append N to the ids (the expert count,
            # outside the real expert range) and 1.0 to the weights
            ids = torch.cat([ids, torch.full((M, 1), N, dtype=torch.int32, device=ids.device)], dim=1)
            weights = torch.cat([weights, torch.ones((M, 1), dtype=torch.float32, device=weights.device)], dim=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return torch.cat([ids.to(torch.float32), weights.to(torch.float32)], dim=1)
        # <<<END_IMPROVE>>>
