import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _pa_partition_kernel(
    query_ptr, key_ptr, value_ptr, table_ptr, lens_ptr,
    max_ptr, sum_ptr, acc_ptr,
    B, HQ, HKV, D, BS, MAX_BLOCKS, P,
    q_s0, q_s1, q_s2,
    k_s0, k_s1, k_s2, k_s3,
    v_s0, v_s1, v_s2, v_s3,
    bt_s0, bt_s1, lens_s0,
    max_s0, max_s1, max_s2,
    sum_s0, sum_s1, sum_s2,
    acc_s0, acc_s1, acc_s2, acc_s3,
    group, scale,
    BLOCK_D: tl.constexpr,
    BLOCK_T: tl.constexpr,
):
    pid = tl.program_id(0)
    part = tl.program_id(1)
    s = pid // HQ
    h = pid % HQ
    hk = h // group

    dims = tl.arange(0, BLOCK_D)
    valid_dim = dims < D
    seq_len = tl.load(lens_ptr + s * lens_s0)

    if part * BLOCK_T < seq_len:
        toks = part * BLOCK_T + tl.arange(0, BLOCK_T)
        valid_tok = toks < seq_len

        q = tl.load(
            query_ptr
            + s * q_s0
            + h * q_s1
            + dims * q_s2,
            mask=valid_dim,
            other=0.0,
        ).to(tl.float32) * scale

        logical_block = toks // BS
        slot = toks - logical_block * BS
        valid_table = logical_block < MAX_BLOCKS
        valid = valid_tok & valid_table
        physical = tl.load(
            table_ptr + s * bt_s0 + logical_block * bt_s1,
            mask=valid,
            other=0,
        ).to(tl.int64)

        k = tl.load(
            key_ptr
            + physical[:, None] * k_s0
            + hk * k_s1
            + slot[:, None] * k_s2
            + dims[None, :] * k_s3,
            mask=valid[:, None] & valid_dim[None, :],
            other=0.0,
        ).to(tl.float32)

        v = tl.load(
            value_ptr
            + physical[:, None] * v_s0
            + hk * v_s1
            + slot[:, None] * v_s2
            + dims[None, :] * v_s3,
            mask=valid[:, None] & valid_dim[None, :],
            other=0.0,
        ).to(tl.float32)

        logits = tl.sum(k * q[None, :], axis=1)
        logits = tl.where(valid, logits, float("-inf"))
        m = tl.max(logits, axis=0)
        safe_m = tl.where(tl.sum(valid.to(tl.int32), axis=0) > 0, m, 0.0)
        weights = tl.exp(logits - safe_m)
        weights = tl.where(valid, weights, 0.0)
        z = tl.sum(weights, axis=0)
        a = tl.sum(weights[:, None] * v, axis=0)
        a = tl.where(valid_dim, a, 0.0)
    else:
        m = tl.full((), float("-inf"), tl.float32)
        z = tl.full((), 0.0, tl.float32)
        a = tl.full((BLOCK_D,), 0.0, tl.float32)

    base_max = max_ptr + s * max_s0 + h * max_s1 + part * max_s2
    base_sum = sum_ptr + s * sum_s0 + h * sum_s1 + part * sum_s2
    base_acc = acc_ptr + s * acc_s0 + h * acc_s1 + part * acc_s2
    tl.store(base_max, m)
    tl.store(base_sum, z)
    tl.store(base_acc + dims * acc_s3, a, mask=valid_dim)


@triton.jit
def _pa_merge_kernel(
    max_ptr, sum_ptr, acc_ptr, out_ptr,
    B, HQ, D, P,
    max_s0, max_s1, max_s2,
    sum_s0, sum_s1, sum_s2,
    acc_s0, acc_s1, acc_s2, acc_s3,
    out_s0, out_s1, out_s2,
    BLOCK_D: tl.constexpr,
    BLOCK_P: tl.constexpr,
):
    pid = tl.program_id(0)
    s = pid // HQ
    h = pid % HQ
    parts = tl.arange(0, BLOCK_P)
    dims = tl.arange(0, BLOCK_D)
    valid_p = parts < P
    valid_d = dims < D

    m = tl.load(
        max_ptr
        + s * max_s0
        + h * max_s1
        + parts * max_s2,
        mask=valid_p,
        other=float("-inf"),
    ).to(tl.float32)
    M = tl.max(m, axis=0)
    weights = tl.exp(m - M)
    weights = tl.where(valid_p, weights, 0.0)

    z = tl.load(
        sum_ptr
        + s * sum_s0
        + h * sum_s1
        + parts * sum_s2,
        mask=valid_p,
        other=0.0,
    ).to(tl.float32)
    denom = tl.sum(weights * z, axis=0)

    a = tl.load(
        acc_ptr
        + s * acc_s0
        + h * acc_s1
        + parts[:, None] * acc_s2
        + dims[None, :] * acc_s3,
        mask=valid_p[:, None] & valid_d[None, :],
        other=0.0,
    ).to(tl.float32)
    result = tl.sum(weights[:, None] * a, axis=0) / denom
    tl.store(
        out_ptr
        + s * out_s0
        + h * out_s1
        + dims * out_s2,
        result,
        mask=valid_d,
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Paged attention for the long-context decode phase (single-token query), for both MHA and GQA.

    Operator semantics: the KV cache is paged with a fixed block_size in the
    physical block pool key_cache / value_cache, and each sequence is addressed
    indirectly through the physical block ids in block_tables; the KV length that
    actually takes part in attention for each sequence is given by seq_lens[s]
    (>=1); slots of the physical block pool that nothing references, and slots of
    the tail block beyond seq_lens[s], are garbage data and must not take part in
    the computation. For query head h of sequence s (its KV head is
    h // query_group_size; let bs = block_size, bt = block_tables):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    softmax is a numerically stable reduction over the whole
    [0, seq_lens[s]) interval.

    This task is in the long-context regime: the block-table capacity max_seq_len
    (16384 in the fixed family) far exceeds 8192, so a single sequence's KV can be
    long. How the work is parallelized is **not** a scoring criterion -- any
    implementation that is numerically equivalent to the full softmax within the
    tolerance is acceptable, and the implementation path is free. Core boundary
    cases: partially filled tail blocks (seq_len not a multiple of the block
    size), seq_len exactly a multiple of the block size, wildly different
    sequence lengths within one batch (as short as 1), and tail-block slot
    masking -- positions beyond seq_len must not contribute any probability mass.

    Input/output specification:
      query       [num_seqs, num_q_heads, head_size], fp16/bf16
      key_cache   [num_blocks, num_kv_heads, block_size, head_size], fp16/bf16
      value_cache same as key_cache
      block_tables[num_seqs, max_blocks_per_seq] int32, logical block -> physical block id
      seq_lens    [num_seqs] int32, each sequence's valid KV length, 1 <= seq_lens[s] <= max_seq_len
      output out  [num_seqs, num_q_heads, head_size], dtype matches query

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling external attention operator libraries such as
        scaled_dot_product_attention / sdpa / flash_attn, and torch.matmul /
        torch.bmm / torch.einsum / torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - Unreferenced physical blocks and slots beyond seq_len must not affect the
        output.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding
    window; the long-context regime (max(seq_lens) > 8192).
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        partition_size = 256
        max_blocks = block_tables.shape[1]
        total_tokens = max_blocks * bs
        P = (total_tokens + partition_size - 1) // partition_size
        P_PAD = triton.next_power_of_2(P)
        D_PAD = triton.next_power_of_2(D)

        part_max = torch.empty((B, H_Q, P), device=query.device, dtype=torch.float32)
        part_sum = torch.empty((B, H_Q, P), device=query.device, dtype=torch.float32)
        part_acc = torch.empty(
            (B, H_Q, P, D), device=query.device, dtype=torch.float32
        )

        grid1 = (B * H_Q, P)
        _pa_partition_kernel[grid1](
            query, key_cache, value_cache, block_tables, seq_lens,
            part_max, part_sum, part_acc,
            B, H_Q, H_KV, D, bs, max_blocks, P,
            query.stride(0), query.stride(1), query.stride(2),
            key_cache.stride(0), key_cache.stride(1),
            key_cache.stride(2), key_cache.stride(3),
            value_cache.stride(0), value_cache.stride(1),
            value_cache.stride(2), value_cache.stride(3),
            block_tables.stride(0), block_tables.stride(1), seq_lens.stride(0),
            part_max.stride(0), part_max.stride(1), part_max.stride(2),
            part_sum.stride(0), part_sum.stride(1), part_sum.stride(2),
            part_acc.stride(0), part_acc.stride(1),
            part_acc.stride(2), part_acc.stride(3),
            group, self.scale,
            BLOCK_D=D_PAD, BLOCK_T=partition_size,
            num_warps=4,
        )

        grid2 = (B * H_Q,)
        _pa_merge_kernel[grid2](
            part_max, part_sum, part_acc, out,
            B, H_Q, D, P,
            part_max.stride(0), part_max.stride(1), part_max.stride(2),
            part_sum.stride(0), part_sum.stride(1), part_sum.stride(2),
            part_acc.stride(0), part_acc.stride(1),
            part_acc.stride(2), part_acc.stride(3),
            out.stride(0), out.stride(1), out.stride(2),
            BLOCK_D=D_PAD, BLOCK_P=P_PAD,
            num_warps=4,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
