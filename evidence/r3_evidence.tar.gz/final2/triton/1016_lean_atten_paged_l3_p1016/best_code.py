import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _paged_attention(Q, K, V, T, C, O,
                     qh: tl.constexpr, qr: tl.constexpr, qd: tl.constexpr,
                     kh: tl.constexpr, kr: tl.constexpr, kd: tl.constexpr,
                     vh: tl.constexpr, vr: tl.constexpr, vd: tl.constexpr,
                     oh: tl.constexpr, or_: tl.constexpr, od: tl.constexpr,
                     th: tl.constexpr, tt: tl.constexpr, cs: tl.constexpr,
                     D: tl.constexpr, PAGE: tl.constexpr, SCALE: tl.constexpr):
    b = tl.program_id(0).to(tl.int64)
    h = tl.program_id(1).to(tl.int64)
    start = tl.load(C + (b - 1) * cs, mask=b > 0, other=0)
    end = tl.load(C + b * cs)
    i = b * 16 + tl.arange(0, 16)
    d = tl.arange(0, D)
    j = tl.arange(0, PAGE)
    query = tl.load(Q + h * qh + i[:, None] * qr + d[None, :] * qd)
    maximum = tl.full((16,), -float("inf"), tl.float32)
    denominator = tl.zeros((16,), tl.float32)
    numerator = tl.zeros((16, D), tl.float32)
    for block in range(start, end):
        physical = tl.load(T + h * th + block.to(tl.int64) * tt).to(tl.int64)
        rows = physical * PAGE + j
        key = tl.load(K + h * kh + d[:, None] * kd + rows[None, :] * kr)
        scores = tl.dot(query, key).to(tl.float32) * SCALE
        new_maximum = tl.maximum(maximum, tl.max(scores, 1))
        alpha = tl.exp(maximum - new_maximum)
        probability = tl.exp(scores - new_maximum[:, None])
        value = tl.load(V + h * vh + rows[:, None] * vr + d[None, :] * vd).to(tl.float32)
        numerator = numerator * alpha[:, None] + tl.dot(probability, value, input_precision="ieee")
        denominator = denominator * alpha + tl.sum(probability, 1)
        maximum = new_maximum
    result = numerator / denominator[:, None]
    tl.store(O + h * oh + i[:, None] * or_ + d[None, :] * od, result)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Batched decode attention over a paged KV cache: ragged batch, 16 queries per
    request, one independent physical block table per head, and blocks of the
    physical pool that nothing references are garbage data.

    The KV cache is paged with a fixed page_size: the h-th head slice of k / v
    (shape [total_kv_len, head_size]) is split into total_kv_len / page_size
    physical blocks; the block table of head h, kv_block_tables[h], lists in order
    the physical block ids referenced by each request, where the blocks
    referenced by request b are
      kv_block_tables[h, batch_num_block_n[b-1] : batch_num_block_n[b]]
    (starting at 0 for b=0; batch_num_block_n is the cumulative sum of the
    per-request block counts, and its last element is the total number of used
    blocks total_used_blocks). Physical blocks that no table entry references are
    garbage data and must not take part in the computation.

    Mathematical definition: let s_b be the starting block offset of request b
    (0 for b=0, otherwise s_b = batch_num_block_n[b-1]); its logical KV length is
    L_b = block count * page_size, and logical position j maps to physical row
    row(j) = kv_block_tables[h, s_b + j // page_size] * page_size + j % page_size.
    For every head h and request b (query row range [b*n_ctx_q, (b+1)*n_ctx_q)):
      scores[i, j] = sm_scale * <q[h, b*n_ctx_q+i, :], k[h, row(j), :]>
      p[i, :] = softmax_j(scores[i, :])
      out[h, b*n_ctx_q+i, :] = sum_j p[i, j] * v[h, row(j), :]
    softmax uses a numerically stable (online) implementation, intermediate
    accumulation is in float32, and the output is cast back to the input dtype.
    Boundary behaviour: every request's KV length is a positive integer multiple
    of page_size (a partially filled tail block is outside the task scope), so the
    softmax denominator is always positive; requests and heads do not affect each
    other.

    Input/output specification:
      q                 [num_heads, n_ctx_q * batch, head_size] float16/bfloat16
      k, v              [num_heads, total_kv_len, head_size] same dtype as q (physical block pool)
      kv_block_tables   [num_heads, total_used_blocks] int32 (0-based physical block ids,
                        values < total_kv_len / page_size)
      batch_num_block_n [batch] int32, cumulative sum of the per-request block counts, monotonically increasing
      out               [num_heads, n_ctx_q * batch, head_size] same dtype as q
    Global-domain constraints: head_size in {16, 32, 64, 128, 256}; page_size is
    fixed at 64; n_ctx_q = 16 (the decode form is fixed); each request's KV length
    is a positive integer multiple of page_size and >= page_size;
    num_kv_heads == num_q_heads (MHA, no GQA).

    Implementation constraints (violations are scored as failures):
      - The core computation (paged KV gathering / QK^T / softmax / PV) must be
        done inside the submitted file; calling external attention operator
        libraries such as scaled_dot_product_attention / sdpa / flash_attn, and
        torch.matmul / torch.bmm / torch.mm / torch.baddbmm / torch.einsum /
        torch.softmax (including ATen-equivalent shortcuts such as F.softmax,
        Tensor.matmul and the @ operator) is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - The scheduling strategy (persistent single kernel or a regular grid) is
        free to choose; only semantic correctness and performance are assessed.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: ragged-batch decode, non-quantized fp16/bf16, no causal mask, no
    ALiBi/sliding window, no GQA.
    """
    def __init__(self, head_size: int, page_size: int = 64, sm_scale=0.5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.head_size = int(head_size)
        self.page_size = int(page_size)
        self.sm_scale = float(sm_scale)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, kv_block_tables, batch_num_block_n):
        # <<<IMPROVE:forward_stmt_1>>>
        # Integer tables are read directly on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        batch_num_block_n = batch_num_block_n.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        num_heads, m_total, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        batch = int(batch_num_block_n.numel())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_ctx_q = m_total // batch
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        page = self.page_size
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert num_heads == k.shape[0] == v.shape[0], "the head counts of q/k/v must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert k.shape[1] == v.shape[1], "the KV pool lengths of k/v must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Page offsets are generated in the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        num_warps = 2 if head_dim <= 32 else 4
        _paged_attention[(batch, num_heads)](
            q, k, v, kv_block_tables, batch_num_block_n, out,
            *q.stride(), *k.stride(), *v.stride(), *out.stride(),
            *kv_block_tables.stride(), batch_num_block_n.stride(0),
            head_dim, page, self.sm_scale,
            num_warps=num_warps,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
