import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _count_chunks(X, Counts, N: tl.constexpr, C: tl.constexpr,
                  T: tl.constexpr):
    p = tl.program_id(0)
    e = p // C
    c = p % C
    i = c * T + tl.arange(0, T)
    x = tl.load(X + i, i < N, other=-1).to(tl.int32)
    flags = ((i < N) & (x == e)).to(tl.int32)
    tl.store(Counts + e.to(tl.int64) * C + c, tl.sum(flags, 0))


@triton.jit
def _count_chunk_histogram(X, Counts, N: tl.constexpr, C: tl.constexpr,
                           E: tl.constexpr, H: tl.constexpr):
    chunk = tl.program_id(0)
    i = chunk * 256 + tl.arange(0, 256)
    ids = tl.load(X + i, i < N, other=H).to(tl.int32)
    ids = tl.where(i < N, ids, H)
    # Out-of-range histogram inputs are ignored, including remainder lanes.
    counts = tl.histogram(ids, H)
    e = tl.arange(0, H)
    tl.store(Counts + e.to(tl.int64) * C + chunk, counts, e < E)


@triton.jit
def _scan_tiles(X, Prefix, Totals, K: tl.constexpr,
                NT: tl.constexpr, ALIGN: tl.constexpr, T: tl.constexpr):
    p = tl.program_id(0)
    row = p // NT
    tile = p % NT
    i = tile * T + tl.arange(0, T)
    offset = row.to(tl.int64) * K + i
    v = tl.load(X + offset, i < K, other=0)
    if ALIGN != 1:
        v = ((v + ALIGN - 1) // ALIGN) * ALIGN
    s = tl.cumsum(v, 0)
    tl.store(Prefix + offset, s - v, i < K)
    tl.store(Totals + row.to(tl.int64) * NT + tile, tl.sum(v, 0))


@triton.jit
def _add_carries(Prefix, Carries, K: tl.constexpr,
                 NT: tl.constexpr, T: tl.constexpr):
    p = tl.program_id(0)
    row = p // NT
    tile = p % NT
    i = tile * T + tl.arange(0, T)
    offset = row.to(tl.int64) * K + i
    carry = tl.load(Carries + row.to(tl.int64) * NT + tile)
    v = tl.load(Prefix + offset, i < K, other=0)
    tl.store(Prefix + offset, v + carry, i < K)


def _exclusive_scan(x, rows, width, align=1):
    tile = min(1024, triton.next_power_of_2(width))
    nt = triton.cdiv(width, tile)
    prefix = torch.empty((rows, width), dtype=torch.int32, device=x.device)
    totals = torch.empty((rows, nt), dtype=torch.int32, device=x.device)
    _scan_tiles[(rows * nt,)](
        x, prefix, totals, width, nt, align, tile, num_warps=4
    )
    if nt == 1:
        return prefix, totals
    carries, total = _exclusive_scan(totals, rows, nt)
    _add_carries[(rows * nt,)](
        prefix, carries, width, nt, tile, num_warps=4
    )
    return prefix, total


@triton.jit
def _initialize_output(Out, Total, N: tl.constexpr,
                       L1: tl.constexpr, L2: tl.constexpr,
                       T: tl.constexpr):
    i = tl.program_id(0) * T + tl.arange(0, T)
    s = tl.load(Total)
    value = tl.where(i < L1, N, tl.where(i < L1 + L2, -1, s))
    tl.store(Out + i, value.to(tl.float32), i < L1 + L2 + 1)


@triton.jit
def _scatter_chunks(X, Prefix, Starts, Out, ExpertCounts, N: tl.constexpr,
                    C: tl.constexpr, T: tl.constexpr,
                    B: tl.constexpr, L1: tl.constexpr):
    p = tl.program_id(0)
    e = p // C
    c = p % C
    i = c * T + tl.arange(0, T)
    x = tl.load(X + i, i < N, other=-1).to(tl.int32)
    match = (i < N) & (x == e)
    flags = match.to(tl.int32)
    rank = tl.cumsum(flags, 0) - 1
    base = tl.load(Starts + e)
    preceding = tl.load(Prefix + e.to(tl.int64) * C + c)
    tl.store(Out + base + preceding + rank, i.to(tl.float32), match)
    if c == 0:
        count = tl.load(ExpertCounts + e)
        blocks = (count + B - 1) // B
        block_start = base // B
        lanes = tl.arange(0, T)
        for block_base in range(0, blocks, T):
            b = block_base + lanes
            tl.store(Out + L1 + block_start + b, e.to(tl.float32), b < blocks)


def _align_triton(topk_ids, E, B):
    n = topk_ids.numel()
    l1 = n + E * (B - 1)
    l2 = triton.cdiv(l1, B)
    chunks = triton.cdiv(n, 256)
    out = torch.empty((l1 + l2 + 1,), dtype=torch.float32,
                      device=topk_ids.device)
    counts = torch.empty((E, chunks), dtype=torch.int32,
                         device=topk_ids.device)
    if 2 <= E <= 1024:
        _count_chunk_histogram[(chunks,)](
            topk_ids, counts, n, chunks, E, triton.next_power_of_2(E),
            num_warps=4
        )
    else:
        _count_chunks[(E * chunks,)](
            topk_ids, counts, n, chunks, 256, num_warps=4
        )
    chunk_prefix, expert_counts = _exclusive_scan(counts, E, chunks)
    starts, total = _exclusive_scan(expert_counts, 1, E, B)
    _initialize_output[(triton.cdiv(l1 + l2 + 1, 1024),)](
        out, total, n, l1, l2, 1024, num_warps=4
    )
    _scatter_chunks[(E * chunks,)](
        topk_ids, chunk_prefix, starts, out, expert_counts,
        n, chunks, 256, B, l1, num_warps=4
    )
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Scheduling prologue of MoE grouped GEMM: tokens bucketized per expert and
    laid out aligned to block_size.

    The input topk_ids ([num_tokens, top_k], elements are expert ids in
    [0, num_experts), duplicates allowed within a row) holds the experts the
    router selected for each token. Write the flattened index
    i = t * top_k + j (t is the token row, j the column), N = num_tokens * top_k,
    E = num_experts, B = block_size. For every expert e:
        T_e = { i : the i-th element of flattened topk_ids == e } (ascending i)
        n_blocks_e = ceil(|T_e| / B)        # aligned blocks occupied by e
        padded_e   = n_blocks_e * B         # aligned slot count of e
    Produce the three scheduling tensors of grouped GEMM:
        sorted_token_ids  length L1 = N + E*(B-1): for e = 0..E-1 in order, all
          indices of T_e (ascending), then padded_e - |T_e| fill sentinels N;
          the buffer tail [S, L1) is also sentinel N, where S = sum_e padded_e
        expert_ids        length L2 = ceil(L1/B): for e = 0..E-1 in order,
          n_blocks_e copies of e (together the first S/B positions), the tail
          [S/B, L2) filled with the -1 sentinel
        num_tokens_post_pad  scalar S (total padded slot count, always a
          multiple of B)
    grouped GEMM takes every B consecutive slots of sorted_token_ids as one
    M-tile, uses expert_ids as that tile's expert id to fetch weights, skips
    fill slots whose value is sentinel N, and num_tokens_post_pad gives the
    valid total length. This task is that scheduling prologue itself and does
    not include the GEMM.

    Boundary behaviour: an expert with |T_e| = 0 occupies 0 blocks and yields no
    sorted entry and no expert entry; when |T_e| is an exact multiple of B no
    padding is produced; the same row may select the same expert more than once
    (different flattened indices are different entries); entries within an
    expert follow ascending flattened index i.

    Input/output specification:
      topk_ids  int64/int32 (or fp32 as cast by the evaluator, integer values
                unchanged), contiguous 2D [num_tokens, top_k]; num_tokens /
                top_k >= 1 and top_k <= num_experts; E and B are __init__
                hyperparameters and >= 1, non powers of two allowed
      returns   a single 1-D float32 tensor of length L1 + L2 + 1, packed in
                three segments:
                out[:L1] = the L1 integers of sorted_token_ids (sentinel N
                           included)
                out[L1:L1+L2] = the L2 integers of expert_ids (tail -1)
                out[L1+L2] = num_tokens_post_pad (scalar S)
                -- all of them are non-negative / minus-one integers; the
                global-domain constraint L1 = N + E*(B-1) <= 2^24 guarantees
                that sentinel N, every index, every expert id and S <= L1 are
                exactly representable in fp32
      __init__ hyperparameters: num_experts (int), block_size (int).

    Implementation constraints (violations are scored as failures):
      - Core computation (bucket counting, block-count prefix sums, scatter
        writes of the layout, block expert table generation) must be done in a
        Triton kernel inside the submitted file; forward may only do input/
        output arrangement (dtype restoration, three-segment cat packing).
        Calling torch.sort / torch.argsort / torch.bincount / torch.cumsum /
        torch.histc / torch.unique / torch.repeat_interleave, or any
        third-party MoE/scheduling operator library, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Integer arithmetic throughout (no floating-point accumulation); the
        output is packed into float32 integers per the protocol above.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: the pure scheduling prologue (sorting / alignment / block table
    generation); no grouped GEMM body and no routing scores (softmax/topk are
    already done upstream).
    """
    def __init__(self, num_experts: int, block_size: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = int(num_experts)
        self.block_size = int(block_size)
        # <<<END_IMPROVE>>>

    def forward(self, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        # Input IDs are converted to int32 inside Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        E, B = self.num_experts, self.block_size
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Expert IDs satisfy the specified input domain.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        N = topk_ids.numel()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        flat_ids = topk_ids.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        out = _align_triton(topk_ids, E, B)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        L1 = N + E * (B - 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        L2 = (L1 + B - 1) // B
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        return out
        # <<<END_IMPROVE>>>
