import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _groupnorm_fwd(
    X, Scale, Bias, Out,
    D: tl.constexpr, HW: tl.constexpr, G: tl.constexpr,
    REP: tl.constexpr, TOTAL: tl.constexpr, ROWS: tl.constexpr,
    EPS: tl.constexpr, SWISH: tl.constexpr, BLOCK: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64)
    base = row * D
    offsets = tl.arange(0, BLOCK).to(tl.int64)
    channel_base = (row % G) * REP

    if D <= BLOCK:
        valid = offsets < D
        values = tl.load(X + base + offsets, valid, other=0).to(tl.float32)
        mean = tl.sum(values, 0) / D
        centered = values - mean
        squares = tl.where(valid, centered * centered, 0.0)
        variance = tl.sum(squares, 0) / D
        inv = tl.rsqrt(variance + EPS)
        tl.store(Out + TOTAL + row, mean)
        tl.store(Out + TOTAL + ROWS + row, inv)
        channels = channel_base + offsets // HW
        scale = tl.load(Scale + channels, valid, other=0).to(tl.float32)
        bias = tl.load(Bias + channels, valid, other=0).to(tl.float32)
        result = centered * inv * scale + bias
        if SWISH:
            result = result / (1.0 + tl.exp(-result))
        tl.store(Out + base + offsets, result, valid)
    else:
        sums = tl.full((BLOCK,), 0, tl.float32)
        for start in range(tl.cdiv(D, BLOCK)):
            indices = start.to(tl.int64) * BLOCK + offsets
            values = tl.load(X + base + indices, indices < D, other=0).to(tl.float32)
            sums += values
        mean = tl.sum(sums, 0) / D

        squares = tl.full((BLOCK,), 0, tl.float32)
        for start in range(tl.cdiv(D, BLOCK)):
            indices = start.to(tl.int64) * BLOCK + offsets
            valid = indices < D
            values = tl.load(X + base + indices, valid, other=0).to(tl.float32)
            centered = values - mean
            squares += tl.where(valid, centered * centered, 0.0)
        variance = tl.sum(squares, 0) / D
        inv = tl.rsqrt(variance + EPS)
        tl.store(Out + TOTAL + row, mean)
        tl.store(Out + TOTAL + ROWS + row, inv)

        for start in range(tl.cdiv(D, BLOCK)):
            indices = start.to(tl.int64) * BLOCK + offsets
            valid = indices < D
            values = tl.load(X + base + indices, valid, other=0).to(tl.float32)
            channels = channel_base + indices // HW
            scale = tl.load(Scale + channels, valid, other=0).to(tl.float32)
            bias = tl.load(Bias + channels, valid, other=0).to(tl.float32)
            result = (values - mean) * inv * scale + bias
            if SWISH:
                result = result / (1.0 + tl.exp(-result))
            tl.store(Out + base + indices, result, valid)


@triton.jit
def _groupnorm_tile_stats(
    X, Means, M2,
    D: tl.constexpr, TILES: tl.constexpr, TILE: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64)
    tile = tl.program_id(1).to(tl.int64)
    offsets = tile * TILE + tl.arange(0, TILE).to(tl.int64)
    valid = offsets < D
    values = tl.load(X + row * D + offsets, valid, other=0).to(tl.float32)
    count = tl.minimum(TILE, D - tile * TILE).to(tl.float32)
    mean = tl.sum(values, 0) / count
    centered = values - mean
    m2 = tl.sum(tl.where(valid, centered * centered, 0.0), 0)
    tl.store(Means + row * TILES + tile, mean)
    tl.store(M2 + row * TILES + tile, m2)


@triton.jit
def _groupnorm_merge_stats(
    Means, M2, Out,
    D: tl.constexpr, TILES: tl.constexpr, TILE: tl.constexpr,
    TOTAL: tl.constexpr, ROWS: tl.constexpr, EPS: tl.constexpr,
    BLOCK: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64)
    lanes = tl.arange(0, BLOCK).to(tl.int64)
    sums = tl.full((BLOCK,), 0.0, tl.float32)
    for start in range(tl.cdiv(TILES, BLOCK)):
        tiles = start.to(tl.int64) * BLOCK + lanes
        valid = tiles < TILES
        count = tl.where(valid, tl.minimum(TILE, D - tiles * TILE), 0).to(tl.float32)
        mean_tile = tl.load(Means + row * TILES + tiles, valid, other=0)
        sums += count * mean_tile
    mean = tl.sum(sums, 0) / D

    squares = tl.full((BLOCK,), 0.0, tl.float32)
    for start in range(tl.cdiv(TILES, BLOCK)):
        tiles = start.to(tl.int64) * BLOCK + lanes
        valid = tiles < TILES
        count = tl.where(valid, tl.minimum(TILE, D - tiles * TILE), 0).to(tl.float32)
        mean_tile = tl.load(Means + row * TILES + tiles, valid, other=0)
        m2_tile = tl.load(M2 + row * TILES + tiles, valid, other=0)
        delta = mean_tile - mean
        squares += m2_tile + count * (delta * delta)
    variance = tl.sum(squares, 0) / D
    inv = tl.rsqrt(variance + EPS)
    tl.store(Out + TOTAL + row, mean)
    tl.store(Out + TOTAL + ROWS + row, inv)


@triton.jit
def _groupnorm_tile_affine(
    X, Scale, Bias, Out,
    D: tl.constexpr, HW: tl.constexpr, G: tl.constexpr,
    REP: tl.constexpr, TOTAL: tl.constexpr, ROWS: tl.constexpr,
    SWISH: tl.constexpr, TILE: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64)
    tile = tl.program_id(1).to(tl.int64)
    offsets = tile * TILE + tl.arange(0, TILE).to(tl.int64)
    valid = offsets < D
    mean = tl.load(Out + TOTAL + row)
    inv = tl.load(Out + TOTAL + ROWS + row)
    values = tl.load(X + row * D + offsets, valid, other=0).to(tl.float32)
    channels = (row % G) * REP + offsets // HW
    scale = tl.load(Scale + channels, valid, other=0).to(tl.float32)
    bias = tl.load(Bias + channels, valid, other=0).to(tl.float32)
    result = (values - mean) * inv * scale + bias
    if SWISH:
        result = result / (1.0 + tl.exp(-result))
    tl.store(Out + row * D + offsets, result, valid)


@triton.jit
def _groupnorm_merge_affine(
    X, Scale, Bias, Means, M2, Out,
    D: tl.constexpr, HW: tl.constexpr, G: tl.constexpr,
    REP: tl.constexpr, TOTAL: tl.constexpr, ROWS: tl.constexpr,
    EPS: tl.constexpr, SWISH: tl.constexpr, TILES: tl.constexpr,
    TILE: tl.constexpr, MERGE_BLOCK: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64)
    tile = tl.program_id(1).to(tl.int64)
    tiles = tl.arange(0, MERGE_BLOCK).to(tl.int64)
    valid_tiles = tiles < TILES
    count = tl.where(
        valid_tiles, tl.minimum(TILE, D - tiles * TILE), 0
    ).to(tl.float32)
    partial_mean = tl.load(
        Means + row * TILES + tiles, valid_tiles, other=0
    ).to(tl.float32)
    partial_m2 = tl.load(
        M2 + row * TILES + tiles, valid_tiles, other=0
    ).to(tl.float32)
    mean = tl.sum(count * partial_mean, 0) / D
    delta = partial_mean - mean
    variance = tl.sum(partial_m2 + count * (delta * delta), 0) / D
    inv = tl.rsqrt(variance + EPS)
    if tile == 0:
        tl.store(Out + TOTAL + row, mean)
        tl.store(Out + TOTAL + ROWS + row, inv)

    offsets = tile * TILE + tl.arange(0, TILE).to(tl.int64)
    valid = offsets < D
    values = tl.load(X + row * D + offsets, valid, other=0).to(tl.float32)
    channels = (row % G) * REP + offsets // HW
    scale = tl.load(Scale + channels, valid, other=0).to(tl.float32)
    bias = tl.load(Bias + channels, valid, other=0).to(tl.float32)
    result = (values - mean) * inv * scale + bias
    if SWISH:
        result = result / (1.0 + tl.exp(-result))
    tl.store(Out + row * D + offsets, result, valid)


@triton.jit
def _groupnorm_small_batched(
    X, Scale, Bias, Out,
    D: tl.constexpr, HW: tl.constexpr, G: tl.constexpr,
    REP: tl.constexpr, TOTAL: tl.constexpr, ROWS: tl.constexpr,
    EPS: tl.constexpr, SWISH: tl.constexpr, BLOCK: tl.constexpr,
    ROW_BATCH: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64) * ROW_BATCH + tl.arange(0, ROW_BATCH).to(tl.int64)
    offsets = tl.arange(0, BLOCK).to(tl.int64)
    valid = (row[:, None] < ROWS) & (offsets[None, :] < D)
    indices = row[:, None] * D + offsets[None, :]
    values = tl.load(X + indices, valid, other=0).to(tl.float32)
    mean = tl.sum(values, axis=1) / D
    centered = values - mean[:, None]
    variance = tl.sum(tl.where(valid, centered * centered, 0.0), axis=1) / D
    inv = tl.rsqrt(variance + EPS)
    tl.store(Out + TOTAL + row, mean, row < ROWS)
    tl.store(Out + TOTAL + ROWS + row, inv, row < ROWS)
    channel = (row[:, None] % G) * REP + offsets[None, :] // HW
    scale = tl.load(Scale + channel, valid, other=0).to(tl.float32)
    bias = tl.load(Bias + channel, valid, other=0).to(tl.float32)
    result = centered * inv[:, None] * scale + bias
    if SWISH:
        result = result / (1.0 + tl.exp(-result))
    tl.store(Out + indices, result, valid)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    GroupNorm forward family: standard GroupNorm and the GroupNorm+Swish fusion.

    The input is x (N, C, H, W), NCHW contiguous; scale / bias are the (C,)
    per-channel affine parameters; the __init__ argument groups = G (dividing C,
    1 <= G <= C) splits the channels into G groups, with channel c belonging to
    group c // (C//G); eps defaults to 1e-5. The normalization statistics are
    computed per (n, g) group: x[n] is split along the channel dimension into G
    segments (group g occupies the channels [g*(C//G), (g+1)*(C//G)), and the number
    of elements in a group is D = (C//G)*H*W), in float32:
        mean_ng     = sum_D x / D                      (biased mean)
        var_ng      = sum_D (x - mean_ng)^2 / D        (biased variance)
        inv_var_ng  = 1 / sqrt(var_ng + eps)
        gn[n,c,h,w] = (x[n,c,h,w] - mean_ng) * inv_var_ng * scale[c] + bias[c]
                      (where the group index is g = c // (C//G))
    The __init__ argument variant selects one of two paths:
        "groupnorm"      : y = gn
        "groupnorm_swish": y = gn * sigmoid(gn) (Swish / SiLU)
    Both variants also emit the per-group statistics mean and inv_var (one entry per
    (n, g), (N, G) layout, float32).

    Boundary behaviour: when the in-group variance is 0 (e.g. D == 1, a single
    element in the group) inv_var = 1/sqrt(eps) (eps guarantees no division by zero)
    and gn = bias; G=1 is full-channel normalization and G=C is per-channel
    normalization, both of which are legal; N/C/H/W are arbitrary (including 1,
    non-powers of two and unaligned), a large in-group D needs a tiling (block-wise)
    reduction, and out-of-range elements at the row tail must not take part in the
    statistics.

    Single-tensor output protocol (forward must return a single tensor; the evaluator
    compares a single output):
    Returns a one-dimensional float32 packed tensor of length N*C*H*W + 2*N*G, with
    three segments packed back to back in order (half-open intervals; each segment is
    float32, reshaped with reshape(-1) and torch.cat'ed):
        [0,               N*C*H*W)           y
        [N*C*H*W,         N*C*H*W + N*G)     mean    ((N, G) flattened row-major)
        [N*C*H*W + N*G,   N*C*H*W + 2*N*G)   inv_var ((N, G) flattened row-major)
    The output is always float32: the y segment is not quantized to a lower
    precision; fp16/bf16 is only the input quantization level (the input is provided
    in that dtype and then cast to float32 to take part in the whole computation).

    Input/output specification:
        x      float32 / float16 / bfloat16 (N, C, H, W), contiguous, N/C/H/W >= 1
        scale  same dtype as x, (C,), contiguous
        bias   same dtype as x, (C,), contiguous
        out    one-dimensional float32 of length N*C*H*W + 2*N*G (the three-segment
               packing protocol above)
        The inputs are the usual randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-group mean / biased var reduction, rsqrt, the
          per-channel affine, and Swish) must be completed inside the submitted file
          with a Triton kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt, the affine and Swish all use float32 intermediates;
          all three output segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "groupnorm", groups: int = 2, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("groupnorm", "groupnorm_swish"), "variant must be one of groupnorm / groupnorm_swish"
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.variant = variant
        self.groups = int(groups)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        n, c, h, w = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        g = self.groups
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        rep = c // g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert 1 <= g <= c and c % g == 0, "groups must divide the number of channels and 1 <= groups <= C"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        total = n * c * h * w
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        rows = n * g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        d = rep * h * w
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty((total + 2 * rows,), device=x.device, dtype=torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        block = min(triton.next_power_of_2(d), 4096)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        if d <= 256 and rows >= 16:
            _groupnorm_small_batched[(triton.cdiv(rows, 4),)](
                x, scale, bias, out,
                d, h * w, g, rep, total, rows,
                self.eps, self.variant == "groupnorm_swish",
                BLOCK=triton.next_power_of_2(d), ROW_BATCH=4,
                num_warps=4, enable_fp_fusion=False,
            )
        elif d < 16384:
            _groupnorm_fwd[(rows,)](
                x, scale, bias, out,
                d, h * w, g, rep, total, rows,
                self.eps, self.variant == "groupnorm_swish", block,
                num_warps=4, enable_fp_fusion=False,
            )
        else:
            tile_size = 4096
            tiles = triton.cdiv(d, tile_size)
            means = torch.empty((rows, tiles), device=x.device, dtype=torch.float32)
            m2 = torch.empty((rows, tiles), device=x.device, dtype=torch.float32)
            _groupnorm_tile_stats[(rows, tiles)](
                x, means, m2, d, tiles, tile_size,
                num_warps=4, enable_fp_fusion=False,
            )
            if tiles <= 32:
                _groupnorm_merge_affine[(rows, tiles)](
                    x, scale, bias, means, m2, out,
                    d, h * w, g, rep, total, rows,
                    self.eps, self.variant == "groupnorm_swish",
                    tiles, tile_size, triton.next_power_of_2(tiles),
                    num_warps=4, enable_fp_fusion=False,
                )
            else:
                _groupnorm_merge_stats[(rows,)](
                    means, m2, out, d, tiles, tile_size,
                    total, rows, self.eps,
                    min(triton.next_power_of_2(tiles), 1024),
                    num_warps=4, enable_fp_fusion=False,
                )
                _groupnorm_tile_affine[(rows, tiles)](
                    x, scale, bias, out,
                    d, h * w, g, rep, total, rows,
                    self.variant == "groupnorm_swish", tile_size,
                    num_warps=4, enable_fp_fusion=False,
                )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return out
        # <<<END_IMPROVE>>>
