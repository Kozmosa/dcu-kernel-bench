import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Cumsum (inclusive prefix sum): a sequential accumulation along a given
    dimension.

    Operator definition: for an n-dimensional input x and the scan dimension
    `dim`, the output out has the same shape as x:
        out[i_0, ..., i_k, ...] = sum_{j <= i_dim} x[i_0, ..., j, ...]
    i.e. an inclusive prefix sum along dimension `dim` (including the current
    element), with every other dimension accumulating independently per chain.
    The __init__ parameter `dim` selects the scan dimension (torch convention:
    non-negative counts from 0, negative counts from the end, e.g. -1 means the
    last dimension), defaulting to 2.

    Numeric contract: accumulation always happens in float32 -- float16/bfloat16
    inputs are first cast to float32, accumulated, then cast back to the input
    dtype (matching the compute-in-fp32 convention of production scan
    libraries).

    Input/output specification:
        x     float32 / float16 / bfloat16, contiguous, ndim in [1, 4],
              every dimension >= 1, scan dimension length L in [1, 65536],
              total element count <= 2^25; values are ordinary randn magnitude
              (no inf/NaN)
        out   a single tensor, same shape / dtype as x, contiguous; forward must
              return a single tensor (the evaluator compares .shape / allclose
              on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless); the offline final audit passes inputs
        natively in their declared dtype -- the implementation must be correct
        for both.

    Boundary behaviour: when L=1, out equals x (cast back to the input dtype);
    non-power-of-two L, prime lengths, and axes longer than a single block's
    capacity must all be handled correctly with masking plus a blocked scan, and
    out-of-range lanes must not contribute to the prefix sum; a negative `dim`
    follows the torch convention.

    Implementation constraints (violations are scored as failures):
        - The core scan (prefix sum) must be handwritten with a Triton kernel
          inside the submitted file; calling any library-level scan primitive is
          forbidden, as is bypassing via mathematically equivalent paths such as
          FFT / matrix multiplication / convolution.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate in float32 and cast the output back to the input dtype.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.cumsum / .cumsum( / torch.cumulative_sum / .cumulative_sum( /
    aten.cumsum / aten.cumulative_sum /
    torch.fft / torch.matmul / torch.mm / torch.bmm / torch.einsum /
    conv1d( / numpy / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, dim: int = 2):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.dim = int(dim)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        ndim = x.dim()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert -ndim <= self.dim < ndim, "dim must point at an existing dimension of the input"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        y = torch.cumsum(x.to(torch.float32), dim=self.dim)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return y.to(x.dtype)
        # <<<END_IMPROVE>>>
