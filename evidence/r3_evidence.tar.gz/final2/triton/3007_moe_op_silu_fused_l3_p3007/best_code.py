import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _fused_experts(
    A, B, AS, BS, W, Sorted, Experts, Count, Out,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    TOP: tl.constexpr, S: tl.constexpr, LENGTH: tl.constexpr,
    SA0: tl.constexpr, SA1: tl.constexpr,
    SB0: tl.constexpr, SB1: tl.constexpr, SB2: tl.constexpr,
    SAS0: tl.constexpr, SAS1: tl.constexpr,
    SBS0: tl.constexpr, SBS1: tl.constexpr, SBS2: tl.constexpr,
    SW0: tl.constexpr, SW1: tl.constexpr,
    SS: tl.constexpr, SE: tl.constexpr,
    QUANT: tl.constexpr, QN: tl.constexpr, QK: tl.constexpr,
    WEIGHT: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    p = tl.program_id(0)
    q = tl.program_id(1)
    blocks_per_expert = tl.cdiv(S, BM)
    block = p // blocks_per_expert
    sub = p % blocks_per_expert

    count = tl.load(Count).to(tl.int64)
    local = sub * BM + tl.arange(0, BM)
    pos = block.to(tl.int64) * S + local
    rows = tl.load(
        Sorted + pos * SS,
        (local < S) & (pos < count) & (pos < LENGTH),
        other=M * TOP,
    ).to(tl.int64)

    valid = (block.to(tl.int64) * S < count) & (local < S)
    valid = valid & (pos < count) & (pos < LENGTH)
    valid = valid & (rows >= 0) & (rows < M * TOP)

    if tl.sum(valid.to(tl.int32), axis=0) > 0:
        expert = tl.load(
            Experts + block.to(tl.int64) * SE,
            block.to(tl.int64) * S < count,
            other=0,
        ).to(tl.int64)

        tokens = rows // TOP
        cols = q * BN + tl.arange(0, BN)
        red = tl.arange(0, BK)

        gate = tl.zeros((BM, BN), dtype=tl.float32)
        up = tl.zeros((BM, BN), dtype=tl.float32)

        for start in range(tl.cdiv(K, BK)):
            k = start * BK + red

            av = tl.load(
                A + tokens[:, None] * SA0 + k[None, :] * SA1,
                valid[:, None] & (k[None, :] < K),
                other=0.0,
            ).to(tl.float32)

            bg = tl.load(
                B + expert * SB0
                + cols[None, :].to(tl.int64) * SB1
                + k[:, None].to(tl.int64) * SB2,
                (k[:, None] < K) & (cols[None, :] < N),
                other=0.0,
            ).to(tl.float32)

            bu = tl.load(
                B + expert * SB0
                + (N + cols[None, :]).to(tl.int64) * SB1
                + k[:, None].to(tl.int64) * SB2,
                (k[:, None] < K) & (cols[None, :] < N),
                other=0.0,
            ).to(tl.float32)

            if QUANT:
                asc = tl.load(
                    AS + tokens[:, None] * SAS0
                    + (k[None, :] // QK) * SAS1,
                    valid[:, None] & (k[None, :] < K),
                    other=0.0,
                ).to(tl.float32)

                bsg = tl.load(
                    BS + expert * SBS0
                    + (cols[None, :] // QN) * SBS1
                    + (k[:, None] // QK) * SBS2,
                    (k[:, None] < K) & (cols[None, :] < N),
                    other=0.0,
                ).to(tl.float32)

                bsu = tl.load(
                    BS + expert * SBS0
                    + ((N + cols[None, :]) // QN) * SBS1
                    + (k[:, None] // QK) * SBS2,
                    (k[:, None] < K) & (cols[None, :] < N),
                    other=0.0,
                ).to(tl.float32)

                av = av * asc
                bg = bg * bsg
                bu = bu * bsu

            gate = tl.dot(av, bg, gate, input_precision="ieee")
            up = tl.dot(av, bu, up, input_precision="ieee")

        if WEIGHT:
            weight = tl.load(
                W + tokens * SW0 + (rows % TOP) * SW1,
                valid,
                other=0.0,
            ).to(tl.float32)
            gate = gate * weight[:, None]
            up = up * weight[:, None]

        result = (gate / (1.0 + tl.exp(-gate))) * up

        tl.store(
            Out + rows[:, None] * N + cols[None, :],
            result,
            valid[:, None] & (cols[None, :] < N),
        )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """SiLU-and-multiply fused into the epilogue of an MoE (Mixture of Experts)
    single-layer expert FFN grouped GEMM: one kernel performs the grouped matrix
    multiply of tokens against expert weights, the routing weight weighting and
    the SwiGLU-style activation together, so no intermediate activation is
    materialized.

    Operator semantics: given
        A             activations (M, K)
        B             expert weights (E, 2N, K), the transposed weight matrix of
                      the e-th expert
        topk_ids      routing result (M, top_k), elements in [0, E), distinct
                      within a row
        topk_weights  routing weights (M, top_k), always positive within a row,
                      no normalization needed
        and the three scheduling tensors precomputed from topk_ids by the
        upstream alignment operator
        sorted_token_ids / expert_ids / num_tokens_post_padded (see the input
        specification).
    For each token m and its j-th selected expert e = topk_ids[m, j]:
        x[m, j, :] = A[m, :] @ B[e, :, :]^T          in R^{2N}
        if mul_routed_weight = True: x[m, j, :] *= topk_weights[m, j]
        out[m*top_k + j, i] = SiLU(x[m, j, i]) * x[m, j, N + i],  i in [0, N)
    where SiLU(u) = u / (1 + exp(-u)) = u * sigmoid(u). The 2N output dimensions
    of B use the chunked gating layout: the first N rows are gate and the last N
    rows are up (distinct from the interleaved layout). Every row of the output
    (M*top_k, N) is written by exactly one expert (routing guarantees that every
    row has an owner).

    fp8 block-quantized mode: with quant="fp8_block", A / B are float8_e4m3 code
    words taking part in the same math after dequantization:
        A_deq[m, k]  = A[m, k]  * A_scale[m,  k // block_k]
        B_deq[e, j, k] = B[e, j, k] * B_scale[e, j // block_n, k // block_k]
    This mode requires K % block_k == 0 and 2N % block_n == 0 (no scale tail
    block). With quant="dense", A / B are the raw weights and A_scale / B_scale
    are ignored one-element placeholder tensors.

    Boundary behaviour:
      - slots in sorted_token_ids whose value is >= M*top_k are alignment padding
        sentinels: they take no part in the computation and produce no output
        row; expert_ids is valid only inside the first ceil(num_tokens_post_padded
        / block_size_m) blocks (the valid prefix takes values in [0, E), with no
        cross-card -1 sentinel, and the tail holds unconsumed fill values).
      - an expert selected by no token does not read its B rows.
      - the three scheduling tensors and topk_ids are mutually redundant (all
        derived from the same topk_ids); the core scheduling may use either
        information source, but the output must match the math defined above in
        terms of topk_ids.

    Input/output specification:
        A            (M, K)    float16/bfloat16 (e4m3 code words in fp8_block
                               mode)
        B            (E, 2N, K) same as A (e4m3 code words in fp8_block mode)
        A_scale      (M, K//block_k) float32 ((1,) placeholder in dense mode)
        B_scale      (E, 2N//block_n, K//block_k) float32 ((1,) placeholder in
                     dense mode)
        topk_weights (M, top_k) float16/bfloat16, same dtype as the output
        topk_ids     (M, top_k) int64
        sorted_token_ids (M*top_k + E*(block_size_m-1),) int32
        expert_ids   (M*top_k + E,) int32
        num_tokens_post_padded (1,) int32
        out          (M*top_k, N), dtype same as topk_weights.
        M, K, E, top_k, block_size_m >= 1; 2N is even; input magnitudes are the
        usual randn/rand scale with no inf/NaN. The evaluator casts all inputs
        to fp32 before passing them in (integer types restore exactly,
        fp16/bf16/fp8 -> fp32 is lossless), so when topk_weights is fp32 the
        output is fp32 as well.

    Implementation constraints (violations are scored as failures):
      - Core computation (the grouped GEMM, fp8 dequantization, the routing
        weight multiply, the SiLU-and-multiply epilogue) must be done with a
        Triton kernel inside the submitted file, with intermediate accumulation
        always float32 and the output cast back to the dtype of topk_weights.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Materializing the intermediate activation (the 2N-wide GEMM result) to
        device memory and then activating it is forbidden -- the whole point of
        this operator is epilogue fusion, so the activation is done in place
        block by block.

    Disallowed list: torch.matmul / torch.bmm / torch.einsum /
    torch._scaled_mm / torch.nn.functional.silu / torch.SiLU / torch.sigmoid.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, mul_routed_weight=True, quant="dense", block_n=128, block_k=128):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert quant in ("dense", "fp8_block"), "quant must be one of dense / fp8_block"
        assert block_n >= 1 and block_k >= 1, "block_n / block_k must be >= 1"
        self.mul_routed_weight = bool(mul_routed_weight)
        self.quant = quant
        self.block_n = int(block_n)
        self.block_k = int(block_k)
        # <<<END_IMPROVE>>>

    def forward(self, A, B, A_scale, B_scale, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        # <<<IMPROVE:forward_stmt_1>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = A.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        E, N2, _ = B.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert N2 % 2 == 0, "the 2N output dimension of B must be even"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        N = N2 // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out_dtype = topk_weights.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _ = (sorted_token_ids, expert_ids, num_tokens_post_padded)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        a = A
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        b = B
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        if self.quant == "fp8_block":
            bk, bn = self.block_k, self.block_n
            assert K % bk == 0 and N2 % bn == 0
            assert A_scale.shape == (M, K // bk), "A_scale shape should be (M, K//block_k)"
            assert B_scale.shape == (E, N2 // bn, K // bk), \
                "B_scale shape should be (E, 2N//block_n, K//block_k)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        tw = topk_weights
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        out = torch.empty((M * top_k, N), dtype=out_dtype, device=A.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        length = sorted_token_ids.numel()
        extra = length - M * top_k
        assert extra >= 0 and extra % E == 0
        s = extra // E + 1
        bm, bn, bk = 16, 32, 32
        quantized = self.quant == "fp8_block"

        if N:
            _fused_experts[
                (triton.cdiv(length, s) * triton.cdiv(s, bm), triton.cdiv(N, bn))
            ](
                a, b, A_scale, B_scale, tw,
                sorted_token_ids, expert_ids, num_tokens_post_padded, out,
                M, N, K, top_k, s, length,
                a.stride(0), a.stride(1),
                b.stride(0), b.stride(1), b.stride(2),
                A_scale.stride(0) if quantized else 0,
                A_scale.stride(1) if quantized else 0,
                B_scale.stride(0) if quantized else 0,
                B_scale.stride(1) if quantized else 0,
                B_scale.stride(2) if quantized else 0,
                tw.stride(0), tw.stride(1),
                sorted_token_ids.stride(0), expert_ids.stride(0),
                quantized, self.block_n, self.block_k,
                self.mul_routed_weight,
                bm, bn, bk,
                num_warps=4,
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return out.to(out_dtype)
        # <<<END_IMPROVE>>>
