import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _prefill(
    Q, K, V, KC, VC, BT, START, LEN, SLOPE, OUT,
    T: tl.constexpr, NS: tl.constexpr, D: tl.constexpr,
    BS: tl.constexpr, X: tl.constexpr, GROUP: tl.constexpr,
    SCALE: tl.constexpr, HAS_ALIBI: tl.constexpr,
    QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr,
    KCS0: tl.constexpr, KCS1: tl.constexpr, KCS2: tl.constexpr,
    KCS3: tl.constexpr, KCS4: tl.constexpr,
    VCS0: tl.constexpr, VCS1: tl.constexpr, VCS2: tl.constexpr,
    VCS3: tl.constexpr, BTS0: tl.constexpr, BTS1: tl.constexpr,
    SS: tl.constexpr, LS: tl.constexpr,
    OS0: tl.constexpr, OS1: tl.constexpr, OS2: tl.constexpr,
    AS: tl.constexpr, DD: tl.constexpr,
):
    base = tl.program_id(0) * 16
    h = tl.program_id(1)
    hk = h // GROUP
    rows = base + tl.arange(0, 16)
    d = tl.arange(0, DD)
    cols = tl.arange(0, 32)

    lo = 0
    hi = NS
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        start_mid = tl.load(START + mid * SS)
        if start_mid <= base:
            lo = mid
        else:
            hi = mid

    b = lo
    cursor = base
    end = tl.minimum(base + 16, T)
    slope = 0.0
    if HAS_ALIBI:
        slope = tl.load(SLOPE + h * AS)

    while cursor < end:
        qs = tl.load(START + b * SS)
        qe = tl.load(START + (b + 1) * SS)
        ctx = tl.load(LEN + b * LS) - (qe - qs)
        seg_end = tl.minimum(end, qe)
        valid = (rows >= cursor) & (rows < seg_end)
        pos = ctx + rows - qs

        q = tl.load(
            Q + rows[:, None] * QS0 + h * QS1 + d[None, :] * QS2,
            valid[:, None] & (d[None, :] < D),
            0,
        ).to(tl.float32)
        q = q * SCALE

        m = tl.full((16,), float("-inf"), tl.float32)
        s = tl.zeros((16,), tl.float32)
        acc = tl.zeros((16, DD), tl.float32)

        limit = ctx + seg_end - qs
        off = 0
        while off < limit:
            l = off + cols
            prefix = (l < ctx) & (l < limit)
            fresh = (l >= ctx) & (l < limit)

            phys = tl.load(
                BT + b * BTS0 + (l // BS) * BTS1,
                prefix,
                0,
            ).to(tl.int64)

            kn = tl.load(
                K + (qs + l - ctx)[None, :] * KS0
                + hk * KS1
                + d[:, None] * KS2,
                fresh[None, :] & (d[:, None] < D),
                0,
            ).to(tl.float32)

            kp = tl.load(
                KC + phys[None, :] * KCS0
                + hk * KCS1
                + (d[:, None] // X) * KCS2
                + (l[None, :] % BS) * KCS3
                + (d[:, None] % X) * KCS4,
                prefix[None, :] & (d[:, None] < D),
                0,
            ).to(tl.float32)

            logits = tl.dot(q, kp + kn, input_precision="ieee")
            logits = logits * 1.0
            if HAS_ALIBI:
                logits += slope * (l[None, :] - pos[:, None]).to(tl.float32)

            logits = tl.where(
                valid[:, None]
                & (l[None, :] <= pos[:, None])
                & (l[None, :] < limit),
                logits,
                float("-inf"),
            )

            row_max = tl.max(logits, 1)
            new_m = tl.maximum(m, row_max)
            new_m = tl.where(valid, new_m, 0.0)

            alpha = tl.exp(m - new_m)
            p = tl.exp(logits - new_m[:, None])
            p = tl.where(valid[:, None], p, 0.0)

            s = s * alpha + tl.sum(p, 1)

            vp = tl.load(
                VC + phys[:, None] * VCS0
                + hk * VCS1
                + d[None, :] * VCS2
                + (l[:, None] % BS) * VCS3,
                prefix[:, None] & (d[None, :] < D),
                0,
            ).to(tl.float32)

            vn = tl.load(
                V + (qs + l - ctx)[:, None] * VS0
                + hk * VS1
                + d[None, :] * VS2,
                fresh[:, None] & (d[None, :] < D),
                0,
            ).to(tl.float32)

            acc = acc * alpha[:, None] + tl.dot(
                p, vp + vn, input_precision="ieee"
            )
            m = new_m
            off += 32

        result = acc / tl.where(valid, s, 1.0)[:, None]
        tl.store(
            OUT + rows[:, None] * OS0 + h * OS1 + d[None, :] * OS2,
            result,
            valid[:, None] & (d[None, :] < D),
        )

        cursor = seg_end
        b += 1
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Paged KV prefix (context) attention: attention for prefill multi-token queries.

    (MHA/GQA, causal + optional ALiBi.)

    Within a batch, num_seqs sequences run in parallel; sequence b has
    query_len[b] = query_start_loc[b+1] - query_start_loc[b] newly computed query
    tokens in this round, and the slices of all sequences are flattened and
    concatenated along the token dimension in query_start_loc order (no
    padding). The current total length of the sequence is seq_lens[b], of which
    the first ctx_len[b] = seq_lens[b] - query_len[b] tokens are the already
    admitted prefix K/V, stored only in the paged KV cache; the K/V of the new
    tokens of this round are given explicitly only as key / value (the cache
    does not contain the new tokens). query_len[b] > 1 means prefill, and == 1
    is also legal (a single-token query against the pure prefix).

    Paged layout: the physical block pool has num_blocks blocks, each holding
    block_size token slots; block_tables[b] is the "prefix logical block ->
    physical block id" table of that sequence, where only the first
    ceil(ctx_len[b]/block_size) columns are valid (the remaining columns are
    garbage). K uses the channel-packed layout: the K channel d of the l-th
    prefix token is stored at
    key_cache[bt[b, l//block_size], h_kv, d//x, l%block_size, d%x]
    (x = 8, head_size is a multiple of 8); V is stored at
    value_cache[bt[b, l//block_size], h_kv, d, l%block_size]. Blocks in the pool
    that are not referenced, as well as slots beyond the prefix length inside
    referenced blocks, are garbage data (magnitudes up to +/-10) and must not
    participate in the computation.

    For the j-th new token of the h-th query head of sequence b (the
    corresponding KV head is h // query_group_size, query_group_size =
    num_heads / num_kv_heads), at in-sequence absolute position pos =
    ctx_len[b] + j:

      logits[l] = scale * <query[pos, h, :], K[l]> + alibi_slopes[h] * (l - pos)
      causal mask: logits at positions l > pos are set to -inf
      p[l] = exp(logits[l] - max_l' logits[l']) / sum_l' exp(logits[l'] - max_l' logits[l'])
      out[pos, h, :] = sum_{l = 0..pos} p[l] * V[l]

    where K[l] / V[l]: for l < ctx_len[b] they come from the paged cache
    (indirect addressing through the block table), and for l >= ctx_len[b] they
    come from key / value. When alibi_slopes is None no bias term is added (it
    degenerates to the unbiased baseline); when a float32 [num_heads] tensor is
    given, the ALiBi bias is added as in the formula above (the bias is 0 at
    l == pos). The softmax uses an online (numerically stable) implementation,
    intermediate accumulation is in float32, and the output is cast back to the
    input dtype.

    Input/output specification (forward parameter order):
      query           [num_tokens, num_heads, head_size]                    fp16/bf16
      key             [num_tokens, num_kv_heads, head_size]                 same as query
      value           [num_tokens, num_kv_heads, head_size]                 same as query
      key_cache       [num_blocks, num_kv_heads, head_size//8, block_size, 8]   same as query
      value_cache     [num_blocks, num_kv_heads, head_size, block_size]         same as query
      block_tables    [num_seqs, max_blocks_per_seq]                         int32
      query_start_loc [num_seqs+1] int32 (prefix sum of query_len, first element 0)
      seq_lens        [num_seqs] int32
      alibi_slopes    [num_heads] float32, or None (no ALiBi bias)
      returns out     [num_tokens, num_heads, head_size], dtype same as query.
      scale defaults to 1/sqrt(head_size) (given by head_size in __init__).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        torch.matmul / torch.bmm / torch.einsum / torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: prefill multi-token queries, non-quantized KV; includes the ALiBi
    bias variant and the unbiased baseline (alibi_slopes passed as None); does
    not include sliding window, does not include a quantized KV cache, and the
    K/V of the new tokens of this round are not written into the cache.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens, alibi_slopes=None):
        # <<<IMPROVE:forward_stmt_1>>>
        # Keep block-table metadata on device in its original integer dtype.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        query_start_loc = query_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        slopes = None if alibi_slopes is None else alibi_slopes.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        num_tokens, num_heads, head_size = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_kv_heads = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        block_size = value_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        x = key_cache.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        group = num_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert num_heads == num_kv_heads * group, "num_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        assert head_size == (head_size // x) * x, "head_size must be an integer multiple of x"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        if num_tokens:
            _prefill[(triton.cdiv(num_tokens, 16), num_heads)](
                query,
                key,
                value,
                key_cache,
                value_cache,
                block_tables,
                query_start_loc,
                seq_lens,
                slopes if slopes is not None else query,
                out,
                num_tokens,
                seq_lens.shape[0],
                head_size,
                block_size,
                x,
                group,
                self.scale,
                slopes is not None,
                query.stride(0),
                query.stride(1),
                query.stride(2),
                key.stride(0),
                key.stride(1),
                key.stride(2),
                value.stride(0),
                value.stride(1),
                value.stride(2),
                key_cache.stride(0),
                key_cache.stride(1),
                key_cache.stride(2),
                key_cache.stride(3),
                key_cache.stride(4),
                value_cache.stride(0),
                value_cache.stride(1),
                value_cache.stride(2),
                value_cache.stride(3),
                block_tables.stride(0),
                block_tables.stride(1),
                query_start_loc.stride(0),
                seq_lens.stride(0),
                out.stride(0),
                out.stride(1),
                out.stride(2),
                slopes.stride(0) if slopes is not None else 1,
                triton.next_power_of_2(head_size),
                num_warps=4,
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return out
        # <<<END_IMPROVE>>>
