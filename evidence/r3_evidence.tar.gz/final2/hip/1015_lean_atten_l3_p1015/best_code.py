import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1015_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor tiled_attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor lengths, torch::Tensor causal, double scale);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("tiled_attention_forward", &tiled_attention_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <cmath>
#include <algorithm>
#include <limits>

template <typename T, int D>
__global__ void tiled_attention_kernel(
    const T* __restrict__ q,
    const T* __restrict__ k,
    const T* __restrict__ v,
    const int32_t* __restrict__ lengths,
    const int32_t* __restrict__ causal,
    T* __restrict__ out,
    int64_t rows,
    int64_t total_kv,
    int64_t batches,
    int64_t qlen,
    int64_t heads,
    int64_t q_numel,
    int64_t k_numel,
    int64_t v_numel,
    int64_t out_numel,
    float scale) {
    __shared__ float query[D];
    __shared__ float tile[32 * D];
    __shared__ float scores[32];
    __shared__ float weights[32];
    __shared__ float row_max;
    __shared__ float row_den;
    __shared__ float rescale;
    __shared__ int64_t kv_start;
    __shared__ int64_t kv_count;

    const int64_t tid = static_cast<int64_t>(threadIdx.x);
    const int64_t stride = static_cast<int64_t>(gridDim.x);

    for (int64_t row = static_cast<int64_t>(blockIdx.x);
         row < rows;
         row += stride) {
        const int64_t token = row / heads;
        const int64_t head = row % heads;
        const int64_t batch = qlen > 0 ? token / qlen : 0;
        const int64_t local_q = qlen > 0 ? token % qlen : 0;

        if (tid == 0) {
            int64_t prefix = 0;
            if (batch >= 0 && batch < batches) {
                for (int64_t s = 0; s < batch; ++s) {
                    prefix += static_cast<int64_t>(lengths[s]);
                }
                int64_t n = static_cast<int64_t>(lengths[batch]);
                if (prefix < 0 || prefix >= total_kv || n <= 0) {
                    prefix = 0;
                    n = 0;
                } else if (n > total_kv - prefix) {
                    n = total_kv - prefix;
                }
                if (causal[0] != 0 && n > local_q + 1) {
                    n = local_q + 1;
                }
                kv_start = prefix;
                kv_count = n;
            } else {
                kv_start = 0;
                kv_count = 0;
            }
            row_max = -INFINITY;
            row_den = 0.0f;
        }

        if (tid < D) {
            const int64_t qi = row * static_cast<int64_t>(D) + tid;
            query[tid] = (qi >= 0 && qi < q_numel) ? static_cast<float>(q[qi]) : 0.0f;
        }
        __syncthreads();

        float accumulator = 0.0f;
        for (int64_t base = 0; base < kv_count; base += 32) {
            for (int64_t x = tid; x < static_cast<int64_t>(32) * D; x += 256) {
                const int64_t j = base + x / D;
                const int64_t d = x % D;
                const int64_t pos = ((kv_start + j) * heads + head) * D + d;
                tile[x] = (j >= 0 && j < kv_count && pos >= 0 && pos < k_numel)
                    ? static_cast<float>(k[pos]) : 0.0f;
            }
            __syncthreads();

            const int64_t key = tid / 8;
            const int64_t lane = tid % 8;
            float dot = 0.0f;
            for (int64_t d = lane; d < D; d += 8) {
                dot += query[d] * tile[key * D + d];
            }
            // HIP width-limited subgroups, independent of native wave size.
            dot += __shfl_down(dot, 4, 8);
            dot += __shfl_down(dot, 2, 8);
            dot += __shfl_down(dot, 1, 8);
            if (lane == 0) {
                const int64_t j = base + key;
                scores[key] = (j >= 0 && j < kv_count) ? dot * scale : -INFINITY;
            }
            __syncthreads();

            float maximum = tid < 32 ? scores[tid] : -INFINITY;
            for (int r = 16; r > 0; r >>= 1) {
                maximum = fmaxf(maximum, __shfl_down(maximum, r, 32));
            }

            if (tid == 0) {
                const float next_max = fmaxf(row_max, maximum);
                rescale = (base == 0) ? 0.0f : expf(row_max - next_max);
                row_max = next_max;
            }
            __syncthreads();

            if (tid < 32) {
                const int64_t j = base + tid;
                weights[tid] = (j >= 0 && j < kv_count)
                    ? expf(scores[tid] - row_max) : 0.0f;
            }

            for (int64_t x = tid; x < static_cast<int64_t>(32) * D; x += 256) {
                const int64_t j = base + x / D;
                const int64_t d = x % D;
                const int64_t pos = ((kv_start + j) * heads + head) * D + d;
                tile[x] = (j >= 0 && j < kv_count && pos >= 0 && pos < v_numel)
                    ? static_cast<float>(v[pos]) : 0.0f;
            }
            __syncthreads();

            float denominator = tid < 32 ? weights[tid] : 0.0f;
            for (int r = 16; r > 0; r >>= 1) {
                denominator += __shfl_down(denominator, r, 32);
            }
            if (tid == 0) {
                row_den = rescale * row_den + denominator;
            }

            if (tid < D) {
                accumulator *= rescale;
                for (int64_t j = 0; j < 32; ++j) {
                    accumulator += weights[j] * tile[j * D + tid];
                }
            }
            __syncthreads();
        }

        if (tid < D) {
            const int64_t oi = row * static_cast<int64_t>(D) + tid;
            if (oi >= 0 && oi < out_numel) {
                out[oi] = static_cast<T>(
                    row_den > 0.0f ? accumulator / row_den : 0.0f);
            }
        }
        __syncthreads();
    }
}

template <typename T>
void launch_tiled_attention(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor lengths,
    torch::Tensor causal,
    torch::Tensor out,
    float scale) {
    const int64_t heads = q.size(1);
    const int64_t rows = q.size(0) * heads;
    const int64_t batches = lengths.numel();
    const int64_t qlen = q.size(0) / batches;
    const int64_t d = q.size(2);
    const int64_t grid_count = std::max<int64_t>(1, std::min<int64_t>(rows, 65535));
    auto stream = at::cuda::getCurrentCUDAStream(q.get_device());

#define LAUNCH_ATTENTION(DIM) \
    tiled_attention_kernel<T, DIM><<<static_cast<unsigned>(grid_count), 256, 0, stream>>>( \
        q.data_ptr<T>(), k.data_ptr<T>(), v.data_ptr<T>(), \
        lengths.data_ptr<int32_t>(), causal.data_ptr<int32_t>(), \
        out.data_ptr<T>(), rows, k.size(0), batches, qlen, heads, \
        q.numel(), k.numel(), v.numel(), out.numel(), scale)

    switch (d) {
        case 16:  LAUNCH_ATTENTION(16); break;
        case 32:  LAUNCH_ATTENTION(32); break;
        case 64:  LAUNCH_ATTENTION(64); break;
        case 128: LAUNCH_ATTENTION(128); break;
        case 256: LAUNCH_ATTENTION(256); break;
        default:
            TORCH_CHECK(false, "unsupported head dimension");
    }
#undef LAUNCH_ATTENTION

    const hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess,
                "attention launch failed: ", hipGetErrorString(error));
}

torch::Tensor tiled_attention_forward(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor lengths,
    torch::Tensor causal,
    double scale) {
    TORCH_CHECK(q.is_cuda(), "q must be on a GPU");
    c10::cuda::CUDAGuard guard(q.device());

    TORCH_CHECK(k.device() == q.device() &&
                v.device() == q.device() &&
                lengths.device() == q.device() &&
                causal.device() == q.device(),
                "all inputs must share a device");
    TORCH_CHECK(q.dim() == 3 && k.dim() == 3 && v.dim() == 3,
                "q, k, and v must be rank three");
    TORCH_CHECK(k.sizes() == v.sizes(),
                "k and v shapes must match");
    TORCH_CHECK(q.size(1) == k.size(1) &&
                q.size(2) == k.size(2),
                "q, k, and v head shapes must match");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type(),
                "q, k, and v dtypes must match");
    TORCH_CHECK(lengths.dim() == 1 &&
                lengths.numel() > 0 &&
                lengths.scalar_type() == at::kInt,
                "lengths must be a nonempty int32 vector");
    TORCH_CHECK(causal.numel() == 1 &&
                causal.scalar_type() == at::kInt,
                "causal must be a scalar int32 tensor");
    TORCH_CHECK(q.size(0) > 0 &&
                q.size(1) > 0 &&
                q.size(0) % lengths.numel() == 0,
                "invalid query or lengths shape");

    const int64_t d = q.size(2);
    TORCH_CHECK(d == 16 || d == 32 || d == 64 || d == 128 || d == 256,
                "unsupported head dimension");

    q = q.contiguous();
    k = k.contiguous();
    v = v.contiguous();
    lengths = lengths.contiguous();
    causal = causal.contiguous();

    auto out = torch::empty_like(q);
    switch (q.scalar_type()) {
        case at::kHalf:
            launch_tiled_attention<at::Half>(
                q, k, v, lengths, causal, out, static_cast<float>(scale));
            break;
        case at::kBFloat16:
            launch_tiled_attention<at::BFloat16>(
                q, k, v, lengths, causal, out, static_cast<float>(scale));
            break;
        case at::kFloat:
            launch_tiled_attention<float>(
                q, k, v, lengths, causal, out, static_cast<float>(scale));
            break;
        default:
            TORCH_CHECK(false, "unsupported attention dtype");
    }
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Attention forward pass over ragged batches with variable-length KV (Lean
    Attention semantics: contiguous, non-paged KV, softmax inside a single
    kernel), covering both decode (independent KV lengths per batch entry) and
    prefill (square causal self-attention) forms, with MHA (Q/K/V head counts
    equal).

    Mathematical definition: the batch holds num_seqs sequences, sequence b has an
    actually participating KV length kv_lens[b] (>= 1), and every query segment has
    the same length q_len (total_q = num_seqs * q_len, with q stored in
    sequence-major order). Let start_k = kv_lens[0] + ... + kv_lens[b-1] (k/v are
    likewise stored contiguously in sequence-major order). For every sequence b,
    head h, query position i (0 <= i < q_len) and KV position j
    (0 <= j < kv_lens[b]):
      scores[i, j] = sm_scale * <q[b*q_len+i, h, :], k[start_k+j, h, :]>
      with causal=1 (the task constrains kv_lens[b] == q_len for all b in this form)
      a square causal mask is applied: positions with j > i are set to -inf; with
      causal=0 no mask is applied;
      p[i, :] = softmax_j(scores[i, :])
      out[b*q_len+i, h, :] = sum_j p[i, j] * v[start_k+j, h, :]
    The softmax uses a numerically stable (online) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.
    Boundary behaviour: kv_lens[b] >= 1 always holds, so the softmax denominator is
    always positive and no row is fully masked; sequences do not affect each other;
    slots in k/v beyond each sequence's cumulative length boundary do not
    participate in the computation.

    Input/output specification:
      q        [num_seqs*q_len, num_heads, head_dim]  float16/bfloat16, sequence-major
      k, v     [total_kv, num_heads, head_dim]        same dtype as q, total_kv = sum(kv_lens)
      kv_lens  [num_seqs] int32 -- the KV length actually participating per sequence
      causal   0-dim int32 tensor, 1 = square causal mask, 0 = no mask
      out      [num_seqs*q_len, num_heads, head_dim]  same dtype as q
    Global constraints: Q/K/V head counts are equal (MHA, no GQA); head_dim in
    {16, 32, 64, 128, 256} and identical across Q/K/V; q_len >= 1; with causal=1,
    kv_lens[b] == q_len for all b.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: contiguous non-paged KV, variable-length ragged batch, MHA, both
    causal states, fp16/bf16 non-quantized inputs; no GQA, no dropout, no
    bias/ALiBi, no LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, kv_lens, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        q = q.contiguous()
        k = k.contiguous()
        v = v.contiguous()
        kv_lens = kv_lens.to(device=q.device, dtype=torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        causal = torch.as_tensor(causal, dtype=torch.int32, device=q.device).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # The fused kernel reads the causal device scalar.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_heads = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        assert num_heads == k.shape[1] == v.shape[1], "MHA: Q/K/V must have the same number of heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_seqs = int(kv_lens.numel())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        q_len = q.shape[0] // num_seqs
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert q_len * num_seqs == q.shape[0], "total_q must be an integer multiple of num_seqs"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Square causal inputs are guaranteed by the task.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = _pyramidkernel_get_extension().tiled_attention_forward(
            q, k, v, kv_lens, causal, float(self.sm_scale))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Prefix offsets are calculated in the HIP block.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Fused tiled HIP attention computes the entire result.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
