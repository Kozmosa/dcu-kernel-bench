import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2014_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor instance_norm_forward(torch::Tensor x, torch::Tensor scale,
                                    torch::Tensor bias, double eps);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("instance_norm_forward", &instance_norm_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cstdint>

__device__ float reduce_sum(float value, float* shared) {
    const int t = threadIdx.x;
    shared[t] = value;
    __syncthreads();
    for (int offset = 128; offset > 0; offset >>= 1) {
        if (t < offset) {
            shared[t] += shared[t + offset];
        }
        __syncthreads();
    }
    float result = shared[0];
    __syncthreads();
    return result;
}

template<typename T>
__global__ void instance_norm_kernel(
    const T* __restrict__ x,
    const T* __restrict__ scale,
    const T* __restrict__ bias,
    T* __restrict__ out,
    int64_t planes,
    int64_t channels,
    int64_t spatial,
    float eps) {
    __shared__ float shared[256];

    for (int64_t plane = static_cast<int64_t>(blockIdx.x);
         plane < planes;
         plane += static_cast<int64_t>(gridDim.x)) {
        const int64_t base = plane * spatial;

        float sum = 0.0f;
        for (int64_t i = static_cast<int64_t>(threadIdx.x);
             i < spatial;
             i += 256) {
            sum += static_cast<float>(x[base + i]);
        }

        const float mean =
            reduce_sum(sum, shared) / static_cast<float>(spatial);

        float squares = 0.0f;
        for (int64_t i = static_cast<int64_t>(threadIdx.x);
             i < spatial;
             i += 256) {
            const float d = static_cast<float>(x[base + i]) - mean;
            squares += d * d;
        }

        const float variance =
            reduce_sum(squares, shared) / static_cast<float>(spatial);
        const float inv = rsqrtf(variance + eps);
        const int64_t channel = plane % channels;
        const float s = static_cast<float>(scale[channel]);
        const float b = static_cast<float>(bias[channel]);

        for (int64_t i = static_cast<int64_t>(threadIdx.x);
             i < spatial;
             i += 256) {
            const float d = static_cast<float>(x[base + i]) - mean;
            out[base + i] = static_cast<T>(__fadd_rn((d * inv) * s, b));
        }

        __syncthreads();
    }
}

template<typename T, int ITEMS>
__global__ void instance_norm_cached_kernel(
    const T* __restrict__ x,
    const T* __restrict__ scale,
    const T* __restrict__ bias,
    T* __restrict__ out,
    int64_t planes,
    int64_t channels,
    int64_t spatial,
    float eps) {
    __shared__ float shared[256];
    float values[ITEMS];

    for (int64_t plane = static_cast<int64_t>(blockIdx.x);
         plane < planes;
         plane += static_cast<int64_t>(gridDim.x)) {
        const int64_t base = plane * spatial;

        #pragma unroll
        for (int k = 0; k < ITEMS; ++k) {
            const int64_t i =
                static_cast<int64_t>(threadIdx.x) +
                static_cast<int64_t>(k) * 256;
            values[k] = i < spatial
                ? static_cast<float>(x[base + i])
                : 0.0f;
        }

        float sum = 0.0f;
        #pragma unroll
        for (int k = 0; k < ITEMS; ++k) {
            const int64_t i =
                static_cast<int64_t>(threadIdx.x) +
                static_cast<int64_t>(k) * 256;
            if (i < spatial) {
                sum += values[k];
            }
        }

        const float mean =
            reduce_sum(sum, shared) / static_cast<float>(spatial);

        float squares = 0.0f;
        #pragma unroll
        for (int k = 0; k < ITEMS; ++k) {
            const int64_t i =
                static_cast<int64_t>(threadIdx.x) +
                static_cast<int64_t>(k) * 256;
            if (i < spatial) {
                const float d = values[k] - mean;
                squares += d * d;
            }
        }

        const float variance =
            reduce_sum(squares, shared) / static_cast<float>(spatial);
        const float inv = rsqrtf(variance + eps);
        const int64_t channel = plane % channels;
        const float s = static_cast<float>(scale[channel]);
        const float b = static_cast<float>(bias[channel]);

        #pragma unroll
        for (int k = 0; k < ITEMS; ++k) {
            const int64_t i =
                static_cast<int64_t>(threadIdx.x) +
                static_cast<int64_t>(k) * 256;
            if (i < spatial) {
                out[base + i] = static_cast<T>(
                    __fadd_rn(((values[k] - mean) * inv) * s, b));
            }
        }

        __syncthreads();
    }
}

torch::Tensor instance_norm_forward(torch::Tensor x, torch::Tensor scale,
                                    torch::Tensor bias, double eps) {
    TORCH_CHECK(x.is_cuda() && scale.is_cuda() && bias.is_cuda(),
                "Inputs must be HIP tensors");
    TORCH_CHECK(x.device() == scale.device() && x.device() == bias.device(),
                "Inputs must share a device");
    TORCH_CHECK(x.is_contiguous() && scale.is_contiguous() &&
                    bias.is_contiguous(),
                "Inputs must be contiguous");
    TORCH_CHECK(x.dim() == 4, "x must be NCHW");
    TORCH_CHECK(x.scalar_type() == scale.scalar_type() &&
                    x.scalar_type() == bias.scalar_type(),
                "Dtypes must match");
    TORCH_CHECK(eps > 0.0, "eps must be positive");

    for (int d = 0; d < 4; ++d) {
        TORCH_CHECK(x.size(d) > 0, "Dimensions must be positive");
    }

    const int64_t channels = static_cast<int64_t>(x.size(1));
    TORCH_CHECK(scale.dim() == 4 && bias.dim() == 4,
                "Affine tensors must have rank four");
    TORCH_CHECK(
        scale.size(0) == 1 && scale.size(1) == channels &&
            scale.size(2) == 1 && scale.size(3) == 1 &&
            bias.sizes() == scale.sizes(),
        "Invalid affine shapes");

    c10::cuda::CUDAGuard guard(x.device());

    const int64_t planes =
        static_cast<int64_t>(x.size(0)) * channels;
    const int64_t spatial =
        static_cast<int64_t>(x.size(2)) *
        static_cast<int64_t>(x.size(3));

    auto out = torch::empty_like(x);
    const unsigned blocks = static_cast<unsigned>(
        std::min<int64_t>(planes, 65535));
    auto stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "instance_norm_forward",
        [&] {
            const float feps = static_cast<float>(eps);

            if (spatial <= 256) {
                instance_norm_cached_kernel<scalar_t, 1>
                    <<<blocks, 256, 0, stream>>>(
                        x.data_ptr<scalar_t>(),
                        scale.data_ptr<scalar_t>(),
                        bias.data_ptr<scalar_t>(),
                        out.data_ptr<scalar_t>(),
                        planes, channels, spatial, feps);
            } else if (spatial <= 512) {
                instance_norm_cached_kernel<scalar_t, 2>
                    <<<blocks, 256, 0, stream>>>(
                        x.data_ptr<scalar_t>(),
                        scale.data_ptr<scalar_t>(),
                        bias.data_ptr<scalar_t>(),
                        out.data_ptr<scalar_t>(),
                        planes, channels, spatial, feps);
            } else if (spatial <= 1024) {
                instance_norm_cached_kernel<scalar_t, 4>
                    <<<blocks, 256, 0, stream>>>(
                        x.data_ptr<scalar_t>(),
                        scale.data_ptr<scalar_t>(),
                        bias.data_ptr<scalar_t>(),
                        out.data_ptr<scalar_t>(),
                        planes, channels, spatial, feps);
            } else if (spatial <= 2048) {
                instance_norm_cached_kernel<scalar_t, 8>
                    <<<blocks, 256, 0, stream>>>(
                        x.data_ptr<scalar_t>(),
                        scale.data_ptr<scalar_t>(),
                        bias.data_ptr<scalar_t>(),
                        out.data_ptr<scalar_t>(),
                        planes, channels, spatial, feps);
            } else if (spatial <= 4096) {
                instance_norm_cached_kernel<scalar_t, 16>
                    <<<blocks, 256, 0, stream>>>(
                        x.data_ptr<scalar_t>(),
                        scale.data_ptr<scalar_t>(),
                        bias.data_ptr<scalar_t>(),
                        out.data_ptr<scalar_t>(),
                        planes, channels, spatial, feps);
            } else {
                instance_norm_kernel<scalar_t>
                    <<<blocks, 256, 0, stream>>>(
                        x.data_ptr<scalar_t>(),
                        scale.data_ptr<scalar_t>(),
                        bias.data_ptr<scalar_t>(),
                        out.data_ptr<scalar_t>(),
                        planes, channels, spatial, feps);
            }
        });

    hipError_t err = hipGetLastError();
    TORCH_CHECK(
        err == hipSuccess,
        "Instance norm launch failed: ",
        hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    InstanceNorm forward pass: per-(N,C) spatial-statistics normalization plus
    per-channel affine (single variant).

    The input x (N, C, H, W) is NCHW contiguous; scale / bias are the (1, C, 1, 1)
    per-channel affine parameters, broadcast along the channel dimension; eps
    defaults to 1e-5. Statistics are taken over the spatial dimensions (H, W) for
    every (n, c) plane (HW = H*W elements per plane), in float32:
        mean_nc    = sum_{h,w} x[n,c,h,w] / HW                  (biased mean)
        var_nc     = sum_{h,w} (x[n,c,h,w] - mean_nc)^2 / HW    (biased variance)
        inv_std_nc = 1 / sqrt(var_nc + eps)
        y[n,c,h,w] = scale[c] * (x[n,c,h,w] - mean_nc) * inv_std_nc + bias[c]
    Instance norm has no train / inference semantic difference: the normalization
    statistics always come from the input itself. The convention is biased (divide
    by HW rather than HW-1), and eps sits inside the rsqrt (its only purpose is the
    division-by-zero guard; it takes part in no unbiased correction).

    Boundary behaviour: when HW == 1 (a single spatial element) var = 0 and
    x - mean = 0, so inv_std = 1/sqrt(eps) and y = bias (eps guarantees no division
    by zero); N/C/H/W are arbitrary (including 1, non-powers-of-two, and unaligned
    sizes); a large HW requires a blocked reduction, and out-of-range elements at
    the row tail must not participate in the statistics.

    Input/output specification:
        x     float32 / float16 / bfloat16 (N, C, H, W), contiguous,
              N/C/H/W >= 1
        scale same dtype as x, (1, C, 1, 1), contiguous
        bias  same dtype as x, (1, C, 1, 1), contiguous
        out   a single tensor, y itself: (N, C, H, W) with the same dtype as x
              (statistics and affine run in float32 intermediates, then cast back
              to the x dtype); no packing
        The inputs are ordinary randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before calling forward (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-(N,C) spatial reduction statistics, rsqrt,
          and the per-channel affine) must be completed with a HIP kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt and affine all run in float32 intermediates; y is
          cast back to the x dtype.
        - forward returns the single tensor `out` (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden list: torch.nn.InstanceNorm1d / torch.nn.InstanceNorm2d /
    torch.nn.InstanceNorm3d / torch.nn.functional.instance_norm /
    F.instance_norm / torch.instance_norm / native_instance_norm /
    torch.nn.GroupNorm / nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm /
    torch.nn.BatchNorm1d / torch.nn.BatchNorm2d / torch.nn.BatchNorm3d /
    torch.nn.SyncBatchNorm / torch.nn.functional.batch_norm /
    F.batch_norm / torch.batch_norm / torch.native_batch_norm /
    miopen / hipdnn.
    (GroupNorm with num_groups=C and BatchNorm via a (1, N*C, H, W) reshape both
    complete this task's core computation in a single step, so they are forbidden
    alongside the instance_norm family.)
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert eps > 0, "eps must be positive"
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().instance_norm_forward(
            x, scale, bias, self.eps
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return out
        # <<<END_IMPROVE>>>
