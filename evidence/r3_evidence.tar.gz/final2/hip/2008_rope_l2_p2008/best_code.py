import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2008_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor rope_forward(torch::Tensor x, torch::Tensor freqs,
                           int64_t rotate_style, bool nope_first,
                           bool reuse_freqs_front_part);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("rope_forward", &rope_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <algorithm>
#include <cstdint>
#include <cmath>

template <typename scalar_t, int Flags>
__global__ void rope_kernel(const scalar_t* __restrict__ x,
                            const scalar_t* __restrict__ freqs,
                            scalar_t* __restrict__ out,
                            int64_t n, int64_t d, int64_t f,
                            int64_t bh, int64_t nf) {
    #pragma clang fp contract(off)
    constexpr bool gptj = (Flags & 1) != 0;
    constexpr bool nope = (Flags & 2) != 0;
    constexpr bool reuse = (Flags & 4) != 0;
    const int64_t r = f * (reuse ? 2 : 1);
    const int64_t start = nope ? d - r : 0;
    const int64_t half = r / 2;
    const int64_t step = int64_t(blockDim.x) * int64_t(gridDim.x);

    for (int64_t i = int64_t(blockIdx.x) * int64_t(blockDim.x) +
                     int64_t(threadIdx.x);
         i < n; i += step) {
        const int64_t c = i % d;
        if (c < start || c >= start + r) {
            out[i] = x[i];
            continue;
        }

        const int64_t row = i / d;
        const int64_t s = row / bh;
        const int64_t j = c - start;
        const int64_t partner = gptj ? (j ^ int64_t(1))
                                     : (j < half ? j + half : j - half);
        const bool negate = gptj ? ((j & 1) == 0) : (j < half);
        const int64_t col = reuse ? (gptj ? j / 2 : j % half) : j;
        const int64_t pi = row * d + start + partner;
        const int64_t fi = s * f + col;

        if (partner >= 0 && partner < r &&
            pi >= 0 && pi < n &&
            col >= 0 && col < f &&
            fi >= 0 && fi < nf) {
            const float a = static_cast<float>(x[i]);
            float b = static_cast<float>(x[pi]);
            if (negate) {
                b = -b;
            }
            const float theta = static_cast<float>(freqs[fi]);
            const float co = cosf(theta);
            const float si = sinf(theta);
            const float p = a * co;
            const float q = b * si;
            out[i] = static_cast<scalar_t>(p + q);
        }
    }
}

template <typename scalar_t, bool GPTJ>
__global__ void rope_paired_kernel(const scalar_t* __restrict__ x,
                                   const scalar_t* __restrict__ freqs,
                                   scalar_t* __restrict__ out,
                                   int64_t n, int64_t d, int64_t f,
                                   int64_t bh, int64_t nf) {
    #pragma clang fp contract(off)
    const int64_t half = d / 2;
    const int64_t pairs = n / 2;
    const int64_t step = int64_t(blockDim.x) * int64_t(gridDim.x);
    for (int64_t t = int64_t(blockIdx.x) * int64_t(blockDim.x) +
                     int64_t(threadIdx.x);
         t < pairs; t += step) {
        const int64_t row = t / half;
        const int64_t j = t % half;
        const int64_t s = row / bh;
        const int64_t fi = s * f + j;
        const int64_t ia = row * d + (GPTJ ? 2 * j : j);
        const int64_t ib = ia + (GPTJ ? 1 : half);
        if (ia >= 0 && ia < n && ib >= 0 && ib < n &&
            fi >= 0 && fi < nf) {
            const float a = static_cast<float>(x[ia]);
            const float b = static_cast<float>(x[ib]);
            const float theta = static_cast<float>(freqs[fi]);
            const float co = cosf(theta);
            const float si = sinf(theta);
            const float ac = a * co;
            const float bs = (-b) * si;
            const float bc = b * co;
            const float as = a * si;
            out[ia] = static_cast<scalar_t>(ac + bs);
            out[ib] = static_cast<scalar_t>(bc + as);
        }
    }
}

template <typename scalar_t, bool GPTJ, bool NopeFirst>
__global__ void rope_partial_paired_kernel(
        const scalar_t* __restrict__ x,
        const scalar_t* __restrict__ freqs,
        scalar_t* __restrict__ out,
        int64_t n, int64_t d, int64_t f, int64_t bh, int64_t nf) {
    #pragma clang fp contract(off)
    const int64_t pairs = n / 4;
    const int64_t r = 2 * f;
    const int64_t start = NopeFirst ? d - r : 0;
    const int64_t pass_start = NopeFirst ? 0 : r;
    const int64_t step = int64_t(blockDim.x) * int64_t(gridDim.x);
    for (int64_t t = int64_t(blockIdx.x) * int64_t(blockDim.x) +
                     int64_t(threadIdx.x);
         t < pairs; t += step) {
        const int64_t row = t / f;
        const int64_t j = t % f;
        const int64_t ia = row * d + start + (GPTJ ? 2 * j : j);
        const int64_t ib = ia + (GPTJ ? 1 : f);
        const int64_t fi = (row / bh) * f + j;
        if (ia >= 0 && ia < n && ib >= 0 && ib < n &&
            fi >= 0 && fi < nf) {
            const float a = static_cast<float>(x[ia]);
            const float b = static_cast<float>(x[ib]);
            const float theta = static_cast<float>(freqs[fi]);
            const float co = cosf(theta);
            const float si = sinf(theta);
            const float ac = a * co;
            const float bs = (-b) * si;
            const float bc = b * co;
            const float as = a * si;
            out[ia] = static_cast<scalar_t>(ac + bs);
            out[ib] = static_cast<scalar_t>(bc + as);
        }
        const int64_t pa = row * d + pass_start + 2 * j;
        const int64_t pb = pa + 1;
        if (pa >= 0 && pa < n && pb >= 0 && pb < n) {
            out[pa] = x[pa];
            out[pb] = x[pb];
        }
    }
}

template <typename scalar_t>
void launch_rope(const torch::Tensor& x, const torch::Tensor& freqs,
                 torch::Tensor& out, int flags, hipStream_t stream) {
    const int64_t n = x.numel();
    const int64_t d = x.size(3);
    const int64_t f = freqs.size(3);
    const int64_t bh = x.size(1) * x.size(2);
    const int64_t nf = freqs.numel();
    const scalar_t* xp = x.data_ptr<scalar_t>();
    const scalar_t* fp = freqs.data_ptr<scalar_t>();
    scalar_t* op = out.data_ptr<scalar_t>();
    const int64_t blocks = std::min<int64_t>((n - 1) / 256 + 1, 65535);

    if ((flags & 4) != 0 && 2 * f == d) {
        const int64_t pairs = n / 2;
        const int64_t pair_blocks =
            std::min<int64_t>((pairs - 1) / 256 + 1, 65535);
        if ((flags & 1) != 0) {
            hipLaunchKernelGGL((rope_paired_kernel<scalar_t, true>),
                               dim3(static_cast<unsigned>(pair_blocks)),
                               dim3(256), 0, stream, xp, fp, op, n, d, f, bh, nf);
        } else {
            hipLaunchKernelGGL((rope_paired_kernel<scalar_t, false>),
                               dim3(static_cast<unsigned>(pair_blocks)),
                               dim3(256), 0, stream, xp, fp, op, n, d, f, bh, nf);
        }
    } else if ((flags & 4) != 0 && 4 * f == d) {
        const int64_t pairs = n / 4;
        const int64_t pair_blocks =
            std::min<int64_t>((pairs - 1) / 256 + 1, 65535);
        if ((flags & 1) != 0) {
            if ((flags & 2) != 0) {
                hipLaunchKernelGGL((rope_partial_paired_kernel<scalar_t, true, true>),
                                   dim3(static_cast<unsigned>(pair_blocks)),
                                   dim3(256), 0, stream, xp, fp, op, n, d, f, bh, nf);
            } else {
                hipLaunchKernelGGL((rope_partial_paired_kernel<scalar_t, true, false>),
                                   dim3(static_cast<unsigned>(pair_blocks)),
                                   dim3(256), 0, stream, xp, fp, op, n, d, f, bh, nf);
            }
        } else {
            if ((flags & 2) != 0) {
                hipLaunchKernelGGL((rope_partial_paired_kernel<scalar_t, false, true>),
                                   dim3(static_cast<unsigned>(pair_blocks)),
                                   dim3(256), 0, stream, xp, fp, op, n, d, f, bh, nf);
            } else {
                hipLaunchKernelGGL((rope_partial_paired_kernel<scalar_t, false, false>),
                                   dim3(static_cast<unsigned>(pair_blocks)),
                                   dim3(256), 0, stream, xp, fp, op, n, d, f, bh, nf);
            }
        }
    } else {
        #define ROPE_CASE(K) \
            case K: \
                hipLaunchKernelGGL((rope_kernel<scalar_t, K>), \
                                   dim3(static_cast<unsigned>(blocks)), \
                                   dim3(256), 0, stream, xp, fp, op, n, d, f, bh, nf); \
                break

        switch (flags) {
            ROPE_CASE(0);
            ROPE_CASE(1);
            ROPE_CASE(2);
            ROPE_CASE(3);
            ROPE_CASE(4);
            ROPE_CASE(5);
            ROPE_CASE(6);
            ROPE_CASE(7);
        }

        #undef ROPE_CASE
    }

    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "RoPE kernel launch failed: ",
                hipGetErrorString(err));
}

torch::Tensor rope_forward(torch::Tensor x, torch::Tensor freqs,
                           int64_t rotate_style, bool nope_first,
                           bool reuse_freqs_front_part) {
    TORCH_CHECK(x.is_cuda() && freqs.is_cuda(), "Expected GPU tensors");
    TORCH_CHECK(x.device() == freqs.device(), "Device mismatch");
    TORCH_CHECK(x.is_contiguous() && freqs.is_contiguous(),
                "Expected contiguous tensors");
    TORCH_CHECK(x.scalar_type() == freqs.scalar_type(), "Dtype mismatch");
    TORCH_CHECK(x.scalar_type() == at::kFloat ||
                x.scalar_type() == at::kHalf ||
                x.scalar_type() == at::kBFloat16,
                "Unsupported dtype");
    TORCH_CHECK(x.dim() == 4 && freqs.dim() == 4,
                "Expected rank four");
    TORCH_CHECK(x.size(0) > 0 && x.size(1) > 0 && x.size(2) > 0 &&
                x.size(3) > 0,
                "Expected positive dimensions");

    const int64_t d = x.size(3);
    TORCH_CHECK(d >= 4 && d <= 256 && (d & (d - 1)) == 0,
                "Invalid head width");
    TORCH_CHECK(freqs.size(0) == x.size(0) &&
                freqs.size(1) == 1 &&
                freqs.size(2) == 1,
                "Invalid frequency shape");

    const int64_t f = freqs.size(3);
    TORCH_CHECK(reuse_freqs_front_part ? (f == d / 2 || f == d / 4)
                                       : (f == d || f == d / 2),
                "Invalid rotation width");
    TORCH_CHECK(rotate_style == 0 || rotate_style == 1,
                "Invalid rotation style");

    const int64_t r = f * (reuse_freqs_front_part ? 2 : 1);
    TORCH_CHECK(r <= d && r % 2 == 0, "Invalid rotation width");

    const c10::cuda::CUDAGuard guard(x.device());
    auto out = torch::empty_like(x);
    const auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());

    const int flags = static_cast<int>(rotate_style) |
                      (nope_first ? 2 : 0) |
                      (reuse_freqs_front_part ? 4 : 0);

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "rope_forward", [&] {
            launch_rope<scalar_t>(x, freqs, out, flags, stream.stream());
        });

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    RoPE (Rotary Position Embedding) forward: dense sbhd layout, with the
    rotation angles given directly as a freqs tensor (not a cached cos/sin table);
    the channels of every head vector are rotated as planes according to the
    sequence position.

    Semantics (the trigonometric functions and the multiply-add are all evaluated in
    float32; the output is cast back to the input dtype):
       The input is x (S, B, H, D) together with freqs (S, 1, 1, F); freqs
       broadcasts over the B and H dimensions.
       Rotation width R = F * 2 (reuse_freqs_front_part=True) or R = F (False).
       Split the last dimension (length D) into a "rotation segment" (length R) and
       a "pass-through segment" (length D - R): with nope_first=False the rotation
       segment occupies the first R channels, with True the last R channels.
       Angle row Theta (length R): with reuse=False, Theta = freqs, one angle per
       rotation channel; with reuse=True, F = R/2 angles are expanded to R columns --
       the NEOX style tiles the whole segment ([a, b] -> [a, b, a, b], each half used
       once), the GPTJ style repeats adjacently ([a, b] -> [a, a, b, b], each number
       pair shares one angle).
       For the rotation segment x_rot (length R) compute:
         out_rot = x_rot * cos(Theta) + rotate_half(x_rot) * sin(Theta)
       rotate_half is decided by the __init__ argument rotate_style:
         NEOX (rotate_style=0): rotate_half(x_rot) = concat(-x_rot[R/2:],
           x_rot[:R/2]), i.e. the first half u and the second half v are swapped with
           the u segment negated, which is equivalent to a plane rotation of every
           pair (u_j, v_j).
         GPTJ (rotate_style=1): even-odd channel pairing, rotate_half(x_rot)[2j] =
           -x_rot[2j+1], rotate_half(x_rot)[2j+1] = x_rot[2j].
       The pass-through segment is appended back without any transformation: with
       nope_first=False, out = concat(out_rot, pass-through segment); with True,
       out = concat(pass-through segment, out_rot).
       Boundary behaviour: when R = D the pass-through segment is empty (full-width
       rotation); when R < D the pass-through segment is kept verbatim, bit for bit;
       the last dimension F of freqs has only the three legal values {D, D/2, D/4}
       (their combination with reuse and R is listed below); all other
       configurations are undefined.

    Input/output specification:
        x      (S, B, H, D)  float16 / bfloat16, contiguous; D is a power of two
                              (4..256), S, B, H are arbitrary positive integers
        freqs  (S, 1, 1, F)  same dtype as x, contiguous; legal combinations:
                              full-width rotation reuse=False: F = D;
                              full-width rotation reuse=True: F = D/2;
                              partial rotation (R=D/2) reuse=False: F = D/2;
                              partial rotation (R=D/2) reuse=True: F = D/4
        output out (S, B, H, D), same dtype as x
        (the evaluator casts the input to fp32 before passing it in; fp16/bf16 ->
        fp32 is lossless)
        hyper-parameters (__init__): rotate_style (0=NEOX, 1=GPTJ), nope_first,
        reuse_freqs_front_part.

    Implementation constraints (violations are scored as failures):
        - The core computation (angle expansion, rotate_half, cos/sin and the
          multiply-add, concatenation of the pass-through segment) must be completed
          inside the submitted file with a HIP kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate computation; cast the output back to the input
          dtype.

    Forbidden: scaled_dot_product_attention / sdpa / flash_attn /
    torch.matmul / torch.bmm / torch.einsum / torch.softmax / torch.polar /
    torch.view_as_complex.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: dense sbhd non-cached forward; variable-length thd, cos/sin cache
    addressing, the dual-input GQA case, the backward pass, and 2D image rotation are
    outside this task.
    """
    def __init__(self, rotate_style: int, nope_first: bool, reuse_freqs_front_part: bool):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.rotate_style = int(rotate_style)
        self.nope_first = bool(nope_first)
        self.reuse_freqs_front_part = bool(reuse_freqs_front_part)
        # <<<END_IMPROVE>>>

    def forward(self, x, freqs):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().rope_forward(
            x, freqs, self.rotate_style, self.nope_first,
            self.reuse_freqs_front_part)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        x32 = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        f32 = freqs.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        d = x32.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        rotate_dim = f32.shape[-1] * (2 if self.reuse_freqs_front_part else 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        start = (d - rotate_dim) if self.nope_first else 0
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        x_rot = x32[..., start : start + rotate_dim]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        x_pass = torch.cat((x32[..., :start], x32[..., start + rotate_dim :]), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        theta = f32
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        if self.reuse_freqs_front_part and self.rotate_style == 0:
            theta = f32.repeat([1] * (f32.dim() - 1) + [2])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        if self.reuse_freqs_front_part and self.rotate_style == 1:
            theta = f32.repeat_interleave(2, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        half = rotate_dim // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        rot_half = x_rot
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        if self.rotate_style == 0:
            x1 = x_rot[..., :half]
            x2 = x_rot[..., half:]
            rot_half = torch.cat((-x2, x1), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        if self.rotate_style == 1:
            x1 = x_rot[..., ::2]
            x2 = x_rot[..., 1::2]
            rot_half = torch.stack((-x2, x1), dim=-1).flatten(-2)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        x_embed = x_rot * torch.cos(theta) + rot_half * torch.sin(theta)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        pieces = (x_pass, x_embed) if self.nope_first else (x_embed, x_pass)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        out = torch.cat(pieces, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        return out.to(dt)
        # <<<END_IMPROVE>>>
