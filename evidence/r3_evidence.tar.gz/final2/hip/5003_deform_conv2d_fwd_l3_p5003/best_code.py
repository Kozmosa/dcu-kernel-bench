import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor deform_forward(
    torch::Tensor x, torch::Tensor offset, torch::Tensor weight,
    torch::Tensor bias, torch::Tensor mask,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw, bool modulated);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_forward", &deform_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <limits>
#include <cmath>
#include <cstdint>

static int64_t checked_mul(int64_t a, int64_t b) {
    TORCH_CHECK(a >= 0 && b >= 0 &&
                (b == 0 || a <= std::numeric_limits<int64_t>::max() / b),
                "Tensor size overflow");
    return a * b;
}

static int64_t output_size(int64_t h, int64_t p, int64_t d,
                           int64_t r, int64_t stride) {
    __int128 t = (__int128)h + 2 * (__int128)p -
                 (__int128)d * (r - 1) - 1;
    __int128 q = t >= 0 ? t / stride : -((-t + stride - 1) / stride);
    q += 1;
    TORCH_CHECK(q >= 0 &&
                q <= std::numeric_limits<int64_t>::max(),
                "Invalid output dimension");
    return (int64_t)q;
}

template <typename T>
__device__ __forceinline__ float read_corner(
    const T* x, int64_t base, int64_t y, int64_t z,
    int64_t h, int64_t w) {
    if (y >= 0 && y < h && z >= 0 && z < w)
        return static_cast<float>(x[base + y * w + z]);
    return 0.0f;
}

template <typename T, bool Modulated>
__global__ void sample_kernel(
    const T* __restrict__ x,
    const T* __restrict__ offset,
    const T* __restrict__ mask,
    float* __restrict__ sampled,
    int64_t total, int64_t cdim, int64_t h, int64_t w,
    int64_t pcount, int64_t swidth, int64_t locations,
    int64_t out_w, int64_t stride_h, int64_t stride_w,
    int64_t pad_h, int64_t pad_w, int64_t dil_h, int64_t dil_w) {
    int64_t step = (int64_t)blockDim.x * gridDim.x;
    for (int64_t id = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
         id < total; id += step) {
        int64_t pos = id % locations;
        int64_t q = id / locations;
        int64_t p = q % pcount;
        q /= pcount;
        int64_t c = q % cdim;
        int64_t n = q / cdim;

        int64_t offset_base =
            (n * (2 * pcount) + 2 * p) * locations + pos;

        int64_t oi = pos / out_w;
        int64_t oj = pos % out_w;
        int64_t ki = p / swidth;
        int64_t kj = p % swidth;

        float yc = static_cast<float>(
            oi * stride_h + ki * dil_h - pad_h);
        float xc = static_cast<float>(
            oj * stride_w + kj * dil_w - pad_w);
        yc += static_cast<float>(offset[offset_base]);
        xc += static_cast<float>(offset[offset_base + locations]);

        float value = 0.0f;
        if (yc > -1.0f && yc < static_cast<float>(h) &&
            xc > -1.0f && xc < static_cast<float>(w)) {
            int64_t iy = (int64_t)floorf(yc);
            int64_t ix = (int64_t)floorf(xc);
            float wy = yc - static_cast<float>(iy);
            float wx = xc - static_cast<float>(ix);
            int64_t base = (n * cdim + c) * h * w;

            float v00 = read_corner(x, base, iy, ix, h, w);
            float v01 = read_corner(x, base, iy, ix + 1, h, w);
            float v10 = read_corner(x, base, iy + 1, ix, h, w);
            float v11 = read_corner(x, base, iy + 1, ix + 1, h, w);

            float a = v00 * ((1.0f - wy) * (1.0f - wx));
            float b = v01 * ((1.0f - wy) * wx);
            float cc = v10 * (wy * (1.0f - wx));
            float d = v11 * (wy * wx);
            value = ((a + b) + cc) + d;
        }

        if (Modulated) {
            value *= static_cast<float>(
                mask[(n * pcount + p) * locations + pos]);
        }
        sampled[id] = value;
    }
}

template <typename T>
__global__ void product_kernel(
    const T* __restrict__ weight,
    const float* __restrict__ sampled,
    const T* __restrict__ bias,
    T* __restrict__ output,
    int64_t kout, int64_t depth, int64_t locations,
    int64_t channel_tiles, int64_t spatial_tiles,
    int64_t tiles) {
    __shared__ float a[16][16];
    __shared__ float b[16][32];

    int64_t tid = threadIdx.x;
    int64_t row = tid / 16;
    int64_t col = tid % 16;

    for (int64_t tile = (int64_t)blockIdx.x;
         tile < tiles;
         tile += (int64_t)gridDim.x) {
        int64_t spatial_tile = tile % spatial_tiles;
        int64_t tmp = tile / spatial_tiles;
        int64_t channel_tile = tmp % channel_tiles;
        int64_t n = tmp / channel_tiles;

        int64_t kbase = channel_tile * 16;
        int64_t lbase = spatial_tile * 32;
        float acc0 = 0.0f;
        float acc1 = 0.0f;

        for (int64_t dbase = 0; dbase < depth; dbase += 16) {
            int64_t kr = kbase + row;
            int64_t dc = dbase + col;
            a[row][col] =
                (kr < kout && dc < depth)
                    ? static_cast<float>(weight[kr * depth + dc])
                    : 0.0f;

            for (int64_t j = tid; j < 512; j += 256) {
                int64_t rr = j / 32;
                int64_t zz = j % 32;
                int64_t dd = dbase + rr;
                int64_t ll = lbase + zz;
                b[rr][zz] =
                    (dd < depth && ll < locations)
                        ? sampled[(n * depth + dd) * locations + ll]
                        : 0.0f;
            }

            __syncthreads();

            #pragma unroll
            for (int i = 0; i < 16; ++i) {
                acc0 = fmaf(a[row][i], b[i][col], acc0);
                acc1 = fmaf(a[row][i], b[i][col + 16], acc1);
            }

            __syncthreads();
        }

        if (kbase + row < kout) {
            float bv = static_cast<float>(bias[kbase + row]);
            int64_t base = (n * kout + kbase + row) * locations;

            if (lbase + col < locations)
                output[base + lbase + col] =
                    static_cast<T>(acc0 + bv);
            if (lbase + col + 16 < locations)
                output[base + lbase + col + 16] =
                    static_cast<T>(acc1 + bv);
        }

        __syncthreads();
    }
}

static void check_launch() {
    hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess,
                "HIP launch failed: ", hipGetErrorString(error));
}

torch::Tensor deform_forward(
    torch::Tensor x, torch::Tensor offset, torch::Tensor weight,
    torch::Tensor bias, torch::Tensor mask,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw, bool modulated) {
    TORCH_CHECK(x.is_cuda(), "Expected GPU tensors");
    c10::cuda::CUDAGuard guard(x.device());

    TORCH_CHECK(
        x.scalar_type() == at::kFloat ||
        x.scalar_type() == at::kHalf ||
        x.scalar_type() == at::kBFloat16,
        "Unsupported dtype");

    for (const auto& t : {x, offset, weight, bias, mask}) {
        TORCH_CHECK(
            t.device() == x.device() &&
            t.scalar_type() == x.scalar_type() &&
            t.is_contiguous(),
            "Expected matching contiguous tensors");
    }

    TORCH_CHECK(
        x.dim() == 4 && offset.dim() == 4 &&
        weight.dim() == 4 && bias.dim() == 1 &&
        mask.dim() == 4,
        "Invalid tensor ranks");
    TORCH_CHECK(sh > 0 && sw > 0 && dh > 0 && dw > 0,
                "Invalid stride/dilation");

    int64_t n = x.size(0);
    int64_t c = x.size(1);
    int64_t h = x.size(2);
    int64_t w = x.size(3);
    int64_t k = weight.size(0);
    int64_t r = weight.size(2);
    int64_t s = weight.size(3);

    TORCH_CHECK(h > 0 && w > 0 && r > 0 && s > 0,
                "Invalid spatial dimensions");
    TORCH_CHECK(weight.size(1) == c && bias.size(0) == k,
                "Channel mismatch");

    int64_t oh = output_size(h, ph, dh, r, sh);
    int64_t ow = output_size(w, pw, dw, s, sw);
    int64_t pcount = checked_mul(r, s);
    int64_t depth = checked_mul(c, pcount);
    int64_t locations = checked_mul(oh, ow);
    int64_t offset_channels = checked_mul(2, pcount);

    TORCH_CHECK(
        offset.size(0) == n &&
        offset.size(1) == offset_channels &&
        offset.size(2) == oh &&
        offset.size(3) == ow,
        "Offset shape mismatch");
    TORCH_CHECK(
        mask.size(0) == n &&
        mask.size(1) == pcount &&
        mask.size(2) == oh &&
        mask.size(3) == ow,
        "Mask shape mismatch");

    int64_t total = checked_mul(checked_mul(n, depth), locations);
    int64_t output_count = checked_mul(checked_mul(n, k), locations);
    checked_mul(total, (int64_t)sizeof(float));
    checked_mul(output_count, (int64_t)x.element_size());

    auto output = torch::empty({n, k, oh, ow}, x.options());
    if (output_count == 0)
        return output;

    auto sampled = torch::empty(
        {n, depth, locations},
        x.options().dtype(at::kFloat));

    int64_t channel_tiles = (k + 15) / 16;
    int64_t spatial_tiles = (locations + 31) / 32;
    int64_t tiles = checked_mul(
        checked_mul(n, channel_tiles), spatial_tiles);

    auto* props = at::cuda::getCurrentDeviceProperties();
    TORCH_CHECK(props->maxThreadsPerBlock >= 256 &&
                props->sharedMemPerBlock >= 3072,
                "Unsupported device limits");

    int64_t max_blocks = std::min<int64_t>(
        65535, props->maxGridSize[0]);
    auto stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "deform_forward",
        [&] {
            if (total > 0) {
                int blocks = (int)std::min<int64_t>(
                    max_blocks, (total + 255) / 256);

                if (modulated) {
                    sample_kernel<scalar_t, true>
                        <<<blocks, 256, 0, stream>>>(
                            x.data_ptr<scalar_t>(),
                            offset.data_ptr<scalar_t>(),
                            mask.data_ptr<scalar_t>(),
                            sampled.data_ptr<float>(),
                            total, c, h, w, pcount, s,
                            locations, ow, sh, sw, ph, pw, dh, dw);
                } else {
                    sample_kernel<scalar_t, false>
                        <<<blocks, 256, 0, stream>>>(
                            x.data_ptr<scalar_t>(),
                            offset.data_ptr<scalar_t>(),
                            nullptr,
                            sampled.data_ptr<float>(),
                            total, c, h, w, pcount, s,
                            locations, ow, sh, sw, ph, pw, dh, dw);
                }
                check_launch();
            }

            int product_blocks = (int)std::min<int64_t>(
                max_blocks, tiles);
            product_kernel<scalar_t>
                <<<product_blocks, 256, 0, stream>>>(
                    weight.data_ptr<scalar_t>(),
                    sampled.data_ptr<float>(),
                    bias.data_ptr<scalar_t>(),
                    output.data_ptr<scalar_t>(),
                    k, depth, locations,
                    channel_tiles, spatial_tiles, tiles);
            check_launch();
        });

    return output;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Deformable 2D convolution forward (Deformable Convolution): sampling grid
    plus a handwritten bilinear interpolation.

    Semantics (NCHW, all intermediate computation in float32):
      For each output position (oi, oj) and kernel position p = i*S + j
      (i in [0,R), j in [0,S), row-major), the base sampling coordinate given by
      the regular convolutional receptive field is
          y0 = oi * stride_h + i * dilation_h - padding_h
          x0 = oj * stride_w + j * dilation_w - padding_w
      After adding the per-(output position x kernel position) offsets, the
      input map is sampled at real-valued coordinates with bilinear
      interpolation:
          yc = y0 + offset[n, 2*p,     oi, oj]     # even channel = y offset
          xc = x0 + offset[n, 2*p + 1, oi, oj]     # odd channel = x offset
          v(n, c, p, oi, oj) = bilinear(input map, yc, xc)
      The __init__ parameter variant selects one of the two paths:
          "modulated" (default, modulated form): the sampled value is
              additionally multiplied by the per-position modulation mask
              v *= mask[n, p, oi, oj]
          "plain" (mask-free form): mask does not take part in the computation
              (its contents are arbitrary, possibly garbage data).
      The output is a single tensor:
          out[n, k, oi, oj] = bias[k]
                              + sum_{c, p} v(n, c, p, oi, oj) * weight[k, c, i, j]
      After the computation it is cast back to the input dtype.

    Bilinear interpolation definition (point-wise identical to mainstream
    deformable convolution operators):
      Let iy = floor(yc), ix = floor(xc), wy = yc - iy, wx = xc - ix, and take
      the four corners (iy, ix), (iy, ix+1), (iy+1, ix), (iy+1, ix+1) with
      weights (1-wy)(1-wx), (1-wy)wx, wy(1-wx), wy*wx respectively; when either
      the row or the column of a corner is out of range (< 0 or > dim-1) that
      corner contributes 0 while the remaining corners are weighted as usual --
      i.e. zero-fill semantics: a partially out-of-range coordinate is still
      weighted by the remaining valid corners, and when it is entirely out of
      range (yc <= -1, outside the yc >= H-1 boundary band, etc.) the sampled
      value is 0. No clamp / nearest-neighbour pull-back is done anywhere.

    Input/output specification (all tensors contiguous, NCHW layout):
      x        float32 / float16 / bfloat16 (N, C, H, W)
      offset   same dtype as x (N, 2*R*S, H_out, W_out): 2 channels per kernel
               position (even channel = y offset, odd channel = x offset,
               p = i*S + j row-major)
      weight   same dtype as x (K, C, R, S)
      bias     same dtype as x (K,)
      mask     same dtype as x (N, R*S, H_out, W_out) (ignored when
               variant="plain")
      out      a single tensor, same dtype as x (N, K, H_out, W_out)
      H_out = (H + 2*padding_h - dilation_h*(R-1) - 1) // stride_h + 1, likewise
      for W_out. The evaluator casts all inputs to fp32 before the call
      (low-precision inputs are lossless).

    Implementation constraints (violations are scored as failures):
      - The core computation (sampling-grid construction, bilinear-interpolation
        sampling, mask modulation, the weighted reduction against weight) must
        be handwritten with a HIP kernel inside the submitted file.
      - forward returns the single tensor out (the evaluator compares a single
        output).
      - Interpolation and the weighted reduction are computed in float32, with
        the output cast back to the input dtype.
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torchvision (including torchvision.ops.deform_conv2d) /
    torch.nn.functional.conv2d (F.conv2d) / torch.nn.Conv2d /
    torch.nn.functional.grid_sample (F.grid_sample) /
    torch.nn.functional.unfold (F.unfold) / torch.matmul / torch.bmm /
    torch.mm / torch.einsum / torch.tensordot / miopen / hipdnn / aiter.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "modulated", stride=(1, 1), padding=(1, 1), dilation=(1, 1)):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("modulated", "plain"), "variant must be either modulated or plain"
        self.variant = variant
        self.stride = (int(stride[0]), int(stride[1]))
        self.padding = (int(padding[0]), int(padding[1]))
        self.dilation = (int(dilation[0]), int(dilation[1]))
        # <<<END_IMPROVE>>>

    def forward(self, x, offset, weight, bias, mask):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().deform_forward(
            x, offset, weight, bias, mask,
            self.stride[0], self.stride[1],
            self.padding[0], self.padding[1],
            self.dilation[0], self.dilation[1],
            self.variant == "modulated",
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        k_out = weight.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        r, s = weight.shape[2], weight.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        sh, sw = self.stride
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        ph, pw = self.padding
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dh, dw = self.dilation
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        h_out = (h + 2 * ph - (dh * (r - 1) + 1)) // sh + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        w_out = (w + 2 * pw - (dw * (s - 1) + 1)) // sw + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert offset.shape[1] == 2 * r * s and mask.shape[1] == r * s, \
            "the channel counts of offset/mask must be 2*R*S / R*S"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert offset.shape[2] == h_out and offset.shape[3] == w_out \
            and mask.shape[2] == h_out and mask.shape[3] == w_out, \
            "the spatial sizes of offset/mask must be (H_out, W_out)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        off = offset.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        wf = weight.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        bf = bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        dev = xf.device
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        base_y = (torch.arange(h_out, dtype=torch.float32, device=dev) * sh - ph).view(1, 1, h_out, 1) \
            + torch.arange(r, dtype=torch.float32, device=dev).view(r, 1, 1, 1) * dh
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        base_x = (torch.arange(w_out, dtype=torch.float32, device=dev) * sw - pw).view(1, 1, 1, w_out) \
            + torch.arange(s, dtype=torch.float32, device=dev).view(1, s, 1, 1) * dw
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        y_coord = (base_y + off[:, 0::2].reshape(n, r, s, h_out, w_out))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        x_coord = (base_x + off[:, 1::2].reshape(n, r, s, h_out, w_out))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        y_coord = y_coord.reshape(n, r * s, h_out, w_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        x_coord = x_coord.reshape(n, r * s, h_out, w_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        iy0 = torch.floor(y_coord).to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        ix0 = torch.floor(x_coord).to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        wy = y_coord - iy0.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        wx = x_coord - ix0.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        iy1 = iy0 + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_27>>>
        ix1 = ix0 + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_28>>>
        n_idx = torch.arange(n, device=xf.device).view(n, 1, 1, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_29>>>
        c_idx = torch.arange(c, device=xf.device).view(1, c, 1, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_30>>>
        def corner(iy, ix, wgt):
            valid = ((iy >= 0) & (iy <= h - 1) &
                     (ix >= 0) & (ix <= w - 1)).to(torch.float32)
            vals = xf[n_idx, c_idx,
                      iy.clamp(0, h - 1).unsqueeze(1),
                      ix.clamp(0, w - 1).unsqueeze(1)]
            return vals * valid.unsqueeze(1) * wgt.unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_31>>>
        sampled = (corner(iy0, ix0, (1.0 - wy) * (1.0 - wx))
                   + corner(iy0, ix1, (1.0 - wy) * wx)
                   + corner(iy1, ix0, wy * (1.0 - wx))
                   + corner(iy1, ix1, wy * wx))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_32>>>
        if self.variant == "modulated":
            sampled = sampled * mask.to(torch.float32).unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_33>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_34>>>
        y = y + bf.view(1, k_out, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_35>>>
        return y.view(n, k_out, h_out, w_out).to(x.dtype)
        # <<<END_IMPROVE>>>
