import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor moe_op(
    torch::Tensor A,
    torch::Tensor B,
    torch::Tensor topk_weights,
    torch::Tensor topk_ids,
    torch::Tensor sorted_token_ids,
    torch::Tensor expert_ids,
    torch::Tensor num_tokens_post_padded);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_op", &moe_op, "HIP MoE grouped GEMM");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <cstdint>
#include <limits>

template <typename scalar_t>
__global__ void moe_kernel(
    const scalar_t* __restrict__ a,
    const scalar_t* __restrict__ b,
    const float* __restrict__ weights,
    const int32_t* __restrict__ sorted_token_ids,
    const int32_t* __restrict__ expert_ids,
    const int32_t* __restrict__ num_tokens_post_padded,
    scalar_t* __restrict__ out,
    int64_t M,
    int64_t K,
    int64_t N,
    int64_t E,
    int64_t top_k,
    int64_t sorted_count,
    int64_t expert_count,
    int64_t slot_count)
{
    const int64_t tid = static_cast<int64_t>(threadIdx.x);
    const int64_t local_row = tid / 32;
    const int64_t local_col = tid % 32;
    const int64_t tile_n = static_cast<int64_t>(blockIdx.x);
    const int64_t grouped_subtile = static_cast<int64_t>(blockIdx.y);
    const int64_t block_index = grouped_subtile / 8;
    const int64_t subtile_index = grouped_subtile % 8;
    const int64_t n = tile_n * 32 + local_col;
    const int64_t sorted_index =
        block_index * 64 + subtile_index * 8 + local_row;

    if (n < 0 || n >= N || sorted_index < 0 ||
        sorted_index >= sorted_count || block_index < 0 ||
        block_index >= expert_count) {
        return;
    }

    const int64_t valid_padded =
        static_cast<int64_t>(*num_tokens_post_padded);
    if (valid_padded <= 0 || block_index >= valid_padded / 64) {
        return;
    }

    const int64_t slot =
        static_cast<int64_t>(sorted_token_ids[sorted_index]);
    if (slot < 0 || slot >= slot_count || top_k <= 0) {
        return;
    }

    const int64_t m = slot / top_k;
    const int64_t j = slot - m * top_k;
    if (m < 0 || m >= M || j < 0 || j >= top_k) {
        return;
    }

    const int64_t expert =
        static_cast<int64_t>(expert_ids[block_index]);
    if (expert < 0 || expert >= E) {
        return;
    }

    float acc = 0.0f;
    for (int64_t k = 0; k < K; ++k) {
        const int64_t a_index = m * K + k;
        const int64_t b_index = (expert * N + n) * K + k;
        if (a_index >= 0 && a_index < M * K &&
            b_index >= 0 && b_index < E * N * K) {
            acc += static_cast<float>(a[a_index]) *
                   static_cast<float>(b[b_index]);
        }
    }

    const int64_t weight_index = m * top_k + j;
    const int64_t out_index = slot * N + n;
    if (weight_index >= 0 && weight_index < slot_count &&
        out_index >= 0 && out_index < slot_count * N) {
        out[out_index] =
            static_cast<scalar_t>(acc * weights[weight_index]);
    }
}

template <typename scalar_t>
static void launch_moe(
    torch::Tensor A,
    torch::Tensor B,
    torch::Tensor topk_weights,
    torch::Tensor sorted_token_ids,
    torch::Tensor expert_ids,
    torch::Tensor num_tokens_post_padded,
    torch::Tensor out,
    int64_t M,
    int64_t K,
    int64_t N,
    int64_t E,
    int64_t top_k,
    int64_t sorted_count,
    int64_t expert_count,
    int64_t slot_count,
    int64_t grid_x,
    int64_t grid_y)
{
    TORCH_CHECK(grid_x > 0 && grid_y > 0,
                "invalid HIP launch dimensions");
    TORCH_CHECK(grid_x <= static_cast<int64_t>(std::numeric_limits<unsigned int>::max()),
                "N tile grid exceeds HIP launch range");
    TORCH_CHECK(grid_y <= static_cast<int64_t>(std::numeric_limits<unsigned int>::max()),
                "token tile grid exceeds HIP launch range");

    dim3 block(256, 1, 1);
    dim3 grid(
        static_cast<unsigned int>(grid_x),
        static_cast<unsigned int>(grid_y),
        1);

    auto stream = at::cuda::getCurrentCUDAStream();

    moe_kernel<scalar_t><<<grid, block, 0, stream.stream()>>>(
        A.data_ptr<scalar_t>(),
        B.data_ptr<scalar_t>(),
        topk_weights.data_ptr<float>(),
        sorted_token_ids.data_ptr<int32_t>(),
        expert_ids.data_ptr<int32_t>(),
        num_tokens_post_padded.data_ptr<int32_t>(),
        out.data_ptr<scalar_t>(),
        M, K, N, E, top_k, sorted_count, expert_count, slot_count);
}

torch::Tensor moe_op(
    torch::Tensor A,
    torch::Tensor B,
    torch::Tensor topk_weights,
    torch::Tensor topk_ids,
    torch::Tensor sorted_token_ids,
    torch::Tensor expert_ids,
    torch::Tensor num_tokens_post_padded)
{
    TORCH_CHECK(A.is_cuda(), "A must be a HIP CUDA tensor");
    TORCH_CHECK(B.is_cuda() && topk_weights.is_cuda() &&
                topk_ids.is_cuda() && sorted_token_ids.is_cuda() &&
                expert_ids.is_cuda() && num_tokens_post_padded.is_cuda(),
                "all inputs must be HIP CUDA tensors");

    TORCH_CHECK(A.device() == B.device() &&
                A.device() == topk_weights.device() &&
                A.device() == topk_ids.device() &&
                A.device() == sorted_token_ids.device() &&
                A.device() == expert_ids.device() &&
                A.device() == num_tokens_post_padded.device(),
                "all inputs must be on the same HIP device");

    TORCH_CHECK(A.dim() == 2 && B.dim() == 3,
                "invalid A or B dimensions");
    TORCH_CHECK(topk_weights.dim() == 2 && topk_ids.dim() == 2,
                "invalid routing dimensions");
    TORCH_CHECK(sorted_token_ids.dim() == 1 &&
                expert_ids.dim() == 1 &&
                num_tokens_post_padded.numel() == 1,
                "invalid layout metadata dimensions");
    TORCH_CHECK(A.scalar_type() == B.scalar_type(),
                "A and B must have the same dtype");
    TORCH_CHECK(A.scalar_type() == at::kHalf ||
                A.scalar_type() == at::kBFloat16 ||
                A.scalar_type() == at::kFloat,
                "A and B must be float16, bfloat16, or float32");
    TORCH_CHECK(topk_weights.scalar_type() == at::kFloat,
                "topk_weights must be float32");

    A = A.contiguous();
    B = B.contiguous();
    topk_weights = topk_weights.contiguous();
    topk_ids = topk_ids.to(at::kInt).contiguous();
    sorted_token_ids = sorted_token_ids.to(at::kInt).contiguous();
    expert_ids = expert_ids.to(at::kInt).contiguous();
    num_tokens_post_padded =
        num_tokens_post_padded.to(at::kInt).contiguous();

    const int64_t M = static_cast<int64_t>(A.size(0));
    const int64_t K = static_cast<int64_t>(A.size(1));
    const int64_t E = static_cast<int64_t>(B.size(0));
    const int64_t N = static_cast<int64_t>(B.size(1));
    const int64_t top_k = static_cast<int64_t>(topk_ids.size(1));
    const int64_t slot_count = M * top_k;
    const int64_t sorted_count =
        static_cast<int64_t>(sorted_token_ids.numel());
    const int64_t expert_count =
        static_cast<int64_t>(expert_ids.numel());

    TORCH_CHECK(B.size(2) == K, "incompatible K dimensions");
    TORCH_CHECK(topk_weights.size(0) == M &&
                static_cast<int64_t>(topk_weights.size(1)) == top_k,
                "incompatible routing weight dimensions");
    TORCH_CHECK(topk_ids.size(0) == M && top_k > 0 && top_k <= 8,
                "invalid routing dimensions");
    TORCH_CHECK(E > 0 && N > 0 && K > 0 && M >= 0,
                "invalid matrix dimensions");

    auto out = torch::zeros({M, top_k, N}, A.options());
    if (M == 0 || N == 0 || K == 0) {
        return out;
    }

    const int64_t padded_blocks = (sorted_count + 63) / 64;
    const int64_t grid_x = (N + 31) / 32;
    const int64_t grid_y = padded_blocks * 8;

    if (A.scalar_type() == at::kHalf) {
        launch_moe<at::Half>(
            A, B, topk_weights, sorted_token_ids, expert_ids,
            num_tokens_post_padded, out, M, K, N, E, top_k,
            sorted_count, expert_count, slot_count, grid_x, grid_y);
    } else if (A.scalar_type() == at::kBFloat16) {
        launch_moe<at::BFloat16>(
            A, B, topk_weights, sorted_token_ids, expert_ids,
            num_tokens_post_padded, out, M, K, N, E, top_k,
            sorted_count, expert_count, slot_count, grid_x, grid_y);
    } else {
        launch_moe<float>(
            A, B, topk_weights, sorted_token_ids, expert_ids,
            num_tokens_post_padded, out, M, K, N, E, top_k,
            sorted_count, expert_count, slot_count, grid_x, grid_y);
    }

    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "moe HIP kernel launch failed: ",
                hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    MoE (Mixture-of-Experts) routed grouped GEMM: non-quantized weights, with
    routing weighting.

    Each token's feature vector A[m] (K dimensions) is dispatched by the routing
    table topk_ids to top_k of the num_experts experts; expert e owns the weight
    matrix B[e] (N x K). For each token m and its j-th routing slot (write
    e = topk_ids[m, j]), the output is defined as

        C[m, j, n] = topk_weights[m, j] * sum_k A[m, k] * B[e, n, k]

    i.e. grouped GEMM followed by a per-slot multiply by the routing weight;
    intermediate accumulation is float32 and the output is cast back to the
    input dtype. Every (m, j) slot hits a legal expert inside [0, num_experts),
    so no output is undefined.

    The inputs also carry the block-aligned layout of grouped GEMM (produced by
    the upstream router; fetching data through it is exactly equivalent to
    computing the formula above directly):
      - sorted_token_ids: int32, length EM = M*top_k + num_experts*(block_m-1),
        with block_m always 64 in this task. Number the slots flat as
        p = m*top_k + j, regroup them by ascending expert id, and pad each group
        up to a multiple of block_m; the intra-group padding positions and the
        array tail hold the sentinel value M*top_k (that is num_valid_tokens;
        offs_token >= it means padding and produces no output).
      - expert_ids: int32, length M*top_k + num_experts; the expert id owning
        block t (covering sorted_token_ids[t*block_m : (t+1)*block_m]), values
        in [0, num_experts), no -1; positions past the number of blocks implied
        by num_tokens_post_padded are sentinel fill and must not be read.
      - num_tokens_post_padded: int32 scalar (length 1), the valid length of
        sorted_token_ids (intra-block padding included), always a multiple of
        block_m.
    The kernel's BLOCK_SIZE_M must divide block_m (that is, be a factor of 64)
    so that every program block sees a single expert.

    Input/output specification:
        A                       (M, K)             float16/bfloat16
        B                       (E, N, K)          same as A (E = num_experts)
        topk_weights            (M, top_k)         float32
        topk_ids                (M, top_k)         int32
        sorted_token_ids        (EM,)              int32
        expert_ids              (M*top_k + E,)     int32
        num_tokens_post_padded  (1,)               int32
        returns C               (M, top_k, N)      dtype same as A

    Implementation constraints (violations are scored as failures):
        - Core computation (layout-driven data fetch + grouped GEMM + weighted
          routing write-out) must be done in a HIP kernel inside the
          submitted file; calling torch.matmul / torch.mm / torch.bmm /
          torch.baddbmm / torch.addmm / torch.einsum /
          torch.nn.functional.linear or any precompiled operator library for
          any matrix multiply is forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate accumulation; the output is cast back to
          the input dtype.
        - Sentinel padding slots must not contaminate any valid output.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: non-quantized fp16/bf16 weights and activations (no w8a8 / int4 /
    mxfp4 quantization), no fused activation (SiLU/GELU etc.), no bias,
    top_k <= 8, num_experts <= 256.
    """
    def __init__(self, num_experts: int, top_k: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = num_experts
        self.top_k = top_k
        # <<<END_IMPROVE>>>

    def forward(self, A, B, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().moe_op(A, B, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        pass
        # <<<END_IMPROVE>>>
