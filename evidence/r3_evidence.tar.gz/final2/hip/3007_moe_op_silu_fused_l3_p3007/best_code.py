import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3007_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor moe_silu_forward(
    torch::Tensor A, torch::Tensor B, torch::Tensor A_scale,
    torch::Tensor B_scale, torch::Tensor topk_weights,
    torch::Tensor topk_ids, bool mul_routed_weight, bool fp8_block,
    int64_t block_n, int64_t block_k);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_silu_forward", &moe_silu_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cstdint>
#include <limits>

template<typename output_t, bool Quant, int ColsPerGroup, bool HoistScales>
__global__ void moe_silu_kernel(
    const float* A, const float* B, const float* AS, const float* BS,
    const float* weights, const int64_t* ids, output_t* out,
    int64_t M, int64_t K, int64_t E, int64_t N, int64_t topk,
    int64_t bn, int64_t bk, int64_t tiles, bool routed)
{
    __shared__ float gates[256];
    __shared__ float ups[256];

    const int64_t t = static_cast<int64_t>(threadIdx.x);
    const int64_t lane = t & 31;
    const int64_t group = t >> 5;
    const int64_t tile_width = 8 * static_cast<int64_t>(ColsPerGroup);
    const int64_t columns = N / tile_width + (N % tile_width != 0);
    const int64_t rows = M * topk;
    const int64_t sk = Quant ? K / bk : 0;
    const int64_t sn = Quant ? (2 * N) / bn : 0;

    for (int64_t tile = static_cast<int64_t>(blockIdx.x);
         tile < tiles;
         tile += static_cast<int64_t>(gridDim.x)) {
        const int64_t r = tile / columns;
        const int64_t tile_col = tile % columns;
        const int64_t m = topk > 0 ? r / topk : 0;
        const int64_t e = (r < rows) ? ids[r] : -1;
        const bool valid = r < rows && m < M && e >= 0 && e < E;

        float gate[ColsPerGroup];
        float up[ColsPerGroup];
        int64_t n[ColsPerGroup];
        int64_t gate_scale_row[ColsPerGroup];
        int64_t up_scale_row[ColsPerGroup];

        #pragma unroll
        for (int c = 0; c < ColsPerGroup; ++c) {
            gate[c] = 0.0f;
            up[c] = 0.0f;
            n[c] = tile_col * tile_width + group + static_cast<int64_t>(8 * c);
            if (Quant && HoistScales && valid && n[c] < N) {
                gate_scale_row[c] = (e * sn + n[c] / bn) * sk;
                up_scale_row[c] = (e * sn + (N + n[c]) / bn) * sk;
            }
        }

        for (int64_t base = 0; base < K; base += 128) {
            float a_scale = 1.0f;
            float gate_scale[ColsPerGroup];
            float up_scale[ColsPerGroup];
            if (Quant && HoistScales && valid && n[0] < N && base < K) {
                const int64_t scale_k = base / bk;
                a_scale = AS[m * sk + scale_k];
                #pragma unroll
                for (int c = 0; c < ColsPerGroup; ++c) {
                    if (n[c] < N) {
                        gate_scale[c] = BS[gate_scale_row[c] + scale_k];
                        up_scale[c] = BS[up_scale_row[c] + scale_k];
                    }
                }
            }
            if (valid && n[0] < N) {
                #pragma unroll
                for (int q = 0; q < 4; ++q) {
                    const int64_t k = base + lane + static_cast<int64_t>(q * 32);
                    if (k < K) {
                        float a = A[m * K + k];
                        if (Quant) {
                            if (HoistScales) {
                                a *= a_scale;
                            } else {
                                a *= AS[m * sk + k / bk];
                            }
                        }

                        #pragma unroll
                        for (int c = 0; c < ColsPerGroup; ++c) {
                            if (n[c] < N) {
                                const int64_t gate_row = n[c];
                                const int64_t up_row = N + n[c];
                                float bg = B[(e * (2 * N) + gate_row) * K + k];
                                float bu = B[(e * (2 * N) + up_row) * K + k];
                                if (Quant) {
                                    if (HoistScales) {
                                        bg *= gate_scale[c];
                                        bu *= up_scale[c];
                                    } else {
                                        bg *= BS[(e * sn + gate_row / bn) * sk + k / bk];
                                        bu *= BS[(e * sn + up_row / bn) * sk + k / bk];
                                    }
                                }
                                gate[c] = fmaf(a, bg, gate[c]);
                                up[c] = fmaf(a, bu, up[c]);
                            }
                        }
                    }
                }
            }
        }

        if (warpSize >= 32 && warpSize % 32 == 0) {
            #pragma unroll
            for (int delta = 16; delta > 0; delta >>= 1) {
                #pragma unroll
                for (int c = 0; c < ColsPerGroup; ++c) {
                    const float og = __shfl_down(gate[c], delta, 32);
                    const float ou = __shfl_down(up[c], delta, 32);
                    if (lane < delta) {
                        gate[c] += og;
                        up[c] += ou;
                    }
                }
            }
        } else {
            #pragma unroll
            for (int c = 0; c < ColsPerGroup; ++c) {
                gates[t] = gate[c];
                ups[t] = up[c];
                __syncthreads();

                for (int64_t delta = 16; delta > 0; delta >>= 1) {
                    if (lane < delta) {
                        gates[t] += gates[t + delta];
                        ups[t] += ups[t + delta];
                    }
                    __syncthreads();
                }

                gate[c] = gates[t];
                up[c] = ups[t];
                __syncthreads();
            }
        }

        if (lane == 0 && r < rows) {
            float w = routed ? weights[r] : 1.0f;
            #pragma unroll
            for (int c = 0; c < ColsPerGroup; ++c) {
                if (n[c] < N) {
                    const float g = gate[c] * w;
                    const float u = up[c] * w;
                    out[r * N + n[c]] = static_cast<output_t>(
                        (g / (1.0f + expf(-g))) * u);
                }
            }
        }
        __syncthreads();
    }
}

torch::Tensor moe_silu_forward(
    torch::Tensor A, torch::Tensor B, torch::Tensor A_scale,
    torch::Tensor B_scale, torch::Tensor topk_weights,
    torch::Tensor topk_ids, bool mul_routed_weight, bool fp8_block,
    int64_t block_n, int64_t block_k)
{
    TORCH_CHECK(A.is_cuda(), "A must be on a HIP device");
    const c10::cuda::CUDAGuard guard(A.device());

    TORCH_CHECK(B.device() == A.device() &&
                topk_weights.device() == A.device() &&
                topk_ids.device() == A.device(),
                "Inputs must share a device");
    TORCH_CHECK(A.dim() == 2 && B.dim() == 3, "Invalid A/B rank");
    TORCH_CHECK(topk_ids.dim() == 2 && topk_weights.dim() == 2,
                "Routing tensors must have rank two");

    const int64_t M = A.size(0);
    const int64_t K = A.size(1);
    const int64_t E = B.size(0);
    const int64_t N2 = B.size(1);

    TORCH_CHECK(M >= 1 && K >= 1 && E >= 1 && N2 % 2 == 0 &&
                B.size(2) == K, "Invalid matrix dimensions");

    const int64_t N = N2 / 2;
    const int64_t topk = topk_ids.size(1);

    TORCH_CHECK(topk >= 1 && topk_ids.size(0) == M &&
                topk_weights.sizes() == topk_ids.sizes(),
                "Invalid routing shape");
    TORCH_CHECK(block_n >= 1 && block_k >= 1,
                "Invalid quantization blocks");
    TORCH_CHECK(topk_weights.scalar_type() == at::kFloat ||
                topk_weights.scalar_type() == at::kHalf ||
                topk_weights.scalar_type() == at::kBFloat16,
                "Unsupported output dtype");
    TORCH_CHECK(M <= std::numeric_limits<int64_t>::max() / topk,
                "Routing size overflow");

    const int64_t rows = M * topk;
    TORCH_CHECK(N == 0 || rows <= std::numeric_limits<int64_t>::max() / N,
                "Output size overflow");

    torch::Tensor as, bs;
    if (fp8_block) {
        TORCH_CHECK(K % block_k == 0 && N2 % block_n == 0,
                    "Quantization dimensions must be divisible by block sizes");
        TORCH_CHECK(A_scale.device() == A.device() &&
                    B_scale.device() == A.device(),
                    "Scales must share the input device");
        TORCH_CHECK(A_scale.dim() == 2 && A_scale.size(0) == M &&
                    A_scale.size(1) == K / block_k,
                    "Invalid A_scale shape");
        TORCH_CHECK(B_scale.dim() == 3 && B_scale.size(0) == E &&
                    B_scale.size(1) == N2 / block_n &&
                    B_scale.size(2) == K / block_k,
                    "Invalid B_scale shape");
        as = A_scale.to(at::kFloat).contiguous();
        bs = B_scale.to(at::kFloat).contiguous();
    }

    auto a = A.to(at::kFloat).contiguous();
    auto b = B.to(at::kFloat).contiguous();
    auto w = topk_weights.to(at::kFloat).contiguous();
    auto ids = topk_ids.to(at::kLong).contiguous();
    auto out = torch::empty({rows, N}, topk_weights.options());

    if (N == 0) {
        return out;
    }

    const int64_t cols_per_group = N >= 64 ? 8 : (N >= 32 ? 4 : 2);
    const int64_t tile_width = 8 * cols_per_group;
    const int64_t columns = N / tile_width + (N % tile_width != 0);
    TORCH_CHECK(rows <= std::numeric_limits<int64_t>::max() / columns,
                "Tile count overflow");
    const int64_t tiles = rows * columns;
    TORCH_CHECK(tiles > 0, "Invalid tile count");

    const unsigned blocks = static_cast<unsigned>(
        std::min<int64_t>(tiles, 65535));
    const auto stream = at::cuda::getCurrentCUDAStream(A.get_device());
    const float* asp = fp8_block ? as.data_ptr<float>() : nullptr;
    const float* bsp = fp8_block ? bs.data_ptr<float>() : nullptr;
    const bool hoist_scales = block_k >= 128 && block_k % 128 == 0;

#define LAUNCH_MOE(QUANT, COLS, HOIST) \
    moe_silu_kernel<scalar_t, QUANT, COLS, HOIST> \
        <<<blocks, 256, 0, stream>>>( \
            a.data_ptr<float>(), b.data_ptr<float>(), \
            asp, bsp, w.data_ptr<float>(), ids.data_ptr<int64_t>(), \
            out.data_ptr<scalar_t>(), M, K, E, N, topk, \
            block_n, block_k, tiles, mul_routed_weight)

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        out.scalar_type(), "moe_silu_forward", [&] {
            if (cols_per_group == 8) {
                if (fp8_block) {
                    if (hoist_scales) {
                        LAUNCH_MOE(true, 8, true);
                    } else {
                        LAUNCH_MOE(true, 8, false);
                    }
                } else {
                    LAUNCH_MOE(false, 8, false);
                }
            } else if (cols_per_group == 4) {
                if (fp8_block) {
                    if (hoist_scales) {
                        LAUNCH_MOE(true, 4, true);
                    } else {
                        LAUNCH_MOE(true, 4, false);
                    }
                } else {
                    LAUNCH_MOE(false, 4, false);
                }
            } else {
                if (fp8_block) {
                    if (hoist_scales) {
                        LAUNCH_MOE(true, 2, true);
                    } else {
                        LAUNCH_MOE(true, 2, false);
                    }
                } else {
                    LAUNCH_MOE(false, 2, false);
                }
            }
        });
#undef LAUNCH_MOE

    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "moe_silu kernel launch failed: ",
                hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    SiLU-and-multiply fused into the epilogue of an MoE (Mixture of Experts)
    single-layer expert FFN grouped GEMM: one kernel performs the grouped matrix
    multiply of tokens against expert weights, the routing weight weighting and
    the SwiGLU-style activation together, so no intermediate activation is
    materialized.

    Operator semantics: given
        A             activations (M, K)
        B             expert weights (E, 2N, K), the transposed weight matrix of
                      the e-th expert
        topk_ids      routing result (M, top_k), elements in [0, E), distinct
                      within a row
        topk_weights  routing weights (M, top_k), always positive within a row,
                      no normalization needed
        and the three scheduling tensors precomputed from topk_ids by the
        upstream alignment operator
        sorted_token_ids / expert_ids / num_tokens_post_padded (see the input
        specification).
    For each token m and its j-th selected expert e = topk_ids[m, j]:
        x[m, j, :] = A[m, :] @ B[e, :, :]^T          in R^{2N}
        if mul_routed_weight = True: x[m, j, :] *= topk_weights[m, j]
        out[m*top_k + j, i] = SiLU(x[m, j, i]) * x[m, j, N + i],  i in [0, N)
    where SiLU(u) = u / (1 + exp(-u)) = u * sigmoid(u). The 2N output dimensions
    of B use the chunked gating layout: the first N rows are gate and the last N
    rows are up (distinct from the interleaved layout). Every row of the output
    (M*top_k, N) is written by exactly one expert (routing guarantees that every
    row has an owner).

    fp8 block-quantized mode: with quant="fp8_block", A / B are float8_e4m3 code
    words taking part in the same math after dequantization:
        A_deq[m, k]  = A[m, k]  * A_scale[m,  k // block_k]
        B_deq[e, j, k] = B[e, j, k] * B_scale[e, j // block_n, k // block_k]
    This mode requires K % block_k == 0 and 2N % block_n == 0 (no scale tail
    block). With quant="dense", A / B are the raw weights and A_scale / B_scale
    are ignored one-element placeholder tensors.

    Boundary behaviour:
      - slots in sorted_token_ids whose value is >= M*top_k are alignment padding
        sentinels: they take no part in the computation and produce no output
        row; expert_ids is valid only inside the first ceil(num_tokens_post_padded
        / block_size_m) blocks (the valid prefix takes values in [0, E), with no
        cross-card -1 sentinel, and the tail holds unconsumed fill values).
      - an expert selected by no token does not read its B rows.
      - the three scheduling tensors and topk_ids are mutually redundant (all
        derived from the same topk_ids); the core scheduling may use either
        information source, but the output must match the math defined above in
        terms of topk_ids.

    Input/output specification:
        A            (M, K)    float16/bfloat16 (e4m3 code words in fp8_block
                               mode)
        B            (E, 2N, K) same as A (e4m3 code words in fp8_block mode)
        A_scale      (M, K//block_k) float32 ((1,) placeholder in dense mode)
        B_scale      (E, 2N//block_n, K//block_k) float32 ((1,) placeholder in
                     dense mode)
        topk_weights (M, top_k) float16/bfloat16, same dtype as the output
        topk_ids     (M, top_k) int64
        sorted_token_ids (M*top_k + E*(block_size_m-1),) int32
        expert_ids   (M*top_k + E,) int32
        num_tokens_post_padded (1,) int32
        out          (M*top_k, N), dtype same as topk_weights.
        M, K, E, top_k, block_size_m >= 1; 2N is even; input magnitudes are the
        usual randn/rand scale with no inf/NaN. The evaluator casts all inputs
        to fp32 before passing them in (integer types restore exactly,
        fp16/bf16/fp8 -> fp32 is lossless), so when topk_weights is fp32 the
        output is fp32 as well.

    Implementation constraints (violations are scored as failures):
      - Core computation (the grouped GEMM, fp8 dequantization, the routing
        weight multiply, the SiLU-and-multiply epilogue) must be done with a
        HIP kernel inside the submitted file, with intermediate accumulation
        always float32 and the output cast back to the dtype of topk_weights.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Materializing the intermediate activation (the 2N-wide GEMM result) to
        device memory and then activating it is forbidden -- the whole point of
        this operator is epilogue fusion, so the activation is done in place
        block by block.

    Disallowed list: torch.matmul / torch.bmm / torch.einsum /
    torch._scaled_mm / torch.nn.functional.silu / torch.SiLU / torch.sigmoid.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, mul_routed_weight=True, quant="dense", block_n=128, block_k=128):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert quant in ("dense", "fp8_block"), "quant must be one of dense / fp8_block"
        assert block_n >= 1 and block_k >= 1, "block_n / block_k must be >= 1"
        self.mul_routed_weight = bool(mul_routed_weight)
        self.quant = quant
        self.block_n = int(block_n)
        self.block_k = int(block_k)
        # <<<END_IMPROVE>>>

    def forward(self, A, B, A_scale, B_scale, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().moe_silu_forward(
            A, B, A_scale, B_scale, topk_weights, topk_ids,
            self.mul_routed_weight, self.quant == "fp8_block",
            self.block_n, self.block_k)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        sorted_token_ids = sorted_token_ids.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        expert_ids = expert_ids.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens_post_padded = num_tokens_post_padded.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = A.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        E, N2, _ = B.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert N2 % 2 == 0, "the 2N output dimension of B must be even"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        N = N2 // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out_dtype = topk_weights.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _ = (sorted_token_ids, expert_ids, num_tokens_post_padded)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return _pyramidkernel_get_extension().moe_silu_forward(
            A, B, A_scale, B_scale, topk_weights, topk_ids,
            self.mul_routed_weight, self.quant == "fp8_block",
            self.block_n, self.block_k)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        b = B.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        tw = topk_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        out = torch.zeros(M * top_k, N, dtype=torch.float32, device=A.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return out.to(out_dtype)
        # <<<END_IMPROVE>>>
