import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

torch::Tensor moe_align_hip(torch::Tensor topk_ids, int64_t num_experts,
                            int64_t block_size);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_align", &moe_align_hip, "MoE alignment (HIP)");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>

template <typename T>
__device__ __forceinline__ int64_t read_id(const T* p, int64_t i) {
    return static_cast<int64_t>(p[i]);
}

template <typename T>
__global__ void count_kernel(const T* ids, int64_t n, int64_t ecount,
                             int64_t qcount, int64_t* counts, float* out,
                             int64_t l1, int64_t l2) {
    __shared__ int64_t values[256];
    int64_t t = static_cast<int64_t>(threadIdx.x);
    int64_t init_i = static_cast<int64_t>(blockIdx.x) *
                     static_cast<int64_t>(blockDim.x) + t;
    int64_t init_step = static_cast<int64_t>(gridDim.x) *
                        static_cast<int64_t>(blockDim.x);
    int64_t init_n = l1 + l2;
    for (int64_t i = init_i; i < init_n; i += init_step)
        out[i] = i < l1 ? static_cast<float>(n) : -1.0f;

    int64_t tasks = ecount * qcount;
    for (int64_t task = static_cast<int64_t>(blockIdx.x);
         task < tasks; task += static_cast<int64_t>(gridDim.x)) {
        int64_t e = task / qcount;
        int64_t q = task % qcount;
        int64_t i = q * 256 + t;
        values[t] = (i < n && read_id(ids, i) == e) ? 1 : 0;
        __syncthreads();
        for (int64_t stride = 128; stride > 0; stride /= 2) {
            if (t < stride) values[t] += values[t + stride];
            __syncthreads();
        }
        if (t == 0) counts[task] = values[0];
        __syncthreads();
    }
}

__global__ void expert_scan_kernel(int64_t* counts, int64_t* totals,
                                   int64_t ecount, int64_t qcount) {
    __shared__ int64_t values[256];
    __shared__ int64_t tile_sum;
    __shared__ int64_t carry;
    int64_t t = static_cast<int64_t>(threadIdx.x);
    for (int64_t e = static_cast<int64_t>(blockIdx.x);
         e < ecount; e += static_cast<int64_t>(gridDim.x)) {
        int64_t base = e * qcount;
        if (t == 0) carry = 0;
        __syncthreads();
        for (int64_t qbase = 0; qbase < qcount; qbase += 256) {
            int64_t q = qbase + t;
            values[t] = q < qcount ? counts[base + q] : 0;
            __syncthreads();
            for (int64_t stride = 1; stride < 256; stride *= 2) {
                int64_t k = (t + 1) * (stride * 2) - 1;
                if (k < 256) values[k] += values[k - stride];
                __syncthreads();
            }
            if (t == 0) {
                tile_sum = values[255];
                values[255] = 0;
            }
            __syncthreads();
            for (int64_t stride = 128; stride > 0; stride /= 2) {
                int64_t k = (t + 1) * (stride * 2) - 1;
                if (k < 256) {
                    int64_t left = values[k - stride];
                    values[k - stride] = values[k];
                    values[k] += left;
                }
                __syncthreads();
            }
            if (q < qcount) counts[base + q] = carry + values[t];
            __syncthreads();
            if (t == 0) carry += tile_sum;
            __syncthreads();
        }
        if (t == 0) totals[e] = carry;
        __syncthreads();
    }
}

__global__ void layout_kernel(const int64_t* totals, int64_t* starts,
                              int64_t* padded, int64_t* total_slots,
                              int64_t ecount, int64_t block_size,
                              float* out, int64_t scalar_pos) {
    if (blockIdx.x != 0 || threadIdx.x != 0) return;
    int64_t sum = 0;
    for (int64_t e = 0; e < ecount; ++e) {
        int64_t count = totals[e];
        int64_t blocks = (count + block_size - 1) / block_size;
        int64_t slots = blocks * block_size;
        starts[e] = sum;
        padded[e] = slots;
        sum += slots;
    }
    total_slots[0] = sum;
    out[scalar_pos] = static_cast<float>(sum);
}

template <typename T>
__global__ void scatter_kernel(const T* ids, int64_t n, int64_t ecount,
                               int64_t qcount, const int64_t* prefixes,
                               const int64_t* starts,
                               const int64_t* padded, int64_t block_size,
                               float* out, int64_t l1, int64_t l2) {
    __shared__ int64_t ranks[256];
    int64_t t = static_cast<int64_t>(threadIdx.x);
    int64_t tasks = ecount * qcount;
    for (int64_t task = static_cast<int64_t>(blockIdx.x);
         task < tasks; task += static_cast<int64_t>(gridDim.x)) {
        int64_t e = task / qcount;
        int64_t q = task % qcount;
        int64_t i = q * 256 + t;
        bool match = i < n && read_id(ids, i) == e;
        ranks[t] = match ? 1 : 0;
        __syncthreads();
        for (int64_t stride = 1; stride < 256; stride *= 2) {
            int64_t k = (t + 1) * (stride * 2) - 1;
            if (k < 256) ranks[k] += ranks[k - stride];
            __syncthreads();
        }
        if (t == 0) ranks[255] = 0;
        __syncthreads();
        for (int64_t stride = 128; stride > 0; stride /= 2) {
            int64_t k = (t + 1) * (stride * 2) - 1;
            if (k < 256) {
                int64_t left = ranks[k - stride];
                ranks[k - stride] = ranks[k];
                ranks[k] += left;
            }
            __syncthreads();
        }
        if (match) {
            int64_t dst = starts[e] + prefixes[task] + ranks[t];
            if (dst >= 0 && dst < l1)
                out[dst] = static_cast<float>(i);
        }
        __syncthreads();

        if (q == 0) {
            int64_t first = starts[e] / block_size;
            int64_t blocks = padded[e] / block_size;
            for (int64_t j = t; j < blocks;
                 j += static_cast<int64_t>(blockDim.x)) {
                int64_t d = first + j;
                if (d >= 0 && d < l2)
                    out[l1 + d] = static_cast<float>(e);
            }
        }
        __syncthreads();
    }
}

static int capped_grid(int64_t blocks) {
    if (blocks < 1) blocks = 1;
    if (blocks > 65535) blocks = 65535;
    return static_cast<int>(blocks);
}

template <typename T>
static torch::Tensor moe_impl(torch::Tensor ids, int64_t ecount,
                              int64_t block_size) {
    int64_t n = static_cast<int64_t>(ids.numel());
    int64_t qcount = (n + 255) / 256;
    int64_t l1 = n + ecount * (block_size - 1);
    int64_t l2 = (l1 + block_size - 1) / block_size;

    auto out = torch::empty({l1 + l2 + 1},
                            ids.options().dtype(torch::kFloat32));
    auto opt = ids.options().dtype(torch::kInt64);
    auto counts = torch::empty({ecount * qcount}, opt);
    auto totals = torch::empty({ecount}, opt);
    auto starts = torch::empty({ecount}, opt);
    auto padded = torch::empty({ecount}, opt);
    auto total_slots = torch::empty({1}, opt);

    int64_t tasks = ecount * qcount;
    int cb = capped_grid(tasks);

    hipStream_t stream =
        at::cuda::getCurrentCUDAStream(ids.device().index());

    hipLaunchKernelGGL((count_kernel<T>), dim3(cb), dim3(256), 0, stream,
                       ids.data_ptr<T>(), n, ecount, qcount,
                       counts.data_ptr<int64_t>(), out.data_ptr<float>(),
                       l1, l2);
    TORCH_CHECK(hipGetLastError() == hipSuccess,
                "count kernel launch failed");

    hipLaunchKernelGGL(expert_scan_kernel, dim3(capped_grid(ecount)), dim3(256),
                       0, stream, counts.data_ptr<int64_t>(),
                       totals.data_ptr<int64_t>(), ecount, qcount);
    TORCH_CHECK(hipGetLastError() == hipSuccess,
                "expert scan kernel launch failed");

    hipLaunchKernelGGL(layout_kernel, dim3(1), dim3(1), 0, stream,
                       totals.data_ptr<int64_t>(), starts.data_ptr<int64_t>(),
                       padded.data_ptr<int64_t>(),
                       total_slots.data_ptr<int64_t>(), ecount, block_size,
                       out.data_ptr<float>(), l1 + l2);
    TORCH_CHECK(hipGetLastError() == hipSuccess,
                "layout kernel launch failed");

    hipLaunchKernelGGL((scatter_kernel<T>), dim3(cb), dim3(256), 0, stream,
                       ids.data_ptr<T>(), n, ecount, qcount,
                       counts.data_ptr<int64_t>(), starts.data_ptr<int64_t>(),
                       padded.data_ptr<int64_t>(), block_size,
                       out.data_ptr<float>(), l1, l2);
    TORCH_CHECK(hipGetLastError() == hipSuccess,
                "scatter kernel launch failed");

    return out;
}

torch::Tensor moe_align_hip(torch::Tensor topk_ids, int64_t num_experts,
                            int64_t block_size) {
    TORCH_CHECK(topk_ids.is_cuda(), "topk_ids must be a CUDA/HIP tensor");
    TORCH_CHECK(topk_ids.dim() == 2, "topk_ids must be 2-dimensional");
    TORCH_CHECK(topk_ids.is_contiguous(), "topk_ids must be contiguous");
    TORCH_CHECK(num_experts > 0, "num_experts must be positive");
    TORCH_CHECK(block_size > 0, "block_size must be positive");
    TORCH_CHECK(topk_ids.scalar_type() == torch::kInt32 ||
                topk_ids.scalar_type() == torch::kInt64 ||
                topk_ids.scalar_type() == torch::kFloat32,
                "topk_ids must have int32, int64, or float32 dtype");

    c10::cuda::CUDAGuard guard(topk_ids.device());
    switch (topk_ids.scalar_type()) {
        case torch::kInt32:
            return moe_impl<int32_t>(topk_ids, num_experts, block_size);
        case torch::kInt64:
            return moe_impl<int64_t>(topk_ids, num_experts, block_size);
        case torch::kFloat32:
            return moe_impl<float>(topk_ids, num_experts, block_size);
        default:
            TORCH_CHECK(false, "unsupported topk_ids dtype");
    }
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Scheduling prologue of MoE grouped GEMM: tokens bucketized per expert and
    laid out aligned to block_size.

    The input topk_ids ([num_tokens, top_k], elements are expert ids in
    [0, num_experts), duplicates allowed within a row) holds the experts the
    router selected for each token. Write the flattened index
    i = t * top_k + j (t is the token row, j the column), N = num_tokens * top_k,
    E = num_experts, B = block_size. For every expert e:
        T_e = { i : the i-th element of flattened topk_ids == e } (ascending i)
        n_blocks_e = ceil(|T_e| / B)        # aligned blocks occupied by e
        padded_e   = n_blocks_e * B         # aligned slot count of e
    Produce the three scheduling tensors of grouped GEMM:
        sorted_token_ids  length L1 = N + E*(B-1): for e = 0..E-1 in order, all
          indices of T_e (ascending), then padded_e - |T_e| fill sentinels N;
          the buffer tail [S, L1) is also sentinel N, where S = sum_e padded_e
        expert_ids        length L2 = ceil(L1/B): for e = 0..E-1 in order,
          n_blocks_e copies of e (together the first S/B positions), the tail
          [S/B, L2) filled with the -1 sentinel
        num_tokens_post_pad  scalar S (total padded slot count, always a
          multiple of B)
    grouped GEMM takes every B consecutive slots of sorted_token_ids as one
    M-tile, uses expert_ids as that tile's expert id to fetch weights, skips
    fill slots whose value is sentinel N, and num_tokens_post_pad gives the
    valid total length. This task is that scheduling prologue itself and does
    not include the GEMM.

    Boundary behaviour: an expert with |T_e| = 0 occupies 0 blocks and yields no
    sorted entry and no expert entry; when |T_e| is an exact multiple of B no
    padding is produced; the same row may select the same expert more than once
    (different flattened indices are different entries); entries within an
    expert follow ascending flattened index i.

    Input/output specification:
      topk_ids  int64/int32 (or fp32 as cast by the evaluator, integer values
                unchanged), contiguous 2D [num_tokens, top_k]; num_tokens /
                top_k >= 1 and top_k <= num_experts; E and B are __init__
                hyperparameters and >= 1, non powers of two allowed
      returns   a single 1-D float32 tensor of length L1 + L2 + 1, packed in
                three segments:
                out[:L1] = the L1 integers of sorted_token_ids (sentinel N
                           included)
                out[L1:L1+L2] = the L2 integers of expert_ids (tail -1)
                out[L1+L2] = num_tokens_post_pad (scalar S)
                -- all of them are non-negative / minus-one integers; the
                global-domain constraint L1 = N + E*(B-1) <= 2^24 guarantees
                that sentinel N, every index, every expert id and S <= L1 are
                exactly representable in fp32
      __init__ hyperparameters: num_experts (int), block_size (int).

    Implementation constraints (violations are scored as failures):
      - Core computation (bucket counting, block-count prefix sums, scatter
        writes of the layout, block expert table generation) must be done in a
        HIP kernel inside the submitted file; forward may only do input/
        output arrangement (dtype restoration, three-segment cat packing).
        Calling torch.sort / torch.argsort / torch.bincount / torch.cumsum /
        torch.histc / torch.unique / torch.repeat_interleave, or any
        third-party MoE/scheduling operator library, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Integer arithmetic throughout (no floating-point accumulation); the
        output is packed into float32 integers per the protocol above.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: the pure scheduling prologue (sorting / alignment / block table
    generation); no grouped GEMM body and no routing scores (softmax/topk are
    already done upstream).
    """
    def __init__(self, num_experts: int, block_size: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = int(num_experts)
        self.block_size = int(block_size)
        # <<<END_IMPROVE>>>

    def forward(self, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().moe_align(
            topk_ids, self.num_experts, self.block_size
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        # <<<END_IMPROVE>>>
