import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p2011_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor batchnorm_bwd(
    torch::Tensor dy,
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor saved_mean,
    torch::Tensor saved_inv_variance,
    bool want_dx);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("batchnorm_bwd", &batchnorm_bwd);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <cstdint>
#include <limits>

__global__ void partial_bn_stats(
    const float* __restrict__ dy,
    const float* __restrict__ x,
    const float* __restrict__ mean,
    const float* __restrict__ inv_var,
    float* __restrict__ partial_dbeta,
    float* __restrict__ partial_dgamma,
    int64_t m,
    int64_t tiles,
    int64_t C,
    int64_t spatial) {
    __shared__ float s_dbeta[256];
    __shared__ float s_dgamma[256];

    const int tid = static_cast<int>(threadIdx.x);
    const int64_t c = static_cast<int64_t>(blockIdx.y);
    const int64_t tile = static_cast<int64_t>(blockIdx.x);
    const int64_t pos = tile * static_cast<int64_t>(blockDim.x) +
                        static_cast<int64_t>(tid);

    float v_dbeta = 0.0f;
    float v_dgamma = 0.0f;
    if (c < C && pos < m) {
        const int64_t idx = ((pos / spatial) * C + c) * spatial +
                            pos % spatial;
        const float xhat = (x[idx] - mean[c]) * inv_var[c];
        const float g = dy[idx];
        v_dbeta = g;
        v_dgamma = g * xhat;
    }

    s_dbeta[tid] = v_dbeta;
    s_dgamma[tid] = v_dgamma;
    __syncthreads();

    for (int stride = 128; stride > 0; stride >>= 1) {
        if (tid < stride) {
            s_dbeta[tid] += s_dbeta[tid + stride];
            s_dgamma[tid] += s_dgamma[tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0 && c < C && tile < tiles) {
        partial_dbeta[c * tiles + tile] = s_dbeta[0];
        partial_dgamma[c * tiles + tile] = s_dgamma[0];
    }
}

__global__ void finalize_bn_stats(
    const float* __restrict__ partial_dbeta,
    const float* __restrict__ partial_dgamma,
    float* __restrict__ dbeta,
    float* __restrict__ dgamma,
    float* __restrict__ packed,
    int64_t tiles,
    int64_t C,
    bool want_dx) {
    __shared__ float s_dbeta[256];
    __shared__ float s_dgamma[256];

    const int tid = static_cast<int>(threadIdx.x);
    const int64_t c = static_cast<int64_t>(blockIdx.x);

    float sum_dbeta = 0.0f;
    float sum_dgamma = 0.0f;
    if (c < C) {
        for (int64_t t = static_cast<int64_t>(tid); t < tiles; t += 256) {
            const int64_t off = c * tiles + t;
            sum_dbeta += partial_dbeta[off];
            sum_dgamma += partial_dgamma[off];
        }
    }

    s_dbeta[tid] = sum_dbeta;
    s_dgamma[tid] = sum_dgamma;
    __syncthreads();

    for (int stride = 128; stride > 0; stride >>= 1) {
        if (tid < stride) {
            s_dbeta[tid] += s_dbeta[tid + stride];
            s_dgamma[tid] += s_dgamma[tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0 && c < C) {
        dbeta[c] = s_dbeta[0];
        dgamma[c] = s_dgamma[0];
        if (!want_dx) {
            packed[c] = s_dgamma[0];
            packed[C + c] = s_dbeta[0];
        }
    }
}

__global__ void bn_dx(
    const float* __restrict__ dy,
    const float* __restrict__ x,
    const float* __restrict__ scale,
    const float* __restrict__ mean,
    const float* __restrict__ inv_var,
    const float* __restrict__ dbeta,
    const float* __restrict__ dgamma,
    float* __restrict__ out,
    int64_t numel,
    int64_t m,
    int64_t C,
    int64_t spatial) {
    const int64_t idx = static_cast<int64_t>(blockIdx.x) *
                            static_cast<int64_t>(blockDim.x) +
                        static_cast<int64_t>(threadIdx.x);
    if (idx >= numel) {
        return;
    }

    const int64_t channel = (idx / spatial) % C;
    const float xhat = (x[idx] - mean[channel]) * inv_var[channel];
    const float factor = (scale[channel] * inv_var[channel]) /
                         static_cast<float>(m);
    out[idx] = factor * (static_cast<float>(m) * dy[idx] -
                         dbeta[channel] - xhat * dgamma[channel]);
}

torch::Tensor batchnorm_bwd(
    torch::Tensor dy,
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor saved_mean,
    torch::Tensor saved_inv_variance,
    bool want_dx) {
    TORCH_CHECK(dy.is_cuda() && x.is_cuda() && scale.is_cuda() &&
                saved_mean.is_cuda() && saved_inv_variance.is_cuda(),
                "all inputs must be CUDA/HIP tensors");
    TORCH_CHECK(dy.device() == x.device() && scale.device() == x.device() &&
                saved_mean.device() == x.device() &&
                saved_inv_variance.device() == x.device(),
                "all inputs must be on the same device");
    const c10::cuda::CUDAGuard device_guard(x.device());
    TORCH_CHECK(dy.scalar_type() == torch::kFloat &&
                x.scalar_type() == torch::kFloat &&
                scale.scalar_type() == torch::kFloat &&
                saved_mean.scalar_type() == torch::kFloat &&
                saved_inv_variance.scalar_type() == torch::kFloat,
                "batchnorm_bwd expects float32 inputs");
    TORCH_CHECK(dy.is_contiguous() && x.is_contiguous() &&
                scale.is_contiguous() && saved_mean.is_contiguous() &&
                saved_inv_variance.is_contiguous(),
                "batchnorm_bwd expects contiguous inputs");
    TORCH_CHECK(dy.dim() == 4 && x.dim() == 4,
                "dy and x must be NCHW tensors");

    const int64_t N = x.size(0);
    const int64_t C = x.size(1);
    const int64_t H = x.size(2);
    const int64_t W = x.size(3);
    const int64_t spatial = H * W;
    const int64_t m = N * H * W;
    const int64_t numel = N * C * H * W;

    TORCH_CHECK(N > 0 && C > 0 && H > 0 && W > 0,
                "input dimensions must be positive");
    TORCH_CHECK(dy.numel() == numel && scale.numel() == C &&
                saved_mean.numel() == C &&
                saved_inv_variance.numel() == C,
                "incompatible tensor sizes");

    const int64_t threads = 256;
    const int64_t tiles = (m + threads - 1) / threads;
    TORCH_CHECK(tiles <= static_cast<int64_t>(std::numeric_limits<unsigned int>::max()),
                "too many reduction tiles");
    TORCH_CHECK(C <= static_cast<int64_t>(std::numeric_limits<unsigned int>::max()),
                "too many channels");

    auto float_options = dy.options().dtype(torch::kFloat);
    auto partial_dbeta = torch::empty({C, tiles}, float_options);
    auto partial_dgamma = torch::empty({C, tiles}, float_options);
    auto dbeta = torch::empty({C}, float_options);
    auto dgamma = torch::empty({C}, float_options);

    torch::Tensor out;
    if (want_dx) {
        out = torch::empty({N, C, H, W}, float_options);
    } else {
        out = torch::empty({2 * C}, float_options);
    }

    hipStream_t stream = at::cuda::getCurrentCUDAStream();

    hipLaunchKernelGGL(
        partial_bn_stats,
        dim3(static_cast<unsigned int>(tiles),
             static_cast<unsigned int>(C), 1),
        dim3(256, 1, 1), 0, stream,
        dy.data_ptr<float>(),
        x.data_ptr<float>(),
        saved_mean.data_ptr<float>(),
        saved_inv_variance.data_ptr<float>(),
        partial_dbeta.data_ptr<float>(),
        partial_dgamma.data_ptr<float>(),
        m, tiles, C, spatial);
    hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess,
                "partial_bn_stats launch failed: ",
                hipGetErrorString(error));

    hipLaunchKernelGGL(
        finalize_bn_stats,
        dim3(static_cast<unsigned int>(C), 1, 1),
        dim3(256, 1, 1), 0, stream,
        partial_dbeta.data_ptr<float>(),
        partial_dgamma.data_ptr<float>(),
        dbeta.data_ptr<float>(),
        dgamma.data_ptr<float>(),
        out.data_ptr<float>(),
        tiles, C, want_dx);
    error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess,
                "finalize_bn_stats launch failed: ",
                hipGetErrorString(error));

    if (want_dx) {
        const int64_t blocks = (numel + threads - 1) / threads;
        TORCH_CHECK(blocks <= static_cast<int64_t>(std::numeric_limits<unsigned int>::max()),
                    "too many output blocks");
        hipLaunchKernelGGL(
            bn_dx,
            dim3(static_cast<unsigned int>(blocks), 1, 1),
            dim3(256, 1, 1), 0, stream,
            dy.data_ptr<float>(),
            x.data_ptr<float>(),
            scale.data_ptr<float>(),
            saved_mean.data_ptr<float>(),
            saved_inv_variance.data_ptr<float>(),
            dbeta.data_ptr<float>(),
            dgamma.data_ptr<float>(),
            out.data_ptr<float>(),
            numel, m, C, spatial);
        error = hipGetLastError();
        TORCH_CHECK(error == hipSuccess,
                    "bn_dx launch failed: ",
                    hipGetErrorString(error));
    }

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    BatchNorm training backward: given the upstream gradient dy, the input x of
    the training forward, the saved statistics (saved_mean / saved_inv_variance) and
    the scale parameter, compute the gradients of the normalized forward
        y = scale * xhat + bias,  xhat = (x - saved_mean) * saved_inv_variance
    The __init__ argument variant selects which gradients are returned:
        "dx"           : returns only the data gradient dx, shape (N, C, H, W), same
                         dtype as x;
        "dgamma_dbeta" : returns only the parameter gradients; dgamma and dbeta are
                         each (1, C, 1, 1) and are emitted as a single 1-D tensor
                         (2*C,) following the "one-dimensional concatenation packing
                         protocol": the first C elements are dgamma (flattened in
                         row-major order) and the last C are dbeta.
    Both variants share the same forward signature; the return value is always a
    single tensor (the evaluator compares a single output). Mathematical definition
    (float32 intermediate computation throughout, m = N*H*W elements per channel):
        xhat         = (x - saved_mean) * saved_inv_variance
        dgamma[c]    = sum_{n,h,w} dy * xhat          (summed per channel)
        dbeta[c]     = sum_{n,h,w} dy                 (summed per channel)
        dx           = (scale * saved_inv_variance / m)
                       * (m*dy - dbeta - xhat * dgamma)
    saved_mean / saved_inv_variance are consumed verbatim as the given values: they
    are the statistics saved by the training forward (inv_variance = 1/sqrt(biased
    variance + eps); eps was already absorbed in the forward, and the backward math
    itself contains no eps) and may be any positive numbers unrelated to the true
    statistics of x -- the given values must be used directly, and recomputing the
    statistics from x is forbidden. saved_inv_variance is always positive.

    Input/output specification (NCHW, contiguous):
        dy                 float32 / float16 / bfloat16 (N, C, H, W)
        x                  same dtype as dy (N, C, H, W)
        scale              same dtype as dy (1, C, 1, 1)
        saved_mean         float32 (1, C, 1, 1) (the statistics are always float32,
                           independent of the input dtype)
        saved_inv_variance float32 (1, C, 1, 1), its elements are always positive
        out                single tensor: (N, C, H, W) with the same dtype as dy for
                           dx; (2*C,) with the same dtype as dy for dgamma_dbeta (the
                           first C are dgamma and the last C are dbeta, both computed
                           in float32 and then cast)
        The evaluator casts all inputs to fp32 before passing them in (fp16/bf16 ->
        fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (xhat reconstruction, the two channel reductions, and
          the element-wise chained multiply-add of dx) must be completed inside the
          submitted file with a HIP kernel; a channel reduction of any size (m =
          N*H*W may exceed the capacity of a single block) must be handled correctly
          with mask / tiling (block-wise) reductions, leaving out no element of the
          channel.
        - Computing the gradients through torch.autograd / autograd.grad /
          .backward() is forbidden, as is calling the batch_norm primitive family or
          any closed-source library primitive (MIOpen / hipDNN and the like).
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The reductions and the intermediate computation run in float32; the output
          is cast back to the input dtype; the packing order of dgamma_dbeta is fixed
          as the dgamma segment first and the dbeta segment last.

    Boundary behaviour: N, C, H and W may all be 1 (m may be 1, in which case
    dx = scale * inv_var * (dy - dy*xhat^2)); non-powers of two and unaligned
    dimensions are allowed; the statistics shape is always (1, C, 1, 1); the input
    value range is the usual randn magnitude (no inf/NaN).
    Forbidden: aiter / torch.batch_norm / torch.native_batch_norm /
    torch.nn.functional.batch_norm / F.batch_norm / torch.nn.BatchNorm1d /
    torch.nn.BatchNorm2d / torch.nn.BatchNorm3d /
    torch.ops.aten.batch_norm / torch.ops.aten.native_batch_norm /
    autograd / .backward(.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "dx"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dx", "dgamma_dbeta"), "variant must be one of dx / dgamma_dbeta"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, dy, x, scale, saved_mean, saved_inv_variance):
        # <<<IMPROVE:forward_stmt_1>>>
        ext = _pyramidkernel_get_extension()
        result = ext.batchnorm_bwd(
            dy.to(torch.float32),
            x.to(torch.float32),
            scale.to(torch.float32),
            saved_mean.to(torch.float32),
            saved_inv_variance.to(torch.float32),
            self.variant == "dx",
        )
        return result.to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        mean = saved_mean.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        inv_var = saved_inv_variance.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        xhat = (xf - mean) * inv_var
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dgamma_c = (dyf * xhat).sum(dim=(0, 2, 3))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        dbeta_c = dyf.sum(dim=(0, 2, 3))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if self.variant == "dgamma_dbeta":
            return torch.cat([dgamma_c.to(x.dtype).reshape(-1),
                              dbeta_c.to(x.dtype).reshape(-1)])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        m = x.shape[0] * x.shape[2] * x.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        scalef = scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        dx = (scalef * inv_var / m) * (m * dyf - dbeta_c.reshape_as(scalef)
                                       - xhat * dgamma_c.reshape_as(scalef))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return dx.to(x.dtype)
        # <<<END_IMPROVE>>>
