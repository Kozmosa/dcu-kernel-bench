import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1030_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

at::Tensor unified_attention(
    const at::Tensor& query,
    const at::Tensor& key_cache,
    const at::Tensor& value_cache,
    const at::Tensor& block_tables,
    const at::Tensor& seq_lens,
    const at::Tensor& cu_seqlens_q,
    const at::Tensor& sinks,
    float scale,
    int64_t sliding_window,
    float softcap,
    bool use_sinks);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("unified_attention", &unified_attention, "Unified paged attention");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <cmath>
#include <limits>
#include <type_traits>

// WAVE_WIDTH == 0 retains the original shared-memory reduction.
template <typename scalar_t, int WAVE_WIDTH = 0>
__global__ void unified_attention_kernel(
    const scalar_t* __restrict__ query,
    const scalar_t* __restrict__ key_cache,
    const scalar_t* __restrict__ value_cache,
    const int64_t* __restrict__ block_tables,
    const int32_t* __restrict__ seq_lens,
    const int32_t* __restrict__ cu_seqlens_q,
    const scalar_t* __restrict__ sinks,
    scalar_t* __restrict__ output,
    int64_t total_q, int64_t num_q_heads, int64_t head_size,
    int64_t num_seqs, int64_t num_blocks, int64_t block_size,
    int64_t num_kv_heads, int64_t max_blocks_per_seq,
    float scale, int64_t sliding_window, float softcap, bool use_sinks) {
    constexpr int THREADS = 128;
    const int64_t lane = threadIdx.x;
    const int64_t work = static_cast<int64_t>(blockIdx.x);
    if (work >= total_q * num_q_heads) return;
    const int64_t row = work / num_q_heads;
    const int64_t h = work % num_q_heads;
    const int64_t q_base = work * head_size;

    extern __shared__ float storage[];
    float* q = storage;
    float* acc = q + head_size;
    float* reduction = acc + head_size;
    __shared__ int64_t seq, first, last, kv_head;
    __shared__ float maximum, denominator, alpha, weight;

    for (int64_t d = lane; d < head_size; d += THREADS) {
        q[d] = static_cast<float>(query[q_base + d]) * scale;
        acc[d] = 0.0f;
    }
    if (lane == 0) {
        int64_t lo = 0, hi = num_seqs;
        while (lo < hi) {
            const int64_t mid = lo + (hi - lo) / 2;
            if (static_cast<int64_t>(cu_seqlens_q[mid + 1]) <= row)
                lo = mid + 1;
            else
                hi = mid;
        }
        seq = lo;
        first = 0;
        last = -1;
        if (seq < num_seqs) {
            const int64_t begin = cu_seqlens_q[seq];
            const int64_t end = cu_seqlens_q[seq + 1];
            const int64_t kv_len = seq_lens[seq];
            if (begin >= 0 && begin <= row && row < end &&
                end <= total_q && kv_len >= end - begin) {
                last = kv_len - (end - begin) + row - begin;
                if (sliding_window > 0 && last >= sliding_window)
                    first = last - sliding_window + 1;
            }
        }
        kv_head = h / (num_q_heads / num_kv_heads);
        maximum = -INFINITY;
        denominator = 0.0f;
        if (use_sinks) {
            float x = static_cast<float>(sinks[h]);
            if (softcap > 0.0f) x = softcap * tanhf(x / softcap);
            maximum = x;
            denominator = 1.0f;
        }
    }
    __syncthreads();

    for (int64_t j = first; j <= last; ++j) {
        const int64_t logical = j / block_size;
        if (logical >= max_blocks_per_seq) continue;
        const int64_t physical = block_tables[seq * max_blocks_per_seq + logical];
        if (physical < 0 || physical >= num_blocks) continue;
        const int64_t base =
            ((physical * block_size + j % block_size) * num_kv_heads + kv_head)
            * head_size;
        float dot = 0.0f;
        for (int64_t d = lane; d < head_size; d += THREADS)
            dot += q[d] * static_cast<float>(key_cache[base + d]);

        if constexpr (WAVE_WIDTH == 0) {
            reduction[lane] = dot;
            __syncthreads();
            for (int64_t stride = THREADS / 2; stride > 0; stride /= 2) {
                if (lane < stride) reduction[lane] += reduction[lane + stride];
                __syncthreads();
            }
            dot = reduction[0];
        } else {
            static_assert(WAVE_WIDTH == 32 || WAVE_WIDTH == 64,
                          "unsupported wave width");
            static_assert(THREADS % WAVE_WIDTH == 0,
                          "block must contain complete waves");
            for (int offset = WAVE_WIDTH / 2; offset > 0; offset /= 2)
                dot += __shfl_down(dot, offset, WAVE_WIDTH);
            if (lane % WAVE_WIDTH == 0)
                reduction[lane / WAVE_WIDTH] = dot;
            __syncthreads();
            if (lane < WAVE_WIDTH) {
                dot = lane < THREADS / WAVE_WIDTH ? reduction[lane] : 0.0f;
                for (int offset = WAVE_WIDTH / 2; offset > 0; offset /= 2)
                    dot += __shfl_down(dot, offset, WAVE_WIDTH);
            }
        }
        if (lane == 0) {
            float logit = dot;
            if (softcap > 0.0f) logit = softcap * tanhf(logit / softcap);
            const float next_max = fmaxf(maximum, logit);
            alpha = expf(maximum - next_max);
            weight = expf(logit - next_max);
            denominator = denominator * alpha + weight;
            maximum = next_max;
        }
        __syncthreads();
        for (int64_t d = lane; d < head_size; d += THREADS)
            acc[d] = alpha * acc[d] + weight * static_cast<float>(value_cache[base + d]);
        __syncthreads();
    }
    const float inverse = denominator > 0.0f ? 1.0f / denominator : 0.0f;
    for (int64_t d = lane; d < head_size; d += THREADS)
        output[q_base + d] = static_cast<scalar_t>(acc[d] * inverse);
}

at::Tensor unified_attention(
    const at::Tensor& query,
    const at::Tensor& key_cache,
    const at::Tensor& value_cache,
    const at::Tensor& block_tables,
    const at::Tensor& seq_lens,
    const at::Tensor& cu_seqlens_q,
    const at::Tensor& sinks,
    float scale,
    int64_t sliding_window,
    float softcap,
    bool use_sinks) {
    TORCH_CHECK(query.is_cuda(), "query must be on the accelerator");
    const c10::cuda::CUDAGuard guard(query.device());
    for (const auto& t : {query, key_cache, value_cache, block_tables,
                          seq_lens, cu_seqlens_q, sinks}) {
        TORCH_CHECK(t.device() == query.device(), "all tensors must share a device");
        TORCH_CHECK(t.is_contiguous(), "all tensors must be contiguous");
    }
    TORCH_CHECK(query.dim() == 3 && key_cache.dim() == 4 &&
                value_cache.dim() == 4 && block_tables.dim() == 2 &&
                seq_lens.dim() == 1 && cu_seqlens_q.dim() == 1 &&
                sinks.dim() == 1, "invalid tensor ranks");
    TORCH_CHECK(query.scalar_type() == key_cache.scalar_type() &&
                query.scalar_type() == value_cache.scalar_type() &&
                query.scalar_type() == sinks.scalar_type(),
                "query, caches, and sinks must have the same dtype");
    TORCH_CHECK(block_tables.scalar_type() == at::kLong,
                "block_tables must be int64");
    TORCH_CHECK(seq_lens.scalar_type() == at::kInt &&
                cu_seqlens_q.scalar_type() == at::kInt,
                "sequence metadata must be int32");

    const int64_t total_q = query.size(0);
    const int64_t num_q_heads = query.size(1);
    const int64_t head_size = query.size(2);
    const int64_t num_blocks = key_cache.size(0);
    const int64_t block_size = key_cache.size(1);
    const int64_t num_kv_heads = key_cache.size(2);
    const int64_t num_seqs = seq_lens.size(0);
    const int64_t max_blocks_per_seq = block_tables.size(1);
    TORCH_CHECK(value_cache.sizes() == key_cache.sizes(),
                "key/value cache shapes must match");
    TORCH_CHECK(head_size > 0 && key_cache.size(3) == head_size &&
                block_size > 0, "invalid cache dimensions");
    TORCH_CHECK(num_q_heads > 0 && num_kv_heads > 0 &&
                num_q_heads % num_kv_heads == 0,
                "query heads must be divisible by KV heads");
    TORCH_CHECK(block_tables.size(0) == num_seqs &&
                cu_seqlens_q.numel() == num_seqs + 1,
                "inconsistent sequence metadata shapes");
    TORCH_CHECK(!use_sinks || sinks.numel() >= num_q_heads,
                "sinks must contain one value per query head");

    auto output = at::empty_like(query);
    if (total_q == 0) return output;
    TORCH_CHECK(num_seqs > 0, "nonempty queries require sequences");

    hipDeviceProp_t properties;
    hipError_t err = hipGetDeviceProperties(&properties, query.get_device());
    TORCH_CHECK(err == hipSuccess, "device query failed: ", hipGetErrorString(err));
    const int64_t work = query.numel() / head_size;
    TORCH_CHECK(work <= static_cast<int64_t>(properties.maxGridSize[0]),
                "attention grid exceeds device limit");
    TORCH_CHECK(properties.maxThreadsPerBlock >= 128,
                "device cannot support attention block size");
    const int wave_width = properties.warpSize;
    const bool wave_supported =
        (wave_width == 32 || wave_width == 64) && 128 % wave_width == 0;
    const int64_t reduction_slots = wave_supported ? 128 / wave_width : 128;
    hipStream_t stream = at::cuda::getCurrentCUDAStream(query.get_device()).stream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        query.scalar_type(), "unified_attention", [&] {
            auto launch = [&](auto width_tag) {
                constexpr int WIDTH = decltype(width_tag)::value;
                hipFuncAttributes attributes;
                hipError_t attr_err = hipFuncGetAttributes(
                    &attributes,
                    reinterpret_cast<const void*>(unified_attention_kernel<scalar_t, WIDTH>));
                TORCH_CHECK(attr_err == hipSuccess, "kernel query failed: ",
                            hipGetErrorString(attr_err));
                const int64_t available_bytes =
                    static_cast<int64_t>(properties.sharedMemPerBlock) -
                    static_cast<int64_t>(attributes.sharedSizeBytes);
                TORCH_CHECK(
                    available_bytes >= reduction_slots * static_cast<int64_t>(sizeof(float)) &&
                    head_size <= (available_bytes / static_cast<int64_t>(sizeof(float)) -
                                  reduction_slots) / 2,
                    "head size exceeds shared memory capacity");
                const int64_t shared_bytes =
                    (2 * head_size + reduction_slots) * static_cast<int64_t>(sizeof(float));
                hipLaunchKernelGGL(
                    (unified_attention_kernel<scalar_t, WIDTH>),
                    dim3(static_cast<unsigned int>(work)), dim3(128),
                    static_cast<size_t>(shared_bytes), stream,
                    query.data_ptr<scalar_t>(),
                    key_cache.data_ptr<scalar_t>(),
                    value_cache.data_ptr<scalar_t>(),
                    block_tables.data_ptr<int64_t>(),
                    seq_lens.data_ptr<int32_t>(),
                    cu_seqlens_q.data_ptr<int32_t>(),
                    sinks.data_ptr<scalar_t>(),
                    output.data_ptr<scalar_t>(),
                    total_q, num_q_heads, head_size, num_seqs,
                    num_blocks, block_size, num_kv_heads, max_blocks_per_seq,
                    scale, sliding_window, softcap, use_sinks);
            };
            if (wave_supported && wave_width == 32)
                launch(std::integral_constant<int, 32>{});
            else if (wave_supported && wave_width == 64)
                launch(std::integral_constant<int, 64>{});
            else
                launch(std::integral_constant<int, 0>{});
        });
    err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "unified attention launch failed: ",
                hipGetErrorString(err));
    err = hipStreamSynchronize(stream);
    TORCH_CHECK(err == hipSuccess, "unified attention execution failed: ",
                hipGetErrorString(err));
    return output;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Unified variable-length attention: paged attention with prefill and decode sequences mixed.

    The num_seqs sequences in the batch share one packed query tensor: the
    queries of sequence s are stored contiguously in the row range
    [cu_seqlens_q[s], cu_seqlens_q[s+1]), q_s = cu_seqlens_q[s+1] -
    cu_seqlens_q[s] rows in total (q_s == 1 is a decode sequence, q_s > 1 is a
    prefill sequence, and the two may be mixed arbitrarily within the batch); the
    KV length of that sequence is kv_s = seq_lens[s], and kv_s >= q_s is
    guaranteed. The KV is not stored contiguously but addressed page-wise: the
    physical address of logical token position j (0 <= j < kv_s) is
      key_cache[block_tables[s, j // block_size], j % block_size, g, :]
      value_cache[block_tables[s, j // block_size], j % block_size, g, :]
    where g is the KV head index. Slots in the physical block pool that are not
    referenced are garbage data and must not participate in the computation; only
    the first ceil(kv_s / block_size) entries of each row of block_tables are
    valid.

    For the i-th query of sequence s (0 <= i < q_s, with in-KV-sequence absolute
    position T = kv_s - q_s + i and row index r = cu_seqlens_q[s] + i) and query
    head h (the corresponding KV head is g = h // query_group_size,
    query_group_size = num_q_heads // num_kv_heads):
      logits[j] = scale * <query[r, h, :], K_phys(j, g, :)>
                  scale defaults to 1 / sqrt(head_size)
      visibility (causal, query right-aligned against the KV): j <= T; if
      sliding_window > 0, additionally T - j < sliding_window (the left window edge)
      if use_sinks=True: one extra virtual sink column is introduced whose logit
      is always sinks[h] and whose value is always the zero vector, and which is
      never masked
      if softcap > 0: all logits (including the sink column) first go through
      c * tanh(logit / c) (c = softcap), and only then the mask and the softmax
      p = softmax(visible logits)
      out[r, h, :] = sum_j p[j] * V_phys(j, g, :)   (the sink column contributes the zero vector)
    The causal right alignment guarantees that every query sees at least its own
    position, so the softmax denominator is always > 0.

    Input/output specification (evaluation dtype is float16 / bfloat16, all
    tensors contiguous):
      query         eval dtype (total_q, num_q_heads, head_size)
                    total_q = cu_seqlens_q[-1]
      key_cache     eval dtype (num_blocks, block_size, num_kv_heads, head_size)
      value_cache   eval dtype, same shape as key_cache
      block_tables  int32 (num_seqs, max_blocks_per_seq) logical block -> physical block id
      seq_lens      int32 (num_seqs) valid KV length kv_s of each sequence (>= q_s)
      cu_seqlens_q  int32 (num_seqs + 1) prefix sum of the query lengths, first element 0
      sinks         eval dtype (num_q_heads) per-head sink logit
                    (ignored when use_sinks=False)
      returns out   eval dtype (total_q, num_q_heads, head_size), aligned with the query rows

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        flex_attention / aiter / torch.matmul / torch.bmm / torch.einsum /
        torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to the
        input dtype.
      - The evaluator casts every input tensor to fp32 before calling forward;
        block table ids, sequence lengths and the position prefix sums are small
        integers that fp32 represents exactly, so .to(torch.int32) /
        .to(torch.long) at the entry recovers them losslessly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: paged KV + prefill/decode mixed ragged batch + GQA + causal right
    alignment + sliding window + logit softcap + attention sinks; no ALiBi, no
    query-query bias, no multimodal bidirectional prefix, no fp8 quantized KV with
    dequantization scales -- those variants are left as separate follow-up tasks.
    """
    def __init__(self, head_size: int, sliding_window: int = 0, softcap: float = 0.0, use_sinks: bool = True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = 1.0 / math.sqrt(head_size)
        self.sliding_window = int(sliding_window)
        self.softcap = float(softcap)
        self.use_sinks = bool(use_sinks)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens, cu_seqlens_q, sinks):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        cu_seqlens_q = cu_seqlens_q.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_seqs = seq_lens.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        block_size = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_kv_heads = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        head_size = key_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        num_q_heads = query.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        group = num_q_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert num_q_heads == num_kv_heads * group, \
            "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        outputs = []
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        output = _pyramidkernel_get_extension().unified_attention(
            query,
            key_cache,
            value_cache,
            block_tables,
            seq_lens,
            cu_seqlens_q,
            sinks,
            float(self.scale),
            int(self.sliding_window),
            float(self.softcap),
            bool(self.use_sinks)
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return output.to(query.dtype)
        # <<<END_IMPROVE>>>
