import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

def _bilinear_zero_pad(x, y_coord, x_coord):
    """Bilinear sampling (an integer coordinate is the pixel centre);
    contributions outside the boundary are 0.

    x: (n, c, h, w); y_coord / x_coord: (n, oh, ow) floating-point sampling
    coordinates (in the H/W coordinate system).
    Returns (n, c, oh, ow). Differentiable with respect to y_coord / x_coord:
    the coordinate gradient flows back only through the interpolation fractions
    (the frac terms) while the floor/index path is treated as a constant -- i.e.
    the subgradient of the standard zero-padding bilinear Theano/DCNv2
    convention.
    """
    n, c, h, w = x.shape
    oh, ow = y_coord.shape[1], y_coord.shape[2]
    y0 = torch.floor(y_coord)
    x0 = torch.floor(x_coord)
    y1 = y0 + 1
    x1 = x0 + 1
    ty = (y_coord - y0).unsqueeze(1)   # (n, 1, oh, ow)
    tx = (x_coord - x0).unsqueeze(1)

    def gather(yc, xc):
        valid = ((yc >= 0) & (yc <= h - 1) & (xc >= 0) & (xc <= w - 1)).unsqueeze(1)
        yi = yc.clamp(0, h - 1).long()
        xi = xc.clamp(0, w - 1).long()
        # The index tensors carry a batch dimension, so plain advanced indexing
        # would move the index dimensions to the front and produce 5-D;
        # flattening plus gather keeps (n, c, oh, ow) and stays differentiable
        # with respect to x
        idx = (yi * w + xi).reshape(n, 1, oh * ow).expand(n, c, oh * ow)
        got = x.reshape(n, c, h * w).gather(2, idx).reshape(n, c, oh, ow)
        return got * valid.to(x.dtype)

    return ((1 - ty) * (1 - tx) * gather(y0, x0)
            + (1 - ty) * tx * gather(y0, x1)
            + ty * (1 - tx) * gather(y1, x0)
            + ty * tx * gather(y1, x1))

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5004_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

void launch_deform_backward(
    const at::Tensor&, const at::Tensor&, const at::Tensor&,
    const at::Tensor&, const at::Tensor&, at::Tensor&,
    int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, bool);

at::Tensor deform_backward(
    const at::Tensor& dy, const at::Tensor& weight, const at::Tensor& x,
    const at::Tensor& offset, const at::Tensor& mask,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw, bool want_dgrad) {
    TORCH_CHECK(dy.is_cuda() && weight.is_cuda() && x.is_cuda() &&
                offset.is_cuda() && mask.is_cuda());
    TORCH_CHECK(dy.scalar_type() == at::kFloat &&
                weight.scalar_type() == at::kFloat &&
                x.scalar_type() == at::kFloat &&
                offset.scalar_type() == at::kFloat &&
                mask.scalar_type() == at::kFloat);
    TORCH_CHECK(dy.is_contiguous() && weight.is_contiguous() &&
                x.is_contiguous() && offset.is_contiguous() &&
                mask.is_contiguous());
    TORCH_CHECK(dy.device() == x.device() && weight.device() == x.device() &&
                offset.device() == x.device() && mask.device() == x.device());
    TORCH_CHECK(x.dim() == 4 && weight.dim() == 4 && dy.dim() == 4 &&
                offset.dim() == 4 && mask.dim() == 4);
    TORCH_CHECK(sh > 0 && sw > 0 && dh > 0 && dw > 0 && ph >= 0 && pw >= 0);

    const int64_t n = x.size(0);
    const int64_t c = x.size(1);
    const int64_t h = x.size(2);
    const int64_t w = x.size(3);
    const int64_t k = weight.size(0);
    const int64_t r = weight.size(2);
    const int64_t s = weight.size(3);
    const int64_t oh = (h + 2 * ph - dh * (r - 1) - 1) / sh + 1;
    const int64_t ow = (w + 2 * pw - dw * (s - 1) - 1) / sw + 1;

    TORCH_CHECK(oh > 0 && ow > 0);
    TORCH_CHECK(weight.size(1) == c);
    TORCH_CHECK(dy.size(0) == n && dy.size(1) == k &&
                dy.size(2) == oh && dy.size(3) == ow);
    TORCH_CHECK(offset.size(0) == n && offset.size(1) == 2 * r * s &&
                offset.size(2) == oh && offset.size(3) == ow);
    TORCH_CHECK(mask.size(0) == n && mask.size(1) == r * s &&
                mask.size(2) == oh && mask.size(3) == ow);

    at::Tensor out;
    if (want_dgrad) {
        const int64_t dxn = n * c * h * w;
        const int64_t don = n * 2 * r * s * oh * ow;
        const int64_t dmn = n * r * s * oh * ow;
        out = at::zeros({dxn + don + dmn}, x.options());
    } else {
        out = at::zeros({k, c, r, s}, x.options());
    }

    launch_deform_backward(
        dy, weight, x, offset, mask, out,
        sh, sw, ph, pw, dh, dw, want_dgrad);
    return out;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_backward", &deform_backward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <cmath>
#include <algorithm>

#define HIP_CHECK(x) do { \
    hipError_t e__ = (x); \
    TORCH_CHECK(e__ == hipSuccess, hipGetErrorString(e__)); \
} while (0)

__device__ __forceinline__ float load4(
    const float* p, int64_t b, int64_t c, int64_t y, int64_t x,
    int64_t C, int64_t H, int64_t W) {
    if (c < 0 || c >= C || y < 0 || y >= H || x < 0 || x >= W)
        return 0.0f;
    const int64_t q = ((b * C + c) * H + y) * W + x;
    return p[q];
}

__device__ __forceinline__ float sample(
    const float* p, int64_t b, int64_t c, float y, float x,
    int64_t C, int64_t H, int64_t W) {
    const int64_t y0 = (int64_t)floorf(y);
    const int64_t x0 = (int64_t)floorf(x);
    const float fy = y - (float)y0;
    const float fx = x - (float)x0;
    const float a = load4(p, b, c, y0, x0, C, H, W);
    const float bb = load4(p, b, c, y0, x0 + 1, C, H, W);
    const float cc = load4(p, b, c, y0 + 1, x0, C, H, W);
    const float d = load4(p, b, c, y0 + 1, x0 + 1, C, H, W);
    return (1.0f - fy) * (1.0f - fx) * a +
           (1.0f - fy) * fx * bb +
           fy * (1.0f - fx) * cc + fy * fx * d;
}

__device__ __forceinline__ void scatter_neighbor(
    float* out, int64_t base, int64_t y, int64_t x,
    int64_t H, int64_t W, float g, float coeff) {
    if (y >= 0 && y < H && x >= 0 && x < W && coeff != 0.0f)
        atomicAdd(out + base + y * W + x, g * coeff);
}

__global__ void fused_dgrad_kernel(
    const float* dy, const float* wt, const float* x, const float* off,
    const float* msk, float* out, int64_t N, int64_t C, int64_t H, int64_t W,
    int64_t K, int64_t R, int64_t S, int64_t OH, int64_t OW,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw) {
    const int64_t spatial = OH * OW;
    const int64_t points = R * S;
    const int64_t total = N * points * spatial;
    const int64_t dxn = N * C * H * W;
    const int64_t don = N * 2 * points * spatial;
    const int64_t step = (int64_t)blockDim.x * (int64_t)gridDim.x;
    for (int64_t q = (int64_t)blockIdx.x * (int64_t)blockDim.x +
                     (int64_t)threadIdx.x;
         q < total; q += step) {
        int64_t z = q;
        const int64_t j = z % OW; z /= OW;
        const int64_t i = z % OH; z /= OH;
        const int64_t m = z % points;
        const int64_t b = z / points;
        const int64_t pm = m / S;
        const int64_t pn = m % S;
        const int64_t oi = (b * 2 * points + 2 * m) * spatial + i * OW + j;
        const float yy = (float)(i * sh - ph + dh * pm) + off[oi];
        const float xx = (float)(j * sw - pw + dw * pn) + off[oi + spatial];
        const float mm = msk[q];

        // Below -1 or at/above the far edge both the value and the
        // coordinate derivatives are zero. At -1 the right derivative
        // can be nonzero, so that coordinate must take the normal path.
        if (yy < -1.0f || yy >= (float)H ||
            xx < -1.0f || xx >= (float)W) {
            out[dxn + oi] = 0.0f;
            out[dxn + oi + spatial] = 0.0f;
            out[dxn + don + q] = 0.0f;
            continue;
        }

        const int64_t y0 = (int64_t)floorf(yy);
        const int64_t x0 = (int64_t)floorf(xx);
        const float fy = yy - (float)y0;
        const float fx = xx - (float)x0;
        const float c00 = (1.0f - fy) * (1.0f - fx);
        const float c01 = (1.0f - fy) * fx;
        const float c10 = fy * (1.0f - fx);
        const float c11 = fy * fx;
        float dm = 0.0f;
        float dyc = 0.0f;
        float dxc = 0.0f;

        for (int64_t ci = 0; ci < C; ++ci) {
            float g = 0.0f;
            for (int64_t ko = 0; ko < K; ++ko) {
                const int64_t di = (b * K + ko) * spatial + i * OW + j;
                const int64_t wi = (ko * C + ci) * points + m;
                g += dy[di] * wt[wi];
            }

            const float a = load4(x, b, ci, y0, x0, C, H, W);
            const float bb = load4(x, b, ci, y0, x0 + 1, C, H, W);
            const float cc = load4(x, b, ci, y0 + 1, x0, C, H, W);
            const float d = load4(x, b, ci, y0 + 1, x0 + 1, C, H, W);
            const float v = c00 * a + c01 * bb + c10 * cc + c11 * d;
            const float vlo = (1.0f - fx) * a + fx * bb;
            const float vhi = (1.0f - fx) * cc + fx * d;
            const float vl = (1.0f - fy) * a + fy * cc;
            const float vr = (1.0f - fy) * bb + fy * d;
            dm += g * v;
            dyc += g * (vhi - vlo);
            dxc += g * (vr - vl);

            const int64_t base = (b * C + ci) * H * W;
            const float gm = g * mm;
            scatter_neighbor(out, base, y0, x0, H, W, gm, c00);
            scatter_neighbor(out, base, y0, x0 + 1, H, W, gm, c01);
            scatter_neighbor(out, base, y0 + 1, x0, H, W, gm, c10);
            scatter_neighbor(out, base, y0 + 1, x0 + 1, H, W, gm, c11);
        }
        out[dxn + oi] = mm * dyc;
        out[dxn + oi + spatial] = mm * dxc;
        out[dxn + don + q] = dm;
    }
}

__global__ void wrw_kernel(
    const float* dy, const float* x, const float* off, const float* msk,
    float* out, int64_t N, int64_t C, int64_t H, int64_t W, int64_t K,
    int64_t R, int64_t S, int64_t OH, int64_t OW,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw) {
    const int64_t q = (int64_t)blockIdx.x * (int64_t)blockDim.x + threadIdx.x;
    const int64_t total = K * C * R * S;
    if (q >= total) return;

    int64_t z = q;
    const int64_t pn = z % S; z /= S;
    const int64_t pm = z % R; z /= R;
    const int64_t ci = z % C; z /= C;
    const int64_t ko = z;
    const int64_t m = pm * S + pn;
    float acc = 0.0f;

    for (int64_t b = 0; b < N; ++b) {
        for (int64_t i = 0; i < OH; ++i) {
            for (int64_t j = 0; j < OW; ++j) {
                const int64_t oi =
                    ((b * (2 * R * S) + 2 * m) * OH + i) * OW + j;
                const float yy = (float)(i * sh - ph + dh * pm) + off[oi];
                const float xx = (float)(j * sw - pw + dw * pn) +
                                 off[oi + OH * OW];
                const int64_t mi = ((b * R * S + m) * OH + i) * OW + j;
                const int64_t di = ((b * K + ko) * OH + i) * OW + j;
                acc += dy[di] * msk[mi] * sample(x, b, ci, yy, xx, C, H, W);
            }
        }
    }
    out[q] = acc;
}

void launch_deform_backward(
    const at::Tensor& dy, const at::Tensor& weight, const at::Tensor& x,
    const at::Tensor& offset, const at::Tensor& mask, at::Tensor& out,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw, bool want_dgrad) {
    const c10::cuda::CUDAGuard device_guard(x.device());
    const hipStream_t stream = at::cuda::getCurrentCUDAStream(x.get_device());
    const int64_t N = x.size(0);
    const int64_t C = x.size(1);
    const int64_t H = x.size(2);
    const int64_t W = x.size(3);
    const int64_t K = weight.size(0);
    const int64_t R = weight.size(2);
    const int64_t S = weight.size(3);
    const int64_t OH = dy.size(2);
    const int64_t OW = dy.size(3);
    const int64_t threads = 128;

    if (want_dgrad) {
        const int64_t pn = N * OH * OW * R * S;
        const int64_t blocks = std::min<int64_t>((pn + threads - 1) / threads, 65535);
        fused_dgrad_kernel<<<blocks, threads, 0, stream>>>(
            dy.data_ptr<float>(), weight.data_ptr<float>(), x.data_ptr<float>(),
            offset.data_ptr<float>(), mask.data_ptr<float>(), out.data_ptr<float>(),
            N, C, H, W, K, R, S, OH, OW, sh, sw, ph, pw, dh, dw);
        HIP_CHECK(hipGetLastError());
    } else {
        const int64_t total = K * C * R * S;
        wrw_kernel<<<(total + threads - 1) / threads, threads, 0, stream>>>(
            dy.data_ptr<float>(), x.data_ptr<float>(), offset.data_ptr<float>(),
            mask.data_ptr<float>(), out.data_ptr<float>(),
            N, C, H, W, K, R, S, OH, OW, sh, sw, ph, pw, dh, dw);
        HIP_CHECK(hipGetLastError());
    }
    HIP_CHECK(hipDeviceSynchronize());
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Deformable 2D convolution backward (DCNv2, with mask modulation):
    gradient with respect to the input (dgrad) and gradient with respect to the
    weights (wrw).

    Semantics (NCHW, offset group = 1, no bias, strictly consistent with the
    standard DCNv2 forward):
        forward y = deform_conv2d(x, offset, weight, mask, stride=(sh,sw),
                               padding=(ph,pw), dilation=(dh,dw))
        output size out_h = floor((H + 2*ph - dh*(R-1) - 1) / sh) + 1 (likewise
        for out_w)
        the m-th kernel sampling point in row-major order m = pm*S + pn
        (pm = m // S, pn = m % S), at output position (i, j):
            sampling coordinate  Y = i*sh - ph + dh*pm + offset[b, 2*m,   i, j]
                                 X = j*sw - pw + dw_*pn + offset[b, 2*m+1, i, j]
            sampled value  V[b, :, i, j, m] = bilinear(x, Y, X): an integer
                coordinate is the pixel centre, interpolated bilinearly; the part
                of a sampling point that falls outside [0,H-1]x[0,W-1]
                contributes 0.
            y[b, ko, i, j] = sum_m mask[b, m, i, j] *
                                 sum_ci weight[ko, ci, pm, pn] * V[b, ci, i, j, m]
        offset channels correspond one-to-one with the kernel sampling points in
        row-major order: channel 2*m is the H-direction offset and 2*m+1 the
        W-direction offset (the only widespread DCNv2 convention; offset
        group = 1 for this task).
    Given the upstream gradient dy = dL/dy (shape (N, out_c, out_h, out_w)):
        dgrad: dx = dL/dx (N,C,H,W), doffset = dL/doffset (N,2*R*S,out_h,out_w),
               dmask = dL/dmask (N,R*S,out_h,out_w)
        wrw:   dw = dL/dw (out_c,C,R,S)
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns the three gradients packed into a single 1-D tensor by
                 the segmentation protocol;
        "wrw":   returns dw; the values of weight do not take part in the
                 output here (shape convention only).
    forward(dy, weight, x, offset, mask) has a fixed five-input signature; the
    tensors mean:
        dy     (N, out_c, out_h, out_w)     upstream gradient, consumed by both
                                            directions
        weight (out_c, C, R, S)             convolution kernel (out_c output
                                            channels / C input channels)
        x      (N, C, H, W)                 forward input
        offset (N, 2*R*S, out_h, out_w)     sampling offsets
        mask   (N, R*S, out_h, out_w)       modulation mask
    forward returns the single tensor out (float32) -- dgrad is a 1-D
    concatenated packing (segmentation protocol):
        out = cat([dx.reshape(-1), doffset.reshape(-1), dmask.reshape(-1)])
        length = N*C*H*W + N*2*R*S*out_h*out_w + N*R*S*out_h*out_w, with the
        segment order fixed as dx | doffset | dmask, each segment being the
        C-order flattening of the corresponding 4-D tensor; the segment order
        must not be swapped;
        wrw -> (out_c, C, R, S), inherently single-output with no packing.

    Input/output specification:
        dy / weight / x / offset / mask are all float32, contiguous, NCHW
        layout; every dimension >= 1; R/S may be 1 (1x1 kernel); H/W may be 1,
        odd, non-power-of-two, not 16-aligned; stride/dilation >= 1, padding
        >= 0, padding follows the forward four-sided symmetric (ph, pw)
        semantics; consistency constraint
            H + 2*ph >= dh*(R-1) + 1, W + 2*pw >= dw_*(S-1) + 1,
        and the spatial sizes of dy/offset/mask must equal out_h/out_w from the
        forward formula, offset channels = 2*R*S, mask channels = R*S.
        Input values are ordinary randn magnitude (no inf/NaN). The evaluator
        casts all inputs to fp32 before the call.

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a HIP kernel inside the
          submitted file: the backward bilinear-sampling scatter of dgrad (the
          analytic partial derivatives with respect to Y/X chained back through
          the kernel weights and the mask into dx/doffset/dmask, with
          out-of-boundary contributions set to 0) or the sampled-value
          correlation accumulation of wrw (summing the cross-correlation of the
          x sampling windows with dy); falling back to torch autograd /
          convolution primitives / grid_sample for the core computation is
          forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares a single
          output); the three dgrad segments must be packed by the segmentation
          protocol above and the segment order must not be swapped.
        - Numeric contract: float32 inputs are accumulated directly in float32,
          with no downcast to half precision; the three dgrad gradient segments
          and the wrw output are all float32.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torchvision / torch.nn.functional.conv2d / F.conv2d /
    torch.conv2d / torch.nn.Conv2d / torch.nn.functional.conv_transpose2d /
    F.conv_transpose2d / torch.nn.ConvTranspose2d /
    torch.nn.grad.conv2d_input / torch.nn.grad.conv2d_weight /
    aten.convolution_backward / deform_conv2d / deform_conv2d_backward /
    grid_sample / F.grid_sample / torch.nn.functional.grid_sample /
    torch.autograd / .backward( / unfold / F.fold /
    torch.nn.functional.fold / im2col / col2im / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1, pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wrw"), "variant must be either dgrad or wrw"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)
        # <<<END_IMPROVE>>>

    def forward(self, dy, weight, x, offset, mask):
        # <<<IMPROVE:forward_stmt_1>>>
        result = _pyramidkernel_get_extension().deform_backward(
            dy, weight, x, offset, mask,
            self.stride_h, self.stride_w,
            self.pad_h, self.pad_w,
            self.dil_h, self.dil_w,
            self.variant == "dgrad",
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        if self.variant == "dgrad":
            return result
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        return result
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return result
        # <<<END_IMPROVE>>>

    def _deform_conv2d_forward(self, x, offset, weight, mask):
        """Handwritten DCNv2 forward (a composition of standard differentiable
        torch operators), used for the autograd backward pass."""
        n, c, h, w = x.shape
        k, _, r, s = weight.shape
        sh, sw = self.stride_h, self.stride_w
        ph, pw = self.pad_h, self.pad_w
        dh, dwl = self.dil_h, self.dil_w
        oh, ow = offset.shape[2], offset.shape[3]
        out = torch.zeros(n, k, oh, ow, dtype=x.dtype, device=x.device)
        for m in range(r * s):
            pm, pn = m // s, m % s
            base_y = torch.arange(oh, dtype=x.dtype, device=x.device) * sh - ph + dh * pm
            base_x = torch.arange(ow, dtype=x.dtype, device=x.device) * sw - pw + dwl * pn
            yo = base_y.view(1, oh, 1) + offset[:, 2 * m]      # (n, oh, ow)
            xo = base_x.view(1, 1, ow) + offset[:, 2 * m + 1]  # (n, oh, ow)
            val = _bilinear_zero_pad(x, yo, xo)                # (n, c, oh, ow)
            wc = weight[:, :, pm, pn]                          # (k, c)
            contrib = torch.einsum("oc,ncij->noij", wc, val)
            out = out + mask[:, m].unsqueeze(1) * contrib
        return out
