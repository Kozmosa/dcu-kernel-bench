import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p6001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor adamw_update(torch::Tensor, torch::Tensor, torch::Tensor,
                          torch::Tensor, torch::Tensor,
                          double, double, double, double, double, bool);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("adamw_update", &adamw_update);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <algorithm>
#include <cstdint>
#include <cmath>

#pragma clang fp contract(off)

// Only out is disjoint: the wrapper allocates it with torch::empty_like.
// Read-only state inputs may alias one another.
template<bool Correct, typename P, typename G, typename M, typename V>
__global__ void adamw_kernel(
    const P* p, const G* g, const M* m, const V* v,
    P* __restrict__ out, const float* step, int64_t n,
    float lr, float b1, float b2, float om1, float om2,
    float eps, float decay) {
    __shared__ float bc[2];
    if (Correct) {
        if (threadIdx.x == 0) {
            float s = step[0];
            bc[0] = 1.0f - powf(b1, s);
            bc[1] = 1.0f - powf(b2, s);
        }
        __syncthreads();
    }
    int64_t stride = static_cast<int64_t>(blockDim.x) * gridDim.x;
    for (int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
         i < n; i += stride) {
        float grad = static_cast<float>(g[i]);
        float param = static_cast<float>(p[i]) * decay;
        float moment = b1 * static_cast<float>(m[i]) + om1 * grad;
        float variance = b2 * static_cast<float>(v[i]) + (om2 * grad) * grad;
        float update;
        if (Correct) {
            update = (moment / bc[0]) / (sqrtf(variance / bc[1]) + eps);
        } else {
            update = moment / (sqrtf(variance) + eps);
        }
        float result = param - lr * update;
        out[i] = static_cast<P>(result);
    }
}

#define DISPATCH_STORAGE(tensor, Type, ...) \
    if ((tensor).scalar_type() == at::kHalf) { \
        using Type = c10::Half; \
        __VA_ARGS__ \
    } else { \
        using Type = float; \
        __VA_ARGS__ \
    }

torch::Tensor adamw_update(
    torch::Tensor params, torch::Tensor grads, torch::Tensor exp_avg,
    torch::Tensor exp_avg_sq, torch::Tensor step,
    double lr, double beta1, double beta2, double eps, double weight_decay,
    bool correct) {
    TORCH_CHECK(params.is_cuda(), "params must be on GPU");
    c10::cuda::CUDAGuard guard(params.device());
    for (const auto& t : {params, grads, exp_avg, exp_avg_sq}) {
        TORCH_CHECK(t.device() == params.device(), "state device mismatch");
        TORCH_CHECK(t.sizes() == params.sizes(), "state shape mismatch");
        TORCH_CHECK(t.is_contiguous(), "state must be contiguous");
        TORCH_CHECK(t.scalar_type() == at::kFloat || t.scalar_type() == at::kHalf,
                    "state must be float32 or float16");
    }
    TORCH_CHECK(step.dim() == 0 && step.numel() == 1 &&
                step.scalar_type() == at::kFloat, "step must be scalar float32");
    TORCH_CHECK(step.device().is_cpu() || step.device() == params.device(),
                "step device mismatch");
    if (step.device().is_cpu()) step = step.to(params.device());
    auto out = torch::empty_like(params);
    int64_t n = params.numel();
    if (n == 0) return out;
    int device = params.get_device();
    hipDeviceProp_t prop;
    hipError_t status = hipGetDeviceProperties(&prop, device);
    TORCH_CHECK(status == hipSuccess, hipGetErrorString(status));
    int threads = std::min(256, prop.maxThreadsPerBlock);
    int64_t blocks64 = std::min<int64_t>((n - 1) / threads + 1,
                                        static_cast<int64_t>(prop.multiProcessorCount) * 8);
    blocks64 = std::min<int64_t>(blocks64, prop.maxGridSize[0]);
    unsigned blocks = static_cast<unsigned>(blocks64);
    auto stream = c10::cuda::getCurrentCUDAStream(device).stream();
    float decay = static_cast<float>(1.0 - lr * weight_decay);
    float om1 = static_cast<float>(1.0 - beta1);
    float om2 = static_cast<float>(1.0 - beta2);
    DISPATCH_STORAGE(params, P,
        DISPATCH_STORAGE(grads, G,
            DISPATCH_STORAGE(exp_avg, M,
                DISPATCH_STORAGE(exp_avg_sq, V,
                    if (correct) {
                        adamw_kernel<true, P, G, M, V><<<blocks, threads, 0, stream>>>(
                            params.data_ptr<P>(), grads.data_ptr<G>(),
                            exp_avg.data_ptr<M>(), exp_avg_sq.data_ptr<V>(),
                            out.data_ptr<P>(), step.data_ptr<float>(), n,
                            float(lr), float(beta1), float(beta2), om1, om2,
                            float(eps), decay);
                    } else {
                        adamw_kernel<false, P, G, M, V><<<blocks, threads, 0, stream>>>(
                            params.data_ptr<P>(), grads.data_ptr<G>(),
                            exp_avg.data_ptr<M>(), exp_avg_sq.data_ptr<V>(),
                            out.data_ptr<P>(), step.data_ptr<float>(), n,
                            float(lr), float(beta1), float(beta2), om1, om2,
                            float(eps), decay);
                    }
                )
            )
        )
    )
    status = hipGetLastError();
    TORCH_CHECK(status == hipSuccess, hipGetErrorString(status));
    return out;
}
#undef DISPATCH_STORAGE
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Fused AdamW optimizer family: a single functional (out-of-place) parameter
    update for standard AdamW and for Transformer-schedule AdamW.

    (1) Operator semantics: the __init__ hyper-parameters lr, beta1, beta2, eps,
    weight_decay are construction constants, and `variant` selects one of two
    update paths. Let `step` be a 0-dimensional float32 scalar tensor (the
    current iteration count). The four state tensors params / grads / exp_avg /
    exp_avg_sq have the same shape and are element-wise aligned; the whole update
    is computed in float32 (inputs are promoted to float32 first):
        1) decoupled weight decay (the AdamW form, applied in both variants --
           equivalent to p = params - lr * weight_decay * params, not L2
           regularization):
               p = params * (1 - lr * weight_decay)
        2) first moment: m = beta1 * exp_avg + (1 - beta1) * grads
        3) second moment: v = beta2 * exp_avg_sq + (1 - beta2) * grads^2
        4) variant="adamw" (standard AdamW, bias correction ON):
               bc1 = 1 - beta1^step; bc2 = 1 - beta2^step
               out = p - lr * (m / bc1) / (sqrt(v / bc2) + eps)
           variant="transformer_adamw" (Transformer schedule, bias correction
           OFF -- the only difference between the two variants):
               out = p - lr * m / (sqrt(v) + eps)
    The two variants are line-by-line identical apart from bias correction; eps is
    added outside the sqrt (denom = sqrt(...) + eps); the power beta^step is a
    float32 scalar power.
    Boundary behaviour: at step=1, bc1 = 1 - beta1 and bc2 = 1 - beta2 take their
    minimum values (the standard AdamW path amplifies the most); for very large
    step the two variants converge numerically; exp_avg_sq is always
    non-negative (second-moment constraint, generated in [0, 0.5)) and
    denom >= eps guarantees no division by zero; this operator has no reduction
    and no indexing -- it is a pure element-wise map.

    (2) Input/output specification:
      - params / grads / exp_avg / exp_avg_sq: float32 or float16 tensors, all
        with the same shape (ndim 1-4, numel >= 1, including non-power-of-two and
        boundary sizes), contiguous;
      - step: a 0-dimensional float32 scalar tensor (numel == 1) whose value is a
        positive-integer-semantics step count (>= 1);
      - returns: the updated parameters, a new tensor with the same shape and
        dtype as params (single-tensor output, out-of-place; no input may be
        modified in place, and no state such as exp_avg / exp_avg_sq may be
        returned).

    (3) Implementation constraints (violations are scored as failures):
      - The core computation (decoupled weight decay, first/second moment update,
        bias-correction power, sqrt, element-wise update) must be completed with a
        HIP kernel inside the submitted file;
      - out-of-place: params / grads / exp_avg / exp_avg_sq must not be modified
        in place;
      - the __init__ and forward signatures of ModelNew must not be changed;
      - intermediate computation uses float32 (fp16 inputs are promoted to
        float32 as well), and the final result is cast back to the dtype of
        params;
      - step arrives as a 0-dimensional tensor and participates in the power
        operation as a scalar inside the kernel; it must not be materialized into
        a temporary tensor of the same shape as params.

    (4) Forbidden list and target hardware:
      - the whole torch.optim family is forbidden (torch.optim.AdamW / Adam /
        SGD / ... plus their _functional / _multi_tensor internal paths);
      - any fused-optimizer library and closed-source entry point is forbidden:
        apex / deepspeed / bitsandbytes / the fused_adam entry-point family /
        hipdnn / miopen;
      - completing this task via an ATen shortcut is forbidden: torch.addcdiv /
        torch.addcmul (including the .addcdiv / .addcdiv_ / .addcmul / .addcmul_
        tensor methods and in-place forms, which finish the parameter update or
        the moment update in a single call); the multi-tensor primitives
        torch._foreach_addcdiv / torch._foreach_addcmul are equally forbidden
        (including their in-place _ forms, which complete the core update step in
        a single call) (the final static audit does substring matching on code
        outside docstrings/comments);
      Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "adamw", lr: float = 1e-3, beta1: float = 0.9, beta2: float = 0.999, eps: float = 1e-8, weight_decay: float = 0.01):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("adamw", "transformer_adamw"), \
            "variant must be one of adamw / transformer_adamw"
        self.variant = variant
        self.lr = float(lr)
        self.beta1 = float(beta1)
        self.beta2 = float(beta2)
        self.eps = float(eps)
        self.weight_decay = float(weight_decay)
        # <<<END_IMPROVE>>>

    def forward(self, params, grads, exp_avg, exp_avg_sq, step):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().adamw_update(
            params, grads, exp_avg, exp_avg_sq, step,
            self.lr, self.beta1, self.beta2, self.eps, self.weight_decay,
            self.variant == "adamw")
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        g = grads.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        m = exp_avg.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        v = exp_avg_sq.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        s = step.to(torch.float32) if torch.is_tensor(step) \
            else torch.tensor(float(step))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        p = p * (1.0 - self.lr * self.weight_decay)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        m = self.beta1 * m + (1.0 - self.beta1) * g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        v = self.beta2 * v + (1.0 - self.beta2) * g * g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if self.variant == "adamw":
            # standard AdamW: bias correction ON
            bc1 = 1.0 - torch.pow(self.beta1, s)
            bc2 = 1.0 - torch.pow(self.beta2, s)
            denom = torch.sqrt(v / bc2) + self.eps
            update = (m / bc1) / denom
        else:
            # transformer_adamw: bias correction OFF (the only difference)
            denom = torch.sqrt(v) + self.eps
            update = m / denom
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return (p - self.lr * update).to(params.dtype)
        # <<<END_IMPROVE>>>
