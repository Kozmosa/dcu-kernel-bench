import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p7001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <vector>
#include <cstdint>

std::vector<torch::Tensor> ctc_forward(
    torch::Tensor probs, torch::Tensor labels,
    torch::Tensor label_lengths, torch::Tensor input_lengths,
    int64_t blank);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("ctc_forward", &ctc_forward, "CTC forward loss and probability gradient");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <c10/util/Half.h>
#include <c10/util/BFloat16.h>
#include <vector>
#include <cstdint>
#include <cmath>
#include <limits>
#include <algorithm>

__device__ __forceinline__ float ctc_lse3(float a, float b, float c) {
    float m = fmaxf(a, fmaxf(b, c));
    if (m == -INFINITY) return -INFINITY;
    return m + logf(expf(a - m) + expf(b - m) + expf(c - m));
}

__device__ __forceinline__ int64_t ctc_symbol(
    const int64_t* labels, int64_t offset, int64_t s, int64_t blank) {
    return (s & 1) ? labels[offset + s / 2] : blank;
}

template <typename scalar_t>
__device__ __forceinline__ float ctc_emit(
    const scalar_t* p, int64_t base, int64_t k, int64_t C) {
    return (k >= 0 && k < C) ? logf(static_cast<float>(p[base + k])) : -INFINITY;
}

template <typename scalar_t>
__global__ void ctc_kernel(
    const scalar_t* __restrict__ probs,
    const int64_t* __restrict__ labels,
    const int64_t* __restrict__ label_lengths,
    const int64_t* __restrict__ input_lengths,
    float* __restrict__ losses,
    float* __restrict__ alpha_all,
    float* __restrict__ beta_all,
    int64_t* __restrict__ metadata,
    int64_t* __restrict__ class_heads,
    int64_t* __restrict__ state_next,
    int64_t state_count, int64_t T, int64_t N, int64_t C,
    int64_t max_states, int64_t total_labels, int64_t blank) {
    __shared__ int64_t off, S, tb;

    for (int64_t n = blockIdx.x; n < N; n += static_cast<int64_t>(gridDim.x)) {
        __syncthreads();

        if (threadIdx.x == 0) {
            bool valid = true;
            off = 0;
            for (int64_t i = 0; i < n; ++i) {
                int64_t l = label_lengths[i];
                if (l < 0 || l > total_labels - off) {
                    valid = false;
                    break;
                }
                off += l;
            }

            int64_t L = label_lengths[n];
            tb = input_lengths[n];
            valid = valid && L >= 0 && L <= total_labels - off &&
                    tb >= 1 && tb <= T &&
                    L <= (std::numeric_limits<int64_t>::max() - 1) / 2;
            S = valid ? 2 * L + 1 : 0;

            if (valid) {
                int64_t base = 2 * off + n;
                valid = base >= 0 && base <= state_count &&
                        S <= state_count - base && S <= max_states;
            }
            if (!valid) {
                S = 0;
                tb = 0;
                losses[n] = INFINITY;
            }
            metadata[n * 3] = off;
            metadata[n * 3 + 1] = S;
            metadata[n * 3 + 2] = tb;
        }
        __syncthreads();

        if (S == 0) continue;

        for (int64_t k = threadIdx.x; k < C; k += static_cast<int64_t>(blockDim.x))
            class_heads[n * C + k] = -1;
        __syncthreads();

        if (threadIdx.x == 0) {
            int64_t list_base = 2 * off + n;
            for (int64_t s = S - 1; s >= 0; --s) {
                int64_t k = ctc_symbol(labels, off, s, blank);
                if (k >= 0 && k < C) {
                    state_next[list_base + s] = class_heads[n * C + k];
                    class_heads[n * C + k] = s;
                } else {
                    state_next[list_base + s] = -1;
                }
            }
        }
        __syncthreads();

        float* alpha = alpha_all + n * T * max_states;
        float* beta = beta_all + n * T * max_states;

        for (int64_t s = threadIdx.x; s < S; s += static_cast<int64_t>(blockDim.x)) {
            int64_t k = ctc_symbol(labels, off, s, blank);
            alpha[s] = s < 2 ? ctc_emit(probs, n * C, k, C) : -INFINITY;
        }
        __syncthreads();

        for (int64_t t = 1; t < tb; ++t) {
            int64_t prev = (t - 1) * max_states;
            int64_t cur = t * max_states;
            int64_t pbase = (t * N + n) * C;

            for (int64_t s = threadIdx.x; s < S; s += static_cast<int64_t>(blockDim.x)) {
                int64_t k = ctc_symbol(labels, off, s, blank);
                float a0 = alpha[prev + s];
                float a1 = s > 0 ? alpha[prev + s - 1] : -INFINITY;
                float a2 = -INFINITY;
                if (s > 1 && k != blank &&
                    k != ctc_symbol(labels, off, s - 2, blank))
                    a2 = alpha[prev + s - 2];
                alpha[cur + s] = ctc_emit(probs, pbase, k, C) +
                                 ctc_lse3(a0, a1, a2);
            }
            __syncthreads();
        }

        int64_t last = (tb - 1) * max_states;
        for (int64_t s = threadIdx.x; s < S; s += static_cast<int64_t>(blockDim.x))
            beta[last + s] = s >= S - 2 ? 0.0f : -INFINITY;

        if (threadIdx.x == 0)
            losses[n] = -ctc_lse3(
                alpha[last + S - 1],
                S > 1 ? alpha[last + S - 2] : -INFINITY,
                -INFINITY);
        __syncthreads();

        for (int64_t t = tb - 2; t >= 0; --t) {
            int64_t next = (t + 1) * max_states;
            int64_t cur = t * max_states;
            int64_t pbase = ((t + 1) * N + n) * C;

            for (int64_t s = threadIdx.x; s < S; s += static_cast<int64_t>(blockDim.x)) {
                int64_t k = ctc_symbol(labels, off, s, blank);
                float b0 = ctc_emit(probs, pbase, k, C) + beta[next + s];
                float b1 = -INFINITY;
                float b2 = -INFINITY;

                if (s + 1 < S) {
                    int64_t k1 = ctc_symbol(labels, off, s + 1, blank);
                    b1 = ctc_emit(probs, pbase, k1, C) + beta[next + s + 1];
                }
                if (s + 2 < S) {
                    int64_t k2 = ctc_symbol(labels, off, s + 2, blank);
                    if (k != blank && k != k2)
                        b2 = ctc_emit(probs, pbase, k2, C) + beta[next + s + 2];
                }
                beta[cur + s] = ctc_lse3(b0, b1, b2);
            }
            __syncthreads();
        }
    }
}

template <typename scalar_t>
__global__ void ctc_gradient(
    const scalar_t* __restrict__ probs,
    const int64_t* __restrict__ labels,
    const int64_t* __restrict__ metadata,
    const float* __restrict__ losses,
    const float* __restrict__ alpha,
    const float* __restrict__ beta,
    float* __restrict__ grads,
    const int64_t* __restrict__ class_heads,
    const int64_t* __restrict__ state_next,
    int64_t state_count, int64_t T, int64_t N, int64_t C,
    int64_t max_states, int64_t count) {
    int64_t stride = static_cast<int64_t>(blockDim.x) * gridDim.x;

    for (int64_t q = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
         q < count; q += stride) {
        int64_t k = q % C;
        int64_t t = (q / C) % T;
        int64_t n = (q / C) / T;
        int64_t tb = metadata[n * 3 + 2];

        if (t >= tb) {
            grads[q] = 0.0f;
            continue;
        }

        int64_t off = metadata[n * 3];
        int64_t S = metadata[n * 3 + 1];
        int64_t list_base = 2 * off + n;
        int64_t abase = (n * T + t) * max_states;
        float log_z = -losses[n];
        float mass = 0.0f;

        int64_t s = class_heads[n * C + k];
        while (s >= 0 && s < S && s < max_states) {
            if (list_base < 0 || list_base >= state_count ||
                s >= state_count - list_base)
                break;

            float v = alpha[abase + s] + beta[abase + s] - log_z;
            if (v != -INFINITY) mass += expf(v);

            int64_t ns = state_next[list_base + s];
            if (ns <= s) break;
            s = ns;
        }

        int64_t pidx = (t * N + n) * C + k;
        float p = static_cast<float>(probs[pidx]);
        grads[q] = p != 0.0f ? -mass / p : 0.0f;
    }
}

static void ctc_check_launch() {
    hipError_t e = hipGetLastError();
    TORCH_CHECK(e == hipSuccess, "CTC HIP kernel launch failed: ",
                hipGetErrorString(e));
}

static int64_t ctc_mul(int64_t a, int64_t b) {
    TORCH_CHECK(a >= 0 && b >= 0 &&
                (b == 0 || a <= std::numeric_limits<int64_t>::max() / b),
                "CTC dimension product overflow");
    return a * b;
}

template <typename scalar_t>
static void ctc_launch(
    const torch::Tensor& probs, const torch::Tensor& labels,
    const torch::Tensor& label_lengths, const torch::Tensor& input_lengths,
    torch::Tensor& losses, torch::Tensor& grads, torch::Tensor& alpha,
    torch::Tensor& beta, torch::Tensor& metadata, torch::Tensor& class_heads,
    torch::Tensor& state_next, int64_t T, int64_t N, int64_t C,
    int64_t max_states, int64_t total_labels) {
    hipStream_t stream =
        at::cuda::getCurrentCUDAStream(probs.device().index()).stream();

    int blocks = static_cast<int>(std::min<int64_t>(N, 65535));
    hipLaunchKernelGGL(
        (ctc_kernel<scalar_t>), dim3(blocks), dim3(128), 0, stream,
        probs.data_ptr<scalar_t>(), labels.data_ptr<int64_t>(),
        label_lengths.data_ptr<int64_t>(), input_lengths.data_ptr<int64_t>(),
        losses.data_ptr<float>(), alpha.data_ptr<float>(),
        beta.data_ptr<float>(), metadata.data_ptr<int64_t>(),
        class_heads.data_ptr<int64_t>(), state_next.data_ptr<int64_t>(),
        state_next.numel(), T, N, C, max_states, total_labels, 0);
    ctc_check_launch();

    int64_t count = grads.numel();
    int gblocks = static_cast<int>(
        std::min<int64_t>((count + 255) / 256, 65535));
    hipLaunchKernelGGL(
        (ctc_gradient<scalar_t>), dim3(gblocks), dim3(256), 0, stream,
        probs.data_ptr<scalar_t>(), labels.data_ptr<int64_t>(),
        metadata.data_ptr<int64_t>(), losses.data_ptr<float>(),
        alpha.data_ptr<float>(), beta.data_ptr<float>(),
        grads.data_ptr<float>(), class_heads.data_ptr<int64_t>(),
        state_next.data_ptr<int64_t>(), state_next.numel(),
        T, N, C, max_states, count);
    ctc_check_launch();
}

std::vector<torch::Tensor> ctc_forward(
    torch::Tensor probs, torch::Tensor labels,
    torch::Tensor label_lengths, torch::Tensor input_lengths,
    int64_t blank) {
    TORCH_CHECK(probs.is_cuda() && probs.is_contiguous() && probs.dim() == 3,
                "probs must be contiguous HIP (T,N,C)");

    c10::cuda::CUDAGuard guard(probs.device());
    int64_t T = probs.size(0);
    int64_t N = probs.size(1);
    int64_t C = probs.size(2);

    TORCH_CHECK(T > 0 && C > 0 && blank >= 0 && blank < C,
                "invalid shape or blank");

    TORCH_CHECK(labels.device() == probs.device() &&
                label_lengths.device() == probs.device() &&
                input_lengths.device() == probs.device() &&
                labels.is_contiguous() && label_lengths.is_contiguous() &&
                input_lengths.is_contiguous() &&
                labels.scalar_type() == torch::kInt64 &&
                label_lengths.scalar_type() == torch::kInt64 &&
                input_lengths.scalar_type() == torch::kInt64 &&
                labels.dim() == 1 && label_lengths.dim() == 1 &&
                input_lengths.dim() == 1,
                "integer inputs must be contiguous int64 vectors on the same device");

    TORCH_CHECK(label_lengths.numel() == N && input_lengths.numel() == N,
                "length vector size mismatch");
    TORCH_CHECK(probs.scalar_type() == torch::kFloat32 ||
                probs.scalar_type() == torch::kFloat16 ||
                probs.scalar_type() == torch::kBFloat16,
                "unsupported probability dtype");

    int64_t total_labels = labels.numel();
    TORCH_CHECK(total_labels <= (std::numeric_limits<int64_t>::max() - 1) / 2,
                "CTC state count overflow");

    int64_t max_states = 2 * total_labels + 1;
    int64_t head_count = ctc_mul(N, C);
    int64_t state_count = ctc_mul(total_labels, 2);
    TORCH_CHECK(N <= std::numeric_limits<int64_t>::max() - state_count,
                "CTC packed state count overflow");
    state_count += N;

    int64_t nt = ctc_mul(N, T);
    int64_t count = ctc_mul(nt, C);
    int64_t workspace = ctc_mul(nt, max_states);

    ctc_mul(head_count, 8);
    ctc_mul(state_count, 8);
    ctc_mul(count, 4);
    ctc_mul(workspace, 4);
    ctc_mul(ctc_mul(N, 3), 8);

    auto fopts = probs.options().dtype(torch::kFloat32);
    auto iopts = probs.options().dtype(torch::kInt64);
    auto losses = torch::empty({N}, fopts);
    auto grads = torch::empty({N, T, C}, fopts);

    if (N == 0) return {losses, grads};

    auto alpha = torch::empty({workspace}, fopts);
    auto beta = torch::empty({workspace}, fopts);
    auto metadata = torch::empty({N, 3}, iopts);
    auto class_heads = torch::empty({head_count}, iopts);
    auto state_next = torch::empty({state_count}, iopts);

    if (probs.scalar_type() == torch::kFloat32) {
        ctc_launch<float>(
            probs, labels, label_lengths, input_lengths, losses, grads,
            alpha, beta, metadata, class_heads, state_next,
            T, N, C, max_states, total_labels);
    } else if (probs.scalar_type() == torch::kFloat16) {
        ctc_launch<c10::Half>(
            probs, labels, label_lengths, input_lengths, losses, grads,
            alpha, beta, metadata, class_heads, state_next,
            T, N, C, max_states, total_labels);
    } else {
        ctc_launch<c10::BFloat16>(
            probs, labels, label_lengths, input_lengths, losses, grads,
            alpha, beta, metadata, class_heads, state_next,
            T, N, C, max_states, total_labels);
    }

    return {losses, grads};
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    CTC (Connectionist Temporal Classification) forward loss: one forward pass
    produces both the per-sequence CTC loss and the gradient with respect to the
    input probabilities. The input probs holds **probabilities**, not logits
    (equivalent to the production library's apply_softmax=False convention: take
    the log of probs directly, no softmax), positive every frame along the class
    dimension and summing to 1; the blank class id is given by a hyperparameter
    (always 0 in the generation domain).

    Layout and input contract (time-major inputs):
      probs          (T, N, C) floating-point probability tensor, T=max_time,
                     N=batch, C=num_classes
      labels         (sum(label_lengths),) integer, the flattened label sequences
                     concatenated in batch order; label values lie in [0, C-1]
                     and are not equal to blank ([1, C-1] in the generation
                     domain)
      label_lengths  (N,) integer, target length of each sequence
      input_lengths  (N,) integer, number of valid input frames of each sequence
                     (1 <= input_lengths[n] <= T)
    Mathematical definition (for each sequence n, write Tb=input_lengths[n], the
    target l_1..l_L (L=label_lengths[n]) and the extended state sequence
    ext = [b, l_1, b, l_2, ..., b, l_L, b] (blank inserted before and after and
    between every two labels), S = 2L+1 states, s = 0..S-1; every recurrence runs
    in log space in float32, with -inf meaning unreachable):
      forward variable alpha (shape (Tb, S)):
        alpha[0,0] = log p[0, blank]; alpha[0,1] = log p[0, ext[1]] (S>1);
        everything else -inf
        alpha[t,s] = log p[t, ext[s]] + LSE( alpha[t-1,s], alpha[t-1,s-1],
                     alpha[t-1,s-2] (only when ext[s] != blank and
                     ext[s] != ext[s-2]) )
      backward variable beta (symmetric; beta does not include the emission of
      the current frame, so that alpha+beta counts every emission factor exactly
      once along each complete alignment path through state s):
        beta[Tb-1,S-1] = beta[Tb-1,S-2] = 0 (S>1), everything else -inf
        beta[t,s] = LSE( log p[t+1,ext[s]] + beta[t+1,s],
                         log p[t+1,ext[s+1]] + beta[t+1,s+1],
                         log p[t+1,ext[s+2]] + beta[t+1,s+2]
                         (the last term only when ext[s] != blank and
                         ext[s] != ext[s+2]) )
      losses[n] = -log Z, Z = LSE( alpha[Tb-1,S-1], alpha[Tb-1,S-2] )
        (the probability sum over all legal alignment paths; the reduction is the
        per-sequence 'none')
      gamma[t,s] = exp( alpha[t,s] + beta[t,s] - log Z )
      gradients[n,t,k] = d losses[n] / d probs[n,t,k]
        = -(1 / p[t,k]) * sum_{s: ext[s]=k} gamma[t,s], t < Tb; 0 for t >= Tb
    forward returns **a single 1-D tensor** out (dtype same as probs, the
    single-tensor packing protocol):
      out[0:N]         = losses (N entries)
      out[N : N+N*T*C] = gradients flattened in (N, T, C) row-major order
    Boundary behaviour:
      - the generation domain guarantees probs strictly positive (the softmax
        convention), labels without consecutive repeats and L <= Tb, so Z is
        finite with no inf/NaN; losses are on the order of <= T*ln(C), which fp16
        can represent.
      - the alpha/beta of unreachable states are -inf and the matching gamma is 0.
      - the gradient is defined with respect to the probability input (not the
        log probability): the chain factor 1/p[t,k] is already part of the
        definition.

    Input/output specification:
      probs          float32 / float16 / bfloat16 (T, N, C), contiguous
      labels / label_lengths / input_lengths   integer (...,), contiguous
      out            a single 1-D tensor, same dtype as probs, length N + N*T*C
      The evaluator casts all inputs to fp32 before passing them in (integer
      tensors must be restored to long by the implementation; their integer
      values are losslessly representable in fp32).

    Implementation constraints (violations are scored as failures):
      - Core computation (log probabilities, the alpha/beta forward-backward
        recurrence, gradient assembly) must be done with a HIP kernel inside
        the submitted file.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate computation happens in float32 (cast probs to fp32 first,
        then take the log); the output is cast back to the probs dtype and then
        concatenated into a single tensor per the packing protocol above.
      - forward returns the single tensor out (the evaluator compares a single
        output).

    Disallowed list: aiter / torch.nn.functional.ctc_loss / torch.ctc_loss /
    F.ctc_loss / torch.nn.CTCLoss / torch.ops.aten.ctc_loss /
    torch.ops.aten._ctc_loss / aten.ctc_loss / .ctc_loss( (including every
    library-level one-step CTC primitive) / warpctc / warp_ctc / torch.autograd
    and .backward() (automatic differentiation must not be used to obtain the
    gradient).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single blank, reduction='none' (per-sequence loss plus the full
    gradient), the input is already a probability (no apply_softmax branch), and
    there are no empty target sequences.
    """
    def __init__(self, blank: int = 0):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.blank = int(blank)
        # <<<END_IMPROVE>>>

    def forward(self, probs, labels, label_lengths, input_lengths):
        # <<<IMPROVE:forward_stmt_1>>>
        labels = labels.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        label_lengths = label_lengths.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        input_lengths = input_lengths.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pf = probs.contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        max_time, batch, num_classes = pf.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        losses, grads = _pyramidkernel_get_extension().ctc_forward(
            pf, labels, label_lengths, input_lengths, int(self.blank))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # Losses are produced by the HIP entrypoint above.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # Gradients are produced by the HIP entrypoint above.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Flattened-label offsets are computed inside the HIP kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # All recurrence and gradient assembly are performed by the HIP entrypoint.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        losses = losses.to(probs.dtype).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        grads = grads.to(probs.dtype).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return torch.cat((losses, grads))
        # <<<END_IMPROVE>>>

    def _ctc_one(self, logp_b, p_b, target, tb, num_classes, max_time):
        # Single-sequence log-space forward-backward: logp_b / p_b are the (T, C)
        # fp32 log probabilities / probabilities, target is (L,) long, tb is the
        # number of valid frames; returns (loss_n, grad_n) with grad_n of shape
        # (max_time, C), always 0 outside the valid frames
        C = num_classes
        L = target.numel()
        S = 2 * L + 1
        neg_inf = float("-inf")
        # device=dev is required: every intermediate tensor built inside this
        # function must live on the same device as logp_b/p_b, which are already
        # on it; omitting device raises "Expected all tensors to be on the same
        # device" on CUDA/DCU (it works on CPU, so local unit tests cannot catch
        # it)
        dev = logp_b.device

        ext = torch.empty(S, dtype=torch.long, device=dev)
        ext[0::2] = self.blank
        ext[1::2] = target

        lp_ext = logp_b[:tb, ext]                      # (tb, S)
        alpha = torch.full((tb, S), neg_inf, dtype=torch.float32, device=dev)
        beta = torch.full((tb, S), neg_inf, dtype=torch.float32, device=dev)

        # Forward recurrence (stepping over the time dimension, the state
        # dimension vectorized as a whole)
        alpha[0, 0] = lp_ext[0, 0]
        alpha[0, 1] = lp_ext[0, 1]
        for t in range(1, tb):
            prev = alpha[t - 1]
            left = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            left[1:] = prev[:-1]
            jump = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            jump[2:] = prev[:-2]
            ok = (ext[2:] != self.blank) & (ext[2:] != ext[:-2])
            jump[2:] = torch.where(ok, jump[2:], torch.full((S - 2,), neg_inf, dtype=torch.float32, device=dev))
            alpha[t] = lp_ext[t] + torch.logsumexp(torch.stack((prev, left, jump)), dim=0)

        # Backward recurrence (beta excludes the current frame's emission:
        # alpha+beta counts every emission factor exactly once along a complete
        # path through state s, so gamma is the state posterior)
        beta[tb - 1, S - 1] = 0.0
        beta[tb - 1, S - 2] = 0.0
        for t in range(tb - 2, -1, -1):
            nxt = beta[t + 1] + lp_ext[t + 1]
            right = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            right[:-1] = nxt[1:]
            jump = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            jump[:-2] = nxt[2:]
            ok = (ext[:-2] != self.blank) & (ext[:-2] != ext[2:])
            jump[:-2] = torch.where(ok, jump[:-2], torch.full((S - 2,), neg_inf, dtype=torch.float32, device=dev))
            beta[t] = torch.logsumexp(torch.stack((nxt, right, jump)), dim=0)

        log_z = torch.logsumexp(alpha[tb - 1] + beta[tb - 1], dim=0)
        gamma = torch.exp(alpha + beta - log_z)        # (tb, S) state posterior

        # dL/dp[t,k] = -(1/p[t,k]) * sum_{s: ext[s]=k} gamma[t,s]
        grad = torch.zeros(tb, C, dtype=torch.float32, device=dev)
        grad.index_add_(1, ext, -gamma)
        grad = grad / p_b[:tb]                         # divide by p (probs is strictly positive)

        grad_full = torch.zeros(max_time, C, dtype=torch.float32, device=dev)
        grad_full[:tb] = grad
        return -log_z, grad_full
