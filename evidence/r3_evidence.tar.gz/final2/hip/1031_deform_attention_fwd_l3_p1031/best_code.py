import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1031_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor deform_attention_forward(torch::Tensor, torch::Tensor, torch::Tensor,
                                      torch::Tensor, torch::Tensor);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_attention_forward", &deform_attention_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cmath>
#include <cstdint>

template<class T>
__global__ void normalization(const T* scores, float* stats, int64_t rows, int64_t K) {
    __shared__ float work[128];
    const int64_t t = threadIdx.x;
    for (int64_t r = blockIdx.x; r < rows; r += int64_t(gridDim.x)) {
        float m = -INFINITY;
        for (int64_t k = t; k < K; k += 128)
            m = fmaxf(m, float(scores[r * K + k]));
        work[t] = m;
        __syncthreads();
        for (int64_t s = 64; s; s >>= 1) {
            if (t < s) work[t] = fmaxf(work[t], work[t + s]);
            __syncthreads();
        }
        m = work[0];
        __syncthreads();
        float sum = 0.0f;
        for (int64_t k = t; k < K; k += 128)
            sum += expf(float(scores[r * K + k]) - m);
        work[t] = sum;
        __syncthreads();
        for (int64_t s = 64; s; s >>= 1) {
            if (t < s) work[t] += work[t + s];
            __syncthreads();
        }
        if (t == 0) {
            stats[2 * r] = m;
            stats[2 * r + 1] = 1.0f / work[0];
        }
        __syncthreads();
    }
}

__device__ inline int64_t metadata(const void* ptr, bool wide, int64_t i) {
    return wide ? static_cast<const int64_t*>(ptr)[i]
                : int64_t(static_cast<const float*>(ptr)[i]);
}

template<class T>
__device__ inline float corner_value(
    const T* v, int64_t n, int64_t h, int64_t d, int64_t y, int64_t x,
    int64_t H, int64_t W, int64_t base, int64_t keys, int64_t heads, int64_t D) {
    if (y < 0 || y >= H || x < 0 || x >= W)
        return 0.0f;
    const int64_t key = base + y * W + x;
    if (key < 0 || key >= keys)
        return 0.0f;
    const int64_t offset = ((n * keys + key) * heads + h) * D + d;
    return float(v[offset]);
}

template<class T, int BLOCK_THREADS>
__global__ void fused_small_rows(
    const T* v, const void* shapes, const void* starts,
    bool shape_long, bool start_long, const T* loc, const T* scores, T* out,
    int64_t rows, int64_t keys, int64_t Q, int64_t heads, int64_t D,
    int64_t K, int64_t P) {
    __shared__ float work[BLOCK_THREADS];
    __shared__ float weights[64];
    __shared__ float coefficients[4][64];
    __shared__ int64_t indices[4][64];

    const int64_t t = int64_t(threadIdx.x);

    for (int64_t r = int64_t(blockIdx.x); r < rows; r += int64_t(gridDim.x)) {
        if (K == 1) {
            if (t == 0)
                weights[0] = 1.0f;
        } else {
            const float score = t < K ? float(scores[r * K + t]) : -INFINITY;
            work[t] = score;
            __syncthreads();

            for (int64_t s = BLOCK_THREADS / 2; s; s >>= 1) {
                if (t < s)
                    work[t] = fmaxf(work[t], work[t + s]);
                __syncthreads();
            }

            const float e = t < K ? expf(score - work[0]) : 0.0f;
            __syncthreads();
            work[t] = e;
            __syncthreads();

            for (int64_t s = BLOCK_THREADS / 2; s; s >>= 1) {
                if (t < s)
                    work[t] += work[t + s];
                __syncthreads();
            }

            if (t < K)
                weights[t] = e * (1.0f / work[0]);
        }

        if (t < K) {
            const int64_t l = t / P;
            const int64_t H = metadata(shapes, shape_long, 2 * l);
            const int64_t W = metadata(shapes, shape_long, 2 * l + 1);
            const int64_t base = metadata(starts, start_long, l);
            const int64_t j = r * K + t;
            const float x = float(loc[2 * j]) * float(W);
            const float y = float(loc[2 * j + 1]) * float(H);

            for (int64_t c = 0; c < 4; ++c) {
                indices[c][t] = -1;
                coefficients[c][t] = 0.0f;
            }

            if (x > -1.0f && x < float(W) && y > -1.0f && y < float(H)) {
                const float xf = floorf(x);
                const float yf = floorf(y);
                const int64_t ix = int64_t(xf);
                const int64_t iy = int64_t(yf);
                const float fx = x - xf;
                const float fy = y - yf;

                coefficients[0][t] = (1.0f - fy) * (1.0f - fx);
                coefficients[1][t] = (1.0f - fy) * fx;
                coefficients[2][t] = fy * (1.0f - fx);
                coefficients[3][t] = fy * fx;

                for (int64_t c = 0; c < 4; ++c) {
                    const int64_t cy = iy + c / 2;
                    const int64_t cx = ix + c % 2;
                    if (cy >= 0 && cy < H && cx >= 0 && cx < W) {
                        const int64_t key = base + cy * W + cx;
                        if (key >= 0 && key < keys)
                            indices[c][t] = key;
                    }
                }
            }
        }

        __syncthreads();

        if (t < D) {
            const int64_t h = r % heads;
            const int64_t n = r / (Q * heads);
            float acc = 0.0f;

            for (int64_t k = 0; k < K; ++k) {
                float terms[4];
                for (int64_t c = 0; c < 4; ++c) {
                    const int64_t key = indices[c][k];
                    const float val = (key >= 0 && key < keys)
                        ? float(v[((n * keys + key) * heads + h) * D + t])
                        : 0.0f;
                    terms[c] = val * coefficients[c][k];
                }

                float sample = __fadd_rn(terms[0], terms[1]);
                sample = __fadd_rn(sample, terms[2]);
                sample = __fadd_rn(sample, terms[3]);
                acc = __fadd_rn(acc, weights[k] * sample);
            }

            out[r * D + t] = T(acc);
        }

        __syncthreads();
    }
}

template<class T>
__global__ void sample_output(
    const T* v, const void* shapes, const void* starts,
    bool shape_long, bool start_long, const T* loc, const T* scores,
    const float* stats, T* out, int64_t total, int64_t keys, int64_t Q,
    int64_t heads, int64_t D, int64_t L, int64_t P) {
    const int64_t K = L * P;

    for (int64_t i = int64_t(blockIdx.x) * int64_t(blockDim.x) + int64_t(threadIdx.x);
         i < total;
         i += int64_t(gridDim.x) * int64_t(blockDim.x)) {
        const int64_t d = i % D;
        const int64_t r = i / D;
        const int64_t h = r % heads;
        const int64_t n = r / (Q * heads);

        const float m = K == 1 ? 0.0f : stats[2 * r];
        const float inv = K == 1 ? 1.0f : stats[2 * r + 1];
        float acc = 0.0f;

        for (int64_t l = 0; l < L; ++l) {
            const int64_t H = metadata(shapes, shape_long, 2 * l);
            const int64_t W = metadata(shapes, shape_long, 2 * l + 1);
            const int64_t base = metadata(starts, start_long, l);

            for (int64_t p = 0; p < P; ++p) {
                const int64_t j = r * K + l * P + p;
                const float x = float(loc[2 * j]) * float(W);
                const float y = float(loc[2 * j + 1]) * float(H);

                if (!(x > -1.0f && x < float(W) &&
                      y > -1.0f && y < float(H)))
                    continue;

                const float xf = floorf(x);
                const float yf = floorf(y);
                const int64_t ix = int64_t(xf);
                const int64_t iy = int64_t(yf);
                const float fx = x - xf;
                const float fy = y - yf;

                float s = corner_value(
                    v, n, h, d, iy, ix, H, W, base, keys, heads, D) *
                    ((1.0f - fy) * (1.0f - fx));
                s = __fadd_rn(s, corner_value(
                    v, n, h, d, iy, ix + 1, H, W, base, keys, heads, D) *
                    ((1.0f - fy) * fx));
                s = __fadd_rn(s, corner_value(
                    v, n, h, d, iy + 1, ix, H, W, base, keys, heads, D) *
                    (fy * (1.0f - fx)));
                s = __fadd_rn(s, corner_value(
                    v, n, h, d, iy + 1, ix + 1, H, W, base, keys, heads, D) *
                    (fy * fx));

                const float w = K == 1
                    ? 1.0f
                    : expf(float(scores[j]) - m) * inv;
                acc = __fadd_rn(acc, w * s);
            }
        }

        out[i] = T(acc);
    }
}

torch::Tensor deform_attention_forward(
    torch::Tensor value, torch::Tensor shapes, torch::Tensor starts,
    torch::Tensor loc, torch::Tensor scores) {
    TORCH_CHECK(value.is_cuda(), "value must be on GPU");
    c10::cuda::CUDAGuard guard(value.device());

    for (const auto& t : {value, shapes, starts, loc, scores}) {
        TORCH_CHECK(t.device() == value.device() && t.is_contiguous(),
                    "inputs must be contiguous and on the same GPU");
    }

    TORCH_CHECK(value.dim() == 4 && shapes.dim() == 2 &&
                shapes.size(1) == 2 && starts.dim() == 1 &&
                loc.dim() == 6 && scores.dim() == 5, "invalid ranks");
    TORCH_CHECK(value.scalar_type() == at::kFloat ||
                value.scalar_type() == at::kHalf,
                "value must be float or half");
    TORCH_CHECK(loc.scalar_type() == value.scalar_type() &&
                scores.scalar_type() == value.scalar_type(),
                "dtype mismatch");
    TORCH_CHECK((shapes.scalar_type() == at::kLong ||
                 shapes.scalar_type() == at::kFloat) &&
                (starts.scalar_type() == at::kLong ||
                 starts.scalar_type() == at::kFloat),
                "metadata must be int64 or float32");

    const int64_t N = value.size(0);
    const int64_t keys = value.size(1);
    const int64_t heads = value.size(2);
    const int64_t D = value.size(3);
    const int64_t L = shapes.size(0);
    const int64_t Q = loc.size(1);
    const int64_t P = loc.size(4);

    TORCH_CHECK(N > 0 && keys > 0 && heads > 0 && D > 0 &&
                L > 0 && Q > 0 && P > 0,
                "dimensions must be positive");
    TORCH_CHECK(starts.size(0) == L && loc.size(0) == N &&
                loc.size(2) == heads && loc.size(3) == L &&
                loc.size(5) == 2,
                "invalid locations or starts");
    TORCH_CHECK(scores.size(0) == N && scores.size(1) == Q &&
                scores.size(2) == heads && scores.size(3) == L &&
                scores.size(4) == P,
                "invalid scores");

    const int64_t rows = N * Q * heads;
    const int64_t K = L * P;
    const int64_t total = rows * D;

    auto out = torch::empty({N, Q, heads * D}, value.options());
    auto stream = at::cuda::getCurrentCUDAStream();
    const int norm_grid = int(std::min<int64_t>(rows, 65535));
    const int out_grid = int(std::min<int64_t>((total + 255) / 256, 65535));

    if (K <= 64 && D <= 128) {
        AT_DISPATCH_FLOATING_TYPES_AND_HALF(value.scalar_type(), "deform_small", [&] {
            if (D <= 64) {
                fused_small_rows<scalar_t, 64><<<norm_grid, 64, 0, stream>>>(
                    value.data_ptr<scalar_t>(),
                    shapes.data_ptr(),
                    starts.data_ptr(),
                    shapes.scalar_type() == at::kLong,
                    starts.scalar_type() == at::kLong,
                    loc.data_ptr<scalar_t>(),
                    scores.data_ptr<scalar_t>(),
                    out.data_ptr<scalar_t>(),
                    rows, keys, Q, heads, D, K, P);
            } else {
                fused_small_rows<scalar_t, 128><<<norm_grid, 128, 0, stream>>>(
                    value.data_ptr<scalar_t>(),
                    shapes.data_ptr(),
                    starts.data_ptr(),
                    shapes.scalar_type() == at::kLong,
                    starts.scalar_type() == at::kLong,
                    loc.data_ptr<scalar_t>(),
                    scores.data_ptr<scalar_t>(),
                    out.data_ptr<scalar_t>(),
                    rows, keys, Q, heads, D, K, P);
            }
            auto error = hipGetLastError();
            TORCH_CHECK(error == hipSuccess, hipGetErrorString(error));
        });
    } else {
        auto stats = torch::empty({rows, 2}, value.options().dtype(at::kFloat));

        AT_DISPATCH_FLOATING_TYPES_AND_HALF(value.scalar_type(), "deform_attention", [&] {
            if (K != 1) {
                normalization<scalar_t><<<norm_grid, 128, 0, stream>>>(
                    scores.data_ptr<scalar_t>(),
                    stats.data_ptr<float>(),
                    rows, K);
                auto error = hipGetLastError();
                TORCH_CHECK(error == hipSuccess, hipGetErrorString(error));
            }

            sample_output<scalar_t><<<out_grid, 256, 0, stream>>>(
                value.data_ptr<scalar_t>(),
                shapes.data_ptr(),
                starts.data_ptr(),
                shapes.scalar_type() == at::kLong,
                starts.scalar_type() == at::kLong,
                loc.data_ptr<scalar_t>(),
                scores.data_ptr<scalar_t>(),
                stats.data_ptr<float>(),
                out.data_ptr<scalar_t>(),
                total, keys, Q, heads, D, L, P);
            auto error = hipGetLastError();
            TORCH_CHECK(error == hipSuccess, hipGetErrorString(error));
        });
    }

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Multi-Scale Deformable Attention forward: value sampling + hand-written
    bilinear interpolation + softmax normalization of the sampling weights.

    Semantics (all intermediate computation in float32): value (N, n_keys, heads,
    D) is the concatenation of the multi-scale feature levels -- level l
    contributes spatial_shapes[l] = (H_l, W_l) keys, laid out inside the level in
    row-major order (H first, then W) over
    [level_start_index[l], level_start_index[l] + H_l*W_l), where
    level_start_index must be the prefix sum of the per-level H_l*W_l (first
    element 0) and n_keys = sum_l H_l*W_l. sampling_locations
    (N, Q, heads, L, P, 2) gives the normalized coordinates of every
    (batch, query, head) at every sampling point of every level, with the last
    dimension being (x, y): channel 0 runs along W and channel 1 along H (the
    generation domain is [0,1)), so the actual sampling coordinates are
        loc_x = x * W_l,  loc_y = y * H_l
    The sampled value goes through four-corner bilinear interpolation:
        ix0 = floor(loc_x), iy0 = floor(loc_y), fx = loc_x - ix0, fy = loc_y - iy0
        the weights of the four corners (iy0,ix0), (iy0,ix0+1), (iy0+1,ix0),
        (iy0+1,ix0+1) are, in that order,
        (1-fy)(1-fx), (1-fy)fx, fy(1-fx), fy*fx
    When a corner's row or column is out of range (< 0 or > dim-1) that corner
    contributes 0 while the other corners are weighted as usual -- i.e. zero
    padding semantics, with no clamp / nearest-neighbour pull-back anywhere in the
    computation; when the coordinates are entirely out of range the sampled value
    is 0.
    attention_weights (N, Q, heads, L, P) are non-negative unnormalized scores:
    first flatten (levels x points) into one dimension and run a numerically
    stable softmax (max subtraction) to normalize them into convex-combination
    weights, then take the weighted sum against the interpolated value of each
    sampling point:
        out[n, q, h*D + d] = sum_{l, p} w[n,q,h,l,p] * bilinear(value_l)[n,q,h,p,d]
    The output is the single tensor out (N, Q, heads*D), cast back to the value
    dtype (naturally a single output, no multi-output packing). When L*P = 1 the
    softmax weights are identically 1.

    Input/output specification (all tensors contiguous):
      value              float32 / float16 (N, n_keys, heads, D)
      spatial_shapes     int64 (L, 2), each row (H_l, W_l), H_l / W_l >= 1
      level_start_index  int64 (L,), prefix sum of the per-level key counts
      sampling_locations same dtype as value (N, Q, heads, L, P, 2), generation domain [0,1)
      attention_weights  same dtype as value (N, Q, heads, L, P), non-negative
      out                single tensor, same dtype as value (N, Q, heads*D)
      every dimension is an arbitrary positive integer (including 1, non-powers
      of 2, and non-16-aligned sizes; a single-level single-pixel (H_l, W_l) =
      (1, 1), and 1xN / Nx1 thin-strip levels are all legal boundaries). The
      evaluator casts every input to fp32 before passing it in (lossless for both
      the low precision and the int64 indices -- an index value <= 2^24 is exactly
      representable in fp32), so the implementation must restore
      spatial_shapes / level_start_index to integer indices before using them.

    Implementation constraints (violations are scored as failures):
      - The core computation (coordinate expansion, four-corner bilinear
        interpolation, softmax normalization of the weights, and the cross-level
        cross-point weighted reduction) must be hand-written as a HIP kernel
        inside the submitted file.
      - The softmax, the interpolation and the weighted reduction are done in
        float32, and the output is cast back to the value dtype.
      - forward returns the single tensor out (N, Q, heads*D) (the evaluator
        compares a single output).
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden list: torchvision (including ready-made deformable attention /
    deformable convolution primitives such as torchvision.ops.ms_deform_attn),
    mmcv, miopen, hipdnn, aiter,
    torch.nn.functional.grid_sample (F.grid_sample),
    torch.nn.functional.interpolate (F.interpolate), torch.matmul /
    torch.bmm / torch.mm / torch.einsum / torch.tensordot,
    torch.softmax / torch.nn.functional.softmax (F.softmax).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, value, spatial_shapes, level_start_index, sampling_locations, attention_weights):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().deform_attention_forward(
            value, spatial_shapes, level_start_index, sampling_locations, attention_weights)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        level_start_index = level_start_index.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        n, n_keys, num_heads, d = value.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        n_levels = spatial_shapes.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_queries = sampling_locations.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_points = sampling_locations.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert sampling_locations.dim() == 6 \
            and sampling_locations.shape[2] == num_heads \
            and sampling_locations.shape[3] == n_levels \
            and sampling_locations.shape[5] == 2, \
            "sampling_locations must be (N, Q, heads, L, P, 2)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert attention_weights.shape == (n, n_queries, num_heads, n_levels, n_points), \
            "attention_weights must be (N, Q, heads, L, P)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert value.shape[1] == int(spatial_shapes.prod(dim=1).sum()), \
            "dimension 1 of value must equal the sum of the per-level H_l*W_l"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        vf = value.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        loc = sampling_locations.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        wf = attention_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        wf = wf.reshape(n, n_queries, num_heads, n_levels * n_points)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # Normalization is implemented by the HIP entrypoint above.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        n_idx = torch.arange(n, device=vf.device).view(n, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        h_idx = torch.arange(num_heads, device=vf.device).view(1, 1, num_heads)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        out = torch.zeros(n, n_queries, num_heads, d,
                          dtype=torch.float32, device=vf.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        for l in range(n_levels):
            h_l = int(spatial_shapes[l, 0])
            w_l = int(spatial_shapes[l, 1])
            base = int(level_start_index[l])
            v_l = vf[:, base: base + h_l * w_l]

            sx = loc[:, :, :, l, :, 0] * float(w_l)
            sy = loc[:, :, :, l, :, 1] * float(h_l)
            ix0 = torch.floor(sx).to(torch.long)
            iy0 = torch.floor(sy).to(torch.long)
            fx = sx - ix0.to(torch.float32)
            fy = sy - iy0.to(torch.float32)

            def corner(iy, ix, wgt):
                valid = ((iy >= 0) & (iy <= h_l - 1)
                         & (ix >= 0) & (ix <= w_l - 1)).to(torch.float32)
                flat = iy.clamp(0, h_l - 1) * w_l + ix.clamp(0, w_l - 1)
                vals = v_l[n_idx, flat, h_idx]
                return vals * (valid * wgt).unsqueeze(-1)

            for p in range(n_points):
                iy0p, ix0p = iy0[..., p], ix0[..., p]
                fyp, fxp = fy[..., p], fx[..., p]
                sampled = (corner(iy0p, ix0p, (1.0 - fyp) * (1.0 - fxp))
                           + corner(iy0p, ix0p + 1, (1.0 - fyp) * fxp)
                           + corner(iy0p + 1, ix0p, fyp * (1.0 - fxp))
                           + corner(iy0p + 1, ix0p + 1, fyp * fxp))
                out = out + wf[:, :, :, l, p].unsqueeze(-1) * sampled
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        return out.view(n, n_queries, num_heads * d).to(value.dtype)
        # <<<END_IMPROVE>>>
