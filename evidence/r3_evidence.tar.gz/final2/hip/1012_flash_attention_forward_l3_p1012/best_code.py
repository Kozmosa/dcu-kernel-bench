import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1012_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor varlen_attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor cu_q, torch::Tensor cu_k, torch::Tensor causal, double scale);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("varlen_attention_forward", &varlen_attention_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cstdint>
#include <cmath>

struct Strides {
    int64_t a, b, c;
};

template<typename T, int P>
__global__ void attention_kernel(
    const T* q, const T* k, const T* v, T* out,
    const int32_t* cq, const int32_t* ck, const int32_t* causal,
    int64_t tq, int64_t tk, int64_t hq, int64_t hk, int64_t d,
    int64_t batches, Strides qs, Strides ks, Strides vs, float scale)
{
    constexpr int S = P + 1;
    __shared__ float query[4 * P];
    __shared__ float tile[32 * S];
    __shared__ float prob[128];
    __shared__ float maximum[4], denom[4], alpha[4];
    const int64_t t = threadIdx.x;
    const int64_t r = t / 32, lane = t % 32;
    const int64_t work_count = ((tq + 3) / 4) * hq;
    for (int64_t work = blockIdx.x; work < work_count; work += gridDim.x) {
        const int64_t head = work % hq;
        const int64_t kvhead = head / (hq / hk);
        const int64_t first = (work / hq) * 4;
        const int64_t last = first + 4 < tq ? first + 4 : tq;
        // Runs are uniform across the block and never share K/V across segments.
        for (int64_t base = first; base < last;) {
            int64_t lo = 0, hi = batches;
            while (lo < hi) {
                const int64_t mid = lo + (hi - lo) / 2;
                if (static_cast<int64_t>(cq[mid + 1]) <= base)
                    lo = mid + 1;
                else
                    hi = mid;
            }
            if (lo >= batches) break;
            const int64_t sq = static_cast<int64_t>(cq[lo]);
            const int64_t eq = static_cast<int64_t>(cq[lo + 1]);
            const int64_t sk = static_cast<int64_t>(ck[lo]);
            const int64_t ek = static_cast<int64_t>(ck[lo + 1]);
            if (sq < 0 || eq > tq || sq > base || eq <= base ||
                sk < 0 || ek > tk || ek <= sk || eq - sq > ek - sk)
                break;
            const int64_t end = eq < last ? eq : last;
            const int64_t nr = end - base;
            const int64_t lq = eq - sq, lk = ek - sk;
            const bool mask = causal[0] != 0;
            const int64_t limit = mask ? end - sq + lk - lq : lk;
            float accum[4 * P / 128];
            #pragma unroll
            for (int n = 0; n < 4 * P / 128; ++n) accum[n] = 0.0f;

            for (int64_t x = t; x < 4 * P; x += 128) {
                const int64_t row = x / P, dim = x % P;
                query[x] = row < nr && dim < d
                    ? static_cast<float>(q[(base + row) * qs.a + head * qs.b + dim * qs.c])
                    : 0.0f;
            }
            if (t < 4) {
                maximum[t] = -INFINITY;
                denom[t] = 0.0f;
            }
            __syncthreads();
            for (int64_t start = 0; start < limit; start += 32) {
                for (int64_t x = t; x < 32 * P; x += 128) {
                    const int64_t key_row = x / P, dim = x % P;
                    const int64_t j = start + key_row;
                    tile[key_row * S + dim] = j < limit && dim < d
                        ? static_cast<float>(k[(sk + j) * ks.a + kvhead * ks.b + dim * ks.c])
                        : 0.0f;
                }
                __syncthreads();
                const int64_t j = start + lane;
                const bool valid = r < nr && j < lk &&
                    (!mask || j <= base + r - sq + lk - lq);
                float score = -INFINITY;
                if (valid) {
                    float dot = 0.0f;
                    for (int64_t dim = 0; dim < d; ++dim)
                        dot = fmaf(query[r * P + dim], tile[lane * S + dim], dot);
                    score = dot * scale;
                }
                // HIP width 32 keeps each aligned half of a wave64 independent.
                // All threads participate, including masked query/key lanes.
                float tile_max = score;
                #pragma unroll
                for (int step = 16; step > 0; step /= 2) {
                    const float other = __shfl_down(tile_max, step, 32);
                    if (lane < step) tile_max = fmaxf(tile_max, other);
                }
                if (lane == 0) {
                    const float tm = tile_max;
                    if (tm == -INFINITY) {
                        alpha[r] = 1.0f;
                    } else {
                        const float next = fmaxf(maximum[r], tm);
                        alpha[r] = expf(maximum[r] - next);
                        maximum[r] = next;
                    }
                }
                __syncthreads();
                const float p = valid ? expf(score - maximum[r]) : 0.0f;
                prob[t] = p;
                float tile_sum = p;
                #pragma unroll
                for (int step = 16; step > 0; step /= 2) {
                    const float other = __shfl_down(tile_sum, step, 32);
                    if (lane < step) tile_sum += other;
                }
                if (lane == 0) denom[r] = alpha[r] * denom[r] + tile_sum;
                // Publish probabilities and denominators and protect K-to-V reuse.
                __syncthreads();
                // All K readers have completed before V overwrites the tile.
                for (int64_t x = t; x < 32 * P; x += 128) {
                    const int64_t key_row = x / P, dim = x % P;
                    const int64_t key = start + key_row;
                    tile[key_row * S + dim] = key < limit && dim < d
                        ? static_cast<float>(v[(sk + key) * vs.a + kvhead * vs.b + dim * vs.c])
                        : 0.0f;
                }
                __syncthreads();
                #pragma unroll
                for (int n = 0; n < 4 * P / 128; ++n) {
                    const int64_t x = t + static_cast<int64_t>(n) * 128;
                    const int64_t row = x / P, dim = x % P;
                    if (row < nr && dim < d) {
                        float sum = 0.0f;
                        #pragma unroll
                        for (int64_t key = 0; key < 32; ++key)
                            sum = fmaf(prob[row * 32 + key], tile[key * S + dim], sum);
                        accum[n] = alpha[row] * accum[n] + sum;
                    }
                }
                __syncthreads();
            }
            #pragma unroll
            for (int n = 0; n < 4 * P / 128; ++n) {
                const int64_t x = t + static_cast<int64_t>(n) * 128;
                const int64_t row = x / P, dim = x % P;
                if (row < nr && dim < d)
                    out[((base + row) * hq + head) * d + dim] =
                        static_cast<T>(accum[n] / denom[row]);
            }
            __syncthreads();
            base = end;
        }
        __syncthreads();
    }
}

template<typename T>
void launch_attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                      torch::Tensor out, torch::Tensor cq, torch::Tensor ck,
                      torch::Tensor causal, float scale, hipStream_t stream) {
    const int64_t tq = q.size(0), tk = k.size(0), hq = q.size(1);
    const int64_t hk = k.size(1), d = q.size(2), batches = cq.numel() - 1;
    const Strides qs{q.stride(0), q.stride(1), q.stride(2)};
    const Strides ks{k.stride(0), k.stride(1), k.stride(2)};
    const Strides vs{v.stride(0), v.stride(1), v.stride(2)};
    const unsigned blocks = static_cast<unsigned>(
        std::min<int64_t>(((tq + 3) / 4) * hq, 65535));
    #define LAUNCH(P) \
        attention_kernel<T, P><<<blocks, 128, 0, stream>>>( \
            q.data_ptr<T>(), k.data_ptr<T>(), v.data_ptr<T>(), out.data_ptr<T>(), \
            cq.data_ptr<int32_t>(), ck.data_ptr<int32_t>(), causal.data_ptr<int32_t>(), \
            tq, tk, hq, hk, d, batches, qs, ks, vs, scale)
    if (d <= 32) { LAUNCH(32); }
    else if (d <= 64) { LAUNCH(64); }
    else if (d <= 128) { LAUNCH(128); }
    else { LAUNCH(256); }
    #undef LAUNCH
    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "attention launch failed: ", hipGetErrorString(err));
}

torch::Tensor varlen_attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor cu_q, torch::Tensor cu_k, torch::Tensor causal, double scale)
{
    TORCH_CHECK(q.is_cuda(), "q must be on GPU");
    TORCH_CHECK(k.device() == q.device() && v.device() == q.device() &&
                cu_q.device() == q.device() && cu_k.device() == q.device() &&
                causal.device() == q.device(), "all tensors must share a device");
    TORCH_CHECK(q.dim() == 3 && k.dim() == 3 && v.dim() == 3, "Q/K/V must have rank 3");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() && q.scalar_type() == v.scalar_type(),
                "Q/K/V dtype mismatch");
    TORCH_CHECK(q.scalar_type() == at::kFloat || q.scalar_type() == at::kHalf ||
                q.scalar_type() == at::kBFloat16, "unsupported Q/K/V dtype");
    TORCH_CHECK(k.sizes() == v.sizes() && q.size(2) == k.size(2), "K/V shape mismatch");
    TORCH_CHECK(q.size(2) >= 1 && q.size(2) <= 256, "invalid head dimension");
    TORCH_CHECK(q.size(1) > 0 && k.size(1) > 0 && q.size(1) % k.size(1) == 0,
                "invalid head counts");
    TORCH_CHECK(cu_q.dim() == 1 && cu_k.dim() == 1 &&
                cu_q.numel() == cu_k.numel() && cu_q.numel() >= 1 &&
                cu_q.scalar_type() == at::kInt && cu_k.scalar_type() == at::kInt &&
                cu_q.is_contiguous() && cu_k.is_contiguous(), "invalid sequence metadata");
    TORCH_CHECK(causal.numel() == 1 && causal.scalar_type() == at::kInt &&
                causal.is_contiguous(), "invalid causal tensor");
    c10::cuda::CUDAGuard guard(q.device());
    auto out = torch::empty(q.sizes(), q.options());
    if (out.numel() == 0) return out;
    TORCH_CHECK(cu_q.numel() >= 2, "missing sequence metadata");
    const auto stream = at::cuda::getCurrentCUDAStream(q.get_device());
    if (q.scalar_type() == at::kFloat)
        launch_attention<float>(q, k, v, out, cu_q, cu_k, causal, static_cast<float>(scale), stream.stream());
    else if (q.scalar_type() == at::kHalf)
        launch_attention<at::Half>(q, k, v, out, cu_q, cu_k, causal, static_cast<float>(scale), stream.stream());
    else
        launch_attention<at::BFloat16>(q, k, v, out, cu_q, cu_k, causal, static_cast<float>(scale), stream.stream());
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Variable-length (varlen) FlashAttention v2 forward pass: dense Q/K/V is
    segmented by cu_seqlens and each segment computes scaled dot-product attention
    independently, supporting MHA/GQA and a causal
    mask.

    Mathematical definition: for segment b of the batch (let
    L_q = cu_seqlens_q[b+1]-cu_seqlens_q[b],
    L_k = cu_seqlens_k[b+1]-cu_seqlens_k[b]; the task constrains 0 < L_q <= L_k, and
    g = num_q_heads // num_kv_heads):
      scores[h,i,j] = sm_scale * <q[start_q+i,h,:], k[start_k+j,h//g,:]>
      with causal=1 a bottom-right-aligned causal mask is applied: positions with
      j > i + (L_k - L_q) are set to -inf (i.e. query position i only attends to key
      positions j <= i + L_k - L_q); with causal=0 no mask is applied.
      p[h,i,:] = softmax_j(scores[h,i,:])
      out[start_q+i,h,:] = sum_j p[h,i,j] * v[start_k+j,h//g,:]
    The softmax uses a numerically stable formulation; intermediates are accumulated
    in float32 and the output is cast back to the input dtype.
    Boundary behaviour: the task guarantees L_q >= 1 for every segment, so the
    softmax denominator is always positive and no row is fully masked; segments
    other than the last do not affect each other.

    Input/output specification:
      q            [total_q, num_q_heads, head_dim]  float16/bfloat16
      k, v         [total_k, num_kv_heads, head_dim] same dtype as q
      cu_seqlens_q [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_q
      cu_seqlens_k [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_k
      causal       0-dim int32 tensor, 1 = causal mask, 0 = no mask
      out          [total_q, num_q_heads, head_dim], same dtype as q
    Global constraints: num_q_heads is an integer multiple of num_kv_heads (GQA;
    equality means MHA); 1 <= head_dim <= 256; for every sequence
    0 < L_q <= L_k.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: varlen forward, non-quantized inputs, no bias/ALiBi, no dropout, no
    LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, cu_seqlens_q, cu_seqlens_k, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        cu_seqlens_q = cu_seqlens_q.to(device=q.device, dtype=torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        cu_seqlens_k = cu_seqlens_k.to(device=q.device, dtype=torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        if torch.is_tensor(causal):
            causal = causal.to(device=q.device, dtype=torch.int32).contiguous()
        else:
            causal = torch.tensor(causal, device=q.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        nheads_q = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        nheads_k = k.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        group = nheads_q // nheads_k
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert nheads_q == nheads_k * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        num_seqs = int(cu_seqlens_q.numel()) - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = _pyramidkernel_get_extension().varlen_attention_forward(
            q, k, v, cu_seqlens_q, cu_seqlens_k, causal, self.sm_scale
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
