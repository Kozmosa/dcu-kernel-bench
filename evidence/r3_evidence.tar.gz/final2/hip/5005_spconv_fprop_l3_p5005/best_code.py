import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5005_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

torch::Tensor spconv_forward(
    torch::Tensor features_fp32,
    torch::Tensor weights_fp32,
    torch::Tensor indice_pairs,
    torch::Tensor indice_counts,
    int64_t num_act_out);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("spconv_forward", &spconv_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cstdint>
#include <algorithm>
#include <limits>

namespace {

__global__ void spconv_kernel(
    const float* __restrict__ features,
    const float* __restrict__ weights,
    const int32_t* __restrict__ pairs,
    const int32_t* __restrict__ counts,
    float* __restrict__ output,
    int64_t n,
    int64_t c_in,
    int64_t c_out,
    int64_t kv,
    int64_t num_act_out,
    int64_t pair_count,
    int64_t weight_count,
    int64_t feature_count,
    int64_t output_count,
    int64_t pair_tiles,
    int64_t channel_tiles,
    int64_t logical_blocks) {
    __shared__ float feature_tile[16][32];
    __shared__ float weight_tile[32][32];
    __shared__ int64_t input_rows[16];
    __shared__ int64_t output_rows[16];
    __shared__ int valid_rows[16];

    const int64_t tid = static_cast<int64_t>(threadIdx.x);
    const int64_t pair_lane = tid / 32;
    const int64_t output_lane = tid % 32;
    const int64_t step = static_cast<int64_t>(gridDim.x);

    for (int64_t logical = static_cast<int64_t>(blockIdx.x);
         logical < logical_blocks;) {
        const int64_t channel_tile = logical % channel_tiles;
        const int64_t kp = logical / channel_tiles;
        const int64_t pair_tile = kp % pair_tiles;
        const int64_t k = kp / pair_tiles;
        const int64_t first_j = pair_tile * 16;
        const int64_t channel_base = channel_tile * 32;
        const int64_t channel = channel_base + output_lane;

        // All threads take the same branch, including empty sparse tiles.
        if (k < kv && first_j < n &&
            first_j < static_cast<int64_t>(counts[k])) {
            const int64_t count = static_cast<int64_t>(counts[k]);
            if (tid < 16) {
                const int64_t j = first_j + tid;
                input_rows[tid] = 0;
                output_rows[tid] = 0;
                valid_rows[tid] = 0;
                if (j < n && j < count) {
                    const int64_t in_offset = k * n + j;
                    const int64_t out_offset = kv * n + in_offset;
                    if (in_offset >= 0 && in_offset < pair_count &&
                        out_offset >= 0 && out_offset < pair_count) {
                        const int64_t in_row = static_cast<int64_t>(pairs[in_offset]);
                        const int64_t out_row = static_cast<int64_t>(pairs[out_offset]);
                        if (in_row >= 0 && in_row < n &&
                            out_row >= 0 && out_row < num_act_out) {
                            input_rows[tid] = in_row;
                            output_rows[tid] = out_row;
                            valid_rows[tid] = 1;
                        }
                    }
                }
            }
            __syncthreads();

            float accumulator = 0.0f;
            float accumulator_second = 0.0f;
            const int64_t second_pair_lane = pair_lane + 8;
            const int64_t reduction_tiles = c_in / 32 + (c_in % 32 != 0);
            for (int64_t tile = 0; tile < reduction_tiles; ++tile) {
                const int64_t input_base = tile * 32;
                const int64_t input_i = input_base + output_lane;
                float fv = 0.0f;
                float fv_second = 0.0f;
                if (valid_rows[pair_lane] && input_i < c_in) {
                    const int64_t offset = input_rows[pair_lane] * c_in + input_i;
                    if (offset >= 0 && offset < feature_count) {
                        fv = features[offset];
                    }
                }
                if (valid_rows[second_pair_lane] && input_i < c_in) {
                    const int64_t offset = input_rows[second_pair_lane] * c_in + input_i;
                    if (offset >= 0 && offset < feature_count) {
                        fv_second = features[offset];
                    }
                }
                feature_tile[pair_lane][output_lane] = fv;
                feature_tile[second_pair_lane][output_lane] = fv_second;

                for (int64_t linear = tid; linear < 1024; linear += 256) {
                    const int64_t local_channel = linear / 32;
                    const int64_t local_i = linear % 32;
                    const int64_t o = channel_base + local_channel;
                    const int64_t i = input_base + local_i;
                    float wv = 0.0f;
                    if (o < c_out && i < c_in) {
                        // Original contiguous filters storage is reinterpreted
                        // as (c_out, kv, c_in): W[o,i,k] = F[o,k,i].
                        // local_i varies fastest for contiguous global loads.
                        const int64_t offset = (o * kv + k) * c_in + i;
                        if (offset >= 0 && offset < weight_count) {
                            wv = weights[offset];
                        }
                    }
                    weight_tile[local_i][local_channel] = wv;
                }
                __syncthreads();

                #pragma unroll
                for (int64_t r = 0; r < 32; ++r) {
                    const float weight_value = weight_tile[r][output_lane];
                    accumulator += feature_tile[pair_lane][r] * weight_value;
                    accumulator_second += feature_tile[second_pair_lane][r] * weight_value;
                }
                __syncthreads();
            }

            if (valid_rows[pair_lane] && channel < c_out) {
                const int64_t offset = output_rows[pair_lane] * c_out + channel;
                if (offset >= 0 && offset < output_count) {
                    atomicAdd(output + offset, accumulator);
                }
            }
            if (valid_rows[second_pair_lane] && channel < c_out) {
                const int64_t offset = output_rows[second_pair_lane] * c_out + channel;
                if (offset >= 0 && offset < output_count) {
                    atomicAdd(output + offset, accumulator_second);
                }
            }
            __syncthreads();
        }
        // Avoid overflow even for a logical grid near the int64 limit.
        if (logical_blocks - logical <= step) {
            break;
        }
        logical += step;
    }
}

}

torch::Tensor spconv_forward(
    torch::Tensor features_fp32,
    torch::Tensor weights_fp32,
    torch::Tensor indice_pairs,
    torch::Tensor indice_counts,
    int64_t num_act_out) {
    TORCH_CHECK(features_fp32.is_cuda(), "features must be a device tensor");
    TORCH_CHECK(weights_fp32.is_cuda(), "weights must be a device tensor");
    TORCH_CHECK(indice_pairs.is_cuda(), "indice_pairs must be a device tensor");
    TORCH_CHECK(indice_counts.is_cuda(), "indice_counts must be a device tensor");
    TORCH_CHECK(weights_fp32.device() == features_fp32.device() &&
                indice_pairs.device() == features_fp32.device() &&
                indice_counts.device() == features_fp32.device(),
                "all tensors must share the feature device");
    const c10::cuda::CUDAGuard guard(features_fp32.device());

    TORCH_CHECK(features_fp32.scalar_type() == torch::kFloat32,
                "features must be float32");
    TORCH_CHECK(weights_fp32.scalar_type() == torch::kFloat32,
                "weights must be float32");
    TORCH_CHECK(indice_pairs.scalar_type() == torch::kInt32,
                "indice_pairs must be int32");
    TORCH_CHECK(indice_counts.scalar_type() == torch::kInt32,
                "indice_num_per_loc must be int32");

    TORCH_CHECK(features_fp32.is_contiguous(), "features must be contiguous");
    TORCH_CHECK(weights_fp32.is_contiguous(), "weights must be contiguous");
    TORCH_CHECK(indice_pairs.is_contiguous(), "indice_pairs must be contiguous");
    TORCH_CHECK(indice_counts.is_contiguous(),
                "indice_num_per_loc must be contiguous");

    TORCH_CHECK(features_fp32.dim() == 2,
                "features must be two-dimensional");
    TORCH_CHECK(weights_fp32.dim() == 3,
                "weights must be three-dimensional");
    TORCH_CHECK(indice_pairs.dim() == 3,
                "indice_pairs must be three-dimensional");
    TORCH_CHECK(indice_counts.dim() == 1,
                "indice_num_per_loc must be one-dimensional");

    const int64_t n = static_cast<int64_t>(features_fp32.size(0));
    const int64_t c_in = static_cast<int64_t>(features_fp32.size(1));
    const int64_t c_out = static_cast<int64_t>(weights_fp32.size(0));
    const int64_t weight_cin = static_cast<int64_t>(weights_fp32.size(1));
    const int64_t kv = static_cast<int64_t>(weights_fp32.size(2));

    TORCH_CHECK(weight_cin == c_in, "incompatible channel dimensions");
    TORCH_CHECK(indice_pairs.size(0) == 2,
                "indice_pairs first dimension must be 2");
    TORCH_CHECK(indice_pairs.size(1) == kv,
                "indice_pairs kernel dimension mismatch");
    TORCH_CHECK(indice_pairs.size(2) == n,
                "indice_pairs active dimension mismatch");
    TORCH_CHECK(indice_counts.size(0) == kv,
                "indice count dimension mismatch");
    TORCH_CHECK(num_act_out >= 0, "num_act_out must be nonnegative");

    const int64_t pair_count = static_cast<int64_t>(indice_pairs.numel());
    const int64_t weight_count = static_cast<int64_t>(weights_fp32.numel());

    auto output = torch::zeros(
        {num_act_out, c_out},
        features_fp32.options().dtype(torch::kFloat32));

    if (n > 0 && kv > 0 && c_in > 0 && c_out > 0 && num_act_out > 0) {
        const int64_t pair_tiles = n / 16 + (n % 16 != 0);
        const int64_t channel_tiles = c_out / 32 + (c_out % 32 != 0);
        const int64_t max_index = std::numeric_limits<int64_t>::max();
        TORCH_CHECK(pair_tiles <= max_index / kv, "tile count overflow");
        const int64_t kp_tiles = kv * pair_tiles;
        TORCH_CHECK(kp_tiles <= max_index / channel_tiles, "tile count overflow");
        const int64_t logical_blocks = kp_tiles * channel_tiles;

        hipDeviceProp_t properties;
        const hipError_t property_error =
            hipGetDeviceProperties(&properties, features_fp32.get_device());
        TORCH_CHECK(property_error == hipSuccess,
                    "HIP device query failed: ", hipGetErrorString(property_error));
        const int64_t device_limit = static_cast<int64_t>(properties.maxGridSize[0]);
        const int64_t occupancy_limit =
            std::max<int64_t>(1, static_cast<int64_t>(properties.multiProcessorCount)) * 32;
        const int64_t physical_blocks =
            std::min(logical_blocks, std::min(device_limit, occupancy_limit));
        TORCH_CHECK(physical_blocks > 0, "invalid HIP grid limit");

        const auto stream = c10::cuda::getCurrentCUDAStream(features_fp32.get_device());
        hipLaunchKernelGGL(
            spconv_kernel,
            dim3(static_cast<unsigned int>(physical_blocks), 1, 1),
            dim3(256, 1, 1),
            0,
            stream.stream(),
            features_fp32.data_ptr<float>(),
            weights_fp32.data_ptr<float>(),
            indice_pairs.data_ptr<int32_t>(),
            indice_counts.data_ptr<int32_t>(),
            output.data_ptr<float>(),
            n,
            c_in,
            c_out,
            kv,
            num_act_out,
            pair_count,
            weight_count,
            static_cast<int64_t>(features_fp32.numel()),
            static_cast<int64_t>(output.numel()),
            pair_tiles,
            channel_tiles,
            logical_blocks);

        const hipError_t error = hipGetLastError();
        TORCH_CHECK(
            error == hipSuccess,
            "spconv HIP kernel launch failed: ",
            hipGetErrorString(error));
    }

    return output;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Sparse convolution forward (the gathered form spconv_fprop): a per
    kernel-offset gather-GEMM-scatter forward over the sparse active points,
    driven by an index-pair table (spconv style).

    Semantic definition (out is first initialized to all zeros, then
    accumulated by the formula below):
        for each kernel offset k in [0, kv):
            n_k = indice_num_per_loc[k]
            for each j in [0, n_k):
                in_idx  = indice_pairs[0, k, j]      # input row index in [0, n)
                out_idx = indice_pairs[1, k, j]      # output row index in [0, num_act_out)
                out[out_idx, :] += features[in_idx, :] @ W[:, :, k].T
    i.e. for each index pair, gather the input row and matrix-multiply it with
    the weight matrix of offset k ((n_k, c_in) @ (c_in, c_out)), then
    scatter-accumulate by the output row index into out. The same output row may
    be hit by any number of index pairs (duplicates are allowed within the same
    k), and all of them accumulate with +=.

    The filters layout mapping (must be respected; it comes from the sample's
    as_strided rearrangement): let F be the contiguous (c_out, c_in, kv) tensor
    of the input; the library interprets its storage with strides
    (c_in*kv, 1, c_in), and the mathematical weight W and F satisfy:
        W[o, i, k] = F.reshape(c_out, kv, c_in)[o, k, i]
    which is equivalent to W = F.reshape(c_out, kv, c_in).permute(0, 2, 1)
    (still shaped (c_out, c_in, kv), a pure reinterpretation view for
    contiguous input); the weight matrix of kernel offset k is W[:, :, k],
    shaped (c_out, c_in).

    Boundary behaviour: kernel offsets with n_k = 0 are skipped entirely; when
    all n_k = 0, out stays all-zero; kv = 1 degenerates to a single-offset
    gather-scatter; num_act_out and n are independent of each other (either may
    be the larger one). Index-pair table entries with j >= n_k are padding
    garbage (they may hold any value, including duplicated valid row indices)
    and must be masked out according to indice_num_per_loc -- they must never be
    read into the computation.

    Input/output specification:
        features           float32 / float16 / bfloat16 (n, c_in), contiguous
        filters            same dtype as features (c_out, c_in, kv), contiguous
        indice_pairs       int32 (2, kv, n), contiguous
        indice_num_per_loc int32 (kv,), contiguous
        num_act_out        0-dim integer tensor (the online evaluator casts all
                           input tensors to fp32: integer indices are exact up
                           to 2^24 and are recovered with int(); the shape
                           domain of this task guarantees indices <= 2^24)
        out                a single tensor, same dtype as features
                           (num_act_out, c_out). This operator is inherently
                           single-output, with no multi-output packing segments.
    Dimension domain: n, c_in, c_out, kv, num_act_out >= 1, non-powers-of-two
    allowed; indice_num_per_loc[k] in [0, n]. Input values are ordinary randn
    magnitude (no inf/NaN).

    Implementation constraints (violations are scored as failures):
        - The core computation (gathering by index pair, the matrix
          multiplication with W[:, :, k], the scatter accumulation by output row
          index) must be done with a HIP kernel inside the submitted file; ATen
          is only allowed for non-core operations such as dtype recovery / shape
          cleanup.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate in float32 throughout (fp16/bf16 inputs are first cast
          losslessly to fp32), then cast the result back to the dtype of
          features; padding table entries must not take part in the computation
          (including out-of-bounds reads).
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.sparse / torch.sparse_coo_tensor /
    torch.sparse_csr_tensor / torch.sparse_csc_tensor / torch.sparse_mm /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear / index_add_ /
    torch.index_add / index_put / torch.index_put / scatter_add_ /
    .scatter_( / torch.scatter / segment_reduce / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, features, filters, indice_pairs, indice_num_per_loc, num_act_out):
        # <<<IMPROVE:forward_stmt_1>>>
        num_act_out = int(num_act_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        c_out, c_in, kv = filters.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        dt = features.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        xf = features.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        wf = filters.to(torch.float32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pairs = indice_pairs.to(torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        counts = indice_num_per_loc.to(torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = _pyramidkernel_get_extension().spconv_forward(
            xf, wf, pairs, counts, num_act_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out.to(dt)
        # <<<END_IMPROVE>>>
