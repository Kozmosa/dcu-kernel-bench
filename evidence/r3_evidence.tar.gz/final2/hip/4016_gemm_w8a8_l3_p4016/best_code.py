import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4016_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

torch::Tensor gemm_w8a8(
    torch::Tensor aq,
    torch::Tensor bq,
    torch::Tensor a_scale,
    torch::Tensor b_scale,
    int64_t M,
    int64_t N,
    int64_t K,
    bool output_bf16);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("gemm_w8a8", &gemm_w8a8, "int8 block-scaled GEMM");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <cmath>

namespace {

constexpr int64_t BM = 64;
constexpr int64_t BN = 64;
constexpr int64_t GROUP = 128;
constexpr int64_t KTILE = 64;

template <typename out_t>
__global__ void gemm_w8a8_kernel(
    const int8_t* __restrict__ aq,
    const int8_t* __restrict__ bq,
    const float* __restrict__ a_scale,
    const float* __restrict__ b_scale,
    out_t* __restrict__ out,
    int64_t M,
    int64_t N,
    int64_t K,
    int64_t groups_k) {
    __shared__ float a_tile[KTILE][BM + 1];
    __shared__ float b_tile[KTILE][BN + 1];

    const int tx = static_cast<int>(threadIdx.x);
    const int ty = static_cast<int>(threadIdx.y);
    const int64_t tid = static_cast<int64_t>(ty) * 16 + static_cast<int64_t>(tx);
    const int64_t block_m = static_cast<int64_t>(blockIdx.y) * BM;
    const int64_t block_n = static_cast<int64_t>(blockIdx.x) * BN;

    float result[4][4] = {};

    for (int64_t g = 0; g < groups_k; ++g) {
        const int64_t group_start = g * GROUP;

        for (int64_t tile = 0; tile < GROUP / KTILE; ++tile) {
            const int64_t k_base = group_start + tile * KTILE;

            for (int64_t load = tid; load < BM * KTILE; load += 256) {
                const int64_t row = load / KTILE;
                const int64_t col = load % KTILE;
                const int64_t global_m = block_m + row;
                const int64_t global_k = k_base + col;
                float value = 0.0f;
                if (global_m < M && global_k < K) {
                    const int64_t aq_offset = global_m * K + global_k;
                    const int64_t scale_offset = global_m * groups_k + g;
                    value = static_cast<float>(aq[aq_offset]) *
                            a_scale[scale_offset];
                }
                a_tile[col][row] = value;
            }

            for (int64_t load = tid; load < BN * KTILE; load += 256) {
                const int64_t row = load / KTILE;
                const int64_t col = load % KTILE;
                const int64_t global_n = block_n + row;
                const int64_t global_k = k_base + col;
                float value = 0.0f;
                if (global_n < N && global_k < K) {
                    const int64_t bq_offset = global_n * K + global_k;
                    const int64_t scale_offset =
                        (global_n / GROUP) * groups_k + g;
                    value = static_cast<float>(bq[bq_offset]) *
                            b_scale[scale_offset];
                }
                b_tile[col][row] = value;
            }

            __syncthreads();

            #pragma unroll
            for (int k = 0; k < static_cast<int>(KTILE); ++k) {
                if (k_base + static_cast<int64_t>(k) < K) {
                    float av[4];
                    float bv[4];

                    #pragma unroll
                    for (int i = 0; i < 4; ++i) {
                        av[i] = a_tile[k][ty + 16 * i];
                        bv[i] = b_tile[k][tx + 16 * i];
                    }

                    #pragma unroll
                    for (int i = 0; i < 4; ++i) {
                        #pragma unroll
                        for (int j = 0; j < 4; ++j) {
                            result[i][j] = fmaf(av[i], bv[j], result[i][j]);
                        }
                    }
                }
            }

            __syncthreads();
        }
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const int64_t m = block_m + static_cast<int64_t>(ty) + 16 * i;
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int64_t n = block_n + static_cast<int64_t>(tx) + 16 * j;
            if (m < M && n < N) {
                out[m * N + n] = static_cast<out_t>(result[i][j]);
            }
        }
    }
}

}  // namespace

torch::Tensor gemm_w8a8(
    torch::Tensor aq,
    torch::Tensor bq,
    torch::Tensor a_scale,
    torch::Tensor b_scale,
    int64_t M,
    int64_t N,
    int64_t K,
    bool output_bf16) {
    TORCH_CHECK(aq.is_cuda(), "aq must be a CUDA/HIP tensor");
    TORCH_CHECK(bq.is_cuda(), "bq must be a CUDA/HIP tensor");
    TORCH_CHECK(a_scale.is_cuda(), "a_scale must be a CUDA/HIP tensor");
    TORCH_CHECK(b_scale.is_cuda(), "b_scale must be a CUDA/HIP tensor");
    TORCH_CHECK(aq.device() == bq.device() &&
                aq.device() == a_scale.device() &&
                aq.device() == b_scale.device(),
                "inputs must be on the same device");

    const c10::cuda::CUDAGuard device_guard(aq.device());

    TORCH_CHECK(M > 0 && N > 0 && K > 0,
                "matrix dimensions must be positive");
    TORCH_CHECK(aq.dim() == 2 && bq.dim() == 2,
                "aq and bq must be 2D");
    TORCH_CHECK(aq.size(0) == M && aq.size(1) == K,
                "aq shape mismatch");
    TORCH_CHECK(bq.size(0) == N && bq.size(1) == K,
                "bq shape mismatch");
    TORCH_CHECK(aq.scalar_type() == torch::kInt8,
                "aq must be int8");
    TORCH_CHECK(bq.scalar_type() == torch::kInt8,
                "bq must be int8");
    TORCH_CHECK(a_scale.scalar_type() == torch::kFloat32,
                "a_scale must be float32");
    TORCH_CHECK(b_scale.scalar_type() == torch::kFloat32,
                "b_scale must be float32");

    const int64_t groups_k = (K + GROUP - 1) / GROUP;
    const int64_t groups_n = (N + GROUP - 1) / GROUP;

    TORCH_CHECK(a_scale.dim() == 2 &&
                a_scale.size(0) == M &&
                a_scale.size(1) == groups_k,
                "a_scale shape mismatch");
    TORCH_CHECK(b_scale.dim() == 2 &&
                b_scale.size(0) == groups_n &&
                b_scale.size(1) == groups_k,
                "b_scale shape mismatch");

    aq = aq.contiguous();
    bq = bq.contiguous();
    a_scale = a_scale.contiguous();
    b_scale = b_scale.contiguous();

    auto output_options = aq.options().dtype(
        output_bf16 ? torch::kBFloat16 : torch::kFloat16);
    torch::Tensor out = torch::empty({M, N}, output_options);

    const int64_t grid_x = (N + BN - 1) / BN;
    const int64_t grid_y = (M + BM - 1) / BM;

    hipDeviceProp_t properties;
    hipError_t properties_error =
        hipGetDeviceProperties(&properties, aq.get_device());
    TORCH_CHECK(properties_error == hipSuccess,
                "HIP device query failed: ",
                hipGetErrorString(properties_error));

    TORCH_CHECK(
        grid_x <= static_cast<int64_t>(properties.maxGridSize[0]) &&
        grid_y <= static_cast<int64_t>(properties.maxGridSize[1]),
        "matrix dimensions exceed launch limits");
    TORCH_CHECK(
        properties.maxThreadsPerBlock >= 256 &&
        properties.maxThreadsDim[0] >= 16 &&
        properties.maxThreadsDim[1] >= 16 &&
        properties.sharedMemPerBlock >=
            static_cast<size_t>(KTILE * (BM + BN + 2) * sizeof(float)),
        "device cannot support the GEMM tile resources");

    const dim3 block(16, 16);
    const dim3 grid(
        static_cast<unsigned int>(grid_x),
        static_cast<unsigned int>(grid_y));
    const auto stream = at::cuda::getCurrentCUDAStream();

    if (output_bf16) {
        gemm_w8a8_kernel<c10::BFloat16><<<grid, block, 0, stream>>>(
            aq.data_ptr<int8_t>(),
            bq.data_ptr<int8_t>(),
            a_scale.data_ptr<float>(),
            b_scale.data_ptr<float>(),
            out.data_ptr<c10::BFloat16>(),
            M, N, K, groups_k);
    } else {
        gemm_w8a8_kernel<c10::Half><<<grid, block, 0, stream>>>(
            aq.data_ptr<int8_t>(),
            bq.data_ptr<int8_t>(),
            a_scale.data_ptr<float>(),
            b_scale.data_ptr<float>(),
            out.data_ptr<c10::Half>(),
            M, N, K, groups_k);
    }

    hipError_t launch_error = hipGetLastError();
    TORCH_CHECK(
        launch_error == hipSuccess,
        "HIP kernel launch failed: ",
        hipGetErrorString(launch_error));

    hipError_t sync_error = hipDeviceSynchronize();
    TORCH_CHECK(
        sync_error == hipSuccess,
        "HIP kernel execution failed: ",
        hipGetErrorString(sync_error));

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    int8 block-quantized GEMM (quantized activations x quantized weights,
    dequantized with block scales).

    Mathematical definition: given the int8 activation code words A (M,K), the
    int8 weight code words B (N,K), the activation per-token-group scale
    As (M, ceil(K/128)) and the weight 128x128 block scale
    Bs (ceil(N/128), ceil(K/128)) (all float32), dequantize first and then do
    the matrix multiply:
      Af[m,k] = A[m,k] * As[m, floor(k/128)]
      Bf[n,k] = B[n,k] * Bs[floor(n/128), floor(k/128)]
      out[m,n] = sum_k Af[m,k] * Bf[n,k]    (float32 accumulation, i.e. Af @ Bf^T)
    The equivalent compute order for block quantization: take an int8 dot
    product per 128-element group along K first (exactly accumulable in int32),
    then multiply by that group's As[m,g] * Bs[n_blk,g] and sum in float32 --
    equal to the expression above within float32 precision. The output is cast
    to the out_dtype passed to __init__.
    Boundary behaviour: when K or N is not divisible by 128 the floor index
    simply extends naturally -- a tail group/block covers only the valid
    elements (out-of-range elements do not take part in the accumulation), and
    the group counts of As/Bs are given by ceil(.../128).

    Input/output specification:
      aq      int8    (M, K)                 activation code words, row-major
      bq      int8    (N, K)                 weight code words, row-major (output channels on rows)
      a_scale float32 (M, ceil(K/128))       per-token scale, one group per 128 elements
      b_scale float32 (ceil(N/128), ceil(K/128))   weight 128x128 block scale
      out     out_dtype (M, N)              bfloat16 / float16
      M/N/K >= 1, all allow non-powers of two and a tail not aligned to 128.

    Implementation constraints (violations are scored as failures):
      - The core computation (int8 GEMM accumulation and the scale multiply)
        must be completed inside the submitted file, and calling library-level
        matrix-multiply shortcuts such as torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / torch._int_mm / F.linear /
        functional.linear, or the other entries on the task set's static-audit
        forbidden list, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation (int8 products can be
        accumulated exactly in int32 first, then converted to float32); the
        output is cast to out_dtype.
      - The evaluator casts every input to fp32 before calling forward; the
        int8 code-word range [-128,127] and the fp32 scales are both exactly
        representable, so .to(torch.int8) / .to(torch.float32) at the entry
        point recover them losslessly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: block shape fixed at [128,128], A is 2D (M,K), no bias, no
    splitK; the output is bfloat16 / float16.
    """
    def __init__(self, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.out_dtype = getattr(torch, out_dtype)
        self.block_n = 128
        self.block_k = 128
        # <<<END_IMPROVE>>>

    def forward(self, aq, bq, a_scale, b_scale):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        aq = aq.to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        bq = bq.to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        a_scale = a_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        b_scale = b_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = aq.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        N = bq.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert K == bq.shape[1], "the K dimension of aq and bq must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        a = aq
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        b_exp = b_scale
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        b = bq
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = _pyramidkernel_get_extension().gemm_w8a8(
            aq, bq, a_scale, b_scale,
            int(M), int(N), int(K),
            self.out_dtype == torch.bfloat16
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out.to(self.out_dtype)
        # <<<END_IMPROVE>>>
