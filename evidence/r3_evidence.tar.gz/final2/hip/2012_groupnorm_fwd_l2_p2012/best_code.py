import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2012_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

namespace pyramidkernel {
torch::Tensor groupnorm_fwd_cuda(
    const torch::Tensor& x,
    const torch::Tensor& scale,
    const torch::Tensor& bias,
    int64_t groups,
    double eps,
    bool swish);
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("groupnorm_fwd_cuda", &pyramidkernel::groupnorm_fwd_cuda,
          "GroupNorm forward (HIP)");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cmath>
#include <cstdint>
#include <limits>

namespace pyramidkernel {

template <typename scalar_t>
__global__ void fused_groupnorm_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ scale,
    const scalar_t* __restrict__ bias,
    float* __restrict__ out,
    int64_t numel,
    int64_t total_groups,
    int64_t group_size,
    int64_t channels,
    int64_t hw,
    float eps,
    bool swish) {
    __shared__ float scratch[256];
    __shared__ float mean_shared;
    __shared__ float inv_shared;
    const int64_t tid = static_cast<int64_t>(threadIdx.x);

    for (int64_t group_id = static_cast<int64_t>(blockIdx.x);
         group_id < total_groups;
         group_id += static_cast<int64_t>(gridDim.x)) {
        const int64_t base = group_id * group_size;
        float sum = 0.0f;
        for (int64_t i = tid; i < group_size; i += 256) {
            const int64_t idx = base + i;
            if (idx < numel)
                sum += static_cast<float>(x[idx]);
        }
        scratch[tid] = sum;
        __syncthreads();
        for (int64_t stride = 128; stride > 0; stride >>= 1) {
            if (tid < stride)
                scratch[tid] += scratch[tid + stride];
            __syncthreads();
        }
        if (tid == 0)
            mean_shared = scratch[0] / static_cast<float>(group_size);
        __syncthreads();
        const float mu = mean_shared;

        float sq = 0.0f;
        for (int64_t i = tid; i < group_size; i += 256) {
            const int64_t idx = base + i;
            if (idx < numel) {
                const float d = static_cast<float>(x[idx]) - mu;
                sq += d * d;
            }
        }
        scratch[tid] = sq;
        __syncthreads();
        for (int64_t stride = 128; stride > 0; stride >>= 1) {
            if (tid < stride)
                scratch[tid] += scratch[tid + stride];
            __syncthreads();
        }
        if (tid == 0) {
            const float variance = scratch[0] / static_cast<float>(group_size);
            inv_shared = 1.0f / sqrtf(variance + eps);
            out[numel + group_id] = mu;
            out[numel + total_groups + group_id] = inv_shared;
        }
        __syncthreads();
        const float inv = inv_shared;

        for (int64_t i = tid; i < group_size; i += 256) {
            const int64_t idx = base + i;
            const int64_t channel = (idx / hw) % channels;
            if (idx < numel && channel < channels) {
                const float v = static_cast<float>(x[idx]);
                const float s = static_cast<float>(scale[channel]);
                const float b = static_cast<float>(bias[channel]);
                const float normalized = (v - mu) * inv;
                // Separate rounding matches the float32 affine expression.
                const float z = __fmul_rn(normalized, s) + b;
                out[idx] = swish ? z / (1.0f + expf(-z)) : z;
            }
        }
        __syncthreads();
    }
}

struct Moments {
    float mean;
    float m2;
    int64_t count;
};

__device__ __forceinline__ Moments merge_moments(Moments a, Moments b) {
    if (b.count == 0) return a;
    if (a.count == 0) return b;
    const int64_t count = a.count + b.count;
    const float delta = b.mean - a.mean;
    const float ratio = static_cast<float>(b.count) / static_cast<float>(count);
    Moments result;
    result.mean = a.mean + delta * ratio;
    result.m2 = a.m2 + b.m2 +
        delta * delta * (static_cast<float>(a.count) * ratio);
    result.count = count;
    return result;
}

__device__ __forceinline__ Moments reduce_moments(
    Moments a, Moments* scratch, int64_t tid) {
    scratch[tid] = a;
    __syncthreads();
    for (int64_t stride = 128; stride > 0; stride >>= 1) {
        if (tid < stride)
            scratch[tid] = merge_moments(scratch[tid], scratch[tid + stride]);
        __syncthreads();
    }
    return scratch[0];
}

template <typename scalar_t>
__global__ void tile_moments_kernel(
    const scalar_t* __restrict__ x,
    float* __restrict__ partial,
    int64_t numel,
    int64_t group_size,
    int64_t tiles_per_group,
    int64_t total_tiles) {
    __shared__ float scratch[256];
    __shared__ float mean_shared;
    const int64_t tid = static_cast<int64_t>(threadIdx.x);
    for (int64_t record = static_cast<int64_t>(blockIdx.x);
         record < total_tiles;
         record += static_cast<int64_t>(gridDim.x)) {
        const int64_t group = record / tiles_per_group;
        const int64_t tile = record % tiles_per_group;
        const int64_t start = tile * 4096;
        const int64_t remaining = group_size - start;
        const int64_t count = remaining < 4096 ? remaining : 4096;
        const int64_t base = group * group_size + start;
        float values[16];
        float sum = 0.0f;
        #pragma unroll
        for (int64_t k = 0; k < 16; ++k) {
            const int64_t i = tid + k * 256;
            float value = 0.0f;
            if (i < count && base + i < numel) {
                value = static_cast<float>(x[base + i]);
                sum += value;
            }
            values[k] = value;
        }
        scratch[tid] = sum;
        __syncthreads();
        for (int64_t stride = 128; stride > 0; stride >>= 1) {
            if (tid < stride)
                scratch[tid] += scratch[tid + stride];
            __syncthreads();
        }
        if (tid == 0)
            mean_shared = scratch[0] / static_cast<float>(count);
        __syncthreads();
        const float tile_mean = mean_shared;

        float sq = 0.0f;
        #pragma unroll
        for (int64_t k = 0; k < 16; ++k) {
            const int64_t i = tid + k * 256;
            if (i < count && base + i < numel) {
                const float d = values[k] - tile_mean;
                sq += d * d;
            }
        }
        scratch[tid] = sq;
        __syncthreads();
        for (int64_t stride = 128; stride > 0; stride >>= 1) {
            if (tid < stride)
                scratch[tid] += scratch[tid + stride];
            __syncthreads();
        }
        if (tid == 0) {
            partial[record] = tile_mean;
            partial[total_tiles + record] = scratch[0];
        }
        __syncthreads();
    }
}

__global__ void merge_tiles_kernel(
    const float* __restrict__ partial,
    float* __restrict__ out,
    int64_t numel,
    int64_t total_groups,
    int64_t group_size,
    int64_t tiles_per_group,
    int64_t total_tiles,
    float eps) {
    __shared__ Moments scratch[256];
    const int64_t tid = static_cast<int64_t>(threadIdx.x);
    for (int64_t group = static_cast<int64_t>(blockIdx.x);
         group < total_groups;
         group += static_cast<int64_t>(gridDim.x)) {
        Moments a = {0.0f, 0.0f, 0};
        for (int64_t tile = tid; tile < tiles_per_group; tile += 256) {
            const int64_t record = group * tiles_per_group + tile;
            const int64_t remaining = group_size - tile * 4096;
            const int64_t count = remaining < 4096 ? remaining : 4096;
            if (record < total_tiles) {
                a = merge_moments(a, Moments{
                    partial[record], partial[total_tiles + record], count});
            }
        }
        const Moments result = reduce_moments(a, scratch, tid);
        if (tid == 0) {
            out[numel + group] = result.mean;
            out[numel + total_groups + group] =
                1.0f / sqrtf(result.m2 / static_cast<float>(group_size) + eps);
        }
        __syncthreads();
    }
}

template <typename scalar_t>
__global__ void groupnorm_output_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ scale,
    const scalar_t* __restrict__ bias,
    float* __restrict__ out,
    int64_t numel,
    int64_t total_groups,
    int64_t group_size,
    int64_t channels,
    int64_t hw,
    bool swish) {
    const int64_t step = static_cast<int64_t>(gridDim.x) * blockDim.x;
    for (int64_t idx = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
         idx < numel; idx += step) {
        const int64_t group = idx / group_size;
        const int64_t channel = (idx / hw) % channels;
        if (group < total_groups && channel < channels) {
            const float mu = out[numel + group];
            const float inv = out[numel + total_groups + group];
            const float normalized = (static_cast<float>(x[idx]) - mu) * inv;
            const float z = __fmul_rn(normalized, static_cast<float>(scale[channel]))
                          + static_cast<float>(bias[channel]);
            out[idx] = swish ? z / (1.0f + expf(-z)) : z;
        }
    }
}

static inline void check_hip(const char* where) {
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, where, ": ", hipGetErrorString(err));
}

static inline dim3 bounded_grid(int64_t blocks) {
    return dim3(static_cast<unsigned int>(blocks < 65535 ? blocks : 65535));
}

torch::Tensor groupnorm_fwd_cuda(
    const torch::Tensor& x,
    const torch::Tensor& scale,
    const torch::Tensor& bias,
    int64_t groups,
    double eps,
    bool swish) {
    TORCH_CHECK(x.is_cuda() && scale.is_cuda() && bias.is_cuda(),
                "inputs must be HIP/CUDA tensors");
    TORCH_CHECK(x.device() == scale.device() && x.device() == bias.device(),
                "inputs must be on the same device");
    TORCH_CHECK(x.dim() == 4, "x must be NCHW");
    TORCH_CHECK(scale.dim() == 1 && bias.dim() == 1,
                "scale and bias must be 1D");
    TORCH_CHECK(x.is_contiguous() && scale.is_contiguous() && bias.is_contiguous(),
                "inputs must be contiguous");
    TORCH_CHECK(x.scalar_type() == scale.scalar_type() &&
                x.scalar_type() == bias.scalar_type(),
                "inputs must have matching dtypes");
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 ||
                x.scalar_type() == torch::kFloat16 ||
                x.scalar_type() == torch::kBFloat16,
                "unsupported input dtype");

    const int64_t n = x.size(0);
    const int64_t c = x.size(1);
    const int64_t h = x.size(2);
    const int64_t w = x.size(3);
    TORCH_CHECK(n > 0 && c > 0 && h > 0 && w > 0,
                "all input dimensions must be positive");
    TORCH_CHECK(groups > 0 && groups <= c && c % groups == 0,
                "groups must divide C and be between 1 and C");
    TORCH_CHECK(scale.size(0) == c && bias.size(0) == c,
                "scale and bias must have C elements");
    TORCH_CHECK(eps > 0.0, "eps must be positive");

    const c10::cuda::CUDAGuard device_guard(x.device());
    const int64_t numel = x.numel();
    const int64_t hw = h * w;
    const int64_t total_groups = n * groups;
    const int64_t group_size = (c / groups) * hw;
    TORCH_CHECK(total_groups <= (std::numeric_limits<int64_t>::max() - numel) / 2,
                "packed output size exceeds int64 range");
    const int64_t out_size = numel + 2 * total_groups;
    auto out = torch::empty({out_size}, x.options().dtype(torch::kFloat32));

    const dim3 grid = bounded_grid(total_groups);
    const dim3 block(256);
    const auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
    const bool tiled = group_size > 16384;
    int64_t tiles_per_group = 0;
    int64_t total_tiles = 0;
    torch::Tensor partial;
    if (tiled) {
        tiles_per_group = (group_size - 1) / 4096 + 1;
        TORCH_CHECK(total_groups <= std::numeric_limits<int64_t>::max() / tiles_per_group,
                    "tile count exceeds int64 range");
        total_tiles = total_groups * tiles_per_group;
        TORCH_CHECK(total_tiles <= std::numeric_limits<int64_t>::max() /
                    (2 * static_cast<int64_t>(sizeof(float))),
                    "tile storage exceeds int64 range");
        partial = torch::empty({2 * total_tiles}, x.options().dtype(torch::kFloat32));
    }

    AT_DISPATCH_FLOATING_TYPES_AND2(
        torch::kFloat16, torch::kBFloat16, x.scalar_type(),
        "fused_groupnorm_hip", [&] {
            if (tiled) {
                hipLaunchKernelGGL(
                    (tile_moments_kernel<scalar_t>),
                    bounded_grid(total_tiles), block, 0, stream.stream(),
                    x.data_ptr<scalar_t>(), partial.data_ptr<float>(),
                    numel, group_size, tiles_per_group, total_tiles);
                check_hip("groupnorm partial moments kernel");
                hipLaunchKernelGGL(
                    merge_tiles_kernel,
                    grid, block, 0, stream.stream(),
                    partial.data_ptr<float>(), out.data_ptr<float>(),
                    numel, total_groups, group_size, tiles_per_group,
                    total_tiles, static_cast<float>(eps));
                check_hip("groupnorm merge moments kernel");
                hipLaunchKernelGGL(
                    (groupnorm_output_kernel<scalar_t>),
                    bounded_grid((numel - 1) / 256 + 1), block, 0, stream.stream(),
                    x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(),
                    bias.data_ptr<scalar_t>(), out.data_ptr<float>(),
                    numel, total_groups, group_size, c, hw, swish);
                check_hip("groupnorm output kernel");
            } else {
                hipLaunchKernelGGL(
                    (fused_groupnorm_kernel<scalar_t>),
                    grid, block, 0, stream.stream(),
                    x.data_ptr<scalar_t>(),
                    scale.data_ptr<scalar_t>(),
                    bias.data_ptr<scalar_t>(),
                    out.data_ptr<float>(),
                    numel, total_groups, group_size, c, hw,
                    static_cast<float>(eps), swish);
                check_hip("fused groupnorm kernel");
            }
        });
    return out;
}

} // namespace pyramidkernel
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    GroupNorm forward family: standard GroupNorm and the GroupNorm+Swish fusion.

    The input is x (N, C, H, W), NCHW contiguous; scale / bias are the (C,)
    per-channel affine parameters; the __init__ argument groups = G (dividing C,
    1 <= G <= C) splits the channels into G groups, with channel c belonging to
    group c // (C//G); eps defaults to 1e-5. The normalization statistics are
    computed per (n, g) group: x[n] is split along the channel dimension into G
    segments (group g occupies the channels [g*(C//G), (g+1)*(C//G)), and the number
    of elements in a group is D = (C//G)*H*W), in float32:
        mean_ng     = sum_D x / D                      (biased mean)
        var_ng      = sum_D (x - mean_ng)^2 / D        (biased variance)
        inv_var_ng  = 1 / sqrt(var_ng + eps)
        gn[n,c,h,w] = (x[n,c,h,w] - mean_ng) * inv_var_ng * scale[c] + bias[c]
                      (where the group index is g = c // (C//G))
    The __init__ argument variant selects one of two paths:
        "groupnorm"      : y = gn
        "groupnorm_swish": y = gn * sigmoid(gn) (Swish / SiLU)
    Both variants also emit the per-group statistics mean and inv_var (one entry per
    (n, g), (N, G) layout, float32).

    Boundary behaviour: when the in-group variance is 0 (e.g. D == 1, a single
    element in the group) inv_var = 1/sqrt(eps) (eps guarantees no division by zero)
    and gn = bias; G=1 is full-channel normalization and G=C is per-channel
    normalization, both of which are legal; N/C/H/W are arbitrary (including 1,
    non-powers of two and unaligned), a large in-group D needs a tiling (block-wise)
    reduction, and out-of-range elements at the row tail must not take part in the
    statistics.

    Single-tensor output protocol (forward must return a single tensor; the evaluator
    compares a single output):
    Returns a one-dimensional float32 packed tensor of length N*C*H*W + 2*N*G, with
    three segments packed back to back in order (half-open intervals; each segment is
    float32, reshaped with reshape(-1) and torch.cat'ed):
        [0,               N*C*H*W)           y
        [N*C*H*W,         N*C*H*W + N*G)     mean    ((N, G) flattened row-major)
        [N*C*H*W + N*G,   N*C*H*W + 2*N*G)   inv_var ((N, G) flattened row-major)
    The output is always float32: the y segment is not quantized to a lower
    precision; fp16/bf16 is only the input quantization level (the input is provided
    in that dtype and then cast to float32 to take part in the whole computation).

    Input/output specification:
        x      float32 / float16 / bfloat16 (N, C, H, W), contiguous, N/C/H/W >= 1
        scale  same dtype as x, (C,), contiguous
        bias   same dtype as x, (C,), contiguous
        out    one-dimensional float32 of length N*C*H*W + 2*N*G (the three-segment
               packing protocol above)
        The inputs are the usual randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-group mean / biased var reduction, rsqrt, the
          per-channel affine, and Swish) must be completed inside the submitted file
          with a HIP kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt, the affine and Swish all use float32 intermediates;
          all three output segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "groupnorm", groups: int = 2, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("groupnorm", "groupnorm_swish"), "variant must be one of groupnorm / groupnorm_swish"
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.variant = variant
        self.groups = int(groups)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        n, c, h, w = x.shape
        g = self.groups
        assert 1 <= g <= c and c % g == 0, "groups must divide the number of channels and 1 <= groups <= C"
        return _pyramidkernel_get_extension().groupnorm_fwd_cuda(
            x, scale, bias, int(g), float(self.eps),
            self.variant == "groupnorm_swish"
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        g = self.groups
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        rep = c // g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert 1 <= g <= c and c % g == 0, "groups must divide the number of channels and 1 <= groups <= C"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        xg = xf.reshape(n, g, -1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        mean = xg.mean(dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        var = (xg - mean.unsqueeze(-1)).pow(2).mean(dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        inv_var = torch.rsqrt(var + self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        mean_c = mean.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        inv_c = inv_var.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        sf = scale.to(torch.float32).reshape(1, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        bf = bias.to(torch.float32).reshape(1, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        gn = (xf - mean_c) * inv_c * sf + bf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        y = gn * torch.sigmoid(gn) if self.variant == "groupnorm_swish" else gn
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return torch.cat([y.reshape(-1), mean.reshape(-1), inv_var.reshape(-1)])
        # <<<END_IMPROVE>>>
