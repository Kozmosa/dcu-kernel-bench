import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2004_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

torch::Tensor fused_qk_concat(
    torch::Tensor q_nope,
    torch::Tensor q_pe,
    torch::Tensor k_nope,
    torch::Tensor k_pe,
    torch::Tensor pos,
    torch::Tensor cos,
    torch::Tensor sin,
    bool is_neox,
    bool apply_rope);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_qk_concat", &fused_qk_concat, "Fused QK RoPE concatenation");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template <typename scalar_t>
__global__ void fused_qk_concat_kernel(
    const scalar_t* __restrict__ q_nope,
    const scalar_t* __restrict__ q_pe,
    const scalar_t* __restrict__ k_nope,
    const scalar_t* __restrict__ k_pe,
    const int64_t* __restrict__ pos,
    const scalar_t* __restrict__ cos,
    const scalar_t* __restrict__ sin,
    scalar_t* __restrict__ out,
    int64_t B,
    int64_t QH,
    int64_t KH,
    int64_t D_nope,
    int64_t D_pe,
    int64_t d_freq,
    bool is_neox,
    bool apply_rope,
    int64_t total) {
    const int64_t linear =
        static_cast<int64_t>(blockIdx.x) * static_cast<int64_t>(blockDim.x) +
        static_cast<int64_t>(threadIdx.x);
    if (linear >= total) {
        return;
    }

    const int64_t width = D_nope + D_pe;
    const int64_t out_heads = QH + KH;
    const int64_t row = linear / width;
    const int64_t d = linear - row * width;
    const int64_t b = row / out_heads;
    const int64_t oh = row - b * out_heads;

    if (b >= B || oh >= out_heads || d >= width) {
        return;
    }

    const bool is_q = oh < QH;
    const int64_t source_head = is_q ? oh : oh - QH;
    const int64_t source_heads = is_q ? QH : KH;
    if (source_head >= source_heads) {
        return;
    }

    const int64_t source_row = b * source_heads + source_head;
    const int64_t output_offset = row * width + d;

    if (d < D_nope) {
        const int64_t source_offset = source_row * D_nope + d;
        out[output_offset] = is_q ? q_nope[source_offset] : k_nope[source_offset];
        return;
    }

    const int64_t pe_d = d - D_nope;
    const int64_t source_offset = source_row * D_pe + pe_d;

    if (!apply_rope) {
        out[output_offset] = is_q ? q_pe[source_offset] : k_pe[source_offset];
        return;
    }

    const int64_t p = pos[b];
    int64_t table_d;
    if (d_freq == D_pe) {
        table_d = pe_d;
    } else if (is_neox) {
        table_d = pe_d % (D_pe / 2);
    } else {
        table_d = pe_d / 2;
    }

    const int64_t table_offset = p * d_freq + table_d;
    const float c = static_cast<float>(cos[table_offset]);
    const float s = static_cast<float>(sin[table_offset]);

    const scalar_t* source = is_q ? q_pe : k_pe;
    const float x = static_cast<float>(source[source_offset]);
    float rotated;

    if (is_neox) {
        const int64_t half = D_pe / 2;
        const int64_t rotate_d = pe_d < half ? pe_d + half : pe_d - half;
        const float rotate_x =
            static_cast<float>(source[source_row * D_pe + rotate_d]);
        rotated = pe_d < half ? -rotate_x : rotate_x;
    } else {
        const int64_t rotate_d = (pe_d & 1) ? pe_d - 1 : pe_d + 1;
        const float rotate_x =
            static_cast<float>(source[source_row * D_pe + rotate_d]);
        rotated = (pe_d & 1) ? rotate_x : -rotate_x;
    }

    out[output_offset] = static_cast<scalar_t>(x * c + rotated * s);
}

template <typename scalar_t>
static void launch_fused_qk_concat(
    const torch::Tensor& q_nope,
    const torch::Tensor& q_pe,
    const torch::Tensor& k_nope,
    const torch::Tensor& k_pe,
    const torch::Tensor& pos,
    const torch::Tensor& cos,
    const torch::Tensor& sin,
    torch::Tensor& out,
    int64_t B,
    int64_t QH,
    int64_t KH,
    int64_t D_nope,
    int64_t D_pe,
    int64_t d_freq,
    bool is_neox,
    bool apply_rope) {
    const int64_t total = B * (QH + KH) * (D_nope + D_pe);
    constexpr int threads = 256;
    const int64_t blocks64 = (total + threads - 1) / threads;
    TORCH_CHECK(
        blocks64 <= static_cast<int64_t>(0x7fffffff),
        "fused_qk_concat launch grid is too large");

    hipLaunchKernelGGL(
        (fused_qk_concat_kernel<scalar_t>),
        dim3(static_cast<unsigned int>(blocks64)),
        dim3(threads),
        0,
        0,
        q_nope.data_ptr<scalar_t>(),
        q_pe.data_ptr<scalar_t>(),
        k_nope.data_ptr<scalar_t>(),
        k_pe.data_ptr<scalar_t>(),
        pos.data_ptr<int64_t>(),
        cos.data_ptr<scalar_t>(),
        sin.data_ptr<scalar_t>(),
        out.data_ptr<scalar_t>(),
        B,
        QH,
        KH,
        D_nope,
        D_pe,
        d_freq,
        is_neox,
        apply_rope,
        total);

    const hipError_t err = hipGetLastError();
    TORCH_CHECK(
        err == hipSuccess,
        "fused_qk_concat kernel launch failed: ",
        hipGetErrorString(err));
}

torch::Tensor fused_qk_concat(
    torch::Tensor q_nope,
    torch::Tensor q_pe,
    torch::Tensor k_nope,
    torch::Tensor k_pe,
    torch::Tensor pos,
    torch::Tensor cos,
    torch::Tensor sin,
    bool is_neox,
    bool apply_rope) {
    TORCH_CHECK(
        q_nope.is_cuda() && q_pe.is_cuda() && k_nope.is_cuda() &&
        k_pe.is_cuda() && pos.is_cuda() && cos.is_cuda() && sin.is_cuda(),
        "all tensors must be on the accelerator");
    TORCH_CHECK(
        q_nope.is_contiguous() && q_pe.is_contiguous() &&
        k_nope.is_contiguous() && k_pe.is_contiguous() &&
        pos.is_contiguous() && cos.is_contiguous() && sin.is_contiguous(),
        "all tensors must be contiguous");
    TORCH_CHECK(
        q_nope.dim() == 3 && q_pe.dim() == 3 &&
        k_nope.dim() == 3 && k_pe.dim() == 3,
        "data tensors must be rank 3");
    TORCH_CHECK(
        pos.dim() == 1 && cos.dim() == 2 && sin.dim() == 2,
        "pos, cos, and sin have invalid ranks");
    TORCH_CHECK(
        q_nope.scalar_type() == at::kHalf ||
        q_nope.scalar_type() == at::kBFloat16 ||
        q_nope.scalar_type() == at::kFloat,
        "data tensors must use float16, bfloat16, or float32");
    TORCH_CHECK(
        q_pe.scalar_type() == q_nope.scalar_type() &&
        k_nope.scalar_type() == q_nope.scalar_type() &&
        k_pe.scalar_type() == q_nope.scalar_type() &&
        cos.scalar_type() == q_nope.scalar_type() &&
        sin.scalar_type() == q_nope.scalar_type(),
        "all data tensors must have the same dtype");
    TORCH_CHECK(pos.scalar_type() == at::kLong, "pos must have int64 dtype");

    const int64_t B = q_nope.size(0);
    const int64_t QH = q_nope.size(1);
    const int64_t D_nope = q_nope.size(2);
    const int64_t KH = k_nope.size(1);
    const int64_t D_pe = q_pe.size(2);

    TORCH_CHECK(
        q_pe.size(0) == B && k_nope.size(0) == B &&
        k_pe.size(0) == B && pos.size(0) == B,
        "batch dimensions must match");
    TORCH_CHECK(
        q_pe.size(1) == QH && k_pe.size(1) == KH,
        "head dimensions must match");
    TORCH_CHECK(
        k_nope.size(2) == D_nope && k_pe.size(2) == D_pe,
        "feature dimensions must match");
    TORCH_CHECK(KH > 0 && QH % KH == 0, "QH must be a positive multiple of KH");
    TORCH_CHECK(D_pe > 0 && (D_pe % 2) == 0, "D_pe must be positive and even");
    TORCH_CHECK(
        cos.size(0) == sin.size(0) && cos.size(1) == sin.size(1),
        "cos and sin shapes must match");

    const int64_t d_freq = cos.size(1);
    TORCH_CHECK(
        d_freq == D_pe || d_freq == D_pe / 2,
        "cos/sin width must equal D_pe or D_pe/2");

    auto out = torch::empty({B, QH + KH, D_nope + D_pe}, q_nope.options());

    if (q_nope.scalar_type() == at::kHalf) {
        launch_fused_qk_concat<at::Half>(
            q_nope, q_pe, k_nope, k_pe, pos, cos, sin, out,
            B, QH, KH, D_nope, D_pe, d_freq, is_neox, apply_rope);
    } else if (q_nope.scalar_type() == at::kBFloat16) {
        launch_fused_qk_concat<at::BFloat16>(
            q_nope, q_pe, k_nope, k_pe, pos, cos, sin, out,
            B, QH, KH, D_nope, D_pe, d_freq, is_neox, apply_rope);
    } else {
        launch_fused_qk_concat<float>(
            q_nope, q_pe, k_nope, k_pe, pos, cos, sin, out,
            B, QH, KH, D_nope, D_pe, d_freq, is_neox, apply_rope);
    }

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    MLA-style QK preprocessing fused operator: rotary position embedding (RoPE)
    on the pe segment plus nope/pe concatenation.

    (1) Operator semantics (mathematical definition and boundary behaviour):
    The Q side takes q_nope [B, QH, D_nope] and q_pe [B, QH, D_pe]; the K side takes
    k_nope [B, KH, D_nope] and k_pe [B, KH, D_pe]. QH must be an integer multiple of
    KH (GQA; write QH_PER_KH = QH // KH) and D_pe must be even. The output is packed
    into a single tensor out [B, QH + KH, D_nope + D_pe]: along the head dimension
    the first QH rows are the Q result and the last KH rows are the K result (each
    KV head is computed and written back only once, i.e. the GQA deduplicated
    write-back semantics).

    The nope segment is copied verbatim: out[:, :QH, :D_nope] = q_nope,
    out[:, QH:, :D_nope] = k_nope. The pe segment (x means q_pe or k_pe, promoted to
    float32 before the computation):
    - apply_rope=False (pure concatenation mode): out[..., D_nope:] = x copied
      verbatim; pos / cos / sin are ignored;
    - apply_rope=True (rope mode): for each batch b take c = cos[pos[b]] and
      s = sin[pos[b]] (width d_freq; d_freq == D_pe is the full-width table,
      d_freq == D_pe//2 is the first-half reuse table), and expand to width D_pe
      according to the rotation style:
        full width: c~ = c;
        first-half reuse + NEOX: c~ = [c, c] (the whole segment repeated once; both
          halves share the same frequency);
        first-half reuse + GPTJ: c~ = [c0, c0, c1, c1, ...] (every element repeated
          twice back to back).
      rotate_half(x) is defined as:
        NEOX (is_neox=True): rotate_half(x)[i] = -x[i + D_pe//2]
          (i < D_pe//2), = x[i - D_pe//2] (i >= D_pe//2);
        GPTJ (is_neox=False): rotate_half(x)[2j] = -x[2j+1],
          rotate_half(x)[2j+1] = x[2j].
      pe segment output = x * c~ + rotate_half(x) * s~, cast back to the input dtype.
    Boundary behaviour: pos[b] is in [0, max_pos) (out of range is undefined
    behaviour); this operator is a memory-bound preprocessing step and computes no
    attention score; the nope segment and the pe segment in pure concatenation mode
    are verbatim copies and must match bit-for-bit; the whole forward is out-of-place
    and must not overwrite any input in place.

    (2) Input/output specification:
    - q_nope / q_pe / k_nope / k_pe: float16 / bfloat16, contiguous, shapes as above
      (QH == KH * QH_PER_KH, one shared batch for all four tensors);
    - pos: int64, [B], one position index per batch (it is cast to floating point
      under the evaluation precision and restored to integer losslessly at the
      entry);
    - cos / sin: same dtype as the data, [max_pos, d_freq], contiguous, used only
      through the row-style indexing cos[pos[b], d];
    - returns: out [B, QH + KH, D_nope + D_pe] with the same dtype as q_nope;
    - hyper-parameters (__init__): is_neox -- True selects the NEOX rotation style /
      False selects GPTJ; apply_rope -- True rotates the pe segment / False pure
      concatenation.

    (3) Implementation constraints (violations are scored as failures):
    - The core computation (row indexing of cos/sin by position, rotation of the pe
      segment, the nope/pe concatenated write-back, and the K-side deduplication
      under GQA) must be completed inside the submitted file with a self-written
      HIP kernel: a single kernel (one launch) with a single
      read-compute-write pass;
    - The __init__ and forward signatures of ModelNew must not be changed;
    - Use float32 for intermediate computation; cast the output back to the input
      dtype.

    (4) Forbidden list and target hardware:
    - Calling ATen shortcuts such as torch.cat / torch.concat (including the tensor
      method .cat) or index_select to complete this task's computation directly is
      forbidden; the authoritative forbidden list is the task.yaml forbidden list
      (it covers the source operator library and other closed-source acceleration
      libraries; the final static audit does substring matching on the code outside
      docstrings / comments);
    - Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, is_neox: bool = True, apply_rope: bool = True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.is_neox = bool(is_neox)
        self.apply_rope = bool(apply_rope)
        # <<<END_IMPROVE>>>

    def forward(self, q_nope, q_pe, k_nope, k_pe, pos, cos, sin):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().fused_qk_concat(
            q_nope, q_pe, k_nope, k_pe, pos.to(torch.long), cos, sin,
            self.is_neox, self.apply_rope)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        B, QH, D_nope = q_nope.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        KH = k_nope.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        D_pe = q_pe.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        assert q_pe.shape[0] == B and k_nope.shape[0] == k_pe.shape[0] == B
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert q_pe.shape[1] == QH and k_pe.shape[1] == KH
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert k_nope.shape[2] == D_nope and k_pe.shape[2] == D_pe
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert QH % KH == 0
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert D_pe % 2 == 0
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty((B, QH + KH, D_nope + D_pe), dtype=q_nope.dtype, device=q_nope.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out[:, :QH, :D_nope] = q_nope
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        out[:, QH:, :D_nope] = k_nope
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        d_freq = cos.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        assert d_freq in (D_pe, D_pe // 2)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        cos_b = cos.to(torch.float32)[pos]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        sin_b = sin.to(torch.float32)[pos]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        cos_f = (torch.cat((cos_b, cos_b), dim=-1) if self.is_neox else cos_b.repeat_interleave(2, dim=-1)) if d_freq == D_pe // 2 else cos_b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        sin_f = (torch.cat((sin_b, sin_b), dim=-1) if self.is_neox else sin_b.repeat_interleave(2, dim=-1)) if d_freq == D_pe // 2 else sin_b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        cos_f = cos_f.unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        sin_f = sin_f.unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        rotate = (lambda x: torch.cat((-x[..., D_pe // 2:], x[..., : D_pe // 2]), dim=-1)) if self.is_neox else (lambda x: torch.stack((-x[..., 1::2], x[..., ::2]), dim=-1).flatten(-2))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        q32, k32 = q_pe.to(torch.float32), k_pe.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        out[:, :QH, D_nope:] = (q32 * cos_f + rotate(q32) * sin_f).to(q_nope.dtype) if self.apply_rope else q_pe
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        out[:, QH:, D_nope:] = (k32 * cos_f + rotate(k32) * sin_f).to(q_nope.dtype) if self.apply_rope else k_pe
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        return out
        # <<<END_IMPROVE>>>
