import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2007_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor rmsnorm_forward(
    torch::Tensor x,
    torch::Tensor weight,
    torch::Tensor residual,
    double eps,
    bool fused);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("rmsnorm_forward", &rmsnorm_forward, "HIP RMSNorm forward");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <cstdint>
#include <limits>
#include <vector>

template <typename scalar_t, bool FUSED>
__global__ void rmsnorm_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ weight,
    const scalar_t* __restrict__ residual,
    scalar_t* __restrict__ out,
    int64_t m,
    int64_t n,
    int64_t out_stride,
    float eps) {
    __shared__ float partial[4];

    const int tid = static_cast<int>(threadIdx.x);
    const int lane = tid & 63;
    const int wave = tid >> 6;
    const int64_t grid_count = static_cast<int64_t>(gridDim.x);

    for (int64_t row = static_cast<int64_t>(blockIdx.x);
         row < m;
         row += grid_count) {
        const int64_t row_offset = row * n;
        float sum = 0.0f;

        for (int64_t col = static_cast<int64_t>(tid);
             col < n;
             col += static_cast<int64_t>(blockDim.x)) {
            float value = static_cast<float>(x[row_offset + col]);
            if constexpr (FUSED) {
                const float rv = static_cast<float>(residual[row_offset + col]);
                value = static_cast<float>(
                    static_cast<scalar_t>(value + rv));
            }
            sum += value * value;
        }

        for (int offset = 32; offset > 0; offset >>= 1) {
            sum += __shfl_down(sum, offset, 64);
        }

        if (lane == 0) {
            partial[wave] = sum;
        }
        __syncthreads();

        if (tid < 64) {
            float total = tid < 4 ? partial[tid] : 0.0f;
            for (int offset = 32; offset > 0; offset >>= 1) {
                total += __shfl_down(total, offset, 64);
            }
            if (tid == 0) {
                partial[0] = total;
            }
        }
        __syncthreads();

        const float rsigma =
            rsqrtf(partial[0] / static_cast<float>(n) + eps);
        const int64_t output_row_offset = row * out_stride;

        for (int64_t col = static_cast<int64_t>(tid);
             col < n;
             col += static_cast<int64_t>(blockDim.x)) {
            float value = static_cast<float>(x[row_offset + col]);
            scalar_t residual_value{};

            if constexpr (FUSED) {
                const float rv = static_cast<float>(residual[row_offset + col]);
                residual_value = static_cast<scalar_t>(value + rv);
                value = static_cast<float>(residual_value);
            }

            const float scaled =
                value * rsigma * static_cast<float>(weight[col]);
            out[output_row_offset + col] = static_cast<scalar_t>(scaled);

            if constexpr (FUSED) {
                out[output_row_offset + n + col] = residual_value;
            }
        }
        __syncthreads();
    }
}

template <typename scalar_t, bool FUSED, int ITEMS>
__global__ void rmsnorm_cached_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ weight,
    const scalar_t* __restrict__ residual,
    scalar_t* __restrict__ out,
    int64_t m,
    int64_t n,
    int64_t out_stride,
    float eps) {
    __shared__ float partial[4];

    const int tid = static_cast<int>(threadIdx.x);
    const int lane = tid & 63;
    const int wave = tid >> 6;
    const int64_t grid_count = static_cast<int64_t>(gridDim.x);
    float values[ITEMS];

    for (int64_t row = static_cast<int64_t>(blockIdx.x);
         row < m;
         row += grid_count) {
        const int64_t row_offset = row * n;
        float sum = 0.0f;

        #pragma unroll
        for (int slot = 0; slot < ITEMS; ++slot) {
            const int64_t col =
                static_cast<int64_t>(tid) +
                static_cast<int64_t>(slot) * 256;
            float value = 0.0f;

            if (col < n) {
                value = static_cast<float>(x[row_offset + col]);
                if constexpr (FUSED) {
                    const float rv =
                        static_cast<float>(residual[row_offset + col]);
                    value = static_cast<float>(
                        static_cast<scalar_t>(value + rv));
                }
                sum += value * value;
            }
            values[slot] = value;
        }

        for (int offset = 32; offset > 0; offset >>= 1) {
            sum += __shfl_down(sum, offset, 64);
        }

        if (lane == 0) {
            partial[wave] = sum;
        }
        __syncthreads();

        if (tid < 64) {
            float total = tid < 4 ? partial[tid] : 0.0f;
            for (int offset = 32; offset > 0; offset >>= 1) {
                total += __shfl_down(total, offset, 64);
            }
            if (tid == 0) {
                partial[0] = total;
            }
        }
        __syncthreads();

        const float rsigma =
            rsqrtf(partial[0] / static_cast<float>(n) + eps);
        const int64_t output_row_offset = row * out_stride;

        #pragma unroll
        for (int slot = 0; slot < ITEMS; ++slot) {
            const int64_t col =
                static_cast<int64_t>(tid) +
                static_cast<int64_t>(slot) * 256;
            if (col < n) {
                const float scaled =
                    values[slot] * rsigma *
                    static_cast<float>(weight[col]);
                out[output_row_offset + col] =
                    static_cast<scalar_t>(scaled);

                if constexpr (FUSED) {
                    out[output_row_offset + n + col] =
                        static_cast<scalar_t>(values[slot]);
                }
            }
        }
        __syncthreads();
    }
}

template <typename scalar_t, bool FUSED, int ITEMS>
__global__ void rmsnorm_wave_rows_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ weight,
    const scalar_t* __restrict__ residual,
    scalar_t* __restrict__ out,
    int64_t m,
    int64_t n,
    int64_t out_stride,
    float eps) {
    const int lane = static_cast<int>(threadIdx.x) % 64;
    const int wave = static_cast<int>(threadIdx.x) / 64;
    const int64_t row_step = static_cast<int64_t>(gridDim.x) * 4;

    for (int64_t row = static_cast<int64_t>(blockIdx.x) * 4 +
                       static_cast<int64_t>(wave);
         row < m;
         row += row_step) {
        float values[ITEMS];
        float sum = 0.0f;
        const int64_t input_offset = row * n;
        const int64_t output_offset = row * out_stride;

        #pragma unroll
        for (int slot = 0; slot < ITEMS; ++slot) {
            const int64_t col = static_cast<int64_t>(lane) +
                                static_cast<int64_t>(slot) * 64;
            float value = 0.0f;
            if (row < m && col < n) {
                value = static_cast<float>(x[input_offset + col]);
                if constexpr (FUSED) {
                    const float rv =
                        static_cast<float>(residual[input_offset + col]);
                    value = static_cast<float>(
                        static_cast<scalar_t>(value + rv));
                }
                sum += value * value;
            }
            values[slot] = value;
        }

        #pragma unroll
        for (int offset = 32; offset > 0; offset >>= 1) {
            sum += __shfl_down(sum, offset, 64);
        }
        const float total = __shfl(sum, 0, 64);
        const float rsigma = rsqrtf(total / static_cast<float>(n) + eps);

        #pragma unroll
        for (int slot = 0; slot < ITEMS; ++slot) {
            const int64_t col = static_cast<int64_t>(lane) +
                                static_cast<int64_t>(slot) * 64;
            if (row < m && col < n) {
                out[output_offset + col] = static_cast<scalar_t>(
                    (values[slot] * rsigma) * static_cast<float>(weight[col]));
                if constexpr (FUSED) {
                    out[output_offset + n + col] =
                        static_cast<scalar_t>(values[slot]);
                }
            }
        }
    }
}

template <typename scalar_t, bool FUSED>
static void launch_rmsnorm(
    const torch::Tensor& x,
    const torch::Tensor& weight,
    const torch::Tensor& residual,
    torch::Tensor& out,
    double eps) {
    const int64_t m = x.size(0);
    const int64_t n = x.size(1);
    const int64_t out_stride = out.size(1);

    const int device = x.get_device();
    hipDeviceProp_t prop;
    hipError_t prop_error = hipGetDeviceProperties(&prop, device);
    TORCH_CHECK(
        prop_error == hipSuccess,
        "hipGetDeviceProperties failed: ",
        hipGetErrorString(prop_error));

    int64_t max_grid = static_cast<int64_t>(prop.maxGridSize[0]);
    if (max_grid < 1) {
        max_grid = 1;
    }
    const int64_t grid_count = m < max_grid ? m : max_grid;

    auto stream = at::cuda::getCurrentCUDAStream(device).stream();
    rmsnorm_kernel<scalar_t, FUSED><<<
        static_cast<unsigned int>(grid_count), 256, 0, stream>>>(
        x.data_ptr<scalar_t>(),
        weight.data_ptr<scalar_t>(),
        FUSED ? residual.data_ptr<scalar_t>() : nullptr,
        out.data_ptr<scalar_t>(),
        m,
        n,
        out_stride,
        static_cast<float>(eps));

    hipError_t launch_error = hipGetLastError();
    TORCH_CHECK(
        launch_error == hipSuccess,
        "rmsnorm HIP kernel launch failed: ",
        hipGetErrorString(launch_error));
}

template <typename scalar_t, bool FUSED, int ITEMS>
static void launch_rmsnorm_cached(
    const torch::Tensor& x,
    const torch::Tensor& weight,
    const torch::Tensor& residual,
    torch::Tensor& out,
    double eps) {
    const int64_t m = x.size(0);
    const int64_t n = x.size(1);
    const int64_t out_stride = out.size(1);

    const int device = x.get_device();
    hipDeviceProp_t prop;
    hipError_t prop_error = hipGetDeviceProperties(&prop, device);
    TORCH_CHECK(
        prop_error == hipSuccess,
        "hipGetDeviceProperties failed: ",
        hipGetErrorString(prop_error));

    int64_t max_grid = static_cast<int64_t>(prop.maxGridSize[0]);
    if (max_grid < 1) {
        max_grid = 1;
    }
    const int64_t grid_count = m < max_grid ? m : max_grid;

    auto stream = at::cuda::getCurrentCUDAStream(device).stream();
    rmsnorm_cached_kernel<scalar_t, FUSED, ITEMS><<<
        static_cast<unsigned int>(grid_count), 256, 0, stream>>>(
        x.data_ptr<scalar_t>(),
        weight.data_ptr<scalar_t>(),
        FUSED ? residual.data_ptr<scalar_t>() : nullptr,
        out.data_ptr<scalar_t>(),
        m,
        n,
        out_stride,
        static_cast<float>(eps));

    hipError_t launch_error = hipGetLastError();
    TORCH_CHECK(
        launch_error == hipSuccess,
        "rmsnorm cached HIP kernel launch failed: ",
        hipGetErrorString(launch_error));
}

template <typename scalar_t, bool FUSED, int ITEMS>
static bool launch_rmsnorm_wave_rows(
    const torch::Tensor& x,
    const torch::Tensor& weight,
    const torch::Tensor& residual,
    torch::Tensor& out,
    double eps) {
    const int device = x.get_device();
    hipDeviceProp_t prop;
    const hipError_t prop_error = hipGetDeviceProperties(&prop, device);
    TORCH_CHECK(
        prop_error == hipSuccess,
        "hipGetDeviceProperties failed: ",
        hipGetErrorString(prop_error));
    if (prop.warpSize != 64) {
        return false;
    }

    const int64_t m = x.size(0);
    const int64_t n = x.size(1);
    if (m == 0) {
        return true;
    }
    const int64_t max_grid = static_cast<int64_t>(prop.maxGridSize[0]);
    TORCH_CHECK(max_grid > 0, "Invalid HIP maximum grid size");
    const int64_t row_groups = m / 4 + static_cast<int64_t>(m % 4 != 0);
    const int64_t grid_count = row_groups < max_grid ? row_groups : max_grid;
    auto stream = at::cuda::getCurrentCUDAStream(device).stream();

    rmsnorm_wave_rows_kernel<scalar_t, FUSED, ITEMS><<<
        static_cast<unsigned int>(grid_count), 256, 0, stream>>>(
        x.data_ptr<scalar_t>(),
        weight.data_ptr<scalar_t>(),
        FUSED ? residual.data_ptr<scalar_t>() : nullptr,
        out.data_ptr<scalar_t>(),
        m,
        n,
        out.size(1),
        static_cast<float>(eps));

    const hipError_t launch_error = hipGetLastError();
    TORCH_CHECK(
        launch_error == hipSuccess,
        "rmsnorm wave rows HIP kernel launch failed: ",
        hipGetErrorString(launch_error));
    return true;
}

template <typename scalar_t, bool FUSED>
static void dispatch_rmsnorm(
    const torch::Tensor& x,
    const torch::Tensor& weight,
    const torch::Tensor& residual,
    torch::Tensor& out,
    double eps) {
    const int64_t n = x.size(1);

    if (n <= 256) {
        bool launched;
        if (n <= 64) {
            launched = launch_rmsnorm_wave_rows<scalar_t, FUSED, 1>(
                x, weight, residual, out, eps);
        } else if (n <= 128) {
            launched = launch_rmsnorm_wave_rows<scalar_t, FUSED, 2>(
                x, weight, residual, out, eps);
        } else {
            launched = launch_rmsnorm_wave_rows<scalar_t, FUSED, 4>(
                x, weight, residual, out, eps);
        }
        if (!launched) {
            launch_rmsnorm_cached<scalar_t, FUSED, 1>(
                x, weight, residual, out, eps);
        }
    } else if (n <= 512) {
        launch_rmsnorm_cached<scalar_t, FUSED, 2>(
            x, weight, residual, out, eps);
    } else if (n <= 1024) {
        launch_rmsnorm_cached<scalar_t, FUSED, 4>(
            x, weight, residual, out, eps);
    } else if (n <= 2048) {
        launch_rmsnorm_cached<scalar_t, FUSED, 8>(
            x, weight, residual, out, eps);
    } else if (n <= 4096) {
        launch_rmsnorm_cached<scalar_t, FUSED, 16>(
            x, weight, residual, out, eps);
    } else if (n <= 8192) {
        launch_rmsnorm_cached<scalar_t, FUSED, 32>(
            x, weight, residual, out, eps);
    } else if (n <= 16384) {
        launch_rmsnorm_cached<scalar_t, FUSED, 64>(
            x, weight, residual, out, eps);
    } else {
        launch_rmsnorm<scalar_t, FUSED>(
            x, weight, residual, out, eps);
    }
}

torch::Tensor rmsnorm_forward(
    torch::Tensor x,
    torch::Tensor weight,
    torch::Tensor residual,
    double eps,
    bool fused) {
    TORCH_CHECK(x.is_cuda(), "x must be a CUDA/HIP tensor");
    TORCH_CHECK(x.dim() == 2, "x must be two-dimensional");
    TORCH_CHECK(x.is_contiguous(), "x must be contiguous");

    TORCH_CHECK(weight.is_cuda(), "weight must be a CUDA/HIP tensor");
    TORCH_CHECK(weight.dim() == 1, "weight must be one-dimensional");
    TORCH_CHECK(weight.is_contiguous(), "weight must be contiguous");
    TORCH_CHECK(
        weight.scalar_type() == x.scalar_type(),
        "weight must have the same dtype as x");
    TORCH_CHECK(
        weight.device() == x.device(),
        "weight must be on the same device as x");
    TORCH_CHECK(
        weight.size(0) == x.size(1),
        "weight length must match x's last dimension");

    TORCH_CHECK(
        x.scalar_type() == at::kFloat ||
        x.scalar_type() == at::kHalf ||
        x.scalar_type() == at::kBFloat16,
        "x must have float32, float16, or bfloat16 dtype");

    if (fused) {
        TORCH_CHECK(
            residual.is_cuda(),
            "residual must be a CUDA/HIP tensor");
        TORCH_CHECK(
            residual.dim() == 2,
            "residual must be two-dimensional");
        TORCH_CHECK(
            residual.is_contiguous(),
            "residual must be contiguous");
        TORCH_CHECK(
            residual.sizes() == x.sizes(),
            "residual must have the same shape as x");
        TORCH_CHECK(
            residual.scalar_type() == x.scalar_type(),
            "residual must have the same dtype as x");
        TORCH_CHECK(
            residual.device() == x.device(),
            "residual must be on the same device as x");
    }

    const int64_t m = x.size(0);
    const int64_t n = x.size(1);
    TORCH_CHECK(n > 0, "x's last dimension must be positive");
    TORCH_CHECK(
        n <= std::numeric_limits<int64_t>::max() / (fused ? 2 : 1),
        "output dimension overflow");

    std::vector<int64_t> output_sizes;
    output_sizes.push_back(m);
    output_sizes.push_back(fused ? n * 2 : n);
    torch::Tensor out = torch::empty(output_sizes, x.options());

    c10::cuda::CUDAGuard device_guard(x.device());

    if (fused) {
        AT_DISPATCH_FLOATING_TYPES_AND2(
            at::kHalf,
            at::kBFloat16,
            x.scalar_type(),
            "rmsnorm_fused_add",
            [&] {
                dispatch_rmsnorm<scalar_t, true>(
                    x, weight, residual, out, eps);
            });
    } else {
        AT_DISPATCH_FLOATING_TYPES_AND2(
            at::kHalf,
            at::kBFloat16,
            x.scalar_type(),
            "rmsnorm",
            [&] {
                dispatch_rmsnorm<scalar_t, false>(
                    x, weight, residual, out, eps);
            });
    }

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    RMSNorm forward family: standard RMSNorm and residual-fused
    (fused residual-add) RMSNorm.

    For each row of an (M, N) input, the normalization is computed in float32 as
    defined below:
        mean_sq = sum_i x_i^2 / N
        rsigma  = rsqrt(mean_sq + eps)
        y_i     = x_i * rsigma * w_i
    where w is the per-channel scale vector. The __init__ parameter `variant`
    selects one of two paths:
        "fused_add": first compute residual_out = x + residual in the input dtype
        (the residual stream passes straight through to the output), then apply the
        RMSNorm above to residual_out;
        "rmsnorm"  : apply the RMSNorm directly to x; residual takes no part in the
        computation (its content is arbitrary and may be garbage data).
    forward returns a single tensor out (same dtype as x): with fused_add it is
    (M, 2N) with the first N columns equal to y and the last N columns equal to
    residual_out (the two logical outputs concatenated along the last dimension);
    with rmsnorm it is (M, N), i.e. y.
    Boundary behaviour: for an all-zero row mean_sq = 0, so rsigma = rsqrt(eps)
    (eps guarantees no division by zero); N is arbitrary (including 1,
    non-powers-of-two, sizes not multiple of 16, and large N beyond a single
    block's reduction capacity) and must all be handled correctly with masking / a
    blocked reduction, and out-of-range elements at the row tail must not
    contribute to the sum of squares.

    Input/output specification:
        x        float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        weight   same dtype as x, (N,), contiguous
        residual same dtype as x, (M, N), contiguous (ignored when variant="rmsnorm")
        out      a single tensor, same dtype as x: (M, 2N) with fused_add (first N
                 columns y, last N columns residual_out), (M, N) with rmsnorm (i.e. y)
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (residual add, per-row sum-of-squares reduction,
          rsqrt, element-wise scaling) must be completed with a HIP kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The sum-of-squares accumulation and the normalization run in float32; y is
          cast back to the input dtype; residual_out is added in the input dtype and
          written out as-is.
        - forward returns the single tensor `out` (the evaluator compares a single
          output); with fused_add the residual_out column block must be bit-identical
          to x + residual in the input dtype.

    Forbidden list: aiter / torch.rms_norm / torch.nn.functional.rms_norm /
    torch.nn.RMSNorm / torch.layer_norm / torch.nn.functional.layer_norm /
    torch.nn.LayerNorm / torch.norm / torch.linalg.norm /
    torch.linalg.vector_norm.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "fused_add", eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("rmsnorm", "fused_add"), "variant must be one of rmsnorm / fused_add"
        self.variant = variant
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, residual):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().rmsnorm_forward(
            x, weight, residual, self.eps, self.variant == "fused_add"
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Residual addition is implemented in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # The kernel writes the residual output block directly.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # HIP performs float32 normalization arithmetic.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # Weights are converted within the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # The row reduction is performed in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # HIP writes the scaled output.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return out
        # <<<END_IMPROVE>>>
