import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1021_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Paged attention for the long-context decode phase (single-token query), for both MHA and GQA.

    Operator semantics: the KV cache is paged with a fixed block_size in the
    physical block pool key_cache / value_cache, and each sequence is addressed
    indirectly through the physical block ids in block_tables; the KV length that
    actually takes part in attention for each sequence is given by seq_lens[s]
    (>=1); slots of the physical block pool that nothing references, and slots of
    the tail block beyond seq_lens[s], are garbage data and must not take part in
    the computation. For query head h of sequence s (its KV head is
    h // query_group_size; let bs = block_size, bt = block_tables):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    softmax is a numerically stable reduction over the whole
    [0, seq_lens[s]) interval.

    This task is in the long-context regime: the block-table capacity max_seq_len
    (16384 in the fixed family) far exceeds 8192, so a single sequence's KV can be
    long. How the work is parallelized is **not** a scoring criterion -- any
    implementation that is numerically equivalent to the full softmax within the
    tolerance is acceptable, and the implementation path is free. Core boundary
    cases: partially filled tail blocks (seq_len not a multiple of the block
    size), seq_len exactly a multiple of the block size, wildly different
    sequence lengths within one batch (as short as 1), and tail-block slot
    masking -- positions beyond seq_len must not contribute any probability mass.

    Input/output specification:
      query       [num_seqs, num_q_heads, head_size], fp16/bf16
      key_cache   [num_blocks, num_kv_heads, block_size, head_size], fp16/bf16
      value_cache same as key_cache
      block_tables[num_seqs, max_blocks_per_seq] int32, logical block -> physical block id
      seq_lens    [num_seqs] int32, each sequence's valid KV length, 1 <= seq_lens[s] <= max_seq_len
      output out  [num_seqs, num_q_heads, head_size], dtype matches query

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling external attention operator libraries such as
        scaled_dot_product_attention / sdpa / flash_attn, and torch.matmul /
        torch.bmm / torch.einsum / torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - Unreferenced physical blocks and slots beyond seq_len must not affect the
        output.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding
    window; the long-context regime (max(seq_lens) > 8192).
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        for s in range(B):
            seq_len = int(seq_lens[s])
            num_blocks = (seq_len + bs - 1) // bs
            physical = block_tables[s, :num_blocks]

            # Gather this sequence's K/V through the block table: [num_blocks, H_KV, bs, D] -> [H_KV, seq_len, D]
            k = key_cache[physical].permute(1, 0, 2, 3).reshape(H_KV, num_blocks * bs, D)[:, :seq_len].to(torch.float32)
            v = value_cache[physical].permute(1, 0, 2, 3).reshape(H_KV, num_blocks * bs, D)[:, :seq_len].to(torch.float32)

            # GQA: the K/V of one KV head is replicated to every query head in the group
            if group > 1:
                k = k.repeat_interleave(group, dim=0)   # [H_Q, seq_len, D]
                v = v.repeat_interleave(group, dim=0)

            q = query[s].to(torch.float32) * self.scale      # [H_Q, D]
            logits = torch.einsum("hd,hld->hl", q, k)   # [H_Q, seq_len]
            probs = torch.softmax(logits, dim=-1)
            out[s] = torch.einsum("hl,hld->hd", probs, v).to(query.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
