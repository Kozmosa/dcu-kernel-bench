import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

torch::Tensor fused_mxfp4(torch::Tensor x, int64_t activation);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_mxfp4", &fused_mxfp4, "Fused activation and MXFP4 quantization");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

static __device__ __forceinline__ float activation_value(float u, int activation) {
    if (activation == 0) {
        return u * (1.0f / (1.0f + expf(-u)));
    }
    if (activation == 1) {
        return 0.5f * u * (1.0f + erff(u * 0.7071067811865476f));
    }
    float u2 = u * u;
    float u3 = u2 * u;
    return 0.5f * u * (1.0f + tanhf(
        0.7978845608028654f * (u + 0.044715f * u3)));
}

static __device__ __forceinline__ uint8_t e2m1_code(float value) {
    uint32_t bits;
    memcpy(&bits, &value, sizeof(bits));

    uint32_t sign = bits & 0x80000000u;
    uint32_t exponent = (bits >> 23) & 0xffu;
    uint32_t mantissa = bits & 0x7fffffu;

    uint32_t adjusted = exponent < 127u ? (126u - exponent) : 0u;
    uint32_t mantissa_prime;
    if (exponent < 127u) {
        uint32_t base = 0x400000u | (mantissa >> 1);
        mantissa_prime = adjusted >= 32u ? 0u : (base >> adjusted);
    } else {
        mantissa_prime = mantissa;
    }

    uint32_t exponent_prime = (exponent > 126u ? exponent : 126u) - 126u;
    uint32_t combined = (((exponent_prime << 2) |
                          (mantissa_prime >> 21)) + 1u) >> 1;
    uint32_t magnitude = combined < 0x7u ? combined : 0x7u;
    return static_cast<uint8_t>((sign ? 0x8u : 0u) | magnitude);
}

__global__ void fused_mxfp4_kernel(
    const float* __restrict__ x,
    uint8_t* __restrict__ output,
    int64_t M,
    int64_t N,
    int64_t d,
    int64_t n_blocks,
    int64_t packed_cols,
    int64_t out_cols,
    int activation) {
    int group = static_cast<int>(threadIdx.x) / 32;
    int lane = static_cast<int>(threadIdx.x) % 32;
    int64_t linear_block = static_cast<int64_t>(blockIdx.x) * 2 + group;
    int64_t total_blocks = M * n_blocks;
    bool valid_block = linear_block < total_blocks;

    int64_t row = 0;
    int64_t block = 0;
    if (valid_block) {
        row = linear_block / n_blocks;
        block = linear_block - row * n_blocks;
    }

    __shared__ float maxima[2][32];
    __shared__ float gated_values[2][32];
    __shared__ float quant_scales[2];

    float value = 0.0f;
    if (valid_block) {
        int64_t element = block * 32 + static_cast<int64_t>(lane);
        if (element < d) {
            int64_t base = row * N + element;
            float a = x[base];
            float b = x[base + d];
            value = activation_value(a, activation) * b;
        }
    }
    gated_values[group][lane] = value;
    maxima[group][lane] = fabsf(value);

    __syncthreads();

    if (lane < 16 && maxima[group][lane + 16] > maxima[group][lane])
        maxima[group][lane] = maxima[group][lane + 16];
    __syncthreads();
    if (lane < 8 && maxima[group][lane + 8] > maxima[group][lane])
        maxima[group][lane] = maxima[group][lane + 8];
    __syncthreads();
    if (lane < 4 && maxima[group][lane + 4] > maxima[group][lane])
        maxima[group][lane] = maxima[group][lane + 4];
    __syncthreads();
    if (lane < 2 && maxima[group][lane + 2] > maxima[group][lane])
        maxima[group][lane] = maxima[group][lane + 2];
    __syncthreads();

    if (lane == 0) {
        quant_scales[group] = 1.0f;
        if (valid_block) {
            if (maxima[group][1] > maxima[group][0])
                maxima[group][0] = maxima[group][1];

            uint32_t amax_bits;
            memcpy(&amax_bits, &maxima[group][0], sizeof(amax_bits));
            amax_bits = (amax_bits + 0x200000u) & 0xff800000u;

            float rounded_amax;
            memcpy(&rounded_amax, &amax_bits, sizeof(rounded_amax));

            float scale_float = floorf(log2f(rounded_amax)) - 2.0f;
            if (scale_float < -127.0f)
                scale_float = -127.0f;
            if (scale_float > 127.0f)
                scale_float = 127.0f;

            int32_t scale = static_cast<int32_t>(scale_float);
            int64_t scale_offset = row * out_cols + packed_cols + block;
            if (scale_offset >= 0 && scale_offset < M * out_cols)
                output[scale_offset] = static_cast<uint8_t>(scale + 127);

            quant_scales[group] = exp2f(-scale_float);
        }
    }

    __syncthreads();

    if (valid_block && lane < 16) {
        float quant_scale = quant_scales[group];

        float value0 = gated_values[group][2 * lane];
        float value1 = gated_values[group][2 * lane + 1];

        uint8_t code0 = e2m1_code(value0 * quant_scale);
        uint8_t code1 = e2m1_code(value1 * quant_scale);

        int64_t packed_index = block * 16 + static_cast<int64_t>(lane);
        if (packed_index < packed_cols) {
            int64_t packed_offset = row * out_cols + packed_index;
            if (packed_offset >= 0 && packed_offset < M * out_cols) {
                output[packed_offset] = static_cast<uint8_t>(
                    (code0 & 0x0fu) | ((code1 & 0x0fu) << 4));
            }
        }
    }
}

torch::Tensor fused_mxfp4(torch::Tensor x, int64_t activation) {
    TORCH_CHECK(x.is_cuda(), "input must be a CUDA/HIP tensor");
    TORCH_CHECK(x.scalar_type() == torch::kFloat32, "input must be float32");
    TORCH_CHECK(x.dim() == 2, "input must be 2-dimensional");
    TORCH_CHECK(x.is_contiguous(), "input must be contiguous");
    TORCH_CHECK(activation >= 0 && activation <= 2, "invalid activation");

    int64_t M = x.size(0);
    int64_t N = x.size(1);
    TORCH_CHECK(N % 4 == 0, "N must be a multiple of 4");

    int64_t d = N / 2;
    int64_t n_blocks = (d + 31) / 32;
    int64_t packed_cols = d / 2;
    int64_t out_cols = packed_cols + n_blocks;

    auto output = torch::empty(
        {M, out_cols},
        torch::TensorOptions().device(x.device()).dtype(torch::kUInt8));

    int64_t total_blocks = M * n_blocks;
    if (total_blocks == 0)
        return output;
    int64_t workgroups = total_blocks / 2 + total_blocks % 2;
    TORCH_CHECK(workgroups <= static_cast<int64_t>(0x7fffffff),
                "launch grid is too large");

    dim3 grid(static_cast<unsigned int>(workgroups), 1, 1);
    dim3 threads(64, 1, 1);

    hipLaunchKernelGGL(
        fused_mxfp4_kernel,
        grid,
        threads,
        0,
        0,
        x.data_ptr<float>(),
        output.data_ptr<uint8_t>(),
        M,
        N,
        d,
        n_blocks,
        packed_cols,
        out_cols,
        static_cast<int>(activation));

    hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess,
                "fused_mxfp4 kernel launch failed: ",
                hipGetErrorString(error));
    return output;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Gated activation x SwiGLU split-half multiply x dynamic MXFP4 quantization
    fused operator.

    Input x has shape (M, N) (N is a multiple of 4). Split the last dimension in
    half: a = x[:, :N/2], b = x[:, N/2:], then first compute the gated product in
    float32 as out = act(a) * b, where act is selected by the __init__ argument
    activation (mathematical definition, all evaluated in float32):
        silu      : u * sigmoid(u)
        gelu      : 0.5 * u * (1 + erf(u * 0.7071067811865476))
        gelu_tanh : 0.5 * u * (1 + tanh(0.7978845608028654 * (u + 0.044715 * u^3)))

    Then split out along the last dimension into contiguous 32-element blocks and
    dynamically quantize each block to MXFP4 (float32 bit manipulation throughout):
      1. When N/2 is not a multiple of 32, zero-pad the right end of the last block
         up to 32 elements; the padding participates in amax.
      2. amax = max|block|; apply (bits + 0x200000) & 0xFF800000 to the float32 bit
         pattern of amax (even_round: clear the mantissa and round up to the power
         of two grid).
      3. Unbiased scale = clamp(floor(log2(amax)) - 2, -127, 127); the e8m0 byte =
         unbiased scale + 127, landing in [0, 254] (meaning 2^(byte - 127)). A
         fully zero block (including a zero-pad segment that makes amax 0) goes
         through log2(0) = -inf, is clamped to -127, and gets byte 0.
      4. q = block * 2^(-unbiased scale), each element rounded to the e2m1 grid
         {0, +-0.5, +-1, +-1.5, +-2, +-3, +-4, +-6}. Bit-level formula: take the
         float32 fields of q -- s (sign bit) / e (biased exponent) / m (23-bit
         mantissa):
             e' = max(e, 126) - 126
             m' = (e < 127) ? (0x400000 | (m >> 1)) >> (126 - e) : m (subnormal
                  rescaling)
             code = (((e' << 2) | (m' >> 21)) + 1) >> 1, then saturated to 0x7
             e2m1 code word (4 bits) = (s ? 8 : 0) | code
      5. Two adjacent e2m1 code words are packed into one uint8: the even index
         occupies the low 4 bits, the odd index the high 4 bits.

    The output is a single uint8 tensor (two segments concatenated along the last
    dimension):
        out (M, N/4 + ceil(N/64)) uint8
        first N/4 columns       : MXFP4 packed code words (two e2m1 values per byte)
        last ceil(N/64) columns : the e8m0 scale byte of each 32-element block
    Both segments are integer code words and must match exactly.

    Input/output specification:
        x    float16 / bfloat16 (M, N), contiguous, N % 4 == 0, M >= 1
             (the evaluator casts the input to fp32 before calling forward;
             fp16/bf16 -> fp32 is lossless)
        out  uint8 (M, N/4 + ceil(N/64))

    Implementation constraints (violations are scored as failures):
        - The core computation (activation, split-half multiply, per-block scale
          and e2m1 quantization, code-word packing) must be completed with a
          HIP kernel inside the submitted file; the output is uint8 code words
          with no floating-point output.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The activation, the multiply and the quantization bit manipulation all
          run in float32 and must be bit-identical to this reference implementation
          (code words and scale bytes exactly equal, no tolerance).
        - When N/2 is not a multiple of 32, handle the block tail with the zero-pad
          semantics described above.

    Forbidden: torch.nn.functional.silu / torch.nn.functional.gelu /
    torch.nn.SiLU / torch.nn.GELU / torch.sigmoid / torch.erf / torch.tanh.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, activation: str = "silu"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert activation in ("silu", "gelu", "gelu_tanh"), "activation must be one of silu / gelu / gelu_tanh"
        self.activation = activation
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.to(torch.float32).contiguous()
        return _pyramidkernel_get_extension().fused_mxfp4(
            x,
            0 if self.activation == "silu" else
            (1 if self.activation == "gelu" else 2),
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, N = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        assert N % 4 == 0, "N must be a multiple of 4"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        d = N // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        a, b = x.split([d, d], dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        out = nn.functional.silu(a) * b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        if self.activation == "gelu":
            out = nn.functional.gelu(a) * b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if self.activation == "gelu_tanh":
            out = nn.functional.gelu(a, approximate="tanh") * b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        BLOCK = 32
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        n_blocks = (d + BLOCK - 1) // BLOCK
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        blocks = out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        if d % BLOCK != 0:
            padded = torch.zeros(M, n_blocks * BLOCK, dtype=torch.float32, device=out.device)
            padded[:, :d] = out
            blocks = padded
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        blocks = blocks.reshape(M, n_blocks, BLOCK)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        amax, _ = torch.max(torch.abs(blocks), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        amax = amax.view(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        amax = (amax + 0x200000) & 0xFF800000
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        amax = amax.view(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        scale_unbiased = torch.clamp(torch.log2(amax).floor() - 2, min=-127, max=127)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        bs_e8m0 = (scale_unbiased + 127).to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        quant_scale = torch.exp2(-scale_unbiased)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        qx = blocks * quant_scale.unsqueeze(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        qx = qx.contiguous().view(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        s = qx & 0x80000000
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        e = (qx >> 23) & 0xFF
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        m = qx & 0x7FFFFF
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        adjusted = torch.clamp(127 - e - 1, min=0)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_27>>>
        m = torch.where(e < 127, (0x400000 | (m >> 1)) >> adjusted, m)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_28>>>
        e = torch.where(e > 126, e, 126) - 126
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_29>>>
        combined = (((e << 2) | (m >> 21)) + 1) >> 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_30>>>
        e2m1_tmp = torch.where(combined < 0x7, combined, 0x7)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_31>>>
        e2m1_value = (((s >> 28) & 0xF) | e2m1_tmp).to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_32>>>
        x_fp4 = e2m1_value[..., ::2] | (e2m1_value[..., 1::2] << 4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_33>>>
        x_fp4 = x_fp4.reshape(M, -1)[:, : d // 2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_34>>>
        return torch.cat([x_fp4, bs_e8m0], dim=-1)
        # <<<END_IMPROVE>>>
