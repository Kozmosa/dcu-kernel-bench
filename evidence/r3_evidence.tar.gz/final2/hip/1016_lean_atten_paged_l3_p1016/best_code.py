import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1016_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

torch::Tensor paged_attention(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor kv_block_tables,
    torch::Tensor batch_num_block_n,
    double sm_scale,
    int64_t head_size,
    int64_t page_size);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention", &paged_attention, "Fused paged decode attention");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/ATen.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <cmath>
#include <limits>

template <typename scalar_t, int DIM, int W>
__global__ void paged_attention_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k,
    const scalar_t* __restrict__ v,
    const int32_t* __restrict__ tables,
    const int32_t* __restrict__ cumulative,
    scalar_t* __restrict__ out,
    int64_t heads,
    int64_t query_rows,
    int64_t batch,
    int64_t page,
    int64_t kv_rows,
    int64_t table_blocks,
    float scale) {
    constexpr int R = (DIM + W - 1) / W;
    const int lane = static_cast<int>(threadIdx.x);
    const int64_t work = static_cast<int64_t>(blockIdx.x);
    const int64_t total = heads * query_rows;

    float qreg[R];
    float acc[R];

    const bool valid_work = work < total;
    const int64_t h = valid_work ? work / query_rows : 0;
    const int64_t qr = valid_work ? work - h * query_rows : 0;
    const int64_t b = valid_work ? qr / 16 : 0;

    int64_t s0 = 0;
    int64_t s1 = 0;
    if (valid_work && b >= 0 && b < batch) {
        if (b > 0) {
            s0 = static_cast<int64_t>(cumulative[b - 1]);
        }
        s1 = static_cast<int64_t>(cumulative[b]);
    }

    const int64_t qbase = (h * query_rows + qr) * static_cast<int64_t>(DIM);

    #pragma unroll
    for (int r = 0; r < R; ++r) {
        const int d = lane + r * W;
        if (valid_work && d < DIM) {
            qreg[r] = static_cast<float>(q[qbase + static_cast<int64_t>(d)]);
        } else {
            qreg[r] = 0.0f;
        }
        acc[r] = 0.0f;
    }

    float norm = 0.0f;
    float max_score = -INFINITY;
    const int64_t block_count = (s1 >= s0) ? (s1 - s0) : 0;
    const int64_t kv_len = block_count * page;

    for (int64_t j = 0; j < kv_len; ++j) {
        const int64_t table_pos = s0 + j / page;
        int64_t row = -1;

        if (valid_work && table_pos >= 0 && table_pos < table_blocks) {
            const int64_t table_offset =
                h * table_blocks + table_pos;
            const int64_t physical_block =
                static_cast<int64_t>(tables[table_offset]);
            const int64_t physical_blocks = kv_rows / page;
            if (physical_block >= 0 && physical_block < physical_blocks) {
                row = physical_block * page + (j % page);
            }
        }

        float partial = 0.0f;
        if (valid_work && row >= 0 && row < kv_rows) {
            const int64_t kbase =
                (h * kv_rows + row) * static_cast<int64_t>(DIM);
            #pragma unroll
            for (int r = 0; r < R; ++r) {
                const int d = lane + r * W;
                if (d < DIM) {
                    partial += qreg[r] *
                        static_cast<float>(k[kbase + static_cast<int64_t>(d)]);
                }
            }
        }

        #pragma unroll
        for (int offset = W / 2; offset > 0; offset >>= 1) {
            partial += __shfl_down(partial, offset, W);
        }
        const float dot = __shfl(partial, 0, W);
        const float score = dot * scale;
        const float new_max = score > max_score ? score : max_score;
        const float old_factor =
            isinf(max_score) ? 0.0f : expf(max_score - new_max);
        const float weight = expf(score - new_max);

        max_score = new_max;
        norm = norm * old_factor + weight;

        if (valid_work && row >= 0 && row < kv_rows) {
            const int64_t vbase =
                (h * kv_rows + row) * static_cast<int64_t>(DIM);
            #pragma unroll
            for (int r = 0; r < R; ++r) {
                const int d = lane + r * W;
                if (d < DIM) {
                    const float value =
                        static_cast<float>(v[vbase + static_cast<int64_t>(d)]);
                    acc[r] = acc[r] * old_factor + weight * value;
                }
            }
        } else {
            #pragma unroll
            for (int r = 0; r < R; ++r) {
                acc[r] *= old_factor;
            }
        }
    }

    #pragma unroll
    for (int r = 0; r < R; ++r) {
        const int d = lane + r * W;
        if (valid_work && d < DIM) {
            out[qbase + static_cast<int64_t>(d)] =
                static_cast<scalar_t>(acc[r] / norm);
        }
    }
}

template <typename scalar_t, int DIM, int W>
static void launch_paged(
    const torch::Tensor& q,
    const torch::Tensor& k,
    const torch::Tensor& v,
    const torch::Tensor& tables,
    const torch::Tensor& cumulative,
    torch::Tensor& out,
    int64_t heads,
    int64_t query_rows,
    int64_t batch,
    int64_t page,
    int64_t kv_rows,
    int64_t table_blocks,
    float scale,
    hipStream_t stream) {
    const int64_t n = heads * query_rows;
    TORCH_CHECK(
        n <= static_cast<int64_t>(std::numeric_limits<unsigned int>::max()),
        "launch grid is too large");

    hipLaunchKernelGGL(
        (paged_attention_kernel<scalar_t, DIM, W>),
        dim3(static_cast<unsigned int>(n), 1, 1),
        dim3(W, 1, 1),
        0,
        stream,
        q.data_ptr<scalar_t>(),
        k.data_ptr<scalar_t>(),
        v.data_ptr<scalar_t>(),
        tables.data_ptr<int32_t>(),
        cumulative.data_ptr<int32_t>(),
        out.data_ptr<scalar_t>(),
        heads,
        query_rows,
        batch,
        page,
        kv_rows,
        table_blocks,
        scale);
}

template <typename scalar_t, int DIM, int W>
static void dispatch_wave(
    const torch::Tensor& q,
    const torch::Tensor& k,
    const torch::Tensor& v,
    const torch::Tensor& tables,
    const torch::Tensor& cumulative,
    torch::Tensor& out,
    int64_t heads,
    int64_t query_rows,
    int64_t batch,
    int64_t page,
    int64_t kv_rows,
    int64_t table_blocks,
    float scale,
    hipStream_t stream) {
    launch_paged<scalar_t, DIM, W>(
        q, k, v, tables, cumulative, out, heads, query_rows, batch,
        page, kv_rows, table_blocks, scale, stream);
}

template <typename scalar_t, int DIM>
static void dispatch_dim(
    const torch::Tensor& q,
    const torch::Tensor& k,
    const torch::Tensor& v,
    const torch::Tensor& tables,
    const torch::Tensor& cumulative,
    torch::Tensor& out,
    int64_t heads,
    int64_t query_rows,
    int64_t batch,
    int64_t page,
    int64_t kv_rows,
    int64_t table_blocks,
    float scale,
    int wave,
    hipStream_t stream) {
    if (wave == 32) {
        dispatch_wave<scalar_t, DIM, 32>(
            q, k, v, tables, cumulative, out, heads, query_rows, batch,
            page, kv_rows, table_blocks, scale, stream);
    } else {
        dispatch_wave<scalar_t, DIM, 64>(
            q, k, v, tables, cumulative, out, heads, query_rows, batch,
            page, kv_rows, table_blocks, scale, stream);
    }
}

torch::Tensor paged_attention(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor kv_block_tables,
    torch::Tensor batch_num_block_n,
    double sm_scale,
    int64_t head_size,
    int64_t page_size) {
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda(),
                "q, k, and v must be CUDA/HIP tensors");
    TORCH_CHECK(kv_block_tables.is_cuda() && batch_num_block_n.is_cuda(),
                "metadata tensors must be CUDA/HIP tensors");

    c10::cuda::CUDAGuard device_guard(q.device());

    TORCH_CHECK(q.get_device() == k.get_device() &&
                q.get_device() == v.get_device() &&
                q.get_device() == kv_block_tables.get_device() &&
                q.get_device() == batch_num_block_n.get_device(),
                "all tensors must be on the same device");

    TORCH_CHECK(q.is_contiguous() && k.is_contiguous() && v.is_contiguous(),
                "q, k, and v must be contiguous");
    TORCH_CHECK(kv_block_tables.is_contiguous() &&
                batch_num_block_n.is_contiguous(),
                "metadata tensors must be contiguous");

    TORCH_CHECK(q.dim() == 3 && k.dim() == 3 && v.dim() == 3,
                "q, k, and v must be rank three");
    TORCH_CHECK(kv_block_tables.dim() == 2 &&
                batch_num_block_n.dim() == 1,
                "metadata tensors have incorrect rank");

    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type(),
                "q, k, and v must have the same dtype");
    TORCH_CHECK(q.scalar_type() == at::kHalf ||
                q.scalar_type() == at::kBFloat16 ||
                q.scalar_type() == at::kFloat,
                "only float16, bfloat16, and float32 are supported");

    TORCH_CHECK(kv_block_tables.scalar_type() == at::kInt &&
                batch_num_block_n.scalar_type() == at::kInt,
                "metadata must be int32");

    TORCH_CHECK(head_size == 16 || head_size == 32 || head_size == 64 ||
                head_size == 128 || head_size == 256,
                "unsupported head size");
    TORCH_CHECK(page_size == 64,
                "page_size must be 64");

    TORCH_CHECK(q.size(0) == k.size(0) && q.size(0) == v.size(0),
                "head counts must match");
    TORCH_CHECK(q.size(2) == k.size(2) && q.size(2) == v.size(2),
                "head sizes must match");
    TORCH_CHECK(q.size(2) == head_size,
                "head_size does not match q");
    TORCH_CHECK(k.size(1) == v.size(1),
                "KV pool lengths must match");
    TORCH_CHECK(k.size(1) > 0 && k.size(1) % page_size == 0,
                "KV pool length must be divisible by page size");
    TORCH_CHECK(kv_block_tables.size(0) == q.size(0),
                "block table head count must match q");

    const int64_t heads = q.size(0);
    const int64_t query_rows = q.size(1);
    const int64_t kv_rows = k.size(1);
    const int64_t batch = batch_num_block_n.size(0);
    const int64_t table_blocks = kv_block_tables.size(1);

    TORCH_CHECK(heads > 0 && query_rows > 0 && batch > 0,
                "input dimensions must be positive");
    TORCH_CHECK(query_rows == batch * 16,
                "decode attention requires sixteen queries per request");
    TORCH_CHECK(table_blocks > 0,
                "block tables must contain at least one block");

    hipDeviceProp_t props;
    int device_index = -1;
    hipError_t err = hipGetDevice(&device_index);
    TORCH_CHECK(err == hipSuccess,
                "unable to query current HIP device: ",
                hipGetErrorString(err));
    err = hipGetDeviceProperties(&props, device_index);
    TORCH_CHECK(err == hipSuccess,
                "unable to query HIP device properties: ",
                hipGetErrorString(err));

    const int wave = props.warpSize;
    TORCH_CHECK(wave == 32 || wave == 64,
                "unsupported native wave width");

    auto out = at::empty_like(q);
    hipStream_t stream =
        at::cuda::getCurrentCUDAStream(q.device().index()).stream();
    const float scale = static_cast<float>(sm_scale);

    if (q.scalar_type() == at::kHalf) {
        if (head_size == 16) {
            dispatch_dim<at::Half, 16>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else if (head_size == 32) {
            dispatch_dim<at::Half, 32>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else if (head_size == 64) {
            dispatch_dim<at::Half, 64>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else if (head_size == 128) {
            dispatch_dim<at::Half, 128>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else {
            dispatch_dim<at::Half, 256>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        }
    } else if (q.scalar_type() == at::kBFloat16) {
        if (head_size == 16) {
            dispatch_dim<at::BFloat16, 16>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else if (head_size == 32) {
            dispatch_dim<at::BFloat16, 32>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else if (head_size == 64) {
            dispatch_dim<at::BFloat16, 64>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else if (head_size == 128) {
            dispatch_dim<at::BFloat16, 128>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else {
            dispatch_dim<at::BFloat16, 256>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        }
    } else {
        if (head_size == 16) {
            dispatch_dim<float, 16>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else if (head_size == 32) {
            dispatch_dim<float, 32>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else if (head_size == 64) {
            dispatch_dim<float, 64>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else if (head_size == 128) {
            dispatch_dim<float, 128>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        } else {
            dispatch_dim<float, 256>(
                q, k, v, kv_block_tables, batch_num_block_n, out,
                heads, query_rows, batch, page_size, kv_rows,
                table_blocks, scale, wave, stream);
        }
    }

    err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "paged attention launch failed: ",
                hipGetErrorString(err));

    err = hipStreamSynchronize(stream);
    TORCH_CHECK(err == hipSuccess,
                "paged attention execution failed: ",
                hipGetErrorString(err));

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Batched decode attention over a paged KV cache: ragged batch, 16 queries per
    request, one independent physical block table per head, and blocks of the
    physical pool that nothing references are garbage data.

    The KV cache is paged with a fixed page_size: the h-th head slice of k / v
    (shape [total_kv_len, head_size]) is split into total_kv_len / page_size
    physical blocks; the block table of head h, kv_block_tables[h], lists in order
    the physical block ids referenced by each request, where the blocks
    referenced by request b are
      kv_block_tables[h, batch_num_block_n[b-1] : batch_num_block_n[b]]
    (starting at 0 for b=0; batch_num_block_n is the cumulative sum of the
    per-request block counts, and its last element is the total number of used
    blocks total_used_blocks). Physical blocks that no table entry references are
    garbage data and must not take part in the computation.

    Mathematical definition: let s_b be the starting block offset of request b
    (0 for b=0, otherwise s_b = batch_num_block_n[b-1]); its logical KV length is
    L_b = block count * page_size, and logical position j maps to physical row
    row(j) = kv_block_tables[h, s_b + j // page_size] * page_size + j % page_size.
    For every head h and request b (query row range [b*n_ctx_q, (b+1)*n_ctx_q)):
      scores[i, j] = sm_scale * <q[h, b*n_ctx_q+i, :], k[h, row(j), :]>
      p[i, :] = softmax_j(scores[i, :])
      out[h, b*n_ctx_q+i, :] = sum_j p[i, j] * v[h, row(j), :]
    softmax uses a numerically stable (online) implementation, intermediate
    accumulation is in float32, and the output is cast back to the input dtype.
    Boundary behaviour: every request's KV length is a positive integer multiple
    of page_size (a partially filled tail block is outside the task scope), so the
    softmax denominator is always positive; requests and heads do not affect each
    other.

    Input/output specification:
      q                 [num_heads, n_ctx_q * batch, head_size] float16/bfloat16
      k, v              [num_heads, total_kv_len, head_size] same dtype as q (physical block pool)
      kv_block_tables   [num_heads, total_used_blocks] int32 (0-based physical block ids,
                        values < total_kv_len / page_size)
      batch_num_block_n [batch] int32, cumulative sum of the per-request block counts, monotonically increasing
      out               [num_heads, n_ctx_q * batch, head_size] same dtype as q
    Global-domain constraints: head_size in {16, 32, 64, 128, 256}; page_size is
    fixed at 64; n_ctx_q = 16 (the decode form is fixed); each request's KV length
    is a positive integer multiple of page_size and >= page_size;
    num_kv_heads == num_q_heads (MHA, no GQA).

    Implementation constraints (violations are scored as failures):
      - The core computation (paged KV gathering / QK^T / softmax / PV) must be
        done inside the submitted file; calling external attention operator
        libraries such as scaled_dot_product_attention / sdpa / flash_attn, and
        torch.matmul / torch.bmm / torch.mm / torch.baddbmm / torch.einsum /
        torch.softmax (including ATen-equivalent shortcuts such as F.softmax,
        Tensor.matmul and the @ operator) is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - The scheduling strategy (persistent single kernel or a regular grid) is
        free to choose; only semantic correctness and performance are assessed.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: ragged-batch decode, non-quantized fp16/bf16, no causal mask, no
    ALiBi/sliding window, no GQA.
    """
    def __init__(self, head_size: int, page_size: int = 64, sm_scale=0.5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.head_size = int(head_size)
        self.page_size = int(page_size)
        self.sm_scale = float(sm_scale)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, kv_block_tables, batch_num_block_n):
        # <<<IMPROVE:forward_stmt_1>>>
        kv_block_tables = kv_block_tables.to(torch.int32)
        batch_num_block_n = batch_num_block_n.to(torch.int32)
        out = _pyramidkernel_get_extension().paged_attention(
            q.contiguous(), k.contiguous(), v.contiguous(),
            kv_block_tables.contiguous(), batch_num_block_n.contiguous(),
            float(self.sm_scale), int(self.head_size), int(self.page_size)
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        batch_num_block_n = batch_num_block_n.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        num_heads, m_total, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        batch = int(batch_num_block_n.numel())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_ctx_q = m_total // batch
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        page = self.page_size
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert num_heads == k.shape[0] == v.shape[0], "the head counts of q/k/v must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert k.shape[1] == v.shape[1], "the KV pool lengths of k/v must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        offs_in_block = torch.arange(page, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
