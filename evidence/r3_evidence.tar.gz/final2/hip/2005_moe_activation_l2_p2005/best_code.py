import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2005_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

torch::Tensor moe_activation_forward(torch::Tensor x, int64_t mode,
                                      double alpha, double limit);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_activation_forward", &moe_activation_forward,
          "Fused MoE activation forward");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <cstdint>

namespace {

__device__ __forceinline__ float sigmoid_f(float x) {
    return 1.0f / (1.0f + expf(-x));
}

__device__ __forceinline__ float gelu_f(float x) {
    return 0.5f * x * (1.0f + erff(x * 0.7071067811865476f));
}

__device__ __forceinline__ float gelu_tanh_f(float x) {
    float x2 = x * x;
    float inner = 0.7978845608028654f * (x + 0.044715f * x * x2);
    return 0.5f * x * (1.0f + tanhf(inner));
}

template <int Mode>
__global__ void moe_activation_kernel(
    const float* __restrict__ input,
    float* __restrict__ output,
    int64_t total,
    int64_t rows,
    int64_t input_width,
    int64_t output_width,
    float alpha,
    float limit) {
    int64_t index =
        static_cast<int64_t>(blockIdx.x) * static_cast<int64_t>(blockDim.x) +
        static_cast<int64_t>(threadIdx.x);
    int64_t stride =
        static_cast<int64_t>(gridDim.x) * static_cast<int64_t>(blockDim.x);
    int64_t input_count = rows * input_width;

    for (int64_t flat = index; flat < total; flat += stride) {
        if (flat < 0 || flat >= total) {
            continue;
        }

        int64_t row = flat / output_width;
        int64_t col = flat - row * output_width;
        if (row < 0 || row >= rows || col < 0 || col >= output_width) {
            continue;
        }

        float result = 0.0f;

        if constexpr (Mode < 4) {
            int64_t offset = row * input_width + col;
            if (offset < 0 || offset >= input_count) {
                continue;
            }

            float value = input[offset];

            if constexpr (Mode == 0) {
                result = value * sigmoid_f(value);
            } else if constexpr (Mode == 1) {
                result = gelu_f(value);
            } else if constexpr (Mode == 2) {
                result = gelu_tanh_f(value);
            } else {
                float positive = value > 0.0f ? value : 0.0f;
                result = positive * positive;
            }
        } else {
            int64_t gate_offset;
            int64_t up_offset;

            if constexpr (Mode == 10) {
                gate_offset = row * input_width + col * 2;
                up_offset = gate_offset + 1;
            } else {
                gate_offset = row * input_width + col;
                up_offset = row * input_width + output_width + col;
            }

            if (gate_offset < 0 || gate_offset >= input_count ||
                up_offset < 0 || up_offset >= input_count) {
                continue;
            }

            float gate = input[gate_offset];
            float up = input[up_offset];

            if constexpr (Mode == 4) {
                result = gate * sigmoid_f(gate) * up;
            } else if constexpr (Mode == 5) {
                float gate_p = gate < limit ? gate : limit;
                float up_p = up;
                if (up_p < -limit) {
                    up_p = -limit;
                }
                if (up_p > limit) {
                    up_p = limit;
                }
                result = gate_p * sigmoid_f(gate_p) * up_p;
            } else if constexpr (Mode == 6 || Mode == 10) {
                float gate_p = gate < limit ? gate : limit;
                float up_p = up;
                if (up_p < -limit) {
                    up_p = -limit;
                }
                if (up_p > limit) {
                    up_p = limit;
                }
                result =
                    gate_p * sigmoid_f(alpha * gate_p) * (up_p + 1.0f);
            } else if constexpr (Mode == 7) {
                result = gelu_f(gate) * up;
            } else if constexpr (Mode == 8) {
                result = gelu_tanh_f(gate) * up;
            } else {
                float silu = gate * sigmoid_f(gate);
                if (silu > limit) {
                    silu = limit;
                }

                float up_p = up;
                if (up_p < -limit) {
                    up_p = -limit;
                }
                if (up_p > limit) {
                    up_p = limit;
                }

                result = silu * up_p;
            }
        }

        if (flat >= 0 && flat < total) {
            output[flat] = result;
        }
    }
}

template <int Mode>
void launch_mode(
    const float* input,
    float* output,
    int64_t total,
    int64_t rows,
    int64_t input_width,
    int64_t output_width,
    float alpha,
    float limit,
    unsigned int blocks) {
    moe_activation_kernel<Mode><<<blocks, 256>>>(
        input,
        output,
        total,
        rows,
        input_width,
        output_width,
        alpha,
        limit);
}

}  // namespace

torch::Tensor moe_activation_forward(
    torch::Tensor x,
    int64_t mode,
    double alpha,
    double limit) {
    TORCH_CHECK(x.is_cuda(), "input must be a CUDA/HIP tensor");
    TORCH_CHECK(x.is_contiguous(), "input must be contiguous");
    TORCH_CHECK(
        x.scalar_type() == torch::kFloat32,
        "input must have float32 dtype");
    TORCH_CHECK(x.dim() == 2, "input must be 2D");
    TORCH_CHECK(mode >= 0 && mode <= 10, "invalid activation mode");

    int64_t rows = x.size(0);
    int64_t input_width = x.size(1);

    TORCH_CHECK(rows >= 1, "input must have at least one row");
    TORCH_CHECK(input_width >= 1, "input width must be positive");

    bool gated = mode >= 4;
    if (gated) {
        TORCH_CHECK(
            (input_width & 1) == 0,
            "gated input width must be even");
    }

    int64_t output_width = gated ? input_width / 2 : input_width;
    int64_t total = rows * output_width;
    auto output = torch::empty({rows, output_width}, x.options());

    constexpr int threads = 256;
    int64_t needed_blocks =
        (total + static_cast<int64_t>(threads) - 1) /
        static_cast<int64_t>(threads);

    if (needed_blocks < 1) {
        needed_blocks = 1;
    }
    if (needed_blocks > 640) {
        needed_blocks = 640;
    }

    unsigned int blocks = static_cast<unsigned int>(needed_blocks);
    const float* input_ptr = x.data_ptr<float>();
    float* output_ptr = output.data_ptr<float>();
    float a = static_cast<float>(alpha);
    float l = static_cast<float>(limit);

    switch (static_cast<int>(mode)) {
        case 0:
            launch_mode<0>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 1:
            launch_mode<1>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 2:
            launch_mode<2>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 3:
            launch_mode<3>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 4:
            launch_mode<4>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 5:
            launch_mode<5>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 6:
            launch_mode<6>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 7:
            launch_mode<7>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 8:
            launch_mode<8>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 9:
            launch_mode<9>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        case 10:
            launch_mode<10>(
                input_ptr, output_ptr, total, rows, input_width,
                output_width, a, l, blocks);
            break;
        default:
            TORCH_CHECK(false, "invalid activation mode");
    }

    hipError_t status = hipGetLastError();
    TORCH_CHECK(
        status == hipSuccess,
        "moe activation kernel launch failed: ",
        hipGetErrorString(status));

    return output;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    MoE FFN activation variant family: gated activations (SwiGLU family
    variants) and non-gated element-wise activations, dispatched by the __init__
    parameters activation / alpha / limit.

    All computation runs in float32 and the output is cast back to the input dtype.
    Define
        SiLU(u)      = u * sigmoid(u)
        GELU(u)      = 0.5 * u * (1 + erf(u * 0.7071067811865476))
        GELU_tanh(u) = 0.5 * u * (1 + tanh(0.7978845608028654
                                           * (u + 0.044715 * u^3)))
        ReLU2(u)     = max(u, 0)^2
    sigmoid / erf / tanh are all evaluated as float32 math functions.

    [gated variants] The input x has shape (M, 2N) and the output (M, N). Two data
    layouts:
        chunked (default) : gate = x[:, :N], up = x[:, N:]
        interleaved       : gate = x[:, 0::2] (even columns), up = x[:, 1::2] (odd
                            columns)
    Write the clamped quantities as gate' = min(gate, limit) (upper bound only) and
    up' = clamp(up, -limit, limit) (symmetric clamping); the output of each variant
    is:
        activation="silu", alpha=None, limit=None:
            out = SiLU(gate) * up                        (standard SwiGLU)
        activation="silu", alpha=None, limit=L:
            out = SiLU(gate') * up'                       (clamped SwiGLU)
        activation="silu", alpha=A, limit=L (A and L must be given together):
            out = gate' * sigmoid(A * gate') * (up' + 1)  (scaled clamped gate)
        activation="gelu" (does not accept alpha / limit):
            out = GELU(gate) * up
        activation="gelu_tanh" (does not accept alpha / limit):
            out = GELU_tanh(gate) * up
        activation="swiglustep" (limit defaults to 7.0, does not accept alpha):
            out = clamp(SiLU(gate), max=limit) * up'      (SiLU first, then the
                                                           upper clamp)
        activation="swiglu_interleaved" (interleaved layout; alpha defaults to
        1.702, limit defaults to 7.0):
            out = gate' * sigmoid(alpha * gate') * (up' + 1)

    [non-gated variants] The input x has shape (M, N) and the output (M, N);
    element-wise activation, alpha / limit are ignored:
        activation="silu_no_mul"      : out = SiLU(x)
        activation="gelu_no_mul"      : out = GELU(x)
        activation="gelu_tanh_no_mul" : out = GELU_tanh(x)
        activation="relu2"            : out = ReLU2(x)

    Boundary behaviour: clamping of gate is upper-bound only (nothing is clamped on
    the negative side) while clamping of up is symmetric; the clamping is applied
    before the activation, except for swiglustep, which computes SiLU first and then
    clamps the result on the upper side. Illegal parameter combinations (an unknown
    variant name; gelu / gelu_tanh with alpha or limit; swiglustep with alpha; silu
    given alpha but not limit) are rejected at construction time.

    Input/output specification:
        x    float16 / bfloat16 (M, n), contiguous, M >= 1; the gated variants
             require n to be even (N = n/2 has no alignment constraint: non-powers
             of two and sizes below the common block size are allowed); the
             non-gated variants accept any n >= 1. The evaluator casts the input to
             fp32 before passing it in; fp16/bf16 -> fp32 is lossless.
        out  same dtype as x; shape (M, n/2) for the gated variants and (M, n) for
             the non-gated ones.
        The input value range is the usual randn magnitude (no inf/NaN).

    Implementation constraints (violations are scored as failures):
        - The core computation (chunked / interleaved data selection, clamping,
          activation, gated multiply) must be completed with a HIP kernel inside
          the submitted file; intermediates are always float32.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate accumulation; cast the output back to the
          input dtype.

    (4) Forbidden list and target hardware:
    - Calling ATen shortcuts such as torch.nn.functional.silu /
      torch.nn.functional.gelu / torch.nn.SiLU / torch.nn.GELU / torch.sigmoid /
      torch.erf / torch.tanh / torch.relu / torch.clamp to complete this task's
      computation directly is forbidden; the authoritative forbidden list is the
      task.yaml forbidden list (it covers the source operator library and other
      closed-source acceleration libraries; the final static audit does substring
      matching on the code outside docstrings / comments);
    - Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, activation: str = "silu", alpha=None, limit=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        gated = (
            "silu",
            "gelu",
            "gelu_tanh",
            "swiglustep",
            "swiglu_interleaved",
        )
        nomul = (
            "silu_no_mul",
            "gelu_no_mul",
            "gelu_tanh_no_mul",
            "relu2",
        )
        name = str(activation).lower()
        assert name in gated or name in nomul, (
            "activation must be one of " + "/".join(gated + nomul) + " variants"
        )
        if name in ("gelu", "gelu_tanh"):
            assert alpha is None and limit is None, (
                "gelu / gelu_tanh do not accept alpha / limit"
            )
        if name == "swiglustep":
            assert alpha is None, "swiglustep does not accept alpha"
        if name == "silu" and alpha is not None:
            assert limit is not None, "silu must set limit as well when alpha is set"
        if name == "swiglustep" and limit is None:
            limit = 7.0
        if name == "swiglu_interleaved":
            alpha = 1.702 if alpha is None else alpha
            limit = 7.0 if limit is None else limit

        self.activation = name
        self.is_gated = name in gated
        self.alpha = None if alpha is None else float(alpha)
        self.limit = None if limit is None else float(limit)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        xf = x.to(torch.float32).contiguous()
        assert xf.dim() == 2, "the input must be a 2D (M, n) tensor"

        if self.activation == "silu_no_mul":
            mode = 0
        elif self.activation == "gelu_no_mul":
            mode = 1
        elif self.activation == "gelu_tanh_no_mul":
            mode = 2
        elif self.activation == "relu2":
            mode = 3
        elif self.activation == "silu":
            mode = (
                6
                if self.alpha is not None
                else (5 if self.limit is not None else 4)
            )
        elif self.activation == "gelu":
            mode = 7
        elif self.activation == "gelu_tanh":
            mode = 8
        elif self.activation == "swiglustep":
            mode = 9
        else:
            mode = 10

        if self.is_gated:
            assert (
                xf.shape[-1] % 2 == 0
            ), "the gated variants require the last dimension n to be even"

        alpha_value = 0.0 if self.alpha is None else self.alpha
        limit_value = 0.0 if self.limit is None else self.limit

        result = _pyramidkernel_get_extension().moe_activation_forward(
            xf,
            mode,
            alpha_value,
            limit_value,
        )
        return result.to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # <<<END_IMPROVE>>>
