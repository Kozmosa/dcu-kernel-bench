import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3004_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

void moe_forward(
    const at::Tensor& a,
    const at::Tensor& w1,
    const at::Tensor& w2,
    const at::Tensor& topk_weights,
    const at::Tensor& topk_ids,
    at::Tensor out);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_forward", &moe_forward, "Fused HIP MoE forward");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cstdint>
#include <cmath>

namespace {

__device__ __forceinline__ float load_value(const void* p, int64_t i, int is_bf16) {
    if (!is_bf16) {
        return reinterpret_cast<const float*>(p)[i];
    }
    const uint16_t v = reinterpret_cast<const uint16_t*>(p)[i];
    const uint32_t bits = static_cast<uint32_t>(v) << 16;
    return __uint_as_float(bits);
}

__device__ __forceinline__ void store_value(void* p, int64_t i, float v, int is_bf16) {
    if (!is_bf16) {
        reinterpret_cast<float*>(p)[i] = v;
        return;
    }
    uint32_t bits = __float_as_uint(v);
    uint32_t upper = bits >> 16;
    const uint32_t lower = bits & 0xffffu;
    if (lower > 0x8000u || (lower == 0x8000u && (upper & 1u))) {
        ++upper;
    }
    reinterpret_cast<uint16_t*>(p)[i] = static_cast<uint16_t>(upper);
}

__global__ void first_projection_kernel(
    const void* __restrict__ a,
    const void* __restrict__ w1,
    const int64_t* __restrict__ ids,
    float* __restrict__ inter,
    int64_t M,
    int64_t K,
    int64_t E,
    int64_t N,
    int64_t top_k,
    int is_bf16) {
    const int64_t total = M * top_k * N;
    const int64_t stride = static_cast<int64_t>(blockDim.x) *
                           static_cast<int64_t>(gridDim.x);
    for (int64_t linear = static_cast<int64_t>(blockIdx.x) *
                              static_cast<int64_t>(blockDim.x) +
                          static_cast<int64_t>(threadIdx.x);
         linear < total;
         linear += stride) {
        const int64_t n = linear % N;
        const int64_t pair = linear / N;
        const int64_t j = pair % top_k;
        const int64_t m = pair / top_k;
        if (m >= M || j >= top_k || n >= N) {
            continue;
        }

        const int64_t expert = ids[m * top_k + j];
        if (expert < 0 || expert >= E) {
            continue;
        }

        float acc = 0.0f;
        for (int64_t k = 0; k < K; ++k) {
            const int64_t ai = m * K + k;
            const int64_t wi = (expert * N + n) * K + k;
            acc += load_value(a, ai, is_bf16) *
                   load_value(w1, wi, is_bf16);
        }
        inter[linear] = acc;
    }
}

__global__ void second_projection_kernel(
    const float* __restrict__ inter,
    const void* __restrict__ w2,
    const void* __restrict__ weights,
    const int64_t* __restrict__ ids,
    void* __restrict__ out,
    int64_t M,
    int64_t K,
    int64_t E,
    int64_t H,
    int64_t top_k,
    int is_bf16) {
    const int64_t total = M * top_k * K;
    const int64_t stride = static_cast<int64_t>(blockDim.x) *
                           static_cast<int64_t>(gridDim.x);
    for (int64_t linear = static_cast<int64_t>(blockIdx.x) *
                              static_cast<int64_t>(blockDim.x) +
                          static_cast<int64_t>(threadIdx.x);
         linear < total;
         linear += stride) {
        const int64_t k = linear % K;
        const int64_t pair = linear / K;
        const int64_t j = pair % top_k;
        const int64_t m = pair / top_k;
        if (m >= M || j >= top_k || k >= K) {
            continue;
        }

        const int64_t expert = ids[m * top_k + j];
        if (expert < 0 || expert >= E) {
            continue;
        }

        float acc = 0.0f;
        const int64_t inter_base = (m * top_k + j) * (H * 2);
        for (int64_t n = 0; n < H; ++n) {
            const float gate = inter[inter_base + n];
            const float up = inter[inter_base + H + n];
            const float sigmoid = 1.0f / (1.0f + expf(-gate));
            const float h = gate * sigmoid * up;
            const int64_t wi = (expert * K + k) * H + n;
            acc += h * load_value(w2, wi, is_bf16);
        }

        const float route_weight =
            load_value(weights, m * top_k + j, is_bf16);
        store_value(out, linear, acc * route_weight, is_bf16);
    }
}

}  // namespace

void moe_forward(
    const at::Tensor& a,
    const at::Tensor& w1,
    const at::Tensor& w2,
    const at::Tensor& topk_weights,
    const at::Tensor& topk_ids,
    at::Tensor out) {
    TORCH_CHECK(a.is_cuda(), "a must be a HIP tensor");
    TORCH_CHECK(w1.is_cuda() && w2.is_cuda(), "weights must be HIP tensors");
    TORCH_CHECK(topk_weights.is_cuda() && topk_ids.is_cuda(),
                "routing tensors must be HIP tensors");
    TORCH_CHECK(out.is_cuda(), "out must be a HIP tensor");

    TORCH_CHECK(a.is_contiguous() && w1.is_contiguous() && w2.is_contiguous() &&
                    topk_weights.is_contiguous() && topk_ids.is_contiguous() &&
                    out.is_contiguous(),
                "all tensors must be contiguous");
    TORCH_CHECK(a.scalar_type() == at::kFloat ||
                    a.scalar_type() == at::kBFloat16,
                "a must be float32 or bfloat16");
    TORCH_CHECK(w1.scalar_type() == a.scalar_type() &&
                    w2.scalar_type() == a.scalar_type() &&
                    topk_weights.scalar_type() == a.scalar_type() &&
                    out.scalar_type() == a.scalar_type(),
                "floating tensors must have matching dtype");
    TORCH_CHECK(topk_ids.scalar_type() == at::kLong,
                "topk_ids must be int64");

    TORCH_CHECK(a.dim() == 2 && w1.dim() == 3 && w2.dim() == 3 &&
                    topk_weights.dim() == 2 && topk_ids.dim() == 2 &&
                    out.dim() == 3,
                "invalid tensor rank");
    TORCH_CHECK(a.device() == w1.device() && a.device() == w2.device() &&
                    a.device() == topk_weights.device() &&
                    a.device() == topk_ids.device() &&
                    a.device() == out.device(),
                "all tensors must be on the same device");

    const int64_t M = a.size(0);
    const int64_t K = a.size(1);
    const int64_t E = w1.size(0);
    const int64_t N = w1.size(1);
    const int64_t top_k = topk_ids.size(1);
    const int64_t H = N / 2;

    TORCH_CHECK(M > 0 && K > 0 && E > 0 && N > 0 && top_k > 0,
                "dimensions must be positive");
    TORCH_CHECK(N % 2 == 0, "w1 channel dimension must be even");
    TORCH_CHECK(w1.size(2) == K, "w1 has incompatible K dimension");
    TORCH_CHECK(w2.size(0) == E && w2.size(1) == K &&
                    w2.size(2) == H,
                "w2 has incompatible shape");
    TORCH_CHECK(topk_weights.size(0) == M &&
                    topk_weights.size(1) == top_k,
                "routing weights have incompatible shape");
    TORCH_CHECK(out.size(0) == M && out.size(1) == top_k &&
                    out.size(2) == K,
                "out has incompatible shape");

    auto temp_options = a.options().dtype(at::kFloat);
    at::Tensor inter = torch::empty({M, top_k, N}, temp_options);

    const bool is_bf16 = a.scalar_type() == at::kBFloat16;
    const int threads = 256;
    const int blocks = 4096;
    auto stream = at::cuda::getDefaultCUDAStream().stream();

    first_projection_kernel<<<blocks, threads, 0, stream>>>(
        a.data_ptr(),
        w1.data_ptr(),
        topk_ids.data_ptr<int64_t>(),
        inter.data_ptr<float>(),
        M, K, E, N, top_k,
        is_bf16 ? 1 : 0);
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "first MoE HIP kernel launch failed: ",
                hipGetErrorString(err));

    second_projection_kernel<<<blocks, threads, 0, stream>>>(
        inter.data_ptr<float>(),
        w2.data_ptr(),
        topk_weights.data_ptr(),
        topk_ids.data_ptr<int64_t>(),
        out.data_ptr(),
        M, K, E, H, top_k,
        is_bf16 ? 1 : 0);
    err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "second MoE HIP kernel launch failed: ",
                hipGetErrorString(err));
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    The full fused Mixture-of-Experts (MoE) token feed-forward path: one call
    completes the whole chain "pick experts by routing -> first grouped GEMM ->
    SwiGLU activation -> second grouped GEMM -> routing weighting".

    Operator semantics (mathematical definition and boundary behaviour):
      Inputs: activation a [M, K]; expert weight w1 [E, N, K] for the first FFN
      layer (N = 2*hidden, the first N/2 channels are gate and the last N/2 are
      up), w2 [E, K, N//2] for the second FFN layer; the routing result
      topk_ids [M, top_k] holds the expert ids selected for each token and
      topk_weights [M, top_k] the matching routing weights. For each token m and
      its j-th expert e = topk_ids[m, j]:
        gate[m,j,:] = a[m,:] @ w1[e, :N//2, :].T          # [N//2]
        up[m,j,:]   = a[m,:] @ w1[e, N//2:, :].T          # [N//2]
        h[m,j,:]    = gate * sigmoid(gate) * up           # SwiGLU, SiLU(x)=x*sigmoid(x)
        out[m,j,k]  = topk_weights[m,j] * sum_{n<N//2} h[m,j,n] * w2[e,k,n]
      that is out[m,j,:] = topk_weights[m,j] * (h[m,j,:] @ w2[e].T). The (m, j)
      pairs are mutually independent; the outputs of all top_k slots are written
      to the result, with no merge, sum or normalization across experts.
      Boundary behaviour: N is even; top_k <= E and the topk_ids values lie in
      [0, E); the top_k experts of one token are generated distinct (even should
      a duplicate appear, the pair-independent computation still holds); M and K
      are arbitrary positive integers (1 included, i.e. the GEMV case); routing
      weighting is always enabled.

    Input/output specification:
      forward(a, w1, w2, topk_weights, topk_ids) -> out
        a            [M, K]        bfloat16/float32, row-major contiguous
        w1           [E, N, K]     same dtype as a, row-major contiguous
        w2           [E, K, N//2]  same dtype as a, row-major contiguous
        topk_weights [M, top_k]    same dtype as a, row-major contiguous
        topk_ids     [M, top_k]    int64 (losslessly recoverable after the
                                   evaluator's fp32 cast)
        out          [M, top_k, K] same dtype as a
      __init__(top_k, num_experts): instance metadata only; forward always goes
      by the actual runtime tensor shapes (top_k = topk_ids.shape[1],
      E = w1.shape[0]).

    Implementation constraints (violations are scored as failures):
      - Core computation (both grouped GEMMs, the SwiGLU activation, the routing
        weighting) must be done with a HIP kernel inside the submitted file;
        calling ATen shortcuts such as torch.matmul / torch.mm / torch.bmm /
        torch.baddbmm / torch.addmm / torch.einsum /
        torch.nn.functional.linear / F.linear / torch.nn.functional.silu /
        F.silu / torch.sigmoid / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: non-quantized bfloat16/float32 activations and weights; single
    card; no expert capacity limit, no shared experts, no routing weight
    normalization; the expert dispatch/scheduling strategy (sorted alignment,
    persistent grid, etc.) is up to the implementation and is judged by the
    output tolerance.
    """
    def __init__(self, top_k: int, num_experts: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.top_k = top_k
        self.num_experts = num_experts
        # <<<END_IMPROVE>>>

    def forward(self, a, w1, w2, topk_weights, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, K = a.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        E, N, _ = w1.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        H = N // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert 0 <= int(topk_ids.min()) and int(topk_ids.max()) < E, "topk_ids must fall inside [0, E)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # Native HIP kernels perform float32 accumulation and dtype conversion.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # Routing weights are consumed directly by the native HIP kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        out = torch.empty((M, top_k, K), dtype=a.dtype, device=a.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        _pyramidkernel_get_extension().moe_forward(
            a, w1, w2, topk_weights, topk_ids, out
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return out
        # <<<END_IMPROVE>>>
