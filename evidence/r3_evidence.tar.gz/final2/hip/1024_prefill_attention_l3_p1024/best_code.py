import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1024_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor prefill_attention(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor b_start_loc,
    torch::Tensor b_seq_len,
    double sm_scale,
    bool causal);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("prefill_attention", &prefill_attention,
          "fused ragged prefill attention");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/hip/HIPContext.h>
#include <c10/core/DeviceGuard.h>
#include <c10/util/Half.h>
#include <c10/util/BFloat16.h>
#include <cstdint>
#include <cmath>
#include <limits>

template <typename scalar_t>
__global__ void ragged_attention_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k,
    const scalar_t* __restrict__ v,
    const int32_t* __restrict__ starts,
    const int32_t* __restrict__ lengths,
    scalar_t* __restrict__ out,
    int64_t total_tokens,
    int64_t num_q_heads,
    int64_t num_kv_heads,
    int64_t head_dim,
    int64_t num_seqs,
    float sm_scale,
    bool causal) {
    extern __shared__ float shared[];
    const int wave_size = warpSize;
    const int wave_id = threadIdx.x / wave_size;
    const int lane = threadIdx.x % wave_size;
    const int waves_per_block = blockDim.x / wave_size;
    const int64_t row =
        static_cast<int64_t>(blockIdx.x) * static_cast<int64_t>(waves_per_block) +
        static_cast<int64_t>(wave_id);

    __shared__ int64_t sequence_start[8];
    __shared__ int64_t sequence_length[8];
    __shared__ bool row_valid[8];

    if (lane == 0) {
        sequence_start[wave_id] = 0;
        sequence_length[wave_id] = 0;
        row_valid[wave_id] = false;
        if (row < total_tokens * num_q_heads && num_seqs > 0) {
            const int64_t token = row / num_q_heads;
            int64_t lo = 0;
            int64_t hi = num_seqs;
            while (lo < hi) {
                const int64_t mid = lo + (hi - lo) / 2;
                if (static_cast<int64_t>(starts[mid]) <= token)
                    lo = mid + 1;
                else
                    hi = mid;
            }
            if (lo > 0) {
                const int64_t seq = lo - 1;
                const int64_t start = static_cast<int64_t>(starts[seq]);
                const int64_t len = static_cast<int64_t>(lengths[seq]);
                if (start >= 0 && len > 0 &&
                    token >= start && token < start + len &&
                    start + len <= total_tokens) {
                    sequence_start[wave_id] = start;
                    sequence_length[wave_id] = len;
                    row_valid[wave_id] = true;
                }
            }
        }
    }

    __syncthreads();
    if (!row_valid[wave_id])
        return;

    const int64_t token = row / num_q_heads;
    const int64_t qhead = row % num_q_heads;
    const int64_t kvhead = qhead / (num_q_heads / num_kv_heads);
    const int64_t qbase = row * head_dim;
    const int64_t tile_base = static_cast<int64_t>(wave_id) * head_dim;
    float* q_cache = shared + tile_base;
    float* accum = shared +
        static_cast<int64_t>(waves_per_block) * head_dim + tile_base;

    for (int64_t c = static_cast<int64_t>(lane); c < head_dim;
         c += static_cast<int64_t>(wave_size)) {
        q_cache[c] = static_cast<float>(q[qbase + c]);
        accum[c] = 0.0f;
    }

    float running_max = -INFINITY;
    float running_den = 0.0f;
    const int64_t start = sequence_start[wave_id];
    const int64_t len = sequence_length[wave_id];
    const int64_t visible = causal ? token - start + 1 : len;

    for (int64_t j = 0; j < visible; ++j) {
        const int64_t key_token = start + j;
        const int64_t kvbase =
            (key_token * num_kv_heads + kvhead) * head_dim;
        float partial = 0.0f;

        for (int64_t c = static_cast<int64_t>(lane); c < head_dim;
             c += static_cast<int64_t>(wave_size)) {
            partial += q_cache[c] * static_cast<float>(k[kvbase + c]);
        }

        for (int delta = wave_size / 2; delta > 0; delta >>= 1)
            partial += __shfl_down(partial, delta, wave_size);

        const float logit = __shfl(partial, 0, wave_size) * sm_scale;
        const float new_max = fmaxf(logit, running_max);
        const float rescale =
            isfinite(running_max) ? expf(running_max - new_max) : 0.0f;
        const float weight = expf(logit - new_max);

        running_max = new_max;
        running_den = running_den * rescale + weight;

        for (int64_t c = static_cast<int64_t>(lane); c < head_dim;
             c += static_cast<int64_t>(wave_size)) {
            const float value = static_cast<float>(v[kvbase + c]);
            accum[c] = accum[c] * rescale + weight * value;
        }
    }

    for (int64_t c = static_cast<int64_t>(lane); c < head_dim;
         c += static_cast<int64_t>(wave_size)) {
        out[qbase + c] = static_cast<scalar_t>(accum[c] / running_den);
    }
}

template <typename scalar_t, int CAP>
__global__ void ragged_attention_register_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k,
    const scalar_t* __restrict__ v,
    const int32_t* __restrict__ starts,
    const int32_t* __restrict__ lengths,
    scalar_t* __restrict__ out,
    int64_t total_tokens,
    int64_t num_q_heads,
    int64_t num_kv_heads,
    int64_t head_dim,
    int64_t num_seqs,
    float sm_scale,
    bool causal) {
    constexpr int SLOTS = CAP / 32;
    float q_reg[SLOTS];
    float acc_reg[SLOTS];

    const int wave_size = warpSize;
    const int wave_id = threadIdx.x / wave_size;
    const int lane = threadIdx.x % wave_size;
    const int waves_per_block = blockDim.x / wave_size;
    const int64_t row =
        static_cast<int64_t>(blockIdx.x) * static_cast<int64_t>(waves_per_block) +
        static_cast<int64_t>(wave_id);

    __shared__ int64_t sequence_start[8];
    __shared__ int64_t sequence_length[8];
    __shared__ bool row_valid[8];

    if (lane == 0) {
        sequence_start[wave_id] = 0;
        sequence_length[wave_id] = 0;
        row_valid[wave_id] = false;
        if (row < total_tokens * num_q_heads && num_seqs > 0) {
            const int64_t token = row / num_q_heads;
            int64_t lo = 0;
            int64_t hi = num_seqs;
            while (lo < hi) {
                const int64_t mid = lo + (hi - lo) / 2;
                if (static_cast<int64_t>(starts[mid]) <= token)
                    lo = mid + 1;
                else
                    hi = mid;
            }
            if (lo > 0) {
                const int64_t seq = lo - 1;
                const int64_t start = static_cast<int64_t>(starts[seq]);
                const int64_t len = static_cast<int64_t>(lengths[seq]);
                if (start >= 0 && len > 0 &&
                    token >= start && token < start + len &&
                    start + len <= total_tokens) {
                    sequence_start[wave_id] = start;
                    sequence_length[wave_id] = len;
                    row_valid[wave_id] = true;
                }
            }
        }
    }

    __syncthreads();
    if (!row_valid[wave_id])
        return;

    const int64_t token = row / num_q_heads;
    const int64_t qhead = row % num_q_heads;
    const int64_t kvhead = qhead / (num_q_heads / num_kv_heads);
    const int64_t qbase = row * head_dim;

    #pragma unroll
    for (int slot = 0; slot < SLOTS; ++slot) {
        const int64_t c =
            static_cast<int64_t>(lane) +
            static_cast<int64_t>(slot) * static_cast<int64_t>(warpSize);
        q_reg[slot] = (c < head_dim)
            ? static_cast<float>(q[qbase + c]) : 0.0f;
        acc_reg[slot] = 0.0f;
    }

    float running_max = -INFINITY;
    float running_den = 0.0f;
    const int64_t start = sequence_start[wave_id];
    const int64_t len = sequence_length[wave_id];
    const int64_t visible = causal ? token - start + 1 : len;

    for (int64_t j = 0; j < visible; ++j) {
        const int64_t key_token = start + j;
        const int64_t kvbase =
            (key_token * num_kv_heads + kvhead) * head_dim;
        float partial = 0.0f;

        #pragma unroll
        for (int slot = 0; slot < SLOTS; ++slot) {
            const int64_t c =
                static_cast<int64_t>(lane) +
                static_cast<int64_t>(slot) * static_cast<int64_t>(warpSize);
            if (c < head_dim)
                partial += q_reg[slot] * static_cast<float>(k[kvbase + c]);
        }

        for (int delta = wave_size / 2; delta > 0; delta >>= 1)
            partial += __shfl_down(partial, delta, wave_size);

        const float logit = __shfl(partial, 0, wave_size) * sm_scale;
        const float new_max = fmaxf(logit, running_max);
        const float rescale =
            isfinite(running_max) ? expf(running_max - new_max) : 0.0f;
        const float weight = expf(logit - new_max);

        running_max = new_max;
        running_den = running_den * rescale + weight;

        #pragma unroll
        for (int slot = 0; slot < SLOTS; ++slot) {
            const int64_t c =
                static_cast<int64_t>(lane) +
                static_cast<int64_t>(slot) * static_cast<int64_t>(warpSize);
            if (c < head_dim) {
                const float value = static_cast<float>(v[kvbase + c]);
                acc_reg[slot] = acc_reg[slot] * rescale + weight * value;
            }
        }
    }

    #pragma unroll
    for (int slot = 0; slot < SLOTS; ++slot) {
        const int64_t c =
            static_cast<int64_t>(lane) +
            static_cast<int64_t>(slot) * static_cast<int64_t>(warpSize);
        if (c < head_dim)
            out[qbase + c] = static_cast<scalar_t>(acc_reg[slot] / running_den);
    }
}

template <typename scalar_t>
static void launch_generic_attention(
    const torch::Tensor& q,
    const torch::Tensor& k,
    const torch::Tensor& v,
    const torch::Tensor& starts,
    const torch::Tensor& lengths,
    torch::Tensor& out,
    double sm_scale,
    bool causal,
    int64_t total_tokens,
    int64_t num_q_heads,
    int64_t num_kv_heads,
    int64_t head_dim,
    int64_t num_seqs,
    int wave_size,
    const hipDeviceProp_t& properties,
    hipStream_t stream) {
    const int threads = 256;
    const int waves_per_block = threads / wave_size;
    const int64_t rows = total_tokens * num_q_heads;
    const int64_t block_count =
        (rows + static_cast<int64_t>(waves_per_block) - 1) /
        static_cast<int64_t>(waves_per_block);

    const int64_t float_count =
        static_cast<int64_t>(waves_per_block) * head_dim * 2;
    TORCH_CHECK(
        float_count <=
            static_cast<int64_t>(properties.sharedMemPerBlock) /
                static_cast<int64_t>(sizeof(float)) - 64,
        "head dimension exceeds available shared memory");

    const size_t shared_bytes =
        static_cast<size_t>(float_count) * sizeof(float);

    ragged_attention_kernel<scalar_t>
        <<<static_cast<unsigned int>(block_count), threads, shared_bytes, stream>>>(
            q.data_ptr<scalar_t>(),
            k.data_ptr<scalar_t>(),
            v.data_ptr<scalar_t>(),
            starts.data_ptr<int32_t>(),
            lengths.data_ptr<int32_t>(),
            out.data_ptr<scalar_t>(),
            total_tokens,
            num_q_heads,
            num_kv_heads,
            head_dim,
            num_seqs,
            static_cast<float>(sm_scale),
            causal);
}

template <typename scalar_t, int CAP>
static void launch_register_attention(
    const torch::Tensor& q,
    const torch::Tensor& k,
    const torch::Tensor& v,
    const torch::Tensor& starts,
    const torch::Tensor& lengths,
    torch::Tensor& out,
    double sm_scale,
    bool causal,
    int64_t total_tokens,
    int64_t num_q_heads,
    int64_t num_kv_heads,
    int64_t head_dim,
    int64_t num_seqs,
    int wave_size,
    hipStream_t stream) {
    const int threads = 256;
    const int waves_per_block = threads / wave_size;
    const int64_t rows = total_tokens * num_q_heads;
    const int64_t block_count =
        (rows + static_cast<int64_t>(waves_per_block) - 1) /
        static_cast<int64_t>(waves_per_block);

    ragged_attention_register_kernel<scalar_t, CAP>
        <<<static_cast<unsigned int>(block_count), threads, 0, stream>>>(
            q.data_ptr<scalar_t>(),
            k.data_ptr<scalar_t>(),
            v.data_ptr<scalar_t>(),
            starts.data_ptr<int32_t>(),
            lengths.data_ptr<int32_t>(),
            out.data_ptr<scalar_t>(),
            total_tokens,
            num_q_heads,
            num_kv_heads,
            head_dim,
            num_seqs,
            static_cast<float>(sm_scale),
            causal);
}

template <typename scalar_t>
static void launch_ragged_attention(
    const torch::Tensor& q,
    const torch::Tensor& k,
    const torch::Tensor& v,
    const torch::Tensor& starts,
    const torch::Tensor& lengths,
    torch::Tensor& out,
    double sm_scale,
    bool causal) {
    const int64_t total_tokens = static_cast<int64_t>(q.size(0));
    const int64_t num_q_heads = static_cast<int64_t>(q.size(1));
    const int64_t num_kv_heads = static_cast<int64_t>(k.size(1));
    const int64_t head_dim = static_cast<int64_t>(q.size(2));
    const int64_t num_seqs = static_cast<int64_t>(starts.size(0));
    const int64_t rows = total_tokens * num_q_heads;

    if (rows == 0)
        return;

    hipDeviceProp_t properties;
    TORCH_CHECK(
        hipGetDeviceProperties(&properties, q.get_device()) == hipSuccess,
        "could not query HIP device properties");

    const int wave_size = properties.warpSize;
    TORCH_CHECK(wave_size == 32 || wave_size == 64,
                "unsupported wavefront size");

    const int threads = 256;
    const int waves_per_block = threads / wave_size;
    const int64_t block_count =
        (rows + static_cast<int64_t>(waves_per_block) - 1) /
        static_cast<int64_t>(waves_per_block);

    TORCH_CHECK(
        block_count <= static_cast<int64_t>(properties.maxGridSize[0]),
        "attention launch grid is too large");

    hipStream_t stream = at::hip::getCurrentHIPStream(q.get_device());

    if (head_dim <= 32) {
        launch_register_attention<scalar_t, 32>(
            q, k, v, starts, lengths, out, sm_scale, causal,
            total_tokens, num_q_heads, num_kv_heads, head_dim, num_seqs,
            wave_size, stream);
    } else if (head_dim <= 64) {
        launch_register_attention<scalar_t, 64>(
            q, k, v, starts, lengths, out, sm_scale, causal,
            total_tokens, num_q_heads, num_kv_heads, head_dim, num_seqs,
            wave_size, stream);
    } else if (head_dim <= 128) {
        launch_register_attention<scalar_t, 128>(
            q, k, v, starts, lengths, out, sm_scale, causal,
            total_tokens, num_q_heads, num_kv_heads, head_dim, num_seqs,
            wave_size, stream);
    } else if (head_dim <= 256) {
        launch_register_attention<scalar_t, 256>(
            q, k, v, starts, lengths, out, sm_scale, causal,
            total_tokens, num_q_heads, num_kv_heads, head_dim, num_seqs,
            wave_size, stream);
    } else {
        launch_generic_attention<scalar_t>(
            q, k, v, starts, lengths, out, sm_scale, causal,
            total_tokens, num_q_heads, num_kv_heads, head_dim, num_seqs,
            wave_size, properties, stream);
    }

    const hipError_t err = hipGetLastError();
    TORCH_CHECK(
        err == hipSuccess,
        "ragged attention kernel launch failed: ",
        hipGetErrorString(err));
}

torch::Tensor prefill_attention(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor b_start_loc,
    torch::Tensor b_seq_len,
    double sm_scale,
    bool causal) {
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda(),
                "Q, K, and V must be accelerator tensors");
    TORCH_CHECK(b_start_loc.is_cuda() && b_seq_len.is_cuda(),
                "sequence metadata must be accelerator tensors");
    TORCH_CHECK(q.is_contiguous() && k.is_contiguous() && v.is_contiguous(),
                "Q, K, and V must be contiguous");
    TORCH_CHECK(b_start_loc.is_contiguous() && b_seq_len.is_contiguous(),
                "sequence metadata must be contiguous");
    TORCH_CHECK(q.dim() == 3 && k.dim() == 3 && v.dim() == 3,
                "Q, K, and V must be rank-3 tensors");
    TORCH_CHECK(b_start_loc.dim() == 1 && b_seq_len.dim() == 1,
                "sequence metadata must be rank-1 tensors");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                    q.scalar_type() == v.scalar_type(),
                "Q, K, and V must have the same dtype");
    TORCH_CHECK(b_start_loc.scalar_type() == torch::kInt &&
                    b_seq_len.scalar_type() == torch::kInt,
                "sequence metadata must be int32 tensors");
    TORCH_CHECK(q.size(0) == k.size(0) && q.size(0) == v.size(0),
                "Q, K, and V must have the same token count");
    TORCH_CHECK(q.size(2) == k.size(2) && q.size(2) == v.size(2),
                "Q, K, and V must have the same head dimension");
    TORCH_CHECK(k.size(1) == v.size(1),
                "K and V heads must match");
    TORCH_CHECK(q.size(1) > 0 && k.size(1) > 0 &&
                    q.size(1) % k.size(1) == 0,
                "query heads must be divisible by KV heads");
    TORCH_CHECK(q.size(2) > 0,
                "head dimension must be positive");
    TORCH_CHECK(b_start_loc.size(0) == b_seq_len.size(0),
                "metadata lengths must match");
    TORCH_CHECK(q.size(0) == 0 || b_seq_len.size(0) > 0,
                "nonempty tensors require sequence metadata");
    TORCH_CHECK(q.device() == k.device() &&
                    q.device() == v.device() &&
                    q.device() == b_start_loc.device() &&
                    q.device() == b_seq_len.device(),
                "all tensors must be on the same device");

    c10::DeviceGuard guard(q.device());
    auto out = torch::empty_like(q);

    switch (q.scalar_type()) {
        case torch::kFloat:
            launch_ragged_attention<float>(
                q, k, v, b_start_loc, b_seq_len, out, sm_scale, causal);
            break;
        case torch::kHalf:
            launch_ragged_attention<at::Half>(
                q, k, v, b_start_loc, b_seq_len, out, sm_scale, causal);
            break;
        case torch::kBFloat16:
            launch_ragged_attention<at::BFloat16>(
                q, k, v, b_start_loc, b_seq_len, out, sm_scale, causal);
            break;
        default:
            TORCH_CHECK(false, "unsupported Q/K/V dtype");
    }

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Non-paged prefill self-attention over a ragged variable-length batch (contiguous KV, GQA, causal optional).

    Operator semantics: the tokens of num_seqs sequences in the batch are stored
    flattened in dimension 0 of q/k/v; sequence i occupies the row range
    [b_start_loc[i], b_start_loc[i] + b_seq_len[i]), and b_start_loc is the
    exclusive prefix sum of the sequence lengths (b_start_loc[0] = 0,
    b_start_loc[i+1] = b_start_loc[i] + b_seq_len[i]), with no padding; the
    q/k/v of each sequence are the query/key/value of the same token batch (self
    attention). For the h-th query head (its KV head is
    g = h // query_group_size, query_group_size = num_q_heads // num_kv_heads)
    and in-sequence relative position t of sequence i
    (0 <= t < L_i, L_i = b_seq_len[i], row index s = b_start_loc[i] + t):
      logits[j] = sm_scale * <q[s, h, :], k[b_start_loc[i]+j, g, :]>
                  (sm_scale defaults to 1 / sqrt(head_dim))
      with causal=True, positions j > t are set to -inf; with causal=False all j are visible
      p[j] = softmax_j(logits[j])
      out[s, h, :] = sum_{j=0}^{L_i-1} p[j] * v[b_start_loc[i]+j, g, :]
    The softmax uses a numerically stable online implementation, intermediate
    accumulation is in float32, and the output is cast back to the input dtype.
    Boundary behaviour: b_seq_len[i] >= 1 always holds, the softmax denominator
    is always positive and there is no fully masked row (under causal masking row
    t sees at least itself); sequences do not affect each other.

    Input/output specification (evaluation dtype is float16 / bfloat16, all
    tensors contiguous):
      q            eval dtype (total_tokens, num_q_heads, head_dim)
      k            eval dtype (total_tokens, num_kv_heads, head_dim)
      v            eval dtype (total_tokens, num_kv_heads, head_dim)
      b_start_loc  int32 (num_seqs) -- exclusive prefix sum of the sequence lengths
      b_seq_len    int32 (num_seqs) -- length of each sequence (>= 1, may all differ)
      returns out  eval dtype (total_tokens, num_q_heads, head_dim)
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (GQA; equality means MHA); Q/K/V share the same head dim and it is >= 16,
    non-power-of-2 is allowed (out-of-range channels must be masked to zero by
    head_dim); total_tokens = sum(b_seq_len).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.
      - The evaluator casts every input tensor to fp32 before calling forward;
        the prefix sum and the sequence lengths are small integers that fp32
        represents exactly, so .to(torch.int32) at the entry recovers them
        losslessly.
      - The maximum sequence length is not an input: an upper bound for the grid
        along the in-sequence position dimension can be derived inside forward
        from int(b_seq_len.max()), and the kernel masks out-of-range rows/columns
        per sequence using L_i.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: contiguous non-paged KV, ragged variable-length batch, GQA,
    causal/non-causal, fp16/bf16 non-quantized inputs; no paged KV cache, no
    prefix-pool indirect addressing, no custom mask, no sliding window, no
    attention sink, no dropout, no LSE output, no MLA absorb form -- those
    variants are left as separate follow-up tasks.
    """
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, b_start_loc, b_seq_len):
        # <<<IMPROVE:forward_stmt_1>>>
        b_start_loc = b_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        b_seq_len = b_seq_len.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        total, H_Q, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = k.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert k.shape[-1] == D and v.shape[-1] == D, "the Q/K/V head dims must be identical"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        scale = self.sm_scale if self.sm_scale is not None else 1.0 / math.sqrt(D)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        B = b_seq_len.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = _pyramidkernel_get_extension().prefill_attention(
            q, k, v, b_start_loc, b_seq_len, float(scale), bool(self.causal)
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
