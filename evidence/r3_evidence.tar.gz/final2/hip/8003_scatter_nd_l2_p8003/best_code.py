import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p8003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor coordinate_overwrite(torch::Tensor data, torch::Tensor indices, torch::Tensor updates);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("coordinate_overwrite", &coordinate_overwrite);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cstdint>
#include <algorithm>

struct Dimensions {
    int64_t size[6];
};

template<typename Vec>
__global__ void copy_vector_payload(const Vec* src, Vec* dst, int64_t count) {
    int64_t step = int64_t(blockDim.x) * int64_t(gridDim.x);
    for (int64_t i = int64_t(blockIdx.x) * int64_t(blockDim.x) + int64_t(threadIdx.x);
         i < count; i += step) {
        dst[i] = src[i];
    }
}

template<typename T>
__global__ void copy_scalar_payload(const T* src, T* dst, int64_t begin, int64_t n) {
    int64_t step = int64_t(blockDim.x) * int64_t(gridDim.x);
    for (int64_t i = begin + int64_t(blockIdx.x) * int64_t(blockDim.x) + int64_t(threadIdx.x);
         i < n; i += step) {
        dst[i] = src[i];
    }
}

template<typename T, typename I, int R>
__global__ void write_payload(const I* indices, const T* updates, T* out,
                              int64_t k_count, int64_t n, Dimensions dims) {
    int64_t step = int64_t(blockDim.x) * int64_t(gridDim.x);
    for (int64_t k = int64_t(blockIdx.x) * int64_t(blockDim.x) + int64_t(threadIdx.x);
         k < k_count; k += step) {
        int64_t offset = 0;
        bool valid = true;
        #pragma unroll
        for (int d = 0; d < R; ++d) {
            I value = indices[k * int64_t(R) + int64_t(d)];
            if (!(value >= I(0) && value < I(dims.size[d]))) {
                valid = false;
                break;
            }
            int64_t coord = static_cast<int64_t>(value);
            offset = offset * dims.size[d] + coord;
        }
        if (valid && offset >= 0 && offset < n) {
            out[offset] = updates[k];
        }
    }
}

template<typename T, typename I, int R>
__global__ void fused_small_payload(const T* data, const I* indices,
                                    const T* updates, T* out,
                                    int64_t k_count, int64_t n, Dimensions dims) {
    for (int64_t i = int64_t(threadIdx.x); i < n; i += int64_t(blockDim.x)) {
        out[i] = data[i];
    }
    __syncthreads();
    for (int64_t k = int64_t(threadIdx.x); k < k_count; k += int64_t(blockDim.x)) {
        int64_t offset = 0;
        bool valid = true;
        #pragma unroll
        for (int d = 0; d < R; ++d) {
            I value = indices[k * int64_t(R) + int64_t(d)];
            if (!(value >= I(0) && value < I(dims.size[d]))) {
                valid = false;
                break;
            }
            int64_t coord = static_cast<int64_t>(value);
            offset = offset * dims.size[d] + coord;
        }
        if (valid && offset >= 0 && offset < n) {
            out[offset] = updates[k];
        }
    }
}

static void check_launch() {
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "coordinate_overwrite HIP launch failed: ",
                hipGetErrorString(err));
}

static unsigned bounded_blocks(int64_t work_items, int64_t threads) {
    int64_t needed = (work_items + threads - 1) / threads;
    int64_t bounded = std::min<int64_t>(needed, 80 * 8);
    return static_cast<unsigned>(std::max<int64_t>(bounded, 1));
}

template<typename T, typename I>
void launch_fused_small(torch::Tensor data, torch::Tensor indices,
                        torch::Tensor updates, torch::Tensor out,
                        int64_t k, int64_t n, int64_t rank, Dimensions dims,
                        hipStream_t stream) {
    const T* dp = reinterpret_cast<const T*>(data.data_ptr());
    const I* ip = reinterpret_cast<const I*>(indices.data_ptr());
    const T* up = reinterpret_cast<const T*>(updates.data_ptr());
    T* op = reinterpret_cast<T*>(out.data_ptr());

    #define FUSED_CASE(R) case R: \
        hipLaunchKernelGGL((fused_small_payload<T, I, R>), dim3(1), dim3(256), 0, stream, \
                           dp, ip, up, op, k, n, dims); \
        break

    switch (rank) {
        FUSED_CASE(1);
        FUSED_CASE(2);
        FUSED_CASE(3);
        FUSED_CASE(4);
        FUSED_CASE(5);
        FUSED_CASE(6);
        default:
            TORCH_CHECK(false, "unsupported rank");
    }
    #undef FUSED_CASE
    check_launch();
}

template<typename T, typename I>
void launch_writes(torch::Tensor indices, torch::Tensor updates, torch::Tensor out,
                   int64_t k, int64_t n, int64_t rank, Dimensions dims,
                   hipStream_t stream) {
    const I* ip = reinterpret_cast<const I*>(indices.data_ptr());
    const T* up = reinterpret_cast<const T*>(updates.data_ptr());
    T* op = reinterpret_cast<T*>(out.data_ptr());

    int64_t threads = (k < 1024) ? 64 : 256;
    unsigned blocks = bounded_blocks(k, threads);

    #define WRITE_CASE(R) case R: \
        hipLaunchKernelGGL((write_payload<T, I, R>), dim3(blocks), dim3(threads), 0, stream, \
                           ip, up, op, k, n, dims); \
        break

    switch (rank) {
        WRITE_CASE(1);
        WRITE_CASE(2);
        WRITE_CASE(3);
        WRITE_CASE(4);
        WRITE_CASE(5);
        WRITE_CASE(6);
        default:
            TORCH_CHECK(false, "unsupported rank");
    }

    #undef WRITE_CASE
    check_launch();
}

template<typename T>
void launch_payload(torch::Tensor data, torch::Tensor indices, torch::Tensor updates,
                    torch::Tensor out, Dimensions dims, hipStream_t stream) {
    int64_t n = static_cast<int64_t>(data.numel());
    int64_t k = static_cast<int64_t>(updates.numel());

    if (k != n && n <= 4096) {
        if (indices.scalar_type() == at::kLong) {
            launch_fused_small<T, int64_t>(data, indices, updates, out, k, n,
                                           data.dim(), dims, stream);
        } else {
            launch_fused_small<T, float>(data, indices, updates, out, k, n,
                                         data.dim(), dims, stream);
        }
        return;
    }

    if (k != n) {
        const T* src = reinterpret_cast<const T*>(data.data_ptr());
        T* dst = reinterpret_cast<T*>(out.data_ptr());

        constexpr int64_t width = sizeof(T) == 4 ? 4 : 8;
        bool aligned = ((reinterpret_cast<uintptr_t>(src) % 16u) == 0u) &&
                       ((reinterpret_cast<uintptr_t>(dst) % 16u) == 0u);

        if (aligned) {
            int64_t vector_count = n / width;
            int64_t copied = vector_count * width;

            if (vector_count > 0) {
                unsigned blocks = bounded_blocks(vector_count, 256);
                hipLaunchKernelGGL((copy_vector_payload<uint4>),
                                   dim3(blocks), dim3(256), 0, stream,
                                   reinterpret_cast<const uint4*>(src),
                                   reinterpret_cast<uint4*>(dst),
                                   vector_count);
                check_launch();
            }

            if (copied < n) {
                int64_t tail = n - copied;
                unsigned blocks = bounded_blocks(tail, 256);
                hipLaunchKernelGGL((copy_scalar_payload<T>),
                                   dim3(blocks), dim3(256), 0, stream,
                                   src, dst, copied, n);
                check_launch();
            }
        } else {
            unsigned blocks = bounded_blocks(n, 256);
            hipLaunchKernelGGL((copy_scalar_payload<T>),
                               dim3(blocks), dim3(256), 0, stream,
                               src, dst, int64_t(0), n);
            check_launch();
        }
    }

    if (indices.scalar_type() == at::kLong) {
        launch_writes<T, int64_t>(indices, updates, out, k, n,
                                  data.dim(), dims, stream);
    } else {
        launch_writes<T, float>(indices, updates, out, k, n,
                                data.dim(), dims, stream);
    }
}

torch::Tensor coordinate_overwrite(torch::Tensor data, torch::Tensor indices, torch::Tensor updates) {
    TORCH_CHECK(data.is_cuda() && indices.is_cuda() && updates.is_cuda(),
                "inputs must be on GPU");
    TORCH_CHECK(data.device() == indices.device() &&
                data.device() == updates.device(),
                "device mismatch");
    TORCH_CHECK(data.is_contiguous() && indices.is_contiguous() &&
                updates.is_contiguous(),
                "inputs must be contiguous");

    int64_t rank = static_cast<int64_t>(data.dim());
    TORCH_CHECK(rank >= 1 && rank <= 6, "unsupported rank");
    TORCH_CHECK(indices.dim() == 2 && indices.size(1) == rank,
                "invalid coordinate shape");
    TORCH_CHECK(updates.dim() == 1 &&
                updates.size(0) == indices.size(0),
                "invalid updates shape");
    TORCH_CHECK(updates.scalar_type() == data.scalar_type(),
                "payload dtype mismatch");
    TORCH_CHECK(data.scalar_type() == at::kFloat ||
                data.scalar_type() == at::kHalf ||
                data.scalar_type() == at::kBFloat16,
                "unsupported payload dtype");
    TORCH_CHECK(indices.scalar_type() == at::kLong ||
                indices.scalar_type() == at::kFloat,
                "unsupported index dtype");
    TORCH_CHECK(updates.numel() >= 1 &&
                updates.numel() <= data.numel(),
                "invalid update count");

    Dimensions dims{};
    for (int64_t d = 0; d < rank; ++d) {
        TORCH_CHECK(data.size(d) >= 1, "empty dimension");
        dims.size[d] = static_cast<int64_t>(data.size(d));
    }

    c10::cuda::CUDAGuard guard(data.device());
    hipStream_t stream =
        c10::cuda::getCurrentCUDAStream(data.get_device()).stream();

    auto out = torch::empty(data.sizes(), data.options());

    if (data.scalar_type() == at::kFloat) {
        launch_payload<uint32_t>(data, indices, updates, out, dims, stream);
    } else {
        launch_payload<uint16_t>(data, indices, updates, out, dims, stream);
    }

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    ScatterND: the index-write family that overwrites positions of `data`
    with `updates` according to integer index tuples.

    Semantics: data has shape (S_0, ..., S_{r-1}) where r is its rank; indices is
    an int64 tensor of shape (K, r) -- each row is a full coordinate tuple that
    picks exactly one position in data; updates has shape (K,) and the same dtype
    as data. The output out has the same shape and dtype as data:
        out[indices[k,0], ..., indices[k,r-1]] = updates[k]
            (hit positions: overwritten, the original value is discarded and
             replaced by the corresponding element of updates)
        all other positions out[i_0, ..., i_{r-1}] = data[i_0, ..., i_{r-1}]
            (misses: the original value is preserved bit-for-bit)
    The write semantics is overwrite, not accumulate; the K coordinate tuples are
    pairwise distinct (the generator samples without replacement), so every data
    element is written at most once. Which write wins for duplicate coordinate
    tuples is undefined behaviour (mainstream frameworks leave the write order
    for duplicate indices undefined either way), and duplicate tuples are outside
    this task's input domain -- the implementation need not define behaviour for
    them, and must not let deduplication / sorting or any other preprocessing
    change the overwrite result for distinct tuples.

    Input/output specification:
        data    float32 / float16 / bfloat16, contiguous, ndim in [1, 6],
                every dimension >= 1, total element count <= 2^23; values are
                ordinary randn magnitude (no inf/NaN)
        indices int64 (K, r) with r = data rank, 1 <= K <= the total element
                count of data; every index value lies in [0, S_d) and the K
                coordinate tuples are pairwise distinct
        updates same dtype as data, shape (K,), contiguous
        out     a single tensor, same shape / dtype as data, contiguous -- this
                operator is naturally single-output, so no multi-output packing is
                needed. forward must return a single tensor (the evaluator
                compares .shape / allclose on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (indices are small non-negative integers < 2^24 and exactly
        representable in fp32, so they are recovered losslessly; fp16/bf16 ->
        fp32 is also lossless). The offline final audit passes inputs natively in
        their declared dtype -- the implementation must be correct for both.

    Boundary behaviour: K=1, K equal to the total element count of data (a full
    permutation, every element written), ndim=1 (indices shaped (K, 1)), and
    shapes with non-power-of-two / prime lengths or axes of length 1 must all be
    handled correctly; the output must be a fresh tensor and must not modify
    data / indices / updates in place.

    Implementation constraints (violations are scored as failures):
        - The core computation (r-dimensional coordinate -> linear offset address
          computation, reading updates, and moving the original values out for
          miss positions) must be completed with a HIP kernel inside the
          submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Pure-movement contract: miss positions match data bit-for-bit and hit
          positions match updates bit-for-bit (bit patterns preserved); no
          numeric transformation may be introduced.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.scatter / .scatter( / .scatter_( / scatter_add / scatter_reduce /
    index_put / torch.put( / .put_( / index_copy / torch_scatter / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, data, indices, updates):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().coordinate_overwrite(data, indices, updates)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return out
        # <<<END_IMPROVE>>>
