import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2010_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor batchnorm_forward(
    torch::Tensor x, torch::Tensor scale, torch::Tensor bias,
    torch::Tensor mean, torch::Tensor variance,
    double eps, double momentum, bool training);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("batchnorm_forward", &batchnorm_forward, "HIP batch normalization forward");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <cstdint>
#include <cmath>

template <typename T>
__device__ __forceinline__ float bn_load(const T* p, int64_t i) {
    return static_cast<float>(p[i]);
}

template <typename T>
__device__ __forceinline__ void bn_store(T* p, int64_t i, float v) {
    p[i] = static_cast<T>(v);
}

template <typename T>
__global__ void bn_inference_kernel(
    const T* __restrict__ x, const T* __restrict__ scale,
    const T* __restrict__ bias, const T* __restrict__ mean,
    const T* __restrict__ variance, T* __restrict__ out,
    int64_t numel, int64_t c, int64_t hw, float eps) {
    int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= numel) return;
    int64_t ch = (i / hw) % c;
    float v = (bn_load(x, i) - bn_load(mean, ch)) *
              rsqrtf(bn_load(variance, ch) + eps) *
              bn_load(scale, ch) + bn_load(bias, ch);
    bn_store(out, i, v);
}

template <typename T>
__global__ void bn_stats_kernel(
    const T* __restrict__ x, float* __restrict__ means,
    float* __restrict__ vars, int64_t n, int64_t c, int64_t hw) {
    int64_t ch = static_cast<int64_t>(blockIdx.x);
    if (ch >= c) return;

    extern __shared__ float smem[];
    int tid = static_cast<int>(threadIdx.x);
    int64_t m = n * hw;
    float sum = 0.0f;

    for (int64_t j = tid; j < m; j += static_cast<int64_t>(blockDim.x)) {
        int64_t ni = j / hw;
        int64_t r = j - ni * hw;
        int64_t off = ni * c * hw + ch * hw + r;
        sum += bn_load(x, off);
    }
    smem[tid] = sum;
    __syncthreads();

    for (int stride = static_cast<int>(blockDim.x) >> 1; stride > 0; stride >>= 1) {
        if (tid < stride) smem[tid] += smem[tid + stride];
        __syncthreads();
    }

    float mu = smem[0] / static_cast<float>(m);
    if (tid == 0) means[ch] = mu;
    __syncthreads();

    float sq = 0.0f;
    for (int64_t j = tid; j < m; j += static_cast<int64_t>(blockDim.x)) {
        int64_t ni = j / hw;
        int64_t r = j - ni * hw;
        int64_t off = ni * c * hw + ch * hw + r;
        float d = bn_load(x, off) - mu;
        sq += d * d;
    }
    smem[tid] = sq;
    __syncthreads();

    for (int stride = static_cast<int>(blockDim.x) >> 1; stride > 0; stride >>= 1) {
        if (tid < stride) smem[tid] += smem[tid + stride];
        __syncthreads();
    }
    if (tid == 0) vars[ch] = smem[0] / static_cast<float>(m);
}

template <typename T>
__global__ void bn_training_output_kernel(
    const T* __restrict__ x, const T* __restrict__ scale,
    const T* __restrict__ bias, const T* __restrict__ running_mean,
    const T* __restrict__ running_var, const float* __restrict__ means,
    const float* __restrict__ vars, float* __restrict__ out,
    int64_t numel, int64_t c, int64_t hw, int64_t m,
    float eps, float momentum) {
    int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;

    if (i < numel) {
        int64_t ch = (i / hw) % c;
        float mu = means[ch];
        float y = (bn_load(x, i) - mu) * rsqrtf(vars[ch] + eps) *
                  bn_load(scale, ch) + bn_load(bias, ch);
        out[i] = y;
    }

    if (i < c) {
        float mu = means[i];
        float var = vars[i];
        float unbiased = var * (static_cast<float>(m) /
                                static_cast<float>(m - 1));
        int64_t base = numel;
        out[base + i] = mu;
        out[base + c + i] = rsqrtf(var + eps);
        out[base + 2 * c + i] =
            (1.0f - momentum) * bn_load(running_mean, i) + momentum * mu;
        out[base + 3 * c + i] =
            (1.0f - momentum) * bn_load(running_var, i) + momentum * unbiased;
    }
}

static inline void bn_check_launch() {
    hipError_t e = hipGetLastError();
    TORCH_CHECK(e == hipSuccess, "HIP batchnorm kernel launch failed: ",
                hipGetErrorString(e));
}

torch::Tensor batchnorm_forward(
    torch::Tensor x, torch::Tensor scale, torch::Tensor bias,
    torch::Tensor mean, torch::Tensor variance,
    double eps, double momentum, bool training) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous(), "x must be contiguous HIP tensor");
    TORCH_CHECK(scale.is_cuda() && bias.is_cuda() &&
                mean.is_cuda() && variance.is_cuda(),
                "all inputs must be HIP tensors");
    TORCH_CHECK(scale.is_contiguous() && bias.is_contiguous() &&
                mean.is_contiguous() && variance.is_contiguous(),
                "parameters must be contiguous");
    TORCH_CHECK(x.dim() == 4, "x must be NCHW");
    TORCH_CHECK(scale.dim() == 4 && bias.dim() == 4 &&
                mean.dim() == 4 && variance.dim() == 4,
                "parameters must be 4-dimensional");
    TORCH_CHECK(x.scalar_type() == scale.scalar_type() &&
                x.scalar_type() == bias.scalar_type() &&
                x.scalar_type() == mean.scalar_type() &&
                x.scalar_type() == variance.scalar_type(),
                "all inputs must have the same dtype");
    TORCH_CHECK(scale.size(0) == 1 && scale.size(2) == 1 &&
                scale.size(3) == 1 && scale.size(1) == x.size(1) &&
                bias.sizes() == scale.sizes() &&
                mean.sizes() == scale.sizes() &&
                variance.sizes() == scale.sizes(),
                "invalid parameter shapes");

    int64_t n = static_cast<int64_t>(x.size(0));
    int64_t c = static_cast<int64_t>(x.size(1));
    int64_t h = static_cast<int64_t>(x.size(2));
    int64_t w = static_cast<int64_t>(x.size(3));
    int64_t hw = h * w;
    int64_t numel = n * c * hw;
    int64_t m = n * hw;
    TORCH_CHECK(m > 0, "input must contain elements");

    if (!training) {
        auto out = torch::empty_like(x);
        constexpr int threads = 256;
        int blocks = static_cast<int>((numel + threads - 1) / threads);
        TORCH_CHECK(blocks > 0, "invalid launch geometry");

        AT_DISPATCH_FLOATING_TYPES_AND2(
            at::ScalarType::Half, at::ScalarType::BFloat16,
            x.scalar_type(), "batchnorm_inference", [&] {
                bn_inference_kernel<scalar_t><<<blocks, threads>>>(
                    x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(),
                    bias.data_ptr<scalar_t>(), mean.data_ptr<scalar_t>(),
                    variance.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(),
                    numel, c, hw, static_cast<float>(eps));
            });
        bn_check_launch();
        return out;
    }

    TORCH_CHECK(m >= 2, "the training variant requires N*H*W >= 2");
    TORCH_CHECK(x.scalar_type() == at::kFloat,
                "training requires float32 input");

    auto opts = x.options().dtype(torch::kFloat32);
    auto batch_mean = torch::empty({c}, opts);
    auto batch_var = torch::empty({c}, opts);
    auto out = torch::empty({numel + 4 * c}, opts);

    int stats_threads = 256;
    if (m <= 64) stats_threads = 64;
    else if (m <= 128) stats_threads = 128;

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "batchnorm_training_stats", [&] {
            bn_stats_kernel<scalar_t><<<
                static_cast<unsigned int>(c), stats_threads,
                static_cast<size_t>(stats_threads) * sizeof(float)>>>(
                x.data_ptr<scalar_t>(), batch_mean.data_ptr<float>(),
                batch_var.data_ptr<float>(), n, c, hw);
        });
    bn_check_launch();

    constexpr int output_threads = 256;
    int64_t total = numel > c ? numel : c;
    int output_blocks = static_cast<int>(
        (total + output_threads - 1) / output_threads);
    TORCH_CHECK(output_blocks > 0, "invalid launch geometry");

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "batchnorm_training_output", [&] {
            bn_training_output_kernel<scalar_t><<<
                output_blocks, output_threads>>>(
                x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(),
                bias.data_ptr<scalar_t>(), mean.data_ptr<scalar_t>(),
                variance.data_ptr<scalar_t>(), batch_mean.data_ptr<float>(),
                batch_var.data_ptr<float>(), out.data_ptr<float>(),
                numel, c, hw, m, static_cast<float>(eps),
                static_cast<float>(momentum));
        });
    bn_check_launch();
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    BatchNorm forward family: inference affine (inference) and training batch
    statistics (training).

    The input is x (N, C, H, W), NCHW contiguous; scale / bias / mean / variance are
    all (1, C, 1, 1) and broadcast along the channel dimension. Reduction dimension:
    per-channel, computing the statistics of every channel c over the three
    dimensions (N, H, W), with m = N*H*W elements per channel. The __init__ argument
    variant selects one of two paths (eps defaults to 1e-5 and momentum to 0.1; both
    are scalar hyper-parameters only):

        "inference": the mean and the variance are given as inputs, element-wise
                     affine (float32 intermediate computation):
            y = scale * (x - mean) / sqrt(variance + eps) + bias
        "training": batch statistics + affine + running update (float32
                    throughout):
            batch_mean_c = sum_{n,h,w} x[n,c,h,w] / m                    (biased batch mean)
            batch_var_c  = sum_{n,h,w} (x[n,c,h,w] - batch_mean_c)^2 / m (biased batch variance)
            saved_mean         = batch_mean                              (shape (1,C,1,1))
            saved_inv_variance = 1 / sqrt(batch_var + eps)               (shape (1,C,1,1))
            y = scale * (x - saved_mean) * saved_inv_variance + bias
            next_running_mean = (1 - momentum) * mean + momentum * batch_mean
            next_running_var  = (1 - momentum) * variance
                                + momentum * batch_var * m / (m - 1)
            In the training variant the 4th/5th forward arguments are the running
            statistics of the previous step (prev_running_mean / prev_running_var);
            the running variance update uses the unbiased batch variance (the
            m/(m-1) correction, hence the requirement m >= 2) -- this is the
            standard PyTorch / cuDNN / MIOpen training-BN convention.

    The forward signature is (x, scale, bias, mean, variance) for both variants: in
    inference the 4th/5th arguments are the given mean / variance, in training they
    are prev_running_mean / prev_running_var.

    Single-tensor output protocol (forward must return a single tensor; the
    evaluator compares a single output):
        "inference": returns y itself, shape (N, C, H, W), same dtype as x;
        "training" : returns a one-dimensional float32 packed tensor of length
                     N*C*H*W + 4*C; the five logical outputs are each cast to
                     float32, reshaped with reshape(-1) and torch.cat'ed in the
                     sample-output order, with the segment protocol (half-open
                     intervals):
            [0,            N*C*H*W)      y
            [N*C*H*W,      N*C*H*W + C)  saved_mean
            [N*C*H*W + C,  N*C*H*W + 2C) saved_inv_variance
            [N*C*H*W + 2C, N*C*H*W + 3C) next_running_mean
            [N*C*H*W + 3C, N*C*H*W + 4C) next_running_var

    Input/output specification:
        x        float32 (always float32 for training) / float16 / bfloat16
                 (inference only), (N, C, H, W), contiguous, N/C/H/W >= 1
        scale    same dtype as x, (1, C, 1, 1), contiguous
        bias     same dtype as x, (1, C, 1, 1), contiguous
        mean     same dtype as x, (1, C, 1, 1), contiguous (inference: the given
                 mean, any real value; training: prev_running_mean)
        variance same dtype as x, (1, C, 1, 1), contiguous, always positive
                 (inference: the given variance; training: prev_running_var)
        out      inference: (N, C, H, W), same dtype as x; training: one-dimensional
                 float32 of length N*C*H*W + 4*C (the five-segment packing protocol
                 above)
        The inputs are the usual randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-channel reduction statistics, rsqrt, the
          affine, and the running update) must be completed inside the submitted
          file with a HIP kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, the normalization and the running update all use float32
          intermediates; the y of inference is cast back to the x dtype; all five
          training segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.BatchNorm1d / torch.nn.BatchNorm2d /
    torch.nn.BatchNorm3d / torch.nn.SyncBatchNorm /
    torch.nn.functional.batch_norm / torch.batch_norm /
    torch.native_batch_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "training", eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("inference", "training"), "variant must be one of inference / training"
        assert eps > 0, "eps must be positive"
        assert 0.0 <= momentum <= 1.0, "momentum must be in [0, 1]"
        self.variant = variant
        self.eps = float(eps)
        self.momentum = float(momentum)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias, mean, variance):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().batchnorm_forward(
            x, scale, bias, mean, variance,
            float(self.eps), float(self.momentum),
            self.variant == "training")
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # <<<END_IMPROVE>>>
