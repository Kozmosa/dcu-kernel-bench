import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor fused_mul_add(torch::Tensor x, pybind11::object a, pybind11::object b);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_mul_add", &fused_mul_add);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <torch/csrc/autograd/python_variable.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <algorithm>
#include <cstdint>

template<typename T>
__global__ void fused_kernel(
    const T* __restrict__ x, T* __restrict__ out,
    const T* __restrict__ a, const T* __restrict__ b,
    float av, float bv, bool a_single, bool b_single, int64_t n) {
    const int64_t step = static_cast<int64_t>(blockDim.x) * gridDim.x;
    for (int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
         i < n; i += step) {
        const float ai = a ? static_cast<float>(a[a_single ? int64_t(0) : i]) : av;
        const float bi = b ? static_cast<float>(b[b_single ? int64_t(0) : i]) : bv;
        const float xi = static_cast<float>(x[i]);
        // Round multiplication to float32 before addition, as in the reference.
        volatile float product = ai * xi;
        out[i] = static_cast<T>(product + bi);
    }
}

struct Operand {
    torch::Tensor tensor;
    float value = 0.0f;
    bool single = false;
};

static Operand parse_operand(const pybind11::object& obj, const torch::Tensor& x) {
    Operand operand;
    if (THPVariable_Check(obj.ptr())) {
        operand.tensor = obj.cast<torch::Tensor>();
        const auto& t = operand.tensor;
        TORCH_CHECK(t.device() == x.device(), "Operands must be on the same device as x");
        TORCH_CHECK(t.scalar_type() == x.scalar_type(), "Operands must have the dtype of x");
        TORCH_CHECK(t.is_contiguous(), "Operands must be contiguous");
        TORCH_CHECK(t.numel() == 1 || t.sizes() == x.sizes(),
                    "Operands must contain one element or have the shape of x");
        operand.single = t.numel() == 1;
    } else {
        TORCH_CHECK(pybind11::isinstance<pybind11::float_>(obj) ||
                    pybind11::isinstance<pybind11::int_>(obj),
                    "Operands must be tensors or Python numeric scalars");
        operand.value = static_cast<float>(obj.cast<double>());
    }
    return operand;
}

torch::Tensor fused_mul_add(torch::Tensor x, pybind11::object a, pybind11::object b) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous(), "x must be a contiguous GPU tensor");
    TORCH_CHECK(x.scalar_type() == at::kFloat || x.scalar_type() == at::kHalf ||
                x.scalar_type() == at::kBFloat16, "Unsupported dtype");
    c10::cuda::CUDAGuard guard(x.device());
    Operand aa = parse_operand(a, x);
    Operand bb = parse_operand(b, x);
    auto out = torch::empty_like(x);
    const int64_t n = x.numel();
    if (n == 0) return out;
    const int blocks = static_cast<int>(std::min<int64_t>((n - 1) / 256 + 1, 4096));
    const auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  x.scalar_type(), "fused_mul_add_hip", [&] {
        const scalar_t* ap = aa.tensor.defined() ? aa.tensor.data_ptr<scalar_t>() : nullptr;
        const scalar_t* bp = bb.tensor.defined() ? bb.tensor.data_ptr<scalar_t>() : nullptr;
        fused_kernel<scalar_t><<<blocks, 256, 0, stream.stream()>>>(
            x.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(),
            ap, bp, aa.value, bb.value, aa.single, bb.single, n);
    });
    const hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess, "HIP kernel launch failed: ", hipGetErrorString(error));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Element-wise fused multiply-add: out = a * x + b.

    (1) Operator semantics: for every element i of x,
    out[i] = a_i * x[i] + b_i. a and b each independently take one of the
    following three forms (any combination is allowed, e.g. a a scalar while b is a
    same-shape tensor):
      1. a Python float / int scalar: a_i = a (the value is broadcast to every
         element of x);
      2. a single-element tensor (numel == 1, any shape, e.g. (1,)): a_i = its only
         element (broadcast);
      3. a tensor with the same shape as x (numel == x.numel()): a_i = the
         corresponding element of a.
    x is a floating-point tensor of arbitrary rank and shape (including
    non-powers-of-two and prime sizes). Intermediate computation runs in float32
    (x / a / b are first promoted to float32, then multiplied and added), and the
    final result is cast back to the dtype of x. Boundary behaviour: this operator
    has no integer tensor inputs and no indexing/length-like semantics; when a and
    b are both scalars the output still has the same shape as x.

    (2) Input/output specification:
      - x: float16 / bfloat16 / float32 tensor, arbitrary shape, contiguous;
      - a, b: one of the three forms above; when a tensor, contiguous with the
        same dtype as x;
      - returns: a new tensor with the same shape and dtype as x (out-of-place; no
        input may be overwritten in place).

    (3) Implementation constraints (violations are scored as failures):
      - The core computation (the multiply-add) must be completed inside the
        submitted file with a self-written HIP kernel: a single kernel and a
        single read-compute-write pass; splitting it into a multiply kernel followed
        by an add kernel is forbidden;
      - When a / b is a scalar or a single-element tensor it must take part in the
        kernel as a broadcast argument and must not be materialized into a
        temporary big tensor with the same shape as x;
      - The __init__ and forward signatures of ModelNew must not be changed;
      - Use float32 for intermediate computation; cast the output back to the dtype
        of x.

    (4) Forbidden list and target hardware:
      - Directly completing this task's computation with ATen shortcuts is
        forbidden: torch.addcmul (including the .addcmul / .addcmul_ methods),
        torch.add, torch.mul, and tensor methods with their in-place forms such as
        .add( / .mul( / .add_( / .mul_; calling a same-functionality entry point
        provided by any precompiled operator library is also forbidden (the final
        static audit does substring matching on the code outside
        docstrings/comments);
      - Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, x, a, b):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().fused_mul_add(x, a, b)
        # <<<END_IMPROVE>>>
