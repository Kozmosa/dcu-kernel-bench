import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1014_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor hstu_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor offsets, torch::Tensor targets,
    int64_t n, double alpha, bool causal, int64_t a, int64_t c);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("hstu_forward", &hstu_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <limits>

struct Layout {
    int64_t s0, s1, s2;
};

__device__ inline int64_t position(int64_t i, int64_t c, int64_t cap) {
    int64_t r = c > 0 ? (i >= c ? i - c + 1 : 0) : i;
    return r < cap ? r : cap;
}

template<class T>
__global__ void hstu_kernel(
    const T* q, const T* k, const T* v, T* out,
    const int64_t* offsets, const int32_t* targets,
    Layout qs, Layout ks, Layout vs,
    int64_t os, int64_t ts, int64_t batch, int64_t total,
    int64_t heads, int64_t dim, int64_t vd, int64_t n,
    float alpha, bool causal, int64_t a, int64_t c,
    int64_t qt, int64_t vt, int64_t jobs) {
    __shared__ float sq[16][33];
    __shared__ float sk[16][33];
    __shared__ float weights[16][16];
    __shared__ float sv[16][32];
    const int64_t tid = threadIdx.x;
    for (int64_t job = blockIdx.x; job < jobs; job += int64_t(gridDim.x)) {
        int64_t z = job;
        const int64_t vb = (z % vt) * 256; z /= vt;
        const int64_t ib = (z % qt) * 16; z /= qt;
        const int64_t h = z % heads;
        const int64_t b = z / heads;
        if (b >= batch) continue;
        const int64_t s = offsets[b * os];
        const int64_t e = offsets[(b + 1) * os];
        if (s < 0 || e < s || e > total) continue;
        const int64_t len = e - s;
        if (ib >= len) continue;
        const int64_t g = targets[b * ts];
        const int64_t cap = (c > 0 ? len - c + 1 : len) - g;
        float acc[16];
        #pragma unroll
        for (int t = 0; t < 16; ++t) acc[t] = 0.0f;
        const int64_t i = ib + tid / 16;
        const int64_t mi = position(i, c, cap);
        int64_t key_end = len;
        if (causal && c == 0) key_end = min(len, ib + 16);
        for (int64_t jb = 0; jb < key_end; jb += 16) {
            float dot = 0.0f;
            for (int64_t db = 0; db < dim; db += 32) {
                for (int64_t t = tid; t < 512; t += 256) {
                    const int64_t r = t / 32, d = db + t % 32;
                    sq[r][t % 32] = ib + r < len && d < dim
                        ? float(q[(s + ib + r) * qs.s0 + h * qs.s1 + d * qs.s2]) : 0.0f;
                    sk[r][t % 32] = jb + r < len && d < dim
                        ? float(k[(s + jb + r) * ks.s0 + h * ks.s1 + d * ks.s2]) : 0.0f;
                }
                __syncthreads();
                #pragma unroll
                for (int d = 0; d < 32; ++d) {
                    const float qval = sq[tid / 16][d];
                    dot = fmaf(qval, sk[tid % 16][d], dot);
                }
                __syncthreads();
            }
            const int64_t j = jb + tid % 16;
            const int64_t mj = position(j, c, cap);
            int64_t distance = mi - mj;
            if (!causal && distance < 0) distance = -distance;
            bool valid = (i == j || distance > 0) && (a <= 0 || distance <= a);
            valid = valid || (c > 0 && mi == 0 && mj < cap);
            float w = 0.0f;
            if (i < len && j < len && valid) {
                float x = alpha * dot;
                w = (x / (1.0f + expf(-x))) / float(n);
            }
            weights[tid / 16][tid % 16] = w;
            __syncthreads();
            for (int64_t chunk = 0; chunk < 8 && vb + chunk * 32 < vd; ++chunk) {
                const int64_t d = vb + chunk * 32 + tid % 32;
                for (int64_t t = tid; t < 512; t += 256) {
                    const int64_t r = t / 32;
                    const int64_t col = vb + chunk * 32 + t % 32;
                    sv[r][t % 32] = jb + r < len && col < vd
                        ? float(v[(s + jb + r) * vs.s0 + h * vs.s1 + col * vs.s2]) : 0.0f;
                }
                __syncthreads();
                #pragma unroll
                for (int half = 0; half < 2; ++half) {
                    const int64_t r = tid / 32 + half * 8;
                    float sum = acc[chunk * 2 + half];
                    #pragma unroll
                    for (int jlocal = 0; jlocal < 16; ++jlocal)
                        sum = fmaf(weights[r][jlocal], sv[jlocal][tid % 32], sum);
                    acc[chunk * 2 + half] = sum;
                }
                __syncthreads();
            }
        }
        for (int64_t chunk = 0; chunk < 8 && vb + chunk * 32 < vd; ++chunk) {
            const int64_t d = vb + chunk * 32 + tid % 32;
            #pragma unroll
            for (int half = 0; half < 2; ++half) {
                const int64_t row = ib + tid / 32 + half * 8;
                if (row < len && d < vd)
                    out[((s + row) * heads + h) * vd + d] = T(acc[chunk * 2 + half]);
            }
        }
        __syncthreads();
    }
}

torch::Tensor hstu_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor offsets, torch::Tensor targets,
    int64_t n, double alpha, bool causal, int64_t a, int64_t c) {
    TORCH_CHECK(q.is_cuda(), "q must be on GPU");
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(k.device() == q.device() && v.device() == q.device() &&
                offsets.device() == q.device() && targets.device() == q.device(),
                "all tensors must share a device");
    TORCH_CHECK(q.dim() == 3 && k.dim() == 3 && v.dim() == 3, "expected rank-three Q/K/V");
    TORCH_CHECK(q.sizes() == k.sizes() && q.size(0) == v.size(0) &&
                q.size(1) == v.size(1), "incompatible Q/K/V shapes");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() && q.scalar_type() == v.scalar_type(),
                "Q/K/V dtypes must match");
    TORCH_CHECK(q.scalar_type() == at::kHalf || q.scalar_type() == at::kBFloat16 ||
                q.scalar_type() == at::kFloat,
                "Q/K/V must be float16, bfloat16 or float32");
    TORCH_CHECK(offsets.dim() == 1 && targets.dim() == 1 &&
                offsets.scalar_type() == at::kLong && targets.scalar_type() == at::kInt &&
                offsets.numel() == targets.numel() + 1, "invalid sequence metadata");
    TORCH_CHECK(n >= 0 && c >= 0 && q.size(2) > 0, "invalid dimensions");
    auto out = torch::empty(v.sizes(), v.options());
    if (out.numel() == 0) return out;
    TORCH_CHECK(n > 0 && targets.numel() > 0, "nonempty output requires sequences");
    const int64_t qt = n / 16 + (n % 16 != 0);
    const int64_t vt = v.size(2) / 256 + (v.size(2) % 256 != 0);
    int64_t jobs = targets.numel();
    for (int64_t factor : {q.size(1), qt, vt}) {
        TORCH_CHECK(factor > 0 && jobs <= std::numeric_limits<int64_t>::max() / factor,
                    "launch work count overflow");
        jobs *= factor;
    }
    hipDeviceProp_t prop;
    auto status = hipGetDeviceProperties(&prop, q.get_device());
    TORCH_CHECK(status == hipSuccess, hipGetErrorString(status));
    TORCH_CHECK(prop.maxThreadsPerBlock >= 256 && prop.sharedMemPerBlock >= sizeof(float) * (16*33 + 16*33 + 16*16 + 16*32),
                "device has insufficient kernel resources");
    const int64_t blocks = std::min(jobs, std::min(int64_t(prop.maxGridSize[0]),
                                                   int64_t(prop.multiProcessorCount) * 8));
    TORCH_CHECK(blocks > 0, "invalid launch grid");
    Layout qs{q.stride(0), q.stride(1), q.stride(2)};
    Layout ks{k.stride(0), k.stride(1), k.stride(2)};
    Layout vs{v.stride(0), v.stride(1), v.stride(2)};
    auto stream = at::cuda::getCurrentCUDAStream(q.get_device());
    AT_DISPATCH_SWITCH(q.scalar_type(), "hstu_forward",
        AT_DISPATCH_CASE(at::ScalarType::Half, [&] {
            hstu_kernel<scalar_t><<<blocks, 256, 0, stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(), offsets.data_ptr<int64_t>(), targets.data_ptr<int32_t>(),
                qs, ks, vs, offsets.stride(0), targets.stride(0), targets.numel(),
                q.size(0), q.size(1), q.size(2), v.size(2), n, float(alpha),
                causal, a, c, qt, vt, jobs);
        })
        AT_DISPATCH_CASE(at::ScalarType::BFloat16, [&] {
            hstu_kernel<scalar_t><<<blocks, 256, 0, stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(), offsets.data_ptr<int64_t>(), targets.data_ptr<int32_t>(),
                qs, ks, vs, offsets.stride(0), targets.stride(0), targets.numel(),
                q.size(0), q.size(1), q.size(2), v.size(2), n, float(alpha),
                causal, a, c, qt, vt, jobs);
        })
        AT_DISPATCH_CASE(at::ScalarType::Float, [&] {
            hstu_kernel<scalar_t><<<blocks, 256, 0, stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(), offsets.data_ptr<int64_t>(), targets.data_ptr<int32_t>(),
                qs, ks, vs, offsets.stride(0), targets.stride(0), targets.numel(),
                q.size(0), q.size(1), q.size(2), v.size(2), n, float(alpha),
                causal, a, c, qt, vt, jobs);
        })
    );
    status = hipGetLastError();
    TORCH_CHECK(status == hipSuccess, hipGetErrorString(status));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    HSTU attention forward (the attention of the generative-recommendation HSTU unit, no softmax / no normalization):
    dense Q/K/V are split by seq_offsets into batch variable-length sequences,
    and each sequence computes independently
    out = (valid * SiLU(alpha*Q*K^T) / N) * V, where N = max_seq_len.

    Mathematical definition (sequence b: s = seq_offsets[b],
    L = seq_offsets[b+1] - seq_offsets[b], g = num_targets[b],
    c = contextual_seq_len, A = max_attn_len; when c = 0, M = L and r[i] = i;
    when c > 0, M = L - c + 1 and r[i] = max(i - c + 1, 0)):
      position renumbering m[i] = min(r[i], M - g)
      d[i,j] = m[i] - m[j]; when causal = False, d[i,j] = abs(d[i,j])
      valid[i,j] = (i == j) or d[i,j] > 0
      when A > 0, valid[i,j] additionally requires d[i,j] <= A
      when c > 0, valid[i,j] is additionally relaxed to true when m[i] == 0 and
      m[j] < M - g
      out[s+i, h, :] = sum_j valid[i,j] * SiLU(alpha*<q[s+i,h,:], k[s+j,h,:]>) / N
                       * v[s+j,h,:]
    where SiLU(x) = x*sigmoid(x). When causal = True, valid is lower triangular
    (including the diagonal); the weights get no softmax and no sum
    normalization, and masked positions contribute exactly 0.
    Boundary behaviour: the last g tokens of a sequence are targets and are
    excluded from the key side by the renumbering truncation; g = 0 is equivalent
    to no target exclusion; when c > 0 the first c tokens (renumbered m = 0)
    additionally see all non-target keys (including each other); an empty
    sequence (L = 0) is legal and produces no output rows; a sequence may be
    shorter than N, and the scaling denominator is always N (not that sequence's
    own length).

    Input/output specification:
      q            [total, num_heads, qk_dim]   float16 / bfloat16
      k            [total, num_heads, qk_dim]   same dtype as q
      v            [total, num_heads, v_dim]    same dtype as q; v_dim may differ from qk_dim
      seq_offsets  [batch + 1] int64, monotonically non-decreasing, first element 0, last element total
      num_targets  [batch] int32, 0 <= num_targets[b] and c + num_targets[b] <= L_b
      out          [total, num_heads, v_dim], same dtype as v
    Global-domain constraints: 0 <= L_b <= max_seq_len; qk_dim / v_dim are powers
    of 2 (of order 64..256).

    Hyper-parameters (__init__): max_seq_len (scaling denominator and upper bound
    on length, N); alpha (logits scale, defaults to 1/sqrt(qk_dim)); causal
    (defaults to True); max_attn_len (defaults to 0 = distance not limited);
    contextual_seq_len (defaults to 0 = disabled).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / SiLU / mask / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / torch.matmul / torch.bmm / torch.einsum / torch.softmax /
        torch.nn.functional.silu and their alias forms (F.silu / F.softmax /
        torch.mm / the @ matrix-multiply operator) is forbidden (implement SiLU
        yourself as x*sigmoid(x)).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to v's
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: forward only, non-quantized inputs, no dropout, no
    backpropagation.
    """
    def __init__(self, max_seq_len: int, alpha=None, causal=True, max_attn_len=0, contextual_seq_len=0):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.max_seq_len = int(max_seq_len)
        self.alpha = float(alpha) if alpha is not None else None
        self.causal = bool(causal)
        self.max_attn_len = int(max_attn_len)
        self.contextual_seq_len = int(contextual_seq_len)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, seq_offsets, num_targets):
        # <<<IMPROVE:forward_stmt_1>>>
        seq_offsets = seq_offsets.to(device=q.device, dtype=torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        num_targets = num_targets.to(device=q.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B = int(seq_offsets.numel()) - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        alpha = self.alpha if self.alpha is not None else 1.0 / math.sqrt(q.shape[2])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = self.max_seq_len
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        c = self.contextual_seq_len
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        out = _pyramidkernel_get_extension().hstu_forward(
            q, k, v, seq_offsets, num_targets, N, alpha,
            self.causal, self.max_attn_len, c)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # The extension computes all sequences.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        return out
        # <<<END_IMPROVE>>>
