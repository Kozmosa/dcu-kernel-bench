import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1010_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor chunked_attention(
    torch::Tensor query, torch::Tensor key, torch::Tensor value,
    torch::Tensor key_cache, torch::Tensor value_cache,
    torch::Tensor block_tables, torch::Tensor query_start_loc,
    torch::Tensor seq_lens, double scale, torch::Tensor out);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("chunked_attention", &chunked_attention, "Chunked paged attention");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/ATen.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cmath>
#include <cstdint>

template <typename T>
__device__ __forceinline__ float as_float(T x) {
    return static_cast<float>(x);
}

template <typename T>
__device__ __forceinline__ T as_scalar(float x) {
    return static_cast<T>(x);
}

__device__ __forceinline__ float reduce64(float x) {
    x += __shfl_down(x, 32, 64);
    x += __shfl_down(x, 16, 64);
    x += __shfl_down(x, 8, 64);
    x += __shfl_down(x, 4, 64);
    x += __shfl_down(x, 2, 64);
    x += __shfl_down(x, 1, 64);
    return x;
}

template <typename scalar_t, int D>
__global__ void chunked_attention_kernel(
    const scalar_t* __restrict__ query,
    const scalar_t* __restrict__ key,
    const scalar_t* __restrict__ value,
    const scalar_t* __restrict__ key_cache,
    const scalar_t* __restrict__ value_cache,
    const int32_t* __restrict__ block_tables,
    const int32_t* __restrict__ query_start_loc,
    const int32_t* __restrict__ seq_lens,
    scalar_t* __restrict__ output,
    int64_t num_tokens,
    int64_t num_heads,
    int64_t num_kv_heads,
    int64_t runtime_head_size,
    int64_t block_size,
    int64_t max_blocks_per_seq,
    int64_t num_blocks,
    int64_t num_seqs,
    float scale) {
    const int64_t head_size = D ? int64_t(D) : runtime_head_size;
    constexpr int registers = D ? (D + 63) / 64 : 16;
    const int lane = static_cast<int>(threadIdx.x);
    const int64_t flat = static_cast<int64_t>(blockIdx.x);
    const int64_t total = num_tokens * num_heads;
    if (lane >= 64 || flat < 0 || flat >= total)
        return;

    const int64_t token = flat / num_heads;
    const int64_t qh = flat % num_heads;
    if (token < 0 || token >= num_tokens || qh < 0 || qh >= num_heads)
        return;

    int64_t lo = 0;
    int64_t hi = num_seqs;
    while (lo < hi) {
        const int64_t mid = lo + (hi - lo) / 2;
        const int64_t e = static_cast<int64_t>(query_start_loc[mid + 1]);
        if (e <= token)
            lo = mid + 1;
        else
            hi = mid;
    }
    const int64_t b = lo;
    if (b < 0 || b >= num_seqs)
        return;

    const int64_t q_start = static_cast<int64_t>(query_start_loc[b]);
    const int64_t q_end = static_cast<int64_t>(query_start_loc[b + 1]);
    const int64_t q_len = q_end - q_start;
    const int64_t j = token - q_start;
    const int64_t seq_len = static_cast<int64_t>(seq_lens[b]);
    const int64_t ctx_len = seq_len - q_len;
    const int64_t pos = ctx_len + j;

    if (q_start < 0 || q_end < q_start || q_end > num_tokens ||
        q_len <= 0 || j < 0 || j >= q_len || seq_len <= 0 ||
        ctx_len < 0 || pos < 0 || pos >= seq_len)
        return;

    const int64_t group = num_heads / num_kv_heads;
    if (group <= 0 || num_heads != group * num_kv_heads)
        return;
    const int64_t kvh = qh / group;
    if (kvh < 0 || kvh >= num_kv_heads)
        return;

    const int64_t qbase = (token * num_heads + qh) * head_size;
    float qreg[registers];
    float accum[registers];
    #pragma unroll
    for (int r = 0; r < registers; ++r) {
        const int64_t d = int64_t(lane) + int64_t(r) * 64;
        if (d < head_size) {
            qreg[r] = as_float(query[qbase + d]);
            accum[r] = 0.0f;
        }
    }

    float max_score = -INFINITY;
    float norm = 0.0f;

    for (int64_t l = 0; l <= pos && l < seq_len; ++l) {
        const bool is_new = l >= ctx_len;
        bool valid = true;
        int64_t kbase = 0;
        int64_t vbase = 0;

        if (is_new) {
            const int64_t nt = q_start + l - ctx_len;
            if (nt < 0 || nt >= num_tokens) {
                valid = false;
            } else {
                kbase = (nt * num_kv_heads + kvh) * head_size;
                vbase = kbase;
            }
        } else {
            const int64_t logical = l / block_size;
            const int64_t slot = l % block_size;
            if (logical < 0 || logical >= max_blocks_per_seq ||
                slot < 0 || slot >= block_size) {
                valid = false;
            } else {
                const int64_t table_index = b * max_blocks_per_seq + logical;
                const int64_t physical =
                    static_cast<int64_t>(block_tables[table_index]);
                if (physical < 0 || physical >= num_blocks) {
                    valid = false;
                } else {
                    kbase =
                        (((physical * num_kv_heads + kvh) * (head_size / 8))
                         * block_size + slot) * 8;
                    vbase =
                        ((physical * num_kv_heads + kvh) * head_size)
                        * block_size + slot;
                }
            }
        }
        if (!valid)
            continue;

        float part = 0.0f;
        #pragma unroll
        for (int r = 0; r < registers; ++r) {
            const int64_t d = int64_t(lane) + int64_t(r) * 64;
            if (d < head_size) {
                const float kval = is_new
                    ? as_float(key[kbase + d])
                    : as_float(key_cache[
                        kbase + (d / 8) * block_size * 8 + (d % 8)]);
                part += qreg[r] * kval;
            }
        }

        float score = reduce64(part);
        score = __shfl(score, 0, 64) * scale;

        const float next_max = score > max_score ? score : max_score;
        const float old_weight =
            max_score == -INFINITY ? 0.0f : expf(max_score - next_max);
        const float weight = expf(score - next_max);

        #pragma unroll
        for (int r = 0; r < registers; ++r) {
            const int64_t d = int64_t(lane) + int64_t(r) * 64;
            if (d < head_size) {
                const float vval = is_new
                    ? as_float(value[vbase + d])
                    : as_float(value_cache[vbase + d * block_size]);
                accum[r] = accum[r] * old_weight + weight * vval;
            }
        }

        if (lane == 0) {
            norm = norm * old_weight + weight;
            max_score = next_max;
        }
        max_score = __shfl(max_score, 0, 64);
        norm = __shfl(norm, 0, 64);
    }

    #pragma unroll
    for (int r = 0; r < registers; ++r) {
        const int64_t d = int64_t(lane) + int64_t(r) * 64;
        if (d < head_size)
            output[qbase + d] = as_scalar<scalar_t>(accum[r] / norm);
    }
}

torch::Tensor chunked_attention(
    torch::Tensor query,
    torch::Tensor key,
    torch::Tensor value,
    torch::Tensor key_cache,
    torch::Tensor value_cache,
    torch::Tensor block_tables,
    torch::Tensor query_start_loc,
    torch::Tensor seq_lens,
    double scale,
    torch::Tensor out) {
    TORCH_CHECK(query.is_cuda(), "query must be on accelerator");
    const c10::cuda::CUDAGuard guard(query.device());

    for (const auto& t : {key, value, key_cache, value_cache, block_tables,
                          query_start_loc, seq_lens, out})
        TORCH_CHECK(t.device() == query.device(), "device mismatch");

    TORCH_CHECK(query.is_contiguous() && key.is_contiguous() &&
                value.is_contiguous() && key_cache.is_contiguous() &&
                value_cache.is_contiguous() && block_tables.is_contiguous() &&
                query_start_loc.is_contiguous() && seq_lens.is_contiguous() &&
                out.is_contiguous(), "all tensors must be contiguous");

    TORCH_CHECK(query.dim() == 3 && key.dim() == 3 && value.dim() == 3,
                "invalid QKV dimensions");
    TORCH_CHECK(key_cache.dim() == 5 && value_cache.dim() == 4,
                "invalid cache dimensions");
    TORCH_CHECK(block_tables.dim() == 2 && query_start_loc.dim() == 1 &&
                seq_lens.dim() == 1 &&
                block_tables.size(0) == seq_lens.size(0) &&
                query_start_loc.size(0) == seq_lens.size(0) + 1,
                "invalid metadata shapes");
    TORCH_CHECK(block_tables.scalar_type() == at::kInt &&
                query_start_loc.scalar_type() == at::kInt &&
                seq_lens.scalar_type() == at::kInt,
                "metadata must be int32");
    TORCH_CHECK(query.scalar_type() == at::kHalf ||
                query.scalar_type() == at::kBFloat16 ||
                query.scalar_type() == at::kFloat,
                "unsupported dtype");
    TORCH_CHECK(query.scalar_type() == key.scalar_type() &&
                query.scalar_type() == value.scalar_type() &&
                query.scalar_type() == key_cache.scalar_type() &&
                query.scalar_type() == value_cache.scalar_type() &&
                query.scalar_type() == out.scalar_type(),
                "dtype mismatch");

    const int64_t num_tokens = query.size(0);
    const int64_t num_heads = query.size(1);
    const int64_t head_size = query.size(2);
    const int64_t num_kv_heads = key.size(1);
    const int64_t block_size = value_cache.size(3);

    TORCH_CHECK(num_heads > 0 && num_kv_heads > 0 &&
                num_heads % num_kv_heads == 0,
                "invalid head grouping");
    TORCH_CHECK(head_size > 0 && head_size <= 1024 && head_size % 8 == 0 &&
                block_size > 0 && key.size(0) == num_tokens &&
                key.size(2) == head_size && value.sizes() == key.sizes() &&
                key_cache.size(0) == value_cache.size(0) &&
                key_cache.size(1) == num_kv_heads &&
                key_cache.size(2) == head_size / 8 &&
                key_cache.size(3) == block_size &&
                key_cache.size(4) == 8 &&
                value_cache.size(1) == num_kv_heads &&
                value_cache.size(2) == head_size &&
                out.sizes() == query.sizes(),
                "invalid tensor shapes");

    const int64_t total = num_tokens * num_heads;
    TORCH_CHECK(total <= static_cast<int64_t>(0x7fffffff),
                "launch grid is too large");
    if (total == 0)
        return out;

    dim3 block(64);
    dim3 grid(static_cast<unsigned int>(total));
    auto stream = at::cuda::getCurrentCUDAStream();

#define LAUNCH_ATTENTION(DIM) \
    chunked_attention_kernel<scalar_t, DIM><<<grid, block, 0, stream>>>( \
        query.data_ptr<scalar_t>(), key.data_ptr<scalar_t>(), \
        value.data_ptr<scalar_t>(), key_cache.data_ptr<scalar_t>(), \
        value_cache.data_ptr<scalar_t>(), block_tables.data_ptr<int32_t>(), \
        query_start_loc.data_ptr<int32_t>(), seq_lens.data_ptr<int32_t>(), \
        out.data_ptr<scalar_t>(), num_tokens, num_heads, num_kv_heads, \
        head_size, block_size, block_tables.size(1), key_cache.size(0), \
        seq_lens.size(0), static_cast<float>(scale))

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        query.scalar_type(), "chunked_attention", [&] {
            switch (head_size) {
                case 64: LAUNCH_ATTENTION(64); break;
                case 128: LAUNCH_ATTENTION(128); break;
                case 256: LAUNCH_ATTENTION(256); break;
                default: LAUNCH_ATTENTION(0); break;
            }
        });
#undef LAUNCH_ATTENTION

    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "chunked attention kernel launch failed: ",
                hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Chunked prefill / decode mixed-batch attention over a paged KV cache (MHA and GQA, causal mask).

    The batch holds num_seqs sequences running in parallel; sequence b computes
    query_len[b] = query_start_loc[b+1] - query_start_loc[b] new query tokens
    this round, and the per-sequence slices are packed back to back along the
    token dimension according to query_start_loc (no padding). Sequence b
    currently has total length seq_lens[b], of which the first
    ctx_len[b] = seq_lens[b] - query_len[b] tokens are already-admitted prefix
    K/V that live only in the paged KV cache; the K/V of this round's new tokens
    are given separately and explicitly as key / value (consistent with the
    corresponding cache slots). A sequence with query_len[b] == 1 is decode,
    > 1 is chunked prefill, and the two kinds may be mixed in the same batch.

    Paged layout: the physical block pool has num_blocks blocks, each holding
    block_size token slots; block_tables[b] is that sequence's "logical block ->
    physical block number" table, covering the whole seq_lens[b] (including this
    round's new tokens). K uses a channel-packed layout: K[tok, h, d] lives at
    key_cache[pblk, h, d // x, tok % block_size, d % x] (x = 8, head_size is a
    multiple of 8); V is value_cache[pblk, h, d, tok % block_size]. Blocks of the
    pool that no block table references, and slots past a sequence's valid
    length, hold garbage data (magnitudes up to +/-10) and must not take part in
    the computation.

    For query head h of sequence b (its KV head is h // query_group_size, where
    query_group_size = num_heads / num_kv_heads) and its j-th new token (absolute
    position within the sequence pos = ctx_len[b] + j):

      logits[l] = scale * <query[pos, h, :], K[l]>,  l = 0 .. seq_lens[b]-1
      causal mask: logits at positions l > pos are set to -inf
      p[l] = exp(logits[l] - max_l logits) / sum_l' exp(logits[l'] - max_l logits)
      out[pos, h, :] = sum_l p[l] * V[l]

    The first ctx_len[b] K / V tokens come from the paged cache (indirectly
    addressed through the block table), the remaining query_len[b] come from
    key / value. softmax uses an online (numerically stable) implementation,
    intermediate accumulation is in float32, and the output is cast back to the
    input dtype.

    Input/output specification (forward parameter order):
      query           [num_tokens, num_heads, head_size]          fp16/bf16
      key             [num_tokens, num_kv_heads, head_size]       same as query
      value           [num_tokens, num_kv_heads, head_size]       same as query
      key_cache       [num_blocks, num_kv_heads, head_size//8, block_size, 8]  same as query
      value_cache     [num_blocks, num_kv_heads, head_size, block_size]        same as query
      block_tables    [num_seqs, max_blocks_per_seq]              int32
      query_start_loc [num_seqs+1] int32 (prefix sum of query_len, first element 0)
      seq_lens        [num_seqs] int32
      output out      [num_tokens, num_heads, head_size], dtype matches query.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / torch.matmul / torch.bmm / torch.einsum / torch.softmax is forbidden
        (the complete forbidden list is defined by the task configuration's
        forbidden field).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: chunked prefill/decode mixed batch, non-quantized KV, no ALiBi,
    no sliding window.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(device=query.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        query_start_loc = query_start_loc.to(device=query.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        seq_lens = seq_lens.to(device=query.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens, num_heads, head_size = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        num_kv_heads = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        block_size = value_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        x = key_cache.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        group = num_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert num_heads == num_kv_heads * group, "num_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _pyramidkernel_get_extension().chunked_attention(
            query, key, value, key_cache, value_cache, block_tables,
            query_start_loc, seq_lens, float(self.scale), out
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
