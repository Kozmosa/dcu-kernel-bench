import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void paged_attention_out(torch::Tensor, torch::Tensor, torch::Tensor,
                         torch::Tensor, torch::Tensor, torch::Tensor, double);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention_out", &paged_attention_out);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cstdint>
#include <cmath>
#include <limits>

struct Layout {
    int64_t B,H,D,K,N,bs,T,P;
    int64_t q[3],k[4],v[4],o[3],bt[2],ls;
};

template<class S>
__global__ void partition_attention(const S* q,const S* k,const S* v,
    const int64_t* bt,const int64_t* lengths,float* partial,float* maxima,
    float* denom,Layout a,float scale) {
    __shared__ float red[256], scores[256], maximum, denominator;
    __shared__ int64_t pages[256];
    const int64_t tid=(int64_t)threadIdx.x,total=a.B*a.H*a.P;
    for(int64_t job=(int64_t)blockIdx.x;job<total;job+=(int64_t)gridDim.x) {
        const int64_t p=job%a.P,h=(job/a.P)%a.H,s=job/(a.P*a.H);
        const int64_t kh=h/(a.H/a.K),len=lengths[s*a.ls];
        const int64_t token=p*256+tid;
        int64_t page=-1;
        if(token<len && token/a.bs<a.T) {
            const int64_t z=bt[s*a.bt[0]+(token/a.bs)*a.bt[1]];
            if(z>=0 && z<a.N) page=z;
        }
        pages[tid]=page;
        __syncthreads();

        for(int64_t batch=0;batch<8;++batch) {
            const int64_t t=batch*32+tid/8,l=p*256+t,physical=pages[t];
            float sum=0.0f;
            if(physical>=0 && physical<a.N && l>=0 && l<len) {
                for(int64_t d=tid%8;d<a.D;d+=8) {
                    const int64_t qo=s*a.q[0]+h*a.q[1]+d*a.q[2];
                    const int64_t ko=physical*a.k[0]+kh*a.k[1]+(l%a.bs)*a.k[2]+d*a.k[3];
                    sum+=(float)q[qo]*(float)k[ko];
                }
            }
            sum+=__shfl_down(sum,4,8);
            sum+=__shfl_down(sum,2,8);
            sum+=__shfl_down(sum,1,8);
            if(tid%8==0)
                scores[t]=(physical>=0 && physical<a.N && l>=0 && l<len)
                    ? sum*scale : -INFINITY;
        }
        __syncthreads();

        red[tid]=scores[tid];
        __syncthreads();
        for(int64_t off=128;off>0;off/=2) {
            if(tid<off) red[tid]=fmaxf(red[tid],red[tid+off]);
            __syncthreads();
        }
        if(tid==0) maximum=red[0];
        __syncthreads();

        const float valid=(pages[tid]>=0 && pages[tid]<a.N &&
                           p*256+tid>=0 && p*256+tid<len) ? 1.0f : 0.0f;
        scores[tid]=valid*expf(scores[tid]-maximum);
        red[tid]=scores[tid];
        __syncthreads();
        for(int64_t off=128;off>0;off/=2) {
            if(tid<off) red[tid]+=red[tid+off];
            __syncthreads();
        }
        if(tid==0) {
            denominator=red[0];
            maxima[job]=maximum;
            denom[job]=denominator;
        }
        __syncthreads();

        for(int64_t d=tid;d<a.D;d+=256) {
            float sum=0.0f;
            for(int64_t t=0;t<256;++t) {
                const int64_t physical=pages[t],l=p*256+t;
                if(physical>=0 && physical<a.N && l>=0 && l<len) {
                    const int64_t vo=physical*a.v[0]+kh*a.v[1]+(l%a.bs)*a.v[2]+d*a.v[3];
                    sum+=scores[t]*(float)v[vo];
                }
            }
            partial[job*a.D+d]=sum;
        }
        __syncthreads();
    }
}

template<class S>
__global__ void merge_attention(const float* partial,const float* maxima,
    const float* denom,S* out,Layout a) {
    __shared__ float rmax[256],rsum[256],maximum,denominator;
    const int64_t tid=(int64_t)threadIdx.x,total=a.B*a.H;
    for(int64_t sh=(int64_t)blockIdx.x;sh<total;sh+=(int64_t)gridDim.x) {
        float m=-INFINITY;
        for(int64_t p=tid;p<a.P;p+=256) {
            const int64_t j=sh*a.P+p;
            if(denom[j]>0.0f) m=fmaxf(m,maxima[j]);
        }
        rmax[tid]=m;
        __syncthreads();
        for(int64_t off=128;off>0;off/=2) {
            if(tid<off) rmax[tid]=fmaxf(rmax[tid],rmax[tid+off]);
            __syncthreads();
        }
        if(tid==0) maximum=rmax[0];
        __syncthreads();

        float z=0.0f;
        for(int64_t p=tid;p<a.P;p+=256) {
            const int64_t j=sh*a.P+p;
            if(denom[j]>0.0f) z+=expf(maxima[j]-maximum)*denom[j];
        }
        rsum[tid]=z;
        __syncthreads();
        for(int64_t off=128;off>0;off/=2) {
            if(tid<off) rsum[tid]+=rsum[tid+off];
            __syncthreads();
        }
        if(tid==0) denominator=rsum[0];
        __syncthreads();

        for(int64_t d=tid;d<a.D;d+=256) {
            float x=0.0f;
            for(int64_t p=0;p<a.P;++p) {
                const int64_t j=sh*a.P+p;
                if(denom[j]>0.0f)
                    x+=expf(maxima[j]-maximum)*partial[j*a.D+d];
            }
            const int64_t oo=(sh/a.H)*a.o[0]+(sh%a.H)*a.o[1]+d*a.o[2];
            out[oo]=(S)(denominator>0.0f ? x/denominator : 0.0f);
        }
        __syncthreads();
    }
}

void paged_attention_out(torch::Tensor query,torch::Tensor key_cache,
    torch::Tensor value_cache,torch::Tensor block_tables,torch::Tensor seq_lens,
    torch::Tensor out,double scale) {
    TORCH_CHECK(query.is_cuda(),"query must be on GPU");
    c10::cuda::CUDAGuard guard(query.device());
    for(auto t:{key_cache,value_cache,block_tables,seq_lens,out})
        TORCH_CHECK(t.device()==query.device(),"device mismatch");
    TORCH_CHECK(query.dim()==3 && key_cache.dim()==4 && value_cache.dim()==4,
                "invalid query/cache ranks");
    TORCH_CHECK(block_tables.dim()==2 && seq_lens.dim()==1,"invalid metadata ranks");
    TORCH_CHECK(key_cache.sizes()==value_cache.sizes(),"cache shape mismatch");
    TORCH_CHECK(out.sizes()==query.sizes(),"output shape mismatch");
    TORCH_CHECK(query.scalar_type()==key_cache.scalar_type() &&
                query.scalar_type()==value_cache.scalar_type() &&
                query.scalar_type()==out.scalar_type(),"dtype mismatch");
    TORCH_CHECK(block_tables.scalar_type()==at::kLong &&
                seq_lens.scalar_type()==at::kLong,"metadata must be int64");

    Layout a{};
    a.B=query.size(0); a.H=query.size(1); a.D=query.size(2);
    a.N=key_cache.size(0); a.K=key_cache.size(1); a.bs=key_cache.size(2);
    a.T=block_tables.size(1);
    TORCH_CHECK(a.K>0 && a.bs>0 && a.H>0 && a.D>0 && a.H%a.K==0,
                "invalid head or block dimensions");
    TORCH_CHECK(key_cache.size(3)==a.D && block_tables.size(0)==a.B &&
                seq_lens.size(0)==a.B,"shape mismatch");
    TORCH_CHECK(a.T<=(INT64_MAX-255)/a.bs,"context size overflow");
    a.P=std::max<int64_t>(1,(a.T*a.bs+255)/256);

    for(int i=0;i<3;++i){a.q[i]=query.stride(i);a.o[i]=out.stride(i);}
    for(int i=0;i<4;++i){a.k[i]=key_cache.stride(i);a.v[i]=value_cache.stride(i);}
    for(int i=0;i<2;++i) a.bt[i]=block_tables.stride(i);
    a.ls=seq_lens.stride(0);
    if(a.B==0) return;
    TORCH_CHECK(a.B<=INT64_MAX/a.H && a.B*a.H<=INT64_MAX/a.P &&
                a.B*a.H*a.P<=INT64_MAX/a.D,"scratch size overflow");

    const int64_t jobs=a.B*a.H*a.P;
    auto options=query.options().dtype(at::kFloat);
    auto partial=torch::empty({jobs,a.D},options);
    auto maxima=torch::empty({jobs},options);
    auto denom=torch::empty({jobs},options);
    auto stream=at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,at::ScalarType::BFloat16,
        query.scalar_type(),"paged_attention",[&] {
        partition_attention<scalar_t><<<std::min<int64_t>(jobs,65535),256,0,stream>>>(
            query.data_ptr<scalar_t>(),key_cache.data_ptr<scalar_t>(),
            value_cache.data_ptr<scalar_t>(),block_tables.data_ptr<int64_t>(),
            seq_lens.data_ptr<int64_t>(),partial.data_ptr<float>(),
            maxima.data_ptr<float>(),denom.data_ptr<float>(),a,(float)scale);
        auto error=hipGetLastError();
        TORCH_CHECK(error==hipSuccess,hipGetErrorString(error));
        merge_attention<scalar_t><<<std::min<int64_t>(a.B*a.H,65535),256,0,stream>>>(
            partial.data_ptr<float>(),maxima.data_ptr<float>(),denom.data_ptr<float>(),
            out.data_ptr<scalar_t>(),a);
        error=hipGetLastError();
        TORCH_CHECK(error==hipSuccess,hipGetErrorString(error));
    });
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Paged attention in the decode phase (single-token query), supporting both
    MHA and GQA.

    The KV cache is stored page-wise with a fixed block_size in the physical block
    pools key_cache / value_cache, and each sequence addresses them indirectly
    through the physical block ids in block_tables; the KV length that actually
    participates in attention for each sequence is given by seq_lens[s], while the
    remaining slots in the pool hold garbage data and must not participate in the
    computation. For query head h of sequence s (whose KV head is
    h // query_group_size):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    The softmax uses an online (numerically stable) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding window.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _pyramidkernel_get_extension().paged_attention_out(
            query, key_cache, value_cache, block_tables, seq_lens, out, self.scale
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
