import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1017_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor mha_forward(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor causal,
    torch::Tensor alibi_slopes,
    double sm_scale);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mha_forward", &mha_forward, "Fused MHA forward");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>
#include <limits>
#include <algorithm>

template <typename scalar_t>
__global__ void mha_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k,
    const scalar_t* __restrict__ v,
    const float* __restrict__ slopes,
    const int32_t* __restrict__ causal_ptr,
    scalar_t* __restrict__ out,
    float* __restrict__ lse,
    int64_t sq, int64_t sk, int64_t nq, int64_t nk,
    int64_t dim, int64_t tiles, float sm_scale) {
    __shared__ float tile[32 * 256];
    __shared__ float query[8][256];
    __shared__ float scores[8][32];
    __shared__ float weights[8][32];
    __shared__ float maximum[8];
    __shared__ float denominator[8];
    __shared__ float alpha[8];

    const int64_t tid = static_cast<int64_t>(threadIdx.x);
    const int64_t row_group = tid / 32;
    const int64_t lane = tid % 32;
    const int64_t query_tiles = (sq + 7) / 8;
    const bool causal = causal_ptr[0] != 0;

    for (int64_t block_id = static_cast<int64_t>(blockIdx.x);
         block_id < tiles;
         block_id += static_cast<int64_t>(gridDim.x)) {
        const int64_t query_tile = block_id % query_tiles;
        const int64_t h = (block_id / query_tiles) % nq;
        const int64_t b = block_id / (query_tiles * nq);
        const int64_t kv_h = h / (nq / nk);
        const int64_t first_i = query_tile * 8;
        const int64_t i = first_i + row_group;
        const bool valid_row = i < sq;

        const int64_t qbase = ((b * sq + i) * nq + h) * dim;
        const int64_t aligned = i + sk - sq;

        int64_t end = valid_row ? sk : 0;
        if (valid_row && causal) {
            end = aligned + 1;
            if (end < 0) end = 0;
            if (end > sk) end = sk;
        }

        int64_t max_end = 0;
        if (first_i < sq) {
            const int64_t last_i = (first_i + 7 < sq) ? first_i + 7 : sq - 1;
            max_end = causal ? last_i + sk - sq + 1 : sk;
            if (max_end < 0) max_end = 0;
            if (max_end > sk) max_end = sk;
        }

        const float slope = slopes[b * nq + h];

        for (int64_t d = lane; d < dim; d += 32) {
            query[row_group][d] = valid_row
                ? static_cast<float>(q[qbase + d])
                : 0.0f;
        }

        if (lane == 0) {
            maximum[row_group] = -INFINITY;
            denominator[row_group] = 0.0f;
            alpha[row_group] = 1.0f;
        }
        scores[row_group][lane] = -INFINITY;
        weights[row_group][lane] = 0.0f;

        float acc[8] = {0.0f, 0.0f, 0.0f, 0.0f,
                        0.0f, 0.0f, 0.0f, 0.0f};

        __syncthreads();

        for (int64_t start = 0; start < max_end; start += 32) {
            const int64_t count = (max_end - start < 32) ? max_end - start : 32;

            for (int64_t x = tid; x < 32 * dim; x += 256) {
                const int64_t key_index = x / dim;
                const int64_t d = x % dim;
                float value = 0.0f;
                if (key_index < count && d < dim) {
                    const int64_t offset =
                        ((b * sk + start + key_index) * nk + kv_h) * dim + d;
                    value = static_cast<float>(k[offset]);
                }
                tile[d * 32 + key_index] = value;
            }
            __syncthreads();

            float score = -INFINITY;
            if (valid_row && lane < count && start + lane < end) {
                float dot = 0.0f;
                for (int64_t d = 0; d < dim; ++d) {
                    dot += query[row_group][d] * tile[d * 32 + lane];
                }
                const int64_t relative = aligned - (start + lane);
                const int64_t distance = relative < 0 ? -relative : relative;
                score = dot * sm_scale - slope * static_cast<float>(distance);
            }
            scores[row_group][lane] = score;
            __syncthreads();

            // The capability branch is uniform across the block. Width-32
            // shuffles isolate each logical row even on wider HIP wavefronts.
            if (warpSize >= 32 && warpSize % 32 == 0) {
                float tile_max = score;
                #pragma unroll
                for (int offset = 16; offset > 0; offset >>= 1) {
                    tile_max = fmaxf(
                        tile_max, __shfl_xor(tile_max, offset, 32));
                }

                const bool has_keys = valid_row && start < end;
                float next_max = maximum[row_group];
                float scale_old = 1.0f;
                float weight = 0.0f;
                if (has_keys) {
                    next_max = fmaxf(next_max, tile_max);
                    scale_old = denominator[row_group] == 0.0f
                        ? 0.0f
                        : expf(maximum[row_group] - next_max);
                    if (lane < count && start + lane < end) {
                        weight = expf(score - next_max);
                    }
                }
                weights[row_group][lane] = weight;

                float tile_sum = weight;
                #pragma unroll
                for (int offset = 16; offset > 0; offset >>= 1) {
                    tile_sum += __shfl_xor(tile_sum, offset, 32);
                }

                if (lane == 0) {
                    alpha[row_group] = scale_old;
                    if (has_keys) {
                        maximum[row_group] = next_max;
                        denominator[row_group] =
                            scale_old * denominator[row_group] + tile_sum;
                    }
                }
            } else {
                if (lane == 0) {
                    if (start < end) {
                        const int64_t row_count =
                            (end - start < 32) ? end - start : 32;
                        float tile_max = -INFINITY;
                        for (int64_t j = 0; j < row_count; ++j) {
                            tile_max = fmaxf(tile_max, scores[row_group][j]);
                        }

                        const float next_max =
                            fmaxf(maximum[row_group], tile_max);
                        const float scale_old =
                            denominator[row_group] == 0.0f
                                ? 0.0f
                                : expf(maximum[row_group] - next_max);

                        float tile_sum = 0.0f;
                        for (int64_t j = 0; j < 32; ++j) {
                            const float weight = j < row_count
                                ? expf(scores[row_group][j] - next_max)
                                : 0.0f;
                            weights[row_group][j] = weight;
                            tile_sum += weight;
                        }

                        alpha[row_group] = scale_old;
                        maximum[row_group] = next_max;
                        denominator[row_group] =
                            scale_old * denominator[row_group] + tile_sum;
                    } else {
                        alpha[row_group] = 1.0f;
                        for (int64_t j = 0; j < 32; ++j) {
                            weights[row_group][j] = 0.0f;
                        }
                    }
                }
            }

            for (int64_t x = tid; x < 32 * dim; x += 256) {
                const int64_t key_index = x / dim;
                const int64_t d = x % dim;
                float value = 0.0f;
                if (key_index < count && d < dim) {
                    const int64_t offset =
                        ((b * sk + start + key_index) * nk + kv_h) * dim + d;
                    value = static_cast<float>(v[offset]);
                }
                tile[key_index * dim + d] = value;
            }
            __syncthreads();

            #pragma unroll
            for (int64_t t = 0; t < 8; ++t) {
                const int64_t d = lane + 32 * t;
                if (d < dim) {
                    float value = alpha[row_group] * acc[t];
                    for (int64_t j = 0; j < count; ++j) {
                        value += weights[row_group][j] * tile[j * dim + d];
                    }
                    acc[t] = value;
                }
            }
            __syncthreads();
        }

        if (valid_row) {
            const float inv_denominator =
                end == 0 ? 0.0f : 1.0f / denominator[row_group];

            #pragma unroll
            for (int64_t t = 0; t < 8; ++t) {
                const int64_t d = lane + 32 * t;
                if (d < dim) {
                    out[qbase + d] = static_cast<scalar_t>(
                        end == 0 ? 0.0f : acc[t] * inv_denominator);
                }
            }

            if (lane == 0) {
                lse[(b * nq + h) * sq + i] =
                    end == 0
                        ? 0.0f
                        : maximum[row_group] + logf(denominator[row_group]);
            }
        }

        __syncthreads();
    }
}

template <typename scalar_t>
__global__ void pack_kernel(
    const scalar_t* __restrict__ out,
    const float* __restrict__ lse,
    float* __restrict__ packed,
    int64_t out_numel, int64_t total_numel) {
    for (int64_t index =
             static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
         index < total_numel;
         index += static_cast<int64_t>(gridDim.x) * blockDim.x) {
        if (index < out_numel) {
            packed[index] = static_cast<float>(out[index]);
        } else {
            const int64_t lse_index = index - out_numel;
            if (lse_index >= 0 && lse_index < total_numel - out_numel) {
                packed[index] = lse[lse_index];
            }
        }
    }
}

template <typename scalar_t>
void launch_mha(
    const torch::Tensor& q, const torch::Tensor& k, const torch::Tensor& v,
    const torch::Tensor& causal, const torch::Tensor& slopes,
    torch::Tensor& out, torch::Tensor& lse, torch::Tensor& packed,
    float scale, hipStream_t stream) {
    const int64_t query_tiles = (q.size(1) + 7) / 8;
    const int64_t tiles = q.size(0) * q.size(2) * query_tiles;
    const unsigned int blocks = static_cast<unsigned int>(
        std::max<int64_t>(1, std::min<int64_t>(tiles, 65535)));

    mha_kernel<scalar_t><<<blocks, 256, 0, stream>>>(
        q.data_ptr<scalar_t>(),
        k.data_ptr<scalar_t>(),
        v.data_ptr<scalar_t>(),
        slopes.data_ptr<float>(),
        causal.data_ptr<int32_t>(),
        out.data_ptr<scalar_t>(),
        lse.data_ptr<float>(),
        q.size(1), k.size(1), q.size(2), k.size(2),
        q.size(3), tiles, scale);

    hipError_t err = hipGetLastError();
    TORCH_CHECK(
        err == hipSuccess,
        "mha kernel launch failed: ",
        hipGetErrorString(err));

    const int64_t total = packed.numel();
    const unsigned int pack_blocks = static_cast<unsigned int>(
        std::max<int64_t>(1, std::min<int64_t>((total + 255) / 256, 65535)));

    pack_kernel<scalar_t><<<pack_blocks, 256, 0, stream>>>(
        out.data_ptr<scalar_t>(),
        lse.data_ptr<float>(),
        packed.data_ptr<float>(),
        out.numel(),
        total);

    err = hipGetLastError();
    TORCH_CHECK(
        err == hipSuccess,
        "packing kernel launch failed: ",
        hipGetErrorString(err));
}

torch::Tensor mha_forward(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor causal,
    torch::Tensor alibi_slopes,
    double sm_scale) {
    TORCH_CHECK(
        q.is_cuda() && k.is_cuda() && v.is_cuda(),
        "q, k, and v must be on the accelerator");
    TORCH_CHECK(
        alibi_slopes.is_cuda(),
        "alibi_slopes must be on the accelerator");
    TORCH_CHECK(
        q.device() == k.device() &&
        q.device() == v.device() &&
        q.device() == alibi_slopes.device(),
        "q, k, v, and slopes must share a device");

    const c10::cuda::CUDAGuard device_guard(q.device());

    TORCH_CHECK(causal.numel() == 1, "causal must be scalar");
    TORCH_CHECK(
        q.dim() == 4 && k.dim() == 4 && v.dim() == 4,
        "inputs must be 4-D");
    TORCH_CHECK(
        q.scalar_type() == k.scalar_type() &&
        q.scalar_type() == v.scalar_type(),
        "Q/K/V dtypes must match");
    TORCH_CHECK(
        q.scalar_type() == torch::kFloat16 ||
        q.scalar_type() == torch::kBFloat16 ||
        q.scalar_type() == torch::kFloat32,
        "inputs must be float16, bfloat16, or float32");
    TORCH_CHECK(
        alibi_slopes.scalar_type() == torch::kFloat32,
        "alibi_slopes must be float32");
    TORCH_CHECK(
        q.size(0) == k.size(0) && q.size(0) == v.size(0),
        "batch dimensions must match");
    TORCH_CHECK(
        q.size(3) == k.size(3) && q.size(3) == v.size(3),
        "head dimensions must match");
    TORCH_CHECK(
        k.size(1) == v.size(1) && k.size(2) == v.size(2),
        "key/value dimensions must match");
    TORCH_CHECK(
        alibi_slopes.dim() == 2 &&
        alibi_slopes.size(0) == q.size(0) &&
        alibi_slopes.size(1) == q.size(2),
        "invalid alibi_slopes shape");

    const int64_t batch = q.size(0);
    const int64_t sq = q.size(1);
    const int64_t nq = q.size(2);
    const int64_t dim = q.size(3);
    const int64_t sk = k.size(1);
    const int64_t nk = k.size(2);

    TORCH_CHECK(
        batch > 0 && sq > 0 && sk > 0 && nq > 0 &&
        nk > 0 && dim > 0 && dim <= 256,
        "invalid dimensions");
    TORCH_CHECK(
        nq % nk == 0,
        "num_q_heads must be divisible by num_kv_heads");

    q = q.contiguous();
    k = k.contiguous();
    v = v.contiguous();
    alibi_slopes = alibi_slopes.contiguous();
    causal = causal.to(q.device(), torch::kInt32).contiguous();

    const int64_t out_numel = q.numel();
    const int64_t rows = out_numel / dim;
    TORCH_CHECK(
        out_numel <= std::numeric_limits<int64_t>::max() - rows,
        "packed tensor is too large");

    auto out = torch::empty({batch, sq, nq, dim}, q.options());
    auto lse = torch::empty(
        {batch, nq, sq},
        q.options().dtype(torch::kFloat32));
    auto packed = torch::empty(
        {out_numel + rows},
        q.options().dtype(torch::kFloat32));

    hipStream_t stream = at::cuda::getCurrentCUDAStream();

    if (q.scalar_type() == torch::kFloat16) {
        launch_mha<at::Half>(
            q, k, v, causal, alibi_slopes, out, lse, packed,
            static_cast<float>(sm_scale), stream);
    } else if (q.scalar_type() == torch::kBFloat16) {
        launch_mha<at::BFloat16>(
            q, k, v, causal, alibi_slopes, out, lse, packed,
            static_cast<float>(sm_scale), stream);
    } else {
        launch_mha<float>(
            q, k, v, causal, alibi_slopes, out, lse, packed,
            static_cast<float>(sm_scale), stream);
    }

    return packed;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Dense (padded 4D batch) FlashAttention forward: scaled dot-product attention
    with softmax, bottom-right-aligned causal mask, ALiBi positional bias,
    MHA/GQA, returning both the output and the per-row log-sum-exp (LSE).

    Mathematical definition (for batch element b, query head h, query position i,
    key position j, g = num_q_heads // num_kv_heads, query head h maps to KV head
    h // g):
      score[b,h,i,j] = sm_scale * <q[b,i,h,:], k[b,j,h//g,:]>
                       - alibi_slopes[b,h] * |i + seqlen_k - seqlen_q - j|
      With causal=1 the bottom-right-aligned causal mask is applied: positions
      j > i + seqlen_k - seqlen_q are set to -inf (i.e. query i only attends to
      keys j <= i + seqlen_k - seqlen_q); with causal=0 no mask is applied at all.
      The ALiBi bias is applied in both causal and non-causal mode; all-zero
      slopes are equivalent to no ALiBi.
      p[b,h,i,:] = softmax_j(score[b,h,i,:])   (numerically stable online form)
      out[b,i,h,:] = sum_j p[b,h,i,j] * v[b,j,h//g,:]
      lse[b,h,i] = ln( sum_j exp(score[b,h,i,j]) )   (natural logarithm)
    softmax/accumulation are done in float32, out is cast back to the input dtype,
    lse is float32.
    Boundary behaviour: with causal=1 and seqlen_q > seqlen_k, rows
    i < seqlen_q - seqlen_k are masked out entirely -- those rows have out = 0 and
    lse = 0 (not -inf).

    Input/output specification:
      q            [batch, seqlen_q, num_q_heads, head_dim]   float16/bfloat16
      k, v         [batch, seqlen_k, num_kv_heads, head_dim]  same dtype as q
      causal       0-dim int32 tensor, 1=causal mask, 0=no mask
      alibi_slopes [batch, num_q_heads] float32, elements >= 0 (all zeros = no ALiBi)
      Returns a single 1-D tensor packed (multi-output packing protocol):
      packed = cat([out.reshape(-1).to(float32), lse.reshape(-1)])
      where out [batch, seqlen_q, num_q_heads, head_dim] (computed in the input
      dtype, then cast to float32 for the concatenation) and lse
      [batch, num_q_heads, seqlen_q] float32; total length of packed =
      batch * seqlen_q * num_q_heads * (head_dim + 1).
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (equal means MHA, otherwise GQA); 1 <= seqlen_q, 1 <= seqlen_k (any
    combination, including seqlen_q > seqlen_k); 1 <= head_dim <= 256.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / ALiBi bias / causal mask / softmax / PV / LSE)
        must be completed inside the submitted file; calling ready-made attention /
        matrix-multiplication / softmax routines is forbidden:
        scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax / torch.logsumexp, as is any
        synonymous wrapper from a third-party operator library.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast out back to the input
        dtype, keep lse in float32.
      - forward must return a single 1-D float32 tensor following the packing
        protocol above (compute out and lse internally first, then flatten and
        concatenate them).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: dense 4D forward, non-quantized inputs, no bias, no dropout, no
    sliding window.
    """
    def __init__(self, head_dim: int, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, causal, alibi_slopes):
        # <<<IMPROVE:forward_stmt_1>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal, dtype=torch.int32, device=q.device)
        else:
            causal = causal.to(device=q.device, dtype=torch.int32)
        return _pyramidkernel_get_extension().mha_forward(
            q, k, v, causal, alibi_slopes.to(torch.float32), float(self.sm_scale)
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        is_causal = bool(int(causal.to(torch.int32)))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        alibi_slopes = alibi_slopes.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        batch, seqlen_q, nheads_q, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        _, seqlen_k, nheads_k, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = nheads_q // nheads_k
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert nheads_q == nheads_k * group
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        qf = q.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        kf = k.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        vf = v.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        scores = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        scores = scores
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pos_q = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pos_k = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        relative = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        scores = scores
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        if is_causal:
            scores = scores
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        lse = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        fully_masked = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        lse = lse
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        probs = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        acc = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        acc = acc
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        out = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        return None
        # <<<END_IMPROVE>>>
