import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1022_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

void pa_prefill_forward(
    torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor,
    torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor,
    c10::optional<torch::Tensor>, torch::Tensor, double);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pa_prefill_forward", &pa_prefill_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <cmath>

template <class T>
__global__ void pa_prefill_kernel(
    const T* q, const T* k, const T* v,
    const T* kc, const T* vc,
    const int64_t* bt,
    const int32_t* starts,
    const int32_t* lens,
    const float* slopes,
    T* out,
    int64_t N, int64_t H, int64_t D, int64_t HK,
    int64_t BS, int64_t NB, int64_t B, int64_t M,
    float scale) {
    const int64_t row = static_cast<int64_t>(blockIdx.x);
    const int64_t lane = static_cast<int64_t>(threadIdx.x);
    if (row >= N * H || lane >= 64) return;

    const int64_t token = row / H;
    const int64_t head = row % H;

    int64_t lo = 0;
    int64_t hi = B;
    while (lo < hi) {
        const int64_t mid = lo + (hi - lo) / 2;
        if (static_cast<int64_t>(starts[mid + 1]) <= token)
            lo = mid + 1;
        else
            hi = mid;
    }
    if (lo >= B) return;

    const int64_t begin = static_cast<int64_t>(starts[lo]);
    const int64_t end = static_cast<int64_t>(starts[lo + 1]);
    if (begin < 0 || end < begin || end > N || token < begin || token >= end)
        return;

    const int64_t qlen = end - begin;
    const int64_t ctx = static_cast<int64_t>(lens[lo]) - qlen;
    if (ctx < 0) return;

    const int64_t pos = ctx + token - begin;
    const int64_t group = H / HK;
    const int64_t kh = head / group;

    extern __shared__ float smem[];
    float* qs = smem;
    float* acc = smem + D;

    for (int64_t d = lane; d < D; d += 64) {
        qs[d] = static_cast<float>(q[row * D + d]) * scale;
        acc[d] = 0.0f;
    }
    __syncthreads();

    float maximum = -INFINITY;
    float denom = 0.0f;
    const float slope = slopes != nullptr ? slopes[head] : 0.0f;

    for (int64_t l = 0; l <= pos; ++l) {
        const bool prefix = l < ctx;
        int64_t physical = -1;
        int64_t nt = -1;
        const int64_t slot = l % BS;

        if (prefix) {
            const int64_t column = l / BS;
            if (column < 0 || column >= M) continue;
            physical = bt[lo * M + column];
            if (physical < 0 || physical >= NB) continue;
        } else {
            nt = begin + l - ctx;
            if (nt < begin || nt >= end || nt < 0 || nt >= N) continue;
        }

        float dot = 0.0f;
        for (int64_t d = lane; d < D; d += 64) {
            if (prefix) {
                const int64_t off =
                    ((((physical * HK + kh) * (D / 8) + d / 8) * BS + slot) * 8) +
                    d % 8;
                dot += qs[d] * static_cast<float>(kc[off]);
            } else {
                const int64_t off = (nt * HK + kh) * D + d;
                dot += qs[d] * static_cast<float>(k[off]);
            }
        }

        for (int delta = 32; delta > 0; delta >>= 1)
            dot += __shfl_xor(dot, delta, 64);

        const float score = dot + slope * static_cast<float>(l - pos);
        const float next_max = fmaxf(maximum, score);
        const float old_factor = expf(maximum - next_max);
        const float weight = expf(score - next_max);

        denom = denom * old_factor + weight;
        maximum = next_max;

        for (int64_t d = lane; d < D; d += 64) {
            float value;
            if (prefix) {
                const int64_t off = ((physical * HK + kh) * D + d) * BS + slot;
                value = static_cast<float>(vc[off]);
            } else {
                const int64_t off = (nt * HK + kh) * D + d;
                value = static_cast<float>(v[off]);
            }
            acc[d] = acc[d] * old_factor + weight * value;
        }
    }

    __syncthreads();
    for (int64_t d = lane; d < D; d += 64)
        out[row * D + d] = static_cast<T>(
            denom > 0.0f ? acc[d] / denom : 0.0f);
}

template <class T, int64_t DH>
__global__ void pa_prefill_register_kernel(
    const T* q, const T* k, const T* v,
    const T* kc, const T* vc,
    const int64_t* bt,
    const int32_t* starts,
    const int32_t* lens,
    const float* slopes,
    T* out,
    int64_t N, int64_t H, int64_t D, int64_t HK,
    int64_t BS, int64_t NB, int64_t B, int64_t M,
    float scale) {
    static_assert(DH == 64 || DH == 128 || DH == 256, "Invalid specialization");
    const int64_t row = static_cast<int64_t>(blockIdx.x);
    const int64_t lane = static_cast<int64_t>(threadIdx.x);
    if (row >= N * H || lane >= 64 || D != DH) return;

    const int64_t token = row / H;
    const int64_t head = row % H;

    int64_t lo = 0;
    int64_t hi = B;
    while (lo < hi) {
        const int64_t mid = lo + (hi - lo) / 2;
        if (static_cast<int64_t>(starts[mid + 1]) <= token)
            lo = mid + 1;
        else
            hi = mid;
    }
    if (lo >= B) return;

    const int64_t begin = static_cast<int64_t>(starts[lo]);
    const int64_t end = static_cast<int64_t>(starts[lo + 1]);
    if (begin < 0 || end < begin || end > N || token < begin || token >= end)
        return;

    const int64_t qlen = end - begin;
    const int64_t ctx = static_cast<int64_t>(lens[lo]) - qlen;
    if (ctx < 0) return;

    const int64_t pos = ctx + token - begin;
    const int64_t group = H / HK;
    const int64_t kh = head / group;

    float qreg[DH / 64];
    float areg[DH / 64];
    #pragma unroll
    for (int64_t i = 0; i < DH / 64; ++i) {
        const int64_t d = lane + 64 * i;
        qreg[i] = static_cast<float>(q[row * DH + d]) * scale;
        areg[i] = 0.0f;
    }

    float maximum = -INFINITY;
    float denom = 0.0f;
    const float slope = slopes != nullptr ? slopes[head] : 0.0f;

    for (int64_t page_begin = 0, column = 0;
         page_begin < ctx; page_begin += BS, ++column) {
        if (column >= M) continue;
        const int64_t physical = bt[lo * M + column];
        if (physical < 0 || physical >= NB) continue;

        int64_t kbase[DH / 64];
        int64_t vbase[DH / 64];
        #pragma unroll
        for (int64_t i = 0; i < DH / 64; ++i) {
            const int64_t d = lane + 64 * i;
            kbase[i] =
                (((physical * HK + kh) * (DH / 8) + d / 8) * BS) * 8 + d % 8;
            vbase[i] = ((physical * HK + kh) * DH + d) * BS;
        }
        const int64_t slots = BS < ctx - page_begin ? BS : ctx - page_begin;
        for (int64_t slot = 0; slot < slots; ++slot) {
            const int64_t l = page_begin + slot;
            float dot = 0.0f;
            #pragma unroll
            for (int64_t i = 0; i < DH / 64; ++i) {
                const int64_t off = kbase[i] + slot * 8;
                dot += qreg[i] * static_cast<float>(kc[off]);
            }

            for (int delta = 32; delta > 0; delta >>= 1)
                dot += __shfl_xor(dot, delta, 64);

            const float score = dot + slope * static_cast<float>(l - pos);
            const float next_max = fmaxf(maximum, score);
            const float old_factor = expf(maximum - next_max);
            const float weight = expf(score - next_max);

            denom = denom * old_factor + weight;
            maximum = next_max;

            #pragma unroll
            for (int64_t i = 0; i < DH / 64; ++i) {
                const int64_t off = vbase[i] + slot;
                const float value = static_cast<float>(vc[off]);
                areg[i] = areg[i] * old_factor + weight * value;
            }
        }
    }

    for (int64_t nt = begin; nt <= token; ++nt) {
        if (nt < begin || nt >= end || nt < 0 || nt >= N) continue;
        const int64_t l = ctx + nt - begin;

        float dot = 0.0f;
        #pragma unroll
        for (int64_t i = 0; i < DH / 64; ++i) {
            const int64_t d = lane + 64 * i;
            const int64_t off = (nt * HK + kh) * DH + d;
            dot += qreg[i] * static_cast<float>(k[off]);
        }

        for (int delta = 32; delta > 0; delta >>= 1)
            dot += __shfl_xor(dot, delta, 64);

        const float score = dot + slope * static_cast<float>(l - pos);
        const float next_max = fmaxf(maximum, score);
        const float old_factor = expf(maximum - next_max);
        const float weight = expf(score - next_max);

        denom = denom * old_factor + weight;
        maximum = next_max;

        #pragma unroll
        for (int64_t i = 0; i < DH / 64; ++i) {
            const int64_t d = lane + 64 * i;
            const int64_t off = (nt * HK + kh) * DH + d;
            const float value = static_cast<float>(v[off]);
            areg[i] = areg[i] * old_factor + weight * value;
        }
    }

    #pragma unroll
    for (int64_t i = 0; i < DH / 64; ++i) {
        const int64_t d = lane + 64 * i;
        out[row * DH + d] = static_cast<T>(
            denom > 0.0f ? areg[i] / denom : 0.0f);
    }
}

void pa_prefill_forward(
    torch::Tensor q,
    torch::Tensor k,
    torch::Tensor v,
    torch::Tensor kc,
    torch::Tensor vc,
    torch::Tensor bt,
    torch::Tensor starts,
    torch::Tensor lens,
    c10::optional<torch::Tensor> slopes,
    torch::Tensor out,
    double scale) {
    c10::cuda::CUDAGuard guard(q.device());

    for (const auto& t : {q, k, v, kc, vc, bt, starts, lens, out}) {
        TORCH_CHECK(
            t.is_cuda() && t.device() == q.device() && t.is_contiguous(),
            "Expected contiguous tensors on the query device");
    }

    TORCH_CHECK(
        q.dim() == 3 && k.dim() == 3 && v.dim() == 3 &&
        kc.dim() == 5 && vc.dim() == 4 && bt.dim() == 2 &&
        starts.dim() == 1 && lens.dim() == 1,
        "Invalid dimensions");

    const int64_t N = q.size(0);
    const int64_t H = q.size(1);
    const int64_t D = q.size(2);
    const int64_t HK = k.size(1);
    const int64_t BS = vc.size(3);
    const int64_t NB = vc.size(0);
    const int64_t B = lens.numel();
    const int64_t M = bt.size(1);

    TORCH_CHECK(
        H > 0 && HK > 0 && H % HK == 0 && D > 0 && D % 8 == 0 &&
        BS > 0 && 2 * D * static_cast<int64_t>(sizeof(float)) <= 49152,
        "Invalid attention dimensions");

    TORCH_CHECK(
        k.size(0) == N && k.size(2) == D &&
        v.sizes() == k.sizes() && out.sizes() == q.sizes(),
        "Invalid token shapes");

    TORCH_CHECK(
        kc.size(0) == NB && kc.size(1) == HK && kc.size(2) == D / 8 &&
        kc.size(3) == BS && kc.size(4) == 8 &&
        vc.size(1) == HK && vc.size(2) == D &&
        bt.size(0) == B && starts.numel() == B + 1,
        "Invalid cache or metadata shapes");

    TORCH_CHECK(
        bt.scalar_type() == at::kLong &&
        starts.scalar_type() == at::kInt &&
        lens.scalar_type() == at::kInt,
        "Invalid metadata dtype");

    for (const auto& t : {k, v, kc, vc, out})
        TORCH_CHECK(t.scalar_type() == q.scalar_type(), "Mismatched dtype");

    TORCH_CHECK(
        q.scalar_type() == at::kFloat ||
        q.scalar_type() == at::kHalf ||
        q.scalar_type() == at::kBFloat16,
        "Expected float, fp16, or bf16");

    const float* slope_ptr = nullptr;
    if (slopes.has_value()) {
        const auto s = slopes.value();
        TORCH_CHECK(
            s.is_cuda() && s.device() == q.device() &&
            s.is_contiguous() && s.scalar_type() == at::kFloat &&
            s.dim() == 1 && s.numel() == H,
            "Invalid slopes");
        slope_ptr = s.data_ptr<float>();
    }

    TORCH_CHECK(N * H <= 2147483647LL, "Launch grid too large");
    if (N == 0) return;

    auto stream = at::cuda::getCurrentCUDAStream();

#define PA_REGISTER_LAUNCH(DIM) \
    hipLaunchKernelGGL( \
        (pa_prefill_register_kernel<scalar_t, DIM>), \
        dim3(static_cast<unsigned int>(N * H)), dim3(64), 0, stream, \
        q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), \
        v.data_ptr<scalar_t>(), kc.data_ptr<scalar_t>(), \
        vc.data_ptr<scalar_t>(), bt.data_ptr<int64_t>(), \
        starts.data_ptr<int32_t>(), lens.data_ptr<int32_t>(), \
        slope_ptr, out.data_ptr<scalar_t>(), \
        N, H, D, HK, BS, NB, B, M, static_cast<float>(scale))

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::kHalf, at::kBFloat16, q.scalar_type(), "pa_prefill", [&] {
            if (D == 64) {
                PA_REGISTER_LAUNCH(64);
            } else if (D == 128) {
                PA_REGISTER_LAUNCH(128);
            } else if (D == 256) {
                PA_REGISTER_LAUNCH(256);
            } else {
                hipLaunchKernelGGL(
                    (pa_prefill_kernel<scalar_t>),
                    dim3(static_cast<unsigned int>(N * H)),
                    dim3(64),
                    static_cast<size_t>(2 * D * sizeof(float)),
                    stream,
                    q.data_ptr<scalar_t>(),
                    k.data_ptr<scalar_t>(),
                    v.data_ptr<scalar_t>(),
                    kc.data_ptr<scalar_t>(),
                    vc.data_ptr<scalar_t>(),
                    bt.data_ptr<int64_t>(),
                    starts.data_ptr<int32_t>(),
                    lens.data_ptr<int32_t>(),
                    slope_ptr,
                    out.data_ptr<scalar_t>(),
                    N, H, D, HK, BS, NB, B, M,
                    static_cast<float>(scale));
            }
        });
#undef PA_REGISTER_LAUNCH

    hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess, hipGetErrorString(error));

    error = hipDeviceSynchronize();
    TORCH_CHECK(error == hipSuccess, hipGetErrorString(error));
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Paged KV prefix (context) attention: attention for prefill multi-token queries.

    (MHA/GQA, causal + optional ALiBi.)

    Within a batch, num_seqs sequences run in parallel; sequence b has
    query_len[b] = query_start_loc[b+1] - query_start_loc[b] newly computed query
    tokens in this round, and the slices of all sequences are flattened and
    concatenated along the token dimension in query_start_loc order (no
    padding). The current total length of the sequence is seq_lens[b], of which
    the first ctx_len[b] = seq_lens[b] - query_len[b] tokens are the already
    admitted prefix K/V, stored only in the paged KV cache; the K/V of the new
    tokens of this round are given explicitly only as key / value (the cache
    does not contain the new tokens). query_len[b] > 1 means prefill, and == 1
    is also legal (a single-token query against the pure prefix).

    Paged layout: the physical block pool has num_blocks blocks, each holding
    block_size token slots; block_tables[b] is the "prefix logical block ->
    physical block id" table of that sequence, where only the first
    ceil(ctx_len[b]/block_size) columns are valid (the remaining columns are
    garbage). K uses the channel-packed layout: the K channel d of the l-th
    prefix token is stored at
    key_cache[bt[b, l//block_size], h_kv, d//x, l%block_size, d%x]
    (x = 8, head_size is a multiple of 8); V is stored at
    value_cache[bt[b, l//block_size], h_kv, d, l%block_size]. Blocks in the pool
    that are not referenced, as well as slots beyond the prefix length inside
    referenced blocks, are garbage data (magnitudes up to +/-10) and must not
    participate in the computation.

    For the j-th new token of the h-th query head of sequence b (the
    corresponding KV head is h // query_group_size, query_group_size =
    num_heads / num_kv_heads), at in-sequence absolute position pos =
    ctx_len[b] + j:

      logits[l] = scale * <query[pos, h, :], K[l]> + alibi_slopes[h] * (l - pos)
      causal mask: logits at positions l > pos are set to -inf
      p[l] = exp(logits[l] - max_l' logits[l']) / sum_l' exp(logits[l'] - max_l' logits[l'])
      out[pos, h, :] = sum_{l = 0..pos} p[l] * V[l]

    where K[l] / V[l]: for l < ctx_len[b] they come from the paged cache
    (indirect addressing through the block table), and for l >= ctx_len[b] they
    come from key / value. When alibi_slopes is None no bias term is added (it
    degenerates to the unbiased baseline); when a float32 [num_heads] tensor is
    given, the ALiBi bias is added as in the formula above (the bias is 0 at
    l == pos). The softmax uses an online (numerically stable) implementation,
    intermediate accumulation is in float32, and the output is cast back to the
    input dtype.

    Input/output specification (forward parameter order):
      query           [num_tokens, num_heads, head_size]                    fp16/bf16
      key             [num_tokens, num_kv_heads, head_size]                 same as query
      value           [num_tokens, num_kv_heads, head_size]                 same as query
      key_cache       [num_blocks, num_kv_heads, head_size//8, block_size, 8]   same as query
      value_cache     [num_blocks, num_kv_heads, head_size, block_size]         same as query
      block_tables    [num_seqs, max_blocks_per_seq]                         int32
      query_start_loc [num_seqs+1] int32 (prefix sum of query_len, first element 0)
      seq_lens        [num_seqs] int32
      alibi_slopes    [num_heads] float32, or None (no ALiBi bias)
      returns out     [num_tokens, num_heads, head_size], dtype same as query.
      scale defaults to 1/sqrt(head_size) (given by head_size in __init__).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        torch.matmul / torch.bmm / torch.einsum / torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: prefill multi-token queries, non-quantized KV; includes the ALiBi
    bias variant and the unbiased baseline (alibi_slopes passed as None); does
    not include sliding window, does not include a quantized KV cache, and the
    K/V of the new tokens of this round are not written into the cache.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens, alibi_slopes=None):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        query_start_loc = query_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        slopes = None if alibi_slopes is None else alibi_slopes.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        num_tokens, num_heads, head_size = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_kv_heads = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        block_size = value_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        x = key_cache.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        group = num_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert num_heads == num_kv_heads * group, "num_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        assert head_size == (head_size // x) * x, "head_size must be an integer multiple of x"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        _pyramidkernel_get_extension().pa_prefill_forward(
            query, key, value, key_cache, value_cache, block_tables,
            query_start_loc, seq_lens, slopes, out, float(self.scale))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return out
        # <<<END_IMPROVE>>>
