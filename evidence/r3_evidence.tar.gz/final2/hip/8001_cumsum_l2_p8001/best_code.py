import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p8001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Cumsum (inclusive prefix sum): a sequential accumulation along a given
    dimension.

    Operator definition: for an n-dimensional input x and the scan dimension
    `dim`, the output out has the same shape as x:
        out[i_0, ..., i_k, ...] = sum_{j <= i_dim} x[i_0, ..., j, ...]
    i.e. an inclusive prefix sum along dimension `dim` (including the current
    element), with every other dimension accumulating independently per chain.
    The __init__ parameter `dim` selects the scan dimension (torch convention:
    non-negative counts from 0, negative counts from the end, e.g. -1 means the
    last dimension), defaulting to 2.

    Numeric contract: accumulation always happens in float32 -- float16/bfloat16
    inputs are first cast to float32, accumulated, then cast back to the input
    dtype (matching the compute-in-fp32 convention of production scan
    libraries).

    Input/output specification:
        x     float32 / float16 / bfloat16, contiguous, ndim in [1, 4],
              every dimension >= 1, scan dimension length L in [1, 65536],
              total element count <= 2^25; values are ordinary randn magnitude
              (no inf/NaN)
        out   a single tensor, same shape / dtype as x, contiguous; forward must
              return a single tensor (the evaluator compares .shape / allclose
              on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless); the offline final audit passes inputs
        natively in their declared dtype -- the implementation must be correct
        for both.

    Boundary behaviour: when L=1, out equals x (cast back to the input dtype);
    non-power-of-two L, prime lengths, and axes longer than a single block's
    capacity must all be handled correctly with masking plus a blocked scan, and
    out-of-range lanes must not contribute to the prefix sum; a negative `dim`
    follows the torch convention.

    Implementation constraints (violations are scored as failures):
        - The core scan (prefix sum) must be handwritten with a HIP kernel
          inside the submitted file; calling any library-level scan primitive is
          forbidden, as is bypassing via mathematically equivalent paths such as
          FFT / matrix multiplication / convolution.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate in float32 and cast the output back to the input dtype.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.cumsum / .cumsum( / torch.cumulative_sum / .cumulative_sum( /
    aten.cumsum / aten.cumulative_sum /
    torch.fft / torch.matmul / torch.mm / torch.bmm / torch.einsum /
    conv1d( / numpy / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, dim: int = 2):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.dim = int(dim)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        ndim = x.dim()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert -ndim <= self.dim < ndim, "dim must point at an existing dimension of the input"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        y = torch.cumsum(x.to(torch.float32), dim=self.dim)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return y.to(x.dtype)
        # <<<END_IMPROVE>>>
