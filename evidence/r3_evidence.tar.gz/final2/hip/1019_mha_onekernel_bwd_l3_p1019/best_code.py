import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1019_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor
mha_backward_fused(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                   torch::Tensor o, torch::Tensor lse, torch::Tensor grad_o,
                   double sm_scale, bool causal);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mha_backward_fused", &mha_backward_fused,
          "Fused HIP multi-head attention backward");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cstdint>
#include <cmath>
#include <limits>

template <typename T>
__device__ __forceinline__ float load_value(const T* p, int64_t i) {
    return static_cast<float>(p[i]);
}

template <typename T>
__device__ __forceinline__ float rounded_value(float x) {
    return static_cast<float>(static_cast<T>(x));
}

template <typename T>
__global__ void mha_kernel(
    const T* __restrict__ q,
    const T* __restrict__ k,
    const T* __restrict__ v,
    const T* __restrict__ o,
    const float* __restrict__ lse,
    const T* __restrict__ grad_o,
    float* __restrict__ packed,
    int64_t B,
    int64_t M,
    int64_t N,
    int64_t HQ,
    int64_t HK,
    int64_t D,
    float scale,
    bool causal,
    int64_t total) {
    const int64_t z =
        static_cast<int64_t>(blockIdx.x) * static_cast<int64_t>(blockDim.x) +
        static_cast<int64_t>(threadIdx.x);
    if (z < 0 || z >= total) {
        return;
    }

    const int64_t q_size = B * M * HQ * D;
    const int64_t kv_size = B * N * HK * D;
    const int64_t group = HQ / HK;

    if (z < q_size) {
        int64_t t = z;
        const int64_t d = t % D;
        t /= D;
        const int64_t h = t % HQ;
        t /= HQ;
        const int64_t i = t % M;
        const int64_t b = t / M;
        const int64_t hk = h / group;

        const int64_t q_base = ((b * M + i) * HQ + h) * D;
        const int64_t lse_index = (b * HQ + h) * M + i;

        float delta = 0.0f;
        for (int64_t r = 0; r < D; ++r) {
            delta += load_value(o, q_base + r) *
                     load_value(grad_o, q_base + r);
        }

        float accum = 0.0f;
        for (int64_t j = 0; j < N; ++j) {
            if (causal && j > i + N - M) {
                continue;
            }

            const int64_t k_base = ((b * N + j) * HK + hk) * D;
            float qk = 0.0f;
            float dp = 0.0f;
            for (int64_t r = 0; r < D; ++r) {
                qk += load_value(q, q_base + r) *
                      load_value(k, k_base + r);
                dp += load_value(grad_o, q_base + r) *
                      load_value(v, k_base + r);
            }

            const float p = expf(scale * qk - lse[lse_index]);
            const float ds = p * (dp - delta);
            accum += ds * load_value(k, k_base + d);
        }

        packed[z] = rounded_value<T>(scale * accum);
        return;
    }

    const int64_t kv_local = z - q_size;
    if (kv_local < 0 || kv_local >= kv_size) {
        return;
    }

    int64_t t = kv_local;
    const int64_t d = t % D;
    t /= D;
    const int64_t hk = t % HK;
    t /= HK;
    const int64_t j = t % N;
    const int64_t b = t / N;

    float accum_k = 0.0f;
    float accum_v = 0.0f;

    for (int64_t h = hk * group; h < (hk + 1) * group; ++h) {
        for (int64_t i = 0; i < M; ++i) {
            if (causal && j > i + N - M) {
                continue;
            }

            const int64_t q_base = ((b * M + i) * HQ + h) * D;
            const int64_t k_base = ((b * N + j) * HK + hk) * D;
            const int64_t lse_index = (b * HQ + h) * M + i;

            float qk = 0.0f;
            float dp = 0.0f;
            float delta = 0.0f;
            for (int64_t r = 0; r < D; ++r) {
                qk += load_value(q, q_base + r) *
                      load_value(k, k_base + r);
                dp += load_value(grad_o, q_base + r) *
                      load_value(v, k_base + r);
                delta += load_value(o, q_base + r) *
                         load_value(grad_o, q_base + r);
            }

            const float p = expf(scale * qk - lse[lse_index]);
            accum_k += p * (dp - delta) * load_value(q, q_base + d);
            accum_v += p * load_value(grad_o, q_base + d);
        }
    }

    packed[q_size + kv_local] = rounded_value<T>(scale * accum_k);
    packed[q_size + kv_size + kv_local] = rounded_value<T>(accum_v);
}

torch::Tensor
mha_backward_fused(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                   torch::Tensor o, torch::Tensor lse, torch::Tensor grad_o,
                   double sm_scale, bool causal) {
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda() &&
                o.is_cuda() && lse.is_cuda() && grad_o.is_cuda(),
                "all inputs must be CUDA/HIP tensors");

    TORCH_CHECK(q.device() == k.device() &&
                q.device() == v.device() &&
                q.device() == o.device() &&
                q.device() == lse.device() &&
                q.device() == grad_o.device(),
                "all inputs must be on the same device");

    const c10::cuda::CUDAGuard device_guard(q.device());

    TORCH_CHECK(q.scalar_type() == at::kFloat ||
                q.scalar_type() == at::kHalf ||
                q.scalar_type() == at::kBFloat16,
                "inputs must be float32, float16, or bfloat16");

    TORCH_CHECK(k.scalar_type() == q.scalar_type() &&
                v.scalar_type() == q.scalar_type() &&
                o.scalar_type() == q.scalar_type() &&
                grad_o.scalar_type() == q.scalar_type(),
                "Q/K/V/O/dO must have the same dtype");

    TORCH_CHECK(lse.scalar_type() == at::kFloat,
                "lse must be float32");

    TORCH_CHECK(q.dim() == 4 && k.dim() == 4 && v.dim() == 4 &&
                o.dim() == 4 && grad_o.dim() == 4 && lse.dim() == 3,
                "invalid input rank");

    TORCH_CHECK(q.is_contiguous() && k.is_contiguous() &&
                v.is_contiguous() && o.is_contiguous() &&
                lse.is_contiguous() && grad_o.is_contiguous(),
                "inputs must be contiguous");

    const int64_t B = q.size(0);
    const int64_t M = q.size(1);
    const int64_t HQ = q.size(2);
    const int64_t D = q.size(3);
    const int64_t N = k.size(1);
    const int64_t HK = k.size(2);

    TORCH_CHECK(B > 0 && M > 0 && N > 0 && HQ > 0 && HK > 0 && D > 0,
                "input dimensions must be positive");
    TORCH_CHECK(D <= 256, "head dimension must be at most 256");
    TORCH_CHECK(HQ % HK == 0,
                "num_q_heads must be divisible by num_kv_heads");

    TORCH_CHECK(k.size(0) == B && v.size(0) == B &&
                o.size(0) == B && grad_o.size(0) == B,
                "batch dimensions must match");
    TORCH_CHECK(k.size(3) == D && v.size(3) == D &&
                o.size(3) == D && grad_o.size(3) == D,
                "head dimensions must match");
    TORCH_CHECK(o.size(1) == M && grad_o.size(1) == M &&
                o.size(2) == HQ && grad_o.size(2) == HQ,
                "query dimensions must match");
    TORCH_CHECK(v.size(1) == N && v.size(2) == HK,
                "key/value dimensions must match");
    TORCH_CHECK(lse.size(0) == B && lse.size(1) == HQ &&
                lse.size(2) == M,
                "lse dimensions must match");

    const int64_t q_size = q.numel();
    const int64_t kv_size = k.numel();
    TORCH_CHECK(q_size >= 0 && kv_size >= 0 &&
                kv_size <= (std::numeric_limits<int64_t>::max() - q_size) / 2,
                "combined output size exceeds int64");
    const int64_t total = q_size + 2 * kv_size;
    const int64_t work_size = q_size + kv_size;

    const int64_t threads = 256;
    const uint64_t blocks =
        (static_cast<uint64_t>(work_size) +
         static_cast<uint64_t>(threads) - 1u) /
        static_cast<uint64_t>(threads);

    TORCH_CHECK(blocks > 0 &&
                blocks <= static_cast<uint64_t>(std::numeric_limits<int>::max()),
                "launch grid is too large");

    auto packed = torch::empty({total}, q.options().dtype(at::kFloat));
    const auto stream = c10::cuda::getCurrentCUDAStream(q.get_device());

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        q.scalar_type(),
        "mha_backward_fused_hip",
        [&] {
            hipLaunchKernelGGL(
                (mha_kernel<scalar_t>),
                dim3(static_cast<unsigned int>(blocks)),
                dim3(static_cast<unsigned int>(threads)),
                0,
                stream.stream(),
                q.data_ptr<scalar_t>(),
                k.data_ptr<scalar_t>(),
                v.data_ptr<scalar_t>(),
                o.data_ptr<scalar_t>(),
                lse.data_ptr<float>(),
                grad_o.data_ptr<scalar_t>(),
                packed.data_ptr<float>(),
                B, M, N, HQ, HK, D,
                static_cast<float>(sm_scale),
                causal,
                work_size);

            hipError_t err = hipGetLastError();
            TORCH_CHECK(err == hipSuccess,
                        "mha_backward_fused kernel launch failed: ",
                        hipGetErrorString(err));
        });

    return packed;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    FlashAttention backward (one-kernel form): given the forward output o and the
    per-row log-sum-exp statistics lse, compute the gradients (dq, dk, dv) from
    (q, k, v, o, lse, do); dK/dV and dQ are produced inside the same kernel
    (dK/dV first, dQ after).

    Mathematical definition (let g = num_q_heads // num_kv_heads and the scaled
    score be s[b,h,i,j] = sm_scale * <q[b,i,h,:], k[b,j,h//g,:]>,
    with sm_scale defaulting to 1/sqrt(head_dim)):
      keep[b,i,j] = (j <= i + seqlen_k - seqlen_q) when causal=1 (bottom-right
                    aligned), always true when causal=0
      p[b,h,i,j]   = exp(s[b,h,i,j] - lse[b,h,i]), and masked positions (keep=0) are always 0
      delta[b,h,i] = sum_d o[b,i,h,d] * do[b,i,h,d]   (computed from the given o)
      dp[b,h,i,j]  = <do[b,i,h,:], v[b,j,h//g,:]>
      ds[b,h,i,j]  = p[b,h,i,j] * (dp[b,h,i,j] - delta[b,h,i])
      dv[b,j,h_k,d] = sum_{h = h_k*g .. h_k*g+g-1} sum_i p[b,h,i,j] * do[b,i,h,d]
      dk[b,j,h_k,d] = sm_scale * sum_{h in the same group} sum_i ds[b,h,i,j] * q[b,i,h,d]
      dq[b,i,h,d]   = sm_scale * sum_j ds[b,h,i,j] * k[b,j,h//g,d]
    Note that dK/dQ are multiplied by sm_scale at the end while dV is not; delta
    uses the input o (not the ideal forward output).
    Boundary behaviour: when causal=1 and i < seqlen_q - seqlen_k the row is fully
    masked -- p/ds are always 0, the dq row is all 0, and it contributes nothing to
    dk/dv (the task input convention sets o=0 and lse=0 for those rows).

    Input/output specification:
      q, o, do  [batch, seqlen_q, num_q_heads, head_dim] float16/bfloat16
      k, v      [batch, seqlen_k, num_kv_heads, head_dim] same dtype as q
      lse       [batch, num_q_heads, seqlen_q] float32 -- natural-log log-sum-exp of
                the scaled scores (0 for fully masked rows)
      returns a single 1-D tensor packed (multi-output packing protocol):
      packed = cat([dq flattened, dk flattened, dv flattened]) (each segment is
      first cast back to the input dtype, then converted to float32)
      where dq has the same shape as q and dk/dv the same shape as k; the total
      length of packed is
      (batch*seqlen_q*num_q_heads + 2*batch*seqlen_k*num_kv_heads) * head_dim.
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
      (GQA; equal means MHA); 1 <= head_dim <= 256 (need not be a power of 2);
      1 <= seqlen_q, seqlen_k; o and lse are the self-consistent forward statistics
      of (q, k, v) (guaranteed by the task's input generator).

    Implementation constraints (violations are scored as failures):
      - The core computation (all matrix multiplies and elementwise operations of
        delta / p / ds / dV / dK / dQ) must be done inside the submitted file;
        calling scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden, and so are
        automatic-differentiation shortcuts such as torch.autograd /
        autograd.grad / .backward(.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - forward must return a single 1-D float32 tensor following the packing
        protocol above (compute dq/dk/dv internally first, then flatten and
        concatenate each).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: dense fixed-length (non-varlen), non-quantized inputs, no dropout /
    ALiBi / bias / fp8; causal and non-causal are selected by __init__'s causal
    switch.
    """
    def __init__(self, head_dim: int, causal: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.head_dim = int(head_dim)
        self.causal = bool(int(causal))
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, o, lse, do):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().mha_backward_fused(
            q, k, v, o, lse, do, self.sm_scale, bool(self.causal)
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
