import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2006_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor fused_residual_layernorm(
    torch::Tensor x, torch::Tensor residual,
    torch::Tensor weight, torch::Tensor bias, double eps);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_residual_layernorm", &fused_residual_layernorm);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <algorithm>
#include <cstdint>
#include <limits>

__device__ __forceinline__ float rounded_mul(float a, float b) {
    volatile float result = a * b;
    return result;
}

__device__ __forceinline__ float row_sum_fallback(float value, float* scratch) {
    const int t = threadIdx.x;
    scratch[t] = value;
    __syncthreads();
    for (int step = 128; step > 0; step >>= 1) {
        if (t < step) scratch[t] += scratch[t + step];
        __syncthreads();
    }
    float result = scratch[0];
    __syncthreads();
    return result;
}

template <int WaveSize>
__device__ __forceinline__ float row_sum(float value, float* scratch) {
    if constexpr (WaveSize == 32 || WaveSize == 64) {
        const int lane = threadIdx.x % WaveSize;
        const int wave = threadIdx.x / WaveSize;
        #pragma unroll
        for (int offset = WaveSize / 2; offset > 0; offset >>= 1) {
            value += __shfl_down(value, offset, WaveSize);
        }
        if (lane == 0) scratch[wave] = value;
        __syncthreads();
        if (wave == 0) {
            float partial = lane < 256 / WaveSize ? scratch[lane] : 0.0f;
            #pragma unroll
            for (int offset = WaveSize / 2; offset > 0; offset >>= 1) {
                partial += __shfl_down(partial, offset, WaveSize);
            }
            if (lane == 0) scratch[0] = partial;
        }
        __syncthreads();
        return scratch[0];
    } else {
        return row_sum_fallback(value, scratch);
    }
}

template <typename scalar_t, int WaveSize>
__global__ void short_residual_norm_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ residual,
    const scalar_t* __restrict__ weight,
    const scalar_t* __restrict__ bias,
    scalar_t* __restrict__ out,
    int64_t M, int64_t N, float eps) {
    const int lane = threadIdx.x % WaveSize;
    const int wave = threadIdx.x / WaveSize;
    constexpr int RowsPerBlock = 256 / WaveSize;
    const int64_t stride = static_cast<int64_t>(gridDim.x) * RowsPerBlock;
    for (int64_t row = static_cast<int64_t>(blockIdx.x) * RowsPerBlock + wave;
         row < M; row += stride) {
        const int64_t input_base = row * N;
        const int64_t output_base = row * (2 * N);
        float values[256 / WaveSize];
        float sum = 0.0f;
        #pragma unroll
        for (int k = 0; k < 256 / WaveSize; ++k) {
            const int64_t j = static_cast<int64_t>(lane) +
                              static_cast<int64_t>(k) * WaveSize;
            float value = 0.0f;
            if (j < N) {
                scalar_t s = static_cast<scalar_t>(
                    static_cast<float>(x[input_base + j]) +
                    static_cast<float>(residual[input_base + j]));
                value = static_cast<float>(s);
                out[output_base + N + j] = s;
            }
            values[k] = value;
            sum += value;
        }
        #pragma unroll
        for (int offset = WaveSize / 2; offset > 0; offset >>= 1) {
            sum += __shfl_down(sum, offset, WaveSize);
        }
        const float mean = __shfl(sum, 0, WaveSize) / static_cast<float>(N);
        float squared = 0.0f;
        #pragma unroll
        for (int k = 0; k < 256 / WaveSize; ++k) {
            const int64_t j = static_cast<int64_t>(lane) +
                              static_cast<int64_t>(k) * WaveSize;
            if (j < N) {
                float delta = values[k] - mean;
                squared += rounded_mul(delta, delta);
            }
        }
        #pragma unroll
        for (int offset = WaveSize / 2; offset > 0; offset >>= 1) {
            squared += __shfl_down(squared, offset, WaveSize);
        }
        const float variance = __shfl(squared, 0, WaveSize) / static_cast<float>(N);
        const float rstd = rsqrtf(variance + eps);
        #pragma unroll
        for (int k = 0; k < 256 / WaveSize; ++k) {
            const int64_t j = static_cast<int64_t>(lane) +
                              static_cast<int64_t>(k) * WaveSize;
            if (j < N) {
                float normalized = rounded_mul(values[k] - mean, rstd);
                float scaled = rounded_mul(normalized, static_cast<float>(weight[j]));
                out[output_base + j] =
                    static_cast<scalar_t>(scaled + static_cast<float>(bias[j]));
            }
        }
    }
}

template <typename scalar_t, int CacheItems, int WaveSize>
__global__ void residual_norm_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ residual,
    const scalar_t* __restrict__ weight,
    const scalar_t* __restrict__ bias,
    scalar_t* __restrict__ out,
    int64_t M, int64_t N, float eps) {
    __shared__ float scratch[256];
    const int64_t t = static_cast<int64_t>(threadIdx.x);
    for (int64_t row = static_cast<int64_t>(blockIdx.x);
         row < M; row += static_cast<int64_t>(gridDim.x)) {
        const int64_t input_base = row * N;
        const int64_t output_base = row * (2 * N);
        float values[CacheItems > 0 ? CacheItems : 1];
        float sum = 0.0f;
        if constexpr (CacheItems > 0) {
            #pragma unroll
            for (int64_t k = 0; k < CacheItems; ++k) {
                const int64_t j = t + k * 256;
                float v = 0.0f;
                if (j < N) {
                    scalar_t s = static_cast<scalar_t>(
                        static_cast<float>(x[input_base + j]) +
                        static_cast<float>(residual[input_base + j]));
                    v = static_cast<float>(s);
                    out[output_base + N + j] = s;
                }
                values[k] = v;
                sum += v;
            }
        } else {
            for (int64_t j = t; j < N; j += 256) {
                scalar_t s = static_cast<scalar_t>(
                    static_cast<float>(x[input_base + j]) +
                    static_cast<float>(residual[input_base + j]));
                out[output_base + N + j] = s;
                sum += static_cast<float>(s);
            }
        }
        const float mean = row_sum<WaveSize>(sum, scratch) / static_cast<float>(N);
        // Every wave must capture the broadcast before scratch[0] is reused.
        if constexpr (WaveSize == 32 || WaveSize == 64) {
            __syncthreads();
        }
        float squared = 0.0f;
        if constexpr (CacheItems > 0) {
            #pragma unroll
            for (int64_t k = 0; k < CacheItems; ++k) {
                const int64_t j = t + k * 256;
                if (j < N) {
                    float delta = values[k] - mean;
                    squared += rounded_mul(delta, delta);
                }
            }
        } else {
            for (int64_t j = t; j < N; j += 256) {
                float delta = static_cast<float>(out[output_base + N + j]) - mean;
                squared += rounded_mul(delta, delta);
            }
        }
        const float variance = row_sum<WaveSize>(squared, scratch) / static_cast<float>(N);
        const float rstd = rsqrtf(variance + eps);
        if constexpr (CacheItems > 0) {
            #pragma unroll
            for (int64_t k = 0; k < CacheItems; ++k) {
                const int64_t j = t + k * 256;
                if (j < N) {
                    float normalized = rounded_mul(values[k] - mean, rstd);
                    float scaled = rounded_mul(normalized, static_cast<float>(weight[j]));
                    out[output_base + j] =
                        static_cast<scalar_t>(scaled + static_cast<float>(bias[j]));
                }
            }
        } else {
            for (int64_t j = t; j < N; j += 256) {
                float v = static_cast<float>(out[output_base + N + j]);
                float normalized = rounded_mul(v - mean, rstd);
                float scaled = rounded_mul(normalized, static_cast<float>(weight[j]));
                out[output_base + j] =
                    static_cast<scalar_t>(scaled + static_cast<float>(bias[j]));
            }
        }
        __syncthreads();
    }
}

torch::Tensor fused_residual_layernorm(
    torch::Tensor x, torch::Tensor residual,
    torch::Tensor weight, torch::Tensor bias, double eps) {
    TORCH_CHECK(x.is_cuda(), "x must be on a HIP device");
    TORCH_CHECK(x.dim() == 2, "x must have shape (M,N)");
    TORCH_CHECK(x.size(0) > 0 && x.size(1) > 0, "M and N must be positive");
    TORCH_CHECK(
        x.scalar_type() == at::kFloat ||
        x.scalar_type() == at::kHalf ||
        x.scalar_type() == at::kBFloat16, "unsupported input dtype");
    for (const auto& tensor : {x, residual, weight, bias}) {
        TORCH_CHECK(tensor.device() == x.device(), "inputs must share a device");
        TORCH_CHECK(tensor.scalar_type() == x.scalar_type(), "inputs must share a dtype");
        TORCH_CHECK(tensor.is_contiguous(), "inputs must be contiguous");
    }
    TORCH_CHECK(residual.sizes() == x.sizes(), "residual shape must match x");
    const int64_t M = x.size(0), N = x.size(1);
    TORCH_CHECK(weight.dim() == 1 && weight.size(0) == N, "invalid weight shape");
    TORCH_CHECK(bias.dim() == 1 && bias.size(0) == N, "invalid bias shape");
    const int64_t limit = std::numeric_limits<int64_t>::max();
    TORCH_CHECK(N <= limit / 2 && M <= limit / (2 * N), "output size overflow");
    const int64_t output_numel = M * (2 * N);
    TORCH_CHECK(output_numel <= limit / static_cast<int64_t>(x.element_size()),
                "output byte size overflow");

    c10::cuda::CUDAGuard guard(x.device());
    const auto* properties = at::cuda::getDeviceProperties(x.get_device());
    TORCH_CHECK(properties->maxThreadsPerBlock >= 256 &&
                properties->maxThreadsDim[0] >= 256 &&
                properties->sharedMemPerBlock >= 256 * sizeof(float),
                "device does not support the required block configuration");
    const int64_t grid_limit = std::min<int64_t>(properties->maxGridSize[0], 65535);
    TORCH_CHECK(grid_limit > 0, "invalid device grid limit");
    const unsigned int blocks = static_cast<unsigned int>(std::min(M, grid_limit));
    auto out = torch::empty({M, 2 * N}, x.options());
    hipStream_t stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    const int wave_size = properties->warpSize;

#define LAUNCH_RESIDUAL_NORM(CAPACITY, WAVE) \
    hipLaunchKernelGGL((residual_norm_kernel<scalar_t, CAPACITY, WAVE>), \
        dim3(blocks), dim3(256), 0, stream, \
        x.data_ptr<scalar_t>(), residual.data_ptr<scalar_t>(), \
        weight.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), \
        out.data_ptr<scalar_t>(), M, N, static_cast<float>(eps))

#define LAUNCH_SHORT_RESIDUAL_NORM(WAVE) \
    hipLaunchKernelGGL((short_residual_norm_kernel<scalar_t, WAVE>), \
        dim3(static_cast<unsigned int>(std::min<int64_t>( \
            1 + (M - 1) / (256 / WAVE), grid_limit))), dim3(256), 0, stream, \
        x.data_ptr<scalar_t>(), residual.data_ptr<scalar_t>(), \
        weight.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), \
        out.data_ptr<scalar_t>(), M, N, static_cast<float>(eps))

#define DISPATCH_RESIDUAL_NORM(CAPACITY) \
    do { \
        if (wave_size == 32) { \
            LAUNCH_RESIDUAL_NORM(CAPACITY, 32); \
        } else if (wave_size == 64) { \
            LAUNCH_RESIDUAL_NORM(CAPACITY, 64); \
        } else { \
            LAUNCH_RESIDUAL_NORM(CAPACITY, 0); \
        } \
    } while (0)

    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                   x.scalar_type(), "residual_layernorm_hip", [&] {
        if (N <= 256 && (wave_size == 32 || wave_size == 64)) {
            if (wave_size == 32) {
                LAUNCH_SHORT_RESIDUAL_NORM(32);
            } else {
                LAUNCH_SHORT_RESIDUAL_NORM(64);
            }
        } else if (N <= 256) {
            DISPATCH_RESIDUAL_NORM(1);
        } else if (N <= 512) {
            DISPATCH_RESIDUAL_NORM(2);
        } else if (N <= 1024) {
            DISPATCH_RESIDUAL_NORM(4);
        } else if (N <= 2048) {
            DISPATCH_RESIDUAL_NORM(8);
        } else if (N <= 4096) {
            DISPATCH_RESIDUAL_NORM(16);
        } else {
            DISPATCH_RESIDUAL_NORM(0);
        }
    });
#undef DISPATCH_RESIDUAL_NORM
#undef LAUNCH_SHORT_RESIDUAL_NORM
#undef LAUNCH_RESIDUAL_NORM
    const hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess, "residual LayerNorm launch failed: ",
                hipGetErrorString(error));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Forward pass of residual-fused LayerNorm (fused add LayerNorm).

    The inputs x and residual are added element-wise to form the residual sum s
    (the addition happens in float32, then s is rounded back to the input dtype
    for storage); LayerNorm is then applied to the last dimension of s together
    with an affine transform (everything evaluated in float32):
        mean_i  = (1/N) * sum_j s[i, j]
        var_i   = (1/N) * sum_j (s[i, j] - mean_i)^2      (biased variance)
        rstd_i  = 1 / sqrt(var_i + eps)                   (eps comes from __init__)
        y[i, j] = (s[i, j] - mean_i) * rstd_i * weight[j] + bias[j]
    The statistics are taken over s as rounded back to the input dtype; y is
    finally rounded back to the input dtype as well.
    Boundary behaviour: N is any positive integer (including 1, non-power-of-two,
    and very long rows), columns outside the mask do not participate in the
    statistics; when var = 0, eps keeps rstd finite; the inputs contain no
    inf/NaN.

    The output is a single tensor out (M, 2N) with the same dtype as the inputs:
        out[:, :N] = y           the LayerNorm output
        out[:, N:] = s           residual_out (the residual sum rounded to the input dtype)

    Input/output specification:
        x        (M, N)  float16 / bfloat16 / float32, contiguous, M >= 1, N >= 1
        residual (M, N)  same as x
        weight   (N,)    same as x (per-channel scale)
        bias     (N,)    same as x (per-channel shift)
        (the evaluator casts the inputs to fp32 before calling forward;
         fp16/bf16 -> fp32 is lossless)

    Implementation constraints (violations are scored as failures):
        - The core computation (residual add, mean/var statistics, normalization,
          affine transform) must be completed with a HIP kernel inside the
          submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate intermediates in float32; both y and residual_out are
          rounded back to the input dtype.

    Forbidden list: torch.nn.functional.layer_norm / torch.layer_norm /
    torch.nn.LayerNorm.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, residual, weight, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().fused_residual_layernorm(
            x, residual, weight, bias, self.eps
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        x = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        residual = residual.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        w = weight.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        b = bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        residual_out = (x + residual).to(dt)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        z = residual_out.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        mean = z.mean(dim=-1, keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        var = (z - mean).pow(2).mean(dim=-1, keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        rstd = torch.rsqrt(var + self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        y = ((z - mean) * rstd) * w + b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        y = y.to(dt)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return torch.cat([y, residual_out], dim=-1)
        # <<<END_IMPROVE>>>
