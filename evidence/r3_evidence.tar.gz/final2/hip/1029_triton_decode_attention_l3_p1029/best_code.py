import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1029_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Decode-stage attention (single-token query) with paged KV.

    The KV cache is paged at page_size granularity: slot s of physical page p in
    key_cache / value_cache corresponds to flat slot number p * page_size + s.
    Sequence b is addressed indirectly through page_tables, and its l-th KV token
    (0 <= l < seq_lens[b]) lives in slot l % page_size of physical page
    page_tables[b, l // page_size]; slots in the page pool that are not
    referenced are garbage data and must not affect the output. Query head h
    corresponds to KV head h // query_group_size
    (query_group_size = num_q_heads // num_kv_heads, equal to 1 means MHA, equal
    to num_q_heads means MQA). For every sequence b and every query head h:
      logits[l] = scale * <q[b,h,:head_dim_qk],
                            key_flat[slot(b,l), h//group, :head_dim_qk]>
      p[l]      = exp(logits[l] - max(logits)) / sum(exp(logits - max(logits)))
      out[b,h,:head_dim_v] = sum_l p[l] * value_flat[slot(b,l), h//group, :head_dim_v]
    where key_flat / value_flat is the [num_pages*page_size, H_KV, D] flat view of
    the page pool, scale defaults to 1/sqrt(head_dim_qk), and the softmax must be
    numerically stable.

    Any implementation that is numerically equivalent within the tolerance is
    acceptable; how the work is parallelized is **not** a scoring criterion.

    Boundary behaviour:
      - Only the first seq_lens[b] KV tokens participate in the computation;
        seq_lens[b] >= 1 (an empty sequence is undefined).
      - page_size >= 1 is an arbitrary value (with page_size == 1 the page_tables
        are simply a per-token slot table).
      - head_dim_qk and head_dim_v may differ, and non-power-of-2 is allowed (for
        example 192/128, 576/512); the channels short of a power of 2 are handled
        by masking, so no out-of-bounds access occurs.
      - The page pool may be larger than what is actually used; page_tables
        entries beyond ceil(seq_lens[b]/page_size) point at valid but garbage
        pages that do not belong to this sequence.

    Inputs:
      q           [num_seqs, num_q_heads, head_dim_qk]  fp16/bf16 -- the query of
                  one new token per batch
      key_cache   [num_pages, page_size, num_kv_heads, head_dim_qk]
      value_cache [num_pages, page_size, num_kv_heads, head_dim_v]
      page_tables [num_seqs, max_pages_per_seq] int32 -- logical page -> physical page id
      seq_lens    [num_seqs] int32 -- the actually valid KV length of each sequence
    Output:
      out [num_seqs, num_q_heads, head_dim_v], dtype same as q.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV / cross-slice reduction) must
        be completed inside the submitted file; calling external attention
        operator libraries such as scaled_dot_product_attention / sdpa /
        flash_attn, as well as torch.matmul / torch.bmm / torch.einsum /
        torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-token decode, non-quantized KV, no logit_cap clamping, no
    ALiBi, no sliding window.
    """
    def __init__(self, page_size: int, head_dim_qk: int, head_dim_v: int, num_kv_splits: int = 8, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.page_size = int(page_size)
        self.head_dim_qk = int(head_dim_qk)
        self.head_dim_v = int(head_dim_v)
        self.num_kv_splits = int(num_kv_splits)
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim_qk)
        # <<<END_IMPROVE>>>

    def forward(self, q, key_cache, value_cache, page_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        page_tables = page_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D_QK = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_pages, page_size, H_KV, _ = key_cache.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        D_V = value_cache.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert page_size == self.page_size, "the key_cache page size does not match the initialized page_size"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        key_flat = key_cache.view(num_pages * page_size, H_KV, D_QK)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        value_flat = value_cache.view(num_pages * page_size, H_KV, D_V)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty(B, H_Q, D_V, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        for b in range(B):
            seq_len = int(seq_lens[b])
            offs = torch.arange(seq_len, device=q.device)
            slots = page_tables[b, offs // page_size] * page_size + offs % page_size

            # Gather this sequence's K/V through the page table: [seq_len, H_KV, D],
            # cast up to float32 after the gather
            k = key_flat[slots].to(torch.float32)
            v = value_flat[slots].to(torch.float32)

            # GQA: the K/V of one KV head are replicated to the contiguous group of query heads
            if group > 1:
                k = k.repeat_interleave(group, dim=1)   # [seq_len, H_Q, D_QK]
                v = v.repeat_interleave(group, dim=1)   # [seq_len, H_Q, D_V]

            qf = q[b].to(torch.float32) * self.scale     # [H_Q, D_QK]
            logits = torch.einsum("hd,lhd->hl", qf, k)   # [H_Q, seq_len]
            probs = torch.softmax(logits, dim=-1)
            out[b] = torch.einsum("hl,lhd->hd", probs, v).to(q.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
