import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

def _deform_attn_forward(value_f, spatial_shapes, level_start_index,
                         sampling_locations_f, attention_weights_f):
    """Multi-scale deformable attention forward (float32, hand-written the same way as task 1031).

    Semantically identical to the reference of task 1031: coordinate expansion,
    four-corner zero-padded bilinear interpolation, softmax normalization of the
    sampling weights over the flattened (levels x points) dimension, and the
    cross-sampling-point weighted reduction. The only difference is that the floor
    path is detached first (the subgradient convention that the floor gradient is
    0 is made explicit, so the gradient only flows back through the interpolation
    fractions fx/fy); numerically it is exactly the same as the forward.
    All inputs are float32 tensors (the caller is responsible for the cast and for
    requires_grad); returns the uncast float32 output (N, Q, heads*D) for the
    gradient chain to use.
    """
    n, n_keys, num_heads, d = value_f.shape
    n_levels = spatial_shapes.shape[0]
    n_queries = sampling_locations_f.shape[1]
    n_points = sampling_locations_f.shape[4]

    # Normalize the sampling weights: flatten (levels x points) into one
    # dimension and run a numerically stable softmax
    wf = attention_weights_f.reshape(n, n_queries, num_heads,
                                     n_levels * n_points)
    wf = torch.softmax(wf, dim=-1).view(n, n_queries, num_heads,
                                        n_levels, n_points)

    n_idx = torch.arange(n, device=value_f.device).view(n, 1, 1)
    h_idx = torch.arange(num_heads, device=value_f.device).view(1, 1, num_heads)

    out = torch.zeros(n, n_queries, num_heads, d,
                      dtype=torch.float32, device=value_f.device)
    for l in range(n_levels):
        h_l = int(spatial_shapes[l, 0])
        w_l = int(spatial_shapes[l, 1])
        base = int(level_start_index[l])
        v_l = value_f[:, base: base + h_l * w_l]   # (n, H_l*W_l, heads, d)

        # normalized coordinates x level size -> real-valued sampling
        # coordinates (channel 0 along W, channel 1 along H)
        sx = sampling_locations_f[:, :, :, l, :, 0] * float(w_l)
        sy = sampling_locations_f[:, :, :, l, :, 1] * float(h_l)
        # The floor / integer-index path is treated as a constant (detached
        # explicitly); the gradient only flows back through fx/fy
        ix0 = torch.floor(sx.detach()).to(torch.long)
        iy0 = torch.floor(sy.detach()).to(torch.long)
        fx = sx - ix0.to(torch.float32)
        fy = sy - iy0.to(torch.float32)

        def corner(iy, ix, wgt):
            # Single-corner sampling: an out-of-range corner contributes 0
            # (zero padding semantics); the clamp only guards the index
            # against going out of range and is cancelled by the 0 weight
            valid = ((iy >= 0) & (iy <= h_l - 1)
                     & (ix >= 0) & (ix <= w_l - 1)).to(torch.float32)
            flat = iy.clamp(0, h_l - 1) * w_l + ix.clamp(0, w_l - 1)
            vals = v_l[n_idx, flat, h_idx]        # (n, q, heads, P, d)
            return vals * (valid * wgt).unsqueeze(-1)

        for p in range(n_points):
            iy0p, ix0p = iy0[..., p], ix0[..., p]      # (n, q, heads)
            fyp, fxp = fy[..., p], fx[..., p]
            sampled = (corner(iy0p, ix0p, (1.0 - fyp) * (1.0 - fxp))
                       + corner(iy0p, ix0p + 1, (1.0 - fyp) * fxp)
                       + corner(iy0p + 1, ix0p, fyp * (1.0 - fxp))
                       + corner(iy0p + 1, ix0p + 1, fyp * fxp))
            out = out + wf[:, :, :, l, p].unsqueeze(-1) * sampled

    return out.view(n, n_queries, num_heads * d)

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1032_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor deform_attn_backward(torch::Tensor, torch::Tensor, torch::Tensor,
                                  torch::Tensor, torch::Tensor, torch::Tensor);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_attn_backward", &deform_attn_backward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cmath>

__global__ void sample_backward(
    const float* v, const int64_t* shapes, const int64_t* bases,
    const float* loc, const float* a, const float* go,
    float* out, float* weights, float* dots,
    int64_t count, int64_t K, int64_t H, int64_t D,
    int64_t Q, int64_t M, int64_t P, int64_t V) {
    for (int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
         i < count; i += (int64_t)gridDim.x * blockDim.x) {
        int64_t row = i / M, j = i % M, l = j / P;
        int64_t h = row % H, n = row / (Q * H);
        int64_t rb = row * M;
        float mx = -INFINITY;
        for (int64_t k = 0; k < M; ++k) mx = fmaxf(mx, a[rb+k]);
        float den = 0.f;
        for (int64_t k = 0; k < M; ++k) den += expf(a[rb+k]-mx);
        float w = expf(a[i]-mx) / den;
        weights[i] = w;
        int64_t ht = shapes[2*l], wd = shapes[2*l+1], base = bases[l];
        float sx = loc[2*i] * (float)wd, sy = loc[2*i+1] * (float)ht;
        int64_t x = (int64_t)floorf(sx), y = (int64_t)floorf(sy);
        float fx = sx - (float)x, fy = sy - (float)y;
        float cw[4] = {(1-fy)*(1-fx), (1-fy)*fx, fy*(1-fx), fy*fx};
        int64_t offs[4];
        bool valid[4];
        for (int64_t k=0; k<4; ++k) {
            int64_t xx=x+(k%2), yy=y+(k/2), key=base+yy*wd+xx;
            valid[k] = xx>=0 && xx<wd && yy>=0 && yy<ht && key>=0 && key<K;
            offs[k] = ((n*K+key)*H+h)*D;
        }
        float t=0.f, dx=0.f, dy=0.f;
        for (int64_t c=0; c<D; ++c) {
            float vv[4] = {0.f,0.f,0.f,0.f};
            float g=go[row*D+c];
            for (int64_t k=0; k<4; ++k) {
                if (valid[k] && offs[k]+c>=0 && offs[k]+c<V) {
                    vv[k]=v[offs[k]+c];
                    atomicAdd(out+offs[k]+c, (g*w)*cw[k]);
                }
            }
            float s=((vv[0]*cw[0]+vv[1]*cw[1])+vv[2]*cw[2])+vv[3]*cw[3];
            t += g*s;
            dx += (g*w)*((1-fy)*(vv[1]-vv[0])+fy*(vv[3]-vv[2]));
            dy += (g*w)*((1-fx)*(vv[2]-vv[0])+fx*(vv[3]-vv[1]));
        }
        dots[i]=t;
        out[V+2*i]=dx*(float)wd;
        out[V+2*i+1]=dy*(float)ht;
    }
}
__global__ void softmax_backward(const float* w, const float* t, float* out,
                                 int64_t rows, int64_t M) {
    for (int64_t row=(int64_t)blockIdx.x*blockDim.x+threadIdx.x;
         row<rows; row+=(int64_t)gridDim.x*blockDim.x) {
        int64_t b=row*M;
        float sum=0.f;
        for(int64_t j=0;j<M;++j) sum+=w[b+j]*t[b+j];
        for(int64_t j=0;j<M;++j) out[b+j]=M==1 ? 0.f : w[b+j]*(t[b+j]-sum);
    }
}
static void check_launch() {
    hipError_t e=hipGetLastError();
    TORCH_CHECK(e==hipSuccess, "HIP launch: ", hipGetErrorString(e));
}
torch::Tensor deform_attn_backward(torch::Tensor value, torch::Tensor shapes,
    torch::Tensor bases, torch::Tensor loc, torch::Tensor a, torch::Tensor go) {
    for (auto t : {value,shapes,bases,loc,a,go}) {
        TORCH_CHECK(t.is_cuda() && t.is_contiguous(), "Expected contiguous HIP tensors");
        TORCH_CHECK(t.device()==value.device(), "Device mismatch");
    }
    TORCH_CHECK(value.dim()==4 && shapes.dim()==2 && shapes.size(1)==2 &&
                bases.dim()==1 && loc.dim()==6 && a.dim()==5 && go.dim()==3,
                "Invalid ranks");
    TORCH_CHECK(value.scalar_type()==at::kFloat || value.scalar_type()==at::kHalf,
                "Expected float or half");
    TORCH_CHECK(loc.scalar_type()==value.scalar_type() &&
                a.scalar_type()==value.scalar_type() && go.scalar_type()==value.scalar_type(),
                "Floating dtype mismatch");
    c10::cuda::CUDAGuard guard(value.device());
    int64_t N=value.size(0), K=value.size(1), H=value.size(2), D=value.size(3);
    int64_t Q=loc.size(1), L=shapes.size(0), P=loc.size(4), M=L*P;
    TORCH_CHECK(N>0 && K>0 && H>0 && D>0 && Q>0 && L>0 && P>0,
                "Dimensions must be positive");
    int64_t rows=N*Q*H, count=rows*M, V=value.numel();
    TORCH_CHECK(loc.numel()==2*count && a.numel()==count &&
                go.numel()==rows*D && bases.numel()==L, "Shape mismatch");
    auto ss=shapes.to(at::kLong), bs=bases.to(at::kLong);
    auto vf=value.to(at::kFloat), lf=loc.to(at::kFloat);
    auto af=a.to(at::kFloat), gf=go.to(at::kFloat);
    auto opts=value.options().dtype(at::kFloat);
    auto out=torch::zeros({V+3*count}, opts);
    auto w=torch::empty({count},opts), t=torch::empty({count},opts);
    auto stream=at::cuda::getCurrentCUDAStream();
    int blocks=(int)std::min<int64_t>((count+127)/128,65535);
    sample_backward<<<blocks,128,0,stream>>>(
        vf.data_ptr<float>(),ss.data_ptr<int64_t>(),bs.data_ptr<int64_t>(),
        lf.data_ptr<float>(),af.data_ptr<float>(),gf.data_ptr<float>(),
        out.data_ptr<float>(),w.data_ptr<float>(),t.data_ptr<float>(),
        count,K,H,D,Q,M,P,V);
    check_launch();
    blocks=(int)std::min<int64_t>((rows+127)/128,65535);
    softmax_backward<<<blocks,128,0,stream>>>(
        w.data_ptr<float>(),t.data_ptr<float>(),out.data_ptr<float>()+V+2*count,rows,M);
    check_launch();
    return out.to(value.scalar_type());
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Multi-Scale Deformable Attention Backward (deform_attn_dgrad): given the forward inputs and the upstream gradient grad_output, one call computes the gradients of value, sampling_locations and attention_weights at once.

    Forward semantics (all intermediate computation float32, the same convention
    as the companion forward task): value (N, n_keys, heads, D) is the
    concatenation of the multi-scale feature levels -- level l contributes
    spatial_shapes[l] = (H_l, W_l) keys, laid out inside the level in row-major
    order (H first, then W) over [level_start_index[l], level_start_index[l] +
    H_l*W_l), where level_start_index must be the prefix sum of the per-level
    H_l*W_l (first element 0) and n_keys = sum_l H_l*W_l. The last dimension of
    sampling_locations (N, Q, heads, L, P, 2) holds the normalized coordinates
    (x, y): channel 0 runs along W and channel 1 along H (generation domain
    [0,1)), so the actual sampling coordinates are loc_x = x * W_l and loc_y =
    y * H_l; the sampled value goes through four-corner bilinear interpolation
    (floor + the fractions fx/fy, with zero padding semantics where an
    out-of-range corner contributes 0, and no clamp / nearest-neighbour
    pull-back); attention_weights (N, Q, heads, L, P) are non-negative
    unnormalized scores, first flattened over (levels x points) into one
    dimension and normalized by a numerically stable softmax (max subtraction)
    into convex-combination weights, then used in the weighted sum against the
    interpolated value of each sampling point, producing the output o
    (N, Q, heads*D).

    Backward semantics (backpropagated through the float32 forward described
    above, at the point before the output is cast back to the value dtype;
    grad_output is first cast to float32): write dO for the float32 form of
    grad_output, w = softmax(attention_weights flattened over L*P), S_{l,p}[c] for
    the four-corner zero-padded bilinear sample of point (l,p), and
    t_{l,p} = <dO, S_{l,p}>; the three gradients are then the analytic gradients
    of o with respect to the three floating-point inputs:
      grad_value[n, key, h, c] = sum_{q, l, p} w_{l,p} * corner_weight *
                                 dO[n, q, h*D + c]
        (per-corner scatter accumulation; out-of-range corners do not scatter)
      grad_sampling_locations[n, q, h, l, p, 0] =
          sum_c dO[n, q, h*D + c] * w_{l,p} * W_l *
          ((1-fy) * (v01 - v00) + fy * (v11 - v10))
      grad_sampling_locations[n, q, h, l, p, 1] =
          sum_c dO[n, q, h*D + c] * w_{l,p} * H_l *
          ((1-fx) * (v10 - v00) + fx * (v11 - v01))
        (v00/v01/v10/v11 are the four corner pixel values of that point, with an
        out-of-range corner counted as 0; the gradient only flows back through
        the fractions fx/fy, and the floor / integer-index path has gradient 0 --
        the standard subgradient of bilinear sampling)
      grad_attention_weights[n, q, h, l, p] = w_{l,p} *
          (t_{l,p} - sum_{l', p'} w_{l',p'} * t_{l',p'})
        (softmax backprop; identically 0 when L*P = 1)
    The softmax, the interpolation, the weighted reduction and all gradient
    accumulation are done in float32, and the three gradients are each cast back
    to the value dtype and then packed into the output.

    Output contract (single tensor, one-dimensional concatenation packing, the
    segment order is fixed and must not be swapped):
      out = cat([grad_value.reshape(-1),
                 grad_sampling_locations.reshape(-1),
                 grad_attention_weights.reshape(-1)])
      a one-dimensional tensor with the same dtype as value, of length
          = n*n_keys*heads*D + n*n_queries*heads*L*P*2 + n*n_queries*heads*L*P
      segment 0 grad_value: n*n_keys*heads*D elements, (N, n_keys, heads, D)
          flattened row-major;
      segment 1 grad_sampling_locations: n*n_queries*heads*L*P*2 elements,
          (N, Q, heads, L, P, 2) flattened row-major (the (x, y) channel order of
          the last dimension is preserved);
      segment 2 grad_attention_weights: n*n_queries*heads*L*P elements,
          (N, Q, heads, L, P) flattened row-major.

    Input/output specification (all tensors contiguous):
      value              float32 / float16 (N, n_keys, heads, D)
      spatial_shapes     int64 (L, 2), each row (H_l, W_l), H_l / W_l >= 1
      level_start_index  int64 (L,), prefix sum of the per-level key counts
      sampling_locations same dtype as value (N, Q, heads, L, P, 2), generation domain [0,1)
      (with an fp16 input individual elements may round to exactly 1.0 through
       the cast; then loc_x = W_l is fully out of range, the sampled value is 0,
       and the zero padding semantics apply)
      attention_weights  same dtype as value (N, Q, heads, L, P), non-negative
      grad_output        same dtype as value (N, Q, heads*D), the upstream
                         gradient in the forward output layout, generation domain [0,1)
      out                single tensor, same dtype as value, 1-D three-segment
                         concatenation (see above)
      every dimension is an arbitrary positive integer (including 1, non-powers
      of 2, and non-16-aligned sizes; a single-level single-pixel (H_l, W_l) =
      (1, 1), 1xN / Nx1 thin-strip levels, Q=1, P=1 and L=1 are all legal
      boundaries, and when L*P=1 grad_attention_weights is identically 0). The
      evaluator casts every input to fp32 before passing it in (lossless for both
      the low precision and the int64 indices -- an index value <= 2^24 is exactly
      representable in fp32), so the implementation must restore
      spatial_shapes / level_start_index to integer indices before using them.

    Implementation constraints (violations are scored as failures):
      - The core computation (softmax backprop, the four-corner gradient scatter
        with the partial derivatives of the interpolation fractions, and the
        cross-query grad_value scatter accumulation) must be hand-written as a HIP
        kernel inside the submitted file.
      - Using torch.autograd / autograd.grad / .backward() to backpropagate for the
        gradients is forbidden; the gradients must be hand-written from the
        analytic formulas above.
      - All gradient accumulation is done in float32; the three gradient segments
        are cast back to the value dtype and concatenated in the segment order
        above; forward returns the single tensor out (the evaluator compares a
        single output).
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden list: torchvision (including ready-made deformable attention /
    deformable convolution primitives such as torchvision.ops.ms_deform_attn),
    mmcv, miopen, hipdnn, aiter,
    torch.nn.functional.grid_sample (F.grid_sample),
    torch.nn.functional.interpolate (F.interpolate), torch.matmul /
    torch.bmm / torch.mm / torch.einsum / torch.tensordot,
    torch.softmax / torch.nn.functional.softmax (F.softmax),
    torch.autograd (including autograd.grad), .backward().
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, value, spatial_shapes, level_start_index, sampling_locations, attention_weights, grad_output):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        spatial_shapes = spatial_shapes.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        level_start_index = level_start_index.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        n, n_keys, num_heads, d = value.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        n_levels = spatial_shapes.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_queries = sampling_locations.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_points = sampling_locations.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert sampling_locations.dim() == 6 \
            and sampling_locations.shape[2] == num_heads \
            and sampling_locations.shape[3] == n_levels \
            and sampling_locations.shape[5] == 2, \
            "sampling_locations must be (N, Q, heads, L, P, 2)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert attention_weights.shape == (n, n_queries, num_heads, n_levels, n_points), \
            "attention_weights must be (N, Q, heads, L, P)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert value.shape[1] == int(spatial_shapes.prod(dim=1).sum()), \
            "dimension 1 of value must equal the sum of the per-level H_l*W_l"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert grad_output.shape == (n, n_queries, num_heads * d), \
            "grad_output must be (N, Q, heads*D)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return _pyramidkernel_get_extension().deform_attn_backward(
            value, spatial_shapes, level_start_index,
            sampling_locations, attention_weights, grad_output)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # <<<END_IMPROVE>>>
