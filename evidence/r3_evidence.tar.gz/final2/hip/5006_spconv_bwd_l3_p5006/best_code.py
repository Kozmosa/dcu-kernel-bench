import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5006_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor spconv_bwd(torch::Tensor, torch::Tensor, torch::Tensor,
                         torch::Tensor, torch::Tensor, bool);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("spconv_bwd", &spconv_bwd);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cstdint>

template <typename PairT, typename CountT>
__global__ void sparse_dx(
    const float* __restrict__ w, const float* __restrict__ y,
    const PairT* __restrict__ p, const CountT* __restrict__ counts,
    float* __restrict__ dx, int64_t n, int64_t ci, int64_t co,
    int64_t kv, int64_t ny, int64_t tiles) {
    __shared__ float a[16][16];
    __shared__ float b[16][16];
    const int64_t r = threadIdx.x / 16;
    const int64_t c = threadIdx.x % 16;
    const int64_t it = (ci + 15) / 16;
    const int64_t jt = (n + 15) / 16;
    for (int64_t t = blockIdx.x; t < tiles; t += gridDim.x) {
        const int64_t k = t / (it * jt);
        const int64_t jbase = ((t / it) % jt) * 16;
        const int64_t ibase = (t % it) * 16;
        const int64_t count = static_cast<int64_t>(counts[k]);
        if (jbase >= count) continue;
        const int64_t j = jbase + r;
        const int64_t i = ibase + c;
        int64_t ir = -1, yr = -1;
        if (j < count && j < n) {
            ir = static_cast<int64_t>(p[k * n + j]);
            yr = static_cast<int64_t>(p[(kv + k) * n + j]);
        }
        const bool valid = ir >= 0 && ir < n && yr >= 0 && yr < ny;
        float acc = 0.0f;
        for (int64_t base = 0; base < co; base += 16) {
            a[r][c] = valid && base + c < co ? y[yr * co + base + c] : 0.0f;
            b[r][c] = base + r < co && i < ci
                ? w[((base + r) * kv + k) * ci + i] : 0.0f;
            __syncthreads();
            #pragma unroll
            for (int q = 0; q < 16; ++q)
                acc = fmaf(a[r][q], b[q][c], acc);
            __syncthreads();
        }
        if (valid && i < ci) atomicAdd(dx + ir * ci + i, acc);
        __syncthreads();
    }
}

template <typename PairT, typename CountT>
__global__ void sparse_dw(
    const float* __restrict__ x, const float* __restrict__ y,
    const PairT* __restrict__ p, const CountT* __restrict__ counts,
    float* __restrict__ dw, int64_t n, int64_t ci, int64_t co,
    int64_t kv, int64_t ny, int64_t tiles) {
    __shared__ float a[16][16];
    __shared__ float b[16][16];
    const int64_t r = threadIdx.x / 16;
    const int64_t c = threadIdx.x % 16;
    const int64_t it = (ci + 15) / 16;
    const int64_t ot = (co + 15) / 16;
    for (int64_t t = blockIdx.x; t < tiles; t += gridDim.x) {
        const int64_t k = t / (it * ot);
        const int64_t o = ((t / it) % ot) * 16 + r;
        const int64_t i = (t % it) * 16 + c;
        const int64_t loaded_count = static_cast<int64_t>(counts[k]);
        const int64_t count = loaded_count < n ? loaded_count : n;
        float acc = 0.0f;
        for (int64_t base = 0; base < count; base += 16) {
            int64_t ia = -1, ya = -1, ib = -1, yb = -1;
            if (base + c < count) {
                ia = static_cast<int64_t>(p[k * n + base + c]);
                ya = static_cast<int64_t>(p[(kv + k) * n + base + c]);
            }
            if (base + r < count) {
                ib = static_cast<int64_t>(p[k * n + base + r]);
                yb = static_cast<int64_t>(p[(kv + k) * n + base + r]);
            }
            a[r][c] = o < co && ia >= 0 && ia < n && ya >= 0 && ya < ny
                ? y[ya * co + o] : 0.0f;
            b[r][c] = i < ci && ib >= 0 && ib < n && yb >= 0 && yb < ny
                ? x[ib * ci + i] : 0.0f;
            __syncthreads();
            #pragma unroll
            for (int q = 0; q < 16; ++q)
                acc = fmaf(a[r][q], b[q][c], acc);
            __syncthreads();
        }
        if (o < co && i < ci) dw[(o * kv + k) * ci + i] = acc;
        __syncthreads();
    }
}

template <typename PairT, typename CountT>
void launch_sparse(
    const torch::Tensor& operand, const torch::Tensor& y,
    const torch::Tensor& pairs, const torch::Tensor& counts,
    torch::Tensor& result, bool dgrad, int64_t n, int64_t ci,
    int64_t co, int64_t kv, int64_t ny, int64_t tiles,
    unsigned blocks, hipStream_t stream) {
    if (dgrad) {
        sparse_dx<PairT, CountT><<<blocks, 256, 0, stream>>>(
            operand.data_ptr<float>(), y.data_ptr<float>(), pairs.data_ptr<PairT>(),
            counts.data_ptr<CountT>(), result.data_ptr<float>(),
            n, ci, co, kv, ny, tiles);
    } else {
        sparse_dw<PairT, CountT><<<blocks, 256, 0, stream>>>(
            operand.data_ptr<float>(), y.data_ptr<float>(), pairs.data_ptr<PairT>(),
            counts.data_ptr<CountT>(), result.data_ptr<float>(),
            n, ci, co, kv, ny, tiles);
    }
    const hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess, "sparse backward launch failed: ", hipGetErrorString(error));
}

template <typename PairT>
void dispatch_counts(
    const torch::Tensor& operand, const torch::Tensor& y,
    const torch::Tensor& pairs, const torch::Tensor& counts,
    torch::Tensor& result, bool dgrad, int64_t n, int64_t ci,
    int64_t co, int64_t kv, int64_t ny, int64_t tiles,
    unsigned blocks, hipStream_t stream) {
    switch (counts.scalar_type()) {
        case at::kFloat:
            launch_sparse<PairT, float>(operand, y, pairs, counts, result,
                dgrad, n, ci, co, kv, ny, tiles, blocks, stream);
            break;
        case at::kInt:
            launch_sparse<PairT, int32_t>(operand, y, pairs, counts, result,
                dgrad, n, ci, co, kv, ny, tiles, blocks, stream);
            break;
        case at::kLong:
            launch_sparse<PairT, int64_t>(operand, y, pairs, counts, result,
                dgrad, n, ci, co, kv, ny, tiles, blocks, stream);
            break;
        default:
            TORCH_CHECK(false, "unsupported count dtype");
    }
}

torch::Tensor spconv_bwd(
    torch::Tensor features, torch::Tensor filters, torch::Tensor out_bp,
    torch::Tensor pairs, torch::Tensor counts, bool dgrad) {
    TORCH_CHECK(features.is_cuda(), "features must be on a GPU");
    c10::cuda::CUDAGuard guard(features.device());
    for (const auto& t : {features, filters, out_bp, pairs, counts}) {
        TORCH_CHECK(t.device() == features.device(), "device mismatch");
        TORCH_CHECK(t.is_contiguous(), "inputs must be contiguous");
    }
    TORCH_CHECK(features.dim() == 2 && filters.dim() == 3 && out_bp.dim() == 2,
                "invalid operand dimensions");
    const int64_t n = features.size(0), ci = features.size(1);
    const int64_t co = filters.size(0), kv = filters.size(2);
    const int64_t ny = out_bp.size(0);
    TORCH_CHECK(n > 0 && ci > 0 && co > 0 && kv > 0 && ny > 0,
                "dimensions must be positive");
    TORCH_CHECK(filters.size(1) == ci && out_bp.size(1) == co, "channel mismatch");
    TORCH_CHECK(pairs.dim() == 3 && pairs.size(0) == 2 &&
                pairs.size(1) == kv && pairs.size(2) == n, "invalid pair shape");
    TORCH_CHECK(counts.dim() == 1 && counts.size(0) == kv, "invalid count shape");
    const auto dtype = features.scalar_type();
    TORCH_CHECK(dtype == at::kFloat || dtype == at::kHalf || dtype == at::kBFloat16,
                "unsupported feature dtype");
    TORCH_CHECK(filters.scalar_type() == dtype && out_bp.scalar_type() == dtype,
                "operand dtype mismatch");
    TORCH_CHECK(pairs.scalar_type() == at::kFloat ||
                pairs.scalar_type() == at::kInt ||
                pairs.scalar_type() == at::kLong, "unsupported pair dtype");
    TORCH_CHECK(counts.scalar_type() == at::kFloat ||
                counts.scalar_type() == at::kInt ||
                counts.scalar_type() == at::kLong, "unsupported count dtype");
    auto y = out_bp.to(at::kFloat);
    auto operand = (dgrad ? filters : features).to(at::kFloat);
    auto opts = features.options().dtype(at::kFloat);
    auto result = dgrad ? torch::zeros({n, ci}, opts) : torch::empty(filters.sizes(), opts);
    const int64_t tiles = kv * ((ci + 15) / 16) * (((dgrad ? n : co) + 15) / 16);
    const unsigned blocks = static_cast<unsigned>(std::min<int64_t>(tiles, 65535));
    auto stream = at::cuda::getCurrentCUDAStream();
    switch (pairs.scalar_type()) {
        case at::kFloat:
            dispatch_counts<float>(operand, y, pairs, counts, result,
                dgrad, n, ci, co, kv, ny, tiles, blocks, stream);
            break;
        case at::kInt:
            dispatch_counts<int32_t>(operand, y, pairs, counts, result,
                dgrad, n, ci, co, kv, ny, tiles, blocks, stream);
            break;
        case at::kLong:
            dispatch_counts<int64_t>(operand, y, pairs, counts, result,
                dgrad, n, ci, co, kv, ny, tiles, blocks, stream);
            break;
        default:
            TORCH_CHECK(false, "unsupported pair dtype");
    }
    return result.to(dtype);
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Sparse convolution backward (gathered form spconv): dgrad (gradient with
    respect to the input features) and wgrad (gradient with respect to the
    weight buffer); it is the exact adjoint of the sparse convolution forward
    (gather-GEMM-scatter).

    Forward semantics (the sole authority for this task's convention; out is
    first initialized to all zeros, then accumulated by the formula below):
        for each kernel offset k in [0, kv):
            n_k = indice_num_per_loc[k]
            for each j in [0, n_k):
                in_idx  = indice_pairs[0, k, j]      # input row index in [0, n)
                out_idx = indice_pairs[1, k, j]      # output row index in [0, num_act_out)
                out[out_idx, :] += features[in_idx, :] @ W[:, :, k].T
    i.e. for each index pair, gather the input row and matrix-multiply it with
    the weight matrix of offset k ((n_k, c_in) @ (c_in, c_out)), then
    scatter-accumulate by the output row index into out.
    The mathematical weight W and the contiguous filters tensor F satisfy the
    layout mapping:
        W[o, i, k] = F.reshape(c_out, kv, c_in)[o, k, i]
    (equivalent to W = F.reshape(c_out, kv, c_in).permute(0, 2, 1), still shaped
    (c_out, c_in, kv)).

    Given the upstream gradient out_bp = dL/dy (shape (num_act_out, c_out)), the
    two directions are defined as the adjoint of that forward with respect to
    features / filters:
        dgrad: dx[in_idx, :] += out_bp[out_idx, :] @ W[:, :, k], output
               (n, c_in), i.e. dL/dfeatures;
        wgrad: dW_math[:, :, k] += out_bp[out_idx, :, None] *
               features[in_idx, None, :] (accumulated per index pair), output as
               the weight gradient dF (c_out, c_in, kv) interpreted with the same
               layout mapping as filters:
               dF.reshape(c_out, kv, c_in)[o, k, i] = dW_math[o, i, k],
               stored contiguously.
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns dx; here the values of features do not take part in the
                 output (shape convention only);
        "wgrad": returns dF; here the values of filters do not take part in the
                 output (shape convention only).
    forward(features, filters, out_bp, indice_pairs, indice_num_per_loc) has a
    fixed five-input signature; both directions are inherently single-tensor
    outputs (no concatenation packing).

    Boundary behaviour: kernel offsets with n_k = 0 are skipped entirely; when
    all n_k = 0 the output is all-zero; kv = 1 degenerates to a single offset;
    num_act_out and n are independent of each other (either may be the larger
    one). Index-pair table entries with j >= indice_num_per_loc[k] are padding
    garbage (they may hold any value, including duplicated valid row indices)
    and must be masked out according to indice_num_per_loc -- they must never be
    read into the computation. The same input/output row may be hit by any number
    of index pairs (duplicates are allowed within the same k), and all of them
    accumulate with +=.

    Input/output specification:
        features           float32 / float16 / bfloat16 (n, c_in), contiguous
        filters            same dtype as features (c_out, c_in, kv), contiguous
        out_bp             same dtype as features (num_act_out, c_out),
                           contiguous
        indice_pairs       int32 (2, kv, n), contiguous
        indice_num_per_loc int32 (kv,), contiguous
        out                a single tensor, same dtype as features: (n, c_in) for
                           dgrad, (c_out, c_in, kv) for wgrad
        Dimension domain: n, c_in, c_out, kv, num_act_out >= 1, non-powers-of-two
        allowed; indice_num_per_loc[k] in [0, n]; row indices <= 2^24. Input
        values are ordinary randn magnitude (no inf/NaN). The evaluator casts all
        input tensors to fp32 before the call (integer indices are exact up to
        2^24 and are recovered with int()/long()).

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a HIP kernel inside the
          submitted file: the scatter accumulation of dgrad (the out_bp rows
          transformed by W[:, :, k] and then scatter-accumulated by in_idx) or
          the per-index-pair outer-product correlation accumulation of wgrad;
          falling back to combinations of torch gather / matmul / scatter or to
          autograd is forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).
        - Numeric contract: accumulate in float32 throughout (fp16/bf16 inputs
          are first cast losslessly to fp32), then cast the result back to the
          dtype of features; padding table entries must not take part in the
          computation (including out-of-bounds reads).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.sparse / torch.sparse_coo_tensor /
    torch.sparse_csr_tensor / torch.sparse_csc_tensor / torch.sparse_mm /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear /
    index_add (including every spelling .index_add( / index_add_ /
    torch.index_add) / index_put / torch.index_put / scatter_add (including
    scatter_add_) / .scatter_( / torch.scatter / scatter_reduce /
    segment_reduce / torch.gather / index_select / torch.take / torch.sum /
    torch.ops.aten / torch.autograd / .backward( / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "dgrad"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, features, filters, out_bp, indice_pairs, indice_num_per_loc):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().spconv_bwd(
            features, filters, out_bp, indice_pairs, indice_num_per_loc,
            self.variant == "dgrad",
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
