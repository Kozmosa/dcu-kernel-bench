import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5008_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Conv + Bias + element-wise activation fused forward family: three
    variants, relu / swish / prelu.

    For the input x (N, C, H, W) and the kernel weight (K, C, R, S), run the 2D
    cross-correlation forward pass (the deep-learning-library conv_fprop
    convention, not the kernel-flipped mathematical convolution), add the
    per-channel bias bias (1, K, 1, 1) (broadcast along the batch and spatial
    dimensions), then apply the element-wise activation. The convolution
    hyper-parameters are shared by the three variants: stride=(1, 1),
    dilation=(1, 1), symmetric zero padding=(1, 1) (1 added on each of the
    top/bottom/left/right sides; the padding value is always zero). Element-wise
    definition:
        z[b, k, i, j] = ( sum_{c, u, v} x[b, c, i+u-1, j+v-1] *
                          weight[k, c, u, v] ) + bias[0, k, 0, 0]
        out[b, k, i, j] = act(z[b, k, i, j])
    where i in [0, H_out), j in [0, W_out), H_out = H - R + 3 and
    W_out = W - S + 3 (the standard convolution output formula once
    stride/padding/dilation are fixed). The activation is selected among three
    by the __init__ parameter variant (z is the convolution result after adding
    bias):
        "relu"  : out = max(z, 0)
        "swish" : out = z * sigmoid(z) = z / (1 + exp(-z))
        "prelu" : out = z (when z > 0), otherwise slope * z (a scalar slope,
                  equivalent to leaky-ReLU with negative_slope=slope; slope is a
                  forward input tensor rather than a module parameter)
    forward returns the single tensor out (N, K, H_out, W_out), with the same
    dtype as x (convolution is inherently single-output, so there are no
    multi-output packing segments).

    Input/output specification:
        x      float16 / bfloat16 / float32 (N, C, H, W), contiguous,
               N/C/H/W >= 1
        weight same dtype as x (K, C, R, S), contiguous, K/R/S >= 1, the
               input-channel dimension equals C
        bias   same dtype as x (1, K, 1, 1), contiguous (per-channel bias,
               broadcast over the whole batch and all spatial positions)
        slope  a 0-dim scalar tensor of the same dtype as x; it takes part in
               the computation only for variant="prelu" (default 0.01, may
               vary); for variant="relu"/"swish" its contents are arbitrary
               (garbage data) and must not affect the output
        out    a single tensor, same dtype as x (N, K, H_out, W_out)
        Inputs are ordinary randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before the call (fp16/bf16 -> fp32 is lossless; the
        output dtype of this task always matches the dtype of the passed x).

    Implementation constraints (violations are scored as failures):
        - The core computation (the padding-aware index/mask expansion and the
          dot-product accumulation, the bias addition, the element-wise
          activation) must all be done and fused with a HIP kernel inside the
          submitted file; replacing it with any form of library convolution or
          ATen GEMM (matmul/mm/bmm/addmm/baddbmm/einsum/tensordot/unfold/linear
          etc., including one-step equivalent routes such as a conv3d
          depth-axis unsqueeze or a conv_transpose2d kernel-flip rewrite) is
          forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The convolution dot-product accumulation, the bias addition and the
          activation are computed in float32 and the output is cast back to the
          input dtype exactly once (do not accumulate in fp16/bf16 low
          precision, and do not make repeated round-trip casts); padding must be
          handled inside the kernel with boundary masks/indices -- do not
          materialize a padded copy on the host side in place of in-kernel
          handling.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.nn.Conv2d / torch.nn.functional.conv2d / F.conv2d /
    torch.conv2d / aten.conv2d / aten.convolution /
    torch.nn.functional.conv3d / torch.conv3d / torch.nn.Conv3d /
    torch.nn.functional.conv_transpose2d / torch.conv_transpose2d /
    torch.nn.ConvTranspose2d /
    torch.nn.functional.unfold / torch.nn.Unfold / .unfold( /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear /
    miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)
    def __init__(self, variant: str = "relu"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("relu", "swish", "prelu"), \
            "variant must be one of relu / swish / prelu"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, bias, slope):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        z = torch.nn.functional.conv2d(
            x.to(torch.float32), weight.to(torch.float32), bias=None,
            stride=self._STRIDE, padding=self._PADDING, dilation=self._DILATION,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        z = z + bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        if self.variant == "relu":
            z = torch.relu(z)
        elif self.variant == "swish":
            z = z * torch.sigmoid(z)
        else:   # prelu: pass z through when z > 0, otherwise slope * z
            sf = slope.to(torch.float32)
            z = torch.where(z > 0, z, z * sf)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return z.to(x.dtype)
        # <<<END_IMPROVE>>>
