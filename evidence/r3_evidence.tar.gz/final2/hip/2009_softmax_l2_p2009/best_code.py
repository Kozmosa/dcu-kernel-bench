import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2009_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor softmax_forward(torch::Tensor x);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("softmax_forward", &softmax_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <algorithm>
#include <cmath>

template <typename scalar_t>
__global__ void row_softmax(const scalar_t* x, scalar_t* y,
                            int64_t rows, int64_t cols) {
    __shared__ float scratch[256];
    const int tid = threadIdx.x;

    for (int64_t row = static_cast<int64_t>(blockIdx.x);
         row < rows;
         row += static_cast<int64_t>(gridDim.x)) {
        const int64_t base = row * cols;
        float vmax = -INFINITY;

        for (int64_t col = static_cast<int64_t>(tid);
             col < cols;
             col += static_cast<int64_t>(blockDim.x)) {
            vmax = fmaxf(vmax, static_cast<float>(x[base + col]));
        }

        scratch[tid] = vmax;
        __syncthreads();

        for (int step = 128; step > 0; step >>= 1) {
            if (tid < step) {
                scratch[tid] = fmaxf(scratch[tid], scratch[tid + step]);
            }
            __syncthreads();
        }

        const float maximum = scratch[0];
        __syncthreads();

        float sum = 0.0f;
        for (int64_t col = static_cast<int64_t>(tid);
             col < cols;
             col += static_cast<int64_t>(blockDim.x)) {
            sum += expf(static_cast<float>(x[base + col]) - maximum);
        }

        scratch[tid] = sum;
        __syncthreads();

        for (int step = 128; step > 0; step >>= 1) {
            if (tid < step) {
                scratch[tid] += scratch[tid + step];
            }
            __syncthreads();
        }

        const float inverse = 1.0f / scratch[0];
        __syncthreads();

        for (int64_t col = static_cast<int64_t>(tid);
             col < cols;
             col += static_cast<int64_t>(blockDim.x)) {
            const float value = expf(static_cast<float>(x[base + col]) - maximum);
            y[base + col] = static_cast<scalar_t>(value * inverse);
        }

        __syncthreads();
    }
}

torch::Tensor softmax_forward(torch::Tensor x) {
    TORCH_CHECK(x.is_cuda(), "x must be on a HIP device");
    TORCH_CHECK(x.dim() == 2 && x.is_contiguous(),
                "x must be a contiguous matrix");
    TORCH_CHECK(x.size(0) > 0 && x.size(1) > 0,
                "empty matrix");
    TORCH_CHECK(x.scalar_type() == at::kFloat ||
                x.scalar_type() == at::kHalf ||
                x.scalar_type() == at::kBFloat16,
                "unsupported dtype");

    c10::cuda::CUDAGuard guard(x.device());
    auto y = torch::empty_like(x);

    const int64_t rows = static_cast<int64_t>(x.size(0));
    const int64_t cols = static_cast<int64_t>(x.size(1));
    const unsigned blocks = static_cast<unsigned>(
        std::min<int64_t>(rows, static_cast<int64_t>(65535)));
    hipStream_t stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "row_softmax",
        [&] {
            hipLaunchKernelGGL(
                row_softmax<scalar_t>,
                dim3(blocks), dim3(256), 0, stream,
                x.data_ptr<scalar_t>(), y.data_ptr<scalar_t>(),
                rows, cols);
        });

    hipError_t status = hipGetLastError();
    TORCH_CHECK(status == hipSuccess,
                "softmax launch failed: ",
                hipGetErrorString(status));

    return y;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    2D row-wise softmax.

    For each row (the last dimension) of an (M, N) input, independently:
        m[i]     = max_j x[i, j]
        z[i, j]  = exp(x[i, j] - m[i])
        y[i, j]  = z[i, j] / sum_j z[i, j]
    Rows are completely independent, and after per-row normalization the elements
    of every row sum to 1. The reference implementation does max / exp / sum
    entirely in float32 and casts the output back to the input dtype.

    Boundary behaviour: N is any positive integer -- when N=1 the row's output is
    always 1; non-power-of-two N and very long rows (longer than a single block's
    capacity) must still give exact results, and out-of-range elements at the row
    tail must not participate in the max and sum reductions; the inputs are
    ordinary randn magnitude (no inf/NaN).

    Input/output specification:
        x   float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        y   same dtype as x, (M, N), the row-wise softmax result
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless); this operator has no integer tensor
        input, so nothing needs restoring.

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-row max reduction, the exp sum reduction,
          and the element-wise normalization) must be completed with a Triton
          kernel inside the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Intermediates (max / sum / exp) are computed in float32; the output is
          cast back to the input dtype.

    Forbidden list: aiter / torch.softmax / torch.nn.functional.softmax /
    torch.nn.Softmax / torch.log_softmax / torch.nn.functional.log_softmax /
    torch.nn.LogSoftmax / torch.special.softmax / torch.special.log_softmax.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().softmax_forward(x)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
