import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4004_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Batch-dimension bf16 GEMM: computes x[b] @ weight[b]^T independently for
    every matrix in the batch.

    Mathematical definition (independent per b in the batch, B/M/N/K >= 1):
      acc[b, m, n] = sum_k x[b, m, k] * weight[b, n, k]    (float32 accumulation)
      out[b, m, n] = acc[b, m, n] + bias[b, 0, n]          (optional bias)
    weight is stored row-major as (B, N, K), so the computation is equivalent to a
    transposed GEMM (each output channel corresponds to one row of weight). The
    bias fusion order follows GEMM kernel convention: the float32 accumulated
    result is first cast to the input dtype (bfloat16), bias is then added
    (bfloat16 arithmetic), and finally the result is cast to the output dtype. With
    no bias it is cast directly. Boundary behaviour: B/M/N/K may be any value >= 1
    (including the minimal 1x1x1 size) and the dimensions may be
    non-powers-of-two, with no alignment requirement on any of them.

    Input/output specification:
      x      bfloat16  (B, M, K)  the activation matrix
      weight bfloat16  (B, N, K)  the weight matrix (row-major, transposed-GEMM semantics)
      bias   bfloat16  (B, 1, N)  optional; when use_bias=False a placeholder tensor is
                                  passed and ignored
      out    output dtype (B, M, N), where the dtype is set by __init__'s out_dtype
                                  (bfloat16 / float16)

    Implementation constraints (violations are scored as failures):
      - The core computation (the bf16 GEMM multiply-accumulate and the bias fusion)
        must be completed inside the submitted file; calling torch.matmul /
        torch.bmm / torch.mm / torch.addmm / torch.baddbmm / torch.einsum /
        F.linear / functional.linear / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; the bias branch follows the fusion
        order above; cast the output to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward; the input
        values (small integer codes and values representable in bfloat16) are all
        exactly representable in fp32, so .to(torch.bfloat16) at the entry point
        recovers them losslessly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: TN layout (x row-major (B,M,K), weight row-major (B,N,K)), no
    split-K, no quantization component at all (pure bf16 inputs, no scale
    dequantization).
    """
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        x = x.to(torch.bfloat16)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        weight = weight.to(torch.bfloat16)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        bias = bias.to(torch.bfloat16) if self.use_bias else None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        B, M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = weight.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == weight.shape[2], "x and weight must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        acc = torch.matmul(x.to(torch.float32), weight.to(torch.float32).transpose(1, 2))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if bias is not None:
            # Matches the GEMM kernel fusion order: cast to the input dtype first,
            # then add the bias.
            acc = acc.to(x.dtype) + bias
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        return acc.to(self.out_dtype)
        # <<<END_IMPROVE>>>
