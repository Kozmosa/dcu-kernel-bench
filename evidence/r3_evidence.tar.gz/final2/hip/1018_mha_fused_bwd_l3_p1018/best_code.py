import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1018_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor mha_backward_hip(torch::Tensor q, torch::Tensor k,
                               torch::Tensor v, torch::Tensor dout, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mha_backward", &mha_backward_hip);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <limits>
#include <cmath>

static constexpr int64_t kProductsSharedBytes = 4 * 16 * 17 * sizeof(float);

struct Strides {
    int64_t b, s, h, d;
    __device__ int64_t offset(int64_t bb, int64_t ss, int64_t hh, int64_t dd) const {
        return bb*b + ss*s + hh*h + dd*d;
    }
};
struct Shape {
    int64_t B, Q, K, H, J, D;
    Strides qs, ks, vs, os;
};

template<typename T>
__device__ float read_input(const T* p, Strides st,
                            int64_t b, int64_t s, int64_t h, int64_t d) {
    return static_cast<float>(p[st.offset(b,s,h,d)]);
}

// All blocks have exactly 256 threads. No wave-size assumptions are used.
template<typename T, int Mode>
__global__ void products(const T* q, const T* k, const T* v, const T* dout,
                         float* a, float* c, T* out, Shape z, float scale,
                         int64_t tiles) {
    __shared__ float l[16][17], r[16][17], u[16][17], w[16][17];
    const int64_t x = threadIdx.x % 16, y = threadIdx.x / 16;
    const int64_t rows = Mode == 2 ? z.K : z.Q;
    const int64_t cols = Mode == 0 ? z.K : z.D;
    const int64_t nr = (rows+15)/16, nc = (cols+15)/16;
    const int64_t heads = Mode == 2 ? z.J : z.H;
    const int64_t group = z.H/z.J;
    for (int64_t tile = blockIdx.x; tile < tiles; tile += gridDim.x) {
        int64_t t = tile;
        const int64_t col0 = (t % nc)*16; t /= nc;
        const int64_t row0 = (t % nr)*16; t /= nr;
        const int64_t head = t % heads, b = t / heads;
        const int64_t i = row0+y, j = col0+x;
        float acc = 0.f, acc2 = 0.f;
        const int64_t groups = Mode == 2 ? group : 1;
        const int64_t reduction = Mode == 0 ? z.D : (Mode == 1 ? z.K : z.Q);
        for (int64_t gh=0; gh<groups; ++gh) {
            const int64_t h = Mode == 2 ? head*group+gh : head;
            const int64_t kh = h/group;
            const int64_t base = (b*z.H+h)*z.Q*z.K;
            for (int64_t rr=0; rr<reduction; rr+=16) {
                float lv=0.f, rv=0.f, uv=0.f, wv=0.f;
                if (Mode == 0) {
                    if (i<z.Q && rr+x<z.D) {
                        lv=read_input(q,z.qs,b,i,h,rr+x);
                        uv=read_input(dout,z.os,b,i,h,rr+x);
                    }
                    if (col0+y<z.K && rr+x<z.D) {
                        rv=read_input(k,z.ks,b,col0+y,kh,rr+x);
                        wv=read_input(v,z.vs,b,col0+y,kh,rr+x);
                    }
                    l[y][x]=lv; u[y][x]=uv;
                    r[x][y]=rv; w[x][y]=wv;
                } else if (Mode == 1) {
                    if (i<z.Q && rr+x<z.K)
                        lv=c[base+i*z.K+rr+x];
                    if (j<z.D && rr+y<z.K)
                        rv=read_input(k,z.ks,b,rr+y,kh,j);
                    l[y][x]=lv; r[y][x]=rv;
                } else {
                    if (row0+x<z.K && rr+y<z.Q) {
                        lv=c[base+(rr+y)*z.K+row0+x];
                        uv=a[base+(rr+y)*z.K+row0+x];
                    }
                    if (j<z.D && rr+y<z.Q) {
                        rv=read_input(q,z.qs,b,rr+y,h,j);
                        wv=read_input(dout,z.os,b,rr+y,h,j);
                    }
                    l[x][y]=lv; u[x][y]=uv;
                    r[y][x]=rv; w[y][x]=wv;
                }
                __syncthreads();
                #pragma unroll
                for (int n=0; n<16; ++n) {
                    acc = fmaf(l[y][n],r[n][x],acc);
                    if (Mode != 1) acc2 = fmaf(u[y][n],w[n][x],acc2);
                }
                __syncthreads();
            }
        }
        if (i<rows && j<cols) {
            if (Mode == 0) {
                const int64_t ix=((b*z.H+head)*z.Q+i)*z.K+j;
                a[ix]=acc*scale; c[ix]=acc2;
            } else if (Mode == 1) {
                out[((b*z.Q+i)*z.H+head)*z.D+j]=static_cast<T>(acc*scale);
            } else {
                const int64_t nq=z.B*z.Q*z.H*z.D, nk=z.B*z.K*z.J*z.D;
                const int64_t ix=((b*z.K+i)*z.J+head)*z.D+j;
                out[nq+ix]=static_cast<T>(acc*scale);
                out[nq+nk+ix]=static_cast<T>(acc2);
            }
        }
        __syncthreads();
    }
}

__device__ float block_reduce(float value, float* shared, bool maximum) {
    const int64_t tid=threadIdx.x;
    shared[tid]=value;
    __syncthreads();
    for (int64_t step=128; step>0; step/=2) {
        if (tid<step)
            shared[tid]=maximum ? fmaxf(shared[tid],shared[tid+step])
                                : shared[tid]+shared[tid+step];
        __syncthreads();
    }
    float result=shared[0];
    __syncthreads();
    return result;
}

__global__ void normalize(float* a, float* c, int64_t rows, int64_t keys) {
    __shared__ float shared[256];
    const int64_t tid=threadIdx.x;
    for (int64_t row=blockIdx.x; row<rows; row+=gridDim.x) {
        const int64_t base=row*keys;
        float mx=-INFINITY;
        for (int64_t j=tid; j<keys; j+=256) mx=fmaxf(mx,a[base+j]);
        mx=block_reduce(mx,shared,true);
        float sum=0.f;
        for (int64_t j=tid; j<keys; j+=256) {
            float e=expf(a[base+j]-mx);
            a[base+j]=e; sum+=e;
        }
        sum=block_reduce(sum,shared,false);
        float delta=0.f;
        for (int64_t j=tid; j<keys; j+=256) {
            float p=a[base+j]/sum;
            a[base+j]=p;
            delta=fmaf(p,c[base+j],delta);
        }
        delta=block_reduce(delta,shared,false);
        for (int64_t j=tid; j<keys; j+=256)
            c[base+j]=a[base+j]*(c[base+j]-delta);
        __syncthreads();
    }
}

template<int Items>
__global__ void normalize_cached(float* a, float* c, int64_t rows, int64_t keys) {
    __shared__ float shared[256];
    const int64_t tid=threadIdx.x;
    for (int64_t row=blockIdx.x; row<rows; row+=gridDim.x) {
        const int64_t base=row*keys;
        float cached[Items], cached_dp[Items];
        float mx=-INFINITY;
        #pragma unroll
        for (int64_t t=0; t<Items; ++t) {
            const int64_t j=tid+256*t;
            cached[t]=-INFINITY;
            cached_dp[t]=0.f;
            if (j<keys) {
                cached[t]=a[base+j];
                cached_dp[t]=c[base+j];
                mx=fmaxf(mx,cached[t]);
            }
        }
        mx=block_reduce(mx,shared,true);
        float sum=0.f;
        #pragma unroll
        for (int64_t t=0; t<Items; ++t) {
            const int64_t j=tid+256*t;
            cached[t]=j<keys ? expf(cached[t]-mx) : 0.f;
            if (j<keys) sum+=cached[t];
        }
        sum=block_reduce(sum,shared,false);
        float delta=0.f;
        #pragma unroll
        for (int64_t t=0; t<Items; ++t) {
            const int64_t j=tid+256*t;
            if (j<keys) {
                cached[t]=cached[t]/sum;
                delta=fmaf(cached[t],cached_dp[t],delta);
            }
        }
        delta=block_reduce(delta,shared,false);
        #pragma unroll
        for (int64_t t=0; t<Items; ++t) {
            const int64_t j=tid+256*t;
            if (j<keys) {
                a[base+j]=cached[t];
                c[base+j]=cached[t]*(cached_dp[t]-delta);
            }
        }
        __syncthreads();
    }
}

static int64_t checked_mul(int64_t a, int64_t b) {
    TORCH_CHECK(a>=0 && b>=0 && (a==0 || b<=INT64_MAX/a), "Tensor size overflow");
    return a*b;
}
static Strides strides(const torch::Tensor& t) {
    int64_t span=0;
    for (int64_t d=0; d<4; ++d) {
        TORCH_CHECK(t.stride(d)>=0, "Negative strides are unsupported");
        int64_t term=checked_mul(std::max<int64_t>(t.size(d)-1,0),t.stride(d));
        TORCH_CHECK(span<=INT64_MAX-term,"Stride offset overflow");
        span+=term;
    }
    return {t.stride(0),t.stride(1),t.stride(2),t.stride(3)};
}
static void check_hip(hipError_t err) {
    TORCH_CHECK(err==hipSuccess, "HIP error: ", hipGetErrorString(err));
}
torch::Tensor mha_backward_hip(torch::Tensor q, torch::Tensor k,
                               torch::Tensor v, torch::Tensor dout, double scale) {
    TORCH_CHECK(q.is_cuda(), "Expected GPU inputs");
    TORCH_CHECK(q.scalar_type()==at::kHalf || q.scalar_type()==at::kBFloat16 ||
                q.scalar_type()==at::kFloat,
                "Expected float16, bfloat16 or float32");
    for (const auto& t : {q,k,v,dout}) {
        TORCH_CHECK(t.dim()==4, "Expected bshd tensors");
        TORCH_CHECK(t.device()==q.device() && t.scalar_type()==q.scalar_type(),
                    "All inputs must have the same device and dtype");
    }
    TORCH_CHECK(q.sizes()==dout.sizes() && k.sizes()==v.sizes(),"Input shape mismatch");
    const int64_t B=q.size(0), Q=q.size(1), H=q.size(2), D=q.size(3);
    const int64_t K=k.size(1), J=k.size(2);
    TORCH_CHECK(k.size(0)==B && k.size(3)==D,"Q/K shape mismatch");
    TORCH_CHECK(Q>0 && K>0 && H>0 && J>0 && H%J==0 && D>=1 && D<=256,
                "Invalid attention dimensions");
    c10::cuda::CUDAGuard guard(q.device());
    Shape z{B,Q,K,H,J,D,strides(q),strides(k),strides(v),strides(dout)};
    int64_t rows=checked_mul(checked_mul(B,H),Q);
    int64_t count=checked_mul(rows,K);
    checked_mul(count,4);
    int64_t nq=checked_mul(rows,D);
    int64_t nk=checked_mul(checked_mul(checked_mul(B,K),J),D);
    TORCH_CHECK(nk<=(INT64_MAX-nq)/2,"Output size overflow");
    checked_mul(nq+2*nk,q.element_size());
    auto out=torch::empty({nq+2*nk},q.options());
    if (B==0) return out;
    auto a=torch::empty({count},q.options().dtype(at::kFloat));
    auto c=torch::empty({count},q.options().dtype(at::kFloat));
    hipDeviceProp_t props;
    check_hip(hipGetDeviceProperties(&props,q.get_device()));
    TORCH_CHECK(props.maxThreadsPerBlock>=256 && props.sharedMemPerBlock>=kProductsSharedBytes,
                "Insufficient GPU launch resources");
    int64_t limit=std::min<int64_t>(props.maxGridSize[0],65535);
    TORCH_CHECK(limit>0,"Invalid grid limit");
    auto grid=[&](int64_t tiles) { return static_cast<unsigned int>(std::min(tiles,limit)); };
    int64_t t0=checked_mul(checked_mul(checked_mul(B,H),(Q+15)/16),(K+15)/16);
    int64_t t1=checked_mul(checked_mul(checked_mul(B,H),(Q+15)/16),(D+15)/16);
    int64_t t2=checked_mul(checked_mul(checked_mul(B,J),(K+15)/16),(D+15)/16);
    auto stream=at::cuda::getCurrentCUDAStream(q.get_device());
    AT_DISPATCH_SWITCH(q.scalar_type(), "mha_backward_hip",
        AT_DISPATCH_CASE_FLOATING_TYPES_AND(at::ScalarType::Half, [&] {
            products<scalar_t,0><<<grid(t0),256,0,stream>>>(
                q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),
                dout.data_ptr<scalar_t>(),a.data_ptr<float>(),c.data_ptr<float>(),
                out.data_ptr<scalar_t>(),z,float(scale),t0);
            check_hip(hipGetLastError());
            if (K<=256) {
                normalize_cached<1><<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            } else if (K<=512) {
                normalize_cached<2><<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            } else if (K<=1024) {
                normalize_cached<4><<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            } else if (K<=2048) {
                normalize_cached<8><<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            } else {
                normalize<<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            }
            check_hip(hipGetLastError());
            products<scalar_t,1><<<grid(t1),256,0,stream>>>(
                q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),
                dout.data_ptr<scalar_t>(),a.data_ptr<float>(),c.data_ptr<float>(),
                out.data_ptr<scalar_t>(),z,float(scale),t1);
            check_hip(hipGetLastError());
            products<scalar_t,2><<<grid(t2),256,0,stream>>>(
                q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),
                dout.data_ptr<scalar_t>(),a.data_ptr<float>(),c.data_ptr<float>(),
                out.data_ptr<scalar_t>(),z,float(scale),t2);
            check_hip(hipGetLastError());
        })
        AT_DISPATCH_CASE(at::ScalarType::BFloat16, [&] {
            products<scalar_t,0><<<grid(t0),256,0,stream>>>(
                q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),
                dout.data_ptr<scalar_t>(),a.data_ptr<float>(),c.data_ptr<float>(),
                out.data_ptr<scalar_t>(),z,float(scale),t0);
            check_hip(hipGetLastError());
            if (K<=256) {
                normalize_cached<1><<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            } else if (K<=512) {
                normalize_cached<2><<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            } else if (K<=1024) {
                normalize_cached<4><<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            } else if (K<=2048) {
                normalize_cached<8><<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            } else {
                normalize<<<grid(rows),256,0,stream>>>(a.data_ptr<float>(),c.data_ptr<float>(),rows,K);
            }
            check_hip(hipGetLastError());
            products<scalar_t,1><<<grid(t1),256,0,stream>>>(
                q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),
                dout.data_ptr<scalar_t>(),a.data_ptr<float>(),c.data_ptr<float>(),
                out.data_ptr<scalar_t>(),z,float(scale),t1);
            check_hip(hipGetLastError());
            products<scalar_t,2><<<grid(t2),256,0,stream>>>(
                q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),
                dout.data_ptr<scalar_t>(),a.data_ptr<float>(),c.data_ptr<float>(),
                out.data_ptr<scalar_t>(),z,float(scale),t2);
            check_hip(hipGetLastError());
        })
    );
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    FlashAttention backward (fused form): given the forward inputs Q/K/V and the
    upstream gradient dO, a single call computes the gradients dQ/dK/dV of the
    scaled dot-product attention forward O = softmax(scale·QK^T)·V with respect to
    Q, K and V. Supports MHA/GQA, dense fixed-length
    [batch, seqlen, heads, head_dim] (bshd) layout, non-causal (seqlen_q and
    seqlen_k may differ).

    Mathematical definition (g = num_q_heads // num_kv_heads,
    scale = 1/sqrt(head_dim), S_q/S_k are the sequence lengths of q/k, the KV head
    index for query head h is h_kv = h // g):
      S[b,h,i,j]     = scale * <q[b,i,h,:], k[b,j,h_kv,:]>
      P[b,h,i,j]     = softmax_j(S[b,h,i,:])     (non-causal, no mask)
      O[b,h,i,:]     = sum_j P[b,h,i,j] * v[b,j,h_kv,:]
      delta[b,h,i]   = <dO[b,i,h,:], O[b,h,i,:]> (= rowsum(dP∘P))
      dP[b,h,i,j]    = <dO[b,i,h,:], v[b,j,h_kv,:]>
      dS[b,h,i,j]    = P[b,h,i,j] * (dP[b,h,i,j] - delta[b,h,i])
      dQ[b,i,h,:]    = scale * sum_j dS[b,h,i,j] * k[b,j,h_kv,:]
      dK[b,j,h_kv,:] = scale * sum_{i, h: h//g = h_kv} dS[b,h,i,j] * q[b,i,h,:]
      dV[b,j,h_kv,:] = sum_{i, h: h//g = h_kv} P[b,h,i,j] * dO[b,i,h,:]
    i.e. dQ = scale·(dS·K), dK = scale·(dS^T·Q) (summed over the query heads inside
    each group of g), dV = P^T·dO (summed over the query heads inside each group of
    g). Intermediates are computed in float32 (numerically stable softmax), and
    each of the three gradients is cast back to the input dtype.
    Boundary behaviour: softmax normalizes along the k dimension, so the
    denominator is always positive; under GQA, dK/dV are the sum of the gradients
    over all query heads belonging to the same KV head, with a shape matching K/V.

    Input/output specification:
      q, do [batch, seqlen_q, num_q_heads, head_dim]  float16/bfloat16
      k, v  [batch, seqlen_k, num_kv_heads, head_dim] same dtype as q
      output: a 1-D tensor with the same dtype as q: dQ, dK, dV flattened in that
              order in their own bshd row-major layouts and then concatenated,
              length = batch*seqlen_q*num_q_heads*head_dim
                       + 2*batch*seqlen_k*num_kv_heads*head_dim
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (equal means MHA, otherwise GQA); 1 <= head_dim <= 256; seqlen_q >= 1,
    seqlen_k >= 1.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / recomputation of P and delta / chained
        gradient products) must be completed inside the submitted file; calling
        scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden, as is obtaining the
        gradients through torch.autograd or .backward().
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: non-causal, dense fixed-length batch layout, no dropout, no
    bias/ALiBi, non-quantized inputs (fp16/bf16).
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, do):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().mha_backward(q, k, v, do, self.sm_scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        # <<<END_IMPROVE>>>
