import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

at::Tensor fused_a8w8(
    const at::Tensor& x, const at::Tensor& w,
    const at::Tensor& xs, const at::Tensor& ws,
    const c10::optional<at::Tensor>& bias, bool output_bfloat16);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_a8w8", &fused_a8w8);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <algorithm>

namespace {

template<typename X, typename W, typename T>
__global__ void fused_kernel(
    const X* __restrict__ x, const W* __restrict__ w,
    const float* __restrict__ xs, const float* __restrict__ ws,
    const void* __restrict__ bias, bool bias_float,
    T* __restrict__ out,
    int64_t M, int64_t N, int64_t K,
    int64_t mt, int64_t nt, int64_t tiles) {
    __shared__ float sx[32][33];
    __shared__ float sw[32][33];
    const int64_t tid = static_cast<int64_t>(threadIdx.x);
    const int64_t rg = tid / 16;
    const int64_t cg = tid % 16;
    for (int64_t tile = static_cast<int64_t>(blockIdx.x);
         tile < tiles; tile += static_cast<int64_t>(gridDim.x)) {
        const int64_t batch = tile / (mt * nt);
        const int64_t tile_m = ((tile / nt) % mt) * 32;
        const int64_t tile_n = (tile % nt) * 32;
        float acc00 = 0.0f, acc01 = 0.0f;
        float acc10 = 0.0f, acc11 = 0.0f;
        for (int64_t kb = 0; kb < K; kb += 32) {
            for (int64_t p = tid; p < 1024; p += 256) {
                const int64_t r = p / 32;
                const int64_t kk = p % 32;
                const int64_t k = kb + kk;
                float xv = 0.0f, wv = 0.0f;
                if (tile_m + r < M && k < K)
                    xv = static_cast<float>(static_cast<int8_t>(
                        x[(batch * M + tile_m + r) * K + k]));
                if (tile_n + r < N && k < K)
                    wv = static_cast<float>(static_cast<int8_t>(
                        w[(batch * N + tile_n + r) * K + k]));
                sx[kk][r] = xv;
                sw[kk][r] = wv;
            }
            __syncthreads();
            #pragma unroll
            for (int64_t kk = 0; kk < 32; ++kk) {
                const float x0 = sx[kk][rg];
                const float x1 = sx[kk][rg + 16];
                const float w0 = sw[kk][cg];
                const float w1 = sw[kk][cg + 16];
                acc00 = fmaf(x0, w0, acc00);
                acc01 = fmaf(x0, w1, acc01);
                acc10 = fmaf(x1, w0, acc10);
                acc11 = fmaf(x1, w1, acc11);
            }
            __syncthreads();
        }

        #pragma unroll
        for (int64_t i = 0; i < 2; ++i) {
            const int64_t m = tile_m + rg + 16 * i;
            #pragma unroll
            for (int64_t j = 0; j < 2; ++j) {
                const int64_t n = tile_n + cg + 16 * j;
                if (m < M && n < N) {
                    const float acc = i == 0
                        ? (j == 0 ? acc00 : acc01)
                        : (j == 0 ? acc10 : acc11);
                    const float row_scaled = acc * xs[batch * M + m];
                    const float scaled = row_scaled * ws[batch * N + n];
                    T result = static_cast<T>(scaled);
                    if (bias != nullptr) {
                        const int64_t offset = batch * N + n;
                        const T rounded_bias = bias_float
                            ? static_cast<T>(static_cast<const float*>(bias)[offset])
                            : static_cast<const T*>(bias)[offset];
                        result = static_cast<T>(
                            static_cast<float>(result) +
                            static_cast<float>(rounded_bias));
                    }
                    out[(batch * M + m) * N + n] = result;
                }
            }
        }
        __syncthreads();
    }
}

template<typename X, typename W, typename T>
void launch(
    const at::Tensor& x, const at::Tensor& w,
    const at::Tensor& xs, const at::Tensor& ws,
    const at::Tensor& bias, at::Tensor& out,
    int64_t mt, int64_t nt, int64_t tiles,
    unsigned int blocks, hipStream_t stream) {
    const void* bp = bias.defined() ? bias.data_ptr() : nullptr;
    const bool bf = bias.defined() && bias.scalar_type() == at::kFloat;
    hipLaunchKernelGGL(
        (fused_kernel<X, W, T>), dim3(blocks), dim3(256), 0, stream,
        x.data_ptr<X>(), w.data_ptr<W>(),
        xs.data_ptr<float>(), ws.data_ptr<float>(), bp, bf, out.data_ptr<T>(),
        x.size(1), w.size(1), x.size(2), mt, nt, tiles);
}

template<typename T>
void dispatch_inputs(
    const at::Tensor& x, const at::Tensor& w,
    const at::Tensor& xs, const at::Tensor& ws,
    const at::Tensor& bias, at::Tensor& out,
    int64_t mt, int64_t nt, int64_t tiles,
    unsigned int blocks, hipStream_t stream) {
    if (x.scalar_type() == at::kFloat) {
        if (w.scalar_type() == at::kFloat)
            launch<float, float, T>(x,w,xs,ws,bias,out,mt,nt,tiles,blocks,stream);
        else
            launch<float, int8_t, T>(x,w,xs,ws,bias,out,mt,nt,tiles,blocks,stream);
    } else {
        if (w.scalar_type() == at::kFloat)
            launch<int8_t, float, T>(x,w,xs,ws,bias,out,mt,nt,tiles,blocks,stream);
        else
            launch<int8_t, int8_t, T>(x,w,xs,ws,bias,out,mt,nt,tiles,blocks,stream);
    }
}

at::Tensor contiguous_if_needed(const at::Tensor& t) {
    return t.is_contiguous() ? t : t.contiguous();
}

} // namespace

at::Tensor fused_a8w8(
    const at::Tensor& x, const at::Tensor& w,
    const at::Tensor& xs, const at::Tensor& ws,
    const c10::optional<at::Tensor>& bias, bool output_bfloat16) {
    TORCH_CHECK(x.is_cuda(), "x must be on a HIP device");
    TORCH_CHECK(w.device() == x.device() &&
                xs.device() == x.device() && ws.device() == x.device(),
                "all inputs must be on the same device");
    TORCH_CHECK(x.dim() == 3 && w.dim() == 3, "x and w must have rank 3");
    const int64_t B = x.size(0), M = x.size(1), K = x.size(2);
    const int64_t N = w.size(1);
    TORCH_CHECK(B > 0 && M > 0 && N > 0 && K > 0, "dimensions must be positive");
    TORCH_CHECK(w.size(0) == B && w.size(2) == K, "batch/K mismatch");
    TORCH_CHECK(xs.dim() == 3 && xs.size(0) == B &&
                xs.size(1) == M && xs.size(2) == 1, "xs must have shape (B,M,1)");
    TORCH_CHECK(ws.dim() == 3 && ws.size(0) == B &&
                ws.size(1) == 1 && ws.size(2) == N, "ws must have shape (B,1,N)");
    TORCH_CHECK((x.scalar_type() == at::kChar || x.scalar_type() == at::kFloat) &&
                (w.scalar_type() == at::kChar || w.scalar_type() == at::kFloat),
                "code words must use int8 or float32 storage");
    TORCH_CHECK(xs.scalar_type() == at::kFloat && ws.scalar_type() == at::kFloat,
                "scales must be float32");
    const auto dtype = output_bfloat16 ? at::kBFloat16 : at::kHalf;
    if (bias.has_value()) {
        TORCH_CHECK(bias->device() == x.device(), "bias device mismatch");
        TORCH_CHECK(bias->dim() == 3 && bias->size(0) == B &&
                    bias->size(1) == 1 && bias->size(2) == N,
                    "bias must have shape (B,1,N)");
        TORCH_CHECK(bias->scalar_type() == at::kFloat || bias->scalar_type() == dtype,
                    "bias must use float32 or output dtype");
    }

    const c10::cuda::CUDAGuard guard(x.device());
    auto xc = contiguous_if_needed(x);
    auto wc = contiguous_if_needed(w);
    auto xsc = contiguous_if_needed(xs);
    auto wsc = contiguous_if_needed(ws);
    at::Tensor bc;
    if (bias.has_value())
        bc = contiguous_if_needed(*bias);
    auto out = at::empty({B, M, N}, x.options().dtype(dtype));
    const int64_t mt = (M - 1) / 32 + 1;
    const int64_t nt = (N - 1) / 32 + 1;
    const int64_t tiles = B * mt * nt;

    // PyTorch caches device properties, so repeated launches do not query HIP.
    const auto* properties = at::cuda::getDeviceProperties(x.get_device());
    TORCH_CHECK(properties->maxThreadsPerBlock >= 256 &&
                properties->sharedMemPerBlock >= 2 * 32 * 33 * sizeof(float),
                "device cannot support the requested tile");
    const int64_t grid_limit = static_cast<int64_t>(properties->maxGridSize[0]);
    TORCH_CHECK(grid_limit > 0, "invalid device grid limit");
    const unsigned int blocks = static_cast<unsigned int>(
        std::min(tiles, std::min(grid_limit, int64_t(65535))));
    const hipStream_t stream = at::cuda::getCurrentCUDAStream(x.get_device());
    if (output_bfloat16)
        dispatch_inputs<at::BFloat16>(xc,wc,xsc,wsc,bc,out,mt,nt,tiles,blocks,stream);
    else
        dispatch_inputs<at::Half>(xc,wc,xsc,wsc,bc,out,mt,nt,tiles,blocks,stream);
    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "fused_a8w8 launch failed: ", hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Batch-dimension int8 quantized GEMM: int8 activations x int8 weights, with an
    outer-product scale applied for dequantization.

    Computed independently for every matrix in the batch (mathematical definition):
      acc[b, m, n] = sum_k xq[b, m, k] * wq[b, n, k]          (float32 accumulation)
      out[b, m, n] = acc[b, m, n] * xs[b, m, 0] * ws[b, 0, n] (+ bias[b, 0, n])

    i.e. out[b] = xq[b] @ wq[b]^T followed by dequantization. wq is stored
    row-major as (B, N, K), so the computation is equivalent to a transposed GEMM
    (row n of the weight is one output-channel column). xs is the per-token scale:
    one value per row of the M dimension, (B, M, 1) float32; ws is the per-channel
    scale: one value per column of the N dimension, (B, 1, N) float32; their outer
    product is the (B, M, N) dequantization matrix. bias (B, 1, N) is optional and
    has the same dtype as the output; with bias the quantized-GEMM kernel fusion
    order applies: the float32 scaled result is first cast to the output dtype, then
    the bias is added.

    Input/output specification:
      xq      int8       (B, M, K)   activation code words
      wq      int8       (B, N, K)   weight code words (row-major, transposed-GEMM
                                     equivalent)
      xs      float32    (B, M, 1)   per-token scale
      ws      float32    (B, 1, N)   per-channel scale
      bias    output dtype (B, 1, N) optional; when use_bias=False a placeholder
                                     tensor is passed and ignored
      out     output dtype (B, M, N) the dtype is set by __init__'s out_dtype
                                     (bfloat16 / float16), B/M/N/K >= 1

    Implementation constraints (violations are scored as failures):
      - The core computation (the int8 GEMM accumulation) must be completed inside
        the submitted file; calling torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / torch._int_mm / F.linear /
        functional.linear is forbidden, as is calling any ready-made operator
        library or closed-source kernel wrapper to complete this computation
        directly.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward; the code
        words are small integers in [-20, 20) and the bias values come from
        low-precision quantization, all exactly representable in fp32, so
        .to(torch.int8) / .to(out_dtype) at the entry point recovers them
        losslessly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: TN layout (x row-major (B,M,K), w row-major (B,N,K)), no split-K;
    B/M/N/K are any values >= 1 with no alignment requirement; the accumulation
    runs in float32 and must agree with the reference fp32 GEMM within tolerance.
    """
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, xq, wq, x_scale, w_scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        # Activation code-word conversion is fused into HIP cooperative loads.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Weight code-word conversion occurs during kernel loads.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        bias = bias if self.use_bias else None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        B, M, K = xq.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = wq.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == wq.shape[2], "xq and wq must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # The extension directly consumes incoming activation storage.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # The extension directly consumes row-major weight storage.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        out = _pyramidkernel_get_extension().fused_a8w8(
            xq, wq, x_scale, w_scale, bias, self.out_dtype == torch.bfloat16)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # Row scaling is fused into the extension epilogue.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Column scaling follows row scaling in the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # The scaled result is rounded to output dtype before bias.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Bias rounding, addition, and final output conversion occur in the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return out
        # <<<END_IMPROVE>>>
