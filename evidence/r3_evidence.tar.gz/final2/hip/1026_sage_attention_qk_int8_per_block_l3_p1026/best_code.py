import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1026_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    SageAttention-style non-causal scaled dot-product attention forward:
    Q/K are already quantized per block to int8 symmetric form (per-block
    absmax/127 scale), while V stays fp16.

    Mathematical definition (g = num_q_heads // num_kv_heads, query head h
    corresponds to KV head h//g; quantization blocking: Q in blocks of 128 rows
    along the sequence direction and K in blocks of 64 rows, with block indices
    i//128 and j//64 respectively, i.e. the index along the last dimension of
    q_scale/k_scale):
      dq[b,h,i,:]    = q_int8[b,h,i,:] * q_scale[b,h,i//128]    (float32 dequant)
      dk[b,hk,j,:]   = k_int8[b,hk,j,:] * k_scale[b,hk,j//64]
      logit[b,h,i,j] = <dq[b,h,i,:], dk[b,h//g,j,:]> / log2(e)
      (divide by log2(e): the quantization stage already folded the softmax scale
         and log2(e) into q_scale, and the softmax
         in base 2, so everything is converted back to the natural-log domain
         here)
      positions where attn_mask[i,j] is False get logit = -inf (bool mask,
        shape [qo_len, kv_len], shared by all batches and heads)
      p[b,h,i,:]   = softmax_j(logit[b,h,i,:])
      out[b,h,i,:] = sum_j p[b,h,i,j] * v[b,h//g,j,:]
    The softmax follows the semantics of a numerically stable online
    implementation; the reference implementation works entirely in float32 (the
    dot product of int8 codewords is exact integer arithmetic in float32), and
    the output is cast back to the dtype of v.
    Numeric scheme (used by the source operator, a submission may reuse it): cast
    p to fp16 and do the matrix multiply against v in fp16, accumulating the
    result of each KV shard into a float32 buffer ("PV fp16 + fp32 shard
    accumulation"), and do the int8 QK^T with a matrix multiply of int8 inputs
    accumulating directly in integers -- whichever numeric scheme is used, it
    must match this reference implementation within the tolerance.
    Boundary behaviour: qo_len and kv_len may differ and need not be integer
    multiples of the block sizes (the tail block takes part in the
    dequantization and the softmax as usual); the task guarantees that every
    query row has at least one unmasked position, so the softmax denominator is
    always positive.

    Input/output specification (tensor_layout="HND"/"NHD" is given by __init__):
      q_int8   int8     HND [batch, num_q_heads, qo_len, head_dim]
                         NHD [batch, qo_len, num_q_heads, head_dim]
      k_int8   int8     HND [batch, num_kv_heads, kv_len, head_dim]
                         NHD [batch, kv_len, num_kv_heads, head_dim]
      v        float16  same layout and same number of KV heads as k_int8
      q_scale  float32  [batch, num_q_heads, ceil(qo_len/128)] (layout independent)
      k_scale  float32  [batch, num_kv_heads, ceil(kv_len/64)] (layout independent)
      attn_mask bool    [qo_len, kv_len] (layout independent)
      out      same shape as q_int8, dtype same as v (single-tensor output)
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (GQA; equality means MHA); head_dim in {64, 128}; qo_len, kv_len >= 1.

    Implementation constraints (violations are scored as failures):
      - The core computation (int8 QK^T / dequantization / softmax / PV) must be
        completed inside the submitted file; calling
        scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.mm / torch.addmm / F.linear / torch.einsum /
        torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.
      - The evaluator casts every input to fp32 before calling forward: the int8
        codewords, the fp16 v and the bool mask are all exactly representable in
        fp32, so the original dtypes are recovered losslessly at the entry.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: non-causal forward, bool mask, GQA, both the HND and NHD layouts;
    does not include the causal variant, float additive masks, LSE output, or the
    quantization stage itself (the int8 codewords are given directly as inputs).
    """
    def __init__(self, tensor_layout="HND"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert tensor_layout in ("HND", "NHD"), "tensor_layout only supports HND / NHD"
        self.tensor_layout = tensor_layout
        # <<<END_IMPROVE>>>

    def forward(self, q_int8, k_int8, v, q_scale, k_scale, attn_mask):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        q_int8 = q_int8.to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        k_int8 = k_int8.to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        v = v.to(torch.float16)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        q_scale = q_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        k_scale = k_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        attn_mask = attn_mask.to(torch.bool)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        nhd = self.tensor_layout == "NHD"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        q = (q_int8.permute(0, 2, 1, 3) if nhd else q_int8).to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        k = (k_int8.permute(0, 2, 1, 3) if nhd else k_int8).to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        vv = (v.permute(0, 2, 1, 3) if nhd else v).to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        b, h_q, qo_len, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        h_kv, kv_len = k.shape[1], k.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        group = h_q // h_kv
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        assert h_q == h_kv * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        k = k.repeat_interleave(group, dim=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        vv = vv.repeat_interleave(group, dim=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        k_scale = k_scale.repeat_interleave(group, dim=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        qs = q_scale.repeat_interleave(128, dim=-1)[..., :qo_len]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        ks = k_scale.repeat_interleave(64, dim=-1)[..., :kv_len]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        logits = torch.matmul(q, k.transpose(-2, -1))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        logits = logits * qs[:, :, :, None] * ks[:, :, None, :] / 1.4426950408889634
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        logits = logits.masked_fill(~attn_mask, float("-inf"))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        probs = torch.softmax(logits, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        out = torch.matmul(probs, vv)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        out = out.permute(0, 2, 1, 3) if nhd else out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        return out.contiguous().to(v.dtype)
        # <<<END_IMPROVE>>>
