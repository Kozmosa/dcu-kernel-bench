import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l1_p8002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor gather_cuda(
    torch::Tensor data,
    torch::Tensor indices,
    int64_t axis,
    bool gather_elements);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("select_forward", &gather_cuda);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cstdint>
#include <vector>
#include <algorithm>

template <typename scalar_t, typename index_t, bool GatherElements, bool InnerOne>
__global__ void gather_kernel(
    const scalar_t* __restrict__ data,
    const index_t* __restrict__ indices,
    scalar_t* __restrict__ output,
    int64_t output_numel,
    int64_t data_numel,
    int64_t indices_numel,
    int64_t data_axis,
    int64_t inner,
    int64_t output_axis) {
    int64_t pos = static_cast<int64_t>(blockIdx.x) *
                     static_cast<int64_t>(blockDim.x) +
                 static_cast<int64_t>(threadIdx.x);
    int64_t stride = static_cast<int64_t>(blockDim.x) *
                     static_cast<int64_t>(gridDim.x);

    for (; pos < output_numel; pos += stride) {
        int64_t outer;
        int64_t inner_pos;
        int64_t index_offset;
        if constexpr (InnerOne) {
            outer = pos / output_axis;
            inner_pos = int64_t(0);
            index_offset = GatherElements ? pos : pos % output_axis;
        } else {
            int64_t axis_linear = pos / inner;
            inner_pos = pos - axis_linear * inner;
            outer = axis_linear / output_axis;
            index_offset = GatherElements ? pos :
                axis_linear - outer * output_axis;
        }

        if (index_offset < 0 || index_offset >= indices_numel) {
            continue;
        }

        int64_t selected = static_cast<int64_t>(indices[index_offset]);
        if (selected < 0 || selected >= data_axis) {
            continue;
        }

        int64_t source = InnerOne ? outer * data_axis + selected :
            (outer * data_axis + selected) * inner + inner_pos;

        if (source >= 0 && source < data_numel) {
            output[pos] = data[source];
        }
    }
}

template <typename scalar_t, typename index_t, bool GatherElements, bool InnerOne>
static void launch_specialized(
    const torch::Tensor& data,
    const torch::Tensor& indices,
    torch::Tensor& output,
    int64_t output_numel,
    int64_t data_axis,
    int64_t inner,
    int64_t output_axis,
    int64_t blocks,
    hipStream_t stream) {
    gather_kernel<scalar_t, index_t, GatherElements, InnerOne>
        <<<static_cast<unsigned int>(blocks), 256, 0, stream>>>(
        data.data_ptr<scalar_t>(),
        indices.data_ptr<index_t>(),
        output.data_ptr<scalar_t>(),
        output_numel,
        static_cast<int64_t>(data.numel()),
        static_cast<int64_t>(indices.numel()),
        data_axis,
        inner,
        output_axis);
}

template <typename scalar_t, typename index_t>
static void launch_gather(
    const torch::Tensor& data,
    const torch::Tensor& indices,
    torch::Tensor& output,
    int64_t output_numel,
    int64_t data_axis,
    int64_t inner,
    int64_t output_axis,
    bool gather_elements) {
    if (output_numel == 0) {
        return;
    }

    const int64_t needed_blocks =
        output_numel / int64_t(256) +
        (output_numel % int64_t(256) != 0);
    const int64_t max_blocks = int64_t(80) * int64_t(8);
    const int64_t blocks = std::min(needed_blocks, max_blocks);
    const auto stream = c10::cuda::getCurrentCUDAStream(data.get_device());

    if (gather_elements) {
        if (inner == 1) {
            launch_specialized<scalar_t, index_t, true, true>(
                data, indices, output, output_numel, data_axis, inner,
                output_axis, blocks, stream.stream());
        } else {
            launch_specialized<scalar_t, index_t, true, false>(
                data, indices, output, output_numel, data_axis, inner,
                output_axis, blocks, stream.stream());
        }
    } else {
        if (inner == 1) {
            launch_specialized<scalar_t, index_t, false, true>(
                data, indices, output, output_numel, data_axis, inner,
                output_axis, blocks, stream.stream());
        } else {
            launch_specialized<scalar_t, index_t, false, false>(
                data, indices, output, output_numel, data_axis, inner,
                output_axis, blocks, stream.stream());
        }
    }

    const hipError_t error = hipGetLastError();
    TORCH_CHECK(
        error == hipSuccess,
        "HIP gather kernel launch failed: ",
        hipGetErrorString(error));
}

torch::Tensor gather_cuda(
    torch::Tensor data,
    torch::Tensor indices,
    int64_t axis,
    bool gather_elements) {
    TORCH_CHECK(data.is_cuda(), "data must be a HIP tensor");
    TORCH_CHECK(indices.is_cuda(), "indices must be a HIP tensor");
    TORCH_CHECK(
        data.device() == indices.device(),
        "tensors must be on the same device");

    const c10::cuda::CUDAGuard device_guard(data.device());

    TORCH_CHECK(data.is_contiguous(), "data must be contiguous");
    TORCH_CHECK(indices.is_contiguous(), "indices must be contiguous");
    TORCH_CHECK(
        data.dim() >= 1 && data.dim() <= 4,
        "unsupported data rank");

    const int64_t ndim = static_cast<int64_t>(data.dim());
    TORCH_CHECK(axis >= 0 && axis < ndim, "axis out of range");

    if (gather_elements) {
        TORCH_CHECK(
            indices.dim() == data.dim(),
            "indices rank mismatch");
        for (int64_t d = 0; d < ndim; ++d) {
            if (d != axis) {
                TORCH_CHECK(
                    indices.size(d) == data.size(d),
                    "indices shape mismatch");
            }
        }
    } else {
        TORCH_CHECK(
            indices.dim() == 1,
            "gather indices must be 1-D");
        TORCH_CHECK(
            indices.numel() >= 1,
            "indices must be non-empty");
    }

    int64_t outer = 1;
    for (int64_t d = 0; d < axis; ++d) {
        outer *= static_cast<int64_t>(data.size(d));
    }

    int64_t inner = 1;
    for (int64_t d = axis + 1; d < ndim; ++d) {
        inner *= static_cast<int64_t>(data.size(d));
    }

    const int64_t data_axis = static_cast<int64_t>(data.size(axis));
    const int64_t output_axis = gather_elements
        ? static_cast<int64_t>(indices.size(axis))
        : static_cast<int64_t>(indices.numel());

    std::vector<int64_t> output_sizes;
    output_sizes.reserve(static_cast<size_t>(ndim));
    for (int64_t d = 0; d < ndim; ++d) {
        output_sizes.push_back(
            d == axis
                ? output_axis
                : static_cast<int64_t>(data.size(d)));
    }

    torch::Tensor output = torch::empty(output_sizes, data.options());
    const int64_t output_numel = outer * output_axis * inner;

    TORCH_CHECK(
        indices.scalar_type() == at::kInt ||
        indices.scalar_type() == at::kLong ||
        indices.scalar_type() == at::kFloat,
        "unsupported index dtype");

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::kHalf,
        at::kBFloat16,
        data.scalar_type(),
        "hip_gather",
        [&] {
            if (indices.scalar_type() == at::kInt) {
                launch_gather<scalar_t, int32_t>(
                    data, indices, output, output_numel, data_axis, inner,
                    output_axis, gather_elements);
            } else if (indices.scalar_type() == at::kLong) {
                launch_gather<scalar_t, int64_t>(
                    data, indices, output, output_numel, data_axis, inner,
                    output_axis, gather_elements);
            } else {
                launch_gather<scalar_t, float>(
                    data, indices, output, output_numel, data_axis, inner,
                    output_axis, gather_elements);
            }
        });

    return output;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Gather / GatherElements: the index-movement family that selects elements
    along a given axis by integer index.

    The __init__ parameter `variant` selects one of two paths; their semantics
    are defined as follows:
        "gather" (select along an axis): `indices` is a 1-D integer vector of
            arbitrary length K;
            out[i_0, ..., i_{axis-1}, j, i_{axis+1}, ...] =
                data[i_0, ..., i_{axis-1}, indices[j], i_{axis+1}, ...]
            i.e. indices[j] picks one whole slice along dimension `axis` at a
            time; the output shape equals the data shape with dimension `axis`
            replaced by K.
        "gather_elements" (element-wise selection with a same-shaped index):
            `indices` has the same rank as data, with every dimension equal to
            data except dimension `axis` (whose length K may differ from data);
            out[i_0, ..., i_{n-1}] = data[i_0, ..., m, ..., i_{n-1}] where
            m = indices[i_0, ..., i_{n-1}] -- each output element takes its own
            subscript along `axis`; the output shape equals the indices shape.
    The difference: gather's index is a 1-D vector that decides how a whole
    slice along `axis` is selected at once; gather_elements' index has the same
    shape as the output and specifies the subscript along `axis` per element.
    The __init__ parameter `axis` sets the selection dimension (torch
    convention: non-negative counts from 0, negative counts from the end),
    defaulting to 1.

    Numeric contract: this operator is pure index movement with no arithmetic.
    A correct implementation produces an output bit-identical to the selected
    elements of the input (bit patterns preserved; no dtype conversion, no
    numeric operation).

    Input/output specification:
        data    float32 / float16 / bfloat16, contiguous, ndim in [1, 4],
                every dimension >= 1, total element count <= 2^23; values are
                ordinary randn magnitude (no inf/NaN)
        indices an integer tensor: for variant="gather" an int64 1-D tensor
                (length K >= 1); for variant="gather_elements" an int32 tensor
                with the same rank as data (shape constraints above); every
                index value lies in [0, data.shape[axis]) -- the input contains
                no out-of-range index
        out     a single tensor, same dtype as data, contiguous: for gather its
                shape is the data shape with dimension `axis` replaced by K;
                for gather_elements its shape is the indices shape. forward must
                return a single tensor (the evaluator compares .shape /
                allclose on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (indices are small non-negative integers < 2^24 and are exactly
        representable in fp32, so they are recovered losslessly; fp16/bf16 ->
        fp32 is also lossless). The offline final audit passes inputs natively
        in their declared dtype -- the implementation must be correct for both.

    Boundary behaviour: K=1, K different from data.shape[axis], an axis of
    length 1, non-power-of-two / prime lengths, and repeated indices hitting the
    same element must all be handled correctly; a negative `axis` follows the
    torch convention.

    Implementation constraints (violations are scored as failures):
        - The core computation (index expansion / address computation plus
          load/store at those addresses) must be completed with a HIP kernel
          inside the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Pure-movement contract: the output is bit-identical to the selected
          elements of data (including float16 / bfloat16 bit patterns); no
          numeric transformation may be introduced.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.gather / .gather( / torch.index_select /
    .index_select( / torch.take_along_dim / .take_along_dim( /
    torch.take( / .take( (including the Tensor.take method form) /
    torch.embedding / nn.Embedding / .embedding( / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "gather", axis: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("gather", "gather_elements"), "variant must be one of gather / gather_elements"
        self.variant = variant
        self.axis = int(axis)
        # <<<END_IMPROVE>>>

    def forward(self, data, indices):
        # <<<IMPROVE:forward_stmt_1>>>
        ndim = data.dim()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        axis = self.axis % ndim
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        idx = indices.contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return _pyramidkernel_get_extension().select_forward(
            data, idx, axis, self.variant == "gather_elements")
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
