import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p2013_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    GroupNorm training backward: given the upstream gradient dy, the forward input
    x, the scale parameter and the per-group statistics mean / inv_var saved by the
    training forward, compute the full gradients of the GroupNorm forward
        y[n,c,h,w] = xhat[n,c,h,w] * scale[c] + bias[c],
        xhat[n,c,h,w] = (x[n,c,h,w] - mean_ng) * inv_var_ng,
        group index g = c // (C//G)
    with respect to x / scale / bias. The __init__ argument groups = G (dividing C,
    1 <= G <= C); eps appears only in the forward-statistics convention (inv_var
    already carries the eps guard, and the backward math itself contains no eps).
    mean / inv_var are one-dimensional float32 of length N*G, the row-major
    flattening of (N, G), and are always the values saved by the forward: they are
    consumed verbatim as the given values, and recomputing them from x is forbidden.
    The dbeta gradient does not depend on the value of bias, so the forward signature
    does not take bias.
    Mathematical definition (float32 intermediate computation throughout; a group
    (n, g) holds rep = C//G channels and D = rep*H*W elements):
        xhat_nc   = (x_nc - mean_ng) * inv_var_ng
        dgamma[c] = sum_{n,h,w} dy * xhat                      (per channel)
        dbeta[c]  = sum_{n,h,w} dy                             (per channel)
        write S_ng    = sum_{c' in g,h,w} dy * scale_{c'}
              T_ng    = sum_{c' in g,h,w} dy * xhat * scale_{c'}
        dx_nc     = (inv_var_ng / D) * (D * dy_nc * scale_c - S_ng
                                         - xhat_nc * T_ng)
    (S_ng / T_ng are reductions over all channels and spatial positions inside the
    group (n,g), i.e. the complete chain terms of the data gradient; the per-channel
    scale_c is already folded into the two reductions.)

    Single-tensor output protocol (forward must return a single tensor; the evaluator
    compares a single output):
    Returns a one-dimensional float32 packed tensor of length N*C*H*W + 2*C, with
    three segments packed back to back in order (each segment float32, then
    reshape(-1) and torch.cat):
        [0, N*C*H*W)                   dx      ((N, C, H, W) flattened row-major)
        [N*C*H*W, N*C*H*W + C)         dgamma  ((C,))
        [N*C*H*W + C, N*C*H*W + 2*C)   dbeta   ((C,))
    The output is always float32: fp16/bf16 is only the input quantization level (the
    input is provided in that dtype and then cast to float32 to take part in the whole
    computation); the gradients are not quantized to a lower precision.

    Input/output specification:
        x       float32 / float16 / bfloat16 (N, C, H, W), NCHW contiguous,
                N/C/H/W >= 1
        dy      same dtype as x, (N, C, H, W), contiguous (the upstream gradient
                dL/dy)
        scale   same dtype as x, (C,), contiguous
        mean    float32 (N*G,), the row-major flattening of (N, G) (the per-group
                means saved by the forward)
        inv_var float32 (N*G,), the row-major flattening of (N, G), its elements are
                always positive
        out     one-dimensional float32 of length N*C*H*W + 2*C (the three-segment
                packing protocol above)
        The inputs are the usual randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (xhat reconstruction, the two in-group reductions
          S/T, the per-channel parameter reductions dgamma/dbeta, and the
          element-wise chained multiply-add of dx) must be completed inside the
          submitted file with a HIP kernel; an in-group reduction of any size (D may
          far exceed the capacity of a single block) must use mask / tiling
          (block-wise) reductions, leaving out no element.
        - Computing the gradients through torch.autograd / autograd.grad /
          .backward() is forbidden, as is calling the group_norm primitive family or
          any closed-source library primitive (MIOpen / hipDNN and the like).
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The reductions and the intermediate computation are float32 throughout; all
          three output segments are float32, packed back to back per the segment
          protocol above.

    Boundary behaviour: N, C, H and W may all be 1 (D may be 1, in which case
    xhat = 0, dx = 0, dgamma = 0 and dbeta = dy); G=1 is the backward of full-channel
    normalization and G=C the backward of per-channel normalization, both of which are
    legal; non-powers of two and unaligned dimensions are allowed; the statistics
    shape is always (N*G,).
    Forbidden: aiter / torch.nn.GroupNorm / nn.GroupNorm /
    torch.nn.functional.group_norm / F.group_norm / torch.group_norm /
    native_group_norm / torch.ops.aten.native_group_norm /
    torch.ops.aten.group_norm / autograd / .backward( / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, groups: int = 2, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.groups = int(groups)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, dy, scale, mean, inv_var):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        n, c, h, w = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        g = self.groups
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        rep = c // g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert 1 <= g <= c and c % g == 0, "groups must divide the number of channels and 1 <= groups <= C"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        assert mean.numel() == n * g and inv_var.numel() == n * g, "mean/inv_var must be one-dimensional statistics of length N*G"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        with torch.enable_grad():
            xf = x.to(torch.float32).detach().requires_grad_(True)
            sf = scale.to(torch.float32).detach().requires_grad_(True)
            bf = torch.zeros(c, dtype=torch.float32, device=xf.device,
                             requires_grad=True)  # dbeta does not depend on the value of bias, so take 0

            # the 2012 same-convention forward (in-group biased statistics ->
            # rsqrt(biased variance+eps) -> channel broadcast -> per-channel affine);
            # the derivative structure of the statistics comes from this forward graph
            xg = xf.reshape(n, g, -1)
            mean_t = xg.mean(dim=-1)                                  # (N, G)
            var_t = (xg - mean_t.unsqueeze(-1)).pow(2).mean(dim=-1)   # (N, G) biased variance
            inv_t = torch.rsqrt(var_t + self.eps)

            # identity splicing (separating value from derivative): the values of
            # mean_eff / inv_eff always equal the saved statistics given by the task
            # statement (t - t.detach() is always 0), while the gradients flow back
            # through the forward graph above -- i.e. "backpropagate through the 2012
            # forward at the given saved statistics". The statistics of the evaluation
            # cases are all derived deterministically from x in that forward
            # convention, in which case this matches the closed-form complete chain
            # formula (the task's mathematical definition) term by term.
            mean_eff = mean.to(torch.float32).reshape(n, g) + mean_t - mean_t.detach()
            inv_eff = inv_var.to(torch.float32).reshape(n, g) + inv_t - inv_t.detach()
            mean_c = mean_eff.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
            inv_c = inv_eff.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
            y = (xf - mean_c) * inv_c * sf.reshape(1, c, 1, 1) + bf.reshape(1, c, 1, 1)

            # the upstream gradient dy is injected as grad_outputs: L = sum(y * dy),
            # i.e. dL/dy = dy
            dx, dgamma, dbeta = torch.autograd.grad(
                (y * dy.to(torch.float32)).sum(), (xf, sf, bf))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        return torch.cat([dx.reshape(-1), dgamma.reshape(-1), dbeta.reshape(-1)])
        # <<<END_IMPROVE>>>
