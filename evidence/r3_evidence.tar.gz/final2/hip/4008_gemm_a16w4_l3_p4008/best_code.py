import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4008_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    AWQ W4A16 quantized GEMM: int4 packed weights are dequantized inside the
    kernel and then multiplied with the activations.

    Operator semantics (mathematical definition and boundary behaviour):
      activation input [M, K] (float16), AWQ int4 packed weights
      qweight [N, K//2] (int8, 2 4-bit code words stored per byte consecutively
      along K, the low nibble corresponding to even k), grouped zeros
      qzeros [K//G, N//2] (int8, 2 4-bit code words stored per byte
      consecutively along N, the low nibble corresponding to even n), grouped
      scales scales [K//G, N] (float16). Dequantization and the matrix multiply
      are defined as
        w[n, k] = (qweight[n, k//2] >> (4*(k%2))) & 0xF
        z[g, n] = (qzeros[g, n//2]   >> (4*(n%2))) & 0xF
        W[k, n] = (w[n, k] - z[k//G, n]) * scales[k//G, n]
        out[m, n] = sum_{k=0}^{K-1} input[m, k] * W[k, n]
      A signed int8 right shift is an arithmetic right shift, so the & 0xF after
      the shift always extracts the stored 4-bit code word (result 0..15);
      w - z takes values in [-15, 15]. The element-wise multiply-accumulate runs
      in float32 throughout, and the output is cast back to the input dtype.
      Boundary behaviour: M, K and N need not be aligned to any tiling size
      (positions past the end along K and N take part in the masked
      accumulation as 0); G is 32/64/128 or G == K (per-channel), and G divides
      K.

    Input/output specification:
      forward(input, qweight, scales, qzeros) -> out
        input   [M, K]         float16, row-major contiguous
        qweight [N, K//2]      int8 packed weights (low nibble = even k)
        scales  [K//G, N]      float16, row-major contiguous
        qzeros  [K//G, N//2]   int8 packed zeros (low nibble = even n)
        out     [M, N]         same dtype as input
      __init__(in_features, out_features, group_size): correspond to K, N, G
      respectively and are instance metadata only; forward always follows the
      actual runtime tensor shapes (G = K // qzeros.shape[0]).

    Implementation constraints (violations are scored as failures):
      - The core computation (int4 code-word unpacking, grouped dequantization,
        the multiply-accumulate main loop) must be completed inside the
        submitted file as HIP kernels; calling torch.matmul / torch.bmm /
        torch.mm / torch.addmm / torch.einsum / torch.nn.functional.linear /
        F.linear / aiter or any other ATen GEMM shortcut is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-card W4A16 GEMM, float16 activations and float16 scales;
    the scheduling strategy (data parallel / split-K / stream-K) and the tiling
    are up to the implementation and judged by the output tolerance; no bias,
    no quantization-aware activation transform, no cross-card communication
    fusion.
    """
    def __init__(self, in_features: int, out_features: int, group_size: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.in_features = in_features
        self.out_features = out_features
        self.group_size = group_size
        # <<<END_IMPROVE>>>

    def forward(self, input, qweight, scales, qzeros):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        qweight = qweight.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        qzeros = qzeros.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        M, K = input.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        N = qweight.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        group = K // qzeros.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert qweight.shape[1] == K // 2 and qzeros.shape[1] == N // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert scales.shape[0] == K // group and scales.shape[1] == N
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        k_shift = (torch.arange(K, device=input.device) % 2) * 4
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        w_int = (qweight.repeat_interleave(2, dim=1) >> k_shift) & 0xF
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        n_shift = (torch.arange(N, device=input.device) % 2) * 4
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        z_int = (qzeros.repeat_interleave(2, dim=1) >> n_shift) & 0xF
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        z_full = z_int.repeat_interleave(group, dim=0)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        s_full = scales.to(torch.float32).repeat_interleave(group, dim=0)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        w_deq = (w_int.to(torch.float32).t() - z_full.to(torch.float32)) * s_full
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        out = torch.matmul(input.to(torch.float32), w_deq)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return out.to(input.dtype)
        # <<<END_IMPROVE>>>
