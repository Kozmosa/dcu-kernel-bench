import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1011_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor extend_attention(
    torch::Tensor q_extend,
    torch::Tensor k_extend,
    torch::Tensor v_extend,
    torch::Tensor k_buffer,
    torch::Tensor v_buffer,
    torch::Tensor qo_indptr,
    torch::Tensor kv_indptr,
    torch::Tensor kv_indices,
    bool causal,
    double sm_scale);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("extend_attention", &extend_attention, "Ragged extend attention (HIP)");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/ATen.h>
#include <ATen/hip/HIPContext.h>
#include <c10/hip/HIPGuard.h>
#include <hip/hip_runtime.h>
#include <cstdint>
#include <cmath>
#include <algorithm>

constexpr int TILE = 64;
constexpr int THREADS = 128;

template <typename scalar_t>
__global__ void extend_attention_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ kext,
    const scalar_t* __restrict__ vext,
    const scalar_t* __restrict__ kbuf,
    const scalar_t* __restrict__ vbuf,
    const int32_t* __restrict__ qo,
    const int32_t* __restrict__ kv,
    const int32_t* __restrict__ ids,
    scalar_t* __restrict__ out,
    int64_t total, int64_t hq, int64_t hkv,
    int64_t dq, int64_t dv, int64_t pool,
    int64_t nseq, int64_t ids_numel, bool causal, float scale) {
    extern __shared__ float shared[];
    float* sq = shared;
    float* logits = sq + dq;
    float* accum = logits + TILE;
    __shared__ int64_t rows[TILE];
    __shared__ float running_max, denom, correction;
    const int64_t lane = threadIdx.x;

    for (int64_t work = static_cast<int64_t>(blockIdx.x);
         work < total * hq;
         work += static_cast<int64_t>(gridDim.x)) {
        const int64_t row = work / hq;
        const int64_t head = work % hq;
        int64_t lo = 0, hi = nseq;
        while (lo < hi) {
            const int64_t mid = lo + (hi - lo) / 2;
            if (row < static_cast<int64_t>(qo[mid + 1])) hi = mid;
            else lo = mid + 1;
        }
        if (lo >= nseq) continue;
        const int64_t qs = qo[lo], qe = qo[lo + 1];
        const int64_t ks = kv[lo], ke = kv[lo + 1];
        if (qs < 0 || qe > total || qs > row || row >= qe ||
            ks < 0 || ke < ks || ke > ids_numel) continue;
        const int64_t prefix = ke - ks;
        const int64_t visible = prefix + (causal ? row - qs + 1 : qe - qs);
        const int64_t g = head / (hq / hkv);
        const int64_t qbase = work * dq;
        for (int64_t c = lane; c < dq; c += THREADS)
            sq[c] = static_cast<float>(q[qbase + c]);
        for (int64_t d = lane; d < dv; d += THREADS)
            accum[d] = 0.0f;
        if (lane == 0) {
            running_max = -INFINITY;
            denom = 0.0f;
        }
        __syncthreads();

        for (int64_t start = 0; start < visible; start += TILE) {
            if (lane < TILE) {
                const int64_t j = start + lane;
                int64_t r = -1;
                bool is_prefix = j < prefix;
                if (j < visible) {
                    if (is_prefix) {
                        const int64_t ip = ks + j;
                        if (ip >= 0 && ip < ids_numel) {
                            const int64_t candidate = ids[ip];
                            if (candidate >= 0 && candidate < pool) r = candidate;
                        }
                    } else {
                        const int64_t candidate = qs + j - prefix;
                        if (candidate >= qs && candidate < qe && candidate < total)
                            r = candidate;
                    }
                }
                rows[lane] = r;
                float dot = 0.0f;
                if (r >= 0) {
                    const scalar_t* key = is_prefix ? kbuf : kext;
                    const int64_t base = (r * hkv + g) * dq;
                    for (int64_t c = 0; c < dq; ++c)
                        dot = fmaf(sq[c], static_cast<float>(key[base + c]), dot);
                }
                logits[lane] = r >= 0 ? dot * scale : -INFINITY;
            }
            __syncthreads();
            if (lane == 0) {
                float m = running_max;
                for (int64_t j = 0; j < TILE; ++j)
                    m = fmaxf(m, logits[j]);
                correction = isfinite(running_max) ? expf(running_max - m) : 0.0f;
                running_max = m;
            }
            __syncthreads();
            if (lane < TILE) {
                logits[lane] = rows[lane] >= 0
                    ? expf(logits[lane] - running_max) : 0.0f;
            }
            __syncthreads();
            if (lane == 0) {
                float sum = 0.0f;
                for (int64_t j = 0; j < TILE; ++j)
                    sum += logits[j];
                denom = denom * correction + sum;
            }
            __syncthreads();
            for (int64_t d = lane; d < dv; d += THREADS) {
                float a = accum[d] * correction;
                for (int64_t j = 0; j < TILE && start + j < visible; ++j) {
                    const int64_t r = rows[j];
                    if (r >= 0) {
                        const scalar_t* value = start + j < prefix ? vbuf : vext;
                        const int64_t offset = (r * hkv + g) * dv + d;
                        a = fmaf(logits[j], static_cast<float>(value[offset]), a);
                    }
                }
                accum[d] = a;
            }
            __syncthreads();
        }
        for (int64_t d = lane; d < dv; d += THREADS)
            out[work * dv + d] = static_cast<scalar_t>(
                denom > 0.0f ? accum[d] / denom : 0.0f);
        __syncthreads();
    }
}

torch::Tensor extend_attention(
    torch::Tensor q, torch::Tensor ke, torch::Tensor ve,
    torch::Tensor kb, torch::Tensor vb, torch::Tensor qo,
    torch::Tensor kv, torch::Tensor ids, bool causal, double sm_scale) {
    TORCH_CHECK(q.is_cuda(), "query must be on the accelerator");
    for (const auto& t : {q, ke, ve, kb, vb, qo, kv, ids}) {
        TORCH_CHECK(t.is_cuda() && t.device() == q.device(),
                    "all tensors must be on the same accelerator");
        TORCH_CHECK(t.is_contiguous(), "all tensors must be contiguous");
    }
    TORCH_CHECK(q.dim() == 3 && ke.dim() == 3 && ve.dim() == 3 &&
                kb.dim() == 3 && vb.dim() == 3, "invalid data tensor ranks");
    TORCH_CHECK(qo.dim() == 1 && kv.dim() == 1 && ids.dim() == 1,
                "invalid index tensor ranks");
    TORCH_CHECK(qo.scalar_type() == at::kInt && kv.scalar_type() == at::kInt &&
                ids.scalar_type() == at::kInt, "indices must be int32");
    TORCH_CHECK(q.scalar_type() == at::kFloat || q.scalar_type() == at::kHalf ||
                q.scalar_type() == at::kBFloat16, "unsupported input dtype");
    for (const auto& t : {ke, ve, kb, vb})
        TORCH_CHECK(t.scalar_type() == q.scalar_type(), "data dtype mismatch");
    TORCH_CHECK(qo.numel() >= 1 && qo.numel() == kv.numel(), "invalid indptr sizes");

    const int64_t total = q.size(0), hq = q.size(1), dq = q.size(2);
    const int64_t hkv = ke.size(1), dv = ve.size(2), pool = kb.size(0);
    const int64_t nseq = qo.numel() - 1;
    TORCH_CHECK(hq > 0 && hkv > 0 && hq % hkv == 0 &&
                dq > 0 && dv > 0, "invalid attention dimensions");
    TORCH_CHECK(ke.size(0) == total && ve.size(0) == total &&
                ke.size(2) == dq && ve.size(1) == hkv &&
                kb.size(1) == hkv && kb.size(2) == dq &&
                vb.size(0) == pool && vb.size(1) == hkv && vb.size(2) == dv,
                "incompatible attention shapes");
    TORCH_CHECK(total == 0 || nseq > 0, "missing sequences");
    c10::hip::HIPGuard guard(q.get_device());
    auto out = torch::empty({total, hq, dv}, q.options());
    if (total == 0) return out;
    const int64_t shared_bytes = (dq + TILE + dv) * static_cast<int64_t>(sizeof(float));
    hipDeviceProp_t props;
    auto status = hipGetDeviceProperties(&props, q.get_device());
    TORCH_CHECK(status == hipSuccess, hipGetErrorString(status));
    TORCH_CHECK(shared_bytes + TILE * sizeof(int64_t) + 3 * sizeof(float)
                <= props.sharedMemPerBlock, "head dimensions exceed shared memory capacity");
    auto stream = at::hip::getCurrentHIPStream();
    const dim3 grid(static_cast<unsigned int>(std::min<int64_t>(total * hq, 65535)));
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "extend_attention_hip", [&] {
            extend_attention_kernel<scalar_t><<<grid, THREADS, shared_bytes, stream.stream()>>>(
                q.data_ptr<scalar_t>(), ke.data_ptr<scalar_t>(), ve.data_ptr<scalar_t>(),
                kb.data_ptr<scalar_t>(), vb.data_ptr<scalar_t>(),
                qo.data_ptr<int32_t>(), kv.data_ptr<int32_t>(), ids.data_ptr<int32_t>(),
                out.data_ptr<scalar_t>(), total, hq, hkv, dq, dv, pool,
                nseq, ids.numel(), causal, static_cast<float>(sm_scale));
            const hipError_t error = hipGetLastError();
            TORCH_CHECK(error == hipSuccess, "extend attention kernel launch failed: ",
                        hipGetErrorString(error));
        });
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Variable-length attention mixing the extend (incremental prefill) phase with a prefix segment (GQA, causal optional).

    Inside the batch each sequence's KV has two segments: the prefix segment is
    already written into the KV pool (k_buffer / v_buffer) and is addressed
    token by token indirectly through the row ids in kv_indices; the extend
    segment holds the tokens newly computed in this step, whose K/V are stored
    contiguously per token in k_extend / v_extend, with the query in q_extend in
    the same order. For sequence i let E_i = qo_indptr[i+1] - qo_indptr[i]
    (number of extend tokens) and P_i = kv_indptr[i+1] - kv_indptr[i] (number of
    prefix tokens). For the t-th query of the extend segment (global position
    T = P_i + t, row s = qo_indptr[i] + t) and query head h (its KV head is
    g = h // query_group_size, query_group_size = num_q_heads // num_kv_heads):
      K_full = concat(k_buffer[kv_indices[kv_indptr[i]:kv_indptr[i+1]]][:, g, :],
                      k_extend[qo_indptr[i]:qo_indptr[i+1]][:, g, :])   P_i + E_i rows
      V_full likewise (taking the head_dim_v head dimension)
      logits[j] = sm_scale * <q_extend[s, h, :], K_full[j]>
                 (sm_scale defaults to 1/sqrt(head_dim_q))
      visibility: the whole prefix is visible; the extend segment with causal=True
      sees only tokens with global position <= T (that is, the first t+1 extend
      tokens), and with causal=False everything is visible
      p = softmax(logits) (numerically stable online implementation)
      out[s, h, :] = sum_j p[j] * V_full[j]
    Under causal the query's own position is always visible, so the softmax
    denominator is always > 0. K's head dimension equals Q's head dimension
    head_dim_q; V's head dimension head_dim_v may differ from it.

    Input/output specification (evaluation dtype is float16 / bfloat16, all tensors contiguous):
      q_extend   evaluation dtype (total_extend, num_q_heads, head_dim_q)
      k_extend   evaluation dtype (total_extend, num_kv_heads, head_dim_q)
      v_extend   evaluation dtype (total_extend, num_kv_heads, head_dim_v)
      k_buffer   evaluation dtype (num_pool, num_kv_heads, head_dim_q)   prefix K pool
      v_buffer   evaluation dtype (num_pool, num_kv_heads, head_dim_v)   prefix V pool
      qo_indptr  int32 (num_seqs + 1) -- prefix sum of extend lengths (each segment >= 1)
      kv_indptr  int32 (num_seqs + 1) -- prefix sum of prefix lengths (each segment >= 0, may be all 0)
      kv_indices int32 (total_prefix) -- pool row ids of the prefix tokens, any
                 permutation is allowed; num_pool may exceed total_prefix, and the
                 unreferenced pool rows are garbage data that must not take part
                 in the computation
      returns out evaluation dtype (total_extend, num_q_heads, head_dim_v)

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - The evaluator casts every input tensor to fp32 before passing it to
        forward; the indptrs and pool row ids are small integers that fp32
        represents exactly, so .to(torch.int32) / .to(torch.long) at the entry
        recovers them losslessly.
      - The maximum extend length is not an input: the upper bound of the grid's
        third dimension can be derived inside forward from qo_indptr, or
        total_extend can be used directly as a conservative bound (inside the
        kernel, mask the out-of-range query rows with each sequence's
        cur_seq_len_extend).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: prefix+extend mixed, variable-length (ragged) batch, GQA,
    causal/non-causal, Q/K/V head-dimension relation as above; no custom mask,
    no sliding window, no attention sink, no KV dequantization scale, the logit
    cap is not enabled (always 0), and the prefix segment gets no separate
    prefill-kernel fusion path -- those variants are left for later standalone
    tasks.
    """
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)
        # <<<END_IMPROVE>>>

    def forward(self, q_extend, k_extend, v_extend, k_buffer, v_buffer, qo_indptr, kv_indptr, kv_indices):
        # <<<IMPROVE:forward_stmt_1>>>
        qo_indptr = qo_indptr.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        kv_indptr = kv_indptr.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        kv_indices = kv_indices.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        total_extend, H_Q, Dq = q_extend.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        H_KV = k_extend.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        Dv = v_extend.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        scale = self.sm_scale if self.sm_scale is not None else 1.0 / math.sqrt(Dq)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        B = qo_indptr.shape[0] - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Output storage is allocated by the native wrapper.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        out = _pyramidkernel_get_extension().extend_attention(
            q_extend.contiguous(),
            k_extend.contiguous(),
            v_extend.contiguous(),
            k_buffer.contiguous(),
            v_buffer.contiguous(),
            qo_indptr.contiguous(),
            kv_indptr.contiguous(),
            kv_indices.contiguous(),
            self.causal,
            float(scale),
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
