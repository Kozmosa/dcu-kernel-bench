import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_E2M1_TABLE = torch.tensor(
    [0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0,
     -0.0, -0.5, -1.0, -1.5, -2.0, -3.0, -4.0, -6.0],
    dtype=torch.float32,
)

def _dequant_mxfp4(codes, scales):
    """mxfp4 dequantization: (..., K//2) uint8 code words plus (..., K//32) uint8
    e8m0 block scales -> (..., K) float32. In every byte the low 4 bits are the
    even-index element and the high 4 bits the odd-index element;
    x[..., k] = e2m1(nibble) * 2^(scales[..., k // 32] - 127)."""
    lo = codes & 0xF
    hi = codes >> 4
    nib = torch.stack((lo, hi), dim=-1).flatten(-2)      # (..., K)
    x = _E2M1_TABLE.to(codes.device)[nib.long()]
    scale = torch.exp2(scales.to(torch.float32) - 127.0)
    return x * scale.repeat_interleave(32, dim=-1)

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3006_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor moe_mxfp4(torch::Tensor a, torch::Tensor as,
                       torch::Tensor b, torch::Tensor bs,
                       torch::Tensor weights, torch::Tensor ids);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_mxfp4", &moe_mxfp4);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <limits>
#include <algorithm>

__device__ __forceinline__ float decode_e8m0(uint8_t scale) {
    const uint32_t s = static_cast<uint32_t>(scale);
    const uint32_t bits = s == 0 ? 0x00400000u : (s << 23);
    return __uint_as_float(bits);
}

__device__ __forceinline__ float decode_mxfp4(uint8_t packed,
                                             uint8_t scale, int64_t k) {
    const unsigned nib = (packed >> ((k & 1) * 4)) & 15;
    const float table[8] = {0.f, .5f, 1.f, 1.5f, 2.f, 3.f, 4.f, 6.f};
    const float val = (nib & 8) ? -table[nib & 7] : table[nib & 7];
    return val * decode_e8m0(scale);
}

__global__ void moe_kernel(
    const uint8_t* __restrict__ a,
    const uint8_t* __restrict__ as,
    const uint8_t* __restrict__ b,
    const uint8_t* __restrict__ bs,
    const float* __restrict__ weights,
    const int64_t* __restrict__ ids,
    at::BFloat16* __restrict__ out,
    int64_t M, int64_t E, int64_t N, int64_t K,
    int64_t topk, int64_t tiles_n, int64_t tiles) {
    __shared__ float activation[256];

    const int64_t tid = static_cast<int64_t>(threadIdx.x);
    const int64_t row = tid / 16;
    const int64_t lane = tid % 16;
    const int64_t kh = K / 2;
    const int64_t ks = K / 32;

    for (int64_t tile = static_cast<int64_t>(blockIdx.x);
         tile < tiles;
         tile += static_cast<int64_t>(gridDim.x)) {
        const int64_t slot = tile / tiles_n;
        const int64_t m = slot / topk;
        const int64_t n = (tile % tiles_n) * 16 + row;
        const bool valid_slot = m < M;
        const int64_t expert = valid_slot ? ids[slot] : -1;
        const bool valid = valid_slot && expert >= 0 && expert < E && n < N;

        float sum = 0.f;
        for (int64_t chunk = 0; chunk < K; chunk += 256) {
            const int64_t ak = chunk + tid;
            float av = 0.f;
            if (valid_slot && ak < K) {
                av = decode_mxfp4(
                    a[m * kh + ak / 2],
                    as[m * ks + ak / 32],
                    ak);
            }
            activation[tid] = av;
            __syncthreads();

            if (valid) {
                const int64_t weight_row = expert * N + n;
                for (int64_t u = 0; u < 8; ++u) {
                    const int64_t local0 = lane + 32 * u;
                    const int64_t local1 = local0 + 16;
                    const int64_t k0 = chunk + local0;
                    const int64_t k1 = chunk + local1;

                    if (k0 < K) {
                        const float weight_scale =
                            decode_e8m0(bs[weight_row * ks + k0 / 32]);
                        const float bv0 = decode_mxfp4(
                            b[weight_row * kh + k0 / 2],
                            static_cast<uint8_t>(0),
                            k0) / decode_e8m0(0);
                        const unsigned nib0 =
                            (b[weight_row * kh + k0 / 2] >>
                             ((k0 & 1) * 4)) & 15;
                        const float table0[8] =
                            {0.f, .5f, 1.f, 1.5f, 2.f, 3.f, 4.f, 6.f};
                        const float magnitude0 = table0[nib0 & 7];
                        const float decoded0 =
                            (nib0 & 8) ? -magnitude0 : magnitude0;
                        sum = fmaf(activation[local0],
                                   decoded0 * weight_scale,
                                   sum);

                        if (k1 < K) {
                            const unsigned nib1 =
                                (b[weight_row * kh + k1 / 2] >>
                                 ((k1 & 1) * 4)) & 15;
                            const float table1[8] =
                                {0.f, .5f, 1.f, 1.5f, 2.f, 3.f, 4.f, 6.f};
                            const float magnitude1 = table1[nib1 & 7];
                            const float decoded1 =
                                (nib1 & 8) ? -magnitude1 : magnitude1;
                            sum = fmaf(activation[local1],
                                       decoded1 * weight_scale,
                                       sum);
                        }
                    }
                }
            }
            __syncthreads();
        }

        float reduced = sum;
        for (int offset = 8; offset > 0; offset /= 2) {
            const float other = __shfl_down(reduced, offset, 16);
            if (lane < offset) {
                reduced += other;
            }
        }

        if (lane == 0 && valid_slot && n < N) {
            out[slot * N + n] =
                at::BFloat16(reduced * weights[slot]);
        }
        __syncthreads();
    }
}

torch::Tensor moe_mxfp4(torch::Tensor a, torch::Tensor as,
                       torch::Tensor b, torch::Tensor bs,
                       torch::Tensor weights, torch::Tensor ids) {
    TORCH_CHECK(a.is_cuda(), "inputs must be GPU tensors");
    for (const auto& x : {as, b, bs, weights, ids}) {
        TORCH_CHECK(x.device() == a.device(), "all inputs must share a device");
    }
    TORCH_CHECK(a.dim() == 2 && as.dim() == 2 &&
                b.dim() == 3 && bs.dim() == 3 &&
                weights.dim() == 2 && ids.dim() == 2,
                "invalid input ranks");
    TORCH_CHECK(a.scalar_type() == at::kByte &&
                as.scalar_type() == at::kByte &&
                b.scalar_type() == at::kByte &&
                bs.scalar_type() == at::kByte,
                "codes and scales must be uint8");
    TORCH_CHECK(ids.scalar_type() == at::kLong &&
                weights.scalar_type() == at::kFloat,
                "ids must be int64 and routing weights float32");

    const int64_t M = a.size(0);
    TORCH_CHECK(a.size(1) <= std::numeric_limits<int64_t>::max() / 2,
                "K overflows int64");
    const int64_t K = a.size(1) * 2;
    const int64_t E = b.size(0);
    const int64_t N = b.size(1);
    const int64_t topk = ids.size(1);

    TORCH_CHECK(M >= 1 && E >= 1 && N >= 1 && K % 32 == 0 &&
                topk >= 1 && topk <= E,
                "invalid contract dimensions");
    TORCH_CHECK(as.size(0) == M && as.size(1) == K / 32 &&
                b.size(2) == K / 2 &&
                bs.size(0) == E && bs.size(1) == N &&
                bs.size(2) == K / 32 &&
                ids.size(0) == M &&
                weights.size(0) == M &&
                weights.size(1) == topk,
                "inconsistent input shapes");

    c10::cuda::CUDAGuard guard(a.device());
    a = a.contiguous();
    as = as.contiguous();
    b = b.contiguous();
    bs = bs.contiguous();
    weights = weights.contiguous();
    ids = ids.contiguous();

    auto out = torch::empty({M, topk, N},
                            a.options().dtype(at::kBFloat16));
    if (out.numel() == 0) {
        return out;
    }

    const int64_t tiles_n = N / 16 + (N % 16 != 0);
    const int64_t tiles = (out.numel() / N) * tiles_n;
    const unsigned blocks =
        static_cast<unsigned>(std::min<int64_t>(tiles, 65535));

    hipStream_t stream = at::cuda::getCurrentCUDAStream(a.get_device());
    hipLaunchKernelGGL(
        moe_kernel,
        dim3(blocks),
        dim3(256),
        0,
        stream,
        a.data_ptr<uint8_t>(),
        as.data_ptr<uint8_t>(),
        b.data_ptr<uint8_t>(),
        bs.data_ptr<uint8_t>(),
        weights.data_ptr<float>(),
        ids.data_ptr<int64_t>(),
        out.data_ptr<at::BFloat16>(),
        M, E, N, K, topk, tiles_n, tiles);

    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "moe_mxfp4 launch failed: ",
                hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    MoE (Mixture of Experts) grouped GEMM: mxfp4 quantized activations x
    mxfp4 quantized expert weights.

    Routing is already done (topk_ids gives the experts selected for each
    token); this operator runs one GEMM per (token, selected expert) slot and
    multiplies by the routing weight (mul_routed_weight is always True):
      c[m, j, n] = topk_weights[m, j] * sum_k adeq[m, k] * bdeq[topk_ids[m, j], n, k]
    The sum runs along the K dimension, intermediate accumulation is float32 and
    the result is cast to bfloat16 for output.

    mxfp4 dequantization definition (the same for activation a and weight b):
      - every byte of the last dimension of the code word tensor holds 2 e2m1
        codes: the low 4 bits are the even-index element and the high 4 bits the
        odd-index element, i.e. the low/high nibble of code[..., i] correspond
        to elements 2i / 2i+1.
      - e2m1 nibble (4 bit) decoding: bit3 is the sign, the low 3 bits index the
        table {0: 0.0, 1: 0.5, 2: 1.0, 3: 1.5, 4: 2.0, 5: 3.0, 6: 4.0, 7: 6.0};
        a set sign bit negates the value (-0.0 takes part in the multiply-add as
        0).
      - e8m0 block scale: every 32 elements of the last dimension share 1 uint8
        scale byte s = scales[..., k // 32], decoded as 2^(s - 127).
      - dequantization:
        x[..., k] = e2m1(nibble(..., k)) * 2^(scales[..., k // 32] - 127).

    Input/output specification:
      a_q          (M, K//2)     uint8   activation code words (K is the logical
                                         feature dimension)
      a_scales     (M, K//32)    uint8   activation e8m0 block scales
      b_q          (E, N, K//2)  uint8   expert weight code words (E experts)
      b_scales     (E, N, K//32) uint8   expert weight e8m0 block scales
      topk_weights (M, top_k)    float16/bfloat16/float32  routing weights (>0)
      topk_ids     (M, top_k)    int64   selected expert ids, values in [0, E)
      out          (M, top_k, N) bfloat16
      Constraints: M >= 1, E >= 1, N >= 1, K % 32 == 0, 1 <= top_k <= E.
      Boundary behaviour: one expert may be selected by several tokens, and one
      token may select the same expert in several of its slots; every (m, j)
      slot is computed independently, with no reduction or weighted merge across
      experts and no dispatch-merge semantics (that belongs to a downstream
      operator).

    Implementation constraints (violations are scored as failures):
      - Core computation (nibble unpacking, e2m1/e8m0 decoding, the GEMM grouped
        by topk_ids, the routing weight multiply) must be done inside the
        submitted file; calling torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / F.linear / functional.linear /
        torch._scaled_mm is forbidden, as is using the built-in torch
        float4/mxfp4 representations and ready-made quantization conversion APIs
        (torch.float4_e2m1fn_x2, torch.quantize_per_tensor, etc.).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast to
        bfloat16.
      - The evaluator casts all inputs to fp32 before calling forward (uint8
        code words and scale bytes (0..255), int64 expert ids (small integers)
        are all exactly representable in fp32), so they must be restored
        losslessly at the entry point (.to(torch.uint8) / .to(torch.long)).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: MoE grouped GEMM of mxfp4 activations x mxfp4 weights plus the
    routing weight multiply; the token-expert alignment scheduling metadata
    (sorted_token_ids / expert_ids / num_tokens_post_padded) is an
    implementation detail and not part of the input contract.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, a_q, a_scales, b_q, b_scales, topk_weights, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        a_q = a_q.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        a_scales = a_scales.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        b_q = b_q.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        b_scales = b_scales.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        topk_weights = topk_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        M, Kh = a_q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        K = Kh * 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        E, N, _ = b_q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        c = _pyramidkernel_get_extension().moe_mxfp4(
            a_q, a_scales, b_q, b_scales, topk_weights, topk_ids)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return c
        # <<<END_IMPROVE>>>
