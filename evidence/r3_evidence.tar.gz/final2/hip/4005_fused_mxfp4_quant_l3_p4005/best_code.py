import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

def _rmsnorm(x, weight, eps):
    # Official semantics: row-wise RMS normalization in float32, then multiply
    # by the weight
    row_norm = torch.sum(x * x, dim=-1)
    norm_factor = torch.rsqrt((row_norm / x.shape[1]) + eps).reshape(-1, 1)
    return x * norm_factor * weight.reshape(1, -1)

def _mxfp4_quant(x):
    # MXFP4 dynamic quantization (block size 32, even rounding). See the Model
    # docstring for the bit-exact semantics: the bit-level algorithm matches the
    # reference implementation; the input is a float32 (M, N) matrix.
    MXFP4_QUANT_BLOCK_SIZE = 32
    x_shape = x.shape
    if x.shape[-1] % MXFP4_QUANT_BLOCK_SIZE != 0:
        shape = list(x_shape)
        shape = shape[:-1] + [
            ((shape[-1] - 1 + MXFP4_QUANT_BLOCK_SIZE) // MXFP4_QUANT_BLOCK_SIZE)
            * MXFP4_QUANT_BLOCK_SIZE
        ]
        shape = tuple(shape)
        x_padded = torch.zeros(shape, dtype=x.dtype, device=x.device)
        x_padded[..., : x.shape[-1]] = x
    else:
        x_padded = x

    # Block scale: round amax up to a power of two, then take floor(log2) - 2
    x_padded = x_padded.reshape(
        -1, x_padded.shape[-1] // MXFP4_QUANT_BLOCK_SIZE, MXFP4_QUANT_BLOCK_SIZE
    ).to(torch.float32)
    amax, _ = torch.max(torch.abs(x_padded), dim=-1)
    amax = amax.view(torch.int32)
    amax = (amax + 0x200000) & 0xFF800000
    amax = amax.view(torch.float32)
    scale_e8m0_unbiased = torch.log2(amax).floor() - 2
    scale_e8m0_unbiased = torch.clamp(scale_e8m0_unbiased, min=-127, max=127)
    quant_scale = torch.exp2(-scale_e8m0_unbiased)

    # Quantized values
    qx = x_padded * quant_scale.unsqueeze(-1)

    # blockscale_e8m0
    bs_e8m0 = scale_e8m0_unbiased.to(torch.uint8) + 127

    # e2m1 rounding: round-half-up, saturating past the range (take min(x, 7) of
    # ((E<<2 | M>>21) + 1) >> 1)
    qx = qx.view(torch.int32)
    s = qx & 0x80000000
    e = (qx >> 23) & 0xFF
    m = qx & 0x7FFFFF

    E8_BIAS = 127
    E2_BIAS = 1
    adjusted_exponents = E8_BIAS - e - 1
    m = torch.where(e < E8_BIAS, (0x400000 | (m >> 1)) >> adjusted_exponents, m)
    e = torch.where(e > E8_BIAS - E2_BIAS, e, E8_BIAS - E2_BIAS) - (E8_BIAS - E2_BIAS)

    combined_val = (((e << 2) | (m >> 21)) + 1) >> 1
    e2m1_tmp = torch.where(combined_val < 0x7, combined_val, 0x7)
    e2m1_value = (((s >> 28) & 0xF) | e2m1_tmp).to(torch.uint8)

    # Pack 2 4-bit code words per byte: even indices occupy the low 4 bits
    x_mxfp4 = e2m1_value[..., ::2] | (e2m1_value[..., 1::2] << 4)
    x_mxfp4 = torch.flatten(x_mxfp4, -2, -1)

    # Drop the extra bytes produced by the zero padding
    if x.shape[-1] % MXFP4_QUANT_BLOCK_SIZE != 0:
        x_mxfp4 = x_mxfp4[..., : x.shape[-1] // 2]

    mxfp4_shape = list(x_shape)
    mxfp4_shape = tuple(mxfp4_shape[:-1] + [mxfp4_shape[-1] // 2])
    x_mxfp4 = x_mxfp4.reshape(mxfp4_shape)
    return x_mxfp4, bs_e8m0

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4005_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor fused_mxfp4(torch::Tensor inp1, torch::Tensor weight1,
                          torch::Tensor res1, double eps);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_mxfp4", &fused_mxfp4);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <cstdint>

static __device__ __forceinline__ uint32_t float_bits(float x) {
    union {
        float f;
        uint32_t u;
    } v;
    v.f = x;
    return v.u;
}

static __device__ __forceinline__ uint8_t encode_e2m1(uint32_t bits) {
    uint32_t sign = (bits >> 28) & 0x8u;
    uint32_t exponent = (bits >> 23) & 0xffu;
    uint32_t mantissa = bits & 0x7fffffu;
    uint32_t adjusted_mantissa = mantissa;

    if (exponent < 127u) {
        int shift = 126 - static_cast<int>(exponent);
        uint32_t t = 0x400000u | (mantissa >> 1);
        adjusted_mantissa = (shift >= 32) ? 0u : (t >> shift);
    }

    uint32_t e2 = exponent > 126u ? exponent - 126u : 0u;
    uint32_t combined =
        (((e2 << 2) | (adjusted_mantissa >> 21)) + 1u) >> 1;
    if (combined > 7u) {
        combined = 7u;
    }
    return static_cast<uint8_t>(sign | combined);
}

__global__ void fused_mxfp4_kernel(
    const float* __restrict__ inp,
    const float* __restrict__ weight,
    const float* __restrict__ residual,
    uint8_t* __restrict__ out,
    int64_t rows,
    int64_t n,
    int64_t packed_cols,
    int64_t block_count,
    float eps) {
    const int64_t row = static_cast<int64_t>(blockIdx.x);
    if (row >= rows) {
        return;
    }

    const int tid = static_cast<int>(threadIdx.x);

    __shared__ float reduction[256];
    __shared__ float inv_rms;
    __shared__ float values[128];
    __shared__ uint8_t codes[128];

    float partial = 0.0f;
    for (int64_t col = static_cast<int64_t>(tid); col < n; col += 256) {
        const int64_t offset = row * n + col;
        const float s = inp[offset] + residual[offset];
        partial += s * s;
    }

    reduction[tid] = partial;
    __syncthreads();

    for (int stride = 128; stride > 0; stride >>= 1) {
        if (tid < stride) {
            reduction[tid] += reduction[tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0) {
        inv_rms = rsqrtf(reduction[0] / static_cast<float>(n) + eps);
    }
    __syncthreads();

    const int wave = tid >> 6;
    const int lane = tid & 63;
    const int64_t iterations = (block_count + 3) / 4;
    const int64_t row_base = row * (packed_cols + block_count);

    for (int64_t iteration = 0; iteration < iterations; ++iteration) {
        const int64_t block = iteration * 4 + static_cast<int64_t>(wave);
        const int64_t start = block * 32;
        const bool valid_block = block < block_count;

        if (lane < 32) {
            const int64_t col = start + static_cast<int64_t>(lane);
            float value = 0.0f;
            if (valid_block && col < n) {
                const int64_t offset = row * n + col;
                const float s = inp[offset] + residual[offset];
                value = (s * inv_rms) * weight[col];
            }
            values[wave * 32 + lane] = value;
        }
        __syncthreads();

        if (lane == 0 && valid_block) {
            float amax = 0.0f;
            for (int k = 0; k < 32; ++k) {
                const float value = values[wave * 32 + k];
                const float absolute_value = value < 0.0f ? -value : value;
                if (absolute_value > amax) {
                    amax = absolute_value;
                }
            }

            const uint32_t amax_bits = float_bits(amax);
            const uint32_t rounded_bits =
                (amax_bits + 0x00200000u) & 0xff800000u;

            int exponent;
            if (rounded_bits == 0u) {
                exponent = -127;
            } else {
                exponent = static_cast<int>((rounded_bits >> 23) & 0xffu) - 127 - 2;
                if (exponent < -127) {
                    exponent = -127;
                } else if (exponent > 127) {
                    exponent = 127;
                }
            }

            out[row_base + packed_cols + block] =
                static_cast<uint8_t>(exponent + 127);

            const float scale = exp2f(-static_cast<float>(exponent));
            for (int k = 0; k < 32; ++k) {
                const float scaled = values[wave * 32 + k] * scale;
                codes[wave * 32 + k] = encode_e2m1(float_bits(scaled));
            }
        }
        __syncthreads();

        if (lane < 16 && valid_block) {
            const int index = wave * 32 + lane * 2;
            const uint8_t low = codes[index];
            const uint8_t high = codes[index + 1];
            out[row_base + block * 16 + static_cast<int64_t>(lane)] =
                static_cast<uint8_t>((low & 0x0fu) | ((high & 0x0fu) << 4));
        }
        __syncthreads();
    }
}

torch::Tensor fused_mxfp4(torch::Tensor inp1, torch::Tensor weight1,
                          torch::Tensor res1, double eps) {
    TORCH_CHECK(inp1.is_cuda(), "inp1 must be a HIP tensor");
    TORCH_CHECK(weight1.is_cuda(), "weight1 must be a HIP tensor");
    TORCH_CHECK(res1.is_cuda(), "res1 must be a HIP tensor");
    TORCH_CHECK(inp1.scalar_type() == torch::kFloat32, "inp1 must be float32");
    TORCH_CHECK(weight1.scalar_type() == torch::kFloat32, "weight1 must be float32");
    TORCH_CHECK(res1.scalar_type() == torch::kFloat32, "res1 must be float32");
    TORCH_CHECK(inp1.dim() == 2 && res1.dim() == 2 && weight1.dim() == 1,
                "invalid tensor dimensions");
    TORCH_CHECK(inp1.sizes() == res1.sizes(), "inp1 and res1 shapes must match");
    TORCH_CHECK(weight1.size(0) == inp1.size(1), "weight shape mismatch");
    TORCH_CHECK(inp1.size(1) >= 2 && (inp1.size(1) % 2) == 0,
                "last dimension must be even and at least 2");

    auto a = inp1.contiguous();
    auto w = weight1.contiguous();
    auto r = res1.contiguous();

    const int64_t rows = a.size(0);
    const int64_t n = a.size(1);
    const int64_t packed_cols = n / 2;
    const int64_t block_count = (n + 31) / 32;

    TORCH_CHECK(rows <= static_cast<int64_t>(0x7fffffff),
                "row count exceeds launch dimension");

    auto out = torch::empty(
        {rows, packed_cols + block_count},
        torch::TensorOptions().device(a.device()).dtype(torch::kUInt8));

    dim3 grid(static_cast<unsigned int>(rows), 1, 1);
    dim3 block(256, 1, 1);

    fused_mxfp4_kernel<<<grid, block>>>(
        a.data_ptr<float>(),
        w.data_ptr<float>(),
        r.data_ptr<float>(),
        out.data_ptr<uint8_t>(),
        rows,
        n,
        packed_cols,
        block_count,
        static_cast<float>(eps));

    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "fused_mxfp4 kernel launch failed: ",
                hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Fused residual add + RMSNorm + MXFP4 dynamic quantization (mxfp4 GEMM
    preprocessing).

    Mathematical definition (all intermediates in float32; inputs are randn in
    the bfloat16/float16 value range):
      1. s = inp1 + res1                                     element-wise add
      2. norm[m, j] = s[m, j] * rsqrt( (1/N1) * sum_j s[m, j]^2 + eps ) * weight1[j]
         eps = 1e-6, normalized along the last dimension
      3. MXFP4 dynamic quantization of every row of norm in 32-element blocks
         (definition below), yielding packed e2m1 code words (2 per byte) and
         e8m0 block scale bytes.

    MXFP4 quantization (block size fixed at 32 along the last dimension; a
    trailing block shorter than 32 zero padded and taking part):
      a. amax = max |x| (inside the block, padding included)
      b. round amax up to a power of two: interpret the IEEE754 bit pattern of
         amax as int32, add 0x200000, bitwise-AND with 0xFF800000, then
         reinterpret as float32 (unchanged when amax is already a power of two,
         otherwise it goes up to the next power of two)
      c. e = clamp( floor(log2(rounded amax)) - 2, -127, 127 )
      d. scale byte = e + 127 (uint8 e8m0 encoding)
      e. q = x * 2^(-e), rounded to the e2m1 code table
         {0, +-0.5, +-1, +-1.5, +-2, +-3, +-4, +-6}: round-half-up (0.5 rounds
         up), saturating to +-6 beyond the range; the equivalent bit-level form
         is ((E<<2 | M>>21) + 1) >> 1 on the fp32 bit pattern, then min(x, 7),
         with bit31 as the sign bit
      f. packing: the 2i-th and the (2i+1)-th code words share one byte, the
         even index occupying the low 4 bits

    Input/output specification:
      inp1    (M, N1)  bfloat16/float16  main input
      weight1 (N1,)    same as inp1      RMSNorm weight
      res1    (M, N1)  same as inp1      residual
      out     (M, N1//2 + ceil(N1/32)) uint8, single-tensor output contract:
              out[:, :N1//2]        packed e2m1 code words (2 per byte, even
                                    indices in the low 4 bits)
              out[:, N1//2:]        e8m0 block scale bytes (ceil(N1/32) per row)
      Constraints: M >= 1; N1 is even and N1 >= 2.
      Boundary behaviour: an all-zero block has amax=0, handled as
      log2(0)=-inf, so after the clamp e=-127, the scale byte is 0 and the code
      words are 0.

    Implementation constraints (violations are scored as failures):
      - The core computation of RMSNorm and quantization (amax/scale
        computation, e2m1 rounding, packing) must be completed inside the
        submitted file; calling torch.nn.functional.rms_norm /
        torch.nn.RMSNorm is forbidden, as is using torch built-in float4/mxfp4
        quantization or conversion APIs (including torch.float4_e2m1fn_x2,
        torch.quantize_per_tensor and other ready-made quantization
        operators), and wrapping or modifying any third-party operator
        library's existing implementation.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate computation uses float32; the output is uint8, and both
        the code words and the scale bytes must be bit-exact against the
        reference implementation (exact match, no tolerance).
      - The evaluator casts every input to fp32 before calling forward
        (bfloat16/float16 values are exact in fp32); just compute with those
        values directly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-path residual + RMSNorm + MXFP4 dynamic quantization
    (block size 32, even rounding), without the downstream GEMM main
    computation.
    """
    def __init__(self, dtype: str = "bfloat16", eps: float = 1e-6):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.dtype = getattr(torch, dtype)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, inp1, weight1, res1):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().fused_mxfp4(inp1, weight1, res1, self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # RMSNorm is fused into the extension call above.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # MXFP4 quantization is fused into the extension call above.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return out
        # <<<END_IMPROVE>>>
