import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p5009_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor fused_dts(torch::Tensor x, torch::Tensor weight,
                        torch::Tensor bias, int64_t bs, bool dcr);
torch::Tensor rearrange_dts(torch::Tensor x, int64_t bs, bool dcr);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_dts", &fused_dts);
    m.def("rearrange_dts", &rearrange_dts);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cstdint>
#include <limits>

template<typename T, int BS, bool DCR>
__global__ void rearrange_kernel(
    const T* __restrict__ x, T* __restrict__ out,
    int64_t count, int64_t C, int64_t H, int64_t W) {
    const int64_t OH = H * BS;
    const int64_t OW = W * BS;
    const int64_t K = C * BS * BS;
    const int64_t step = int64_t(blockDim.x) * gridDim.x;
    for (int64_t idx = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         idx < count; idx += step) {
        int64_t v = idx;
        const int64_t ow = v % OW;
        v /= OW;
        const int64_t oh = v % OH;
        v /= OH;
        const int64_t c = v % C;
        const int64_t n = v / C;
        const int64_t rem = (oh % BS) * BS + ow % BS;
        const int64_t k = DCR ? rem * C + c : c * BS * BS + rem;
        const int64_t src = ((n * K + k) * H + oh / BS) * W + ow / BS;
        if (src >= 0 && src < count) {
            out[idx] = static_cast<T>(static_cast<float>(x[src]));
        }
    }
}

template<typename T, int BS, bool DCR>
__global__ __launch_bounds__(256) void fused_kernel(
    const T* __restrict__ x, const T* __restrict__ weight,
    const T* __restrict__ bias, T* __restrict__ out,
    int64_t N, int64_t CI, int64_t K, int64_t H, int64_t W,
    int64_t spatial_tiles, int64_t channel_tiles, int64_t tile_count) {
    constexpr int RT = 36;
    __shared__ float sw[RT][32];
    __shared__ float sx[RT][64];
    const int64_t tid = threadIdx.x;
    const int64_t cb = tid / 16;
    const int64_t pb = tid % 16;
    const int64_t P = H * W;
    const int64_t R = CI * 9;
    const int64_t C = K / (BS * BS);
    const int64_t OH = H * BS;
    const int64_t OW = W * BS;

    for (int64_t tile = blockIdx.x; tile < tile_count; tile += gridDim.x) {
        const int64_t pt = tile % spatial_tiles;
        const int64_t kt = (tile / spatial_tiles) % channel_tiles;
        const int64_t n = tile / (spatial_tiles * channel_tiles);
        const int64_t p0 = pt * 64;
        const int64_t k0 = kt * 32;
        const int64_t load_col = tid % 64;
        const int64_t load_row_start = tid / 64;
        const int64_t load_p = p0 + load_col;
        const int64_t load_h = load_p / W;
        const int64_t load_w = load_p % W;
        const bool spatial_valid = n < N && load_p < P;
        float acc[2][4] = {};
        for (int64_t q0 = 0; q0 < R; q0 += RT) {
            for (int64_t s = tid; s < 32 * RT; s += 256) {
                const int64_t k = k0 + s / RT;
                const int64_t q = q0 + s % RT;
                float a = 0.0f;
                if (k < K && q < R)
                    a = static_cast<float>(weight[k * R + q]);
                sw[s % RT][s / RT] = a;
            }
            for (int64_t row = load_row_start; row < RT; row += 4) {
                const int64_t q = q0 + row;
                const int64_t ci = q / 9;
                const int64_t tap = q % 9;
                const int64_t ih = load_h + tap / 3 - 1;
                const int64_t iw = load_w + tap % 3 - 1;
                float a = 0.0f;
                if (spatial_valid && q < R && ci < CI &&
                    ih >= 0 && ih < H && iw >= 0 && iw < W) {
                    a = static_cast<float>(x[((n * CI + ci) * H + ih) * W + iw]);
                }
                sx[row][load_col] = a;
            }
            __syncthreads();
            #pragma unroll
            for (int q = 0; q < RT; ++q) {
                const float w0 = sw[q][cb];
                const float w1 = sw[q][cb + 16];
                #pragma unroll
                for (int j = 0; j < 4; ++j) {
                    const float a = sx[q][pb + 16 * j];
                    acc[0][j] = fmaf(w0, a, acc[0][j]);
                    acc[1][j] = fmaf(w1, a, acc[1][j]);
                }
            }
            __syncthreads();
        }
        #pragma unroll
        for (int i = 0; i < 2; ++i) {
            const int64_t k = k0 + cb + 16 * i;
            if (n < N && k < K) {
                const float b = static_cast<float>(bias[k]);
                const int64_t c = DCR ? k % C : k / (BS * BS);
                const int64_t rem = DCR ? k / C : k % (BS * BS);
                #pragma unroll
                for (int j = 0; j < 4; ++j) {
                    const int64_t p = p0 + pb + 16 * j;
                    if (p < P) {
                        const int64_t oh = (p / W) * BS + rem / BS;
                        const int64_t ow = (p % W) * BS + rem % BS;
                        const int64_t dst = ((n * C + c) * OH + oh) * OW + ow;
                        out[dst] = static_cast<T>(acc[i][j] + b);
                    }
                }
            }
        }
    }
}

static void validate_x(const torch::Tensor& x, int64_t bs) {
    TORCH_CHECK(x.is_cuda(), "x must be on a HIP device");
    TORCH_CHECK(x.dim() == 4 && x.is_contiguous(), "x must be contiguous NCHW");
    TORCH_CHECK(x.scalar_type() == at::kFloat ||
                x.scalar_type() == at::kHalf ||
                x.scalar_type() == at::kBFloat16, "unsupported x dtype");
    TORCH_CHECK(bs == 2 || bs == 3 || bs == 4, "invalid block size");
    for (int d = 0; d < 4; ++d)
        TORCH_CHECK(x.size(d) > 0, "dimensions must be positive");
}

static torch::Tensor make_output(const torch::Tensor& x, int64_t K, int64_t bs) {
    TORCH_CHECK(K > 0 && K % (bs * bs) == 0, "invalid output channels");
    const int64_t limit = std::numeric_limits<int64_t>::max();
    TORCH_CHECK(x.size(2) <= limit / bs && x.size(3) <= limit / bs,
                "spatial dimensions overflow");
    int64_t elements = x.size(0);
    for (int64_t v : {K, x.size(2), x.size(3)}) {
        TORCH_CHECK(elements <= limit / v, "output size overflow");
        elements *= v;
    }
    return torch::empty({x.size(0), K / (bs * bs),
                         x.size(2) * bs, x.size(3) * bs}, x.options());
}

template<typename T, int BS, bool DCR>
static void launch_rearrange(const torch::Tensor& x, torch::Tensor& out,
                             hipStream_t stream) {
    const int64_t count = out.numel();
    const unsigned blocks = static_cast<unsigned>(
        std::min<int64_t>((count - 1) / 256 + 1, 65535));
    rearrange_kernel<T, BS, DCR><<<blocks, 256, 0, stream>>>(
        x.data_ptr<T>(), out.data_ptr<T>(), count, out.size(1), x.size(2), x.size(3));
    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "rearrange launch failed: ", hipGetErrorString(err));
}

template<typename T, int BS, bool DCR>
static void launch_fused(const torch::Tensor& x, const torch::Tensor& weight,
                         const torch::Tensor& bias, torch::Tensor& out,
                         hipStream_t stream) {
    const int64_t P = x.size(2) * x.size(3);
    const int64_t st = (P - 1) / 64 + 1;
    const int64_t ct = (weight.size(0) - 1) / 32 + 1;
    const int64_t tiles = x.size(0) * ct * st;
    const unsigned blocks = static_cast<unsigned>(std::min<int64_t>(tiles, 65535));
    fused_kernel<T, BS, DCR><<<blocks, 256, 0, stream>>>(
        x.data_ptr<T>(), weight.data_ptr<T>(), bias.data_ptr<T>(), out.data_ptr<T>(),
        x.size(0), x.size(1), weight.size(0), x.size(2), x.size(3), st, ct, tiles);
    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "fused launch failed: ", hipGetErrorString(err));
}

#define SELECT_DTS(LAUNCH, ...) \
    do { \
        if (bs == 2) { \
            if (dcr) LAUNCH<scalar_t, 2, true>(__VA_ARGS__); \
            else LAUNCH<scalar_t, 2, false>(__VA_ARGS__); \
        } else if (bs == 3) { \
            if (dcr) LAUNCH<scalar_t, 3, true>(__VA_ARGS__); \
            else LAUNCH<scalar_t, 3, false>(__VA_ARGS__); \
        } else { \
            if (dcr) LAUNCH<scalar_t, 4, true>(__VA_ARGS__); \
            else LAUNCH<scalar_t, 4, false>(__VA_ARGS__); \
        } \
    } while (false)

torch::Tensor rearrange_dts(torch::Tensor x, int64_t bs, bool dcr) {
    validate_x(x, bs);
    const c10::cuda::CUDAGuard guard(x.device());
    auto out = make_output(x, x.size(1), bs);
    hipStream_t stream = at::cuda::getCurrentCUDAStream(x.get_device());
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  x.scalar_type(), "rearrange_dts", [&] {
        SELECT_DTS(launch_rearrange, x, out, stream);
    });
    return out;
}

torch::Tensor fused_dts(torch::Tensor x, torch::Tensor weight,
                        torch::Tensor bias, int64_t bs, bool dcr) {
    validate_x(x, bs);
    TORCH_CHECK(weight.device() == x.device() && bias.device() == x.device(),
                "all operands must have the same device");
    TORCH_CHECK(weight.scalar_type() == x.scalar_type() &&
                bias.scalar_type() == x.scalar_type(), "operand dtype mismatch");
    TORCH_CHECK(weight.dim() == 4 && weight.is_contiguous() &&
                weight.size(0) > 0 && weight.size(1) == x.size(1) &&
                weight.size(2) == 3 && weight.size(3) == 3,
                "weight must be contiguous (K,C_in,3,3)");
    TORCH_CHECK(bias.dim() == 4 && bias.is_contiguous() &&
                bias.size(0) == 1 && bias.size(1) == weight.size(0) &&
                bias.size(2) == 1 && bias.size(3) == 1,
                "bias must be contiguous (1,K,1,1)");
    const c10::cuda::CUDAGuard guard(x.device());
    auto out = make_output(x, weight.size(0), bs);
    hipStream_t stream = at::cuda::getCurrentCUDAStream(x.get_device());
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  x.scalar_type(), "fused_dts", [&] {
        SELECT_DTS(launch_fused, x, weight, bias, out, stream);
    });
    return out;
}
#undef SELECT_DTS
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Conv+Bias+DepthToSpace fusion (conv_bias_dts) and pure DepthToSpace
    pixel rearrangement (dts) forward family.

    DepthToSpace (D2S) rearranges the channel dimension of an (N, K, H, W)
    feature map into the spatial dimensions: K must be divisible by
    block_size^2; writing C = K // block_size^2, the output is
    (N, C, H*bs, W*bs) (bs = block_size). The rearrangement mode is selected
    between two by the __init__ parameter mode, defined in terms of a
    six-dimensional view + transpose + reshape of v = (N, K, H, W):
        "CRD": v.reshape(N, C, bs, bs, H, W).permute(0, 1, 4, 2, 5, 3)
                .reshape(N, C, H*bs, W*bs)
                (bit-for-bit equivalent to
                torch.nn.functional.pixel_shuffle(v, bs) -- that ATen primitive
                is on the forbidden list; the equivalence is only noted here and
                it must not be called directly)
        "DCR": v.reshape(N, bs, bs, C, H, W).permute(0, 3, 4, 1, 5, 2)
                .reshape(N, C, H*bs, W*bs)
    Both modes produce the same output shape; only the channel-to-spatial-block
    mapping differs. Element-wise formula:
        out[b, c, h*bs + r, w*bs + d] = v[b, idx(c, r, d), h, w]
        CRD: idx = c*bs^2 + r*bs + d; DCR: idx = (r*bs + d)*C + c
        (c in [0, C), r/d in [0, bs), h in [0, H), w in [0, W))

    The fused path is selected between two by the __init__ parameter variant:
        "conv_bias_dts": for x (N, C_in, H, W) and the kernel weight
            (K, C_in, 3, 3), run the 2D cross-correlation forward pass (the
            deep-learning-library conv_fprop convention, not the kernel-flipped
            mathematical convolution), add the per-channel bias bias
            (1, K, 1, 1) (broadcast along the batch and spatial dimensions),
            then apply the D2S above to the convolution result. The convolution
            hyper-parameters are fixed: stride=(1, 1), symmetric zero
            padding=(1, 1) (1 added on each of the top/bottom/left/right sides;
            the padding value is always zero), dilation=(1, 1), so the
            convolution output keeps the spatial size (H, W) and the final
            output is (N, K//bs^2, H*bs, W*bs). forward(x, weight, bias) uses all
            three parameters.
        "dts": pure data rearrangement without convolution (super-resolution /
            pixel-rearrangement scenario): x itself is the (N, K, H, W) feature
            map to rearrange, forward(x) is called with a single parameter, and
            weight/bias are not passed (the optional parameters default to None;
            even if they are passed they must not affect the output); the
            rearrangement is pure index movement and bit-for-bit lossless.
    The convolution dot-product accumulation and the bias addition are computed
    in float32 intermediate precision throughout (the dts branch likewise
    promotes to float32 losslessly before the rearrangement), and the output is
    cast back to the dtype of x exactly once.

    Input/output specification:
        x      float16 / bfloat16 / float32 4D contiguous;
               (N, C_in, H, W) with C_in >= 1 for
               variant="conv_bias_dts", (N, K, H, W) with K % bs^2 == 0 for
               variant="dts"
        weight same dtype as x (K, C_in, 3, 3), contiguous (conv_bias_dts only)
        bias   same dtype as x (1, K, 1, 1), contiguous (conv_bias_dts only)
        out    a single tensor, same dtype as x (N, K//bs^2, H*bs, W*bs) (both
               the convolution and D2S are inherently single-output, so there
               are no multi-output packing segments)
        N/K/H/W >= 1 (non-powers-of-two, primes and boundary values are
        allowed, including N=1 and H=W=1); K % block_size^2 == 0; block_size in
        {2, 3, 4}; mode in {"CRD", "DCR"};
        inputs are ordinary randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before the call (fp16/bf16 -> fp32 is lossless; the
        output dtype of this task always matches the dtype of the passed x).

    Implementation constraints (violations are scored as failures):
        - The core computation (the padding-aware index/mask expansion and the
          dot-product accumulation, the bias addition, the six-dimensional
          rearrangement index mapping) must all be done and fused with a HIP
          kernel inside the submitted file; it is forbidden to replace it with
          any form of library convolution, ATen GEMM
          (matmul/mm/bmm/addmm/baddbmm/einsum/tensordot/unfold/fold/linear
          etc.), pixel_shuffle-family primitives (including a pixel_unshuffle
          round trip), or one-step equivalent routes such as a conv3d depth-axis
          unsqueeze or a conv_transpose2d kernel-flip rewrite.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The convolution dot-product accumulation and the bias addition are
          computed in float32 and the output is cast back to the input dtype
          exactly once (do not accumulate in fp16/bf16 low precision, and do not
          make repeated round-trip casts); padding must be handled inside the
          kernel with boundary masks/indices -- do not materialize a padded copy
          on the host side in place of in-kernel handling.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.nn.Conv2d / torch.nn.functional.conv2d / F.conv2d /
    torch.conv2d / aten.conv2d / aten.convolution /
    torch.nn.functional.conv3d / torch.conv3d / torch.nn.Conv3d /
    torch.nn.functional.conv_transpose2d / torch.conv_transpose2d /
    torch.nn.ConvTranspose2d /
    torch.nn.functional.unfold / torch.nn.Unfold / .unfold( /
    torch.nn.functional.fold / torch.nn.Fold / .fold( /
    torch.nn.functional.pixel_shuffle / torch.pixel_shuffle / pixel_shuffle /
    torch.nn.PixelShuffle / PixelShuffle /
    torch.nn.functional.pixel_unshuffle / torch.pixel_unshuffle /
    pixel_unshuffle / torch.nn.PixelUnshuffle / PixelUnshuffle /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear /
    miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)
    def __init__(self, variant: str = "conv_bias_dts", mode: str = "CRD", block_size: int = 2):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("conv_bias_dts", "dts"), \
            "variant must be either conv_bias_dts or dts"
        assert mode in ("CRD", "DCR"), "mode must be either CRD or DCR"
        assert block_size in (2, 3, 4), "block_size must be 2 / 3 / 4"
        self.variant = variant
        self.mode = mode
        self.block_size = block_size
        # <<<END_IMPROVE>>>

    def forward(self, x, weight=None, bias=None):
        # <<<IMPROVE:forward_stmt_1>>>
        ext = _pyramidkernel_get_extension()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        if self.variant == "conv_bias_dts":
            return ext.fused_dts(x, weight, bias, self.block_size, self.mode == "DCR")
        else:
            return ext.rearrange_dts(x, self.block_size, self.mode == "DCR")
        # <<<END_IMPROVE>>>

    def _depth_to_space(self, v):
        """Six-dimensional view + transpose + reshape: a pure index
        rearrangement (no numeric operations) matching mode/block_size one to
        one; the per-dimension permutation corresponds exactly to the fused
        graph's first reshape -> transpose -> second reshape."""
        bs = self.block_size
        n, k, h, w = v.shape
        c = k // (bs * bs)
        if self.mode == "CRD":
            t = v.reshape(n, c, bs, bs, h, w).permute(0, 1, 4, 2, 5, 3)
        else:   # DCR
            t = v.reshape(n, bs, bs, c, h, w).permute(0, 3, 4, 1, 5, 2)
        return t.reshape(n, c, h * bs, w * bs)
