import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4009_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    8-bit quantized GEMM: int8 / fp8 activations x same-dtype weights, with an
    outer-product scale applied for dequantization.

    Mathematical definition: given the quantized activation x (M, K), the quantized
    weight w (N, K) (row-major with output channels as rows, i.e. transposed-GEMM
    semantics), the per-token scale x_scale (M, 1) float32, the per-channel scale
    w_scale (1, N) float32, and an optional bias (1, N) float32:
      acc[m, n] = sum_k x[m, k] * w[n, k]                (float32 accumulation)
      out[m, n] = acc[m, n] * x_scale[m, 0] * w_scale[0, n]  (outer-product dequantization)
      out[m, n] = out[m, n] + bias[0, n]                 (when use_bias=True, the
                                                     dequantized result is added in float32)
    Finally the result is cast to out_dtype. The numeric value is determined jointly
    by the quantization code words and the scales: a dequantized element equals the
    code word times the corresponding position of the outer product of x_scale and
    w_scale.

    Input/output specification:
      x        in_dtype   (M, K)  row-major activation code words; in_dtype in
                          {int8, fp8e4m3, fp8e5m2} (e4m3 = 4-bit exponent, 3-bit
                          mantissa; e5m2 = 5-bit exponent, 2-bit mantissa), set by
                          __init__'s in_dtype
      w        in_dtype   (N, K)  row-major weight code words (output channels as rows)
      x_scale  float32    (M, 1)  per-token scale
      w_scale  float32    (1, N)  per-channel scale
      bias     float32    (1, N)  a placeholder tensor when use_bias=False, ignored
      out      out_dtype  (M, N)  out_dtype in {bfloat16, float16}; M/N/K >= 1,
                          non-powers-of-two allowed and K may not divide the tile
                          (the tail is zero-padded by masking)

    Implementation constraints (violations are scored as failures):
      - The core computation (the 8-bit GEMM accumulation and the dequantization)
        must be completed inside the submitted file; calling torch.matmul /
        torch.bmm / torch.mm / torch.addmm / torch.einsum / torch._int_mm /
        torch._scaled_mm / F.linear / functional.linear is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; dequantization and the bias add are
        completed in the float32 domain before casting to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward: int8 / fp8
        code words and the scales are all exactly representable in fp32, so
        .to(in_dtype) at the entry point recovers the quantization code words
        losslessly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: 2D GEMM (no batch dimension), x row-major (M,K) / w row-major
    (N,K), scalar (per-token x per-channel) scales; excluding 128x128 blocked
    scales, a batch dimension, and output-buffer preallocation variants.
    """
    def __init__(self, in_dtype="fp8e4m3", out_dtype="bfloat16", use_bias=True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        quant = {"fp8e4m3": torch.float8_e4m3fn,
                 "fp8e5m2": torch.float8_e5m2,
                 "int8": torch.int8}
        out = {"bfloat16": torch.bfloat16, "float16": torch.float16}
        self.in_dtype = quant[in_dtype]
        self.out_dtype = out[out_dtype]
        self.use_bias = bool(use_bias)
        # <<<END_IMPROVE>>>

    def forward(self, x, w, x_scale, w_scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        x = x.to(self.in_dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        w = w.to(self.in_dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        x_scale = x_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        w_scale = w_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        N = w.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert K == w.shape[1], "x and w must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        acc = torch.matmul(x.to(torch.float32), w.to(torch.float32).t())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        out = acc * torch.matmul(x_scale, w_scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        if self.use_bias:
            out = out.to(torch.float32) + bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return out.to(self.out_dtype)
        # <<<END_IMPROVE>>>
