import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

at::Tensor add_swiglu(const at::Tensor& base,
                     const at::Tensor& delta,
                     const at::Tensor& grad_out);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("add_swiglu", &add_swiglu);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <algorithm>
#include <cstdint>
#include <limits>

template <typename scalar_t>
__global__ void add_swiglu_kernel(
    const scalar_t* __restrict__ base,
    const scalar_t* __restrict__ delta,
    const scalar_t* __restrict__ grad_out,
    scalar_t* __restrict__ fused,
    int64_t rows, int64_t width, int64_t D)
{
    const int64_t count = rows * D;
    const int64_t stride = static_cast<int64_t>(blockDim.x) * gridDim.x;
    for (int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x
                     + threadIdx.x;
         i < count; i += stride) {
        const int64_t row = i / D;
        const int64_t col = i - row * D;
        // i < rows * D implies row < rows and col < D, bounding
        // both input halves and all three output regions.
        const int64_t input_offset = row * width + col;
        const int64_t output_offset = row * (3 * D) + col;
        const float gate = static_cast<float>(base[input_offset])
                         + static_cast<float>(delta[input_offset]);
        const float up = static_cast<float>(base[input_offset + D])
                       + static_cast<float>(delta[input_offset + D]);
        const float g = static_cast<float>(grad_out[i]);
        const float sig = 1.0f / (1.0f + expf(-gate));
        const float silu = gate * sig;
        const float dgate = (g * up) * (sig + silu * (1.0f - sig));
        fused[output_offset] = static_cast<scalar_t>(silu * up);
        fused[output_offset + D] = static_cast<scalar_t>(dgate);
        fused[output_offset + 2 * D] = static_cast<scalar_t>(g * silu);
    }
}

template <typename scalar_t>
__global__ void add_swiglu_row_tiled_kernel(
    const scalar_t* __restrict__ base,
    const scalar_t* __restrict__ delta,
    const scalar_t* __restrict__ grad_out,
    scalar_t* __restrict__ fused,
    int64_t rows, int64_t width, int64_t D,
    int64_t tiles_per_row, int64_t total_tiles)
{
    __shared__ int64_t shared_row;
    __shared__ int64_t shared_tile_col;
    for (int64_t tile_id = static_cast<int64_t>(blockIdx.x);
         tile_id < total_tiles;
         tile_id += static_cast<int64_t>(gridDim.x)) {
        if (threadIdx.x == 0) {
            const int64_t row = tile_id / tiles_per_row;
            shared_row = row;
            shared_tile_col = (tile_id - row * tiles_per_row) * int64_t(256);
        }
        __syncthreads();
        const int64_t row = shared_row;
        const int64_t col = shared_tile_col + static_cast<int64_t>(threadIdx.x);
        if (row < rows && col < D) {
            const int64_t input_offset = row * width + col;
            const int64_t upstream_offset = row * D + col;
            const int64_t output_offset = row * (3 * D) + col;
            const float gate = static_cast<float>(base[input_offset])
                             + static_cast<float>(delta[input_offset]);
            const float up = static_cast<float>(base[input_offset + D])
                           + static_cast<float>(delta[input_offset + D]);
            const float g = static_cast<float>(grad_out[upstream_offset]);
            const float sig = 1.0f / (1.0f + expf(-gate));
            const float silu = gate * sig;
            const float dgate = (g * up) * (sig + silu * (1.0f - sig));
            fused[output_offset] = static_cast<scalar_t>(silu * up);
            fused[output_offset + D] = static_cast<scalar_t>(dgate);
            fused[output_offset + 2 * D] = static_cast<scalar_t>(g * silu);
        }
        __syncthreads();
    }
}

template <typename scalar_t>
void launch_add_swiglu(
    const at::Tensor& base, const at::Tensor& delta,
    const at::Tensor& grad_out, at::Tensor& fused,
    int64_t rows, int64_t width, int64_t D, hipStream_t stream)
{
    constexpr int threads = 256;
    if (D >= 256) {
        const int64_t tiles_per_row = 1 + (D - 1) / int64_t(256);
        // tiles_per_row <= D, and rows * (3 * D) was checked.
        const int64_t total_tiles = rows * tiles_per_row;
        const int blocks = static_cast<int>(
            std::min<int64_t>(total_tiles, 4096));
        hipLaunchKernelGGL(
            (add_swiglu_row_tiled_kernel<scalar_t>),
            dim3(blocks), dim3(threads), 0, stream,
            base.data_ptr<scalar_t>(), delta.data_ptr<scalar_t>(),
            grad_out.data_ptr<scalar_t>(), fused.data_ptr<scalar_t>(),
            rows, width, D, tiles_per_row, total_tiles);
    } else {
        const int64_t count = rows * D;
        const int blocks = static_cast<int>(
            std::min<int64_t>(1 + (count - 1) / threads, 4096));
        hipLaunchKernelGGL(
            (add_swiglu_kernel<scalar_t>),
            dim3(blocks), dim3(threads), 0, stream,
            base.data_ptr<scalar_t>(), delta.data_ptr<scalar_t>(),
            grad_out.data_ptr<scalar_t>(), fused.data_ptr<scalar_t>(),
            rows, width, D);
    }
}

at::Tensor add_swiglu(const at::Tensor& base,
                     const at::Tensor& delta,
                     const at::Tensor& grad_out)
{
    TORCH_CHECK(base.is_cuda() && delta.is_cuda() && grad_out.is_cuda(),
                "Inputs must be HIP device tensors");
    TORCH_CHECK(base.device() == delta.device() &&
                base.device() == grad_out.device(),
                "Inputs must be on the same device");
    TORCH_CHECK(base.dim() == 2 && delta.dim() == 2 && grad_out.dim() == 2,
                "Inputs must be two-dimensional");
    TORCH_CHECK(base.sizes() == delta.sizes(),
                "base and delta must have matching shapes");
    TORCH_CHECK(base.scalar_type() == at::kHalf ||
                base.scalar_type() == at::kBFloat16 ||
                base.scalar_type() == at::kFloat,
                "Inputs must be float16, bfloat16, or float32");
    TORCH_CHECK(base.scalar_type() == delta.scalar_type() &&
                base.scalar_type() == grad_out.scalar_type(),
                "Inputs must have matching dtypes");
    TORCH_CHECK(base.is_contiguous() && delta.is_contiguous() &&
                grad_out.is_contiguous(), "Inputs must be contiguous");

    const int64_t rows = base.size(0);
    const int64_t width = base.size(1);
    TORCH_CHECK(width > 0 && width % 2 == 0,
                "Width must be a nonzero even number");
    const int64_t D = width / 2;
    TORCH_CHECK(grad_out.size(0) == rows && grad_out.size(1) == D,
                "grad_out must have shape (num_rows, width / 2)");
    const int64_t limit = std::numeric_limits<int64_t>::max();
    TORCH_CHECK(D <= limit / 3, "Output width exceeds int64 range");
    const int64_t output_width = 3 * D;
    TORCH_CHECK(rows <= limit / output_width,
                "Output element count exceeds int64 range");

    const c10::cuda::CUDAGuard guard(base.device());
    auto fused = at::empty({rows, output_width}, base.options());
    if (rows == 0) {
        return fused;
    }

    hipStream_t stream = c10::cuda::getCurrentCUDAStream(base.get_device()).stream();
    if (base.scalar_type() == at::kHalf) {
        launch_add_swiglu<at::Half>(
            base, delta, grad_out, fused, rows, width, D, stream);
    } else if (base.scalar_type() == at::kFloat) {
        launch_add_swiglu<float>(
            base, delta, grad_out, fused, rows, width, D, stream);
    } else {
        launch_add_swiglu<at::BFloat16>(
            base, delta, grad_out, fused, rows, width, D, stream);
    }
    const hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess,
                "add_swiglu kernel launch failed: ", hipGetErrorString(error));
    return fused;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Training-oriented Add + SwiGLU fused operator: forward activation plus
    first-order analytic backward in a single call.

    Operator semantics:
      base and delta are added element-wise, then split in half along the last
      dimension (let D = width // 2):
        gate = (base + delta)[..., :D], up = (base + delta)[..., D:]
      The forward is a plain (non-clipped, non-interleaved) SwiGLU:
        out = SiLU(gate) * up, where SiLU(g) = g * sigmoid(g)
      The backward receives the upstream gradient grad_out (same shape as out);
      the derivative of SiLU is
        SiLU'(g) = sigmoid(g) * (1 + g * (1 - sigmoid(g)))
      base and delta enter the sum with the same coefficient, so their input
      gradients are element-wise identical:
        grad[..., :D] = (grad_out * up) * SiLU'(gate)
        grad[..., D:] = grad_out * SiLU(gate)
      This task merges forward and backward into a single forward call returning
      one fused tensor (3D columns):
        fused[..., 0:D)   = out (the activation output)
        fused[..., D:2D)  = the gate half of grad (the same for base and delta)
        fused[..., 2D:3D) = the up half of grad
      Boundary behaviour: width is a non-zero even number; num_rows may be 0 (an
      empty batch, output (0, 3D)); the input tensors are not modified; there is
      no broadcasting and no implicit dtype promotion; the evaluation ground truth
      is the float32 intermediate computation, and the tolerances cover the
      differences between half-precision rounding paths, so no specific eager
      rounding chain needs to be reproduced bit-for-bit.

    Input/output specification:
      base     (num_rows, width)      contiguous float16/bfloat16, width a non-zero even number
      delta    (num_rows, width)      same shape, dtype and device as base
      grad_out (num_rows, width // 2) same dtype as base, the upstream gradient of out
      returns  (num_rows, 3 * (width // 2)) same dtype as base, layout as above

    Implementation constraints (violations are scored as failures):
      - The core computation (the addition, SiLU/sigmoid, and the two gradient
        formulas) must be completed with a HIP kernel inside the submitted file;
        torch tensor operations are limited to output allocation and layout
        handling.
      - Calling ready-made implementations such as aiter /
        torch.nn.functional.silu / torch.sigmoid / torch.matmul / torch.bmm /
        torch.einsum is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, base, delta, grad_out):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().add_swiglu(base, delta, grad_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
