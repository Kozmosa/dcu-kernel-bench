import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4018_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor quant_forward(torch::Tensor x,
                            c10::optional<torch::Tensor> scale,
                            int64_t mode, bool fp8);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("quant_forward", &quant_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <algorithm>
#include <cstdint>
#include <limits>
#include <mutex>
#include <unordered_map>

namespace {
constexpr int THREADS = 256;

int device_wave_width(int device) {
    static std::mutex mutex;
    static std::unordered_map<int, int> widths;
    std::lock_guard<std::mutex> lock(mutex);
    auto it = widths.find(device);
    if (it != widths.end()) return it->second;

    hipDeviceProp_t properties{};
    const hipError_t e = hipGetDeviceProperties(&properties, device);
    TORCH_CHECK(e == hipSuccess,
                "HIP device property query failed: ", hipGetErrorString(e));
    TORCH_CHECK(properties.maxThreadsPerBlock >= THREADS &&
                properties.maxThreadsDim[0] >= THREADS,
                "HIP quantization requires a 256-thread block");
    const int width = properties.warpSize;
    widths.emplace(device, width);
    return width;
}

template<int W>
__device__ __forceinline__ float block_max(float v, float* scratch) {
    const int t = threadIdx.x;
    if constexpr (W == 32 || W == 64) {
        const int lane = t % W;
        const int wave = t / W;
        for (int d = W / 2; d > 0; d >>= 1) {
            v = fmaxf(v, __shfl_down(v, d, W));
        }
        if (lane == 0) scratch[wave] = v;
        __syncthreads();

        if (wave == 0) {
            float a = lane < THREADS / W ? scratch[lane] : 0.0f;
            for (int d = W / 2; d > 0; d >>= 1) {
                a = fmaxf(a, __shfl_down(a, d, W));
            }
            if (lane == 0) scratch[0] = a;
        }
        __syncthreads();
    } else {
        scratch[t] = v;
        __syncthreads();
        for (int d = THREADS / 2; d > 0; d >>= 1) {
            if (t < d) scratch[t] = fmaxf(scratch[t], scratch[t + d]);
            __syncthreads();
        }
    }
    return scratch[0];
}

__device__ __forceinline__ float round_e4m3(float v) {
    const float a = fabsf(v);
    if (a == 0.0f) return v;

    int e = -9;
    if (a >= 0.015625f) {
        const unsigned int bits = __float_as_uint(a);
        e = static_cast<int>((bits >> 23) & 255u) - 127 - 3;
    }

    const float step = ldexpf(1.0f, e);
    const float rounded = rintf(a / step) * step;
    return copysignf(rounded, v);
}

template<bool FP8>
__device__ __forceinline__ float quantize(float v) {
    if (FP8) return round_e4m3(v);
    const int iv = static_cast<int>(rintf(v));
    return static_cast<float>(iv);
}

template<bool FP8, int W, int K>
__global__ void token_wave_kernel(const float* __restrict__ x,
                                  float* __restrict__ out,
                                  int64_t rows, int64_t cols, int64_t n) {
    static_assert(W == 32 || W == 64, "unsupported wave width");
    const int lane = threadIdx.x % W;
    const int wave = threadIdx.x / W;
    const int64_t stride = static_cast<int64_t>(gridDim.x) * (THREADS / W);
    for (int64_t row = static_cast<int64_t>(blockIdx.x) * (THREADS / W) + wave;
         row < rows; row += stride) {
        const int64_t base = row * cols;
        float values[K];
        float a = 0.0f;
        #pragma unroll
        for (int k = 0; k < K; ++k) {
            const int64_t col = static_cast<int64_t>(lane) + static_cast<int64_t>(k) * W;
            const int64_t idx = base + col;
            values[k] = 0.0f;
            if (col < cols && idx < n) values[k] = x[idx];
            a = fmaxf(a, fabsf(values[k]));
        }
        for (int d = W / 2; d > 0; d >>= 1)
            a = fmaxf(a, __shfl_down(a, d, W));
        a = __shfl(a, 0, W);
        const float denom = FP8 ? 448.0f : 127.0f;
        const float s = fmaxf(a, 1.0e-10f) * (1.0f / denom);
        const float inverse = __fdiv_rn(1.0f, s);
        if (lane == 0 && row < rows) out[n + row] = s;
        #pragma unroll
        for (int k = 0; k < K; ++k) {
            const int64_t col = static_cast<int64_t>(lane) + static_cast<int64_t>(k) * W;
            const int64_t idx = base + col;
            if (col < cols && idx < n)
                out[idx] = quantize<FP8>(values[k] * inverse);
        }
    }
}

template<bool FP8, int W>
__global__ void token_kernel(const float* __restrict__ x,
                             float* __restrict__ out,
                             int64_t rows, int64_t cols, int64_t n) {
    __shared__ float scratch[THREADS];
    __shared__ float inverse;

    const int64_t t = static_cast<int64_t>(threadIdx.x);
    for (int64_t row = static_cast<int64_t>(blockIdx.x);
         row < rows;
         row += static_cast<int64_t>(gridDim.x)) {
        const int64_t base = row * cols;
        float a = 0.0f;

        for (int64_t col = t; col < cols; col += static_cast<int64_t>(THREADS)) {
            const int64_t idx = base + col;
            if (idx < n) a = fmaxf(a, fabsf(x[idx]));
        }

        a = block_max<W>(a, scratch);

        if (t == 0) {
            const float denom = FP8 ? 448.0f : 127.0f;
            // ATen's division by a host scalar multiplies by its fp32 reciprocal.
            const float s = fmaxf(a, 1.0e-10f) * (1.0f / denom);
            out[n + row] = s;
            inverse = __fdiv_rn(1.0f, s);
        }
        __syncthreads();

        const float inv = inverse;
        for (int64_t col = t; col < cols; col += static_cast<int64_t>(THREADS)) {
            const int64_t idx = base + col;
            if (idx < n) out[idx] = quantize<FP8>(x[idx] * inv);
        }
        __syncthreads();
    }
}

template<bool FP8, int W, int K>
__global__ void token_cached_kernel(const float* __restrict__ x,
                                    float* __restrict__ out,
                                    int64_t rows, int64_t cols, int64_t n) {
    __shared__ float scratch[THREADS];
    __shared__ float inverse;

    const int64_t t = static_cast<int64_t>(threadIdx.x);
    for (int64_t row = static_cast<int64_t>(blockIdx.x);
         row < rows;
         row += static_cast<int64_t>(gridDim.x)) {
        const int64_t base = row * cols;
        float values[K];
        float a = 0.0f;

        #pragma unroll
        for (int k = 0; k < K; ++k) {
            const int64_t col = t + static_cast<int64_t>(k)
                                     * static_cast<int64_t>(THREADS);
            const int64_t idx = base + col;
            values[k] = 0.0f;
            if (col < cols && idx < n) values[k] = x[idx];
            a = fmaxf(a, fabsf(values[k]));
        }

        a = block_max<W>(a, scratch);

        if (t == 0) {
            const float denom = FP8 ? 448.0f : 127.0f;
            // Match the fallback's fp32 scale evaluation and reciprocal ordering.
            const float s = fmaxf(a, 1.0e-10f) * (1.0f / denom);
            out[n + row] = s;
            inverse = __fdiv_rn(1.0f, s);
        }
        __syncthreads();

        const float inv = inverse;
        #pragma unroll
        for (int k = 0; k < K; ++k) {
            const int64_t col = t + static_cast<int64_t>(k)
                                     * static_cast<int64_t>(THREADS);
            const int64_t idx = base + col;
            if (col < cols && idx < n)
                out[idx] = quantize<FP8>(values[k] * inv);
        }
        // All threads must finish using the shared reciprocal before the next row.
        __syncthreads();
    }
}

template<int W>
__global__ void partial_kernel(const float* __restrict__ x,
                               float* __restrict__ partial,
                               int64_t n) {
    __shared__ float scratch[THREADS];

    int64_t i = static_cast<int64_t>(blockIdx.x) * static_cast<int64_t>(THREADS)
              + static_cast<int64_t>(threadIdx.x);
    const int64_t stride = static_cast<int64_t>(gridDim.x) * static_cast<int64_t>(THREADS);

    float a = 0.0f;
    for (; i < n; i += stride) a = fmaxf(a, fabsf(x[i]));

    a = block_max<W>(a, scratch);
    if (threadIdx.x == 0) partial[static_cast<int64_t>(blockIdx.x)] = a;
}

template<bool FP8, int W>
__global__ void scale_kernel(const float* __restrict__ partial,
                             float* __restrict__ out,
                             int64_t count, int64_t n) {
    __shared__ float scratch[THREADS];

    float a = 0.0f;
    for (int64_t i = static_cast<int64_t>(threadIdx.x);
         i < count;
         i += static_cast<int64_t>(THREADS)) {
        a = fmaxf(a, partial[i]);
    }

    a = block_max<W>(a, scratch);
    if (threadIdx.x == 0) {
        const float denom = FP8 ? 448.0f : 127.0f;
        out[n] = a * (1.0f / denom);
    }
}

template<bool FP8, bool STATIC>
__global__ void tensor_kernel(const float* __restrict__ x,
                              const float* __restrict__ scale,
                              float* __restrict__ out,
                              int64_t n) {
    const int64_t start = static_cast<int64_t>(blockIdx.x) * static_cast<int64_t>(THREADS)
                         + static_cast<int64_t>(threadIdx.x);
    const int64_t stride = static_cast<int64_t>(gridDim.x) * static_cast<int64_t>(THREADS);

    float s;
    if (STATIC) {
        s = scale[0];
        if (start == 0) out[n] = s;
    } else {
        s = out[n];
    }

    for (int64_t i = start; i < n; i += stride) {
        out[i] = quantize<FP8>(__fdiv_rn(x[i], s));
    }
}

void check_launch() {
    const hipError_t e = hipGetLastError();
    TORCH_CHECK(e == hipSuccess,
                "HIP quantization launch failed: ",
                hipGetErrorString(e));
}

template<bool FP8, int W>
void run(torch::Tensor x,
         c10::optional<torch::Tensor> scale,
         torch::Tensor out,
         int64_t mode,
         hipStream_t stream) {
    const int64_t n = x.numel();
    const int64_t rows = x.size(0);
    const int64_t cols = x.size(1);

    const float* xp = x.data_ptr<float>();
    float* op = out.data_ptr<float>();

    const int64_t needed = n > 0
        ? (n + static_cast<int64_t>(THREADS) - 1) / static_cast<int64_t>(THREADS)
        : 1;
    const int blocks = static_cast<int>(
        std::max<int64_t>(1, std::min<int64_t>(4096, needed)));

    if (mode == 2) {
        if (rows == 0) return;
        if constexpr (W == 32 || W == 64) {
            if (cols > 0 && cols <= 256) {
                const int wave_blocks = static_cast<int>(std::min<int64_t>(
                    (rows - 1) / (THREADS / W) + 1, 65535));
                if (cols <= W) {
                    token_wave_kernel<FP8, W, 1><<<wave_blocks, THREADS, 0, stream>>>(
                        xp, op, rows, cols, n);
                } else if (cols <= 2 * W) {
                    token_wave_kernel<FP8, W, 2><<<wave_blocks, THREADS, 0, stream>>>(
                        xp, op, rows, cols, n);
                } else if (cols <= 4 * W) {
                    token_wave_kernel<FP8, W, 4><<<wave_blocks, THREADS, 0, stream>>>(
                        xp, op, rows, cols, n);
                } else {
                    token_wave_kernel<FP8, W, 8><<<wave_blocks, THREADS, 0, stream>>>(
                        xp, op, rows, cols, n);
                }
                check_launch();
                return;
            }
        }
        if constexpr (W == 64) {
            if (rows >= 1024 && cols > 256 && cols <= 1024) {
                const int64_t wave_blocks = std::min<int64_t>(
                    (rows - 1) / (THREADS / W) + 1, 65535);
                if (cols <= 512) {
                    token_wave_kernel<FP8, W, 8><<<static_cast<int>(wave_blocks), THREADS, 0, stream>>>(
                        xp, op, rows, cols, n);
                } else {
                    token_wave_kernel<FP8, W, 16><<<static_cast<int>(wave_blocks), THREADS, 0, stream>>>(
                        xp, op, rows, cols, n);
                }
                check_launch();
                return;
            }
        }
        const int row_blocks = static_cast<int>(
            std::min<int64_t>(rows, 65535));
        if (cols > 0 && cols <= 2048) {
            if (cols <= 256) {
                token_cached_kernel<FP8, W, 1><<<row_blocks, THREADS, 0, stream>>>(
                    xp, op, rows, cols, n);
            } else if (cols <= 512) {
                token_cached_kernel<FP8, W, 2><<<row_blocks, THREADS, 0, stream>>>(
                    xp, op, rows, cols, n);
            } else if (cols <= 1024) {
                token_cached_kernel<FP8, W, 4><<<row_blocks, THREADS, 0, stream>>>(
                    xp, op, rows, cols, n);
            } else {
                token_cached_kernel<FP8, W, 8><<<row_blocks, THREADS, 0, stream>>>(
                    xp, op, rows, cols, n);
            }
        } else {
            token_kernel<FP8, W><<<row_blocks, THREADS, 0, stream>>>(
                xp, op, rows, cols, n);
        }
        check_launch();
    } else if (mode == 0) {
        tensor_kernel<FP8, true><<<blocks, THREADS, 0, stream>>>(
            xp, scale->data_ptr<float>(), op, n);
        check_launch();
    } else {
        auto partial = torch::empty(
            {static_cast<int64_t>(blocks)}, x.options());

        partial_kernel<W><<<blocks, THREADS, 0, stream>>>(
            xp, partial.data_ptr<float>(), n);
        check_launch();

        scale_kernel<FP8, W><<<1, THREADS, 0, stream>>>(
            partial.data_ptr<float>(), op,
            static_cast<int64_t>(blocks), n);
        check_launch();

        tensor_kernel<FP8, false><<<blocks, THREADS, 0, stream>>>(
            xp, nullptr, op, n);
        check_launch();
    }
}

template<bool FP8>
void dispatch(torch::Tensor x,
              c10::optional<torch::Tensor> scale,
              torch::Tensor out,
              int64_t mode,
              hipStream_t stream,
              int width) {
    if (width == 32) run<FP8, 32>(x, scale, out, mode, stream);
    else if (width == 64) run<FP8, 64>(x, scale, out, mode, stream);
    else run<FP8, 0>(x, scale, out, mode, stream);
}
}

torch::Tensor quant_forward(torch::Tensor x,
                            c10::optional<torch::Tensor> scale,
                            int64_t mode, bool fp8) {
    TORCH_CHECK(x.is_cuda() && x.scalar_type() == torch::kFloat32,
                "x must be a GPU float32 tensor");
    TORCH_CHECK(x.dim() == 2 && x.is_contiguous(),
                "x must be contiguous and 2D");
    TORCH_CHECK(mode >= 0 && mode <= 2,
                "invalid quantization mode");

    const c10::cuda::CUDAGuard guard(x.device());
    const int width = device_wave_width(x.get_device());

    if (mode == 0) {
        TORCH_CHECK(scale.has_value(),
                    "static quantization requires scale");
        TORCH_CHECK(scale->device() == x.device() &&
                    scale->scalar_type() == torch::kFloat32 &&
                    scale->numel() == 1 &&
                    scale->is_contiguous(),
                    "scale must be one contiguous float32 value on the input device");
    }

    if (mode == 1) {
        TORCH_CHECK(x.numel() > 0,
                    "dynamic tensor reduction requires input");
    }

    const int64_t count = mode == 2 ? x.size(0) : 1;
    TORCH_CHECK(
        x.numel() <= std::numeric_limits<int64_t>::max() - count,
        "output size overflow");

    auto out = torch::empty({x.numel() + count}, x.options());
    hipStream_t stream =
        c10::cuda::getCurrentCUDAStream(x.get_device()).stream();

    if (fp8) dispatch<true>(x, scale, out, mode, stream, width);
    else dispatch<false>(x, scale, out, mode, stream, width);

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    fp8(e4m3)/int8 quantization kernel family: static per-tensor / dynamic
    per-tensor / dynamic per-token.

    The input x is a contiguous 2D float tensor (rows, cols); the __init__
    hyperparameter mode selects the quantization mode and quant_dtype selects
    the target dtype (int8 or fp8 e4m3). Intermediate arithmetic is float32
    throughout. Definitions per mode (dtype_max: 127 for int8, 448 for fp8
    e4m3):

      static_per_tensor (the scale is given by the input):
          q_i  = x_i / scale                    # fp32 division, scale is (1,) fp32
          y_i  = int8: round_half_even(q_i); fp8: rne_e4m3(q_i)
          scale_out = scale (passed through as is, segment length 1)
      dynamic_per_tensor (single scale for the whole tensor, no division-by-zero guard):
          amax = max_i |x_i|                    # fp32
          s    = amax / dtype_max
          y_i  = int8: round_half_even(x_i / s); fp8: rne_e4m3(x_i / s)
          scale_out = s (segment length 1)
      dynamic_per_token (one scale per row, with a division-by-zero guard):
          amax_r = max_j |x_rj|                 # fp32
          s_r    = max(amax_r, 1e-10) / dtype_max
          y_rj   = int8: round_half_even(x_rj * (1/s_r)); fp8: rne_e4m3(x_rj * (1/s_r))
          scale_out = s (segment length rows, row-major)

    round_half_even is banker's rounding (0.5 -> 0, -0.5 -> 0, 1.5 -> 2,
    126.5 -> 126), consistent with torch.round; rne_e4m3 is rounding to the
    nearest representable e4m3 value (equivalent to .to(float8_e4m3fn)).
    Boundary behaviour: an all-zero row under per-token has amax_r = 0, the
    1e-10 guard gives s_r = 1e-10/dtype_max and every code word of that row is
    0 -- the output must be finite, producing NaN/Inf is a wrong
    implementation; per-tensor modes have no division-by-zero guard (the input
    contract guarantees amax > 0).

    Input/output specification:
      x     float16/bfloat16, contiguous (rows, cols); the evaluator casts the
            input to fp32 before passing it in -- fp16/bf16 values are exact in
            fp32, so the quantization semantics are unchanged
      scale used only in static_per_tensor mode: (1,) float32 positive number
      out   a 1-D float32 tensor of length rows*cols + S (single-tensor output
            protocol, two segments packed):
            out[:rows*cols] = quantized code words promoted to float32 (int8
                              are integers in [-127,127]; fp8 are exact e4m3
                              values)
            out[rows*cols:] = the scale segment: per-token gives rows row
                              scales (row-major), per-tensor/static gives 1
                              tensor scale
      __init__ hyperparameters: mode (str, default "dynamic_per_token"),
            quant_dtype (str, "int8" or "float8_e4m3", default "int8").
      Input contract: x is not all zero (per-tensor modes); for every mode the
      quotient/product before quantization falls inside the target dtype range
      (the cast has no overflow semantics divergence).

    Implementation constraints (violations are scored as failures):
      - The core computation (amax reduction, scale, quantized code words) must
        be completed in HIP kernels inside the submitted file; forward may
        only do input/output shaping (dtype conversion, the two-segment packing,
        etc.). Calling any ready-made quantization library / quantization
        shortcut is forbidden (including torch.quantize_per_tensor /
        torch.quantize_per_channel).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate arithmetic uses float32; the computation order of the
        scale and the quotient must match the definitions above -- per-token
        computes the reciprocal 1/s_r first and then multiplies by x, whereas
        static/per-tensor use the fp32 direct division x_i / s (reciprocal
        multiplication and direct division differ by 1 ulp, which shifts code
        words on tie boundaries); int8 rounding uses round_half_even.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: 2D contiguous input, int8 and fp8 e4m3 target dtypes, three
    modes in one operator; without the GEMM back-end computation and without
    block-scaling floating-point (mxfp4) quantization.
    """
    def __init__(self, mode: str = "dynamic_per_token", quant_dtype: str = "int8"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert mode in ("static_per_tensor", "dynamic_per_tensor", "dynamic_per_token"), "invalid mode"
        assert quant_dtype in ("int8", "float8_e4m3"), "quant_dtype must be int8 or float8_e4m3"
        self.mode = mode
        self.quant_dtype = torch.int8 if quant_dtype == "int8" else torch.float8_e4m3fn
        # <<<END_IMPROVE>>>

    def forward(self, x, scale=None):
        # <<<IMPROVE:forward_stmt_1>>>
        assert x.dim() == 2, "x must be a 2D tensor"
        assert x.is_contiguous(), "x must be contiguous"
        mode_id = {"static_per_tensor": 0, "dynamic_per_tensor": 1, "dynamic_per_token": 2}[self.mode]
        static_scale = None
        if mode_id == 0:
            assert scale is not None, "static_per_tensor requires scale"
            static_scale = scale.to(torch.float32).reshape(1)
        return _pyramidkernel_get_extension().quant_forward(
            x.to(torch.float32), static_scale, mode_id,
            self.quant_dtype == torch.float8_e4m3fn
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert x.is_contiguous(), "x must be contiguous"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        qdt = self.quant_dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        dtype_max = torch.iinfo(qdt).max if qdt == torch.int8 else torch.finfo(qdt).max
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        x_f32 = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        absf = torch.abs(x_f32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        if self.mode == "static_per_tensor": s = scale.to(torch.float32).reshape(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if self.mode == "dynamic_per_tensor": s = (torch.max(absf) / dtype_max).reshape(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if self.mode == "dynamic_per_token": s = torch.max(absf, dim=-1).values.clamp(min=1.0e-10) / dtype_max
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        if self.mode == "dynamic_per_token": q = x_f32 * (1.0 / s)[:, None]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        if self.mode != "dynamic_per_token": q = x_f32 / s
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        if qdt == torch.int8: q = q.round()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        qx = q.to(qdt)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        codes = qx.reshape(-1).to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        return torch.cat([codes, s.reshape(-1).to(torch.float32)])
        # <<<END_IMPROVE>>>
