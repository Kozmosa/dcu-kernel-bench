import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1020_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor mla_decode(torch::Tensor, torch::Tensor, torch::Tensor,
                         torch::Tensor, torch::Tensor, torch::Tensor,
                         int64_t, int64_t, int64_t, double, bool);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mla_decode", &mla_decode);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <limits>
#include <cmath>
#include <cstdint>

template <typename T>
__device__ __forceinline__ float rope_value(
    const T* x, const T* cs, int64_t d, int64_t rd, bool neox) {
    float v = float(x[d]);
    if (d >= rd) return v;
    const int64_t half = rd / 2;
    const bool second = neox ? (d >= half) : ((d & 1) != 0);
    const int64_t i = neox ? (d % half) : (d / 2);
    const int64_t partner = neox ? (second ? d - half : d + half) : (d ^ 1);
    const float other = float(x[partner]);
    const float co = float(cs[i]);
    const float si = float(cs[half + i]);
    return second ? (v * co + other * si) : (v * co - other * si);
}

template <typename T>
__global__ void partial_attention(
    const T* q, const T* kv, const T* cs,
    const int32_t* positions, const int32_t* indptr,
    const int32_t* indices, float* scratch,
    int64_t B, int64_t H, int64_t c, int64_t r, int64_t rd,
    int64_t rows, int64_t nids, int64_t npos, int64_t parts,
    float scale, bool neox) {
    const int64_t task = int64_t(blockIdx.x);
    const int64_t part = task % parts;
    const int64_t bh = task / parts;
    const int64_t b = bh / H;
    const int64_t t = int64_t(threadIdx.x);
    if (b >= B) return;

    const int64_t D = c + r;
    const int64_t start = int64_t(indptr[b]);
    const int64_t end = int64_t(indptr[b + 1]);
    const int64_t position = int64_t(positions[b]);
    const bool valid = start >= 0 && end > start && end <= nids &&
                       position >= 0 && position < npos;

    int64_t lo = 0;
    int64_t hi = 0;
    if (valid) {
        const int64_t len = end - start;
        lo = start + (len * part) / parts;
        hi = start + (len * (part + 1)) / parts;
    }

    extern __shared__ float shared[];
    float* query = shared;
    float* key = query + D;
    float* numerator = key + D;
    float* reduction = numerator + c;
    __shared__ float max_logit;
    __shared__ float norm;
    __shared__ float alpha;
    __shared__ float beta;

    if (t == 0) {
        max_logit = -INFINITY;
        norm = 0.0f;
    }
    for (int64_t d = t; d < c; d += int64_t(blockDim.x))
        numerator[d] = 0.0f;

    for (int64_t d = t; d < D; d += int64_t(blockDim.x)) {
        float v = 0.0f;
        if (valid) {
            if (d < c)
                v = float(q[bh * D + d]);
            else
                v = rope_value(q + bh * D + c, cs + position * rd,
                               d - c, rd, neox);
        }
        query[d] = v;
    }
    __syncthreads();

    for (int64_t logical = lo; logical < hi; ++logical) {
        const int64_t physical = int64_t(indices[logical]);
        const bool row_valid = physical >= 0 && physical < rows;
        float partial = 0.0f;

        for (int64_t d = t; d < D; d += int64_t(blockDim.x)) {
            float v = 0.0f;
            if (row_valid) {
                const T* row = kv + physical * D;
                if (logical == end - 1 && d >= c)
                    v = rope_value(row + c, cs + position * rd,
                                   d - c, rd, neox);
                else
                    v = float(row[d]);
            }
            key[d] = v;
            partial += query[d] * v;
        }

        reduction[t] = partial;
        __syncthreads();
        for (int64_t stride = int64_t(blockDim.x) / 2; stride > 0; stride /= 2) {
            if (t < stride)
                reduction[t] += reduction[t + stride];
            __syncthreads();
        }

        if (t == 0) {
            const float score = reduction[0] * scale;
            const float new_max = fmaxf(max_logit, score);
            alpha = expf(max_logit - new_max);
            beta = expf(score - new_max);
            norm = alpha * norm + beta;
            max_logit = new_max;
        }
        __syncthreads();

        for (int64_t d = t; d < c; d += int64_t(blockDim.x))
            numerator[d] = alpha * numerator[d] + beta * key[d];
        __syncthreads();
    }

    const int64_t base = task * (c + 2);
    for (int64_t d = t; d < c; d += int64_t(blockDim.x))
        scratch[base + d] = numerator[d];
    if (t == 0) {
        scratch[base + c] = max_logit;
        scratch[base + c + 1] = norm;
    }
}

template <typename T>
__global__ void merge_attention(
    const float* scratch, T* out,
    int64_t batch_heads, int64_t c, int64_t parts) {
    const int64_t bh = int64_t(blockIdx.x);
    if (bh >= batch_heads) return;

    for (int64_t d = int64_t(threadIdx.x); d < c; d += int64_t(blockDim.x)) {
        float global_max = -INFINITY;
        for (int64_t p = 0; p < parts; ++p) {
            const int64_t base = (bh * parts + p) * (c + 2);
            if (scratch[base + c + 1] > 0.0f)
                global_max = fmaxf(global_max, scratch[base + c]);
        }

        float num = 0.0f;
        float den = 0.0f;
        for (int64_t p = 0; p < parts; ++p) {
            const int64_t base = (bh * parts + p) * (c + 2);
            const float part_norm = scratch[base + c + 1];
            if (part_norm > 0.0f) {
                const float weight = expf(scratch[base + c] - global_max);
                num += weight * scratch[base + d];
                den += weight * part_norm;
            }
        }
        out[bh * c + d] = T(den > 0.0f ? num / den : 0.0f);
    }
}

template <typename T>
__global__ void write_last_rope(
    const T* kv, const T* cs, const int32_t* positions,
    const int32_t* indptr, const int32_t* indices, T* out,
    int64_t B, int64_t H, int64_t c, int64_t r, int64_t rd,
    int64_t rows, int64_t nids, int64_t npos, bool neox) {
    const int64_t b = int64_t(blockIdx.x);
    if (b >= B) return;

    const int64_t start = int64_t(indptr[b]);
    const int64_t end = int64_t(indptr[b + 1]);
    const int64_t position = int64_t(positions[b]);
    bool valid = start >= 0 && end > start && end <= nids &&
                 position >= 0 && position < npos;

    const int64_t physical = valid ? int64_t(indices[end - 1]) : -1;
    valid = valid && physical >= 0 && physical < rows;

    for (int64_t d = int64_t(threadIdx.x); d < r; d += int64_t(blockDim.x)) {
        float value = 0.0f;
        if (valid)
            value = rope_value(kv + physical * (c + r) + c,
                               cs + position * rd, d, rd, neox);
        out[B * H * c + b * r + d] = T(value);
    }
}

static inline void check_launch() {
    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess,
                "MLA HIP launch failed: ", hipGetErrorString(err));
}

torch::Tensor mla_decode(
    torch::Tensor q, torch::Tensor kv, torch::Tensor cs,
    torch::Tensor positions, torch::Tensor indptr, torch::Tensor indices,
    int64_t c, int64_t r, int64_t rd, double scale, bool neox) {
    TORCH_CHECK(q.is_cuda(), "q must be on GPU");
    c10::cuda::CUDAGuard guard(q.device());

    for (const auto& x : {kv, cs, positions, indptr, indices})
        TORCH_CHECK(x.device() == q.device(), "all inputs must share a device");

    TORCH_CHECK(q.dim() == 3 && kv.dim() == 2 && cs.dim() == 2,
                "invalid input dimensions");

    const int64_t B = q.size(0);
    const int64_t H = q.size(1);
    const int64_t D = q.size(2);

    TORCH_CHECK(B > 0 && H > 0 && c > 0 && r > 0 && D == c + r,
                "invalid attention shape");
    TORCH_CHECK(rd >= 2 && rd <= r && (rd & (rd - 1)) == 0,
                "invalid rotary dimension");
    TORCH_CHECK(kv.size(1) == D && cs.size(1) == rd,
                "invalid cache shape");
    TORCH_CHECK(q.scalar_type() == at::kHalf ||
                q.scalar_type() == at::kBFloat16 ||
                q.scalar_type() == at::kFloat ||
                q.scalar_type() == at::kDouble,
                "unsupported input dtype");
    TORCH_CHECK(kv.scalar_type() == q.scalar_type() &&
                cs.scalar_type() == q.scalar_type(),
                "cache dtype mismatch");
    TORCH_CHECK(positions.numel() == B &&
                indptr.numel() == B + 1 &&
                indices.dim() == 1,
                "invalid metadata shapes");

    auto positions32 = positions.scalar_type() == at::kInt
        ? positions : positions.to(at::kInt);
    auto indptr32 = indptr.scalar_type() == at::kInt
        ? indptr : indptr.to(at::kInt);
    auto indices32 = indices.scalar_type() == at::kInt
        ? indices : indices.to(at::kInt);

    q = q.contiguous();
    kv = kv.contiguous();
    cs = cs.contiguous();
    positions32 = positions32.contiguous();
    indptr32 = indptr32.contiguous();
    indices32 = indices32.contiguous();

    const int64_t total_ids = indices32.numel();
    const int64_t parts = std::min<int64_t>(
        32, std::max<int64_t>(1, (total_ids + B * 256 - 1) / (B * 256)));

    TORCH_CHECK(B * H * parts <= std::numeric_limits<unsigned int>::max(),
                "grid too large");

    const int64_t shared_bytes =
        (2 * D + c + 256) * int64_t(sizeof(float));
    hipDeviceProp_t props;
    TORCH_CHECK(hipGetDeviceProperties(&props, q.get_device()) == hipSuccess,
                "cannot query device");
    TORCH_CHECK(shared_bytes <= int64_t(props.sharedMemPerBlock),
                "shared memory requirement too large");

    auto out = torch::empty({B * H * c + B * r}, q.options());
    auto scratch = torch::empty(
        {B * H * parts * (c + 2)}, q.options().dtype(at::kFloat));
    auto stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "mla_decode", [&] {
            partial_attention<scalar_t>
                <<<static_cast<unsigned int>(B * H * parts),
                   256, shared_bytes, stream>>>(
                    q.data_ptr<scalar_t>(),
                    kv.data_ptr<scalar_t>(),
                    cs.data_ptr<scalar_t>(),
                    positions32.data_ptr<int32_t>(),
                    indptr32.data_ptr<int32_t>(),
                    indices32.data_ptr<int32_t>(),
                    scratch.data_ptr<float>(),
                    B, H, c, r, rd, kv.size(0), total_ids, cs.size(0),
                    parts, float(scale), neox);
            check_launch();

            merge_attention<scalar_t>
                <<<static_cast<unsigned int>(B * H), 256, 0, stream>>>(
                    scratch.data_ptr<float>(),
                    out.data_ptr<scalar_t>(),
                    B * H, c, parts);
            check_launch();

            write_last_rope<scalar_t>
                <<<static_cast<unsigned int>(B), 256, 0, stream>>>(
                    kv.data_ptr<scalar_t>(),
                    cs.data_ptr<scalar_t>(),
                    positions32.data_ptr<int32_t>(),
                    indptr32.data_ptr<int32_t>(),
                    indices32.data_ptr<int32_t>(),
                    out.data_ptr<scalar_t>(),
                    B, H, c, r, rd, kv.size(0), total_ids, cs.size(0),
                    neox);
            check_launch();
        });

    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    DeepSeek MLA decode-phase attention with a single-token query, fusing the RoPE
    rotation, page size = 1.

    Semantics: q is the current decode step's query [B, H, c + r] (c =
    kv_lora_rank compressed nope part first, r = qk_rope_head_dim rope part q_pe
    after it). The KV cache is stored per token (page size 1): kv_cache has
    total_tokens rows, each row = [compressed latent vector (first c dims) | k_pe
    (last r dims)]; the j-th logical token of batch b lives at physical row
    kv_indices[kv_indptr[b] + j] (kv_indptr is the cumulative sum of the sequence
    lengths, starting at 0); unreferenced rows of the row pool are garbage data and
    must not take part in the computation. Value is exactly the first c columns of
    that row: the compressed part of K shares the same latent vector with V (the
    MLA structure -- every query head shares one per-token compressed KV, there is
    no separate KV head).

    For every batch b (let pos = positions[b], rd = rotary_dim, half = rd // 2):
      1. RoPE rotation: take the row [cos(half) | sin(half)] of cos_sin_cache by
         position pos. The first rd dims of q_pe are rotated and the dims after rd
         pass through unchanged; the k_pe of the last logical token
         (j = seq_len_b - 1) is likewise rotated only in its first rd dims (dims
         after rd pass through), while the k_pe of the other tokens is treated as
         already rotated and used as the raw cache value. The rotation style is
         chosen by is_neox_style:
           NEOX (rotate-half): (x1, x2) = (first half dims, last half dims)
           GPT-J (interleaved): (x1, x2) = (even dims, odd dims)
           rotation output = concat(x1*cos - x2*sin, x2*cos + x1*sin) (scattered
           back in their own order).
      2. Attention (softmax over all j = 0..seq_len_b-1):
           s[h, j] = sm_scale * ( <q_nope[b,h,:], k_lat[b,j,:]>
                                + <q_pe'[b,h,:], k_pe'[b,j,:]> )
         where ' denotes after rotation; k_pe' is the rotated value only for the
         last token and the raw cache value for the others.
           p[h, :] = softmax_j(s[h, :])
           attn_out[b, h, :] = sum_j p[h, j] * k_lat[b, j, :]
      3. k_pe_tokens[b, :] = the full rotated k_pe of the last token (r dims, for
         writing back to the cache).
    softmax is numerically stable, intermediate accumulation is float32, and the
    output is cast back to the input dtype.
    Boundary behaviour: seq_len_b >= 1 (when it equals 1 that token is "the last
    token" and its k_pe takes part in the rotation); how the KV reduction is
    organized is only an implementation detail -- any implementation numerically
    equivalent to the full softmax is acceptable; there is no logit cap, no causal
    mask (decode naturally attends the whole cache), and no quantization.

    Input/output specification:
      q              [B, H, c + r] float16/bfloat16
      kv_cache       [total_tokens, c + r] same dtype as q (token-level KV row pool)
      cos_sin_cache  [max_positions, rd] same dtype as q (first half columns cos,
                     last half columns sin; row t corresponds to position
                     t = 0,1,...)
      positions      [B] int32 (sequence position of the current query; values
                     < max_positions, independent of seq_len)
      kv_indptr      [B+1] int32 (cumulative sum of the sequence lengths: first
                     element 0, monotonically non-decreasing)
      kv_indices     [total_kv] int32 (logical token -> physical row id; values
                     < total_tokens; total_kv == kv_indptr[-1])
      out            1-D flat concatenation, length B*H*c + B*r, same dtype as q:
                     the first B*H*c entries = attn_out ([B, H, c] flattened in
                     row-major order), the last B*r entries = k_pe_tokens
                     ([B, r] flattened in row-major order)
    Global-domain constraints: rd is a power of 2 and rd <= r;
    total_tokens >= kv_indptr[-1]; each sequence seq_len_b >= 1; B, H, c, r,
    max_positions are given by the shape family.

    Implementation constraints (violations are scored as failures):
      - The core computation (RoPE rotation / KV gathering / QK^T / softmax / PV)
        must be done inside the submitted file; calling
        scaled_dot_product_attention / sdpa / flash_attn / aiter / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - The 1-D concatenation layout of the output must match the specification
        above (the evaluator compares element by element).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-token decode, use_rope always true, non-quantized
    fp16/bf16, no logit cap, no causal mask / ALiBi / sliding window.
    """
    def __init__(self, kv_lora_rank: int, qk_rope_head_dim: int, rotary_dim: int, sm_scale=None, is_neox_style=True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.kv_lora_rank = int(kv_lora_rank)
        self.qk_rope_head_dim = int(qk_rope_head_dim)
        self.rotary_dim = int(rotary_dim)
        self.sm_scale = float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(self.kv_lora_rank + self.qk_rope_head_dim)
        self.is_neox_style = bool(is_neox_style)
        # <<<END_IMPROVE>>>

    def forward(self, q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().mla_decode(
            q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices,
            self.kv_lora_rank, self.qk_rope_head_dim, self.rotary_dim,
            self.sm_scale, self.is_neox_style)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        kv_indptr = kv_indptr.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        kv_indices = kv_indices.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        c, rd = self.kv_lora_rank, self.rotary_dim
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        half = rd // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        B, H, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        r = D - c
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert r == self.qk_rope_head_dim, "q's last dim must equal kv_lora_rank + qk_rope_head_dim"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        def apply_rope(x, cos, sin):
            rot = x[..., :rd]
            if self.is_neox_style:
                x1, x2 = rot[..., :half], rot[..., half:]
            else:
                x1, x2 = rot[..., ::2], rot[..., 1::2]
            o1 = x1 * cos - x2 * sin
            o2 = x2 * cos + x1 * sin
            if self.is_neox_style:
                rot_out = torch.cat((o1, o2), dim=-1)
            else:
                rot_out = torch.stack((o1, o2), dim=-1).flatten(-2)
            return torch.cat((rot_out, x[..., rd:]), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        attn_out = torch.empty(B, H, c, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        k_pe_tokens = torch.empty(B, r, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # The HIP entrypoint above implements attention.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return torch.cat((attn_out.reshape(-1), k_pe_tokens.reshape(-1)))
        # <<<END_IMPROVE>>>
