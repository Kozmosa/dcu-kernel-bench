import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4017_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    per-token-group int8 dynamic quantization (activation preprocessing for
    W8A8 integer GEMM).

    The input x is a contiguous 2D float tensor (rows, cols) and cols must be
    divisible by group_size. In row-major (flattened) order x is cut into
    G = rows*cols/group_size contiguous groups of group_size elements each.
    For every group g (all intermediate arithmetic in float32):
        absmax_g = max( max_{i in g} |x_i|, eps )    # eps is the division-by-zero guard
        scale_g  = absmax_g / 127                    # fp32 division
        q_i      = trunc_int8( clamp( x_i / scale_g, -128, 127 ) )
    trunc_int8 means truncate toward zero and then convert to int8, so the
    quantized code words end up in [-127, 127].
    Boundary behaviour: when absmax_g < eps (including an all-zero group)
    scale_g = eps/127 and every code word in the group is 0; the eps guard must
    take effect (producing a 0 scale or NaN is a wrong implementation).

    Input/output specification:
      x    float16/bfloat16, contiguous (rows, cols), cols % group_size == 0;
           the evaluator casts the input to fp32 before passing it in --
           fp16/bf16 values are exact in fp32, so the quantization semantics are
           unchanged
      out  a 1-D float32 tensor of length rows*cols + rows*cols/group_size
           (single-tensor output protocol, two segments packed):
           out[:rows*cols]  = int8 code words promoted to float32 (integers in
                              [-127,127])
           out[rows*cols:]  = the per-group scales, in row-major order
                              ((rows, cols/group_size) flattened)
      __init__ hyperparameters: group_size (int, default 128), eps (float,
      default 1e-10).

    Implementation constraints (violations are scored as failures):
      - The core computation (in-group absmax, scale, quantized code words)
        must be completed in HIP kernels inside the submitted file; forward
        may only do input/output shaping (dtype conversion, the two-segment
        packing, etc.). Calling aiter / torch.quantize_per_tensor /
        torch.quantize_per_channel is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate arithmetic uses float32; the scale must be computed as the
        fp32 division absmax/127 (precomputing a reciprocal and multiplying
        shifts the code words by 1 at the truncation boundary); the code words
        are first clamped to [-128, 127] and then truncated toward zero into
        int8.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: 2D contiguous input, torch.int8 code words, fp32 scale, without
    the GEMM back-end computation.
    """
    def __init__(self, group_size: int = 128, eps: float = 1e-10):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.group_size = int(group_size)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        gs = self.group_size
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert x.dim() == 2, "x must be a 2D tensor"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        assert x.shape[-1] % gs == 0, "the last dimension must be divisible by group_size"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert x.is_contiguous(), "x must be contiguous"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        rows, cols = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        int8_min, int8_max = -128.0, 127.0
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        y = x.to(torch.float32).reshape(-1, gs)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        amax = y.abs().amax(dim=1, keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        amax = torch.maximum(amax, torch.full_like(amax, self.eps))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        y_s = amax / int8_max
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        y_q = (y / y_s).clamp(min=int8_min, max=int8_max).to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        codes = y_q.reshape(rows, cols).reshape(-1).to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        scales = y_s.reshape(rows, cols // gs).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return torch.cat([codes, scales])
        # <<<END_IMPROVE>>>
