```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _paged_attention_partials(
    Q, K, V, TABLE, ENDS, PART, MAXIMUM, DENOM,
    QH: tl.constexpr, QM: tl.constexpr, QD: tl.constexpr,
    KH: tl.constexpr, KM: tl.constexpr, KD: tl.constexpr,
    VH: tl.constexpr, VM: tl.constexpr, VD: tl.constexpr,
    TH: tl.constexpr, TB: tl.constexpr, ES: tl.constexpr,
    BATCH: tl.constexpr, NQ: tl.constexpr,
    D: tl.constexpr, BD: tl.constexpr, BQ: tl.constexpr,
    PAGE: tl.constexpr, SPLITS: tl.constexpr, SCALE: tl.constexpr,
):
    hb = tl.program_id(0)
    split = tl.program_id(1)
    h = hb // BATCH
    b = hb % BATCH

    first = tl.load(ENDS + (b - 1) * ES, mask=b > 0, other=0)
    last = tl.load(ENDS + b * ES)
    count = last - first
    per_split = tl.cdiv(count, SPLITS)
    begin = first + split * per_split
    end = tl.minimum(begin + per_split, last)

    qi = tl.arange(0, BQ)
    di = tl.arange(0, BD)
    ti = tl.arange(0, 64)

    q = tl.load(
        Q + h * QH + (b * NQ + qi[:, None]) * QM + di[None, :] * QD,
        mask=(qi[:, None] < NQ) & (di[None, :] < D),
        other=0,
    ).to(tl.float32)

    maximum = tl.full((BQ,), -float("inf"), tl.float32)
    denom = tl.zeros((BQ,), tl.float32)
    accum = tl.zeros((BQ, BD), tl.float32)

    for block in range(begin, end):
        physical = tl.load(TABLE + h * TH + block * TB)
        for offset in range(tl.cdiv(PAGE, 64)):
            token = offset * 64 + ti
            rows = physical * PAGE + token
            keys = tl.load(
                K + h * KH + rows[None, :] * KM + di[:, None] * KD,
                mask=(di[:, None] < D) & (token[None, :] < PAGE),
                other=0,
            ).to(tl.float32)
            scores = tl.dot(q, keys, input_precision="ieee") * SCALE
            scores = tl.where(token[None, :] < PAGE, scores, -float("inf"))
            new_maximum = tl.maximum(maximum, tl.max(scores, axis=1))
            correction = tl.exp(maximum - new_maximum)
            probabilities = tl.exp(scores - new_maximum[:, None])

            values = tl.load(
                V + h * VH + rows[:, None] * VM + di[None, :] * VD,
                mask=(token[:, None] < PAGE) & (di[None, :] < D),
                other=0,
            ).to(tl.float32)
            accum = accum * correction[:, None]
            accum = tl.dot(probabilities, values, accum, input_precision="ieee")
            denom = denom * correction + tl.sum(probabilities, axis=1)
            maximum = new_maximum

    scalar_base = (hb * SPLITS + split) * NQ
    tl.store(MAXIMUM + scalar_base + qi, maximum, mask=qi < NQ)
    tl.store(DENOM + scalar_base + qi, denom, mask=qi < NQ)
    tl.store(
        PART + (scalar_base + qi[:, None]) * D + di[None, :],
        accum,
        mask=(qi[:, None] < NQ) & (di[None, :] < D),
    )


@triton.jit
def _paged_attention_merge(
    PART, MAXIMUM, DENOM, OUT,
    OH: tl.constexpr, OM: tl.constexpr, OD: tl.constexpr,
    BATCH: tl.constexpr, NQ: tl.constexpr,
    D: tl.constexpr, BD: tl.constexpr,
    SPLITS: tl.constexpr, BS: tl.constexpr,
):
    hb = tl.program_id(0)
    query = tl.program_id(1)
    h = hb // BATCH
    b = hb % BATCH

    si = tl.arange(0, BS)
    di = tl.arange(0, BD)
    index = (hb * SPLITS + si) * NQ + query
    maxima = tl.load(MAXIMUM + index, mask=si < SPLITS, other=-float("inf"))
    denominators = tl.load(DENOM + index, mask=si < SPLITS, other=0)
    global_maximum = tl.max(maxima, axis=0)
    weights = tl.exp(maxima - global_maximum)
    denominator = tl.sum(weights * denominators, axis=0)
    partials = tl.load(
        PART + index[:, None] * D + di[None, :],
        mask=(si[:, None] < SPLITS) & (di[None, :] < D),
        other=0,
    )
    result = tl.sum(partials * weights[:, None], axis=0) / denominator
    tl.store(
        OUT + h * OH + (b * NQ + query) * OM + di * OD,
        result,
        mask=di < D,
    )


class ModelNew(nn.Module):
    def __init__(self, head_size: int, page_size: int = 64, sm_scale=0.5):
        super().__init__()
        self.head_size = int(head_size)
        self.page_size = int(page_size)
        self.sm_scale = float(sm_scale)

    def forward(self, q, k, v, kv_block_tables, batch_num_block_n):
        heads, total_queries, dimension = q.shape
        batch = batch_num_block_n.numel()
        queries = total_queries // batch
        used_blocks = kv_block_tables.shape[1]
        average_blocks = triton.cdiv(used_blocks, batch)
        splits = min(32, max(1, triton.cdiv(average_blocks, 8)))

        out = torch.empty_like(q)
        partials = torch.empty(
            (heads * batch, splits, queries, dimension),
            device=q.device,
            dtype=torch.float32,
        )
        maxima = torch.empty(
            (heads * batch, splits, queries),
            device=q.device,
            dtype=torch.float32,
        )
        denominators = torch.empty_like(maxima)

        _paged_attention_partials[(heads * batch, splits)](
            q, k, v, kv_block_tables, batch_num_block_n,
            partials, maxima, denominators,
            *q.stride(), *k.stride(), *v.stride(),
            *kv_block_tables.stride(), batch_num_block_n.stride(0),
            batch, queries, dimension,
            max(16, triton.next_power_of_2(dimension)),
            max(16, triton.next_power_of_2(queries)),
            self.page_size, splits, self.sm_scale,
            num_warps=4,
        )
        _paged_attention_merge[(heads * batch, queries)](
            partials, maxima, denominators, out,
            *out.stride(),
            batch, queries, dimension,
            triton.next_power_of_2(dimension),
            splits, triton.next_power_of_2(splits),
            num_warps=4,
        )
        return out
```