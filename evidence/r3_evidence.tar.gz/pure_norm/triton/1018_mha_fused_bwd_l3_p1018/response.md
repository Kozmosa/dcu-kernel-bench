```python
import math
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _rows(
    Q, K, V, DO, LSE, DELTA, OUT,
    SQ: tl.constexpr, SK: tl.constexpr,
    HQ: tl.constexpr, HK: tl.constexpr, D: tl.constexpr,
    QS: tl.constexpr, KS: tl.constexpr, VS: tl.constexpr, OS: tl.constexpr,
    SCALE: tl.constexpr, BD: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, GRAD: tl.constexpr,
):
    tile = tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // HQ
    h = bh % HQ
    kh = h // (HQ // HK)
    i = tile * BM + tl.arange(0, BM)
    d = tl.arange(0, BD)
    j0 = tl.arange(0, BN)

    q = tl.load(
        Q + b * QS[0] + i[:, None] * QS[1] + h * QS[2] + d[None, :] * QS[3],
        (i[:, None] < SQ) & (d[None, :] < D), 0,
    ).to(tl.float32)
    go = tl.load(
        DO + b * OS[0] + i[:, None] * OS[1] + h * OS[2] + d[None, :] * OS[3],
        (i[:, None] < SQ) & (d[None, :] < D), 0,
    ).to(tl.float32)

    if GRAD:
        lse = tl.load(LSE + bh * SQ + i, i < SQ, 0)
        delta = tl.load(DELTA + bh * SQ + i, i < SQ, 0)
        acc = tl.full((BM, BD), 0, tl.float32)
    else:
        maximum = tl.full((BM,), -float("inf"), tl.float32)
        denom = tl.full((BM,), 0, tl.float32)
        numerator = tl.full((BM,), 0, tl.float32)

    for start in range(tr.cdiv(SK, BN)):
        j = start * BN + j0
        k = tl.load(
            K + b * KS[0] + j[:, None] * KS[1] + kh * KS[2] + d[None, :] * KS[3],
            (j[:, None] < SK) & (d[None, :] < D), 0,
        ).to(tl.float32)
        v = tl.load(
            V + b * VS[0] + j[:, None] * VS[1] + kh * VS[2] + d[None, :] * VS[3],
            (j[:, None] < SK) & (d[None, :] < D), 0,
        ).to(tl.float32)
        scores = tl.dot(q, tl.trans(k), input_precision="ieee") * SCALE
        scores = tl.where(j[None, :] < SK, scores, -float("inf"))
        dp = tl.dot(go, tl.trans(v), input_precision="ieee")

        if GRAD:
            p = tl.exp(scores - lse[:, None])
            ds = p * (dp - delta[:, None])
            acc += tl.dot(ds, k, input_precision="ieee")
        else:
            new_max = tl.maximum(maximum, tl.max(scores, 1))
            correction = tl.exp(maximum - new_max)
            p = tl.exp(scores - new_max[:, None])
            denom = denom * correction + tl.sum(p, 1)
            numerator = numerator * correction + tl.sum(p * dp, 1)
            maximum = new_max

    if GRAD:
        offsets = ((b * SQ + i[:, None]) * HQ + h) * D + d[None, :]
        tl.store(OUT + offsets, acc * SCALE, (i[:, None] < SQ) & (d[None, :] < D))
    else:
        tl.store(LSE + bh * SQ + i, maximum + tl.log(denom), i < SQ)
        tl.store(DELTA + bh * SQ + i, numerator / denom, i < SQ)


@tr.jit
def _kv(
    Q, K, V, DO, LSE, DELTA, OUT,
    B: tl.constexpr, SQ: tl.constexpr, SK: tl.constexpr,
    HQ: tl.constexpr, HK: tl.constexpr, D: tl.constexpr,
    QS: tl.constexpr, KS: tl.constexpr, VS: tl.constexpr, OS: tl.constexpr,
    SCALE: tl.constexpr, BD: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr,
):
    tile = tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // HK
    kh = bh % HK
    j = tile * BN + tl.arange(0, BN)
    d = tl.arange(0, BD)
    i0 = tl.arange(0, BM)
    k = tl.load(
        K + b * KS[0] + j[:, None] * KS[1] + kh * KS[2] + d[None, :] * KS[3],
        (j[:, None] < SK) & (d[None, :] < D), 0,
    ).to(tl.float32)
    v = tl.load(
        V + b * VS[0] + j[:, None] * VS[1] + kh * VS[2] + d[None, :] * VS[3],
        (j[:, None] < SK) & (d[None, :] < D), 0,
    ).to(tl.float32)
    dk = tl.full((BN, BD), 0, tl.float32)
    dv = tl.full((BN, BD), 0, tl.float32)

    for gh in range(HQ // HK):
        h = kh * (HQ // HK) + gh
        # Accumulate each head independently before the GQA reduction.
        head_dk = tl.full((BN, BD), 0, tl.float32)
        head_dv = tl.full((BN, BD), 0, tl.float32)
        for start in range(tr.cdiv(SQ, BM)):
            i = start * BM + i0
            q = tl.load(
                Q + b * QS[0] + i[:, None] * QS[1] + h * QS[2] + d[None, :] * QS[3],
                (i[:, None] < SQ) & (d[None, :] < D), 0,
            ).to(tl.float32)
            go = tl.load(
                DO + b * OS[0] + i[:, None] * OS[1] + h * OS[2] + d[None, :] * OS[3],
                (i[:, None] < SQ) & (d[None, :] < D), 0,
            ).to(tl.float32)
            lse = tl.load(LSE + (b * HQ + h) * SQ + i, i < SQ, 0)
            delta = tl.load(DELTA + (b * HQ + h) * SQ + i, i < SQ, 0)
            scores = tl.dot(k, tl.trans(q), input_precision="ieee") * SCALE
            p = tl.exp(scores - lse[None, :])
            p = tl.where(i[None, :] < SQ, p, 0.0)
            dp = tl.dot(v, tl.trans(go), input_precision="ieee")
            ds = p * (dp - delta[None, :])
            head_dk += tl.dot(ds, q, input_precision="ieee")
            head_dv += tl.dot(p, go, input_precision="ieee")
        dk += head_dk * SCALE
        dv += head_dv

    nq: tl.constexpr = B * SQ * HQ * D
    nk: tl.constexpr = B * SK * HK * D
    offsets = ((b * SK + j[:, None]) * HK + kh) * D + d[None, :]
    mask = (j[:, None] < SK) & (d[None, :] < D)
    tl.store(OUT + nq + offsets, dk, mask)
    tl.store(OUT + nq + nk + offsets, dv, mask)


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, q, k, v, do):
        b, sq, hq, d = q.shape
        _, sk, hk, _ = k.shape
        assert hq % hk == 0, "num_q_heads must be an integer multiple of num_kv_heads"
        out = torch.empty(
            b * sq * hq * d + 2 * b * sk * hk * d,
            dtype=q.dtype, device=q.device,
        )
        lse = torch.empty((b, hq, sq), dtype=torch.float32, device=q.device)
        delta = torch.empty_like(lse)
        bd = max(16, tr.next_power_of_2(d))
        bm, bn = 16, 32
        common = dict(
            SQ=sq, SK=sk, HQ=hq, HK=hk, D=d,
            QS=q.stride(), KS=k.stride(), VS=v.stride(), OS=do.stride(),
            SCALE=self.sm_scale, BD=bd, BM=bm, BN=bn,
            num_warps=4,
        )
        _rows[(tr.cdiv(sq, bm), b * hq)](
            q, k, v, do, lse, delta, out, GRAD=False, **common
        )
        _rows[(tr.cdiv(sq, bm), b * hq)](
            q, k, v, do, lse, delta, out, GRAD=True, **common
        )
        _kv[(tr.cdiv(sk, bn), b * hk)](
            q, k, v, do, lse, delta, out, B=b, **common
        )
        return out
```