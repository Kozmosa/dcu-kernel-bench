import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _lse3(a, b, c):
    m = tl.maximum(tl.maximum(a, b), c)
    safe_m = tl.where(m == -float("inf"), 0.0, m)
    return m + tl.log(
        tl.exp(a - safe_m) + tl.exp(b - safe_m) + tl.exp(c - safe_m)
    )


@triton.jit
def _prepare(P, LP, Grad, SIZE: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    p = tl.load(P + i, i < SIZE, other=1).to(tl.float32)
    tl.store(LP + i, tl.log(p), i < SIZE)
    tl.store(Grad + i, 0.0, i < SIZE)


@triton.jit
def _forward_backward(
    LP, Labels, Lengths, Times, Alpha, Gamma, Out, Offsets,
    T: tl.constexpr, N: tl.constexpr, C: tl.constexpr,
    BLANK: tl.constexpr, SLOTS: tl.constexpr,
    B: tl.constexpr, BN: tl.constexpr,
):
    n = tl.program_id(0)
    ns = tl.arange(0, BN)
    lens = tl.load(Lengths + ns, ns < N, other=0).to(tl.int32)
    offset = tl.sum(tl.where(ns < n, lens, 0), 0)
    tl.store(Offsets + n, offset)
    length = tl.load(Lengths + n).to(tl.int32)
    tb = tl.load(Times + n).to(tl.int32)
    states = 2 * length + 1

    s = tl.arange(0, B)
    valid = s < states
    odd = (s & 1) != 0
    label = tl.load(
        Labels + offset + s // 2,
        valid & odd,
        other=BLANK,
    ).to(tl.int32)
    ext = tl.where(odd, label, BLANK)

    prev_ext = tl.gather(ext, tl.maximum(s - 2, 0), 0)
    next_ext = tl.gather(ext, tl.minimum(s + 2, B - 1), 0)
    skip_left = (s >= 2) & (ext != BLANK) & (ext != prev_ext)
    skip_right = (s + 2 < states) & (ext != BLANK) & (ext != next_ext)

    emission = tl.load(LP + n * C + ext, valid, other=0)
    a = tl.where(valid & (s < 2), emission, -float("inf"))
    base = n * T * SLOTS
    tl.store(Alpha + base + s, a, valid)

    for t in range(1, tb):
        left = tl.gather(a, tl.maximum(s - 1, 0), 0)
        left = tl.where(s >= 1, left, -float("inf"))
        jump = tl.gather(a, tl.maximum(s - 2, 0), 0)
        jump = tl.where(skip_left, jump, -float("inf"))
        emission = tl.load(
            LP + (t * N + n) * C + ext, valid, other=0
        )
        a = tl.where(valid, emission + _lse3(a, left, jump), -float("inf"))
        tl.store(Alpha + base + t * SLOTS + s, a, valid)

    terminal = valid & (s >= states - 2)
    end_a = tl.where(terminal, a, -float("inf"))
    m = tl.max(end_a, 0)
    log_z = m + tl.log(tl.sum(tl.exp(end_a - m), 0))
    tl.store(Out + n, -log_z)

    beta = tl.where(terminal, 0.0, -float("inf"))
    posterior = tl.exp(a + beta - log_z)
    tl.store(Gamma + base + (tb - 1) * SLOTS + s, posterior, valid)

    for step in range(1, tb):
        t = tb - 1 - step
        emission = tl.load(
            LP + ((t + 1) * N + n) * C + ext, valid, other=0
        )
        nxt = beta + emission
        right = tl.gather(nxt, tl.minimum(s + 1, B - 1), 0)
        right = tl.where(s + 1 < states, right, -float("inf"))
        jump = tl.gather(nxt, tl.minimum(s + 2, B - 1), 0)
        jump = tl.where(skip_right, jump, -float("inf"))
        beta = tl.where(valid, _lse3(nxt, right, jump), -float("inf"))
        a = tl.load(Alpha + base + t * SLOTS + s, valid, other=-float("inf"))
        posterior = tl.exp(a + beta - log_z)
        tl.store(Gamma + base + t * SLOTS + s, posterior, valid)


@triton.jit
def _accumulate(
    Gamma, Labels, Lengths, Times, Offsets, Grad,
    T: tl.constexpr, C: tl.constexpr, SLOTS: tl.constexpr,
    BLANK: tl.constexpr, B: tl.constexpr,
):
    t = tl.program_id(0)
    n = tl.program_id(1)
    tb = tl.load(Times + n).to(tl.int32)
    if t < tb:
        length = tl.load(Lengths + n).to(tl.int32)
        offset = tl.load(Offsets + n)
        s = tl.arange(0, B)
        valid = s < 2 * length + 1
        odd = (s & 1) != 0
        g = tl.load(
            Gamma + (n * T + t) * SLOTS + s, valid, other=0
        )
        blank_g = tl.sum(tl.where(odd, 0.0, g), 0)
        tl.store(Grad + (n * T + t) * C + BLANK, -blank_g)
        label = tl.load(
            Labels + offset + s // 2, valid & odd, other=BLANK
        ).to(tl.int32)
        tl.atomic_add(
            Grad + (n * T + t) * C + label,
            -g,
            valid & odd,
            sem="relaxed",
        )


@triton.jit
def _pack(
    P, Grad, Out,
    T: tl.constexpr, N: tl.constexpr, C: tl.constexpr,
    SIZE: tl.constexpr, BLOCK: tl.constexpr,
):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    k = i % C
    t = (i // C) % T
    n = i // (T * C)
    p = tl.load(P + (t * N + n) * C + k, i < SIZE, other=1).to(tl.float32)
    g = tl.load(Grad + i, i < SIZE, other=0)
    tl.store(Out + N + i, g / p, i < SIZE)


class ModelNew(nn.Module):
    def __init__(self, blank: int = 0):
        super().__init__()
        self.blank = int(blank)

    def forward(self, probs, labels, label_lengths, input_lengths):
        T, N, C = probs.shape
        size = T * N * C
        # Integer-valued floating inputs are converted in the device kernels.
        slots = 2 * min(T, labels.numel()) + 1
        block_states = triton.next_power_of_2(slots)
        warps = 4 if block_states <= 1024 else 8

        out = torch.empty(N + size, device=probs.device, dtype=probs.dtype)
        logp = torch.empty((T, N, C), device=probs.device, dtype=torch.float32)
        grad = torch.empty((N, T, C), device=probs.device, dtype=torch.float32)
        alpha = torch.empty((N, T, slots), device=probs.device, dtype=torch.float32)
        gamma = torch.empty_like(alpha)
        offsets = torch.empty((N,), device=probs.device, dtype=torch.int32)

        _prepare[(triton.cdiv(size, 512),)](
            probs, logp, grad, size, 512
        )
        _forward_backward[(N,)](
            logp, labels, label_lengths, input_lengths,
            alpha, gamma, out, offsets,
            T, N, C, self.blank, slots,
            block_states, triton.next_power_of_2(N),
            num_warps=warps, enable_fp_fusion=False,
        )
        _accumulate[(T, N)](
            gamma, labels, label_lengths, input_lengths, offsets, grad,
            T, C, slots, self.blank, block_states,
            num_warps=warps,
        )
        _pack[(triton.cdiv(size, 512),)](
            probs, grad, out, T, N, C, size, 512
        )
        return out
