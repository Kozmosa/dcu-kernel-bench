import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _clear(O, SIZE: tl.constexpr, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    tl.store(O + i, 0.0, i < SIZE)


@tr.jit
def _input_products(
    DY, WT, MASK, T, U,
    C: tl.constexpr, K: tl.constexpr, M: tl.constexpr,
    P: tl.constexpr, Q: tl.constexpr,
    BC: tl.constexpr, BP: tl.constexpr, BK: tl.constexpr,
):
    ci = tl.program_id(0) * BC + tl.arange(0, BC)
    qi = tl.program_id(1) * BP + tl.arange(0, BP)
    m = tl.program_id(2)
    ki = tl.arange(0, BK)
    batch = qi // P
    pos = qi % P
    modulation = tl.load(
        MASK + batch * M * P + m * P + pos, qi < Q, other=0
    )
    grad = tl.full((BC, BP), 0, tl.float32)
    unmodulated = tl.full((BC, BP), 0, tl.float32)
    for start in range(tr.cdiv(K, BK)):
        kk = start * BK + ki
        w = tl.load(
            WT + kk[None, :] * C * M + ci[:, None] * M + m,
            (ci[:, None] < C) & (kk[None, :] < K), other=0,
        )
        d = tl.load(
            DY + batch[None, :] * K * P + kk[:, None] * P + pos[None, :],
            (kk[:, None] < K) & (qi[None, :] < Q), other=0,
        )
        grad = tl.dot(w, d * modulation[None, :], grad, input_precision="ieee")
        unmodulated = tl.dot(w, d, unmodulated, input_precision="ieee")
    address = (m * C + ci[:, None]) * Q + qi[None, :]
    valid = (ci[:, None] < C) & (qi[None, :] < Q)
    tl.store(T + address, grad, valid)
    tl.store(U + address, unmodulated, valid)


@tr.jit
def _sampling(
    X, OFFSET, MASK, T, U, OUT,
    N: tl.constexpr, C: tl.constexpr, H: tl.constexpr, W: tl.constexpr,
    M: tl.constexpr, S: tl.constexpr, OH: tl.constexpr, OW: tl.constexpr,
    SH: tl.constexpr, SW: tl.constexpr,
    PH: tl.constexpr, PW: tl.constexpr,
    DH: tl.constexpr, DW: tl.constexpr,
    DGRAD: tl.constexpr, BC: tl.constexpr, BP: tl.constexpr,
):
    P: tl.constexpr = OH * OW
    Q: tl.constexpr = N * P
    DX_SIZE: tl.constexpr = N * C * H * W
    DO_SIZE: tl.constexpr = N * 2 * M * P
    ci = tl.program_id(0) * BC + tl.arange(0, BC)
    qi = tl.program_id(1) * BP + tl.arange(0, BP)
    m = tl.program_id(2)
    b = qi // P
    p = qi % P
    op = b * (2 * M * P) + 2 * m * P + p
    oy = tl.load(OFFSET + op, qi < Q, other=0)
    ox = tl.load(OFFSET + op + P, qi < Q, other=0)
    y = (p // OW * SH - PH + (m // S) * DH).to(tl.float32) + oy
    xx = (p % OW * SW - PW + (m % S) * DW).to(tl.float32) + ox
    yf = tl.floor(y)
    xf = tl.floor(xx)
    yi = yf.to(tl.int32)
    xi = xf.to(tl.int32)
    fy = y - yf
    fx = xx - xf
    a = (1.0 - fy) * (1.0 - fx)
    bb = (1.0 - fy) * fx
    cc = fy * (1.0 - fx)
    dd = fy * fx

    base = (b[None, :] * C + ci[:, None]) * H * W
    valid = (ci[:, None] < C) & (qi[None, :] < Q)
    v00 = valid & (yi[None, :] >= 0) & (yi[None, :] < H) & (xi[None, :] >= 0) & (xi[None, :] < W)
    v01 = valid & (yi[None, :] >= 0) & (yi[None, :] < H) & (xi[None, :] + 1 >= 0) & (xi[None, :] + 1 < W)
    v10 = valid & (yi[None, :] + 1 >= 0) & (yi[None, :] + 1 < H) & (xi[None, :] >= 0) & (xi[None, :] < W)
    v11 = valid & (yi[None, :] + 1 >= 0) & (yi[None, :] + 1 < H) & (xi[None, :] + 1 >= 0) & (xi[None, :] + 1 < W)
    p00 = base + yi[None, :] * W + xi[None, :]
    p01 = p00 + 1
    p10 = p00 + W
    p11 = p00 + W + 1
    x00 = tl.load(X + p00, v00, other=0)
    x01 = tl.load(X + p01, v01, other=0)
    x10 = tl.load(X + p10, v10, other=0)
    x11 = tl.load(X + p11, v11, other=0)
    value = ((a[None, :] * x00 + bb[None, :] * x01)
             + cc[None, :] * x10) + dd[None, :] * x11
    temporary = (m * C + ci[:, None]) * Q + qi[None, :]

    if DGRAD:
        g = tl.load(T + temporary, valid, other=0)
        u = tl.load(U + temporary, valid, other=0)
        tl.atomic_add(OUT + p00, g * a[None, :], v00, sem="relaxed")
        tl.atomic_add(OUT + p01, g * bb[None, :], v01, sem="relaxed")
        tl.atomic_add(OUT + p10, g * cc[None, :], v10, sem="relaxed")
        tl.atomic_add(OUT + p11, g * dd[None, :], v11, sem="relaxed")

        # Keep the four interpolation paths separate, as in the reference.
        ga = g * x00
        gb = g * x01
        gc = g * x10
        gd = g * x11
        gy = ((gd * fx[None, :] + gc * (1.0 - fx[None, :]))
              - gb * fx[None, :]) - ga * (1.0 - fx[None, :])
        gx = ((gd * fy[None, :] - gc * fy[None, :])
              + gb * (1.0 - fy[None, :])) - ga * (1.0 - fy[None, :])
        sy = tl.sum(gy, axis=0)
        sx = tl.sum(gx, axis=0)
        sm = tl.sum(u * value, axis=0)
        mp = b * M * P + m * P + p
        if BC >= C:
            tl.store(OUT + DX_SIZE + op, sy, qi < Q)
            tl.store(OUT + DX_SIZE + op + P, sx, qi < Q)
            tl.store(OUT + DX_SIZE + DO_SIZE + mp, sm, qi < Q)
        else:
            tl.atomic_add(OUT + DX_SIZE + op, sy, qi < Q, sem="relaxed")
            tl.atomic_add(OUT + DX_SIZE + op + P, sx, qi < Q, sem="relaxed")
            tl.atomic_add(OUT + DX_SIZE + DO_SIZE + mp, sm, qi < Q, sem="relaxed")
    else:
        tl.store(OUT + temporary, value, valid)


@tr.jit
def _weight_products(
    DY, V, MASK, OUT,
    C: tl.constexpr, K: tl.constexpr, M: tl.constexpr,
    P: tl.constexpr, Q: tl.constexpr,
    BO: tl.constexpr, BC: tl.constexpr, BQ: tl.constexpr,
):
    ko = tl.program_id(0) * BO + tl.arange(0, BO)
    ci = tl.program_id(1) * BC + tl.arange(0, BC)
    m = tl.program_id(2)
    rq = tl.arange(0, BQ)
    acc = tl.full((BO, BC), 0, tl.float32)
    for start in range(tr.cdiv(Q, BQ)):
        q = start * BQ + rq
        batch = q // P
        pos = q % P
        modulation = tl.load(
            MASK + batch * M * P + m * P + pos, q < Q, other=0
        )
        d = tl.load(
            DY + batch[None, :] * K * P + ko[:, None] * P + pos[None, :],
            (ko[:, None] < K) & (q[None, :] < Q), other=0,
        )
        v = tl.load(
            V + (m * C + ci[None, :]) * Q + q[:, None],
            (q[:, None] < Q) & (ci[None, :] < C), other=0,
        )
        acc = tl.dot(d * modulation[None, :], v, acc, input_precision="ieee")
    tl.store(
        OUT + ko[:, None] * C * M + ci[None, :] * M + m,
        acc, (ko[:, None] < K) & (ci[None, :] < C),
    )


class ModelNew(nn.Module):
    def __init__(
        self, variant: str = "dgrad",
        stride_h: int = 1, stride_w: int = 1,
        pad_h: int = 1, pad_w: int = 1,
        dil_h: int = 1, dil_w: int = 1,
    ):
        super().__init__()
        assert variant in ("dgrad", "wrw"), "variant must be either dgrad or wrw"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)

    def forward(self, dy, weight, x, offset, mask):
        n, c, h, w = x.shape
        k, _, r, s = weight.shape
        oh, ow = dy.shape[2:]
        m = r * s
        p = oh * ow
        q = n * p
        args = (
            n, c, h, w, m, s, oh, ow,
            self.stride_h, self.stride_w,
            self.pad_h, self.pad_w, self.dil_h, self.dil_w,
        )
        bc = min(32, tr.next_power_of_2(c))
        bp = 32
        sample_grid = (tr.cdiv(c, bc), tr.cdiv(q, bp), m)

        if self.variant == "dgrad":
            size = n * c * h * w + 3 * n * m * p
            out = torch.empty((size,), dtype=torch.float32, device=x.device)
            t = torch.empty((m, c, q), dtype=torch.float32, device=x.device)
            u = torch.empty((m, c, q), dtype=torch.float32, device=x.device)
            _clear[(tr.cdiv(size, 1024),)](out, size, 1024)
            _input_products[(tr.cdiv(c, 16), tr.cdiv(q, 32), m)](
                dy, weight, mask, t, u, c, k, m, p, q,
                16, 32, 32, num_warps=4, enable_fp_fusion=False,
            )
            _sampling[sample_grid](
                x, offset, mask, t, u, out, *args,
                True, bc, bp, num_warps=4, enable_fp_fusion=False,
            )
            return out

        values = torch.empty((m, c, q), dtype=torch.float32, device=x.device)
        out = torch.empty((k, c, r, s), dtype=torch.float32, device=x.device)
        _sampling[sample_grid](
            x, offset, mask, values, values, values, *args,
            False, bc, bp, num_warps=4, enable_fp_fusion=False,
        )
        _weight_products[(tr.cdiv(k, 16), tr.cdiv(c, 32), m)](
            dy, values, mask, out, c, k, m, p, q,
            16, 32, 32, num_warps=4, enable_fp_fusion=False,
        )
        return out
