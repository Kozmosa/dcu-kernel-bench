import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _route_tiles(
    X, W, OUT, PART_SCORES, PART_IDS,
    M: tl.constexpr, K: tl.constexpr, N: tl.constexpr,
    XS0: tl.constexpr, XS1: tl.constexpr,
    WS0: tl.constexpr, WS1: tl.constexpr,
    SHARED: tl.constexpr,
    SINGLE: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    rows = tl.program_id(0) * BM + tl.arange(0, BM)
    tile_n = tl.program_id(1)
    cols = tile_n * BN + tl.arange(0, BN)
    ks = tl.arange(0, BK)

    acc = tl.full((BM, BN), 0.0, tl.float32)
    for start in range(tl.cdiv(K, BK)):
        kk = start * BK + ks
        a = tl.load(
            X + rows[:, None] * XS0 + kk[None, :] * XS1,
            mask=(rows[:, None] < M) & (kk[None, :] < K),
            other=0.0,
        ).to(tl.float32)
        b = tl.load(
            W + kk[:, None] * WS0 + cols[None, :] * WS1,
            mask=(kk[:, None] < K) & (cols[None, :] < N),
            other=0.0,
        ).to(tl.float32)
        acc = tl.dot(a, b, acc, input_precision="ieee")

    # Reduce the rounded sigmoid scores, since sigmoid saturation creates ties
    # that are not necessarily ties between the original logits.
    scores = tl.div_rn(1.0, 1.0 + tl.exp(-acc))
    scores = tl.where(cols[None, :] < N, scores, -float("inf"))
    best = tl.max(scores, axis=1)
    ids = tl.min(
        tl.where(
            (cols[None, :] < N) & (scores == best[:, None]),
            cols[None, :],
            2147483647,
        ),
        axis=1,
    )

    if SINGLE:
        if SHARED:
            tl.store(OUT + rows * 4, ids.to(tl.float32), rows < M)
            tl.store(OUT + rows * 4 + 1, N, rows < M)
            tl.store(OUT + rows * 4 + 2, best, rows < M)
            tl.store(OUT + rows * 4 + 3, 1.0, rows < M)
        else:
            tl.store(OUT + rows * 2, ids.to(tl.float32), rows < M)
            tl.store(OUT + rows * 2 + 1, best, rows < M)
    else:
        tl.store(PART_SCORES + tile_n * M + rows, best, rows < M)
        tl.store(PART_IDS + tile_n * M + rows, ids, rows < M)


@triton.jit
def _finish_route(
    PART_SCORES, PART_IDS, OUT,
    M: tl.constexpr, N: tl.constexpr, NT: tl.constexpr,
    SHARED: tl.constexpr,
    BR: tl.constexpr, BT: tl.constexpr,
):
    rows = tl.program_id(0) * BR + tl.arange(0, BR)
    tiles = tl.arange(0, BT)
    offsets = tiles[:, None] * M + rows[None, :]
    valid = (tiles[:, None] < NT) & (rows[None, :] < M)

    scores = tl.load(PART_SCORES + offsets, valid, other=-float("inf"))
    ids = tl.load(PART_IDS + offsets, valid, other=2147483647)
    best = tl.max(scores, axis=0)
    best_ids = tl.min(
        tl.where(scores == best[None, :], ids, 2147483647), axis=0
    )

    if SHARED:
        tl.store(OUT + rows * 4, best_ids.to(tl.float32), rows < M)
        tl.store(OUT + rows * 4 + 1, N, rows < M)
        tl.store(OUT + rows * 4 + 2, best, rows < M)
        tl.store(OUT + rows * 4 + 3, 1.0, rows < M)
    else:
        tl.store(OUT + rows * 2, best_ids.to(tl.float32), rows < M)
        tl.store(OUT + rows * 2 + 1, best, rows < M)


class ModelNew(nn.Module):
    def __init__(self, fused_shared_experts: bool = True):
        super().__init__()
        self.fused_shared_experts = bool(fused_shared_experts)

    def forward(self, x, w):
        assert x.dim() == 2 and w.dim() == 2, "x / w must be 2-D tensors"
        M, K = x.shape
        Kb, N = w.shape
        assert K == Kb, (
            "the last dimension of x must equal the number of rows of w"
        )
        assert N >= 1

        out = torch.empty(
            (M, 4 if self.fused_shared_experts else 2),
            device=x.device,
            dtype=torch.float32,
        )
        if M == 0:
            return out

        bm = 16
        bn = min(64, max(16, triton.next_power_of_2(N)))
        bk = 32
        nt = triton.cdiv(N, bn)

        if nt == 1:
            partial_scores = out
            partial_ids = out
        else:
            partial_scores = torch.empty(
                (nt, M), device=x.device, dtype=torch.float32
            )
            partial_ids = torch.empty(
                (nt, M), device=x.device, dtype=torch.int32
            )

        _route_tiles[(triton.cdiv(M, bm), nt)](
            x, w, out, partial_scores, partial_ids,
            M, K, N,
            x.stride(0), x.stride(1),
            w.stride(0), w.stride(1),
            self.fused_shared_experts, nt == 1,
            bm, bn, bk,
            num_warps=4,
        )

        if nt > 1:
            bt = triton.next_power_of_2(nt)
            br = max(1, min(32, 1024 // bt))
            br = triton.next_power_of_2(br)
            _finish_route[(triton.cdiv(M, br),)](
                partial_scores, partial_ids, out,
                M, N, nt, self.fused_shared_experts,
                br, bt,
                num_warps=4,
            )
        return out
