import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _attention(
    Q, K, V, QS, KS, Mask, Out,
    QSTR: tl.constexpr, KSTR: tl.constexpr, VSTR: tl.constexpr,
    QSSTR: tl.constexpr, KSSTR: tl.constexpr,
    MSTR: tl.constexpr, OSTR: tl.constexpr,
    HQ: tl.constexpr, GROUP: tl.constexpr,
    NQ: tl.constexpr, NK: tl.constexpr, D: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr,
):
    rows = tl.program_id(0) * BM + tl.arange(0, BM)
    bh = tl.program_id(1)
    b = bh // HQ
    h = bh % HQ
    kh = h // GROUP
    ds = tl.arange(0, D)
    cols = tl.arange(0, BN)

    q = tl.load(
        Q + b * QSTR[0] + h * QSTR[1]
        + rows[:, None] * QSTR[2] + ds[None, :] * QSTR[3],
        mask=rows[:, None] < NQ, other=0,
    ).to(tl.int8)
    qs = tl.load(
        QS + b * QSSTR[0] + h * QSSTR[1]
        + (rows // 128) * QSSTR[2],
        mask=rows < NQ, other=0,
    ).to(tl.float32)

    maximum = tl.full((BM,), float("-inf"), tl.float32)
    denominator = tl.zeros((BM,), tl.float32)
    accumulator = tl.zeros((BM, D), tl.float32)

    for start in range(tl.cdiv(NK, BN)):
        js = start * BN + cols
        k = tl.load(
            K + b * KSTR[0] + kh * KSTR[1]
            + ds[:, None] * KSTR[3] + js[None, :] * KSTR[2],
            mask=js[None, :] < NK, other=0,
        ).to(tl.int8)
        ks = tl.load(
            KS + b * KSSTR[0] + kh * KSSTR[1]
            + (js // 64) * KSSTR[2],
            mask=js < NK, other=0,
        ).to(tl.float32)
        valid = tl.load(
            Mask + rows[:, None] * MSTR[0] + js[None, :] * MSTR[1],
            mask=(rows[:, None] < NQ) & (js[None, :] < NK),
            other=0,
        ) != 0

        scores = tl.dot(q, k).to(tl.float32)
        scores = scores * qs[:, None]
        scores = scores * ks[None, :]
        scores = scores * 0.6931471805599453
        scores = tl.where(valid, scores, float("-inf"))

        new_maximum = tl.maximum(maximum, tl.max(scores, axis=1))
        safe_maximum = tl.where(
            new_maximum == float("-inf"), 0.0, new_maximum
        )
        correction = tl.exp(maximum - safe_maximum)
        probabilities = tl.exp(scores - safe_maximum[:, None])

        denominator = denominator * correction + tl.sum(probabilities, axis=1)
        accumulator = accumulator * correction[:, None]

        values = tl.load(
            V + b * VSTR[0] + kh * VSTR[1]
            + js[:, None] * VSTR[2] + ds[None, :] * VSTR[3],
            mask=js[:, None] < NK, other=0,
        ).to(tl.float16)

        # Two half-precision components retain float32 probability accuracy.
        p_hi = probabilities.to(tl.float16)
        p_lo = (probabilities - p_hi.to(tl.float32)).to(tl.float16)
        accumulator = tl.dot(p_hi, values, accumulator)
        accumulator = tl.dot(p_lo, values, accumulator)
        maximum = new_maximum

    result = accumulator / denominator[:, None]
    tl.store(
        Out + b * OSTR[0] + h * OSTR[1]
        + rows[:, None] * OSTR[2] + ds[None, :] * OSTR[3],
        result, mask=rows[:, None] < NQ,
    )


class ModelNew(nn.Module):
    def __init__(self, tensor_layout="HND"):
        super().__init__()
        assert tensor_layout in ("HND", "NHD"), (
            "tensor_layout only supports HND / NHD"
        )
        self.tensor_layout = tensor_layout

    def forward(self, q_int8, k_int8, v, q_scale, k_scale, attn_mask):
        nhd = self.tensor_layout == "NHD"

        def strides(t):
            s = t.stride()
            return (s[0], s[2], s[1], s[3]) if nhd else tuple(s)

        if nhd:
            batch, nq, hq, dim = q_int8.shape
            nk, hkv = k_int8.shape[1:3]
        else:
            batch, hq, nq, dim = q_int8.shape
            hkv, nk = k_int8.shape[1:3]

        assert hkv > 0 and hq % hkv == 0, (
            "num_q_heads must be an integer multiple of num_kv_heads"
        )
        out = torch.empty(
            q_int8.shape, device=q_int8.device, dtype=torch.float16
        )
        _attention[(tr.cdiv(nq, 32), batch * hq)](
            q_int8, k_int8, v, q_scale, k_scale, attn_mask, out,
            strides(q_int8), strides(k_int8), strides(v),
            tuple(q_scale.stride()), tuple(k_scale.stride()),
            tuple(attn_mask.stride()), strides(out),
            hq, hq // hkv, nq, nk, dim, 32, 64,
            num_warps=4, num_stages=2, enable_fp_fusion=False,
        )
        return out
