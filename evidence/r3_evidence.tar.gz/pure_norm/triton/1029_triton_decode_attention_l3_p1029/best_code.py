import math
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _paged_attention_split(
    Q, K, V, PT, LENS, PART, STATS,
    H: tl.constexpr, GROUP: tl.constexpr,
    DK: tl.constexpr, DV: tl.constexpr,
    PAGE: tl.constexpr, SPLITS: tl.constexpr, SCALE: tl.constexpr,
    Q0: tl.constexpr, Q1: tl.constexpr, Q2: tl.constexpr,
    K0: tl.constexpr, K1: tl.constexpr, K2: tl.constexpr, K3: tl.constexpr,
    V0: tl.constexpr, V1: tl.constexpr, V2: tl.constexpr, V3: tl.constexpr,
    P0: tl.constexpr, P1: tl.constexpr, L0: tl.constexpr,
    BK: tl.constexpr, BV: tl.constexpr, BT: tl.constexpr,
):
    bh = tl.program_id(0)
    split = tl.program_id(1)
    b = bh // H
    h = bh % H
    kh = h // GROUP
    length = tl.load(LENS + b * L0).to(tl.int32)

    tiles = tl.cdiv(length, BT)
    tiles_per_split = tl.cdiv(tiles, SPLITS)
    start = split * tiles_per_split * BT
    end = tl.minimum(start + tiles_per_split * BT, length)

    kd = tl.arange(0, BK)
    vd = tl.arange(0, BV)
    rows = tl.arange(0, BT)
    query = tl.load(
        Q + b * Q0 + h * Q1 + kd * Q2,
        mask=kd < DK, other=0,
    ).to(tl.float32) * SCALE

    maximum = tl.full((), -float("inf"), tl.float32)
    denominator = tl.full((), 0.0, tl.float32)
    accumulator = tl.full((BV,), 0.0, tl.float32)

    for base in range(start, end, BT):
        tokens = base + rows
        valid = tokens < end
        pages = tl.load(
            PT + b * P0 + (tokens // PAGE) * P1,
            mask=valid, other=0,
        ).to(tl.int64)
        offsets = tokens % PAGE

        keys = tl.load(
            K + pages[:, None] * K0
            + offsets[:, None] * K1
            + kh * K2 + kd[None, :] * K3,
            mask=valid[:, None] & (kd[None, :] < DK),
            other=0,
        ).to(tl.float32)

        logits = tl.sum(keys * query[None, :], axis=1)
        logits = tl.where(valid, logits, -float("inf"))
        new_maximum = tl.maximum(maximum, tl.max(logits, axis=0))
        correction = tl.exp(maximum - new_maximum)
        weights = tl.exp(logits - new_maximum)

        values = tl.load(
            V + pages[:, None] * V0
            + offsets[:, None] * V1
            + kh * V2 + vd[None, :] * V3,
            mask=valid[:, None] & (vd[None, :] < DV),
            other=0,
        ).to(tl.float32)

        accumulator = accumulator * correction + tl.sum(
            weights[:, None] * values, axis=0
        )
        denominator = denominator * correction + tl.sum(weights, axis=0)
        maximum = new_maximum

    part_index = bh * SPLITS + split
    tl.store(PART + part_index * DV + vd, accumulator, mask=vd < DV)
    tl.store(STATS + part_index * 2, maximum)
    tl.store(STATS + part_index * 2 + 1, denominator)


@triton.jit
def _paged_attention_merge(
    PART, STATS, OUT,
    DV: tl.constexpr, SPLITS: tl.constexpr,
    BS: tl.constexpr, BV: tl.constexpr,
):
    bh = tl.program_id(0)
    splits = tl.arange(0, BS)
    channels = tl.arange(0, BV)
    index = bh * SPLITS + splits

    maxima = tl.load(
        STATS + index * 2, mask=splits < SPLITS, other=-float("inf")
    )
    denominators = tl.load(
        STATS + index * 2 + 1, mask=splits < SPLITS, other=0.0
    )
    maximum = tl.max(maxima, axis=0)
    factors = tl.exp(maxima - maximum)
    denominator = tl.sum(denominators * factors, axis=0)
    partial = tl.load(
        PART + index[:, None] * DV + channels[None, :],
        mask=(splits[:, None] < SPLITS) & (channels[None, :] < DV),
        other=0.0,
    )
    result = tl.sum(partial * factors[:, None], axis=0) / denominator
    tl.store(OUT + bh * DV + channels, result, mask=channels < DV)


class ModelNew(nn.Module):
    def __init__(
        self, page_size: int, head_dim_qk: int, head_dim_v: int,
        num_kv_splits: int = 8, scale=None
    ):
        super().__init__()
        self.page_size = int(page_size)
        self.head_dim_qk = int(head_dim_qk)
        self.head_dim_v = int(head_dim_v)
        self.num_kv_splits = int(num_kv_splits)
        self.scale = (
            float(scale) if scale is not None
            else 1.0 / math.sqrt(head_dim_qk)
        )

    def forward(self, q, key_cache, value_cache, page_tables, seq_lens):
        batch, heads, dk = q.shape
        _, page_size, kv_heads, _ = key_cache.shape
        dv = value_cache.shape[-1]
        group = heads // kv_heads
        assert heads == kv_heads * group, (
            "num_q_heads must be an integer multiple of num_kv_heads"
        )
        assert page_size == self.page_size, (
            "the key_cache page size does not match the initialized page_size"
        )

        out = torch.empty(
            (batch, heads, dv), device=q.device, dtype=q.dtype
        )
        if batch == 0 or heads == 0:
            return out

        block_tokens = 32
        capacity_tiles = max(
            1, triton.cdiv(page_tables.shape[1] * page_size, block_tokens)
        )
        splits = min(max(1, self.num_kv_splits), capacity_tiles)
        partial = torch.empty(
            (batch * heads, splits, dv),
            device=q.device, dtype=torch.float32,
        )
        stats = torch.empty(
            (batch * heads, splits, 2),
            device=q.device, dtype=torch.float32,
        )

        _paged_attention_split[(batch * heads, splits)](
            q, key_cache, value_cache, page_tables, seq_lens, partial, stats,
            heads, group, dk, dv, page_size, splits, self.scale,
            *q.stride(),
            *key_cache.stride(),
            *value_cache.stride(),
            *page_tables.stride(),
            seq_lens.stride(0),
            triton.next_power_of_2(dk),
            triton.next_power_of_2(dv),
            block_tokens,
            num_warps=4,
            num_stages=1,
            enable_fp_fusion=False,
        )
        _paged_attention_merge[(batch * heads,)](
            partial, stats, out,
            dv, splits,
            triton.next_power_of_2(splits),
            triton.next_power_of_2(dv),
            num_warps=4,
            enable_fp_fusion=False,
        )
        return out
