import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _channel_partials(
    X, DY, Mean, Inv, PartialGamma, PartialBeta,
    C: tl.constexpr, G: tl.constexpr, R: tl.constexpr,
    HW: tl.constexpr, NT: tl.constexpr,
    BC: tl.constexpr, BS: tl.constexpr,
):
    cb = tl.program_id(0)
    tile = tl.program_id(1)
    n = tl.program_id(2)

    channels = cb * BC + tl.arange(0, BC)
    spatial = tile * BS + tl.arange(0, BS)
    group = n * G + channels // R
    mu = tl.load(Mean + group, channels < C, other=0)
    inv = tl.load(Inv + group, channels < C, other=0)

    offsets = (n * C + channels[:, None]) * HW + spatial[None, :]
    valid = (channels[:, None] < C) & (spatial[None, :] < HW)
    x = tl.load(X + offsets, valid, other=0).to(tl.float32)
    dy = tl.load(DY + offsets, valid, other=0).to(tl.float32)
    xhat = (x - mu[:, None]) * inv[:, None]

    dg = tl.sum(dy * xhat, axis=1)
    db = tl.sum(dy, axis=1)
    dst = (n * C + channels) * NT + tile
    tl.store(PartialGamma + dst, dg, channels < C)
    tl.store(PartialBeta + dst, db, channels < C)


@tr.jit
def _group_sums(
    PartialGamma, PartialBeta, Scale, Sums,
    C: tl.constexpr, G: tl.constexpr, R: tl.constexpr,
    NT: tl.constexpr, B: tl.constexpr,
):
    ng = tl.program_id(0)
    n = ng // G
    g = ng % G
    lane = tl.arange(0, B)
    s = tl.full((B,), 0, tl.float32)
    t = tl.full((B,), 0, tl.float32)

    for base in range(tr.cdiv(R * NT, B)):
        k = base * B + lane
        channel = g * R + k // NT
        index = (n * C + g * R) * NT + k
        valid = k < R * NT
        gamma = tl.load(PartialGamma + index, valid, other=0)
        beta = tl.load(PartialBeta + index, valid, other=0)
        scale = tl.load(Scale + channel, valid, other=0).to(tl.float32)
        s += beta * scale
        t += gamma * scale

    tl.store(Sums + 2 * ng, tl.sum(s, axis=0))
    tl.store(Sums + 2 * ng + 1, tl.sum(t, axis=0))


@tr.jit
def _parameter_sums(
    PartialGamma, PartialBeta, Out,
    N: tl.constexpr, C: tl.constexpr, HW: tl.constexpr,
    NT: tl.constexpr, B: tl.constexpr,
):
    channel = tl.program_id(0)
    lane = tl.arange(0, B)
    gamma = tl.full((B,), 0, tl.float32)
    beta = tl.full((B,), 0, tl.float32)

    for base in range(tr.cdiv(N * NT, B)):
        k = base * B + lane
        index = ((k // NT) * C + channel) * NT + k % NT
        valid = k < N * NT
        gamma += tl.load(PartialGamma + index, valid, other=0)
        beta += tl.load(PartialBeta + index, valid, other=0)

    end = N * C * HW
    tl.store(Out + end + channel, tl.sum(gamma, axis=0))
    tl.store(Out + end + C + channel, tl.sum(beta, axis=0))


@tr.jit
def _input_grad(
    X, DY, Scale, Mean, Inv, Sums, Out,
    TOTAL: tl.constexpr, C: tl.constexpr, G: tl.constexpr,
    R: tl.constexpr, HW: tl.constexpr, B: tl.constexpr,
):
    i = tl.program_id(0) * B + tl.arange(0, B)
    valid = i < TOTAL
    channel = (i // HW) % C
    ng = i // (R * HW)

    x = tl.load(X + i, valid, other=0).to(tl.float32)
    dy = tl.load(DY + i, valid, other=0).to(tl.float32)
    scale = tl.load(Scale + channel, valid, other=0).to(tl.float32)
    mu = tl.load(Mean + ng, valid, other=0)
    inv = tl.load(Inv + ng, valid, other=0)
    s = tl.load(Sums + 2 * ng, valid, other=0)
    t = tl.load(Sums + 2 * ng + 1, valid, other=0)

    xhat = (x - mu) * inv
    weighted_dy = dy * scale
    dx = (inv / (R * HW)) * ((R * HW) * weighted_dy - s - xhat * t)
    tl.store(Out + i, dx, valid)


class ModelNew(nn.Module):
    def __init__(self, groups: int = 2, eps: float = 1e-5):
        super().__init__()
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.groups = int(groups)
        self.eps = float(eps)

    def forward(self, x, dy, scale, mean, inv_var):
        n, c, h, w = x.shape
        g = self.groups
        assert 1 <= g <= c and c % g == 0, (
            "groups must divide the number of channels and 1 <= groups <= C"
        )
        assert mean.numel() == n * g and inv_var.numel() == n * g, (
            "mean/inv_var must be one-dimensional statistics of length N*G"
        )

        r = c // g
        hw = h * w
        total = n * c * hw
        bs = min(256, tr.next_power_of_2(hw))
        bc = min(32, max(1, 1024 // bs))
        nt = tr.cdiv(hw, bs)

        out = torch.empty(total + 2 * c, device=x.device, dtype=torch.float32)
        partial_gamma = torch.empty(
            (n * c * nt,), device=x.device, dtype=torch.float32
        )
        partial_beta = torch.empty_like(partial_gamma)
        sums = torch.empty((n * g * 2,), device=x.device, dtype=torch.float32)

        _channel_partials[(tr.cdiv(c, bc), nt, n)](
            x, dy, mean, inv_var, partial_gamma, partial_beta,
            c, g, r, hw, nt, bc, bs,
            num_warps=4, enable_fp_fusion=False,
        )
        group_block = min(1024, tr.next_power_of_2(r * nt))
        _group_sums[(n * g,)](
            partial_gamma, partial_beta, scale, sums,
            c, g, r, nt, group_block,
            num_warps=4, enable_fp_fusion=False,
        )
        parameter_block = min(1024, tr.next_power_of_2(n * nt))
        _parameter_sums[(c,)](
            partial_gamma, partial_beta, out,
            n, c, hw, nt, parameter_block,
            num_warps=4, enable_fp_fusion=False,
        )
        _input_grad[(tr.cdiv(total, 1024),)](
            x, dy, scale, mean, inv_var, sums, out,
            total, c, g, r, hw, 1024,
            num_warps=4, enable_fp_fusion=False,
        )
        return out
