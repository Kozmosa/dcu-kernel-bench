```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _residual_rms_mxfp4(
    X, W, R, OUT,
    N: tl.constexpr,
    XS0: tl.constexpr, XS1: tl.constexpr,
    RS0: tl.constexpr, RS1: tl.constexpr,
    WS: tl.constexpr,
    EPS: tl.constexpr,
    B: tl.constexpr,
):
    row = tl.program_id(0)
    col = tl.arange(0, B)
    valid = col < N

    x = tl.load(X + row * XS0 + col * XS1, valid, 0).to(tl.float32)
    r = tl.load(R + row * RS0 + col * RS1, valid, 0).to(tl.float32)
    w = tl.load(W + col * WS, valid, 0).to(tl.float32)

    s = x + r
    square_sum = tl.sum(s * s, axis=0)
    inv_rms = tl.rsqrt(square_sum * (1.0 / N) + EPS)
    norm = (s * inv_rms) * w
    norm = tl.where(valid, norm, 0.0)

    blocks = tl.reshape(norm, (B // 32, 32))
    amax = tl.max(tl.abs(blocks), axis=1)
    rounded_bits = (amax.to(tl.uint32, bitcast=True) + 0x200000) & 0xFF800000
    rounded_exp = ((rounded_bits >> 23) & 255).to(tl.int32)
    scale_exp = tl.maximum(tl.minimum(rounded_exp - 129, 127), -127)

    # Construct the normal fp32 power of two exactly, including 2**127.
    scale_bits = (127 - scale_exp).to(tl.uint32) << 23
    scale = scale_bits.to(tl.float32, bitcast=True)
    q = blocks * scale[:, None]

    bits = q.to(tl.uint32, bitcast=True)
    sign = (bits >> 28) & 8
    exponent = ((bits >> 23) & 255).to(tl.int32)
    mantissa = bits & 0x7FFFFF

    shift = 126 - exponent
    safe_shift = tl.minimum(tl.maximum(shift, 0), 31)
    subnormal_mantissa = (0x400000 | (mantissa >> 1)) >> safe_shift
    subnormal_mantissa = tl.where(shift >= 32, 0, subnormal_mantissa)
    mantissa = tl.where(exponent < 127, subnormal_mantissa, mantissa)
    exponent = tl.maximum(exponent, 126) - 126

    magnitude = (((exponent.to(tl.uint32) << 2) | (mantissa >> 21)) + 1) >> 1
    codes = sign | tl.minimum(magnitude, 7)
    flat_codes = tl.reshape(codes, (B,))
    shifted_codes = flat_codes << ((col & 1) * 4)
    packed = tl.sum(tl.reshape(shifted_codes, (B // 2, 2)), axis=1)

    num_scales: tl.constexpr = (N + 31) // 32
    out_stride: tl.constexpr = N // 2 + num_scales
    byte_col = tl.arange(0, B // 2)
    tl.store(
        OUT + row * out_stride + byte_col,
        packed.to(tl.uint8),
        byte_col < N // 2,
    )

    block_col = tl.arange(0, B // 32)
    tl.store(
        OUT + row * out_stride + N // 2 + block_col,
        (scale_exp + 127).to(tl.uint8),
        block_col < num_scales,
    )


class ModelNew(nn.Module):
    def __init__(self, dtype: str = "bfloat16", eps: float = 1e-6):
        super().__init__()
        self.dtype = getattr(torch, dtype)
        self.eps = float(eps)

    def forward(self, inp1, weight1, res1):
        m, n = inp1.shape
        out = torch.empty(
            (m, n // 2 + (n + 31) // 32),
            device=inp1.device,
            dtype=torch.uint8,
        )
        block = max(32, triton.next_power_of_2(n))
        num_warps = 4 if block <= 2048 else (8 if block <= 8192 else 16)
        _residual_rms_mxfp4[(m,)](
            inp1, weight1, res1, out,
            n,
            inp1.stride(0), inp1.stride(1),
            res1.stride(0), res1.stride(1),
            weight1.stride(0),
            self.eps,
            block,
            num_warps=num_warps,
            enable_fp_fusion=False,
        )
        return out
```