```python
import torch
import torch.nn as nn
import triton
import triton.language as tl
from triton.language.extra import libdevice


@triton.jit
def _activation_kernel(
    X, Y,
    TOTAL: tl.constexpr,
    N: tl.constexpr,
    STRIDE_M: tl.constexpr,
    STRIDE_N: tl.constexpr,
    NAME: tl.constexpr,
    GATED: tl.constexpr,
    ALPHA: tl.constexpr,
    LIMIT: tl.constexpr,
    BLOCK: tl.constexpr,
):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = i < TOTAL
    row = i // N
    col = i % N

    if GATED:
        if NAME == "swiglu_interleaved":
            base = row * STRIDE_M + (2 * col) * STRIDE_N
            up_offset = base + STRIDE_N
        else:
            base = row * STRIDE_M + col * STRIDE_N
            up_offset = base + N * STRIDE_N
        gate = tl.load(X + base, valid, other=0).to(tl.float32)
        up = tl.load(X + up_offset, valid, other=0).to(tl.float32)
    else:
        base = row * STRIDE_M + col * STRIDE_N
        gate = tl.load(X + base, valid, other=0).to(tl.float32)

    if NAME == "swiglustep":
        act = gate * (1.0 / (1.0 + tl.exp(-gate)))
        act = tl.minimum(act, LIMIT)
        up = tl.minimum(tl.maximum(up, -LIMIT), LIMIT)
        result = act * up
    elif NAME == "silu" or NAME == "swiglu_interleaved":
        if LIMIT is not None:
            gate = tl.minimum(gate, LIMIT)
            up = tl.minimum(tl.maximum(up, -LIMIT), LIMIT)
        if ALPHA is not None:
            act = gate * (1.0 / (1.0 + tl.exp(-(ALPHA * gate))))
            result = act * (up + 1.0)
        else:
            act = gate * (1.0 / (1.0 + tl.exp(-gate)))
            result = act * up
    elif NAME == "silu_no_mul":
        result = gate * (1.0 / (1.0 + tl.exp(-gate)))
    elif NAME == "gelu" or NAME == "gelu_no_mul":
        act = (0.5 * gate) * (
            1.0 + libdevice.erf(gate * 0.7071067811865476)
        )
        if GATED:
            result = act * up
        else:
            result = act
    elif NAME == "gelu_tanh" or NAME == "gelu_tanh_no_mul":
        cubic = ((0.044715 * gate) * gate) * gate
        inner = 0.7978845608028654 * (gate + cubic)
        act = (0.5 * gate) * (1.0 + libdevice.tanh(inner))
        if GATED:
            result = act * up
        else:
            result = act
    else:
        act = tl.maximum(gate, 0.0)
        result = act * act

    tl.store(Y + i, result, valid)


class ModelNew(nn.Module):
    def __init__(self, activation: str = "silu", alpha=None, limit=None):
        super().__init__()
        gated = ("silu", "gelu", "gelu_tanh", "swiglustep", "swiglu_interleaved")
        nomul = ("silu_no_mul", "gelu_no_mul", "gelu_tanh_no_mul", "relu2")
        name = str(activation).lower()
        assert name in gated or name in nomul, (
            "activation must be one of " + "/".join(gated + nomul) + " variants"
        )
        if name in ("gelu", "gelu_tanh"):
            assert alpha is None and limit is None, (
                "gelu / gelu_tanh do not accept alpha / limit"
            )
        if name == "swiglustep":
            assert alpha is None, "swiglustep does not accept alpha"
        if name == "silu" and alpha is not None:
            assert limit is not None, (
                "silu must set limit as well when alpha is set"
            )
        if name == "swiglustep" and limit is None:
            limit = 7.0
        if name == "swiglu_interleaved":
            alpha = 1.702 if alpha is None else alpha
            limit = 7.0 if limit is None else limit
        self.activation = name
        self.is_gated = name in gated
        self.alpha = None if alpha is None else float(alpha)
        self.limit = None if limit is None else float(limit)

    def forward(self, x):
        assert x.dim() == 2, "the input must be a 2D (M, n) tensor"
        m, n = x.shape
        if self.is_gated:
            assert n % 2 == 0, (
                "the gated variants require the last dimension n to be even"
            )
            n //= 2
        out = torch.empty((m, n), device=x.device, dtype=x.dtype)
        total = m * n
        if total == 0:
            return out
        block = 256 if total < 4096 else 1024
        with torch.cuda.device(x.device):
            _activation_kernel[(triton.cdiv(total, block),)](
                x, out,
                total, n,
                x.stride(0), x.stride(1),
                self.activation, self.is_gated,
                self.alpha if self.is_gated else None,
                self.limit if self.is_gated else None,
                block,
                num_warps=4,
                enable_fp_fusion=False,
            )
        return out
```