```python
import math
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _attention(
    Q, K, V, L, C, O,
    QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr,
    H: tl.constexpr, D: tl.constexpr, QLEN: tl.constexpr,
    BATCH: tl.constexpr, LB: tl.constexpr,
    SCALE: tl.constexpr, DEVICE_CAUSAL: tl.constexpr,
    CAUSAL: tl.constexpr, BD: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr,
):
    block = tl.program_id(0)
    h = tl.program_id(1)
    b = tl.program_id(2)
    bs = tl.arange(0, LB)
    lengths = tl.load(L + bs, bs < BATCH, 0).to(tl.int32)
    start = tl.sum(tl.where(bs < b, lengths, 0), 0)
    length = tl.load(L + b).to(tl.int32)
    causal = CAUSAL
    if DEVICE_CAUSAL:
        causal = tl.load(C).to(tl.int32) != 0

    rows = block * BM + tl.arange(0, BM)
    ds = tl.arange(0, BD)
    ns = tl.arange(0, BN)
    q = tl.load(
        Q + (b * QLEN + rows[:, None]) * QS0
        + h * QS1 + ds[None, :] * QS2,
        (rows[:, None] < QLEN) & (ds[None, :] < D), 0,
    ).to(tl.float32)
    m = tl.full((BM,), -float("inf"), tl.float32)
    z = tl.zeros((BM,), tl.float32)
    acc = tl.zeros((BM, BD), tl.float32)
    end = length
    if causal:
        end = tl.minimum(end, (block + 1) * BM)

    for base in range(0, end, BN):
        cols = base + ns
        k = tl.load(
            K + (start + cols[None, :]) * KS0
            + h * KS1 + ds[:, None] * KS2,
            (cols[None, :] < length) & (ds[:, None] < D), 0,
        ).to(tl.float32)
        scores = tl.dot(q, k, input_precision="ieee") * SCALE
        valid = cols[None, :] < length
        if causal:
            valid = valid & (cols[None, :] <= rows[:, None])
        scores = tl.where(valid, scores, -float("inf"))
        new_m = tl.maximum(m, tl.max(scores, 1))
        alpha = tl.exp(m - new_m)
        p = tl.exp(scores - new_m[:, None])
        v = tl.load(
            V + (start + cols[:, None]) * VS0
            + h * VS1 + ds[None, :] * VS2,
            (cols[:, None] < length) & (ds[None, :] < D), 0,
        ).to(tl.float32)
        acc = acc * alpha[:, None] + tl.dot(p, v, input_precision="ieee")
        z = z * alpha + tl.sum(p, 1)
        m = new_m

    result = acc / z[:, None]
    tl.store(
        O + ((b * QLEN + rows[:, None]) * H + h) * D + ds[None, :],
        result, (rows[:, None] < QLEN) & (ds[None, :] < D),
    )


@tr.jit
def _decode(
    Q, K, V, L, C, P, M, Z,
    QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr,
    H: tl.constexpr, D: tl.constexpr, QLEN: tl.constexpr,
    BATCH: tl.constexpr, LB: tl.constexpr,
    SCALE: tl.constexpr, DEVICE_CAUSAL: tl.constexpr,
    CAUSAL: tl.constexpr, SPLITS: tl.constexpr,
    BD: tl.constexpr, BN: tl.constexpr,
):
    row_head = tl.program_id(0)
    split = tl.program_id(1)
    h = row_head % H
    row = row_head // H
    b = row // QLEN
    qi = row % QLEN
    bs = tl.arange(0, LB)
    lengths = tl.load(L + bs, bs < BATCH, 0).to(tl.int32)
    start = tl.sum(tl.where(bs < b, lengths, 0), 0)
    length = tl.load(L + b).to(tl.int32)
    causal = CAUSAL
    if DEVICE_CAUSAL:
        causal = tl.load(C).to(tl.int32) != 0
    if causal:
        length = tl.minimum(length, qi + 1)

    tiles = tl.cdiv(length, BN)
    tiles_per_split = tl.cdiv(tiles, SPLITS)
    begin = split * tiles_per_split * BN
    end = tl.minimum(length, begin + tiles_per_split * BN)
    ds = tl.arange(0, BD)
    ns = tl.arange(0, BN)
    q = tl.load(
        Q + row * QS0 + h * QS1 + ds * QS2, ds < D, 0
    ).to(tl.float32)
    m = tl.full((), -float("inf"), tl.float32)
    z = tl.full((), 0, tl.float32)
    acc = tl.zeros((BD,), tl.float32)

    for base in range(begin, end, BN):
        cols = base + ns
        k = tl.load(
            K + (start + cols[:, None]) * KS0
            + h * KS1 + ds[None, :] * KS2,
            (cols[:, None] < end) & (ds[None, :] < D), 0,
        ).to(tl.float32)
        scores = tl.sum(k * q[None, :], 1) * SCALE
        scores = tl.where(cols < end, scores, -float("inf"))
        new_m = tl.maximum(m, tl.max(scores, 0))
        alpha = tl.exp(m - new_m)
        p = tl.exp(scores - new_m)
        v = tl.load(
            V + (start + cols[:, None]) * VS0
            + h * VS1 + ds[None, :] * VS2,
            (cols[:, None] < end) & (ds[None, :] < D), 0,
        ).to(tl.float32)
        acc = acc * alpha + tl.sum(p[:, None] * v, 0)
        z = z * alpha + tl.sum(p, 0)
        m = new_m

    index = row_head * SPLITS + split
    tl.store(P + index * D + ds, acc, ds < D)
    tl.store(M + index, m)
    tl.store(Z + index, z)


@tr.jit
def _merge(P, M, Z, O, D: tl.constexpr, SPLITS: tl.constexpr,
           BS: tl.constexpr, BD: tl.constexpr):
    row = tl.program_id(0)
    ss = tl.arange(0, BS)
    ds = tl.arange(0, BD)
    index = row * SPLITS + ss
    m = tl.load(M + index, ss < SPLITS, -float("inf"))
    z = tl.load(Z + index, ss < SPLITS, 0)
    maximum = tl.max(m, 0)
    weights = tl.exp(m - maximum)
    p = tl.load(
        P + index[:, None] * D + ds[None, :],
        (ss[:, None] < SPLITS) & (ds[None, :] < D), 0,
    )
    denominator = tl.sum(z * weights, 0)
    result = tl.sum(p * weights[:, None], 0) / denominator
    tl.store(O + row * D + ds, result, ds < D)


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)

    def forward(self, q, k, v, kv_lens, causal):
        batch = kv_lens.numel()
        total_q, heads, dim = q.shape
        qlen = total_q // batch
        assert total_q == batch * qlen
        assert heads == k.shape[1] == v.shape[1]
        if kv_lens.device != q.device:
            kv_lens = kv_lens.to(device=q.device)
        device_causal = isinstance(causal, torch.Tensor) and causal.is_cuda
        if device_causal:
            causal_arg = causal
            causal_value = False
        else:
            causal_arg = kv_lens
            causal_value = bool(int(causal))

        out = torch.empty(q.shape, dtype=q.dtype, device=q.device)
        common = dict(
            QS0=q.stride(0), QS1=q.stride(1), QS2=q.stride(2),
            KS0=k.stride(0), KS1=k.stride(1), KS2=k.stride(2),
            VS0=v.stride(0), VS1=v.stride(1), VS2=v.stride(2),
            H=heads, D=dim, QLEN=qlen, BATCH=batch,
            LB=tr.next_power_of_2(batch), SCALE=self.sm_scale,
            DEVICE_CAUSAL=device_causal, CAUSAL=causal_value,
            BD=tr.next_power_of_2(dim),
        )
        if qlen <= 4:
            splits = min(32, max(1, tr.cdiv(k.shape[0], batch * 256)))
            count = total_q * heads
            partial = torch.empty((count, splits, dim), device=q.device, dtype=torch.float32)
            maxima = torch.empty((count, splits), device=q.device, dtype=torch.float32)
            sums = torch.empty_like(maxima)
            _decode[(count, splits)](
                q, k, v, kv_lens, causal_arg, partial, maxima, sums,
                **common, SPLITS=splits, BN=64, num_warps=4,
            )
            _merge[(count,)](
                partial, maxima, sums, out, D=dim, SPLITS=splits,
                BS=tr.next_power_of_2(splits), BD=tr.next_power_of_2(dim),
                num_warps=4,
            )
        else:
            _attention[(tr.cdiv(qlen, 16), heads, batch)](
                q, k, v, kv_lens, causal_arg, out,
                **common, BM=16, BN=32, num_warps=4,
            )
        return out
```