import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _histogram(X, Counts, N: tl.constexpr, E: tl.constexpr,
               C: tl.constexpr, K: tl.constexpr, H: tl.constexpr):
    c = tl.program_id(0)
    i = c * K + tl.arange(0, K)
    x = tl.load(X + i, i < N, other=E).to(tl.int32)
    h = tl.histogram(x, H)
    e = tl.arange(0, H)
    tl.store(Counts + e * C + c, h, e < E)


@tr.jit
def _count_large(X, Counts, N: tl.constexpr, E: tl.constexpr,
                 C: tl.constexpr, K: tl.constexpr):
    c = tl.program_id(0)
    e = tl.program_id(1)
    i = c * K + tl.arange(0, K)
    x = tl.load(X + i, i < N, other=-1).to(tl.int32)
    count = tl.sum(((i < N) & (x == e)).to(tl.int32), 0)
    tl.store(Counts + e * C + c, count)


@tr.jit
def _chunk_prefix(Counts, Prefix, Totals, C: tl.constexpr,
                  P: tl.constexpr):
    e = tl.program_id(0)
    c = tl.arange(0, P)
    count = tl.load(Counts + e * C + c, c < C, other=0)
    inclusive = tl.cumsum(count, 0)
    tl.store(Prefix + e * C + c, inclusive - count, c < C)
    tl.store(Totals + e, tl.sum(count, 0))


@tr.jit
def _initialize_and_offsets(Out, Totals, Starts,
                            N: tl.constexpr, E: tl.constexpr,
                            B: tl.constexpr, L1: tl.constexpr,
                            L2: tl.constexpr, K: tl.constexpr,
                            Q: tl.constexpr):
    pid = tl.program_id(0)
    i = pid * K + tl.arange(0, K)
    tl.store(Out + i, tl.where(i < L1, N, -1), i < L1 + L2)

    if pid == 0:
        r = tl.arange(0, Q)
        carry = tl.full((), 0, tl.int32)
        for base in range(tr.cdiv(E, Q)):
            e = base * Q + r
            count = tl.load(Totals + e, e < E, other=0)
            padded = ((count + B - 1) // B) * B
            prefix = tl.cumsum(padded, 0)
            tl.store(Starts + e, carry + prefix - padded, e < E)
            carry += tl.sum(padded, 0)
        tl.store(Out + L1 + L2, carry)


@tr.jit
def _scatter(X, Out, Counts, Prefix, Totals, Starts,
             N: tl.constexpr, E: tl.constexpr, B: tl.constexpr,
             C: tl.constexpr, K: tl.constexpr, L1: tl.constexpr):
    c = tl.program_id(0)
    e = tl.program_id(1)
    r = tl.arange(0, K)
    count = tl.load(Counts + e * C + c)
    start = tl.load(Starts + e)

    if count > 0:
        i = c * K + r
        x = tl.load(X + i, i < N, other=-1).to(tl.int32)
        match = (i < N) & (x == e)
        rank = tl.cumsum(match.to(tl.int32), 0) - 1
        preceding = tl.load(Prefix + e * C + c)
        destination = start + preceding + rank
        tl.store(Out + destination, i, match)

    total = tl.load(Totals + e)
    blocks = (total + B - 1) // B
    for base in range(c * K, blocks, C * K):
        b = base + r
        tl.store(Out + L1 + start // B + b, e, b < blocks)


@tr.jit
def _single_expert(Out, N: tl.constexpr, B: tl.constexpr,
                   L1: tl.constexpr, L2: tl.constexpr,
                   K: tl.constexpr):
    i = tl.program_id(0) * K + tl.arange(0, K)
    blocks = tr.cdiv(N, B)
    value = tl.where(
        i < L1,
        tl.where(i < N, i, N),
        tl.where(i < L1 + L2, tl.where(i < L1 + blocks, 0, -1),
                 blocks * B),
    )
    tl.store(Out + i, value, i < L1 + L2 + 1)


class ModelNew(nn.Module):
    def __init__(self, num_experts: int, block_size: int):
        super().__init__()
        self.num_experts = int(num_experts)
        self.block_size = int(block_size)

    def forward(self, topk_ids):
        n = topk_ids.numel()
        e = self.num_experts
        b = self.block_size
        l1 = n + e * (b - 1)
        l2 = tr.cdiv(l1, b)
        out = torch.empty(
            (l1 + l2 + 1,), device=topk_ids.device, dtype=torch.float32
        )

        if e == 1:
            _single_expert[(tr.cdiv(l1 + l2 + 1, 1024),)](
                out, n, b, l1, l2, 1024, num_warps=4
            )
            return out

        k = 1024
        c = tr.cdiv(n, k)
        counts = torch.empty((e, c), device=topk_ids.device, dtype=torch.int32)
        prefix = torch.empty_like(counts)
        totals = torch.empty((e,), device=topk_ids.device, dtype=torch.int32)
        starts = torch.empty_like(totals)

        if e <= 1024:
            _histogram[(c,)](
                topk_ids, counts, n, e, c, k, tr.next_power_of_2(e),
                num_warps=4,
            )
        else:
            _count_large[(c, e)](
                topk_ids, counts, n, e, c, k, num_warps=4
            )

        p = tr.next_power_of_2(c)
        _chunk_prefix[(e,)](
            counts, prefix, totals, c, p,
            num_warps=4 if p <= 2048 else 8,
        )
        _initialize_and_offsets[(tr.cdiv(l1 + l2, 1024),)](
            out, totals, starts, n, e, b, l1, l2, 1024,
            min(1024, tr.next_power_of_2(e)), num_warps=4,
        )
        _scatter[(c, e)](
            topk_ids, out, counts, prefix, totals, starts,
            n, e, b, c, k, l1, num_warps=4,
        )
        return out
