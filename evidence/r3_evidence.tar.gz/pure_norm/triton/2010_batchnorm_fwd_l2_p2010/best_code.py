import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _affine(
    X, Scale, Bias, Mean, Variance, Out,
    C: tl.constexpr, S: tl.constexpr, TOTAL: tl.constexpr,
    EPS: tl.constexpr, TRAINING: tl.constexpr, BLOCK: tl.constexpr,
):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = i < TOTAL
    c = (i // S) % C
    x = tl.load(X + i, valid, other=0).to(tl.float32)
    scale = tl.load(Scale + c, valid, other=0).to(tl.float32)
    bias = tl.load(Bias + c, valid, other=0).to(tl.float32)
    if TRAINING:
        mean = tl.load(Out + TOTAL + c, valid, other=0)
        inv = tl.load(Out + TOTAL + C + c, valid, other=0)
    else:
        mean = tl.load(Mean + c, valid, other=0).to(tl.float32)
        var = tl.load(Variance + c, valid, other=0).to(tl.float32)
        inv = tl.rsqrt(var + EPS)
    y = ((x - mean) * inv) * scale + bias
    tl.store(Out + i, y, valid)


@triton.jit
def _small_training(
    X, Scale, Bias, Mean, Variance, Out,
    C: tl.constexpr, S: tl.constexpr, M: tl.constexpr,
    TOTAL: tl.constexpr, EPS: tl.constexpr, MOM: tl.constexpr,
    BLOCK: tl.constexpr,
):
    c = tl.program_id(0)
    r = tl.arange(0, BLOCK)
    valid = r < M
    offset = (r // S) * (C * S) + c * S + r % S
    x = tl.load(X + offset, valid, other=0).to(tl.float32)
    avg = tl.sum(x, 0) / M
    centered = tl.where(valid, x - avg, 0.0)
    var = tl.sum(centered * centered, 0) / M
    inv = tl.rsqrt(var + EPS)
    scale = tl.load(Scale + c).to(tl.float32)
    bias = tl.load(Bias + c).to(tl.float32)
    y = ((x - avg) * inv) * scale + bias
    tl.store(Out + offset, y, valid)
    old_mean = tl.load(Mean + c).to(tl.float32)
    old_var = tl.load(Variance + c).to(tl.float32)
    new_mean = (1.0 - MOM) * old_mean + MOM * avg
    unbiased = var * (M / (M - 1))
    new_var = (1.0 - MOM) * old_var + MOM * unbiased
    tl.store(Out + TOTAL + c, avg)
    tl.store(Out + TOTAL + C + c, inv)
    tl.store(Out + TOTAL + 2 * C + c, new_mean)
    tl.store(Out + TOTAL + 3 * C + c, new_var)


@triton.jit
def _partial_stats(
    X, PartialMean, PartialM2,
    C: tl.constexpr, S: tl.constexpr, M: tl.constexpr,
    PARTS: tl.constexpr, BLOCK: tl.constexpr,
):
    c = tl.program_id(0)
    p = tl.program_id(1)
    r = p * BLOCK + tl.arange(0, BLOCK)
    valid = r < M
    offset = (r // S) * (C * S) + c * S + r % S
    x = tl.load(X + offset, valid, other=0).to(tl.float32)
    count = tl.minimum(BLOCK, M - p * BLOCK)
    avg = tl.sum(x, 0) / count
    delta = tl.where(valid, x - avg, 0.0)
    m2 = tl.sum(delta * delta, 0)
    tl.store(PartialMean + c * PARTS + p, avg)
    tl.store(PartialM2 + c * PARTS + p, m2)


@triton.jit
def _finish_stats(
    PartialMean, PartialM2, Mean, Variance, Out,
    C: tl.constexpr, M: tl.constexpr, TOTAL: tl.constexpr,
    PARTS: tl.constexpr, CHUNK: tl.constexpr, BLOCK: tl.constexpr,
    EPS: tl.constexpr, MOM: tl.constexpr,
):
    c = tl.program_id(0)
    p = tl.arange(0, BLOCK)
    valid = p < PARTS
    avg_p = tl.load(PartialMean + c * PARTS + p, valid, other=0)
    m2_p = tl.load(PartialM2 + c * PARTS + p, valid, other=0)
    count = tl.where(valid, tl.minimum(CHUNK, M - p * CHUNK), 0)
    avg = tl.sum(avg_p * count, 0) / M
    delta = avg_p - avg
    var = tl.sum(m2_p + delta * delta * count, 0) / M
    inv = tl.rsqrt(var + EPS)
    old_mean = tl.load(Mean + c).to(tl.float32)
    old_var = tl.load(Variance + c).to(tl.float32)
    new_mean = (1.0 - MOM) * old_mean + MOM * avg
    unbiased = var * (M / (M - 1))
    new_var = (1.0 - MOM) * old_var + MOM * unbiased
    tl.store(Out + TOTAL + c, avg)
    tl.store(Out + TOTAL + C + c, inv)
    tl.store(Out + TOTAL + 2 * C + c, new_mean)
    tl.store(Out + TOTAL + 3 * C + c, new_var)


class ModelNew(nn.Module):
    def __init__(self, variant: str = "training", eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        assert variant in ("inference", "training"), "variant must be one of inference / training"
        assert eps > 0, "eps must be positive"
        assert 0.0 <= momentum <= 1.0, "momentum must be in [0, 1]"
        self.variant = variant
        self.eps = float(eps)
        self.momentum = float(momentum)

    def forward(self, x, scale, bias, mean, variance):
        n, c, h, w = x.shape
        s = h * w
        m = n * s
        total = n * c * s

        if self.variant == "inference":
            out = torch.empty(x.shape, device=x.device, dtype=x.dtype)
            _affine[(triton.cdiv(total, 1024),)](
                x, scale, bias, mean, variance, out,
                c, s, total, self.eps, False, 1024,
                num_warps=4, enable_fp_fusion=False,
            )
            return out

        assert m >= 2, (
            "the training variant requires N*H*W >= 2 "
            "(the m/(m-1) unbiased correction factor of the running variance)"
        )
        out = torch.empty((total + 4 * c,), device=x.device, dtype=torch.float32)
        if m <= 4096:
            block = triton.next_power_of_2(m)
            _small_training[(c,)](
                x, scale, bias, mean, variance, out,
                c, s, m, total, self.eps, self.momentum, block,
                num_warps=4 if block <= 2048 else 8,
                enable_fp_fusion=False,
            )
            return out

        chunk = max(2048, triton.next_power_of_2(triton.cdiv(m, 4096)))
        parts = triton.cdiv(m, chunk)
        partial_mean = torch.empty((c, parts), device=x.device, dtype=torch.float32)
        partial_m2 = torch.empty_like(partial_mean)
        _partial_stats[(c, parts)](
            x, partial_mean, partial_m2,
            c, s, m, parts, chunk,
            num_warps=4 if chunk <= 2048 else 8,
            enable_fp_fusion=False,
        )
        _finish_stats[(c,)](
            partial_mean, partial_m2, mean, variance, out,
            c, m, total, parts, chunk, triton.next_power_of_2(parts),
            self.eps, self.momentum,
            num_warps=4, enable_fp_fusion=False,
        )
        _affine[(triton.cdiv(total, 1024),)](
            x, scale, bias, mean, variance, out,
            c, s, total, self.eps, True, 1024,
            num_warps=4, enable_fp_fusion=False,
        )
        return out
