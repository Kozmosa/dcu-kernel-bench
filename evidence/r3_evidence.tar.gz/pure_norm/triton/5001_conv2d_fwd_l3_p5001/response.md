```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _direct_conv(
    X, W, Y,
    C: tl.constexpr, H: tl.constexpr, IW: tl.constexpr,
    K: tl.constexpr, R: tl.constexpr, S: tl.constexpr,
    OH: tl.constexpr, OW: tl.constexpr, PAD: tl.constexpr,
    TOTAL: tl.constexpr, BLOCK: tl.constexpr,
):
    idx = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = idx < TOTAL
    spatial = idx % (OH * OW)
    k = (idx // (OH * OW)) % K
    batch = idx // (K * OH * OW)
    iy = spatial // OW - PAD
    ix = spatial % OW - PAD
    acc = tl.full((BLOCK,), 0, tl.float32)

    for c in range(C):
        for r in range(R):
            for s in range(S):
                yy = iy + r
                xx = ix + s
                a = tl.load(
                    X + ((batch * C + c) * H + yy) * IW + xx,
                    valid & (yy >= 0) & (yy < H) & (xx >= 0) & (xx < IW),
                    other=0.0,
                )
                b = tl.load(
                    W + ((k * C + c) * R + r) * S + s,
                    valid,
                    other=0.0,
                )
                acc = tl.fma(a, b, acc)

    tl.store(Y + idx, acc, valid)


@triton.jit
def _implicit_conv(
    X, W, Y,
    C: tl.constexpr, H: tl.constexpr, IW: tl.constexpr,
    K: tl.constexpr, R: tl.constexpr, S: tl.constexpr,
    OH: tl.constexpr, OW: tl.constexpr, PAD: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    spatial_tile = tl.program_id(0)
    channel_tile = tl.program_id(1)
    batch = tl.program_id(2)

    ks = channel_tile * BM + tl.arange(0, BM)
    ps = spatial_tile * BN + tl.arange(0, BN)
    ds = tl.arange(0, BK)
    py = ps // OW - PAD
    px = ps % OW - PAD
    acc = tl.full((BM, BN), 0.0, tl.float32)

    for base in range(tl.cdiv(C * R * S, BK)):
        red = base * BK + ds
        c = red // (R * S)
        r = (red // S) % R
        s = red % S

        weights = tl.load(
            W + ks[:, None] * (C * R * S) + red[None, :],
            (ks[:, None] < K) & (red[None, :] < C * R * S),
            other=0.0,
        )
        yy = r[:, None] + py[None, :]
        xx = s[:, None] + px[None, :]
        offsets = ((batch * C + c[:, None]) * H + yy) * IW + xx
        inputs = tl.load(
            X + offsets,
            (red[:, None] < C * R * S)
            & (ps[None, :] < OH * OW)
            & (yy >= 0) & (yy < H)
            & (xx >= 0) & (xx < IW),
            other=0.0,
        )
        acc = tl.dot(weights, inputs, acc, input_precision="ieee")

    out_offsets = (batch * K + ks[:, None]) * (OH * OW) + ps[None, :]
    tl.store(
        Y + out_offsets, acc,
        (ks[:, None] < K) & (ps[None, :] < OH * OW),
    )


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _DILATION = (1, 1)
    _PAD_SYMMETRIC = (1, 1)
    _PRE_PADDING = (2, 2)
    _POST_PADDING = (1, 1)

    def __init__(self, variant: str = "standard"):
        super().__init__()
        assert variant in ("standard", "asymmetric"), (
            "variant must be either standard or asymmetric"
        )
        self.variant = variant

    def forward(self, x, weight):
        n, c, h, w = x.shape
        k, wc, r, s = weight.shape
        assert wc == c
        pad = 2 if self.variant == "asymmetric" else 1
        added = 4 if self.variant == "asymmetric" else 3
        oh = h - r + added
        ow = w - s + added
        if oh <= 0 or ow <= 0:
            raise ValueError("Kernel size exceeds padded input size")
        out = torch.empty((n, k, oh, ow), device=x.device, dtype=x.dtype)

        with torch.cuda.device(x.device):
            if c * r * s <= 16:
                total = n * k * oh * ow
                _direct_conv[(triton.cdiv(total, 256),)](
                    x, weight, out,
                    c, h, w, k, r, s, oh, ow, pad, total, 256,
                    num_warps=4,
                )
            else:
                bm, bn, bk = 32, 64, 16
                _implicit_conv[
                    (triton.cdiv(oh * ow, bn), triton.cdiv(k, bm), n)
                ](
                    x, weight, out,
                    c, h, w, k, r, s, oh, ow, pad,
                    bm, bn, bk,
                    num_warps=4,
                    num_stages=2,
                )
        return out
```