```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _deformable_attention(
    Value,
    Shapes,
    Starts,
    Locations,
    Scores,
    Output,
    N_KEYS: tl.constexpr,
    HEADS: tl.constexpr,
    CHANNELS: tl.constexpr,
    QUERIES: tl.constexpr,
    POINTS: tl.constexpr,
    SAMPLES: tl.constexpr,
    BLOCK_S: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    row = tl.program_id(0)
    channel = tl.program_id(1) * BLOCK_D + tl.arange(0, BLOCK_D)
    batch = row // (QUERIES * HEADS)
    head = row % HEADS
    sample_lane = tl.arange(0, BLOCK_S)

    running_max = tl.full((), -float("inf"), tl.float32)
    running_sum = tl.full((), 0.0, tl.float32)
    accumulator = tl.full((BLOCK_D,), 0.0, tl.float32)

    for first in range(tl.cdiv(SAMPLES, BLOCK_S)):
        sample = first * BLOCK_S + sample_lane
        sample_valid = sample < SAMPLES
        level = sample // POINTS

        score = tl.load(
            Scores + row.to(tl.int64) * SAMPLES + sample,
            sample_valid,
            other=-float("inf"),
        ).to(tl.float32)
        new_max = tl.maximum(running_max, tl.max(score, 0))
        rescale = tl.exp(running_max - new_max)
        weight = tl.exp(score - new_max)

        height = tl.load(Shapes + 2 * level, sample_valid, other=1).to(tl.int64)
        width = tl.load(Shapes + 2 * level + 1, sample_valid, other=1).to(tl.int64)
        start = tl.load(Starts + level, sample_valid, other=0).to(tl.int64)

        location_offset = (row.to(tl.int64) * SAMPLES + sample) * 2
        x = tl.load(Locations + location_offset, sample_valid, other=0).to(tl.float32)
        y = tl.load(Locations + location_offset + 1, sample_valid, other=0).to(tl.float32)
        sx = x * width.to(tl.float32)
        sy = y * height.to(tl.float32)
        floor_x = tl.floor(sx)
        floor_y = tl.floor(sy)
        ix = floor_x.to(tl.int64)
        iy = floor_y.to(tl.int64)
        fx = sx - floor_x
        fy = sy - floor_y

        x0_valid = (ix >= 0) & (ix < width)
        x1_valid = (ix + 1 >= 0) & (ix + 1 < width)
        y0_valid = (iy >= 0) & (iy < height)
        y1_valid = (iy + 1 >= 0) & (iy + 1 < height)
        valid = sample_valid[:, None] & (channel[None, :] < CHANNELS)

        key = batch.to(tl.int64) * N_KEYS + start + iy * width + ix
        offset = (
            (key[:, None] * HEADS + head) * CHANNELS
            + channel[None, :]
        )
        column_stride = HEADS * CHANNELS
        row_stride = width[:, None] * column_stride

        v00 = tl.load(
            Value + offset,
            valid & x0_valid[:, None] & y0_valid[:, None],
            other=0.0,
        ).to(tl.float32)
        v01 = tl.load(
            Value + offset + column_stride,
            valid & x1_valid[:, None] & y0_valid[:, None],
            other=0.0,
        ).to(tl.float32)
        v10 = tl.load(
            Value + offset + row_stride,
            valid & x0_valid[:, None] & y1_valid[:, None],
            other=0.0,
        ).to(tl.float32)
        v11 = tl.load(
            Value + offset + row_stride + column_stride,
            valid & x1_valid[:, None] & y1_valid[:, None],
            other=0.0,
        ).to(tl.float32)

        w00 = (1.0 - fy) * (1.0 - fx)
        w01 = (1.0 - fy) * fx
        w10 = fy * (1.0 - fx)
        w11 = fy * fx
        interpolated = (
            v00 * w00[:, None]
            + v01 * w01[:, None]
            + v10 * w10[:, None]
            + v11 * w11[:, None]
        )

        accumulator = accumulator * rescale + tl.sum(
            interpolated * weight[:, None], axis=0
        )
        running_sum = running_sum * rescale + tl.sum(weight, axis=0)
        running_max = new_max

    result = accumulator / running_sum
    tl.store(
        Output + row.to(tl.int64) * CHANNELS + channel,
        result,
        channel < CHANNELS,
    )


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(
        self,
        value,
        spatial_shapes,
        level_start_index,
        sampling_locations,
        attention_weights,
    ):
        n, n_keys, heads, channels = value.shape
        queries = sampling_locations.shape[1]
        levels = spatial_shapes.shape[0]
        points = sampling_locations.shape[4]
        samples = levels * points

        output = torch.empty(
            (n, queries, heads * channels),
            dtype=value.dtype,
            device=value.device,
        )

        block_d = min(32, triton.next_power_of_2(channels))
        block_s = min(128, triton.next_power_of_2(samples))
        _deformable_attention[
            (n * queries * heads, triton.cdiv(channels, block_d))
        ](
            value,
            spatial_shapes,
            level_start_index,
            sampling_locations,
            attention_weights,
            output,
            N_KEYS=n_keys,
            HEADS=heads,
            CHANNELS=channels,
            QUERIES=queries,
            POINTS=points,
            SAMPLES=samples,
            BLOCK_S=block_s,
            BLOCK_D=block_d,
            num_warps=4,
            enable_fp_fusion=False,
        )
        return output
```