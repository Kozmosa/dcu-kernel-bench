```python
import math

import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _ragged_attention(
    Q, K, V, Starts, Lengths, Out,
    HQ: tl.constexpr,
    HKV: tl.constexpr,
    D: tl.constexpr,
    GROUP: tl.constexpr,
    NSEQS: tl.constexpr,
    SCALE: tl.constexpr,
    CAUSAL: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BD: tl.constexpr,
):
    block = tl.program_id(0)
    head = tl.program_id(1)

    # Sequence i owns virtual blocks starting at floor(start_i / BM) + i.
    # This provides enough blocks for each sequence without a host-side
    # maximum-length reduction or any device-to-host synchronization.
    lo = 0
    hi = NSEQS
    while lo < hi:
        mid = (lo + hi) // 2
        start_mid = tl.load(Starts + mid).to(tl.int32)
        virtual_start = start_mid // BM + mid
        before = virtual_start <= block
        lo = tl.where(before, mid + 1, lo)
        hi = tl.where(before, hi, mid)

    seq = lo - 1
    start = tl.load(Starts + seq).to(tl.int32)
    length = tl.load(Lengths + seq).to(tl.int32)
    tile = block - (start // BM + seq)
    first_row = tile * BM

    if first_row < length:
        rows = first_row + tl.arange(0, BM)
        cols = tl.arange(0, BN)
        dims = tl.arange(0, BD)
        kv_head = head // GROUP

        q = tl.load(
            Q + (start + rows[:, None]) * HQ * D
            + head * D + dims[None, :],
            mask=(rows[:, None] < length) & (dims[None, :] < D),
            other=0.0,
        ).to(tl.float32)

        running_max = tl.full((BM,), -float("inf"), tl.float32)
        denominator = tl.full((BM,), 0.0, tl.float32)
        accumulator = tl.full((BM, BD), 0.0, tl.float32)

        end = length
        if CAUSAL:
            end = tl.minimum(length, first_row + BM)

        for offset in range(0, end, BN):
            positions = offset + cols
            k = tl.load(
                K + (start + positions[None, :]) * HKV * D
                + kv_head * D + dims[:, None],
                mask=(positions[None, :] < length) & (dims[:, None] < D),
                other=0.0,
            ).to(tl.float32)

            scores = tl.dot(q, k, input_precision="ieee") * SCALE
            visible = positions[None, :] < length
            if CAUSAL:
                visible = visible & (positions[None, :] <= rows[:, None])
            scores = tl.where(visible, scores, -float("inf"))

            next_max = tl.maximum(running_max, tl.max(scores, axis=1))
            correction = tl.exp(running_max - next_max)
            probabilities = tl.exp(scores - next_max[:, None])

            v = tl.load(
                V + (start + positions[:, None]) * HKV * D
                + kv_head * D + dims[None, :],
                mask=(positions[:, None] < length) & (dims[None, :] < D),
                other=0.0,
            ).to(tl.float32)

            accumulator = accumulator * correction[:, None]
            accumulator = tl.dot(
                probabilities, v, accumulator, input_precision="ieee"
            )
            denominator = denominator * correction + tl.sum(
                probabilities, axis=1
            )
            running_max = next_max

        result = accumulator / denominator[:, None]
        tl.store(
            Out + (start + rows[:, None]) * HQ * D
            + head * D + dims[None, :],
            result,
            mask=(rows[:, None] < length) & (dims[None, :] < D),
        )


class ModelNew(nn.Module):
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)

    def forward(self, q, k, v, b_start_loc, b_seq_len):
        total, hq, d = q.shape
        hkv = k.shape[1]
        group = hq // hkv
        assert hq == hkv * group, (
            "num_q_heads must be an integer multiple of num_kv_heads"
        )
        assert k.shape[-1] == d and v.shape[-1] == d, (
            "the Q/K/V head dims must be identical"
        )

        out = torch.empty_like(q)
        sequences = b_seq_len.numel()
        if total == 0:
            return out

        scale = self.sm_scale if self.sm_scale is not None else 1.0 / math.sqrt(d)
        bm = 16
        _ragged_attention[(total // bm + sequences, hq)](
            q, k, v, b_start_loc, b_seq_len, out,
            HQ=hq,
            HKV=hkv,
            D=d,
            GROUP=group,
            NSEQS=sequences,
            SCALE=scale,
            CAUSAL=self.causal,
            BM=bm,
            BN=32,
            BD=triton.next_power_of_2(d),
            num_warps=4,
            num_stages=1,
        )
        return out
```