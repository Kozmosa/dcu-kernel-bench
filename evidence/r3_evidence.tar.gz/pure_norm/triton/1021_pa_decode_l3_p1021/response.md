```python
import math

import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _paged_attention_partial(
    Q, K, V, BT, SL, PART, STATS,
    HQ: tl.constexpr,
    GROUP: tl.constexpr,
    D: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    NPART: tl.constexpr,
    SCALE: tl.constexpr,
    QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr,
    KS2: tl.constexpr, KS3: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr,
    VS2: tl.constexpr, VS3: tl.constexpr,
    BTS0: tl.constexpr, BTS1: tl.constexpr,
    SLS0: tl.constexpr,
    TOKENS: tl.constexpr,
    DD: tl.constexpr,
):
    sh = tl.program_id(0)
    partition = tl.program_id(1)
    sequence = sh // HQ
    head = sh % HQ
    kv_head = head // GROUP

    length = tl.load(SL + sequence * SLS0)
    start = partition * TOKENS
    dims = tl.arange(0, DD)
    partial_base = (sh * NPART + partition) * D
    stats_base = (sh * NPART + partition) * 2

    if start < length:
        positions = start + tl.arange(0, TOKENS)
        valid = positions < length
        physical = tl.load(
            BT + sequence * BTS0 + (positions // BLOCK_SIZE) * BTS1,
            mask=valid,
            other=0,
        ).to(tl.int64)
        slots = positions % BLOCK_SIZE

        q = tl.load(
            Q + sequence * QS0 + head * QS1 + dims * QS2,
            mask=dims < D,
            other=0.0,
        ).to(tl.float32)
        q = q * SCALE

        k = tl.load(
            K
            + physical[:, None] * KS0
            + kv_head * KS1
            + slots[:, None] * KS2
            + dims[None, :] * KS3,
            mask=valid[:, None] & (dims[None, :] < D),
            other=0.0,
        ).to(tl.float32)

        logits = tl.sum(k * q[None, :], axis=1)
        logits = tl.where(valid, logits, -float("inf"))
        maximum = tl.max(logits, axis=0)
        weights = tl.exp(logits - maximum)
        denominator = tl.sum(weights, axis=0)

        v = tl.load(
            V
            + physical[:, None] * VS0
            + kv_head * VS1
            + slots[:, None] * VS2
            + dims[None, :] * VS3,
            mask=valid[:, None] & (dims[None, :] < D),
            other=0.0,
        ).to(tl.float32)
        numerator = tl.sum(weights[:, None] * v, axis=0)

        tl.store(PART + partial_base + dims, numerator, mask=dims < D)
        tl.store(STATS + stats_base, maximum)
        tl.store(STATS + stats_base + 1, denominator)
    else:
        tl.store(PART + partial_base + dims, 0.0, mask=dims < D)
        tl.store(STATS + stats_base, -float("inf"))
        tl.store(STATS + stats_base + 1, 0.0)


@triton.jit
def _paged_attention_merge(
    PART, STATS, OUT,
    HQ: tl.constexpr,
    D: tl.constexpr,
    NPART: tl.constexpr,
    OS0: tl.constexpr, OS1: tl.constexpr, OS2: tl.constexpr,
    PP: tl.constexpr,
    DD: tl.constexpr,
):
    sh = tl.program_id(0)
    partitions = tl.arange(0, PP)
    dims = tl.arange(0, DD)

    maximums = tl.load(
        STATS + (sh * NPART + partitions) * 2,
        mask=partitions < NPART,
        other=-float("inf"),
    )
    denominators = tl.load(
        STATS + (sh * NPART + partitions) * 2 + 1,
        mask=partitions < NPART,
        other=0.0,
    )
    maximum = tl.max(maximums, axis=0)
    factors = tl.exp(maximums - maximum)
    denominator = tl.sum(denominators * factors, axis=0)

    numerators = tl.load(
        PART + (sh * NPART + partitions[:, None]) * D + dims[None, :],
        mask=(partitions[:, None] < NPART) & (dims[None, :] < D),
        other=0.0,
    )
    result = tl.sum(numerators * factors[:, None], axis=0) / denominator
    tl.store(
        OUT + (sh // HQ) * OS0 + (sh % HQ) * OS1 + dims * OS2,
        result,
        mask=dims < D,
    )


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        batch, heads, head_size = query.shape
        kv_heads = key_cache.shape[1]
        block_size = key_cache.shape[2]
        group = heads // kv_heads
        assert heads == kv_heads * group, (
            "num_q_heads must be an integer multiple of num_kv_heads"
        )

        output = torch.empty(
            query.shape, dtype=query.dtype, device=query.device
        )
        if batch == 0 or heads == 0:
            return output

        tokens = 256
        capacity = block_tables.shape[1] * block_size
        partitions = triton.cdiv(capacity, tokens)
        padded_dim = triton.next_power_of_2(head_size)

        partial = torch.empty(
            (batch * heads, partitions, head_size),
            device=query.device,
            dtype=torch.float32,
        )
        stats = torch.empty(
            (batch * heads, partitions, 2),
            device=query.device,
            dtype=torch.float32,
        )

        _paged_attention_partial[(batch * heads, partitions)](
            query, key_cache, value_cache, block_tables, seq_lens,
            partial, stats,
            heads, group, head_size, block_size, partitions, self.scale,
            *query.stride(),
            *key_cache.stride(),
            *value_cache.stride(),
            *block_tables.stride(),
            seq_lens.stride(0),
            tokens, padded_dim,
            num_warps=8 if padded_dim >= 128 else 4,
            num_stages=1,
            enable_fp_fusion=False,
        )

        _paged_attention_merge[(batch * heads,)](
            partial, stats, output,
            heads, head_size, partitions,
            *output.stride(),
            triton.next_power_of_2(partitions), padded_dim,
            num_warps=4,
            num_stages=1,
            enable_fp_fusion=False,
        )
        return output
```