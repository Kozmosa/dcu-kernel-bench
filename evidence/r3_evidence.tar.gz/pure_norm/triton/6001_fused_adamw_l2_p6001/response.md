```python
import torch
import torch.nn as nn
import triton
import triton.language as tl
from triton.language.extra import libdevice


@triton.jit
def _adamw_update(
    Params,
    Grads,
    ExpAvg,
    ExpAvgSq,
    Step,
    Out,
    N: tl.constexpr,
    LR: tl.constexpr,
    BETA1: tl.constexpr,
    BETA2: tl.constexpr,
    EPS: tl.constexpr,
    DECAY: tl.constexpr,
    BIAS_CORRECTION: tl.constexpr,
    BLOCK: tl.constexpr,
):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    mask = offsets < N

    p = tl.load(Params + offsets, mask, other=0).to(tl.float32)
    g = tl.load(Grads + offsets, mask, other=0).to(tl.float32)
    m = tl.load(ExpAvg + offsets, mask, other=0).to(tl.float32)
    v = tl.load(ExpAvgSq + offsets, mask, other=0).to(tl.float32)

    p = p * DECAY
    m = BETA1 * m + (1.0 - BETA1) * g
    v = BETA2 * v + ((1.0 - BETA2) * g) * g

    if BIAS_CORRECTION:
        s = tl.load(Step).to(tl.float32)
        b1 = tl.full((), BETA1, tl.float32)
        b2 = tl.full((), BETA2, tl.float32)
        bc1 = 1.0 - libdevice.pow(b1, s)
        bc2 = 1.0 - libdevice.pow(b2, s)
        denom = tl.sqrt(v / bc2) + EPS
        update = (m / bc1) / denom
    else:
        denom = tl.sqrt(v) + EPS
        update = m / denom

    tl.store(Out + offsets, p - LR * update, mask)


class ModelNew(nn.Module):
    def __init__(
        self,
        variant: str = "adamw",
        lr: float = 1e-3,
        beta1: float = 0.9,
        beta2: float = 0.999,
        eps: float = 1e-8,
        weight_decay: float = 0.01,
    ):
        super().__init__()
        assert variant in ("adamw", "transformer_adamw"), (
            "variant must be one of adamw / transformer_adamw"
        )
        self.variant = variant
        self.lr = float(lr)
        self.beta1 = float(beta1)
        self.beta2 = float(beta2)
        self.eps = float(eps)
        self.weight_decay = float(weight_decay)

    def forward(self, params, grads, exp_avg, exp_avg_sq, step):
        out = torch.empty_like(params)
        n = params.numel()
        if n == 0:
            return out

        bias_correction = self.variant == "adamw"
        if bias_correction:
            if torch.is_tensor(step):
                step_arg = step.to(device=params.device, dtype=torch.float32)
            else:
                step_arg = torch.tensor(
                    float(step), device=params.device, dtype=torch.float32
                )
        else:
            step_arg = params

        block = 256 if n < 4096 else 1024
        with torch.cuda.device(params.device):
            _adamw_update[(triton.cdiv(n, block),)](
                params,
                grads,
                exp_avg,
                exp_avg_sq,
                step_arg,
                out,
                n,
                self.lr,
                self.beta1,
                self.beta2,
                self.eps,
                1.0 - self.lr * self.weight_decay,
                bias_correction,
                block,
                num_warps=4,
                enable_fp_fusion=False,
            )
        return out
```