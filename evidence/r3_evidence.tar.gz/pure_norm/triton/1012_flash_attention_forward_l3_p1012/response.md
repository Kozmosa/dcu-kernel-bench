```python
import math

import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _varlen_attention(
    Q, K, V, CQ, CK, CAUSAL, O,
    TQ: tl.constexpr,
    NS: tl.constexpr,
    GROUP: tl.constexpr,
    D: tl.constexpr,
    QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr,
    OS0: tl.constexpr, OS1: tl.constexpr, OS2: tl.constexpr,
    SCALE: tl.constexpr,
    CAUSAL_POINTER: tl.constexpr,
    CAUSAL_VALUE: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BD: tl.constexpr,
):
    tile = tl.program_id(0)
    head = tl.program_id(1)
    kv_head = head // GROUP
    first = tile * BM
    last = tl.minimum(first + BM, TQ)

    if CAUSAL_POINTER:
        causal = tl.load(CAUSAL) != 0
    else:
        causal = CAUSAL_VALUE

    # Locate the segment containing the first query in this global tile.
    lo = 0
    hi = NS
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        boundary = tl.load(CQ + mid)
        left = boundary <= first
        lo = tl.where(left, mid, lo)
        hi = tl.where(left, hi, mid)

    seq = lo
    sq = tl.load(CQ + seq)
    rows = first + tl.arange(0, BM)
    dims = tl.arange(0, BD)
    cols = tl.arange(0, BN)

    # A tile may cross segment boundaries; each segment is processed separately.
    while sq < last:
        eq = tl.load(CQ + seq + 1)
        sk = tl.load(CK + seq)
        ek = tl.load(CK + seq + 1)
        lq = eq - sq
        lk = ek - sk
        valid_rows = (rows >= sq) & (rows < eq) & (rows < TQ)

        q = tl.load(
            Q + rows[:, None] * QS0 + head * QS1 + dims[None, :] * QS2,
            mask=valid_rows[:, None] & (dims[None, :] < D),
            other=0,
        ).to(tl.float32)

        maximum = tl.full((BM,), -float("inf"), tl.float32)
        denominator = tl.full((BM,), 0.0, tl.float32)
        accumulator = tl.full((BM, BD), 0.0, tl.float32)

        stop = lk
        if causal:
            stop = tl.minimum(lk, last - sq + lk - lq)

        for start in range(0, stop, BN):
            keys = start + cols
            k = tl.load(
                K + (sk + keys[None, :]) * KS0
                + kv_head * KS1 + dims[:, None] * KS2,
                mask=(keys[None, :] < lk) & (dims[:, None] < D),
                other=0,
            ).to(tl.float32)

            scores = tl.dot(q, k, input_precision="ieee") * SCALE
            allowed = valid_rows[:, None] & (keys[None, :] < lk)
            if causal:
                allowed = allowed & (
                    keys[None, :] <= rows[:, None] - sq + lk - lq
                )
            scores = tl.where(allowed, scores, -float("inf"))

            next_maximum = tl.maximum(maximum, tl.max(scores, axis=1))
            next_maximum = tl.where(valid_rows, next_maximum, 0.0)
            correction = tl.exp(maximum - next_maximum)
            probabilities = tl.exp(scores - next_maximum[:, None])

            v = tl.load(
                V + (sk + keys[:, None]) * VS0
                + kv_head * VS1 + dims[None, :] * VS2,
                mask=(keys[:, None] < lk) & (dims[None, :] < D),
                other=0,
            ).to(tl.float32)

            accumulator = accumulator * correction[:, None]
            accumulator += tl.dot(
                probabilities, v, input_precision="ieee"
            )
            denominator = (
                denominator * correction + tl.sum(probabilities, axis=1)
            )
            maximum = next_maximum

        result = accumulator / tl.where(
            valid_rows, denominator, 1.0
        )[:, None]
        tl.store(
            O + rows[:, None] * OS0 + head * OS1 + dims[None, :] * OS2,
            result,
            mask=valid_rows[:, None] & (dims[None, :] < D),
        )

        seq += 1
        sq = eq


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = (
            float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v, cu_seqlens_q, cu_seqlens_k, causal):
        total_q, heads_q, head_dim = q.shape
        heads_k = k.shape[1]
        assert heads_q % heads_k == 0
        num_seqs = cu_seqlens_q.numel() - 1

        out = torch.empty(q.shape, dtype=q.dtype, device=q.device)
        if total_q == 0:
            return out

        if cu_seqlens_q.device != q.device:
            cu_seqlens_q = cu_seqlens_q.to(device=q.device)
        if cu_seqlens_k.device != q.device:
            cu_seqlens_k = cu_seqlens_k.to(device=q.device)

        causal_pointer = isinstance(causal, torch.Tensor)
        if causal_pointer:
            if causal.device != q.device:
                causal = causal.to(device=q.device)
            causal_arg = causal
            causal_value = False
        else:
            causal_arg = q
            causal_value = bool(int(causal))

        block_m = 16
        block_n = 32
        _varlen_attention[
            (triton.cdiv(total_q, block_m), heads_q)
        ](
            q, k, v, cu_seqlens_q, cu_seqlens_k, causal_arg, out,
            total_q, num_seqs, heads_q // heads_k, head_dim,
            *q.stride(), *k.stride(), *v.stride(), *out.stride(),
            self.sm_scale, causal_pointer, causal_value,
            block_m, block_n, max(16, triton.next_power_of_2(head_dim)),
            num_warps=4,
            num_stages=1,
        )
        return out
```