import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _expert_swiglu(
    A, B, AS, BS, W, IDS, OUT,
    K: tl.constexpr, N: tl.constexpr, TOPK: tl.constexpr,
    A0: tl.constexpr, A1: tl.constexpr,
    B0: tl.constexpr, B1: tl.constexpr, B2: tl.constexpr,
    AS0: tl.constexpr, AS1: tl.constexpr,
    BS0: tl.constexpr, BS1: tl.constexpr, BS2: tl.constexpr,
    W0: tl.constexpr, W1: tl.constexpr,
    I0: tl.constexpr, I1: tl.constexpr,
    QUANT: tl.constexpr, MUL: tl.constexpr,
    SCALE_N: tl.constexpr, SCALE_K: tl.constexpr,
    TILE_N: tl.constexpr, TILE_K: tl.constexpr,
):
    route = tl.program_id(0)
    token = route // TOPK
    slot = route % TOPK
    expert = tl.load(IDS + token * I0 + slot * I1).to(tl.int64)

    n = tl.program_id(1) * TILE_N + tl.arange(0, TILE_N)
    rk = tl.arange(0, TILE_K)
    gate_sum = tl.full((TILE_N, TILE_K), 0, tl.float32)
    up_sum = tl.full((TILE_N, TILE_K), 0, tl.float32)

    for start in range(tl.cdiv(K, TILE_K)):
        k = start * TILE_K + rk
        av = tl.load(
            A + token * A0 + k * A1, mask=k < K, other=0
        ).to(tl.float32)
        gate = tl.load(
            B + expert * B0 + n[:, None] * B1 + k[None, :] * B2,
            mask=(n[:, None] < N) & (k[None, :] < K),
            other=0,
        ).to(tl.float32)
        up = tl.load(
            B + expert * B0 + (N + n[:, None]) * B1 + k[None, :] * B2,
            mask=(n[:, None] < N) & (k[None, :] < K),
            other=0,
        ).to(tl.float32)

        if QUANT:
            a_scale = tl.load(
                AS + token * AS0 + (k // SCALE_K) * AS1,
                mask=k < K, other=0,
            )
            gate_scale = tl.load(
                BS + expert * BS0
                + (n[:, None] // SCALE_N) * BS1
                + (k[None, :] // SCALE_K) * BS2,
                mask=(n[:, None] < N) & (k[None, :] < K),
                other=0,
            )
            up_scale = tl.load(
                BS + expert * BS0
                + ((N + n[:, None]) // SCALE_N) * BS1
                + (k[None, :] // SCALE_K) * BS2,
                mask=(n[:, None] < N) & (k[None, :] < K),
                other=0,
            )
            av = av * a_scale
            gate = gate * gate_scale
            up = up * up_scale

        gate_sum = gate_sum + gate * av[None, :]
        up_sum = up_sum + up * av[None, :]

    g = tl.sum(gate_sum, axis=1)
    u = tl.sum(up_sum, axis=1)
    if MUL:
        weight = tl.load(W + token * W0 + slot * W1).to(tl.float32)
        g = g * weight
        u = u * weight

    result = (g / (1.0 + tl.exp(-g))) * u
    tl.store(OUT + route * N + n, result, mask=n < N)


class ModelNew(nn.Module):
    def __init__(self, mul_routed_weight=True, quant="dense", block_n=128, block_k=128):
        super().__init__()
        assert quant in ("dense", "fp8_block"), "quant must be one of dense / fp8_block"
        assert block_n >= 1 and block_k >= 1, "block_n / block_k must be >= 1"
        self.mul_routed_weight = bool(mul_routed_weight)
        self.quant = quant
        self.block_n = int(block_n)
        self.block_k = int(block_k)

    def forward(
        self, A, B, A_scale, B_scale, topk_weights, topk_ids,
        sorted_token_ids, expert_ids, num_tokens_post_padded,
    ):
        M, K = A.shape
        E, N2, _ = B.shape
        assert N2 % 2 == 0, "the 2N output dimension of B must be even"
        N = N2 // 2
        top_k = topk_ids.shape[1]
        quantized = self.quant == "fp8_block"

        if quantized:
            assert K % self.block_k == 0
            assert N2 % self.block_n == 0
            assert A_scale.shape == (M, K // self.block_k)
            assert B_scale.shape == (E, N2 // self.block_n, K // self.block_k)
            as0, as1 = A_scale.stride()
            bs0, bs1, bs2 = B_scale.stride()
        else:
            as0 = as1 = bs0 = bs1 = bs2 = 0

        out = torch.empty(
            (M * top_k, N), device=A.device, dtype=topk_weights.dtype
        )
        if M * top_k == 0 or N == 0:
            return out

        tile_k = min(1024, triton.next_power_of_2(K))
        tile_n = 4 if tile_k >= 512 else 8

        _expert_swiglu[(M * top_k, triton.cdiv(N, tile_n))](
            A, B, A_scale, B_scale, topk_weights, topk_ids, out,
            K, N, top_k,
            *A.stride(), *B.stride(),
            as0, as1, bs0, bs1, bs2,
            *topk_weights.stride(), *topk_ids.stride(),
            quantized, self.mul_routed_weight,
            self.block_n, self.block_k,
            tile_n, tile_k,
            num_warps=4,
            enable_fp_fusion=False,
        )
        return out
