import math

import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _attention_forward(
    Q, K, V, Slopes, Causal, Packed,
    SQ: tl.constexpr, SK: tl.constexpr,
    HQ: tl.constexpr, HK: tl.constexpr, D: tl.constexpr,
    QS0: tl.constexpr, QS1: tl.constexpr,
    QS2: tl.constexpr, QS3: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr,
    KS2: tl.constexpr, KS3: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr,
    VS2: tl.constexpr, VS3: tl.constexpr,
    AS0: tl.constexpr, AS1: tl.constexpr,
    SCALE: tl.constexpr,
    OUT_SIZE: tl.constexpr,
    CAUSAL_POINTER: tl.constexpr,
    CAUSAL_VALUE: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BD: tl.constexpr,
):
    query_block = tl.program_id(0)
    batch_head = tl.program_id(1)
    batch = batch_head // HQ
    head = batch_head % HQ
    kv_head = head // (HQ // HK)

    if CAUSAL_POINTER:
        is_causal = tl.load(Causal) != 0
    else:
        is_causal = CAUSAL_VALUE

    rows = query_block * BM + tl.arange(0, BM)
    dims = tl.arange(0, BD)
    cols = tl.arange(0, BN)
    aligned_rows = rows + SK - SQ

    q = tl.load(
        Q + batch * QS0 + rows[:, None] * QS1
        + head * QS2 + dims[None, :] * QS3,
        (rows[:, None] < SQ) & (dims[None, :] < D),
        other=0,
    ).to(tl.float32)
    slope = tl.load(Slopes + batch * AS0 + head * AS1).to(tl.float32)

    maximum = tl.full((BM,), -float("inf"), tl.float32)
    denominator = tl.zeros((BM,), tl.float32)
    accumulator = tl.zeros((BM, BD), tl.float32)

    end = SK
    if is_causal:
        end = tl.minimum(SK, tl.maximum(0, (query_block + 1) * BM + SK - SQ))

    for start in range(0, end, BN):
        keys = start + cols
        k = tl.load(
            K + batch * KS0 + keys[None, :] * KS1
            + kv_head * KS2 + dims[:, None] * KS3,
            (keys[None, :] < SK) & (dims[:, None] < D),
            other=0,
        ).to(tl.float32)

        scores = tl.dot(q, k, input_precision="ieee") * SCALE
        distance = tl.abs(aligned_rows[:, None] - keys[None, :]).to(tl.float32)
        scores = scores - slope * distance

        valid = (rows[:, None] < SQ) & (keys[None, :] < SK)
        if is_causal:
            valid = valid & (keys[None, :] <= aligned_rows[:, None])
        scores = tl.where(valid, scores, -float("inf"))

        next_maximum = tl.maximum(maximum, tl.max(scores, axis=1))
        safe_maximum = tl.where(next_maximum == -float("inf"), 0.0, next_maximum)
        correction = tl.exp(maximum - safe_maximum)
        probabilities = tl.exp(scores - safe_maximum[:, None])

        denominator = denominator * correction + tl.sum(probabilities, axis=1)
        accumulator = accumulator * correction[:, None]

        v = tl.load(
            V + batch * VS0 + keys[:, None] * VS1
            + kv_head * VS2 + dims[None, :] * VS3,
            (keys[:, None] < SK) & (dims[None, :] < D),
            other=0,
        ).to(tl.float32)
        accumulator = tl.dot(
            probabilities, v, accumulator, input_precision="ieee"
        )
        maximum = next_maximum

    has_keys = denominator > 0
    result = accumulator / tl.where(has_keys, denominator, 1.0)[:, None]
    result = result.to(Q.dtype.element_ty).to(tl.float32)
    lse = tl.where(
        has_keys,
        maximum + tl.log(tl.where(has_keys, denominator, 1.0)),
        0.0,
    )

    output_offsets = (
        ((batch * SQ + rows[:, None]) * HQ + head) * D + dims[None, :]
    )
    tl.store(
        Packed + output_offsets,
        result,
        (rows[:, None] < SQ) & (dims[None, :] < D),
    )
    tl.store(
        Packed + OUT_SIZE + batch_head * SQ + rows,
        lse,
        rows < SQ,
    )


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, sm_scale=None):
        super().__init__()
        self.sm_scale = (
            float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v, causal, alibi_slopes):
        batch, seqlen_q, nheads_q, head_dim = q.shape
        _, seqlen_k, nheads_k, _ = k.shape
        assert nheads_q % nheads_k == 0, (
            "num_q_heads must be an integer multiple of num_kv_heads"
        )

        causal_pointer = isinstance(causal, torch.Tensor) and causal.is_cuda
        if causal_pointer:
            causal_argument = causal
            causal_value = False
        else:
            causal_argument = q
            causal_value = bool(int(causal))

        out_size = batch * seqlen_q * nheads_q * head_dim
        packed = torch.empty(
            (out_size + batch * nheads_q * seqlen_q,),
            dtype=torch.float32,
            device=q.device,
        )
        if batch == 0 or nheads_q == 0 or seqlen_q == 0:
            return packed

        block_m = 16
        block_n = 32
        block_d = max(16, triton.next_power_of_2(head_dim))

        _attention_forward[
            (triton.cdiv(seqlen_q, block_m), batch * nheads_q)
        ](
            q, k, v, alibi_slopes, causal_argument, packed,
            seqlen_q, seqlen_k, nheads_q, nheads_k, head_dim,
            *q.stride(),
            *k.stride(),
            *v.stride(),
            *alibi_slopes.stride(),
            self.sm_scale,
            out_size,
            causal_pointer,
            causal_value,
            block_m, block_n, block_d,
            num_warps=4,
            num_stages=1,
            enable_fp_fusion=False,
        )
        return packed
