import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _fused_layernorm(
    X, R, W, B, O,
    N: tl.constexpr, EPS: tl.constexpr, BLOCK: tl.constexpr,
):
    row = tl.program_id(0)
    col = tl.arange(0, BLOCK)
    mask = col < N
    offset = row.to(tl.int64) * N + col

    x = tl.load(X + offset, mask, 0).to(tl.float32)
    r = tl.load(R + offset, mask, 0).to(tl.float32)
    s = (x + r).to(O.dtype.element_ty).to(tl.float32)
    mean = tl.sum(tl.where(mask, s, 0.0), 0) / N
    d = s - mean
    variance = tl.sum(tl.where(mask, d * d, 0.0), 0) / N
    inv_std = tl.rsqrt(variance + EPS)

    w = tl.load(W + col, mask, 0).to(tl.float32)
    b = tl.load(B + col, mask, 0).to(tl.float32)
    y = (d * inv_std) * w + b

    out_offset = row.to(tl.int64) * (2 * N) + col
    tl.store(O + out_offset, y, mask)
    tl.store(O + out_offset + N, s, mask)


@triton.jit
def _long_sum(
    X, R, O, SUM,
    N: tl.constexpr, PARTS: tl.constexpr, BLOCK: tl.constexpr,
):
    row = tl.program_id(0)
    part = tl.program_id(1)
    col = part * BLOCK + tl.arange(0, BLOCK)
    mask = col < N
    offset = row.to(tl.int64) * N + col
    x = tl.load(X + offset, mask, 0).to(tl.float32)
    r = tl.load(R + offset, mask, 0).to(tl.float32)
    s = (x + r).to(O.dtype.element_ty).to(tl.float32)
    tl.store(O + row.to(tl.int64) * (2 * N) + N + col, s, mask)
    total = tl.sum(tl.where(mask, s, 0.0), 0)
    tl.store(SUM + row.to(tl.int64) * PARTS + part, total)


@triton.jit
def _long_variance(
    O, SUM, VAR,
    N: tl.constexpr, PARTS: tl.constexpr,
    BLOCK: tl.constexpr, REDUCE: tl.constexpr,
):
    row = tl.program_id(0)
    part = tl.program_id(1)
    p = tl.arange(0, REDUCE)
    totals = tl.load(
        SUM + row.to(tl.int64) * PARTS + p, p < PARTS, 0
    )
    mean = tl.sum(totals, 0) / N

    col = part * BLOCK + tl.arange(0, BLOCK)
    mask = col < N
    s = tl.load(
        O + row.to(tl.int64) * (2 * N) + N + col, mask, 0
    ).to(tl.float32)
    d = s - mean
    variance_sum = tl.sum(tl.where(mask, d * d, 0.0), 0)
    tl.store(VAR + row.to(tl.int64) * PARTS + part, variance_sum)


@triton.jit
def _long_output(
    O, W, B, SUM, VAR,
    N: tl.constexpr, PARTS: tl.constexpr, EPS: tl.constexpr,
    BLOCK: tl.constexpr, REDUCE: tl.constexpr,
):
    row = tl.program_id(0)
    part = tl.program_id(1)
    p = tl.arange(0, REDUCE)
    stat_offset = row.to(tl.int64) * PARTS + p
    totals = tl.load(SUM + stat_offset, p < PARTS, 0)
    variances = tl.load(VAR + stat_offset, p < PARTS, 0)
    mean = tl.sum(totals, 0) / N
    inv_std = tl.rsqrt(tl.sum(variances, 0) / N + EPS)

    col = part * BLOCK + tl.arange(0, BLOCK)
    mask = col < N
    out_offset = row.to(tl.int64) * (2 * N) + col
    s = tl.load(O + out_offset + N, mask, 0).to(tl.float32)
    w = tl.load(W + col, mask, 0).to(tl.float32)
    b = tl.load(B + col, mask, 0).to(tl.float32)
    y = ((s - mean) * inv_std) * w + b
    tl.store(O + out_offset, y, mask)


class ModelNew(nn.Module):
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        self.eps = float(eps)

    def forward(self, x, residual, weight, bias):
        m, n = x.shape
        out = torch.empty((m, 2 * n), dtype=x.dtype, device=x.device)

        if n <= 16384:
            block = triton.next_power_of_2(n)
            warps = 4 if block <= 2048 else 8 if block <= 8192 else 16
            _fused_layernorm[(m,)](
                x, residual, weight, bias, out,
                N=n, EPS=self.eps, BLOCK=block,
                num_warps=warps, enable_fp_fusion=False,
            )
        else:
            block = 2048
            parts = triton.cdiv(n, block)
            reduce = triton.next_power_of_2(parts)
            sums = torch.empty((m, parts), dtype=torch.float32, device=x.device)
            variances = torch.empty_like(sums)
            grid = (m, parts)
            _long_sum[grid](
                x, residual, out, sums,
                N=n, PARTS=parts, BLOCK=block,
                num_warps=4, enable_fp_fusion=False,
            )
            _long_variance[grid](
                out, sums, variances,
                N=n, PARTS=parts, BLOCK=block, REDUCE=reduce,
                num_warps=4, enable_fp_fusion=False,
            )
            _long_output[grid](
                out, weight, bias, sums, variances,
                N=n, PARTS=parts, EPS=self.eps,
                BLOCK=block, REDUCE=reduce,
                num_warps=4, enable_fp_fusion=False,
            )
        return out
