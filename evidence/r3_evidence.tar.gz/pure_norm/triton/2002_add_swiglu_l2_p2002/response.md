```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _add_swiglu_forward_backward(
    BASE, DELTA, GRAD, OUTPUT,
    D: tl.constexpr,
    N: tl.constexpr,
    BASE_ROW: tl.constexpr,
    BASE_COL: tl.constexpr,
    DELTA_ROW: tl.constexpr,
    DELTA_COL: tl.constexpr,
    GRAD_ROW: tl.constexpr,
    GRAD_COL: tl.constexpr,
    BLOCK: tl.constexpr,
):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = i < N
    row = i // D
    col = i % D

    b = row * BASE_ROW + col * BASE_COL
    d = row * DELTA_ROW + col * DELTA_COL

    gate = (
        tl.load(BASE + b, valid, other=0).to(tl.float32)
        + tl.load(DELTA + d, valid, other=0).to(tl.float32)
    )
    up = (
        tl.load(BASE + b + D * BASE_COL, valid, other=0).to(tl.float32)
        + tl.load(DELTA + d + D * DELTA_COL, valid, other=0).to(tl.float32)
    )
    grad = tl.load(
        GRAD + row * GRAD_ROW + col * GRAD_COL, valid, other=0
    ).to(tl.float32)

    sig = 1.0 / (1.0 + tl.exp(-gate))
    silu = gate * sig
    activation = silu * up
    dgate = (grad * up) * (sig + silu * (1.0 - sig))
    dup = grad * silu

    out_offset = row * (3 * D) + col
    tl.store(OUTPUT + out_offset, activation, valid)
    tl.store(OUTPUT + out_offset + D, dgate, valid)
    tl.store(OUTPUT + out_offset + 2 * D, dup, valid)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, base, delta, grad_out):
        rows, width = base.shape
        d = width // 2
        output = torch.empty(
            (rows, 3 * d), device=base.device, dtype=base.dtype
        )
        n = rows * d
        if n:
            block = 256
            _add_swiglu_forward_backward[(triton.cdiv(n, block),)](
                base, delta, grad_out, output,
                d, n,
                base.stride(0), base.stride(1),
                delta.stride(0), delta.stride(1),
                grad_out.stride(0), grad_out.stride(1),
                block,
                num_warps=4,
                enable_fp_fusion=False,
            )
        return output
```