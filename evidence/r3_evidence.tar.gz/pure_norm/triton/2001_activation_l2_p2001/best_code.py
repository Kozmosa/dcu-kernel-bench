import torch
import torch.nn as nn
import triton
import triton.language as tl
from triton.language.extra import libdevice


@triton.jit
def _activation(a, ACTIVATION: tl.constexpr):
    if ACTIVATION == 0:
        return libdevice.div_rn(a, 1.0 + libdevice.exp(-a))
    elif ACTIVATION == 1:
        return (0.5 * a) * (
            1.0 + libdevice.erf(a * 0.7071067811865476)
        )
    else:
        cube = (a * a) * a
        inner = 0.7978845608028654 * (a + 0.044715 * cube)
        return (0.5 * a) * (1.0 + libdevice.tanh(inner))


@triton.jit
def _gated_mxfp4(
    X,
    Y,
    M: tl.constexpr,
    D: tl.constexpr,
    NB: tl.constexpr,
    SX0: tl.constexpr,
    SX1: tl.constexpr,
    ACTIVATION: tl.constexpr,
    GROUP: tl.constexpr,
):
    block = tl.program_id(0) * GROUP + tl.arange(0, GROUP)
    row = block // NB
    block_in_row = block % NB
    col = block_in_row[:, None] * 32 + tl.arange(0, 32)[None, :]
    valid = (row[:, None] < M) & (col < D)

    offset = row[:, None] * SX0 + col * SX1
    a = tl.load(X + offset, valid, other=0.0).to(tl.float32)
    b = tl.load(X + offset + D * SX1, valid, other=0.0).to(tl.float32)
    value = _activation(a, ACTIVATION) * b
    value = tl.where(valid, value, 0.0)

    maximum = tl.max(tl.abs(value), axis=1)
    rounded_bits = (
        maximum.to(tl.uint32, bitcast=True) + 0x200000
    ) & 0xFF800000
    exponent = ((rounded_bits >> 23) & 255).to(tl.int32)
    scale = tl.minimum(tl.maximum(exponent - 129, -127), 127)
    scale_byte = scale + 127

    inverse_scale = ((127 - scale).to(tl.uint32) << 23).to(
        tl.float32, bitcast=True
    )
    q = value * inverse_scale[:, None]
    bits = q.to(tl.uint32, bitcast=True)
    sign = (bits >> 28) & 8
    e = ((bits >> 23) & 255).to(tl.int32)
    mantissa = bits & 0x7FFFFF
    shift = tl.maximum(126 - e, 0)
    small_mantissa = (0x400000 | (mantissa >> 1)) >> tl.minimum(shift, 31)
    small_mantissa = tl.where(shift >= 32, 0, small_mantissa)
    mantissa = tl.where(e < 127, small_mantissa, mantissa)
    adjusted_e = tl.maximum(e, 126) - 126
    magnitude = (((adjusted_e << 2) | (mantissa >> 21)) + 1) >> 1
    code = sign | tl.minimum(magnitude, 7)

    even, odd = tl.split(tl.reshape(code, (GROUP, 16, 2)))
    packed = even | (odd << 4)
    packed_col = block_in_row[:, None] * 16 + tl.arange(0, 16)[None, :]
    output_width = D // 2 + NB
    tl.store(
        Y + row[:, None] * output_width + packed_col,
        packed.to(tl.uint8),
        (row[:, None] < M) & (packed_col < D // 2),
    )
    tl.store(
        Y + row * output_width + D // 2 + block_in_row,
        scale_byte.to(tl.uint8),
        row < M,
    )


class ModelNew(nn.Module):
    def __init__(self, activation: str = "silu"):
        super().__init__()
        assert activation in ("silu", "gelu", "gelu_tanh"), (
            "activation must be one of silu / gelu / gelu_tanh"
        )
        self.activation = activation

    def forward(self, x):
        M, N = x.shape
        assert N % 4 == 0, "N must be a multiple of 4"
        d = N // 2
        n_blocks = (d + 31) // 32
        result = torch.empty(
            (M, d // 2 + n_blocks), dtype=torch.uint8, device=x.device
        )
        if M == 0 or n_blocks == 0:
            return result

        activation = {"silu": 0, "gelu": 1, "gelu_tanh": 2}[self.activation]
        group = 8
        _gated_mxfp4[(triton.cdiv(M * n_blocks, group),)](
            x,
            result,
            M,
            d,
            n_blocks,
            x.stride(0),
            x.stride(1),
            activation,
            group,
            num_warps=4,
            enable_fp_fusion=False,
        )
        return result
