import math

import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _causal_attention(
    Q, K, V, O,
    QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr, QS3: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr, KS3: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr, VS3: tl.constexpr,
    L: tl.constexpr,
    HQ: tl.constexpr,
    GROUP: tl.constexpr,
    D: tl.constexpr,
    BD: tl.constexpr,
    SCALE: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
):
    query_block = tl.program_id(0)
    batch_head = tl.program_id(1)
    batch = batch_head // HQ
    head = batch_head % HQ
    kv_head = head // GROUP

    rows = query_block * BM + tl.arange(0, BM)
    dims = tl.arange(0, BD)
    cols = tl.arange(0, BN)

    q = tl.load(
        Q + batch * QS0 + head * QS1
        + rows[:, None] * QS2 + dims[None, :] * QS3,
        mask=(rows[:, None] < L) & (dims[None, :] < D),
        other=0.0,
    ).to(tl.float32)
    # Match the reference's float32 scaling before the dot product.
    q = q * SCALE

    maximum = tl.full((BM,), -float("inf"), tl.float32)
    denominator = tl.zeros((BM,), tl.float32)
    accumulator = tl.zeros((BM, BD), tl.float32)

    key_base = K + batch * KS0 + kv_head * KS1
    value_base = V + batch * VS0 + kv_head * VS1
    end = tl.minimum((query_block + 1) * BM, L)

    for start in range(0, end, BN):
        keys = start + cols
        k = tl.load(
            key_base + dims[:, None] * KS3 + keys[None, :] * KS2,
            mask=(dims[:, None] < D) & (keys[None, :] < L),
            other=0.0,
        ).to(tl.float32)

        scores = tl.dot(q, k, input_precision="ieee")
        scores = tl.where(
            (keys[None, :] <= rows[:, None]) & (keys[None, :] < L),
            scores,
            -float("inf"),
        )

        next_maximum = tl.maximum(maximum, tl.max(scores, axis=1))
        correction = tl.exp2((maximum - next_maximum) * 1.4426950408889634)
        probabilities = tl.exp2(
            (scores - next_maximum[:, None]) * 1.4426950408889634
        )

        denominator = denominator * correction + tl.sum(probabilities, axis=1)
        accumulator = accumulator * correction[:, None]

        values = tl.load(
            value_base + keys[:, None] * VS2 + dims[None, :] * VS3,
            mask=(keys[:, None] < L) & (dims[None, :] < D),
            other=0.0,
        ).to(tl.float32)
        accumulator += tl.dot(probabilities, values, input_precision="ieee")
        maximum = next_maximum

    result = accumulator / denominator[:, None]
    tl.store(
        O + batch_head * L * D + rows[:, None] * D + dims[None, :],
        result,
        mask=(rows[:, None] < L) & (dims[None, :] < D),
    )


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = (
            float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v):
        B, Hq, L, D = q.shape
        Bk, Hkv, Lk, Dk = k.shape
        assert B == Bk and L == Lk and D == Dk, (
            "task constraint: qo_len == kv_len (causal)"
        )
        assert Hkv > 0
        group = Hq // Hkv
        assert Hq == Hkv * group, (
            "num_qo_heads must be an integer multiple of num_kv_heads"
        )
        assert v.shape == k.shape

        out = torch.empty((B, Hq, L, D), device=q.device, dtype=q.dtype)
        if B == 0 or Hq == 0 or L == 0:
            return out

        with torch.cuda.device(q.device):
            _causal_attention[(triton.cdiv(L, 32), B * Hq)](
                q, k, v, out,
                *q.stride(),
                *k.stride(),
                *v.stride(),
                L=L,
                HQ=Hq,
                GROUP=group,
                D=D,
                BD=triton.next_power_of_2(D),
                SCALE=self.sm_scale,
                BM=32,
                BN=32,
                num_warps=4,
                num_stages=1,
                enable_fp_fusion=False,
            )
        return out
