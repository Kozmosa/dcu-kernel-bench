import math

import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _delta_kernel(
    O, DO, Delta,
    M: tl.constexpr, HQ: tl.constexpr, D: tl.constexpr,
    OS: tl.constexpr, DOS: tl.constexpr,
    BD: tl.constexpr, BR: tl.constexpr,
):
    r = tl.program_id(0) * BR + tl.arange(0, BR)
    bh = tl.program_id(1)
    b = bh // HQ
    h = bh % HQ
    d = tl.arange(0, BD)
    ov = tl.load(
        O + b * OS[0] + r[:, None] * OS[1] + h * OS[2]
        + d[None, :] * OS[3],
        (r[:, None] < M) & (d[None, :] < D), 0,
    ).to(tl.float32)
    go = tl.load(
        DO + b * DOS[0] + r[:, None] * DOS[1] + h * DOS[2]
        + d[None, :] * DOS[3],
        (r[:, None] < M) & (d[None, :] < D), 0,
    ).to(tl.float32)
    value = tl.sum(ov * go, 1)
    tl.store(Delta + bh * M + r, value, r < M)


@tr.jit
def _backward_kernel(
    Q, K, V, DO, LSE, Delta, Out,
    M: tl.constexpr, N: tl.constexpr,
    HQ: tl.constexpr, HK: tl.constexpr, D: tl.constexpr,
    GROUP: tl.constexpr, B: tl.constexpr,
    QS: tl.constexpr, KS: tl.constexpr, VS: tl.constexpr,
    DOS: tl.constexpr, LS: tl.constexpr,
    SCALE: tl.constexpr, CAUSAL: tl.constexpr,
    BD: tl.constexpr, TILE: tl.constexpr,
    KV_BLOCKS: tl.constexpr,
):
    tile = tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // HQ
    h = bh % HQ
    hk = h // GROUP
    d = tl.arange(0, BD)
    x = tl.arange(0, TILE)
    qsize: tl.constexpr = B * M * HQ * D
    ksize: tl.constexpr = B * N * HK * D

    if tile < KV_BLOCKS:
        if h % GROUP == 0:
            j = tile * TILE + x
            kval = tl.load(
                K + b * KS[0] + j[:, None] * KS[1] + hk * KS[2]
                + d[None, :] * KS[3],
                (j[:, None] < N) & (d[None, :] < D), 0,
            ).to(tl.float32)
            vval = tl.load(
                V + b * VS[0] + j[:, None] * VS[1] + hk * VS[2]
                + d[None, :] * VS[3],
                (j[:, None] < N) & (d[None, :] < D), 0,
            ).to(tl.float32)
            ak = tl.full((TILE, BD), 0, tl.float32)
            av = tl.full((TILE, BD), 0, tl.float32)

            for gh in range(GROUP):
                hh = h + gh
                head_k = tl.full((TILE, BD), 0, tl.float32)
                head_v = tl.full((TILE, BD), 0, tl.float32)
                start = 0
                if CAUSAL:
                    start = tl.maximum(0, tile * TILE + M - N)
                    start = (start // TILE) * TILE
                for base in range(start, M, TILE):
                    i = base + x
                    qval = tl.load(
                        Q + b * QS[0] + i[:, None] * QS[1] + hh * QS[2]
                        + d[None, :] * QS[3],
                        (i[:, None] < M) & (d[None, :] < D), 0,
                    ).to(tl.float32)
                    gval = tl.load(
                        DO + b * DOS[0] + i[:, None] * DOS[1] + hh * DOS[2]
                        + d[None, :] * DOS[3],
                        (i[:, None] < M) & (d[None, :] < D), 0,
                    ).to(tl.float32)
                    lval = tl.load(
                        LSE + b * LS[0] + hh * LS[1] + i * LS[2],
                        i < M, 0,
                    ).to(tl.float32)
                    delt = tl.load(Delta + (b * HQ + hh) * M + i, i < M, 0)
                    score = tl.dot(kval, tl.trans(qval), input_precision="ieee") * SCALE
                    valid = (j[:, None] < N) & (i[None, :] < M)
                    if CAUSAL:
                        valid = valid & (j[:, None] <= i[None, :] + N - M)
                    p = tl.exp(tl.where(valid, score - lval[None, :], -float("inf")))
                    dp = tl.dot(vval, tl.trans(gval), input_precision="ieee")
                    ds = p * (dp - delt[None, :])
                    head_k += tl.dot(ds, qval, input_precision="ieee")
                    head_v += tl.dot(p, gval, input_precision="ieee")
                ak += head_k * SCALE
                av += head_v

            out_offset = ((b * N + j[:, None]) * HK + hk) * D + d[None, :]
            mask = (j[:, None] < N) & (d[None, :] < D)
            tl.store(Out + qsize + out_offset, ak.to(K.dtype.element_ty).to(tl.float32), mask)
            tl.store(
                Out + qsize + ksize + out_offset,
                av.to(V.dtype.element_ty).to(tl.float32), mask,
            )
    else:
        i = (tile - KV_BLOCKS) * TILE + x
        qval = tl.load(
            Q + b * QS[0] + i[:, None] * QS[1] + h * QS[2]
            + d[None, :] * QS[3],
            (i[:, None] < M) & (d[None, :] < D), 0,
        ).to(tl.float32)
        gval = tl.load(
            DO + b * DOS[0] + i[:, None] * DOS[1] + h * DOS[2]
            + d[None, :] * DOS[3],
            (i[:, None] < M) & (d[None, :] < D), 0,
        ).to(tl.float32)
        lval = tl.load(
            LSE + b * LS[0] + h * LS[1] + i * LS[2], i < M, 0,
        ).to(tl.float32)
        delt = tl.load(Delta + bh * M + i, i < M, 0)
        aq = tl.full((TILE, BD), 0, tl.float32)
        end = N
        if CAUSAL:
            end = tl.minimum(N, (tile - KV_BLOCKS + 1) * TILE + N - M)
            end = tl.maximum(end, 0)
        for base in range(0, end, TILE):
            j = base + x
            kval = tl.load(
                K + b * KS[0] + j[:, None] * KS[1] + hk * KS[2]
                + d[None, :] * KS[3],
                (j[:, None] < N) & (d[None, :] < D), 0,
            ).to(tl.float32)
            vval = tl.load(
                V + b * VS[0] + j[:, None] * VS[1] + hk * VS[2]
                + d[None, :] * VS[3],
                (j[:, None] < N) & (d[None, :] < D), 0,
            ).to(tl.float32)
            score = tl.dot(qval, tl.trans(kval), input_precision="ieee") * SCALE
            valid = (i[:, None] < M) & (j[None, :] < N)
            if CAUSAL:
                valid = valid & (j[None, :] <= i[:, None] + N - M)
            p = tl.exp(tl.where(valid, score - lval[:, None], -float("inf")))
            dp = tl.dot(gval, tl.trans(vval), input_precision="ieee")
            ds = p * (dp - delt[:, None])
            aq += tl.dot(ds, kval, input_precision="ieee")

        result = (aq * SCALE).to(Q.dtype.element_ty).to(K.dtype.element_ty).to(tl.float32)
        offset = ((b * M + i[:, None]) * HQ + h) * D + d[None, :]
        tl.store(Out + offset, result, (i[:, None] < M) & (d[None, :] < D))


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, causal: int, scale=None):
        super().__init__()
        self.head_dim = int(head_dim)
        self.causal = bool(int(causal))
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)

    def forward(self, q, k, v, o, lse, do):
        B, M, HQ, D = q.shape
        _, N, HK, _ = k.shape
        group = HQ // HK
        assert HQ == HK * group, "num_q_heads must be an integer multiple of num_kv_heads"

        packed = torch.empty(
            (B * M * HQ + 2 * B * N * HK) * D,
            device=q.device, dtype=torch.float32,
        )
        delta = torch.empty((B, HQ, M), device=q.device, dtype=torch.float32)
        bd = max(16, tr.next_power_of_2(D))
        tile = 32

        _delta_kernel[(tr.cdiv(M, 16), B * HQ)](
            o, do, delta,
            M, HQ, D, o.stride(), do.stride(), bd, 16,
            num_warps=4,
        )
        _backward_kernel[(tr.cdiv(N, tile) + tr.cdiv(M, tile), B * HQ)](
            q, k, v, do, lse, delta, packed,
            M, N, HQ, HK, D, group, B,
            q.stride(), k.stride(), v.stride(), do.stride(), lse.stride(),
            self.sm_scale, self.causal, bd, tile, tr.cdiv(N, tile),
            num_warps=4,
            enable_fp_fusion=False,
        )
        return packed
