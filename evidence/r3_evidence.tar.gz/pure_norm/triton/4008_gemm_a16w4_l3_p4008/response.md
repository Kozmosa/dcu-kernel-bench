```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _small_m_partial(
    A, QW, S, QZ, P,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    G: tl.constexpr, NS: tl.constexpr,
    AS0: tl.constexpr, AS1: tl.constexpr,
    WS0: tl.constexpr, WS1: tl.constexpr,
    SS0: tl.constexpr, SS1: tl.constexpr,
    ZS0: tl.constexpr, ZS1: tl.constexpr,
    BN: tl.constexpr, BK: tl.constexpr,
):
    ni = tl.program_id(0) * BN + tl.arange(0, BN)
    ki = tl.program_id(1) * BK + tl.arange(0, BK)
    mi = tl.program_id(2)
    gi = ki // G

    packed_w = tl.load(
        QW + ni[:, None] * WS0 + (ki[None, :] // 2) * WS1,
        (ni[:, None] < N) & (ki[None, :] < K),
        other=0,
    ).to(tl.int32)
    w = (packed_w >> ((ki[None, :] & 1) * 4)) & 15
    packed_z = tl.load(
        QZ + gi[None, :] * ZS0 + (ni[:, None] // 2) * ZS1,
        (ni[:, None] < N) & (ki[None, :] < K),
        other=0,
    ).to(tl.int32)
    z = (packed_z >> ((ni[:, None] & 1) * 4)) & 15
    scale = tl.load(
        S + gi[None, :] * SS0 + ni[:, None] * SS1,
        (ni[:, None] < N) & (ki[None, :] < K),
        other=0,
    ).to(tl.float32)
    a = tl.load(
        A + mi * AS0 + ki * AS1, ki < K, other=0
    ).to(tl.float32)
    weight = (w - z).to(tl.float32) * scale
    result = tl.sum(weight * a[None, :], axis=1)
    tl.store(
        P + (mi * NS + tl.program_id(1)) * N + ni,
        result,
        ni < N,
    )


@triton.jit
def _finish_small_m(
    P, O, N: tl.constexpr, NS: tl.constexpr,
    BN: tl.constexpr, BS: tl.constexpr,
):
    n = tl.program_id(0) * BN + tl.arange(0, BN)
    s = tl.arange(0, BS)
    m = tl.program_id(1)
    values = tl.load(
        P + (m * NS + s[:, None]) * N + n[None, :],
        (s[:, None] < NS) & (n[None, :] < N),
        other=0,
    )
    result = tl.sum(values, axis=0)
    tl.store(O + m * N + n, result, n < N)


@triton.jit
def _quantized_gemm(
    A, QW, S, QZ, O,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    G: tl.constexpr,
    AS0: tl.constexpr, AS1: tl.constexpr,
    WS0: tl.constexpr, WS1: tl.constexpr,
    SS0: tl.constexpr, SS1: tl.constexpr,
    ZS0: tl.constexpr, ZS1: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    m = tl.program_id(0) * BM + tl.arange(0, BM)
    n = tl.program_id(1) * BN + tl.arange(0, BN)
    rk = tl.arange(0, BK)
    acc = tl.full((BM, BN), 0, tl.float32)

    for start in range(tl.cdiv(K, BK)):
        k = start * BK + rk
        g = k // G
        a = tl.load(
            A + m[:, None] * AS0 + k[None, :] * AS1,
            (m[:, None] < M) & (k[None, :] < K),
            other=0,
        ).to(tl.float32)

        packed_w = tl.load(
            QW + n[None, :] * WS0 + (k[:, None] // 2) * WS1,
            (k[:, None] < K) & (n[None, :] < N),
            other=0,
        ).to(tl.int32)
        w = (packed_w >> ((k[:, None] & 1) * 4)) & 15

        packed_z = tl.load(
            QZ + g[:, None] * ZS0 + (n[None, :] // 2) * ZS1,
            (k[:, None] < K) & (n[None, :] < N),
            other=0,
        ).to(tl.int32)
        z = (packed_z >> ((n[None, :] & 1) * 4)) & 15

        scale = tl.load(
            S + g[:, None] * SS0 + n[None, :] * SS1,
            (k[:, None] < K) & (n[None, :] < N),
            other=0,
        ).to(tl.float32)
        weight = (w - z).to(tl.float32) * scale
        acc = tl.dot(a, weight, acc, input_precision="ieee")

    tl.store(
        O + m[:, None] * N + n[None, :],
        acc,
        (m[:, None] < M) & (n[None, :] < N),
    )


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int, group_size: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.group_size = group_size

    def forward(self, input, qweight, scales, qzeros):
        M, K = input.shape
        N = qweight.shape[0]
        group = K // qzeros.shape[0]
        assert qweight.shape[1] == K // 2
        assert qzeros.shape[1] == N // 2
        assert scales.shape[0] == K // group
        assert scales.shape[1] == N

        out = torch.empty((M, N), device=input.device, dtype=input.dtype)
        if M == 0 or N == 0:
            return out

        strides = (
            input.stride(0), input.stride(1),
            qweight.stride(0), qweight.stride(1),
            scales.stride(0), scales.stride(1),
            qzeros.stride(0), qzeros.stride(1),
        )

        if M <= 4:
            bk = 512
            ns = triton.cdiv(K, bk)
            partial = torch.empty(
                (M, ns, N), device=input.device, dtype=torch.float32
            )
            _small_m_partial[(triton.cdiv(N, 8), ns, M)](
                input, qweight, scales, qzeros, partial,
                M, N, K, group, ns, *strides,
                BN=8, BK=bk, num_warps=4,
                enable_fp_fusion=False,
            )
            _finish_small_m[(triton.cdiv(N, 128), M)](
                partial, out, N, ns,
                BN=128, BS=triton.next_power_of_2(ns),
                num_warps=4,
            )
        else:
            _quantized_gemm[(triton.cdiv(M, 16), triton.cdiv(N, 32))](
                input, qweight, scales, qzeros, out,
                M, N, K, group, *strides,
                BM=16, BN=32, BK=32,
                num_warps=4,
            )
        return out
```