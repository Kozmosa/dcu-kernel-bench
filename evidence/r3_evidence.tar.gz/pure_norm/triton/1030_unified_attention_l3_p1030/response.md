```python
import math
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _partial_attention(
    Q, K, V, BT, LENS, CU, PART, MAXIMA, SUMS,
    H: tl.constexpr, HK: tl.constexpr, D: tl.constexpr,
    BS: tl.constexpr, NB: tl.constexpr, NS: tl.constexpr,
    SCALE: tl.constexpr, WINDOW: tl.constexpr, CAP: tl.constexpr,
    SPLITS: tl.constexpr, BD: tl.constexpr, BN: tl.constexpr,
):
    row = tl.program_id(0)
    head = tl.program_id(1)
    split = tl.program_id(2)

    # Upper bound on the prefix sums also handles empty sequences.
    lo = 0
    hi = NS
    while lo < hi:
        mid = (lo + hi) // 2
        boundary = tl.load(CU + mid + 1).to(tl.int32)
        advance = boundary <= row
        lo = tl.where(advance, mid + 1, lo)
        hi = tl.where(advance, hi, mid)
    seq = lo
    first = tl.load(CU + seq).to(tl.int32)
    last = tl.load(CU + seq + 1).to(tl.int32)
    kv_len = tl.load(LENS + seq).to(tl.int32)
    end = kv_len - (last - first) + row - first + 1
    begin = 0
    if WINDOW > 0:
        begin = tl.maximum(0, end - WINDOW)

    tiles = tl.cdiv(end - begin, BN)
    per_split = tl.cdiv(tiles, SPLITS)
    tile_begin = split * per_split
    tile_end = tl.minimum(tile_begin + per_split, tiles)

    d = tl.arange(0, BD)
    n = tl.arange(0, BN)
    q = tl.load(Q + (row * H + head) * D + d, d < D, 0).to(tl.float32)
    q = q * SCALE
    kv_head = head // (H // HK)

    m = tl.full((), -float("inf"), tl.float32)
    z = tl.full((), 0.0, tl.float32)
    acc = tl.full((BD,), 0.0, tl.float32)

    for tile in range(tile_begin, tile_end):
        pos = begin + tile * BN + n
        valid = pos < end
        page = tl.load(
            BT + seq * NB + pos // BS, valid, 0
        ).to(tl.int32)
        offsets = (
            ((page[:, None].to(tl.int64) * BS + pos[:, None] % BS) * HK
             + kv_head) * D + d[None, :]
        )
        k = tl.load(K + offsets, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        logits = tl.sum(k * q[None, :], axis=1)
        if CAP > 0:
            x = logits / CAP
            logits = CAP * (2.0 / (1.0 + tl.exp(2.0 * -x)) - 1.0)
        logits = tl.where(valid, logits, -float("inf"))
        new_m = tl.maximum(m, tl.max(logits, axis=0))
        correction = tl.exp(m - new_m)
        p = tl.exp(logits - new_m)
        v = tl.load(V + offsets, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        acc = acc * correction + tl.sum(p[:, None] * v, axis=0)
        z = z * correction + tl.sum(p, axis=0)
        m = new_m

    idx = (row * H + head) * SPLITS + split
    tl.store(PART + idx * D + d, acc, d < D)
    tl.store(MAXIMA + idx, m)
    tl.store(SUMS + idx, z)


@tr.jit
def _finish_attention(
    PART, MAXIMA, SUMS, SINKS, OUT,
    H: tl.constexpr, D: tl.constexpr, SPLITS: tl.constexpr,
    BD: tl.constexpr, BP: tl.constexpr,
    USE_SINKS: tl.constexpr, CAP: tl.constexpr,
):
    idx = tl.program_id(0)
    s = tl.arange(0, BP)
    d = tl.arange(0, BD)
    m = tl.load(MAXIMA + idx * SPLITS + s, s < SPLITS, -float("inf"))
    z = tl.load(SUMS + idx * SPLITS + s, s < SPLITS, 0)
    maximum = tl.max(m, axis=0)
    sink = tl.full((), -float("inf"), tl.float32)
    if USE_SINKS:
        sink = tl.load(SINKS + idx % H).to(tl.float32)
        if CAP > 0:
            sink = CAP * (2.0 / (1.0 + tl.exp(-2.0 * sink / CAP)) - 1.0)
        maximum = tl.maximum(maximum, sink)

    weights = tl.exp(m - maximum)
    denominator = tl.sum(z * weights, axis=0)
    if USE_SINKS:
        denominator += tl.exp(sink - maximum)
    partial = tl.load(
        PART + (idx * SPLITS + s[:, None]) * D + d[None, :],
        (s[:, None] < SPLITS) & (d[None, :] < D),
        0,
    )
    result = tl.sum(partial * weights[:, None], axis=0) / denominator
    tl.store(OUT + idx * D + d, result, d < D)


class ModelNew(nn.Module):
    def __init__(
        self,
        head_size: int,
        sliding_window: int = 0,
        softcap: float = 0.0,
        use_sinks: bool = True,
    ):
        super().__init__()
        self.scale = 1.0 / math.sqrt(head_size)
        self.sliding_window = int(sliding_window)
        self.softcap = float(softcap)
        self.use_sinks = bool(use_sinks)

    def forward(
        self, query, key_cache, value_cache, block_tables,
        seq_lens, cu_seqlens_q, sinks,
    ):
        total_q, heads, dim = query.shape
        _, block_size, kv_heads, _ = key_cache.shape
        assert heads % kv_heads == 0
        out = torch.empty_like(query)
        if total_q == 0:
            return out

        capacity = block_tables.shape[1] * block_size
        if self.sliding_window > 0:
            capacity = min(capacity, self.sliding_window)
        parallel_rows = total_q * heads
        desired = max(1, min(16, tr.cdiv(1024, parallel_rows)))
        splits = min(desired, max(1, tr.cdiv(capacity, 256)))
        partial = torch.empty(
            (total_q, heads, splits, dim), device=query.device, dtype=torch.float32
        )
        maxima = torch.empty(
            (total_q, heads, splits), device=query.device, dtype=torch.float32
        )
        sums = torch.empty_like(maxima)
        bd = tr.next_power_of_2(dim)

        _partial_attention[(total_q, heads, splits)](
            query, key_cache, value_cache, block_tables,
            seq_lens, cu_seqlens_q, partial, maxima, sums,
            H=heads, HK=kv_heads, D=dim, BS=block_size,
            NB=block_tables.shape[1], NS=seq_lens.shape[0],
            SCALE=self.scale, WINDOW=self.sliding_window, CAP=self.softcap,
            SPLITS=splits, BD=bd, BN=32,
            num_warps=4, enable_fp_fusion=False,
        )
        _finish_attention[(total_q * heads,)](
            partial, maxima, sums, sinks, out,
            H=heads, D=dim, SPLITS=splits, BD=bd,
            BP=tr.next_power_of_2(splits),
            USE_SINKS=self.use_sinks, CAP=self.softcap,
            num_warps=4,
        )
        return out
```