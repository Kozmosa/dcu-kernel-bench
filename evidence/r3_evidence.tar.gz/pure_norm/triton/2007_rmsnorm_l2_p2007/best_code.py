import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _rms_rows(
    X, W, R, O,
    M: tl.constexpr, N: tl.constexpr,
    EPS: tl.constexpr, FUSED: tl.constexpr,
    ROWS: tl.constexpr, COLS: tl.constexpr,
):
    rows = tl.program_id(0) * ROWS + tl.arange(0, ROWS)
    cols = tl.arange(0, COLS)
    valid = (rows[:, None] < M) & (cols[None, :] < N)
    offsets = rows[:, None].to(tl.int64) * N + cols[None, :]
    v = tl.load(X + offsets, valid, other=0).to(tl.float32)
    if FUSED:
        r = tl.load(R + offsets, valid, other=0).to(tl.float32)
        v = (v + r).to(X.dtype.element_ty).to(tl.float32)

    square = v * v
    inv = tl.rsqrt(tl.sum(square, axis=1) / N + EPS)
    w = tl.load(W + cols, cols < N, other=0).to(tl.float32)
    y = (v * inv[:, None]) * w[None, :]

    if FUSED:
        out_offsets = rows[:, None].to(tl.int64) * (2 * N) + cols[None, :]
        tl.store(O + out_offsets, y, valid)
        tl.store(O + out_offsets + N, v, valid)
    else:
        tl.store(O + offsets, y, valid)


@triton.jit
def _rms_partials(
    X, R, O, P,
    N: tl.constexpr, PARTS: tl.constexpr,
    FUSED: tl.constexpr, BLOCK: tl.constexpr,
):
    part = tl.program_id(0)
    row = tl.program_id(1).to(tl.int64)
    cols = part * BLOCK + tl.arange(0, BLOCK)
    valid = cols < N
    v = tl.load(X + row * N + cols, valid, other=0).to(tl.float32)
    if FUSED:
        r = tl.load(R + row * N + cols, valid, other=0).to(tl.float32)
        v = (v + r).to(X.dtype.element_ty).to(tl.float32)
        tl.store(O + row * (2 * N) + N + cols, v, valid)
    tl.store(P + row * PARTS + part, tl.sum(v * v, axis=0))


@triton.jit
def _rms_statistics(
    P, S,
    N: tl.constexpr, PARTS: tl.constexpr,
    EPS: tl.constexpr, BLOCK: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64)
    lanes = tl.arange(0, BLOCK)
    accum = tl.full((BLOCK,), 0, tl.float32)
    for start in range(tl.cdiv(PARTS, BLOCK)):
        idx = start * BLOCK + lanes
        accum += tl.load(P + row * PARTS + idx, idx < PARTS, other=0)
    inv = tl.rsqrt(tl.sum(accum, axis=0) / N + EPS)
    tl.store(S + row, inv)


@triton.jit
def _rms_apply(
    X, W, S, O,
    N: tl.constexpr, FUSED: tl.constexpr, BLOCK: tl.constexpr,
):
    row = tl.program_id(1).to(tl.int64)
    cols = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = cols < N
    if FUSED:
        v = tl.load(
            O + row * (2 * N) + N + cols, valid, other=0
        ).to(tl.float32)
    else:
        v = tl.load(X + row * N + cols, valid, other=0).to(tl.float32)
    w = tl.load(W + cols, valid, other=0).to(tl.float32)
    inv = tl.load(S + row)
    y = (v * inv) * w
    stride: tl.constexpr = 2 * N if FUSED else N
    tl.store(O + row * stride + cols, y, valid)


class ModelNew(nn.Module):
    def __init__(self, variant: str = "fused_add", eps: float = 1e-5):
        super().__init__()
        assert variant in ("rmsnorm", "fused_add"), (
            "variant must be one of rmsnorm / fused_add"
        )
        self.variant = variant
        self.eps = float(eps)

    def forward(self, x, weight, residual):
        m, n = x.shape
        fused = self.variant == "fused_add"
        out = torch.empty(
            (m, 2 * n if fused else n), device=x.device, dtype=x.dtype
        )
        residual_ptr = residual if fused else x

        if n <= 16384:
            cols = triton.next_power_of_2(n)
            rows = min(16, max(1, 1024 // cols))
            warps = 4 if cols <= 4096 else 8
            _rms_rows[(triton.cdiv(m, rows),)](
                x, weight, residual_ptr, out,
                m, n, self.eps, fused, rows, cols,
                num_warps=warps,
                enable_fp_fusion=False,
            )
        else:
            block = 4096
            parts = triton.cdiv(n, block)
            partials = torch.empty(
                (m, parts), device=x.device, dtype=torch.float32
            )
            statistics = torch.empty(
                (m,), device=x.device, dtype=torch.float32
            )
            _rms_partials[(parts, m)](
                x, residual_ptr, out, partials,
                n, parts, fused, block,
                num_warps=4,
                enable_fp_fusion=False,
            )
            _rms_statistics[(m,)](
                partials, statistics,
                n, parts, self.eps,
                min(1024, triton.next_power_of_2(parts)),
                num_warps=4,
                enable_fp_fusion=False,
            )
            _rms_apply[(parts, m)](
                x, weight, statistics, out,
                n, fused, block,
                num_warps=4,
                enable_fp_fusion=False,
            )
        return out
