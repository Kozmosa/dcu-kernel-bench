```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _qk_rope_pack(
    QN, QP, KN, KP, POS, COS, SIN, OUT,
    QH: tl.constexpr,
    KH: tl.constexpr,
    DN: tl.constexpr,
    DP: tl.constexpr,
    DF: tl.constexpr,
    NEOX: tl.constexpr,
    ROPE: tl.constexpr,
    BLOCK: tl.constexpr,
):
    batch = tl.program_id(1)
    side = tl.program_id(2)
    width: tl.constexpr = DN + DP

    if side == 0:
        heads = QH
        head_start = 0
        nope_ptr = QN
        pe_ptr = QP
    else:
        heads = KH
        head_start = QH
        nope_ptr = KN
        pe_ptr = KP

    indices = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = indices < heads * width
    head = indices // width
    dim = indices % width
    source_row = batch * heads + head

    value = tl.full((BLOCK,), 0, tl.float32)
    if DN > 0:
        nope = tl.load(
            nope_ptr + source_row * DN + dim,
            mask=valid & (dim < DN),
            other=0,
        ).to(tl.float32)
        value = nope

    if DP > 0:
        pd = dim - DN
        pe_mask = valid & (dim >= DN)
        x = tl.load(
            pe_ptr + source_row * DP + pd,
            mask=pe_mask,
            other=0,
        ).to(tl.float32)

        if ROPE:
            position = tl.load(POS + batch).to(tl.int64)
            if NEOX:
                partner = tl.where(pd < DP // 2, pd + DP // 2, pd - DP // 2)
                negative = pd < DP // 2
            else:
                partner = pd ^ 1
                negative = (pd & 1) == 0

            rotated = tl.load(
                pe_ptr + source_row * DP + partner,
                mask=pe_mask,
                other=0,
            ).to(tl.float32)
            rotated = tl.where(negative, -rotated, rotated)

            if DF == DP:
                frequency = pd
            elif NEOX:
                frequency = tl.where(pd < DP // 2, pd, pd - DP // 2)
            else:
                frequency = pd // 2

            c = tl.load(
                COS + position * DF + frequency,
                mask=pe_mask,
                other=0,
            ).to(tl.float32)
            s = tl.load(
                SIN + position * DF + frequency,
                mask=pe_mask,
                other=0,
            ).to(tl.float32)
            x = x * c + rotated * s

        value = tl.where(dim >= DN, x, value)

    destination = (
        batch * (QH + KH) * width + head_start * width + indices
    )
    tl.store(OUT + destination, value, mask=valid)


class ModelNew(nn.Module):
    def __init__(self, is_neox: bool = True, apply_rope: bool = True):
        super().__init__()
        self.is_neox = bool(is_neox)
        self.apply_rope = bool(apply_rope)

    def forward(self, q_nope, q_pe, k_nope, k_pe, pos, cos, sin):
        B, QH, D_nope = q_nope.shape
        KH = k_nope.shape[1]
        D_pe = q_pe.shape[-1]

        assert q_pe.shape[0] == B and k_nope.shape[0] == k_pe.shape[0] == B
        assert q_pe.shape[1] == QH and k_pe.shape[1] == KH
        assert k_nope.shape[2] == D_nope and k_pe.shape[2] == D_pe
        assert KH > 0 and QH % KH == 0
        assert D_pe % 2 == 0

        d_freq = cos.shape[-1]
        assert d_freq in (D_pe, D_pe // 2)

        out = torch.empty(
            (B, QH + KH, D_nope + D_pe),
            dtype=q_nope.dtype,
            device=q_nope.device,
        )
        width = D_nope + D_pe
        if B == 0 or width == 0:
            return out

        block = 256
        _qk_rope_pack[
            (triton.cdiv(max(QH, KH) * width, block), B, 2)
        ](
            q_nope, q_pe, k_nope, k_pe, pos, cos, sin, out,
            QH, KH, D_nope, D_pe, d_freq,
            self.is_neox, self.apply_rope, block,
            num_warps=4,
            enable_fp_fusion=False,
        )
        return out
```