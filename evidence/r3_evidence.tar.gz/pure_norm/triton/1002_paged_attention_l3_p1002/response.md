```python
import math

import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _paged_attention_parts(
    Q, K, V, Tables, Lengths, Partial, Stats, Out,
    HQ: tl.constexpr,
    GROUP: tl.constexpr,
    D: tl.constexpr,
    PAGE: tl.constexpr,
    PARTS: tl.constexpr,
    SCALE: tl.constexpr,
    QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr,
    KS2: tl.constexpr, KS3: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr,
    VS2: tl.constexpr, VS3: tl.constexpr,
    TS0: tl.constexpr, TS1: tl.constexpr,
    LS0: tl.constexpr,
    OS0: tl.constexpr, OS1: tl.constexpr, OS2: tl.constexpr,
    BLOCK: tl.constexpr,
    BD: tl.constexpr,
    DIRECT: tl.constexpr,
):
    sh = tl.program_id(0)
    part = tl.program_id(1)
    s = sh // HQ
    h = sh % HQ
    kh = h // GROUP
    length = tl.load(Lengths + s * LS0).to(tl.int32)

    ds = tl.arange(0, BD)
    ts = part * BLOCK + tl.arange(0, BLOCK)
    valid = ts < length

    q = tl.load(
        Q + s * QS0 + h * QS1 + ds * QS2,
        mask=ds < D, other=0,
    ).to(tl.float32)
    q = q * SCALE

    pages = tl.load(
        Tables + s * TS0 + (ts // PAGE) * TS1,
        mask=valid, other=0,
    ).to(tl.int64)
    within = ts % PAGE

    k = tl.load(
        K + pages[:, None] * KS0 + kh * KS1
        + within[:, None] * KS2 + ds[None, :] * KS3,
        mask=valid[:, None] & (ds[None, :] < D),
        other=0,
    ).to(tl.float32)

    logits = tl.sum(k * q[None, :], axis=1)
    logits = tl.where(valid, logits, -float("inf"))
    maximum = tl.max(logits, axis=0)
    safe_maximum = tl.where(maximum == -float("inf"), 0.0, maximum)
    weights = tl.exp(logits - safe_maximum)
    denominator = tl.sum(weights, axis=0)

    v = tl.load(
        V + pages[:, None] * VS0 + kh * VS1
        + within[:, None] * VS2 + ds[None, :] * VS3,
        mask=valid[:, None] & (ds[None, :] < D),
        other=0,
    ).to(tl.float32)
    numerator = tl.sum(weights[:, None] * v, axis=0)

    if DIRECT:
        result = numerator / tl.where(denominator > 0, denominator, 1.0)
        tl.store(
            Out + s * OS0 + h * OS1 + ds * OS2,
            result, mask=ds < D,
        )
    else:
        tl.store(
            Partial + (sh * PARTS + part) * D + ds,
            numerator, mask=ds < D,
        )
        tl.store(Stats + (sh * PARTS + part) * 2, maximum)
        tl.store(Stats + (sh * PARTS + part) * 2 + 1, denominator)


@triton.jit
def _paged_attention_merge(
    Partial, Stats, Out,
    HQ: tl.constexpr,
    D: tl.constexpr,
    PARTS: tl.constexpr,
    OS0: tl.constexpr, OS1: tl.constexpr, OS2: tl.constexpr,
    BP: tl.constexpr,
    BD: tl.constexpr,
):
    sh = tl.program_id(0)
    ps = tl.arange(0, BP)
    ds = tl.arange(0, BD)

    maxima = tl.load(
        Stats + (sh * PARTS + ps) * 2,
        mask=ps < PARTS, other=-float("inf"),
    )
    denominators = tl.load(
        Stats + (sh * PARTS + ps) * 2 + 1,
        mask=ps < PARTS, other=0,
    )
    maximum = tl.max(maxima, axis=0)
    maximum = tl.where(maximum == -float("inf"), 0.0, maximum)
    factors = tl.exp(maxima - maximum)
    denominator = tl.sum(factors * denominators, axis=0)

    numerators = tl.load(
        Partial + (sh * PARTS + ps[:, None]) * D + ds[None, :],
        mask=(ps[:, None] < PARTS) & (ds[None, :] < D),
        other=0,
    )
    result = tl.sum(numerators * factors[:, None], axis=0)
    result = result / tl.where(denominator > 0, denominator, 1.0)
    tl.store(
        Out + (sh // HQ) * OS0 + (sh % HQ) * OS1 + ds * OS2,
        result, mask=ds < D,
    )


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        batch, heads, dim = query.shape
        kv_heads = key_cache.shape[1]
        page_size = key_cache.shape[2]
        group = heads // kv_heads
        assert heads == kv_heads * group, (
            "num_q_heads must be an integer multiple of num_kv_heads"
        )

        out = torch.empty_like(query)
        if batch == 0 or heads == 0 or dim == 0:
            return out

        capacity = block_tables.shape[1] * page_size
        block = min(256, triton.next_power_of_2(max(1, capacity)))
        parts = max(1, triton.cdiv(capacity, block))
        padded_dim = triton.next_power_of_2(dim)

        if parts == 1:
            partial = out
            stats = out
        else:
            partial = torch.empty(
                (batch * heads, parts, dim),
                dtype=torch.float32, device=query.device,
            )
            stats = torch.empty(
                (batch * heads, parts, 2),
                dtype=torch.float32, device=query.device,
            )

        _paged_attention_parts[(batch * heads, parts)](
            query, key_cache, value_cache, block_tables, seq_lens,
            partial, stats, out,
            heads, group, dim, page_size, parts, self.scale,
            *query.stride(),
            *key_cache.stride(),
            *value_cache.stride(),
            *block_tables.stride(),
            seq_lens.stride(0),
            *out.stride(),
            BLOCK=block,
            BD=padded_dim,
            DIRECT=parts == 1,
            num_warps=4 if block * padded_dim <= 32768 else 8,
        )

        if parts > 1:
            _paged_attention_merge[(batch * heads,)](
                partial, stats, out,
                heads, dim, parts,
                *out.stride(),
                BP=triton.next_power_of_2(parts),
                BD=padded_dim,
                num_warps=4,
            )
        return out
```