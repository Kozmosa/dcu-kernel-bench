import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _quantize_groups(
    X,
    Out,
    N: tl.constexpr,
    GROUPS: tl.constexpr,
    GS: tl.constexpr,
    EPS: tl.constexpr,
    BLOCK_G: tl.constexpr,
    BLOCK_C: tl.constexpr,
):
    groups = tl.program_id(0) * BLOCK_G + tl.arange(0, BLOCK_G)
    columns = tl.arange(0, BLOCK_C)
    offsets = groups[:, None] * GS + columns[None, :]
    valid = (groups[:, None] < GROUPS) & (columns[None, :] < GS)

    values = tl.load(X + offsets, mask=valid, other=0.0).to(tl.float32)
    maxima = tl.max(tl.abs(values), axis=1)
    maxima = tl.maximum(maxima, tl.full((), EPS, tl.float32))

    # Both divisions must round as fp32 division before truncating the codes.
    scales = tl.div_rn(maxima, 127.0)
    normalized = tl.div_rn(values, scales[:, None])
    clamped = tl.minimum(tl.maximum(normalized, -128.0), 127.0)
    codes = clamped.to(tl.int32).to(tl.int8).to(tl.float32)

    tl.store(Out + offsets, codes, mask=valid)
    tl.store(Out + N + groups, scales, mask=groups < GROUPS)


class ModelNew(nn.Module):
    def __init__(self, group_size: int = 128, eps: float = 1e-10):
        super().__init__()
        self.group_size = int(group_size)
        self.eps = float(eps)

    def forward(self, x):
        gs = self.group_size
        assert x.dim() == 2, "x must be a 2D tensor"
        assert x.shape[-1] % gs == 0, (
            "the last dimension must be divisible by group_size"
        )
        assert x.is_contiguous(), "x must be contiguous"

        rows, cols = x.shape
        n = rows * cols
        groups = n // gs
        out = torch.empty((n + groups,), device=x.device, dtype=torch.float32)
        if groups == 0:
            return out

        block_c = triton.next_power_of_2(gs)
        block_g = min(16, max(1, 1024 // block_c))
        block_g = triton.next_power_of_2(block_g)
        num_warps = 4 if block_c * block_g <= 2048 else 8

        _quantize_groups[(triton.cdiv(groups, block_g),)](
            x,
            out,
            N=n,
            GROUPS=groups,
            GS=gs,
            EPS=self.eps,
            BLOCK_G=block_g,
            BLOCK_C=block_c,
            num_warps=num_warps,
            enable_fp_fusion=False,
        )
        return out
