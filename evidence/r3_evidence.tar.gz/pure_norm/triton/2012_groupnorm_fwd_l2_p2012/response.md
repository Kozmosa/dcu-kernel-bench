```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _groupnorm_kernel(
    x_ptr,
    scale_ptr,
    bias_ptr,
    out_ptr,
    n_groups,
    c,
    hw,
    rep,
    d_size,
    eps,
    do_swish,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)

    n = pid // n_groups
    g = pid - n * n_groups

    x_group_ptr = x_ptr + n * c * hw + g * rep * hw

    offsets = tl.arange(0, BLOCK_SIZE)
    mask = offsets < d_size

    total = tl.zeros([BLOCK_SIZE], dtype=tl.float32)
    start = 0
    while start < d_size:
        idx = start + offsets
        tile_mask = idx < d_size
        vals = tl.load(x_group_ptr + idx, mask=tile_mask, other=0.0).to(tl.float32)
        total += tl.where(tile_mask, vals, 0.0)
        start += BLOCK_SIZE

    mean = tl.sum(total, axis=0) / d_size

    sq_total = tl.zeros([BLOCK_SIZE], dtype=tl.float32)
    start = 0
    while start < d_size:
        idx = start + offsets
        tile_mask = idx < d_size
        vals = tl.load(x_group_ptr + idx, mask=tile_mask, other=0.0).to(tl.float32)
        diff = vals - mean
        sq_total += tl.where(tile_mask, diff * diff, 0.0)
        start += BLOCK_SIZE

    var = tl.sum(sq_total, axis=0) / d_size
    inv_var = tl.rsqrt(var + eps)

    stat_base = c * hw * n_groups
    stat_index = stat_base + g
    tl.store(out_ptr + c * hw * n_groups + n * n_groups + g, mean)
    tl.store(
        out_ptr + c * hw * n_groups + n * n_groups + n_groups * 0 + n_groups * 0,
        mean,
    )
    tl.store(
        out_ptr + c * hw * n_groups + n_groups * (n_groups * 0 + n) + g,
        mean,
    )

    y_base = n * c * hw + g * rep * hw
    output_y = out_ptr + y_base
    stats_base = c * hw * n_groups
    mean_out = out_ptr + stats_base + n * n_groups + g
    inv_out = out_ptr + stats_base + n_groups * n_groups + n * n_groups + g

    tl.store(mean_out, mean)
    tl.store(inv_out, inv_var)

    start = 0
    while start < d_size:
        idx = start + offsets
        tile_mask = idx < d_size

        vals = tl.load(x_group_ptr + idx, mask=tile_mask, other=0.0).to(tl.float32)
        channel = idx // hw
        channel_global = g * rep + channel

        scale = tl.load(scale_ptr + channel_global, mask=tile_mask, other=0.0).to(tl.float32)
        bias = tl.load(bias_ptr + channel_global, mask=tile_mask, other=0.0).to(tl.float32)

        gn = (vals - mean) * inv_var * scale + bias

        sigmoid = 1.0 / (1.0 + tl.exp(-gn))
        y = tl.where(do_swish != 0, gn * sigmoid, gn)

        tl.store(output_y + idx, y, mask=tile_mask)
        start += BLOCK_SIZE


class ModelNew(nn.Module):
    def __init__(self, variant: str = "groupnorm", groups: int = 2, eps: float = 1e-5):
        super().__init__()
        assert variant in ("groupnorm", "groupnorm_swish"), (
            "variant must be one of groupnorm / groupnorm_swish"
        )
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.variant = variant
        self.groups = int(groups)
        self.eps = float(eps)

    def forward(self, x, scale, bias):
        n, c, h, w = x.shape
        g = self.groups
        assert 1 <= g <= c and c % g == 0, (
            "groups must divide the number of channels and 1 <= groups <= C"
        )

        rep = c // g
        hw = h * w
        d_size = rep * hw
        y_size = n * c * hw
        stat_size = n * g

        out = torch.empty(
            y_size + 2 * stat_size,
            device=x.device,
            dtype=torch.float32,
        )

        block_size = 1024
        if d_size <= 256:
            block_size = 256
        elif d_size <= 512:
            block_size = 512
        elif d_size <= 1024:
            block_size = 1024
        elif d_size <= 2048:
            block_size = 2048

        _groupnorm_kernel[(n * g,)](
            x,
            scale,
            bias,
            out,
            g,
            c,
            hw,
            rep,
            d_size,
            self.eps,
            1 if self.variant == "groupnorm_swish" else 0,
            BLOCK_SIZE=block_size,
            num_warps=4 if block_size <= 512 else 8,
        )

        y_end = y_size
        mean_src = out[y_end + stat_size : y_end + 2 * stat_size]
        out[y_end + stat_size : y_end + 2 * stat_size].copy_(
            out[y_end : y_end + stat_size]
        )
        out[y_end : y_end + stat_size].copy_(mean_src)

        return out
```