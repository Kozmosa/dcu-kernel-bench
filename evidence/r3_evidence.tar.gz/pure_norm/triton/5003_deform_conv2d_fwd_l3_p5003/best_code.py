import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _deform_conv_kernel(
    x_ptr,
    off_ptr,
    weight_ptr,
    bias_ptr,
    mask_ptr,
    out_ptr,
    n_total,
    channels,
    height,
    width,
    k_out,
    r_size,
    s_size,
    h_out,
    w_out,
    stride_h,
    stride_w,
    padding_h,
    padding_w,
    dilation_h,
    dilation_w,
    BLOCK_K: tl.constexpr,
    BLOCK_Q: tl.constexpr,
    MODULATED: tl.constexpr,
):
    pid_k = tl.program_id(0)
    pid_spatial = tl.program_id(1)

    n_idx = pid_spatial // (h_out * w_out)
    spatial_idx = pid_spatial % (h_out * w_out)
    oi = spatial_idx // w_out
    oj = spatial_idx % w_out

    k_idx = pid_k * BLOCK_K + tl.arange(0, BLOCK_K)
    k_valid = k_idx < k_out

    acc = tl.zeros((BLOCK_K,), dtype=tl.float32)
    crs = channels * r_size * s_size
    q_count = crs

    q_offsets = tl.arange(0, BLOCK_Q)

    q_start = 0
    while q_start < q_count:
        q = q_start + q_offsets
        q_valid = q < q_count

        c_idx = q // (r_size * s_size)
        p_idx = q % (r_size * s_size)
        ri = p_idx // s_size
        sj = p_idx % s_size

        off_base = (
            n_idx * (2 * r_size * s_size) * h_out * w_out
            + (2 * p_idx) * h_out * w_out
            + spatial_idx
        )
        y_offset = tl.load(off_ptr + off_base, mask=q_valid, other=0.0).to(tl.float32)
        x_offset = tl.load(
            off_ptr + off_base + h_out * w_out,
            mask=q_valid,
            other=0.0,
        ).to(tl.float32)

        base_y = oi * stride_h + ri * dilation_h - padding_h
        base_x = oj * stride_w + sj * dilation_w - padding_w
        sample_y = base_y + y_offset
        sample_x = base_x + x_offset

        iy0 = tl.floor(sample_y).to(tl.int32)
        ix0 = tl.floor(sample_x).to(tl.int32)
        iy1 = iy0 + 1
        ix1 = ix0 + 1

        wy = sample_y - iy0.to(tl.float32)
        wx = sample_x - ix0.to(tl.float32)

        v00 = (
            (iy0 >= 0)
            & (iy0 < height)
            & (ix0 >= 0)
            & (ix0 < width)
            & q_valid
        )
        v01 = (
            (iy0 >= 0)
            & (iy0 < height)
            & (ix1 >= 0)
            & (ix1 < width)
            & q_valid
        )
        v10 = (
            (iy1 >= 0)
            & (iy1 < height)
            & (ix0 >= 0)
            & (ix0 < width)
            & q_valid
        )
        v11 = (
            (iy1 >= 0)
            & (iy1 < height)
            & (ix1 >= 0)
            & (ix1 < width)
            & q_valid
        )

        iy0_safe = tl.maximum(0, tl.minimum(height - 1, iy0))
        ix0_safe = tl.maximum(0, tl.minimum(width - 1, ix0))
        iy1_safe = tl.maximum(0, tl.minimum(height - 1, iy1))
        ix1_safe = tl.maximum(0, tl.minimum(width - 1, ix1))

        x_base = n_idx * channels * height * width
        x00_ptr = x_ptr + x_base + c_idx * height * width + iy0_safe * width + ix0_safe
        x01_ptr = x_ptr + x_base + c_idx * height * width + iy0_safe * width + ix1_safe
        x10_ptr = x_ptr + x_base + c_idx * height * width + iy1_safe * width + ix0_safe
        x11_ptr = x_ptr + x_base + c_idx * height * width + iy1_safe * width + ix1_safe

        x00 = tl.load(x00_ptr, mask=v00, other=0.0).to(tl.float32)
        x01 = tl.load(x01_ptr, mask=v01, other=0.0).to(tl.float32)
        x10 = tl.load(x10_ptr, mask=v10, other=0.0).to(tl.float32)
        x11 = tl.load(x11_ptr, mask=v11, other=0.0).to(tl.float32)

        sampled = (
            x00 * (1.0 - wy) * (1.0 - wx)
            + x01 * (1.0 - wy) * wx
            + x10 * wy * (1.0 - wx)
            + x11 * wy * wx
        )

        if MODULATED:
            mask_base = (
                n_idx * (r_size * s_size) * h_out * w_out
                + p_idx * h_out * w_out
                + spatial_idx
            )
            modulation = tl.load(
                mask_ptr + mask_base,
                mask=q_valid,
                other=0.0,
            ).to(tl.float32)
            sampled *= modulation

        weight_base = k_idx[:, None] * crs
        weight_offset = weight_base + c_idx[None, :] * (r_size * s_size) + p_idx[None, :]
        weights = tl.load(
            weight_ptr + weight_offset,
            mask=k_valid[:, None] & q_valid[None, :],
            other=0.0,
        ).to(tl.float32)

        acc += tl.sum(weights * sampled[None, :], axis=1)
        q_start += BLOCK_Q

    bias = tl.load(bias_ptr + k_idx, mask=k_valid, other=0.0).to(tl.float32)
    result = acc + bias

    out_offset = (
        n_idx * k_out * h_out * w_out
        + k_idx * h_out * w_out
        + spatial_idx
    )
    tl.store(out_ptr + out_offset, result, mask=k_valid)


class ModelNew(nn.Module):
    def __init__(
        self,
        variant: str = "modulated",
        stride=(1, 1),
        padding=(1, 1),
        dilation=(1, 1),
    ):
        super().__init__()
        assert variant in ("modulated", "plain"), "variant must be either modulated or plain"
        self.variant = variant
        self.stride = (int(stride[0]), int(stride[1]))
        self.padding = (int(padding[0]), int(padding[1]))
        self.dilation = (int(dilation[0]), int(dilation[1]))

    def forward(self, x, offset, weight, bias, mask):
        n, c, h, w = x.shape
        k_out = weight.shape[0]
        r, s = weight.shape[2], weight.shape[3]
        sh, sw = self.stride
        ph, pw = self.padding
        dh, dw = self.dilation

        h_out = (h + 2 * ph - (dh * (r - 1) + 1)) // sh + 1
        w_out = (w + 2 * pw - (dw * (s - 1) + 1)) // sw + 1

        assert offset.shape[1] == 2 * r * s and mask.shape[1] == r * s
        assert offset.shape[2] == h_out and offset.shape[3] == w_out
        assert mask.shape[2] == h_out and mask.shape[3] == w_out

        out = torch.empty(
            (n, k_out, h_out, w_out),
            device=x.device,
            dtype=x.dtype,
        )

        block_k = 64
        block_q = 128
        grid = (
            triton.cdiv(k_out, block_k),
            n * h_out * w_out,
        )

        _deform_conv_kernel[grid](
            x,
            offset,
            weight,
            bias,
            mask,
            out,
            n,
            c,
            h,
            w,
            k_out,
            r,
            s,
            h_out,
            w_out,
            sh,
            sw,
            ph,
            pw,
            dh,
            dw,
            BLOCK_K=block_k,
            BLOCK_Q=block_q,
            MODULATED=self.variant == "modulated",
        )
        return out
