import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _dispatch(Ids, Counts, Rows, P: tl.constexpr, B: tl.constexpr):
    p = tl.program_id(0) * B + tl.arange(0, B)
    e = tl.load(Ids + p, p < P, 0).to(tl.int32)
    slot = tl.atomic_add(Counts + e, 1, sem="relaxed", mask=p < P)
    tl.store(Rows + e * P + slot, p, p < P)


@tr.jit
def _first_grouped(
    A, W, Counts, Rows, Hidden,
    P: tl.constexpr, K: tl.constexpr, H: tl.constexpr,
    TOP: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    e = tl.program_id(0)
    block = tl.program_id(1)
    count = tl.load(Counts + e)
    if block * BM < count:
        r = block * BM + tl.arange(0, BM)
        p = tl.load(Rows + e * P + r, r < count, 0)
        n = tl.program_id(2) * BN + tl.arange(0, BN)
        k = tl.arange(0, BK)
        g = tl.full((BM, BN), 0, tl.float32)
        u = tl.full((BM, BN), 0, tl.float32)
        for base in range(tr.cdiv(K, BK)):
            kk = base * BK + k
            a = tl.load(
                A + (p // TOP)[:, None] * K + kk[None, :],
                (r < count)[:, None] & (kk < K)[None, :], 0,
            ).to(tl.float32)
            wg = tl.load(
                W + e * (2 * H * K) + n[None, :] * K + kk[:, None],
                (kk < K)[:, None] & (n < H)[None, :], 0,
            ).to(tl.float32)
            wu = tl.load(
                W + e * (2 * H * K) + (n[None, :] + H) * K + kk[:, None],
                (kk < K)[:, None] & (n < H)[None, :], 0,
            ).to(tl.float32)
            g = tl.dot(a, wg, g, input_precision="ieee")
            u = tl.dot(a, wu, u, input_precision="ieee")
        h = (g / (1.0 + tl.exp(-g))) * u
        tl.store(
            Hidden + p[:, None] * H + n[None, :], h,
            (r < count)[:, None] & (n < H)[None, :],
        )


@tr.jit
def _second_grouped(
    Hidden, W, Weights, Counts, Rows, Out,
    P: tl.constexpr, K: tl.constexpr, H: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    e = tl.program_id(0)
    block = tl.program_id(1)
    count = tl.load(Counts + e)
    if block * BM < count:
        r = block * BM + tl.arange(0, BM)
        p = tl.load(Rows + e * P + r, r < count, 0)
        n = tl.program_id(2) * BN + tl.arange(0, BN)
        k = tl.arange(0, BK)
        acc = tl.full((BM, BN), 0, tl.float32)
        for base in range(tr.cdiv(H, BK)):
            kk = base * BK + k
            a = tl.load(
                Hidden + p[:, None] * H + kk[None, :],
                (r < count)[:, None] & (kk < H)[None, :], 0,
            )
            w = tl.load(
                W + e * (K * H) + n[None, :] * H + kk[:, None],
                (kk < H)[:, None] & (n < K)[None, :], 0,
            ).to(tl.float32)
            acc = tl.dot(a, w, acc, input_precision="ieee")
        weight = tl.load(Weights + p, r < count, 0).to(tl.float32)
        tl.store(
            Out + p[:, None] * K + n[None, :],
            acc * weight[:, None],
            (r < count)[:, None] & (n < K)[None, :],
        )


@tr.jit
def _first_vector(
    A, W, Ids, Hidden,
    K: tl.constexpr, H: tl.constexpr, TOP: tl.constexpr,
    BN: tl.constexpr, BK: tl.constexpr,
):
    p = tl.program_id(0)
    e = tl.load(Ids + p).to(tl.int32)
    n = tl.program_id(1) * BN + tl.arange(0, BN)
    k = tl.arange(0, BK)
    ga = tl.full((BN, BK), 0, tl.float32)
    ua = tl.full((BN, BK), 0, tl.float32)
    for base in range(tr.cdiv(K, BK)):
        kk = base * BK + k
        a = tl.load(A + (p // TOP) * K + kk, kk < K, 0).to(tl.float32)
        wg = tl.load(
            W + e * (2 * H * K) + n[:, None] * K + kk[None, :],
            (n < H)[:, None] & (kk < K)[None, :], 0,
        ).to(tl.float32)
        wu = tl.load(
            W + e * (2 * H * K) + (n[:, None] + H) * K + kk[None, :],
            (n < H)[:, None] & (kk < K)[None, :], 0,
        ).to(tl.float32)
        ga = tl.fma(wg, a[None, :], ga)
        ua = tl.fma(wu, a[None, :], ua)
    g = tl.sum(ga, 1)
    u = tl.sum(ua, 1)
    h = (g / (1.0 + tl.exp(-g))) * u
    tl.store(Hidden + p * H + n, h, n < H)


@tr.jit
def _second_vector(
    Hidden, W, Ids, Weights, Out,
    K: tl.constexpr, H: tl.constexpr,
    BN: tl.constexpr, BK: tl.constexpr,
):
    p = tl.program_id(0)
    e = tl.load(Ids + p).to(tl.int32)
    n = tl.program_id(1) * BN + tl.arange(0, BN)
    k = tl.arange(0, BK)
    acc = tl.full((BN, BK), 0, tl.float32)
    for base in range(tr.cdiv(H, BK)):
        kk = base * BK + k
        h = tl.load(Hidden + p * H + kk, kk < H, 0)
        w = tl.load(
            W + e * (K * H) + n[:, None] * H + kk[None, :],
            (n < K)[:, None] & (kk < H)[None, :], 0,
        ).to(tl.float32)
        acc = tl.fma(w, h[None, :], acc)
    value = tl.sum(acc, 1)
    weight = tl.load(Weights + p).to(tl.float32)
    tl.store(Out + p * K + n, value * weight, n < K)


@tr.jit
def _zero_counts(Counts, E: tl.constexpr, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    tl.store(Counts + i, 0, i < E)


class ModelNew(nn.Module):
    def __init__(self, top_k: int, num_experts: int):
        super().__init__()
        self.top_k = top_k
        self.num_experts = num_experts

    def forward(self, a, w1, w2, topk_weights, topk_ids):
        m, k = a.shape
        e, n, _ = w1.shape
        top = topk_ids.shape[1]
        h = n // 2
        p = m * top
        out = torch.empty((m, top, k), dtype=a.dtype, device=a.device)
        if p == 0:
            return out

        hidden = torch.empty((p, h), dtype=torch.float32, device=a.device)

        if p < 8 * e or e * p > 32 * 1024 * 1024:
            _first_vector[(p, tr.cdiv(h, 4))](
                a, w1, topk_ids, hidden,
                k, h, top, 4, min(256, tr.next_power_of_2(k)),
                num_warps=4,
            )
            _second_vector[(p, tr.cdiv(k, 4))](
                hidden, w2, topk_ids, topk_weights, out,
                k, h, 4, min(256, tr.next_power_of_2(max(h, 1))),
                num_warps=4,
            )
        else:
            counts = torch.empty((e,), dtype=torch.int32, device=a.device)
            rows = torch.empty((e, p), dtype=torch.int32, device=a.device)
            _zero_counts[(tr.cdiv(e, 256),)](counts, e, 256)
            _dispatch[(tr.cdiv(p, 256),)](
                topk_ids, counts, rows, p, 256,
            )
            _first_grouped[(e, tr.cdiv(p, 16), tr.cdiv(h, 32))](
                a, w1, counts, rows, hidden,
                p, k, h, top, 16, 32, 32,
                num_warps=4,
            )
            _second_grouped[(e, tr.cdiv(p, 16), tr.cdiv(k, 32))](
                hidden, w2, topk_weights, counts, rows, out,
                p, k, h, 16, 32, 32,
                num_warps=4,
            )
        return out
