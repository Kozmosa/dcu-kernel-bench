```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _quantized_batched_gemm(
    X, W, XS, WS, Bias, Out,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    XB: tl.constexpr, XM: tl.constexpr, XK: tl.constexpr,
    WB: tl.constexpr, WN: tl.constexpr, WK: tl.constexpr,
    XSB: tl.constexpr, XSM: tl.constexpr,
    WSB: tl.constexpr, WSN: tl.constexpr,
    BB: tl.constexpr, BN: tl.constexpr,
    USE_BIAS: tl.constexpr,
    BM: tl.constexpr, BN_TILE: tl.constexpr, BK: tl.constexpr,
):
    tile_m = tl.program_id(0)
    tile_n = tl.program_id(1)
    batch = tl.program_id(2)

    rows = tile_m * BM + tl.arange(0, BM)
    cols = tile_n * BN_TILE + tl.arange(0, BN_TILE)
    ks = tl.arange(0, BK)

    xp = X + batch * XB + rows[:, None] * XM + ks[None, :] * XK
    wp = W + batch * WB + cols[None, :] * WN + ks[:, None] * WK

    acc = tl.full((BM, BN_TILE), 0, tl.float32)
    for block in range(tl.cdiv(K, BK)):
        valid_k = block * BK + ks < K
        x = tl.load(
            xp, mask=(rows[:, None] < M) & valid_k[None, :], other=0
        )
        w = tl.load(
            wp, mask=valid_k[:, None] & (cols[None, :] < N), other=0
        )

        # Integer code words are exactly representable in fp16; the dot
        # instruction accumulates their products directly into float32.
        x = x.to(tl.int8).to(tl.float16)
        w = w.to(tl.int8).to(tl.float16)
        acc = tl.dot(x, w, acc)
        xp += BK * XK
        wp += BK * WK

    xs = tl.load(XS + batch * XSB + rows * XSM, rows < M, other=0)
    ws = tl.load(WS + batch * WSB + cols * WSN, cols < N, other=0)
    value = acc * xs[:, None].to(tl.float32)
    value = value * ws[None, :].to(tl.float32)

    output_type = Out.dtype.element_ty
    if USE_BIAS:
        value = value.to(output_type).to(tl.float32)
        bias = tl.load(Bias + batch * BB + cols * BN, cols < N, other=0)
        bias = bias.to(output_type).to(tl.float32)
        value = value + bias[None, :]

    op = Out + batch * M * N + rows[:, None] * N + cols[None, :]
    tl.store(
        op,
        value.to(output_type),
        mask=(rows[:, None] < M) & (cols[None, :] < N),
    )


class ModelNew(nn.Module):
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)

    def forward(self, xq, wq, x_scale, w_scale, bias):
        B, M, K = xq.shape
        N = wq.shape[1]
        assert K == wq.shape[2], "xq and wq must agree on the K dimension"

        out = torch.empty((B, M, N), device=xq.device, dtype=self.out_dtype)

        bm = 16 if M <= 16 else 32
        bn = 32 if N <= 32 else 64
        bk = 32

        if self.use_bias:
            bias_ptr = bias
            bias_batch_stride = bias.stride(0)
            bias_col_stride = bias.stride(2)
        else:
            bias_ptr = out
            bias_batch_stride = 0
            bias_col_stride = 0

        _quantized_batched_gemm[
            (triton.cdiv(M, bm), triton.cdiv(N, bn), B)
        ](
            xq, wq, x_scale, w_scale, bias_ptr, out,
            M, N, K,
            xq.stride(0), xq.stride(1), xq.stride(2),
            wq.stride(0), wq.stride(1), wq.stride(2),
            x_scale.stride(0), x_scale.stride(1),
            w_scale.stride(0), w_scale.stride(2),
            bias_batch_stride, bias_col_stride,
            self.use_bias,
            bm, bn, bk,
            num_warps=4,
            num_stages=2,
            enable_fp_fusion=False,
        )
        return out
```