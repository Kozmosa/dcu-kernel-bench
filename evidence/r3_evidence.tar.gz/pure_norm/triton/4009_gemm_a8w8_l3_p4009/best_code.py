import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _quantized_gemm(
    X, W, XS, WS, BIAS, OUT,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    XSM: tl.constexpr, XSK: tl.constexpr,
    WSN: tl.constexpr, WSK: tl.constexpr,
    XSS: tl.constexpr, WSS: tl.constexpr, BS: tl.constexpr,
    USE_BIAS: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
    GROUP_M: tl.constexpr,
):
    pid = tl.program_id(0)
    num_m = tl.cdiv(M, BM)
    num_n = tl.cdiv(N, BN)
    group_size = GROUP_M * num_n
    group_id = pid // group_size
    first_m = group_id * GROUP_M
    active_m = tl.minimum(num_m - first_m, GROUP_M)
    local_pid = pid % group_size
    tile_m = first_m + local_pid % active_m
    tile_n = local_pid // active_m

    rows = tile_m * BM + tl.arange(0, BM)
    cols = tile_n * BN + tl.arange(0, BN)
    ks = tl.arange(0, BK)

    xp = X + rows[:, None] * XSM + ks[None, :] * XSK
    wp = W + cols[None, :] * WSN + ks[:, None] * WSK
    acc = tl.full((BM, BN), 0, tl.float32)

    for block in range(tl.cdiv(K, BK)):
        valid_k = block * BK + ks < K

        # All int8 and fp8 code words are represented exactly by bfloat16.
        # Its exponent range also covers the full fp8e5m2 range.
        a = tl.load(
            xp, (rows[:, None] < M) & valid_k[None, :], other=0
        ).to(tl.bfloat16)
        b = tl.load(
            wp, valid_k[:, None] & (cols[None, :] < N), other=0
        ).to(tl.bfloat16)
        acc = tl.dot(a, b, acc)
        xp += BK * XSK
        wp += BK * WSK

    sx = tl.load(XS + rows * XSS, rows < M, other=0).to(tl.float32)
    sw = tl.load(WS + cols * WSS, cols < N, other=0).to(tl.float32)

    # Preserve the reference's outer-product-first rounding order.
    scale = sx[:, None] * sw[None, :]
    result = acc * scale
    if USE_BIAS:
        bias = tl.load(BIAS + cols * BS, cols < N, other=0).to(tl.float32)
        result = result + bias[None, :]

    tl.store(
        OUT + rows[:, None] * N + cols[None, :],
        result,
        (rows[:, None] < M) & (cols[None, :] < N),
    )


class ModelNew(nn.Module):
    def __init__(self, in_dtype="fp8e4m3", out_dtype="bfloat16", use_bias=True):
        super().__init__()
        quant = {
            "fp8e4m3": torch.float8_e4m3fn,
            "fp8e5m2": torch.float8_e5m2,
            "int8": torch.int8,
        }
        out = {
            "bfloat16": torch.bfloat16,
            "float16": torch.float16,
        }
        self.in_dtype = quant[in_dtype]
        self.out_dtype = out[out_dtype]
        self.use_bias = bool(use_bias)

    def forward(self, x, w, x_scale, w_scale, bias):
        M, K = x.shape
        N = w.shape[0]
        assert K == w.shape[1], "x and w must agree on the K dimension"

        result = torch.empty((M, N), device=x.device, dtype=self.out_dtype)
        if M == 0 or N == 0:
            return result

        bm = 16 if M <= 16 else 32
        bn = 32 if N <= 32 else 64
        bk = 64
        grid = (triton.cdiv(M, bm) * triton.cdiv(N, bn),)

        _quantized_gemm[grid](
            x, w, x_scale, w_scale,
            bias if self.use_bias else result,
            result,
            M, N, K,
            x.stride(0), x.stride(1),
            w.stride(0), w.stride(1),
            x_scale.stride(0), w_scale.stride(1),
            bias.stride(1) if self.use_bias else 0,
            self.use_bias,
            bm, bn, bk, 8,
            num_warps=4,
            num_stages=2,
            enable_fp_fusion=False,
        )
        return result
