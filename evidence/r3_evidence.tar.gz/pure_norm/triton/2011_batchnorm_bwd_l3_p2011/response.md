```python
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _small_bn_backward(
    DY, X, SCALE, MEAN, INV, OUT,
    C: tl.constexpr, S: tl.constexpr, M: tl.constexpr,
    B: tl.constexpr, PARAMS: tl.constexpr,
):
    c = tl.program_id(0)
    r = tl.arange(0, B)
    valid = r < M
    offset = (r // S) * (C * S) + c * S + r % S
    dy = tl.load(DY + offset, valid, 0).to(tl.float32)
    x = tl.load(X + offset, valid, 0).to(tl.float32)
    mean = tl.load(MEAN + c).to(tl.float32)
    inv = tl.load(INV + c).to(tl.float32)
    xhat = (x - mean) * inv
    gamma = tl.sum(tl.where(valid, dy * xhat, 0.0), 0)
    beta = tl.sum(dy, 0)
    if PARAMS:
        tl.store(OUT + c, gamma)
        tl.store(OUT + C + c, beta)
    else:
        scale = tl.load(SCALE + c).to(tl.float32)
        result = ((scale * inv) / M) * (
            (M * dy - beta) - xhat * gamma
        )
        tl.store(OUT + offset, result, valid)


@tr.jit
def _partial_bn_backward(
    DY, X, MEAN, INV, PART,
    C: tl.constexpr, S: tl.constexpr, M: tl.constexpr,
    P: tl.constexpr, B: tl.constexpr,
):
    c = tl.program_id(0)
    p = tl.program_id(1)
    r = p * B + tl.arange(0, B)
    mean = tl.load(MEAN + c).to(tl.float32)
    inv = tl.load(INV + c).to(tl.float32)
    acc_gamma = tl.full((B,), 0.0, tl.float32)
    acc_beta = tl.full((B,), 0.0, tl.float32)
    for base in range(0, tr.cdiv(M, P * B)):
        index = r + base * P * B
        valid = index < M
        offset = (index // S) * (C * S) + c * S + index % S
        dy = tl.load(DY + offset, valid, 0).to(tl.float32)
        x = tl.load(X + offset, valid, 0).to(tl.float32)
        xhat = (x - mean) * inv
        acc_gamma += tl.where(valid, dy * xhat, 0.0)
        acc_beta += dy
    gamma = tl.sum(acc_gamma, 0)
    beta = tl.sum(acc_beta, 0)
    tl.store(PART + c * P + p, gamma)
    tl.store(PART + C * P + c * P + p, beta)


@tr.jit
def _finish_bn_reduction(
    PART, OUT,
    C: tl.constexpr, P: tl.constexpr, B: tl.constexpr,
):
    c = tl.program_id(0)
    p = tl.arange(0, B)
    gamma = tl.load(PART + c * P + p, p < P, 0)
    beta = tl.load(PART + C * P + c * P + p, p < P, 0)
    tl.store(OUT + c, tl.sum(gamma, 0))
    tl.store(OUT + C + c, tl.sum(beta, 0))


@tr.jit
def _apply_bn_backward(
    DY, X, SCALE, MEAN, INV, GRADS, OUT,
    C: tl.constexpr, S: tl.constexpr, M: tl.constexpr,
    TOTAL: tl.constexpr, B: tl.constexpr,
):
    offset = tl.program_id(0) * B + tl.arange(0, B)
    valid = offset < TOTAL
    c = (offset // S) % C
    dy = tl.load(DY + offset, valid, 0).to(tl.float32)
    x = tl.load(X + offset, valid, 0).to(tl.float32)
    mean = tl.load(MEAN + c, valid, 0).to(tl.float32)
    inv = tl.load(INV + c, valid, 0).to(tl.float32)
    scale = tl.load(SCALE + c, valid, 0).to(tl.float32)
    gamma = tl.load(GRADS + c, valid, 0)
    beta = tl.load(GRADS + C + c, valid, 0)
    xhat = (x - mean) * inv
    result = ((scale * inv) / M) * (
        (M * dy - beta) - xhat * gamma
    )
    tl.store(OUT + offset, result, valid)


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dx"):
        super().__init__()
        assert variant in ("dx", "dgamma_dbeta"), (
            "variant must be one of dx / dgamma_dbeta"
        )
        self.variant = variant

    def forward(self, dy, x, scale, saved_mean, saved_inv_variance):
        n, c, h, w = x.shape
        spatial = h * w
        m = n * spatial
        params = self.variant == "dgamma_dbeta"
        out = torch.empty(
            (2 * c,) if params else x.shape,
            dtype=x.dtype,
            device=x.device,
        )

        if m <= 2048:
            block = tr.next_power_of_2(max(m, 1))
            _small_bn_backward[(c,)](
                dy, x, scale, saved_mean, saved_inv_variance, out,
                C=c, S=spatial, M=m, B=block, PARAMS=params,
                num_warps=4, enable_fp_fusion=False,
            )
            return out

        block = 2048
        partitions = min(tr.cdiv(m, block), 1024)
        partial = torch.empty(
            (2, c, partitions), dtype=torch.float32, device=x.device
        )
        _partial_bn_backward[(c, partitions)](
            dy, x, saved_mean, saved_inv_variance, partial,
            C=c, S=spatial, M=m, P=partitions, B=block,
            num_warps=4, enable_fp_fusion=False,
        )

        grads = out if params else torch.empty(
            (2 * c,), dtype=torch.float32, device=x.device
        )
        _finish_bn_reduction[(c,)](
            partial, grads,
            C=c, P=partitions, B=tr.next_power_of_2(partitions),
            num_warps=4, enable_fp_fusion=False,
        )

        if not params:
            total = n * c * spatial
            _apply_bn_backward[(tr.cdiv(total, 1024),)](
                dy, x, scale, saved_mean, saved_inv_variance, grads, out,
                C=c, S=spatial, M=m, TOTAL=total, B=1024,
                num_warps=4, enable_fp_fusion=False,
            )
        return out
```