```python
import math

import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _hstu_forward(
    Q, K, V, Offsets, Targets, Out,
    QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
    KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr,
    VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr,
    OS0: tl.constexpr, OS1: tl.constexpr, OS2: tl.constexpr,
    H: tl.constexpr,
    D: tl.constexpr,
    DV: tl.constexpr,
    ALPHA: tl.constexpr,
    N: tl.constexpr,
    CAUSAL: tl.constexpr,
    A: tl.constexpr,
    C: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BD: tl.constexpr,
    BV: tl.constexpr,
    VBLOCKS: tl.constexpr,
):
    row_block = tl.program_id(0)
    batch_head = tl.program_id(1)
    value_block = tl.program_id(2)
    batch = batch_head // H
    head = batch_head % H

    start = tl.load(Offsets + batch)
    end = tl.load(Offsets + batch + 1)
    length = end - start
    row_start = row_block * BM

    if row_start < length:
        targets = tl.load(Targets + batch)
        rows = row_start + tl.arange(0, BM)
        dims = tl.arange(0, BD)
        values = value_block * BV + tl.arange(0, BV)

        if C > 0:
            boundary = length - C + 1 - targets
            row_pos = tl.minimum(tl.maximum(rows - C + 1, 0), boundary)
        else:
            boundary = length - targets
            row_pos = tl.minimum(rows, boundary)

        q = tl.load(
            Q + (start + rows[:, None]) * QS0
            + head * QS1 + dims[None, :] * QS2,
            mask=(rows[:, None] < length) & (dims[None, :] < D),
            other=0,
        ).to(tl.float32)

        acc = tl.full((BM, BV), 0, tl.float32)
        key_end = length
        if CAUSAL:
            if C > 0:
                if row_start >= C:
                    key_end = tl.minimum(length, row_start + BM)
            else:
                key_end = tl.minimum(length, row_start + BM)

        for key_start in range(0, key_end, BN):
            keys = key_start + tl.arange(0, BN)
            k = tl.load(
                K + (start + keys[None, :]) * KS0
                + head * KS1 + dims[:, None] * KS2,
                mask=(keys[None, :] < length) & (dims[:, None] < D),
                other=0,
            ).to(tl.float32)

            logits = tl.dot(q, k, input_precision="ieee") * ALPHA
            weights = (logits / (1.0 + tl.exp(-logits))) / N

            if C > 0:
                key_pos = tl.minimum(tl.maximum(keys - C + 1, 0), boundary)
            else:
                key_pos = tl.minimum(keys, boundary)

            distance = row_pos[:, None] - key_pos[None, :]
            if not CAUSAL:
                distance = tl.abs(distance)

            valid = (rows[:, None] == keys[None, :]) | (distance > 0)
            if A > 0:
                valid = valid & (distance <= A)
            if C > 0:
                valid = valid | (
                    (row_pos[:, None] == 0)
                    & (key_pos[None, :] < boundary)
                )
            valid = valid & (keys[None, :] < length) & (rows[:, None] < length)
            weights = tl.where(valid, weights, 0.0)

            v = tl.load(
                V + (start + keys[:, None]) * VS0
                + head * VS1 + values[None, :] * VS2,
                mask=(keys[:, None] < length) & (values[None, :] < DV),
                other=0,
            ).to(tl.float32)
            acc = tl.dot(weights, v, acc, input_precision="ieee")

        tl.store(
            Out + (start + rows[:, None]) * OS0
            + head * OS1 + values[None, :] * OS2,
            acc,
            mask=(rows[:, None] < length) & (values[None, :] < DV),
        )


class ModelNew(nn.Module):
    def __init__(
        self,
        max_seq_len: int,
        alpha=None,
        causal=True,
        max_attn_len=0,
        contextual_seq_len=0,
    ):
        super().__init__()
        self.max_seq_len = int(max_seq_len)
        self.alpha = float(alpha) if alpha is not None else None
        self.causal = bool(causal)
        self.max_attn_len = int(max_attn_len)
        self.contextual_seq_len = int(contextual_seq_len)

    def forward(self, q, k, v, seq_offsets, num_targets):
        out = torch.empty(v.shape, dtype=v.dtype, device=v.device)
        total, heads, d = q.shape
        batches = seq_offsets.numel() - 1
        if total == 0 or heads == 0 or v.shape[2] == 0:
            return out

        alpha = self.alpha if self.alpha is not None else 1.0 / math.sqrt(d)
        dv = v.shape[2]
        bm, bn = 32, 32
        bv = min(64, tr.next_power_of_2(dv))
        value_blocks = tr.cdiv(dv, bv)

        with torch.cuda.device(q.device):
            _hstu_forward[
                (tr.cdiv(self.max_seq_len, bm), batches * heads, value_blocks)
            ](
                q, k, v, seq_offsets, num_targets, out,
                *q.stride(),
                *k.stride(),
                *v.stride(),
                *out.stride(),
                H=heads,
                D=d,
                DV=dv,
                ALPHA=alpha,
                N=self.max_seq_len,
                CAUSAL=self.causal,
                A=self.max_attn_len,
                C=self.contextual_seq_len,
                BM=bm,
                BN=bn,
                BD=tr.next_power_of_2(d),
                BV=bv,
                VBLOCKS=value_blocks,
                num_warps=4,
                num_stages=1,
                enable_fp_fusion=False,
            )
        return out
```