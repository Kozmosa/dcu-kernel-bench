import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _routed_grouped_gemm(
    A, B, W, Sorted, Experts, Padded, C,
    M: tl.constexpr,
    N: tl.constexpr,
    K: tl.constexpr,
    TOP_K: tl.constexpr,
    A_SM: tl.constexpr,
    A_SK: tl.constexpr,
    B_SE: tl.constexpr,
    B_SN: tl.constexpr,
    B_SK: tl.constexpr,
    W_SM: tl.constexpr,
    W_SJ: tl.constexpr,
    SORT_S: tl.constexpr,
    EXP_S: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BK: tl.constexpr,
):
    block_m = tl.program_id(0)
    block_n = tl.program_id(1)
    start = block_m * BM
    padded = tl.load(Padded)

    if start < padded:
        rows = start + tl.arange(0, BM)
        slots = tl.load(
            Sorted + rows * SORT_S,
            mask=rows < padded,
            other=M * TOP_K,
        )
        valid = slots < M * TOP_K
        tokens = slots // TOP_K
        expert = tl.load(Experts + (start // 64) * EXP_S)
        cols = block_n * BN + tl.arange(0, BN)
        ks = tl.arange(0, BK)

        a_ptr = A + tokens[:, None] * A_SM + ks[None, :] * A_SK
        b_ptr = (
            B + expert * B_SE
            + ks[:, None] * B_SK
            + cols[None, :] * B_SN
        )

        acc = tl.zeros((BM, BN), dtype=tl.float32)
        for k in range(tl.cdiv(K, BK)):
            a = tl.load(
                a_ptr,
                mask=valid[:, None] & (k * BK + ks[None, :] < K),
                other=0.0,
            )
            b = tl.load(
                b_ptr,
                mask=(k * BK + ks[:, None] < K) & (cols[None, :] < N),
                other=0.0,
            )
            acc = tl.dot(a, b, acc, input_precision="ieee")
            a_ptr += BK * A_SK
            b_ptr += BK * B_SK

        weights = tl.load(
            W + tokens * W_SM + (slots % TOP_K) * W_SJ,
            mask=valid,
            other=0.0,
        ).to(tl.float32)
        result = acc * weights[:, None]
        tl.store(
            C + slots[:, None] * N + cols[None, :],
            result,
            mask=valid[:, None] & (cols[None, :] < N),
        )


class ModelNew(nn.Module):
    def __init__(self, num_experts: int, top_k: int):
        super().__init__()
        self.num_experts = num_experts
        self.top_k = top_k

    def forward(
        self, A, B, topk_weights, topk_ids,
        sorted_token_ids, expert_ids, num_tokens_post_padded,
    ):
        m, k = A.shape
        e, n, _ = B.shape
        top_k = topk_ids.shape[1]
        out = torch.empty((m, top_k, n), device=A.device, dtype=A.dtype)
        if m == 0 or top_k == 0 or n == 0:
            return out

        bm = 32 if m * top_k < e * 64 else 64
        bn = 64
        bk = 32
        max_blocks = min(
            triton.cdiv(sorted_token_ids.numel(), 64),
            triton.cdiv(m * top_k, 64) + e - 1,
        )
        grid = (max_blocks * (64 // bm), triton.cdiv(n, bn))

        _routed_grouped_gemm[grid](
            A, B, topk_weights, sorted_token_ids, expert_ids,
            num_tokens_post_padded, out,
            m, n, k, top_k,
            A.stride(0), A.stride(1),
            B.stride(0), B.stride(1), B.stride(2),
            topk_weights.stride(0), topk_weights.stride(1),
            sorted_token_ids.stride(0), expert_ids.stride(0),
            bm, bn, bk,
            num_warps=4,
            num_stages=2,
        )
        return out
