```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _small_matmul(
    X, W, Y,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    XS0: tl.constexpr, XS1: tl.constexpr,
    WS0: tl.constexpr, WS1: tl.constexpr,
    BK: tl.constexpr,
):
    p = tl.program_id(0)
    m = p // N
    n = p % N
    k = tl.arange(0, BK)
    acc = tl.full((BK,), 0, tl.float32)
    for start in range(tl.cdiv(K, BK)):
        kk = start * BK + k
        a = tl.load(
            X + m * XS0 + kk * XS1, mask=kk < K, other=0
        ).to(tl.float32)
        b = tl.load(
            W + n * WS0 + kk * WS1, mask=kk < K, other=0
        ).to(tl.float32)
        acc = tl.fma(a, b, acc)
    result = tl.sum(acc, axis=0)
    tl.store(Y + p, result)


@triton.jit
def _matmul(
    X, W, Y,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    XS0: tl.constexpr, XS1: tl.constexpr,
    WS0: tl.constexpr, WS1: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
    GROUP_M: tl.constexpr,
):
    pid = tl.program_id(0)
    grid_m = tl.cdiv(M, BM)
    grid_n = tl.cdiv(N, BN)

    group_size = GROUP_M * grid_n
    group_id = pid // group_size
    first_m = group_id * GROUP_M
    actual_group_m = tl.minimum(grid_m - first_m, GROUP_M)
    within = pid % group_size
    tile_m = first_m + within % actual_group_m
    tile_n = within // actual_group_m

    rows = tile_m * BM + tl.arange(0, BM)
    cols = tile_n * BN + tl.arange(0, BN)
    ks = tl.arange(0, BK)

    xp = X + rows[:, None] * XS0 + ks[None, :] * XS1
    wp = W + ks[:, None] * WS1 + cols[None, :] * WS0

    acc = tl.full((BM, BN), 0, tl.float32)
    for block in range(tl.cdiv(K, BK)):
        valid_k = block * BK + ks < K
        a = tl.load(
            xp, mask=(rows[:, None] < M) & valid_k[None, :], other=0
        )
        b = tl.load(
            wp, mask=valid_k[:, None] & (cols[None, :] < N), other=0
        )
        acc = tl.dot(a, b, acc, input_precision="ieee")
        xp += BK * XS1
        wp += BK * WS1

    tl.store(
        Y + rows[:, None] * N + cols[None, :],
        acc,
        mask=(rows[:, None] < M) & (cols[None, :] < N),
    )


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

    def forward(self, x, weight):
        m, k = x.shape
        n, wk = weight.shape
        assert k == wk, "x and weight must agree on the K dimension"

        out = torch.empty((m, n), dtype=x.dtype, device=x.device)
        if m == 0 or n == 0:
            return out

        if m * n <= 64:
            bk = min(2048, triton.next_power_of_2(max(k, 1)))
            _small_matmul[(m * n,)](
                x, weight, out,
                m, n, k,
                x.stride(0), x.stride(1),
                weight.stride(0), weight.stride(1),
                bk,
                num_warps=4,
            )
        else:
            bm = 16 if m <= 16 else 32
            bn = 32 if n <= 32 else 64
            bk = 32 if x.dtype == torch.float32 else 64
            grid = (triton.cdiv(m, bm) * triton.cdiv(n, bn),)
            _matmul[grid](
                x, weight, out,
                m, n, k,
                x.stride(0), x.stride(1),
                weight.stride(0), weight.stride(1),
                bm, bn, bk, 8,
                num_warps=4,
                num_stages=2,
            )
        return out
```