```python
import math
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _paged_prefill(
    Q, K, V, KC, VC, BT, QS, SL, SLOPE, O,
    NSEQ: tl.constexpr, D: tl.constexpr, GROUP: tl.constexpr,
    BS: tl.constexpr, PACK: tl.constexpr,
    SCALE: tl.constexpr, HAS_ALIBI: tl.constexpr,
    QSTR: tl.constexpr, KSTR: tl.constexpr, VSTR: tl.constexpr,
    KCSTR: tl.constexpr, VCSTR: tl.constexpr,
    BTSTR: tl.constexpr, QSSTR: tl.constexpr, SLSTR: tl.constexpr,
    SSTR: tl.constexpr, OSTR: tl.constexpr,
    M: tl.constexpr, N: tl.constexpr, DD: tl.constexpr,
):
    tile = tl.program_id(0)
    h = tl.program_id(1)

    # Map a densely numbered query tile to its sequence without host reads.
    b = 0
    start = tl.load(QS)
    end = tl.load(QS + QSSTR)
    tiles = tl.cdiv(end - start, M)
    while (tile >= tiles) & (b < NSEQ - 1):
        tile -= tiles
        b += 1
        start = end
        end = tl.load(QS + (b + 1) * QSSTR)
        tiles = tl.cdiv(end - start, M)

    if tile < tiles:
        qlen = end - start
        ctx = tl.load(SL + b * SLSTR) - qlen
        kh = h // GROUP
        r = tile * M + tl.arange(0, M)
        d = tl.arange(0, DD)
        pos = ctx + r
        q = tl.load(
            Q + (start + r[:, None]) * QSTR[0]
            + h * QSTR[1] + d[None, :] * QSTR[2],
            (r[:, None] < qlen) & (d[None, :] < D), 0,
        ).to(tl.float32) * SCALE

        slope = 0.0
        if HAS_ALIBI:
            slope = tl.load(SLOPE + h * SSTR).to(tl.float32)

        maximum = tl.full((M,), -float("inf"), tl.float32)
        denom = tl.full((M,), 0.0, tl.float32)
        acc = tl.full((M, DD), 0.0, tl.float32)
        limit = ctx + tl.minimum((tile + 1) * M, qlen)

        for base in range(0, tl.cdiv(limit, N)):
            l = base * N + tl.arange(0, N)
            prefix = l < ctx
            valid = l < limit
            physical = tl.load(
                BT + b * BTSTR[0] + (l // BS) * BTSTR[1],
                prefix & valid, 0,
            ).to(tl.int64)
            slot = l % BS
            new_token = start + l - ctx

            cached_k = tl.load(
                KC + physical[None, :] * KCSTR[0]
                + kh * KCSTR[1]
                + (d[:, None] // PACK) * KCSTR[2]
                + slot[None, :] * KCSTR[3]
                + (d[:, None] % PACK) * KCSTR[4],
                (d[:, None] < D) & prefix[None, :] & valid[None, :],
                0,
            ).to(tl.float32)
            new_k = tl.load(
                K + new_token[None, :] * KSTR[0]
                + kh * KSTR[1] + d[:, None] * KSTR[2],
                (d[:, None] < D) & (~prefix[None, :]) & valid[None, :],
                0,
            ).to(tl.float32)
            keys = tl.where(prefix[None, :], cached_k, new_k)

            scores = tl.dot(q, keys, input_precision="ieee")
            if HAS_ALIBI:
                scores += slope * (l[None, :] - pos[:, None]).to(tl.float32)
            scores = tl.where(
                valid[None, :] & (l[None, :] <= pos[:, None]),
                scores, -float("inf"),
            )

            next_max = tl.maximum(maximum, tl.max(scores, axis=1))
            correction = tl.exp(maximum - next_max)
            p = tl.exp(scores - next_max[:, None])
            denom = denom * correction + tl.sum(p, axis=1)
            acc *= correction[:, None]

            cached_v = tl.load(
                VC + physical[:, None] * VCSTR[0]
                + kh * VCSTR[1] + d[None, :] * VCSTR[2]
                + slot[:, None] * VCSTR[3],
                prefix[:, None] & valid[:, None] & (d[None, :] < D),
                0,
            ).to(tl.float32)
            new_v = tl.load(
                V + new_token[:, None] * VSTR[0]
                + kh * VSTR[1] + d[None, :] * VSTR[2],
                (~prefix[:, None]) & valid[:, None] & (d[None, :] < D),
                0,
            ).to(tl.float32)
            vals = tl.where(prefix[:, None], cached_v, new_v)
            acc += tl.dot(p, vals, input_precision="ieee")
            maximum = next_max

        result = acc / denom[:, None]
        tl.store(
            O + (start + r[:, None]) * OSTR[0]
            + h * OSTR[1] + d[None, :] * OSTR[2],
            result,
            (r[:, None] < qlen) & (d[None, :] < D),
        )


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(
        self, query, key, value, key_cache, value_cache,
        block_tables, query_start_loc, seq_lens, alibi_slopes=None
    ):
        tokens, heads, dim = query.shape
        kv_heads = key_cache.shape[1]
        pack = key_cache.shape[4]
        assert heads % kv_heads == 0
        assert dim % pack == 0
        out = torch.empty(query.shape, dtype=query.dtype, device=query.device)
        sequences = seq_lens.shape[0]
        if tokens == 0 or sequences == 0:
            return out

        m = 16
        grid = (tr.cdiv(tokens, m) + sequences - 1, heads)
        _paged_prefill[grid](
            query, key, value, key_cache, value_cache,
            block_tables, query_start_loc, seq_lens,
            alibi_slopes if alibi_slopes is not None else query, out,
            NSEQ=sequences, D=dim, GROUP=heads // kv_heads,
            BS=value_cache.shape[3], PACK=pack,
            SCALE=self.scale, HAS_ALIBI=alibi_slopes is not None,
            QSTR=query.stride(), KSTR=key.stride(), VSTR=value.stride(),
            KCSTR=key_cache.stride(), VCSTR=value_cache.stride(),
            BTSTR=block_tables.stride(),
            QSSTR=query_start_loc.stride(0), SLSTR=seq_lens.stride(0),
            SSTR=alibi_slopes.stride(0) if alibi_slopes is not None else 1,
            OSTR=out.stride(),
            M=m, N=32, DD=tr.next_power_of_2(dim),
            num_warps=4, num_stages=1,
        )
        return out
```