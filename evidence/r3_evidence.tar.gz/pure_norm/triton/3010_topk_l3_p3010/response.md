```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _local_select(
    X, V, I, OUT,
    M: tl.constexpr,
    K: tl.constexpr,
    GROUPS: tl.constexpr,
    KEEP: tl.constexpr,
    TILE: tl.constexpr,
    DIRECT: tl.constexpr,
    REPEATED: tl.constexpr,
):
    row = tl.program_id(0)
    group = tl.program_id(1)
    lane = tl.arange(0, TILE)
    col = group * TILE + lane
    valid = col < M
    value = tl.load(X + row * M + col, valid, other=-float("inf"))

    if REPEATED:
        for j in range(KEEP):
            maximum = tl.max(tl.where(valid, value, -float("inf")), 0)
            winner = tl.min(
                tl.where(valid & (value == maximum), col, 2147483647), 0
            )
            if DIRECT:
                tl.store(OUT + row * (2 * K) + j, maximum)
                tl.store(OUT + row * (2 * K) + K + j, winner.to(tl.float32))
            else:
                dst = (row * GROUPS + group) * KEEP + j
                tl.store(V + dst, maximum)
                tl.store(I + dst, winner)
            valid = valid & (col != winner)
    else:
        # Preserve a real negative infinity even when padding has the same key.
        neg_inf_col = tl.min(
            tl.where(valid & (value == -float("inf")), col, 2147483647), 0
        )
        non_inf_count = tl.sum(
            (valid & (value != -float("inf"))).to(tl.int32), 0
        )
        sorted_value, sorted_col = tl.sort_key_value(
            value, col, descending=True
        )
        sorted_col = tl.where(
            (lane == non_inf_count) & (neg_inf_col != 2147483647),
            neg_inf_col,
            sorted_col,
        )
        if DIRECT:
            tl.store(
                OUT + row * (2 * K) + lane,
                sorted_value,
                lane < K,
            )
            tl.store(
                OUT + row * (2 * K) + K + lane,
                sorted_col.to(tl.float32),
                lane < K,
            )
        else:
            dst = (row * GROUPS + group) * KEEP + lane
            tl.store(V + dst, sorted_value, lane < KEEP)
            tl.store(I + dst, sorted_col, lane < KEEP)


@triton.jit
def _merge_select(
    V, I, NV, NI, OUT,
    M: tl.constexpr,
    K: tl.constexpr,
    GROUPS: tl.constexpr,
    NEXT_GROUPS: tl.constexpr,
    CAP: tl.constexpr,
    NEXT_CAP: tl.constexpr,
    SPAN: tl.constexpr,
    BLOCK: tl.constexpr,
    FINAL: tl.constexpr,
):
    row = tl.program_id(0)
    pair = tl.program_id(1)
    work = tl.program_id(2) * BLOCK + tl.arange(0, BLOCK)

    side = work // CAP
    pos = work % CAP
    group = pair * 2 + side
    other_group = pair * 2 + (1 - side)

    length = tl.minimum(K, tl.maximum(0, tl.minimum(SPAN, M - group * SPAN)))
    other_length = tl.minimum(
        K, tl.maximum(0, tl.minimum(SPAN, M - other_group * SPAN))
    )
    active = (work < 2 * CAP) & (group < GROUPS) & (pos < length)
    value = tl.load(
        V + (row * GROUPS + group) * CAP + pos,
        active,
        other=-float("inf"),
    )
    index = tl.load(
        I + (row * GROUPS + group) * CAP + pos,
        active,
        other=2147483647,
    )

    lo = tl.full((BLOCK,), 0, tl.int32)
    hi = tl.where(active, other_length, 0)
    for _ in range((CAP + 1).bit_length()):
        mid = (lo + hi) // 2
        searching = active & (lo < hi) & (other_group < GROUPS)
        other_value = tl.load(
            V + (row * GROUPS + other_group) * CAP + mid,
            searching,
            other=-float("inf"),
        )
        before = other_value > value
        lo = tl.where(searching & before, mid + 1, lo)
        hi = tl.where(searching & ~before, mid, hi)

    rank = pos + lo
    write = active & (rank < NEXT_CAP)
    if FINAL:
        tl.store(OUT + row * (2 * K) + rank, value, write)
        tl.store(
            OUT + row * (2 * K) + K + rank,
            index.to(tl.float32),
            write,
        )
    else:
        dst = (row * NEXT_GROUPS + pair) * NEXT_CAP + rank
        tl.store(NV + dst, value, write)
        tl.store(NI + dst, index, write)


class ModelNew(nn.Module):
    def __init__(self, k: int = 8):
        super().__init__()
        assert k >= 1, "k must be >= 1"
        self.k = int(k)

    def forward(self, x):
        b, m = x.shape
        k = self.k
        if k > m:
            raise ValueError("k must not exceed the number of columns")
        out = torch.empty((b, 2 * k), device=x.device, dtype=torch.float32)
        if b == 0:
            return out

        tile = triton.next_power_of_2(m) if m <= 1024 else 512
        groups = triton.cdiv(m, tile)
        cap = min(k, tile)
        repeated = k <= 8

        if groups == 1:
            _local_select[(b, 1)](
                x, out, out, out,
                M=m, K=k, GROUPS=1, KEEP=k, TILE=tile,
                DIRECT=True, REPEATED=repeated,
                num_warps=4,
            )
            return out

        values = torch.empty(
            (b, groups, cap), device=x.device, dtype=torch.float32
        )
        indices = torch.empty(
            (b, groups, cap), device=x.device, dtype=torch.int32
        )
        _local_select[(b, groups)](
            x, values, indices, out,
            M=m, K=k, GROUPS=groups, KEEP=cap, TILE=tile,
            DIRECT=False, REPEATED=repeated,
            num_warps=4,
        )

        span = tile
        while groups > 1:
            next_groups = triton.cdiv(groups, 2)
            next_cap = min(k, 2 * cap)
            final = next_groups == 1
            if final:
                next_values = out
                next_indices = out
            else:
                next_values = torch.empty(
                    (b, next_groups, next_cap),
                    device=x.device,
                    dtype=torch.float32,
                )
                next_indices = torch.empty(
                    (b, next_groups, next_cap),
                    device=x.device,
                    dtype=torch.int32,
                )
            block = min(256, max(64, triton.next_power_of_2(2 * cap)))
            _merge_select[(b, next_groups, triton.cdiv(2 * cap, block))](
                values, indices, next_values, next_indices, out,
                M=m, K=k, GROUPS=groups, NEXT_GROUPS=next_groups,
                CAP=cap, NEXT_CAP=next_cap, SPAN=span, BLOCK=block,
                FINAL=final,
                num_warps=4,
            )
            values, indices = next_values, next_indices
            groups, cap = next_groups, next_cap
            span *= 2

        return out
```