import torch
import torch.nn as nn
import triton
import triton.language as tl
from triton.language.extra import libdevice


@triton.jit
def _rope_forward(
    X,
    Freqs,
    Y,
    HEADS: tl.constexpr,
    D: tl.constexpr,
    F: tl.constexpr,
    R: tl.constexpr,
    START: tl.constexpr,
    STYLE: tl.constexpr,
    REUSE: tl.constexpr,
    ROWS: tl.constexpr,
):
    sequence = tl.program_id(0)
    rows = tl.program_id(1) * ROWS + tl.arange(0, ROWS)
    channels = tl.arange(0, D)
    relative = channels - START
    rotating = (relative >= 0) & (relative < R)

    if STYLE == 0:
        partner = tl.where(relative < R // 2, relative + R // 2, relative - R // 2)
        negative = relative < R // 2
        if REUSE:
            angle_index = relative % (R // 2)
        else:
            angle_index = relative
    else:
        partner = relative ^ 1
        negative = (relative & 1) == 0
        if REUSE:
            angle_index = relative // 2
        else:
            angle_index = relative

    angles = tl.load(
        Freqs + sequence * F + angle_index,
        mask=rotating,
        other=0.0,
    ).to(tl.float32)
    cosine = libdevice.cos(angles)
    sine = libdevice.sin(angles)

    base = (sequence * HEADS + rows) * D
    values = tl.load(
        X + base[:, None] + channels[None, :],
        mask=rows[:, None] < HEADS,
        other=0.0,
    ).to(tl.float32)
    paired = tl.load(
        X + base[:, None] + START + partner[None, :],
        mask=(rows[:, None] < HEADS) & rotating[None, :],
        other=0.0,
    ).to(tl.float32)

    signed = tl.where(negative[None, :], -paired, paired)
    rotated = values * cosine[None, :] + signed * sine[None, :]
    result = tl.where(rotating[None, :], rotated, values)
    tl.store(
        Y + base[:, None] + channels[None, :],
        result,
        mask=rows[:, None] < HEADS,
    )


class ModelNew(nn.Module):
    def __init__(self, rotate_style: int, nope_first: bool, reuse_freqs_front_part: bool):
        super().__init__()
        self.rotate_style = int(rotate_style)
        self.nope_first = bool(nope_first)
        self.reuse_freqs_front_part = bool(reuse_freqs_front_part)

    def forward(self, x, freqs):
        s, b, h, d = x.shape
        f = freqs.shape[-1]
        r = f * (2 if self.reuse_freqs_front_part else 1)
        start = d - r if self.nope_first else 0
        heads = b * h
        rows = min(triton.next_power_of_2(heads), max(1, 1024 // d))
        out = torch.empty_like(x)
        _rope_forward[(s, triton.cdiv(heads, rows))](
            x,
            freqs,
            out,
            HEADS=heads,
            D=d,
            F=f,
            R=r,
            START=start,
            STYLE=self.rotate_style,
            REUSE=self.reuse_freqs_front_part,
            ROWS=rows,
            num_warps=4,
            enable_fp_fusion=False,
        )
        return out
