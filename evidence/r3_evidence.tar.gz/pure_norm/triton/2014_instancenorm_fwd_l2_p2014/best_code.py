import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _normalize_rows(
    X, Scale, Bias, Y,
    S: tl.constexpr, C: tl.constexpr, ROWS: tl.constexpr,
    EPS: tl.constexpr, BLOCK: tl.constexpr, GROUP: tl.constexpr,
):
    rows = tl.program_id(0) * GROUP + tl.arange(0, GROUP)
    cols = tl.arange(0, BLOCK)
    valid = (rows[:, None] < ROWS) & (cols[None, :] < S)
    offsets = rows[:, None] * S + cols[None, :]
    x = tl.load(X + offsets, valid, other=0).to(tl.float32)
    mean = tl.sum(x, axis=1) / S
    centered = x - mean[:, None]
    squared = tl.where(cols[None, :] < S, centered * centered, 0.0)
    variance = tl.sum(squared, axis=1) / S
    inv_std = tl.rsqrt(variance + EPS)
    scale = tl.load(Scale + rows % C, rows < ROWS, other=0).to(tl.float32)
    bias = tl.load(Bias + rows % C, rows < ROWS, other=0).to(tl.float32)
    y = ((centered * inv_std[:, None]) * scale[:, None]) + bias[:, None]
    tl.store(Y + offsets, y, valid)


@triton.jit
def _partial_statistics(
    X, PartialMean, PartialM2,
    S: tl.constexpr, PARTS: tl.constexpr, BLOCK: tl.constexpr,
):
    row = tl.program_id(0)
    part = tl.program_id(1)
    cols = part * BLOCK + tl.arange(0, BLOCK)
    valid = cols < S
    x = tl.load(X + row * S + cols, valid, other=0).to(tl.float32)
    count = tl.minimum(BLOCK, S - part * BLOCK)
    mean = tl.sum(x, axis=0) / count
    delta = x - mean
    m2 = tl.sum(tl.where(valid, delta * delta, 0.0), axis=0)
    tl.store(PartialMean + row * PARTS + part, mean)
    tl.store(PartialM2 + row * PARTS + part, m2)


@triton.jit
def _finish_statistics(
    PartialMean, PartialM2, Mean, InvStd,
    S: tl.constexpr, PARTS: tl.constexpr,
    CHUNK: tl.constexpr, BLOCK: tl.constexpr, EPS: tl.constexpr,
):
    row = tl.program_id(0)
    parts = tl.arange(0, BLOCK)
    valid = parts < PARTS
    count = tl.where(valid, tl.minimum(CHUNK, S - parts * CHUNK), 0).to(tl.float32)
    means = tl.load(PartialMean + row * PARTS + parts, valid, other=0)
    m2 = tl.load(PartialM2 + row * PARTS + parts, valid, other=0)
    mean = tl.sum(means * count, axis=0) / S
    delta = means - mean
    variance = tl.sum(m2 + delta * delta * count, axis=0) / S
    tl.store(Mean + row, mean)
    tl.store(InvStd + row, tl.rsqrt(variance + EPS))


@triton.jit
def _apply_normalization(
    X, Scale, Bias, Mean, InvStd, Y,
    S: tl.constexpr, C: tl.constexpr, BLOCK: tl.constexpr,
):
    row = tl.program_id(0)
    cols = tl.program_id(1) * BLOCK + tl.arange(0, BLOCK)
    valid = cols < S
    x = tl.load(X + row * S + cols, valid, other=0).to(tl.float32)
    mean = tl.load(Mean + row)
    inv_std = tl.load(InvStd + row)
    scale = tl.load(Scale + row % C).to(tl.float32)
    bias = tl.load(Bias + row % C).to(tl.float32)
    y = ((x - mean) * inv_std) * scale + bias
    tl.store(Y + row * S + cols, y, valid)


class ModelNew(nn.Module):
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        assert eps > 0, "eps must be positive"
        self.eps = float(eps)

    def forward(self, x, scale, bias):
        n, c, h, w = x.shape
        spatial = h * w
        rows = n * c
        out = torch.empty(x.shape, dtype=x.dtype, device=x.device)

        if spatial <= 8192:
            block = triton.next_power_of_2(spatial)
            group = min(16, max(1, 1024 // block))
            warps = 4 if block * group <= 2048 else 8
            _normalize_rows[(triton.cdiv(rows, group),)](
                x, scale, bias, out,
                spatial, c, rows, self.eps, block, group,
                num_warps=warps,
                enable_fp_fusion=False,
            )
        else:
            chunk = 2048
            parts = triton.cdiv(spatial, chunk)
            partial_mean = torch.empty(
                (rows, parts), dtype=torch.float32, device=x.device
            )
            partial_m2 = torch.empty_like(partial_mean)
            mean = torch.empty((rows,), dtype=torch.float32, device=x.device)
            inv_std = torch.empty_like(mean)

            _partial_statistics[(rows, parts)](
                x, partial_mean, partial_m2,
                spatial, parts, chunk,
                num_warps=4,
                enable_fp_fusion=False,
            )
            _finish_statistics[(rows,)](
                partial_mean, partial_m2, mean, inv_std,
                spatial, parts, chunk, triton.next_power_of_2(parts), self.eps,
                num_warps=4,
                enable_fp_fusion=False,
            )
            _apply_normalization[(rows, triton.cdiv(spatial, 1024))](
                x, scale, bias, mean, inv_std, out,
                spatial, c, 1024,
                num_warps=4,
                enable_fp_fusion=False,
            )
        return out
