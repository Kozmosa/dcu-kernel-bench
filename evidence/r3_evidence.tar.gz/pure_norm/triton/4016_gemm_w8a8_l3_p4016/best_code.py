import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _block_quantized_gemm(
    A, B, AS, BS, C,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    AM: tl.constexpr, AK: tl.constexpr,
    BN: tl.constexpr, BK: tl.constexpr,
    ASM: tl.constexpr, ASG: tl.constexpr,
    BSN: tl.constexpr, BSG: tl.constexpr,
    TM: tl.constexpr, TN: tl.constexpr,
):
    pm = tl.program_id(0)
    pn = tl.program_id(1)

    rm = pm * TM + tl.arange(0, TM)
    rn = pn * TN + tl.arange(0, TN)
    rk = tl.arange(0, 128)

    acc = tl.full((TM, TN), 0, tl.float32)

    for g in range(tl.cdiv(K, 128)):
        kk = g * 128 + rk
        a = tl.load(
            A + rm[:, None] * AM + kk[None, :] * AK,
            mask=(rm[:, None] < M) & (kk[None, :] < K),
            other=0,
        ).to(tl.int8)
        b = tl.load(
            B + rn[None, :] * BN + kk[:, None] * BK,
            mask=(rn[None, :] < N) & (kk[:, None] < K),
            other=0,
        ).to(tl.int8)

        dot = tl.dot(a, b, out_dtype=tl.int32).to(tl.float32)
        sa = tl.load(
            AS + rm * ASM + g * ASG,
            mask=rm < M,
            other=0,
        ).to(tl.float32)
        # TN divides 128, so each output tile has one weight block scale.
        sb = tl.load(BS + (pn * TN // 128) * BSN + g * BSG).to(
            tl.float32
        )
        acc = acc + dot * (sa[:, None] * sb)

    tl.store(
        C + rm[:, None] * N + rn[None, :],
        acc,
        mask=(rm[:, None] < M) & (rn[None, :] < N),
    )


class ModelNew(nn.Module):
    def __init__(self, out_dtype: str = "bfloat16"):
        super().__init__()
        self.out_dtype = getattr(torch, out_dtype)
        self.block_n = 128
        self.block_k = 128

    def forward(self, aq, bq, a_scale, b_scale):
        M, K = aq.shape
        N = bq.shape[0]
        assert K == bq.shape[1], "the K dimension of aq and bq must match"

        out = torch.empty((M, N), device=aq.device, dtype=self.out_dtype)
        tm = 16 if M <= 16 else 32
        tn = 32 if N <= 32 else 64

        _block_quantized_gemm[
            (triton.cdiv(M, tm), triton.cdiv(N, tn))
        ](
            aq, bq, a_scale, b_scale, out,
            M, N, K,
            aq.stride(0), aq.stride(1),
            bq.stride(0), bq.stride(1),
            a_scale.stride(0), a_scale.stride(1),
            b_scale.stride(0), b_scale.stride(1),
            tm, tn,
            num_warps=4,
            num_stages=2,
            enable_fp_fusion=False,
        )
        return out
