import math

import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _attention_parts(
    Q, KV, CS, POS, PTR, IDX, PART, STATS, OUT,
    H: tl.constexpr, C: tl.constexpr, R: tl.constexpr,
    RD: tl.constexpr, B: tl.constexpr, NS: tl.constexpr,
    SCALE: tl.constexpr, NEOX: tl.constexpr,
    QB: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
    KS: tl.constexpr, KD: tl.constexpr,
    CS0: tl.constexpr, CS1: tl.constexpr,
    PS: tl.constexpr, IS: tl.constexpr, TS: tl.constexpr,
    DC: tl.constexpr, DR: tl.constexpr, NT: tl.constexpr,
):
    bh = tl.program_id(0)
    split = tl.program_id(1)
    b = bh // H
    h = bh % H

    begin = tl.load(PTR + b * TS)
    end = tl.load(PTR + (b + 1) * TS)
    length = end - begin
    tiles = tl.cdiv(length, NT)
    tiles_per_split = tl.cdiv(tiles, NS)
    first = split * tiles_per_split * NT
    stop = tl.minimum(first + tiles_per_split * NT, length)

    dc = tl.arange(0, DC)
    dr = tl.arange(0, DR)
    ti = tl.arange(0, NT)
    qbase = Q + b * QB + h * QH
    qc = tl.load(qbase + dc * QD, dc < C, other=0).to(tl.float32)
    qr = tl.load(qbase + (C + dr) * QD, dr < R, other=0).to(tl.float32)

    if NEOX:
        second = dr >= RD // 2
        partner = tl.where(second, dr - RD // 2, dr + RD // 2)
        frequency = dr % (RD // 2)
    else:
        second = (dr % 2) != 0
        partner = dr ^ 1
        frequency = dr // 2

    pos = tl.load(POS + b * PS)
    cosine = tl.load(
        CS + pos * CS0 + frequency * CS1, dr < RD, other=1
    ).to(tl.float32)
    sine = tl.load(
        CS + pos * CS0 + (frequency + RD // 2) * CS1,
        dr < RD, other=0,
    ).to(tl.float32)
    qp = tl.load(
        qbase + (C + partner) * QD, dr < RD, other=0
    ).to(tl.float32)
    qr_rot = qr * cosine + tl.where(second, qp, -qp) * sine
    qr = tl.where(dr < RD, qr_rot, qr)

    last_row = tl.load(IDX + (end - 1) * IS).to(tl.int64)
    last = tl.load(
        KV + last_row * KS + (C + dr) * KD, dr < R, other=0
    ).to(tl.float32)
    last_partner = tl.load(
        KV + last_row * KS + (C + partner) * KD, dr < RD, other=0
    ).to(tl.float32)
    last_rot = last * cosine + tl.where(second, last_partner, -last_partner) * sine
    last = tl.where(dr < RD, last_rot, last)
    if (h == 0) & (split == 0):
        tl.store(OUT + B * H * C + b * R + dr, last, dr < R)

    maximum = tl.full((), -float("inf"), tl.float32)
    denominator = tl.full((), 0.0, tl.float32)
    accumulator = tl.full((DC,), 0.0, tl.float32)

    for offset in range(first, stop, NT):
        token = offset + ti
        valid = token < stop
        row = tl.load(IDX + (begin + token) * IS, valid, other=0).to(tl.int64)
        latent = tl.load(
            KV + row[:, None] * KS + dc[None, :] * KD,
            valid[:, None] & (dc[None, :] < C), other=0,
        ).to(tl.float32)
        rope = tl.load(
            KV + row[:, None] * KS + (C + dr[None, :]) * KD,
            valid[:, None] & (dr[None, :] < R), other=0,
        ).to(tl.float32)
        rope = tl.where((token == length - 1)[:, None], last[None, :], rope)
        score = (
            tl.sum(latent * qc[None, :], axis=1)
            + tl.sum(rope * qr[None, :], axis=1)
        ) * SCALE
        score = tl.where(valid, score, -float("inf"))
        new_maximum = tl.maximum(maximum, tl.max(score, axis=0))
        correction = tl.exp(maximum - new_maximum)
        probability = tl.exp(score - new_maximum)
        accumulator = accumulator * correction + tl.sum(
            probability[:, None] * latent, axis=0
        )
        denominator = denominator * correction + tl.sum(probability, axis=0)
        maximum = new_maximum

    slot = bh * NS + split
    tl.store(PART + slot * C + dc, accumulator, dc < C)
    tl.store(STATS + slot * 2, maximum)
    tl.store(STATS + slot * 2 + 1, denominator)


@tr.jit
def _combine(PART, STATS, OUT,
             C: tl.constexpr, NS: tl.constexpr,
             DC: tl.constexpr, DS: tl.constexpr):
    bh = tl.program_id(0)
    s = tl.arange(0, DS)
    d = tl.arange(0, DC)
    slot = bh * NS + s
    maximum = tl.load(STATS + slot * 2, s < NS, other=-float("inf"))
    denominator = tl.load(STATS + slot * 2 + 1, s < NS, other=0)
    global_maximum = tl.max(maximum, axis=0)
    weight = tl.exp(maximum - global_maximum)
    total = tl.sum(weight * denominator, axis=0)
    values = tl.load(
        PART + slot[:, None] * C + d[None, :],
        (s[:, None] < NS) & (d[None, :] < C), other=0,
    )
    result = tl.sum(values * weight[:, None], axis=0) / total
    tl.store(OUT + bh * C + d, result, d < C)


class ModelNew(nn.Module):
    def __init__(self, kv_lora_rank: int, qk_rope_head_dim: int,
                 rotary_dim: int, sm_scale=None, is_neox_style=True):
        super().__init__()
        self.kv_lora_rank = int(kv_lora_rank)
        self.qk_rope_head_dim = int(qk_rope_head_dim)
        self.rotary_dim = int(rotary_dim)
        self.sm_scale = (
            float(sm_scale) if sm_scale is not None
            else 1.0 / math.sqrt(self.kv_lora_rank + self.qk_rope_head_dim)
        )
        self.is_neox_style = bool(is_neox_style)

    def forward(self, q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices):
        b, h, dim = q.shape
        c = self.kv_lora_rank
        r = self.qk_rope_head_dim
        assert dim == c + r
        splits = min(32, max(1, tr.cdiv(kv_indices.numel(), max(1, b) * 256)))
        out = torch.empty((b * h * c + b * r,), device=q.device, dtype=q.dtype)
        if b == 0:
            return out
        partial = torch.empty(
            (b * h, splits, c), device=q.device, dtype=torch.float32
        )
        stats = torch.empty(
            (b * h, splits, 2), device=q.device, dtype=torch.float32
        )
        _attention_parts[(b * h, splits)](
            q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices,
            partial, stats, out,
            h, c, r, self.rotary_dim, b, splits,
            self.sm_scale, self.is_neox_style,
            q.stride(0), q.stride(1), q.stride(2),
            kv_cache.stride(0), kv_cache.stride(1),
            cos_sin_cache.stride(0), cos_sin_cache.stride(1),
            positions.stride(0) if positions.ndim == 1 else 1,
            kv_indices.stride(0), kv_indptr.stride(0),
            tr.next_power_of_2(c), tr.next_power_of_2(r), 32,
            num_warps=4, enable_fp_fusion=False,
        )
        _combine[(b * h,)](
            partial, stats, out, c, splits,
            tr.next_power_of_2(c), tr.next_power_of_2(splits),
            num_warps=4,
        )
        return out
