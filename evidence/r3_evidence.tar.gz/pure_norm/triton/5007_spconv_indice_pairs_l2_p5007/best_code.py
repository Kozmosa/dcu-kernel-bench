import math
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _make_map(
    X, Keys, Earliest, Slots,
    N: tl.constexpr, ND: tl.constexpr, BATCH: tl.constexpr,
    K: tl.constexpr, S: tl.constexpr, P: tl.constexpr,
    L: tl.constexpr, O: tl.constexpr,
    CHUNKS: tl.constexpr, HSIZE: tl.constexpr, BLOCK: tl.constexpr,
):
    chunk = tl.program_id(0)
    k = tl.program_id(1)
    lane = tl.arange(0, BLOCK)
    i = chunk * BLOCK + lane
    active = i < N
    batch = tl.load(X + i * (ND + 1), active, other=-1).to(tl.int32)
    valid = active & (batch >= 0) & (batch < BATCH)
    key = batch.to(tl.int64)
    for d in tl.static_range(ND):
        radix = 1
        for e in tl.static_range(d + 1, ND):
            radix *= K[e]
        offset = (k // radix) % K[d]
        x = tl.load(X + i * (ND + 1) + d + 1, active, other=0).to(tl.int32)
        value = x + P[d] - offset * L[d]
        q = value // S[d]
        valid &= (value >= 0) & (value % S[d] == 0) & (q < O[d])
        key = key * O[d] + q.to(tl.int64)

    h = key.to(tl.uint64)
    h = (h ^ (h >> 30)) * 0xbf58476d1ce4e5b9
    h = (h ^ (h >> 27)) * 0x94d049bb133111eb
    h = h ^ (h >> 31)
    pos = (h & (HSIZE - 1)).to(tl.int32)
    pending = valid
    while tl.sum(pending.to(tl.int32), 0) > 0:
        candidate = tl.where(pending, key, -1).to(tl.int64)
        old = tl.atomic_cas(Keys + pos, -1, candidate)
        accepted = (old == -1) | (old == key)
        pending = pending & ~accepted
        pos = tl.where(pending, (pos + 1) & (HSIZE - 1), pos)

    ordinal = k * N + i
    tl.atomic_min(Earliest + pos, ordinal, sem="relaxed", mask=valid)
    padded = (k * CHUNKS + chunk) * BLOCK + lane
    tl.store(Slots + padded, tl.where(valid, pos, -1))


@tr.jit
def _count_blocks(
    Slots, Earliest, Counts,
    N: tl.constexpr, CHUNKS: tl.constexpr,
    TOTAL: tl.constexpr, BLOCK: tl.constexpr,
):
    block = tl.program_id(0)
    lane = tl.arange(0, BLOCK)
    k = block // CHUNKS
    i = (block % CHUNKS) * BLOCK + lane
    slot = tl.load(Slots + block * BLOCK + lane)
    valid = slot >= 0
    first = tl.load(Earliest + slot, valid, other=-1)
    fresh = valid & (first == k * N + i)
    tl.store(Counts + block, tl.sum(valid.to(tl.int32), 0))
    tl.store(Counts + TOTAL + block, tl.sum(fresh.to(tl.int32), 0))


@tr.jit
def _scan_blocks(
    X, Y, Totals,
    N: tl.constexpr, GROUPS: tl.constexpr, BLOCK: tl.constexpr,
):
    block = tl.program_id(0)
    channel = tl.program_id(1)
    lane = tl.arange(0, BLOCK)
    idx = block * BLOCK + lane
    values = tl.load(X + channel * N + idx, idx < N, other=0)
    prefix = tl.cumsum(values, 0)
    tl.store(Y + channel * N + idx, prefix, idx < N)
    tl.store(Totals + channel * GROUPS + block, tl.sum(values, 0))


@tr.jit
def _add_scan_offsets(
    Y, Upper, N: tl.constexpr, GROUPS: tl.constexpr,
    BLOCK: tl.constexpr,
):
    block = tl.program_id(0)
    channel = tl.program_id(1)
    idx = block * BLOCK + tl.arange(0, BLOCK)
    carry = tl.load(
        Upper + channel * GROUPS + block - 1,
        block > 0, other=0,
    )
    value = tl.load(Y + channel * N + idx, idx < N, other=0)
    tl.store(Y + channel * N + idx, value + carry, idx < N)


@tr.jit
def _write_points(
    Slots, Keys, Earliest, Prefix, Ranks, Out,
    N: tl.constexpr, ND: tl.constexpr, O: tl.constexpr,
    CHUNKS: tl.constexpr, TOTAL: tl.constexpr, BLOCK: tl.constexpr,
):
    block = tl.program_id(0)
    lane = tl.arange(0, BLOCK)
    k = block // CHUNKS
    i = (block % CHUNKS) * BLOCK + lane
    slot = tl.load(Slots + block * BLOCK + lane)
    valid = slot >= 0
    first = tl.load(Earliest + slot, valid, other=-1)
    fresh = valid & (first == k * N + i)
    carry = tl.load(Prefix + TOTAL + block - 1, block > 0, other=0)
    rank = carry + tl.cumsum(fresh.to(tl.int32), 0) - 1
    tl.store(Ranks + slot, rank, fresh)

    key = tl.load(Keys + slot, fresh, other=0)
    for d in tl.static_range(ND - 1, -1, -1):
        coord = (key % O[d]).to(tl.int32)
        key = key // O[d]
        tl.store(Out + rank * (ND + 1) + d + 1, coord, fresh)
    tl.store(Out + rank * (ND + 1), key.to(tl.int32), fresh)


@tr.jit
def _write_pairs(
    Slots, Ranks, Prefix, Out,
    N: tl.constexpr, KV: tl.constexpr, ND: tl.constexpr,
    CAP: tl.constexpr, CHUNKS: tl.constexpr,
    TOTAL: tl.constexpr, BLOCK: tl.constexpr,
):
    block = tl.program_id(0)
    lane = tl.arange(0, BLOCK)
    k = block // CHUNKS
    chunk = block % CHUNKS
    i = chunk * BLOCK + lane
    slot = tl.load(Slots + block * BLOCK + lane)
    valid = slot >= 0
    before = tl.load(Prefix + block - 1, block > 0, other=0)
    start_block = k * CHUNKS
    start = tl.load(Prefix + start_block - 1, start_block > 0, other=0)
    count = tl.cumsum(valid.to(tl.int32), 0)
    position = before - start + count - 1
    rank = tl.load(Ranks + slot, valid, other=-1)
    base = CAP * (ND + 1)
    tl.store(Out + base + k * N + position, i, valid)
    tl.store(Out + base + KV * N + k * N + position, rank, valid)
    if chunk == CHUNKS - 1:
        end = tl.load(Prefix + block)
        tl.store(Out + base + 2 * KV * N + k, end - start)


def _inclusive_scan_two(x, length):
    block = 512
    groups = tr.cdiv(length, block)
    y = torch.empty((2, length), device=x.device, dtype=torch.int32)
    totals = torch.empty((2, groups), device=x.device, dtype=torch.int32)
    _scan_blocks[(groups, 2)](
        x, y, totals, length, groups, block, num_warps=4
    )
    if groups > 1:
        upper = _inclusive_scan_two(totals, groups)
        _add_scan_offsets[(groups, 2)](
            y, upper, length, groups, block, num_warps=4
        )
    return y


class ModelNew(nn.Module):
    def __init__(
        self, batch_size: int = 2, input_dims=None, ksize=None,
        stride=None, padding=None, dilation=None
    ):
        super().__init__()
        self.batch_size = int(batch_size)
        self.input_dims = list(input_dims if input_dims is not None else [4, 32, 32])
        self.ksize = list(ksize if ksize is not None else [3, 3, 3])
        self.stride = list(stride if stride is not None else [1, 1, 1])
        self.padding = list(padding if padding is not None else [1, 1, 1])
        self.dilation = list(dilation if dilation is not None else [1, 1, 1])
        assert self.batch_size >= 1
        self.ndim = len(self.input_dims)
        assert 1 <= self.ndim <= 3
        assert all(
            len(p) == self.ndim
            for p in (self.ksize, self.stride, self.padding, self.dilation)
        )
        self.output_dims = []
        for d in range(self.ndim):
            assert self.input_dims[d] >= 1
            assert self.ksize[d] >= 1
            assert self.stride[d] >= 1
            assert self.padding[d] >= 0
            assert self.dilation[d] >= 1
            size = (
                self.input_dims[d] + 2 * self.padding[d]
                - self.dilation[d] * (self.ksize[d] - 1) - 1
            ) // self.stride[d] + 1
            assert size >= 1
            self.output_dims.append(size)
        self.kv = math.prod(self.ksize)
        self.volume = self.batch_size * math.prod(self.output_dims)

    def forward(self, indices):
        n = indices.shape[0]
        nd = self.ndim
        kv = self.kv
        cap = min(kv * n, self.volume)
        block = 256
        chunks = tr.cdiv(n, block)
        total = kv * chunks
        hsize = tr.next_power_of_2(max(2, 2 * cap))
        device = indices.device

        out = torch.full(
            (cap * (nd + 1) + 2 * kv * n + kv,),
            -1, dtype=torch.int32, device=device,
        )
        keys = torch.full((hsize,), -1, dtype=torch.int64, device=device)
        earliest = torch.full(
            (hsize,), 2147483647, dtype=torch.int32, device=device
        )
        slots = torch.empty(
            (total * block,), dtype=torch.int32, device=device
        )
        counts = torch.empty((2, total), dtype=torch.int32, device=device)
        ranks = torch.empty((hsize,), dtype=torch.int32, device=device)

        _make_map[(chunks, kv)](
            indices, keys, earliest, slots,
            n, nd, self.batch_size,
            tuple(self.ksize), tuple(self.stride), tuple(self.padding),
            tuple(self.dilation), tuple(self.output_dims),
            chunks, hsize, block, num_warps=4,
        )
        _count_blocks[(total,)](
            slots, earliest, counts, n, chunks, total, block, num_warps=4
        )
        prefix = _inclusive_scan_two(counts, total)
        _write_points[(total,)](
            slots, keys, earliest, prefix, ranks, out,
            n, nd, tuple(self.output_dims), chunks, total, block,
            num_warps=4,
        )
        _write_pairs[(total,)](
            slots, ranks, prefix, out,
            n, kv, nd, cap, chunks, total, block, num_warps=4,
        )
        return out
