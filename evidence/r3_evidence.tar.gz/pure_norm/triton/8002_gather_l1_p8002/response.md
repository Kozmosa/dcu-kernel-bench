```python
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _select_kernel(
    Data,
    Indices,
    Out,
    N: tl.constexpr,
    AXIS_SIZE: tl.constexpr,
    K: tl.constexpr,
    INNER: tl.constexpr,
    ELEMENTWISE: tl.constexpr,
    INDEX_CONTIGUOUS: tl.constexpr,
    INDEX_SHAPE: tl.constexpr,
    INDEX_STRIDES: tl.constexpr,
    BLOCK: tl.constexpr,
):
    pos = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = pos < N

    if ELEMENTWISE:
        if INDEX_CONTIGUOUS:
            index_offset = pos
        else:
            remaining = pos
            index_offset = tl.full((BLOCK,), 0, tl.int32)
            for dim in tl.static_range(len(INDEX_SHAPE) - 1, -1, -1):
                coordinate = remaining % INDEX_SHAPE[dim]
                remaining = remaining // INDEX_SHAPE[dim]
                index_offset += coordinate * INDEX_STRIDES[dim]
    else:
        index_offset = ((pos // INNER) % K) * INDEX_STRIDES[0]

    selected = tl.load(Indices + index_offset, valid, other=0).to(tl.int32)
    outer = pos // (K * INNER)
    inner = pos % INNER
    source_offset = (outer * AXIS_SIZE + selected) * INNER + inner
    value = tl.load(Data + source_offset, valid, other=0)
    tl.store(Out + pos, value, valid)


@tr.jit
def _select_slices_kernel(
    Data,
    Indices,
    Out,
    AXIS_SIZE: tl.constexpr,
    K: tl.constexpr,
    INNER: tl.constexpr,
    INDEX_STRIDE: tl.constexpr,
    BLOCK: tl.constexpr,
):
    slice_id = tl.program_id(0)
    inner = tl.program_id(1) * BLOCK + tl.arange(0, BLOCK)
    outer = slice_id // K
    selected = tl.load(Indices + (slice_id % K) * INDEX_STRIDE).to(tl.int32)
    value = tl.load(
        Data + (outer * AXIS_SIZE + selected) * INNER + inner,
        inner < INNER,
        other=0,
    )
    tl.store(Out + slice_id * INNER + inner, value, inner < INNER)


class ModelNew(nn.Module):
    def __init__(self, variant: str = "gather", axis: int = 1):
        super().__init__()
        assert variant in ("gather", "gather_elements"), (
            "variant must be one of gather / gather_elements"
        )
        self.variant = variant
        self.axis = int(axis)

    def forward(self, data, indices):
        ndim = data.dim()
        axis = self.axis % ndim
        elementwise = self.variant == "gather_elements"

        if elementwise:
            shape = tuple(indices.shape)
            k = shape[axis]
        else:
            k = indices.shape[0]
            shape = tuple(data.shape[:axis]) + (k,) + tuple(data.shape[axis + 1:])

        out = torch.empty(shape, device=data.device, dtype=data.dtype)
        n = out.numel()
        if n == 0:
            return out

        inner = 1
        for dim in range(axis + 1, ndim):
            inner *= data.shape[dim]

        block = 1024
        if not elementwise and inner >= 1024:
            _select_slices_kernel[(n // inner, tr.cdiv(inner, block))](
                data,
                indices,
                out,
                AXIS_SIZE=data.shape[axis],
                K=k,
                INNER=inner,
                INDEX_STRIDE=indices.stride(0),
                BLOCK=block,
                num_warps=4,
            )
        else:
            _select_kernel[(tr.cdiv(n, block),)](
                data,
                indices,
                out,
                N=n,
                AXIS_SIZE=data.shape[axis],
                K=k,
                INNER=inner,
                ELEMENTWISE=elementwise,
                INDEX_CONTIGUOUS=indices.is_contiguous(),
                INDEX_SHAPE=tuple(indices.shape),
                INDEX_STRIDES=tuple(indices.stride()),
                BLOCK=block,
                num_warps=4,
            )
        return out
```