```python
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _zero(O, N: tl.constexpr, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    tl.store(O + i, 0.0, i < N)


@tr.jit
def _normalize(A, W, K: tl.constexpr, B: tl.constexpr):
    row = tl.program_id(0)
    p = tl.arange(0, B)
    a = tl.load(A + row * K + p, p < K, other=-float("inf")).to(tl.float32)
    e = tl.exp(a - tl.max(a, 0))
    w = e / tl.sum(e, 0)
    tl.store(W + row * K + p, w, p < K)


@tr.jit
def _point_backward(
    V, Shapes, Starts, Loc, W, GO, O, T,
    NK: tl.constexpr, NH: tl.constexpr, D: tl.constexpr,
    Q: tl.constexpr, P: tl.constexpr, K: tl.constexpr,
    NV: tl.constexpr, B: tl.constexpr,
):
    point = tl.program_id(0)
    row = point // K
    level = (point % K) // P
    head = row % NH
    batch = row // (Q * NH)

    height = tl.load(Shapes + level * 2).to(tl.int32)
    width = tl.load(Shapes + level * 2 + 1).to(tl.int32)
    start = tl.load(Starts + level).to(tl.int64)

    sx = tl.load(Loc + point * 2).to(tl.float32) * width
    sy = tl.load(Loc + point * 2 + 1).to(tl.float32) * height
    x = tl.floor(sx).to(tl.int32)
    y = tl.floor(sy).to(tl.int32)
    fx = sx - x.to(tl.float32)
    fy = sy - y.to(tl.float32)
    ax = 1.0 - fx
    ay = 1.0 - fy

    m00 = (x >= 0) & (x < width) & (y >= 0) & (y < height)
    m01 = (x + 1 >= 0) & (x + 1 < width) & (y >= 0) & (y < height)
    m10 = (x >= 0) & (x < width) & (y + 1 >= 0) & (y + 1 < height)
    m11 = (x + 1 >= 0) & (x + 1 < width) & (y + 1 >= 0) & (y + 1 < height)

    base = batch.to(tl.int64) * NK + start
    i00 = ((base + y * width + x) * NH + head) * D
    i01 = i00 + NH * D
    i10 = i00 + width.to(tl.int64) * NH * D
    i11 = i10 + NH * D

    w = tl.load(W + point)
    c00 = ay * ax
    c01 = ay * fx
    c10 = fy * ax
    c11 = fy * fx

    lanes = tl.arange(0, B)
    st = tl.full((B,), 0, tl.float32)
    dx = tl.full((B,), 0, tl.float32)
    dy = tl.full((B,), 0, tl.float32)

    for block in range(tr.cdiv(D, B)):
        c = block * B + lanes
        active = c < D
        g = tl.load(GO + row.to(tl.int64) * D + c, active, other=0).to(tl.float32)
        v00 = tl.load(V + i00 + c, active & m00, other=0).to(tl.float32)
        v01 = tl.load(V + i01 + c, active & m01, other=0).to(tl.float32)
        v10 = tl.load(V + i10 + c, active & m10, other=0).to(tl.float32)
        v11 = tl.load(V + i11 + c, active & m11, other=0).to(tl.float32)

        sample = ((v00 * c00 + v01 * c01) + v10 * c10) + v11 * c11
        st += g * sample
        gw = g * w

        # Follow the interpolation backward's operation ordering.
        a00 = gw * v00
        a01 = gw * v01
        a10 = gw * v10
        a11 = gw * v11
        dx += ((a11 * fy + a01 * ay) - a10 * fy) - a00 * ay
        dy += ((a11 * fx + a10 * ax) - a01 * fx) - a00 * ax

        tl.atomic_add(O + i00 + c, gw * c00, active & m00, sem="relaxed")
        tl.atomic_add(O + i01 + c, gw * c01, active & m01, sem="relaxed")
        tl.atomic_add(O + i10 + c, gw * c10, active & m10, sem="relaxed")
        tl.atomic_add(O + i11 + c, gw * c11, active & m11, sem="relaxed")

    tl.store(T + point, tl.sum(st, 0))
    tl.store(O + NV + point.to(tl.int64) * 2, tl.sum(dx, 0) * width)
    tl.store(O + NV + point.to(tl.int64) * 2 + 1, tl.sum(dy, 0) * height)


@tr.jit
def _weight_backward(
    W, T, O, K: tl.constexpr, OFFSET: tl.constexpr, B: tl.constexpr,
):
    row = tl.program_id(0)
    k = tl.arange(0, B)
    i = row.to(tl.int64) * K + k
    w = tl.load(W + i, k < K, other=0)
    t = tl.load(T + i, k < K, other=0)
    mean = tl.sum(w * t, 0)
    result = w * (t - mean)
    if K == 1:
        result = tl.full((B,), 0, tl.float32)
    tl.store(O + OFFSET + i, result, k < K)


@tr.jit
def _cast(X, Y, N: tl.constexpr, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    tl.store(Y + i, tl.load(X + i, i < N, other=0), i < N)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, value, spatial_shapes, level_start_index,
                sampling_locations, attention_weights, grad_output):
        n, n_keys, heads, d = value.shape
        q = sampling_locations.shape[1]
        levels = spatial_shapes.shape[0]
        points = sampling_locations.shape[4]
        k = levels * points
        rows = n * q * heads
        samples = rows * k
        nv = n * n_keys * heads * d
        total = nv + 3 * samples

        # Metadata may be supplied on the host; conversion to integer indices
        # happens inside the sampling kernel.
        if spatial_shapes.device != value.device:
            spatial_shapes = spatial_shapes.to(device=value.device)
        if level_start_index.device != value.device:
            level_start_index = level_start_index.to(device=value.device)

        output = torch.empty(total, device=value.device, dtype=torch.float32)
        weights = torch.empty(samples, device=value.device, dtype=torch.float32)
        dots = torch.empty_like(weights)

        _zero[(tr.cdiv(nv, 1024),)](output, nv, 1024)
        kb = tr.next_power_of_2(k)
        softmax_warps = 4 if kb <= 2048 else 8
        _normalize[(rows,)](
            attention_weights, weights, k, kb,
            num_warps=softmax_warps,
        )
        cb = min(256, max(32, tr.next_power_of_2(d)))
        _point_backward[(samples,)](
            value, spatial_shapes, level_start_index, sampling_locations,
            weights, grad_output, output, dots,
            n_keys, heads, d, q, points, k, nv, cb,
            num_warps=4, enable_fp_fusion=False,
        )
        _weight_backward[(rows,)](
            weights, dots, output, k, nv + 2 * samples, kb,
            num_warps=softmax_warps, enable_fp_fusion=False,
        )
        if value.dtype != torch.float32:
            result = torch.empty(total, device=value.device, dtype=value.dtype)
            _cast[(tr.cdiv(total, 1024),)](output, result, total, 1024)
            return result
        return output
```