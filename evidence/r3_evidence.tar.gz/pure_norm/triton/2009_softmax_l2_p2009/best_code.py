import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _softmax_rows(
    X, Y,
    M: tl.constexpr, N: tl.constexpr,
    SX0: tl.constexpr, SX1: tl.constexpr,
    R: tl.constexpr, B: tl.constexpr,
):
    rows = tl.program_id(0) * R + tl.arange(0, R)
    cols = tl.arange(0, B)
    valid = (rows[:, None] < M) & (cols[None, :] < N)
    values = tl.load(
        X + rows[:, None].to(tl.int64) * SX0 + cols[None, :] * SX1,
        mask=valid,
        other=-float("inf"),
    ).to(tl.float32)
    maxima = tl.max(values, axis=1)
    # Keep padded rows finite without changing any valid row.
    maxima = tl.where(rows < M, maxima, 0.0)
    exponentials = tl.exp(values - maxima[:, None])
    totals = tl.sum(exponentials, axis=1)
    totals = tl.where(rows < M, totals, 1.0)
    result = exponentials / totals[:, None]
    tl.store(
        Y + rows[:, None].to(tl.int64) * N + cols[None, :],
        result,
        mask=valid,
    )


@triton.jit
def _fill_ones(Y, M: tl.constexpr, B: tl.constexpr):
    offsets = tl.program_id(0) * B + tl.arange(0, B)
    tl.store(Y + offsets, 1.0, mask=offsets < M)


@triton.jit
def _chunk_stats(
    X, StatsMax, StatsSum,
    N: tl.constexpr, C: tl.constexpr,
    SX0: tl.constexpr, SX1: tl.constexpr,
    B: tl.constexpr,
):
    row = tl.program_id(0)
    chunk = tl.program_id(1)
    cols = chunk * B + tl.arange(0, B)
    values = tl.load(
        X + row.to(tl.int64) * SX0 + cols * SX1,
        mask=cols < N,
        other=-float("inf"),
    ).to(tl.float32)
    maximum = tl.max(values, axis=0)
    total = tl.sum(tl.exp(values - maximum), axis=0)
    offset = row.to(tl.int64) * C + chunk
    tl.store(StatsMax + offset, maximum)
    tl.store(StatsSum + offset, total)


@triton.jit
def _combine_stats(
    StatsMax, StatsSum, RowMax, RowInvSum,
    C: tl.constexpr, B: tl.constexpr,
):
    row = tl.program_id(0)
    chunks = tl.arange(0, B)
    offsets = row.to(tl.int64) * C + chunks
    maxima = tl.load(StatsMax + offsets, chunks < C, other=-float("inf"))
    sums = tl.load(StatsSum + offsets, chunks < C, other=0.0)
    maximum = tl.max(maxima, axis=0)
    total = tl.sum(sums * tl.exp(maxima - maximum), axis=0)
    tl.store(RowMax + row, maximum)
    tl.store(RowInvSum + row, 1.0 / total)


@triton.jit
def _normalize_chunks(
    X, Y, RowMax, RowInvSum,
    N: tl.constexpr,
    SX0: tl.constexpr, SX1: tl.constexpr,
    B: tl.constexpr,
):
    row = tl.program_id(0)
    cols = tl.program_id(1) * B + tl.arange(0, B)
    maximum = tl.load(RowMax + row)
    inverse = tl.load(RowInvSum + row)
    values = tl.load(
        X + row.to(tl.int64) * SX0 + cols * SX1,
        mask=cols < N,
        other=-float("inf"),
    ).to(tl.float32)
    result = tl.exp(values - maximum) * inverse
    tl.store(Y + row.to(tl.int64) * N + cols, result, mask=cols < N)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        m, n = x.shape
        y = torch.empty((m, n), dtype=x.dtype, device=x.device)
        if m == 0:
            return y

        if n == 1:
            _fill_ones[(triton.cdiv(m, 1024),)](y, m, 1024)
            return y

        sx0, sx1 = x.stride()
        if n <= 32768:
            b = triton.next_power_of_2(n)
            if b <= 256:
                r = min(16, max(1, 1024 // b))
                warps = 4
            elif b <= 1024:
                r = 4
                warps = 4
            else:
                r = 1
                warps = 4 if b <= 4096 else (8 if b <= 16384 else 16)
            _softmax_rows[(triton.cdiv(m, r),)](
                x, y, m, n, sx0, sx1, r, b,
                num_warps=warps,
            )
            return y

        block = 4096
        chunks = triton.cdiv(n, block)
        stats_max = torch.empty((m, chunks), dtype=torch.float32, device=x.device)
        stats_sum = torch.empty_like(stats_max)
        row_max = torch.empty((m,), dtype=torch.float32, device=x.device)
        row_inv_sum = torch.empty_like(row_max)

        _chunk_stats[(m, chunks)](
            x, stats_max, stats_sum, n, chunks, sx0, sx1, block,
            num_warps=4,
        )
        _combine_stats[(m,)](
            stats_max, stats_sum, row_max, row_inv_sum,
            chunks, triton.next_power_of_2(chunks),
            num_warps=4,
        )
        _normalize_chunks[(m, chunks)](
            x, y, row_max, row_inv_sum, n, sx0, sx1, block,
            num_warps=4,
        )
        return y
