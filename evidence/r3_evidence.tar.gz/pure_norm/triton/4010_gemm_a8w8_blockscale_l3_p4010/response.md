```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _block_scaled_gemm(
    X, W, XS, WS, Y,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    GK: tl.constexpr, GN: tl.constexpr,
    X0: tl.constexpr, X1: tl.constexpr,
    W0: tl.constexpr, W1: tl.constexpr,
    XS0: tl.constexpr, XS1: tl.constexpr,
    WS0: tl.constexpr, WS1: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    pm = tl.program_id(0)
    pn = tl.program_id(1)

    rows = pm * BM + tl.arange(0, BM)
    cols = pn * BN + tl.arange(0, BN)
    rk = tl.arange(0, BK)

    acc = tl.full((BM, BN), 0.0, tl.float32)

    for start in range(tl.cdiv(K, BK)):
        kk = start * BK + rk
        groups = kk // GK

        a = tl.load(
            X + rows[:, None] * X0 + kk[None, :] * X1,
            mask=(rows[:, None] < M) & (kk[None, :] < K),
            other=0.0,
        ).to(tl.float32)
        b = tl.load(
            W + cols[None, :] * W0 + kk[:, None] * W1,
            mask=(cols[None, :] < N) & (kk[:, None] < K),
            other=0.0,
        ).to(tl.float32)

        sa = tl.load(
            XS + rows[:, None] * XS0 + groups[None, :] * XS1,
            mask=(rows[:, None] < M) & (kk[None, :] < K),
            other=0.0,
        ).to(tl.float32)
        sb = tl.load(
            WS + (cols[None, :] // GN) * WS0 + groups[:, None] * WS1,
            mask=(cols[None, :] < N) & (kk[:, None] < K),
            other=0.0,
        ).to(tl.float32)

        a = a * sa
        b = b * sb
        acc = tl.dot(a, b, acc, input_precision="ieee")

    tl.store(
        Y + rows[:, None] * N + cols[None, :],
        acc,
        mask=(rows[:, None] < M) & (cols[None, :] < N),
    )


class ModelNew(nn.Module):
    def __init__(self, group_k=128, group_n=128, out_dtype="bfloat16"):
        super().__init__()
        if isinstance(group_k, (list, tuple)):
            group_k, group_n, out_dtype = group_k
        self.group_k = int(group_k)
        self.group_n = int(group_n)
        self.out_dtype = getattr(torch, out_dtype)

    def forward(self, x, w, x_scale, w_scale):
        m, k = x.shape
        n = w.shape[0]
        gk, gn = self.group_k, self.group_n
        assert k == w.shape[1], "the K dimension of x and w must match"
        assert gk > 0 and gn > 0
        scale_k = (k + gk - 1) // gk
        scale_n = (n + gn - 1) // gn
        assert x_scale.shape == (m, scale_k), (
            f"x_scale shape should be ({m}, {scale_k}), "
            f"got {tuple(x_scale.shape)}"
        )
        assert w_scale.shape == (scale_n, scale_k), (
            f"w_scale shape should be ({scale_n}, {scale_k}), "
            f"got {tuple(w_scale.shape)}"
        )

        # Input code words are exactly representable FP8 values, including
        # when the evaluator supplies them in float32 storage.
        out = torch.empty((m, n), device=x.device, dtype=self.out_dtype)
        bm = 16 if m <= 16 else 32
        bn = 32
        with torch.cuda.device(x.device):
            _block_scaled_gemm[
                (triton.cdiv(m, bm), triton.cdiv(n, bn))
            ](
                x, w, x_scale, w_scale, out,
                m, n, k, gk, gn,
                x.stride(0), x.stride(1),
                w.stride(0), w.stride(1),
                x_scale.stride(0), x_scale.stride(1),
                w_scale.stride(0), w_scale.stride(1),
                bm, bn, 32,
                num_warps=4,
                num_stages=2,
                enable_fp_fusion=False,
            )
        return out
```