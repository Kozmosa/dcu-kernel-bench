import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _dgrad_kernel(
    W, G, P, Counts, DX,
    N: tl.constexpr, CI: tl.constexpr, CO: tl.constexpr, KV: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    pair_block = tl.program_id(0)
    channel_block = tl.program_id(1)
    k = tl.program_id(2)
    count = tl.load(Counts + k).to(tl.int32)
    if pair_block * BM < count:
        j = pair_block * BM + tl.arange(0, BM)
        i = channel_block * BN + tl.arange(0, BN)
        r = tl.arange(0, BK)
        valid = j < count
        src = tl.load(P + k * N + j, valid, 0).to(tl.int32)
        dst = tl.load(P + (KV + k) * N + j, valid, 0).to(tl.int32)
        acc = tl.full((BM, BN), 0, tl.float32)
        for base in range(tr.cdiv(CO, BK)):
            o = base * BK + r
            g = tl.load(
                G + dst[:, None] * CO + o[None, :],
                valid[:, None] & (o[None, :] < CO), 0,
            ).to(tl.float32)
            w = tl.load(
                W + o[:, None] * (KV * CI) + k * CI + i[None, :],
                (o[:, None] < CO) & (i[None, :] < CI), 0,
            ).to(tl.float32)
            acc += tl.dot(g, w, input_precision="ieee")
        tl.atomic_add(
            DX + src[:, None] * CI + i[None, :],
            acc,
            valid[:, None] & (i[None, :] < CI),
            sem="relaxed",
        )


@tr.jit
def _wgrad_kernel(
    X, G, P, Counts, Partial,
    N: tl.constexpr, CI: tl.constexpr, CO: tl.constexpr, KV: tl.constexpr,
    SPLITS: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    tile = tl.program_id(0)
    k = tl.program_id(1)
    split = tl.program_id(2)
    o = (tile // tr.cdiv(CI, BN)) * BM + tl.arange(0, BM)
    i = (tile % tr.cdiv(CI, BN)) * BN + tl.arange(0, BN)
    r = tl.arange(0, BK)
    count = tl.load(Counts + k).to(tl.int32)
    acc = tl.full((BM, BN), 0, tl.float32)
    for base in range(split * BK, count, SPLITS * BK):
        j = base + r
        valid = j < count
        src = tl.load(P + k * N + j, valid, 0).to(tl.int32)
        dst = tl.load(P + (KV + k) * N + j, valid, 0).to(tl.int32)
        g = tl.load(
            G + dst[None, :] * CO + o[:, None],
            valid[None, :] & (o[:, None] < CO), 0,
        ).to(tl.float32)
        x = tl.load(
            X + src[:, None] * CI + i[None, :],
            valid[:, None] & (i[None, :] < CI), 0,
        ).to(tl.float32)
        acc += tl.dot(g, x, input_precision="ieee")
    offsets = (
        split * (CO * KV * CI)
        + o[:, None] * (KV * CI)
        + k * CI
        + i[None, :]
    )
    tl.store(
        Partial + offsets, acc,
        (o[:, None] < CO) & (i[None, :] < CI),
    )


@tr.jit
def _finish_kernel(
    Partial, Output,
    SIZE: tl.constexpr, SPLITS: tl.constexpr,
    RS: tl.constexpr, BLOCK: tl.constexpr,
):
    x = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    s = tl.arange(0, RS)
    v = tl.load(
        Partial + s[:, None] * SIZE + x[None, :],
        (s[:, None] < SPLITS) & (x[None, :] < SIZE),
        0,
    )
    result = tl.sum(v, axis=0)
    tl.store(Output + x, result, x < SIZE)


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dgrad"):
        super().__init__()
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant

    def forward(self, features, filters, out_bp, indice_pairs, indice_num_per_loc):
        n, ci = features.shape
        co, _, kv = filters.shape

        if self.variant == "dgrad":
            accum = torch.zeros(
                (n, ci), device=features.device, dtype=torch.float32
            )
            _dgrad_kernel[
                (tr.cdiv(n, 32), tr.cdiv(ci, 32), kv)
            ](
                filters, out_bp, indice_pairs, indice_num_per_loc, accum,
                n, ci, co, kv, 32, 32, 32,
                num_warps=4,
            )
            if features.dtype == torch.float32:
                return accum
            output = torch.empty(
                (n, ci), device=features.device, dtype=features.dtype
            )
            _finish_kernel[(tr.cdiv(n * ci, 256),)](
                accum, output, n * ci, 1, 1, 256, num_warps=4
            )
            return output

        splits = min(32, max(1, tr.cdiv(n, 512)))
        output = torch.empty(
            (co, ci, kv), device=features.device, dtype=features.dtype
        )
        size = co * kv * ci
        if splits == 1 and features.dtype == torch.float32:
            partial = output
        else:
            partial = torch.empty(
                (splits, size), device=features.device, dtype=torch.float32
            )
        _wgrad_kernel[
            (tr.cdiv(co, 32) * tr.cdiv(ci, 32), kv, splits)
        ](
            features, out_bp, indice_pairs, indice_num_per_loc, partial,
            n, ci, co, kv, splits, 32, 32, 32,
            num_warps=4,
        )
        if partial is not output:
            _finish_kernel[(tr.cdiv(size, 256),)](
                partial, output, size, splits, tr.next_power_of_2(splits),
                256, num_warps=4,
            )
        return output
