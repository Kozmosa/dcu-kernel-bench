```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _zero_kernel(Out, SIZE: tl.constexpr, BLOCK: tl.constexpr):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    tl.store(Out + offsets, 0.0, offsets < SIZE)


@triton.jit
def _sparse_forward_kernel(
    Features,
    Filters,
    Pairs,
    Counts,
    Out,
    N: tl.constexpr,
    CI: tl.constexpr,
    CO: tl.constexpr,
    KV: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BK: tl.constexpr,
):
    pair_block = tl.program_id(0)
    channel_block = tl.program_id(1)
    kernel_offset = tl.program_id(2)

    count = tl.load(Counts + kernel_offset).to(tl.int32)
    if pair_block * BM < count:
        rows = pair_block * BM + tl.arange(0, BM)
        columns = channel_block * BN + tl.arange(0, BN)
        reduction = tl.arange(0, BK)
        valid_rows = (rows < count) & (rows < N)

        input_rows = tl.load(
            Pairs + kernel_offset * N + rows,
            mask=valid_rows,
            other=0,
        ).to(tl.int32)
        output_rows = tl.load(
            Pairs + KV * N + kernel_offset * N + rows,
            mask=valid_rows,
            other=0,
        ).to(tl.int32)

        accum = tl.full((BM, BN), 0.0, tl.float32)
        for block in range(tl.cdiv(CI, BK)):
            channels = block * BK + reduction
            x = tl.load(
                Features + input_rows[:, None] * CI + channels[None, :],
                mask=valid_rows[:, None] & (channels[None, :] < CI),
                other=0.0,
            ).to(tl.float32)
            w = tl.load(
                Filters
                + columns[None, :] * (KV * CI)
                + kernel_offset * CI
                + channels[:, None],
                mask=(channels[:, None] < CI) & (columns[None, :] < CO),
                other=0.0,
            ).to(tl.float32)
            accum = tl.dot(x, w, accum, input_precision="ieee")

        tl.atomic_add(
            Out + output_rows[:, None] * CO + columns[None, :],
            accum,
            mask=valid_rows[:, None] & (columns[None, :] < CO),
            sem="relaxed",
        )


@triton.jit
def _cast_kernel(Source, Destination, SIZE: tl.constexpr, BLOCK: tl.constexpr):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    values = tl.load(Source + offsets, offsets < SIZE, other=0.0)
    tl.store(Destination + offsets, values, offsets < SIZE)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, features, filters, indice_pairs, indice_num_per_loc, num_act_out):
        output_rows = int(num_act_out)
        c_out, c_in, kv = filters.shape
        n = features.shape[0]
        size = output_rows * c_out

        accumulator = torch.empty(
            (output_rows, c_out),
            dtype=torch.float32,
            device=features.device,
        )
        if size == 0:
            return torch.empty(
                (output_rows, c_out),
                dtype=features.dtype,
                device=features.device,
            )

        with torch.cuda.device(features.device):
            _zero_kernel[(triton.cdiv(size, 1024),)](
                accumulator, SIZE=size, BLOCK=1024
            )
            _sparse_forward_kernel[
                (triton.cdiv(n, 16), triton.cdiv(c_out, 32), kv)
            ](
                features,
                filters,
                indice_pairs,
                indice_num_per_loc,
                accumulator,
                N=n,
                CI=c_in,
                CO=c_out,
                KV=kv,
                BM=16,
                BN=32,
                BK=32,
                num_warps=4,
            )

            if features.dtype == torch.float32:
                return accumulator

            output = torch.empty(
                (output_rows, c_out),
                dtype=features.dtype,
                device=features.device,
            )
            _cast_kernel[(triton.cdiv(size, 1024),)](
                accumulator, output, SIZE=size, BLOCK=1024
            )
            return output
```