```python
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl
import triton.language.extra.libdevice as libdevice


@tr.jit
def _encode(q, FP8: tl.constexpr):
    if FP8:
        # E4M3 has three fraction bits and a minimum subnormal of 2**-9.
        bits = tl.abs(q).to(tl.int32, bitcast=True)
        exponent = (bits >> 23) & 255
        step_exponent = tl.maximum(exponent - 3, 118)
        step = (step_exponent << 23).to(tl.float32, bitcast=True)
        inv_step = ((254 - step_exponent) << 23).to(tl.float32, bitcast=True)
        return libdevice.nearbyint(q * inv_step) * step
    else:
        return libdevice.nearbyint(q)


@tr.jit
def _tokens(X, Y, R: tl.constexpr, C: tl.constexpr,
            MAX: tl.constexpr, FP8: tl.constexpr, B: tl.constexpr):
    row = tl.program_id(0)
    j = tl.arange(0, B)
    if C <= B:
        v = tl.load(X + row * C + j, j < C, other=0).to(tl.float32)
        amax = tl.max(tl.abs(v), 0)
        s = tl.div_rn(tl.maximum(amax, 1.0e-10), MAX)
        inv = tl.div_rn(1.0, s)
        tl.store(Y + row * C + j, _encode(v * inv, FP8), j < C)
    else:
        acc = tl.full((B,), 0, tl.float32)
        for start in range(tr.cdiv(C, B)):
            col = start * B + j
            v = tl.load(X + row * C + col, col < C, other=0).to(tl.float32)
            acc = tl.maximum(acc, tl.abs(v))
        s = tl.div_rn(tl.maximum(tl.max(acc, 0), 1.0e-10), MAX)
        inv = tl.div_rn(1.0, s)
        for start in range(tr.cdiv(C, B)):
            col = start * B + j
            v = tl.load(X + row * C + col, col < C, other=0).to(tl.float32)
            tl.store(Y + row * C + col, _encode(v * inv, FP8), col < C)
    tl.store(Y + R * C + row, s)


@tr.jit
def _partial_max(X, P, N: tl.constexpr, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    x = tl.load(X + i, i < N, other=0).to(tl.float32)
    tl.store(P + tl.program_id(0), tl.max(tl.abs(x), 0))


@tr.jit
def _finish_scale(P, Y, N: tl.constexpr, K: tl.constexpr,
                  MAX: tl.constexpr, B: tl.constexpr):
    i = tl.arange(0, B)
    a = tl.load(P + i, i < K, other=0)
    tl.store(Y + N, tl.div_rn(tl.max(a, 0), MAX))


@tr.jit
def _tensor_codes(X, S, Y, N: tl.constexpr,
                  STATIC: tl.constexpr, FP8: tl.constexpr, B: tl.constexpr):
    pid = tl.program_id(0)
    i = pid * B + tl.arange(0, B)
    if STATIC:
        s = tl.load(S).to(tl.float32)
        if pid == 0:
            tl.store(Y + N, s)
    else:
        s = tl.load(Y + N)
    v = tl.load(X + i, i < N, other=0).to(tl.float32)
    q = tl.div_rn(v, s)
    tl.store(Y + i, _encode(q, FP8), i < N)


@tr.jit
def _small_tensor(X, Y, N: tl.constexpr, MAX: tl.constexpr,
                  FP8: tl.constexpr, B: tl.constexpr):
    i = tl.arange(0, B)
    v = tl.load(X + i, i < N, other=0).to(tl.float32)
    s = tl.div_rn(tl.max(tl.abs(v), 0), MAX)
    tl.store(Y + i, _encode(tl.div_rn(v, s), FP8), i < N)
    tl.store(Y + N, s)


class ModelNew(nn.Module):
    def __init__(self, mode: str = "dynamic_per_token", quant_dtype: str = "int8"):
        super().__init__()
        assert mode in (
            "static_per_tensor", "dynamic_per_tensor", "dynamic_per_token"
        ), "invalid mode"
        assert quant_dtype in (
            "int8", "float8_e4m3"
        ), "quant_dtype must be int8 or float8_e4m3"
        self.mode = mode
        self.quant_dtype = (
            torch.int8 if quant_dtype == "int8" else torch.float8_e4m3fn
        )

    def forward(self, x, scale=None):
        assert x.dim() == 2, "x must be a 2D tensor"
        assert x.is_contiguous(), "x must be contiguous"
        rows, cols = x.shape
        n = rows * cols
        fp8 = self.quant_dtype != torch.int8
        maximum = 448.0 if fp8 else 127.0
        per_token = self.mode == "dynamic_per_token"
        out = torch.empty(
            (n + (rows if per_token else 1),),
            dtype=torch.float32,
            device=x.device,
        )

        if per_token:
            if cols == 0:
                raise RuntimeError("max(): reduction dimension must have non-zero size")
            if rows:
                block = min(8192, tr.next_power_of_2(cols))
                warps = 4 if block <= 2048 else 8
                _tokens[(rows,)](
                    x, out, rows, cols, maximum, fp8, block,
                    num_warps=warps, enable_fp_fusion=False,
                )
        elif self.mode == "static_per_tensor":
            if scale is None:
                raise ValueError("scale is required for static_per_tensor")
            _tensor_codes[(max(1, tr.cdiv(n, 1024)),)](
                x, scale, out, n, True, fp8, 1024,
                num_warps=4, enable_fp_fusion=False,
            )
        elif n <= 8192:
            if n == 0:
                raise RuntimeError("max(): input must have non-zero size")
            block = tr.next_power_of_2(n)
            _small_tensor[(1,)](
                x, out, n, maximum, fp8, block,
                num_warps=4 if block <= 2048 else 8,
                enable_fp_fusion=False,
            )
        else:
            count = tr.cdiv(n, 4096)
            partial = torch.empty((count,), dtype=torch.float32, device=x.device)
            _partial_max[(count,)](x, partial, n, 4096, num_warps=4)
            while count > 8192:
                next_count = tr.cdiv(count, 4096)
                reduced = torch.empty(
                    (next_count,), dtype=torch.float32, device=x.device
                )
                _partial_max[(next_count,)](
                    partial, reduced, count, 4096, num_warps=4
                )
                partial = reduced
                count = next_count
            _finish_scale[(1,)](
                partial, out, n, count, maximum, tr.next_power_of_2(count),
                num_warps=4,
            )
            _tensor_codes[(tr.cdiv(n, 1024),)](
                x, out, out, n, False, fp8, 1024,
                num_warps=4, enable_fp_fusion=False,
            )
        return out
```