import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _activate(z, Slope, ACT: tl.constexpr):
    if ACT == 0:
        return tl.maximum(z, 0.0)
    elif ACT == 1:
        return z / (1.0 + tl.exp(-z))
    else:
        s = tl.load(Slope).to(tl.float32)
        return tl.where(z > 0.0, z, s * z)


@tr.jit
def _small_conv(
    X, Weight, Bias, Slope, Y,
    C: tl.constexpr, H: tl.constexpr, W: tl.constexpr,
    K: tl.constexpr, R: tl.constexpr, S: tl.constexpr,
    OH: tl.constexpr, OW: tl.constexpr,
    ACT: tl.constexpr, BLOCK: tl.constexpr,
):
    p = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    k = tl.program_id(1)
    b = tl.program_id(2)
    valid = p < OH * OW
    ih = p // OW - 1
    iw = p % OW - 1
    acc = tl.full((BLOCK,), 0.0, tl.float32)
    for c in range(C):
        for r in tl.static_range(R):
            for s in tl.static_range(S):
                h = ih + r
                w = iw + s
                xv = tl.load(
                    X + ((b * C + c) * H + h) * W + w,
                    valid & (h >= 0) & (h < H) & (w >= 0) & (w < W),
                    other=0.0,
                ).to(tl.float32)
                wv = tl.load(
                    Weight + ((k * C + c) * R + r) * S + s
                ).to(tl.float32)
                acc = tl.fma(xv, wv, acc)
    acc += tl.load(Bias + k).to(tl.float32)
    result = _activate(acc, Slope, ACT)
    tl.store(Y + (b * K + k) * OH * OW + p, result, valid)


@tr.jit
def _implicit_conv(
    X, Weight, Bias, Slope, Y,
    C: tl.constexpr, H: tl.constexpr, W: tl.constexpr,
    K: tl.constexpr, R: tl.constexpr, S: tl.constexpr,
    OH: tl.constexpr, OW: tl.constexpr,
    ACT: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    p = tl.program_id(0) * BN + tl.arange(0, BN)
    k = tl.program_id(1) * BM + tl.arange(0, BM)
    batch = tl.program_id(2)
    q = tl.arange(0, BK)
    iy = p // OW - 1
    ix = p % OW - 1

    acc = tl.full((BM, BN), 0.0, tl.float32)
    for base in range(tr.cdiv(C * R * S, BK)):
        reduction = base * BK + q
        ch = reduction // (R * S)
        ry = (reduction // S) % R
        rx = reduction % S
        yy = ry[:, None] + iy[None, :]
        xx = rx[:, None] + ix[None, :]

        a = tl.load(
            Weight + k[:, None] * (C * R * S) + reduction[None, :],
            (k[:, None] < K) & (reduction[None, :] < C * R * S),
            other=0.0,
        ).to(tl.float32)

        v = tl.load(
            X + ((batch * C + ch[:, None]) * H + yy) * W + xx,
            (reduction[:, None] < C * R * S)
            & (p[None, :] < OH * OW)
            & (yy >= 0) & (yy < H)
            & (xx >= 0) & (xx < W),
            other=0.0,
        ).to(tl.float32)

        acc = tl.dot(a, v, acc, input_precision="ieee")

    bias = tl.load(Bias + k, k < K, other=0.0).to(tl.float32)
    acc += bias[:, None]
    result = _activate(acc, Slope, ACT)
    tl.store(
        Y + (batch * K + k[:, None]) * (OH * OW) + p[None, :],
        result,
        (k[:, None] < K) & (p[None, :] < OH * OW),
    )


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)

    def __init__(self, variant: str = "relu"):
        super().__init__()
        assert variant in ("relu", "swish", "prelu"), \
            "variant must be one of relu / swish / prelu"
        self.variant = variant

    def forward(self, x, weight, bias, slope):
        n, c, h, w = x.shape
        k, _, r, s = weight.shape
        oh = h - r + 3
        ow = w - s + 3
        out = torch.empty((n, k, oh, ow), device=x.device, dtype=x.dtype)
        act = {"relu": 0, "swish": 1, "prelu": 2}[self.variant]

        if c * r * s <= 27 or (k <= 4 and c * r * s <= 128):
            block = 128
            _small_conv[(tr.cdiv(oh * ow, block), k, n)](
                x, weight, bias, slope, out,
                c, h, w, k, r, s, oh, ow,
                act, block,
                num_warps=4,
            )
        else:
            bm, bn, bk = 16, 64, 32
            _implicit_conv[(tr.cdiv(oh * ow, bn), tr.cdiv(k, bm), n)](
                x, weight, bias, slope, out,
                c, h, w, k, r, s, oh, ow,
                act, bm, bn, bk,
                num_warps=4,
            )
        return out
