```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _batched_gemm(
    X, W, Bias, Out,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    XB: tl.constexpr, XM: tl.constexpr, XK: tl.constexpr,
    WB: tl.constexpr, WN: tl.constexpr, WK: tl.constexpr,
    BB: tl.constexpr, BN: tl.constexpr,
    USE_BIAS: tl.constexpr,
    BM: tl.constexpr, BN_TILE: tl.constexpr, BK: tl.constexpr,
):
    pm = tl.program_id(0)
    pn = tl.program_id(1)
    batch = tl.program_id(2)

    rows = pm * BM + tl.arange(0, BM)
    cols = pn * BN_TILE + tl.arange(0, BN_TILE)
    ks = tl.arange(0, BK)

    xp = X + batch * XB + rows[:, None] * XM + ks[None, :] * XK
    wp = W + batch * WB + ks[:, None] * WK + cols[None, :] * WN

    acc = tl.full((BM, BN_TILE), 0.0, tl.float32)
    for block in range(tl.cdiv(K, BK)):
        valid_k = block * BK + ks
        a = tl.load(
            xp,
            mask=(rows[:, None] < M) & (valid_k[None, :] < K),
            other=0.0,
        ).to(tl.bfloat16)
        w = tl.load(
            wp,
            mask=(valid_k[:, None] < K) & (cols[None, :] < N),
            other=0.0,
        ).to(tl.bfloat16)
        acc = tl.dot(a, w, acc)
        xp += BK * XK
        wp += BK * WK

    if USE_BIAS:
        bias = tl.load(
            Bias + batch * BB + cols * BN,
            mask=cols < N,
            other=0.0,
        ).to(tl.bfloat16).to(tl.float32)
        acc = (
            acc.to(tl.bfloat16).to(tl.float32) + bias[None, :]
        ).to(tl.bfloat16).to(tl.float32)

    output = acc.to(Out.dtype.element_ty)
    tl.store(
        Out + batch * M * N + rows[:, None] * N + cols[None, :],
        output,
        mask=(rows[:, None] < M) & (cols[None, :] < N),
    )


@triton.jit
def _small_gemm(
    X, W, Bias, Out,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    XB: tl.constexpr, XM: tl.constexpr, XK: tl.constexpr,
    WB: tl.constexpr, WN: tl.constexpr, WK: tl.constexpr,
    BB: tl.constexpr, BN: tl.constexpr,
    USE_BIAS: tl.constexpr,
    RK: tl.constexpr,
    TILE: tl.constexpr,
):
    batch = tl.program_id(1)
    ids = tl.program_id(0) * TILE + tl.arange(0, TILE)
    rows = ids // N
    cols = ids % N
    ks = tl.arange(0, RK)

    a = tl.load(
        X + batch * XB + rows[:, None] * XM + ks[None, :] * XK,
        mask=(ids[:, None] < M * N) & (ks[None, :] < K),
        other=0.0,
    ).to(tl.bfloat16).to(tl.float32)
    w = tl.load(
        W + batch * WB + cols[:, None] * WN + ks[None, :] * WK,
        mask=(ids[:, None] < M * N) & (ks[None, :] < K),
        other=0.0,
    ).to(tl.bfloat16).to(tl.float32)

    acc = tl.sum(a * w, axis=1)
    if USE_BIAS:
        bias = tl.load(
            Bias + batch * BB + cols * BN,
            mask=ids < M * N,
            other=0.0,
        ).to(tl.bfloat16).to(tl.float32)
        acc = (
            acc.to(tl.bfloat16).to(tl.float32) + bias
        ).to(tl.bfloat16).to(tl.float32)

    tl.store(
        Out + batch * M * N + ids,
        acc.to(Out.dtype.element_ty),
        mask=ids < M * N,
    )


class ModelNew(nn.Module):
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)

    def forward(self, x, weight, bias):
        B, M, K = x.shape
        N = weight.shape[1]
        assert K == weight.shape[2], "x and weight must agree on the K dimension"

        out = torch.empty((B, M, N), dtype=self.out_dtype, device=x.device)
        bias_ptr = bias if self.use_bias else x
        bb = bias.stride(0) if self.use_bias else 0
        bn = bias.stride(2) if self.use_bias else 0

        args = (
            x, weight, bias_ptr, out,
            M, N, K,
            x.stride(0), x.stride(1), x.stride(2),
            weight.stride(0), weight.stride(1), weight.stride(2),
            bb, bn, self.use_bias,
        )

        with torch.cuda.device(x.device):
            if M * N <= 64 and K <= 1024:
                _small_gemm[(triton.cdiv(M * N, 4), B)](
                    *args,
                    RK=triton.next_power_of_2(K),
                    TILE=4,
                    num_warps=4,
                )
            else:
                bm = 32 if M < 64 else 64
                nt = 32 if N < 64 else 64
                _batched_gemm[
                    (triton.cdiv(M, bm), triton.cdiv(N, nt), B)
                ](
                    *args,
                    BM=bm,
                    BN_TILE=nt,
                    BK=32,
                    num_warps=4,
                    num_stages=2,
                )
        return out
```