```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _matmul_kernel(
    X, W, Y,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    XM: tl.constexpr, XK: tl.constexpr,
    WN: tl.constexpr, WK: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
    GROUP_M: tl.constexpr,
):
    pid = tl.program_id(0)
    num_m = tl.cdiv(M, BM)
    num_n = tl.cdiv(N, BN)
    group_size = GROUP_M * num_n
    group_id = pid // group_size
    first_m = group_id * GROUP_M
    actual_group_m = tl.minimum(num_m - first_m, GROUP_M)
    local_pid = pid % group_size
    tile_m = first_m + local_pid % actual_group_m
    tile_n = local_pid // actual_group_m

    rows = tile_m * BM + tl.arange(0, BM)
    cols = tile_n * BN + tl.arange(0, BN)
    ks = tl.arange(0, BK)

    xp = X + rows[:, None] * XM + ks[None, :] * XK
    wp = W + cols[None, :] * WN + ks[:, None] * WK
    acc = tl.zeros((BM, BN), tl.float32)

    for block in range(tl.cdiv(K, BK)):
        valid_k = block * BK + ks < K
        a = tl.load(
            xp, mask=(rows[:, None] < M) & valid_k[None, :], other=0
        )
        b = tl.load(
            wp, mask=valid_k[:, None] & (cols[None, :] < N), other=0
        )
        acc = tl.dot(a, b, acc, input_precision="ieee")
        xp += BK * XK
        wp += BK * WK

    tl.store(
        Y + rows[:, None] * N + cols[None, :],
        acc,
        mask=(rows[:, None] < M) & (cols[None, :] < N),
    )


@triton.jit
def _vector_kernel(
    X, W, Y,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    XM: tl.constexpr, XK: tl.constexpr,
    WN: tl.constexpr, WK: tl.constexpr,
    ROW_VECTOR: tl.constexpr,
    BO: tl.constexpr, BK: tl.constexpr,
):
    outputs = tl.program_id(0) * BO + tl.arange(0, BO)
    ks = tl.arange(0, BK)
    accum = tl.zeros((BO, BK), tl.float32)

    for block in range(tl.cdiv(K, BK)):
        k = block * BK + ks
        if ROW_VECTOR:
            a = tl.load(X + k * XK, mask=k < K, other=0).to(tl.float32)
            b = tl.load(
                W + outputs[:, None] * WN + k[None, :] * WK,
                mask=(outputs[:, None] < N) & (k[None, :] < K),
                other=0,
            ).to(tl.float32)
        else:
            a = tl.load(W + k * WK, mask=k < K, other=0).to(tl.float32)
            b = tl.load(
                X + outputs[:, None] * XM + k[None, :] * XK,
                mask=(outputs[:, None] < M) & (k[None, :] < K),
                other=0,
            ).to(tl.float32)
        accum = tl.fma(a[None, :], b, accum)

    result = tl.sum(accum, axis=1)
    if ROW_VECTOR:
        tl.store(Y + outputs, result, mask=outputs < N)
    else:
        tl.store(Y + outputs, result, mask=outputs < M)


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

    def forward(self, x, weight):
        m, k = x.shape
        n, weight_k = weight.shape
        assert k == weight_k, "x and weight must agree on the K dimension"
        out = torch.empty((m, n), device=x.device, dtype=x.dtype)

        if m == 0 or n == 0:
            return out

        if m == 1 or n == 1:
            bo = 4
            bk = min(512, max(32, triton.next_power_of_2(k)))
            _vector_kernel[(triton.cdiv(max(m, n), bo),)](
                x, weight, out,
                m, n, k,
                x.stride(0), x.stride(1),
                weight.stride(0), weight.stride(1),
                m == 1, bo, bk,
                num_warps=4,
            )
        else:
            if x.dtype == torch.float32:
                bm, bn, bk = 32, 32, 32
            else:
                bm = 32 if m < 64 else 64
                bn, bk = 64, 32

            _matmul_kernel[
                (triton.cdiv(m, bm) * triton.cdiv(n, bn),)
            ](
                x, weight, out,
                m, n, k,
                x.stride(0), x.stride(1),
                weight.stride(0), weight.stride(1),
                bm, bn, bk, 8,
                num_warps=4,
                num_stages=2,
            )

        return out
```