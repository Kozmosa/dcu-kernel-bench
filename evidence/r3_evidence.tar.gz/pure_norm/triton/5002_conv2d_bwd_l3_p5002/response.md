```python
import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _input_grad(
    DY, WT, OUT,
    C: tl.constexpr, H: tl.constexpr, W: tl.constexpr,
    O: tl.constexpr, R: tl.constexpr, S: tl.constexpr,
    OH: tl.constexpr, OW: tl.constexpr,
    SH: tl.constexpr, SW: tl.constexpr,
    PH: tl.constexpr, PW: tl.constexpr,
    DH: tl.constexpr, DW: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    ci = tl.program_id(0) * BM + tl.arange(0, BM)
    pos = tl.program_id(1) * BN + tl.arange(0, BN)
    batch = tl.program_id(2)
    ih = pos // W
    iw = pos % W
    kk = tl.arange(0, BK)
    acc = tl.full((BM, BN), 0.0, tl.float32)

    for r in range(R):
        hh = ih + PH - r * DH
        yh = hh // SH
        hvalid = (hh % SH == 0) & (yh >= 0) & (yh < OH)
        for s in range(S):
            ww = iw + PW - s * DW
            yw = ww // SW
            valid = (
                hvalid & (ww % SW == 0) &
                (yw >= 0) & (yw < OW) & (pos < H * W)
            )
            for base in range(tr.cdiv(O, BK)):
                oc = base * BK + kk
                weights = tl.load(
                    WT + ((oc[None, :] * C + ci[:, None]) * R + r) * S + s,
                    (ci[:, None] < C) & (oc[None, :] < O),
                    other=0.0,
                )
                grads = tl.load(
                    DY + ((batch * O + oc[:, None]) * OH + yh[None, :]) * OW
                    + yw[None, :],
                    (oc[:, None] < O) & valid[None, :],
                    other=0.0,
                )
                acc = tl.dot(weights, grads, acc, input_precision="ieee")

    tl.store(
        OUT + (batch * C + ci[:, None]) * H * W + pos[None, :],
        acc,
        (ci[:, None] < C) & (pos[None, :] < H * W),
    )


@tr.jit
def _weight_grad(
    DY, X, PART,
    N: tl.constexpr, C: tl.constexpr,
    H: tl.constexpr, W: tl.constexpr,
    O: tl.constexpr, R: tl.constexpr, S: tl.constexpr,
    OH: tl.constexpr, OW: tl.constexpr,
    SH: tl.constexpr, SW: tl.constexpr,
    PH: tl.constexpr, PW: tl.constexpr,
    DH: tl.constexpr, DW: tl.constexpr,
    CHUNK: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    oc = tl.program_id(0) * BM + tl.arange(0, BM)
    cols = tl.program_id(1) * BN + tl.arange(0, BN)
    split = tl.program_id(2)
    ci = cols // (R * S)
    rr = (cols // S) % R
    ss = cols % S
    kk = tl.arange(0, BK)
    acc = tl.full((BM, BN), 0.0, tl.float32)

    for step in range(tr.cdiv(CHUNK, BK)):
        k = split * CHUNK + step * BK + kk
        batch = k // (OH * OW)
        yh = (k // OW) % OH
        yw = k % OW
        ih = yh[:, None] * SH - PH + rr[None, :] * DH
        iw = yw[:, None] * SW - PW + ss[None, :] * DW

        grads = tl.load(
            DY + (batch[None, :] * O + oc[:, None]) * OH * OW
            + yh[None, :] * OW + yw[None, :],
            (oc[:, None] < O) & (k[None, :] < N * OH * OW),
            other=0.0,
        )
        values = tl.load(
            X + ((batch[:, None] * C + ci[None, :]) * H + ih) * W + iw,
            (k[:, None] < N * OH * OW) &
            (cols[None, :] < C * R * S) &
            (ih >= 0) & (ih < H) & (iw >= 0) & (iw < W),
            other=0.0,
        )
        acc = tl.dot(grads, values, acc, input_precision="ieee")

    tl.store(
        PART + split * O * C * R * S + oc[:, None] * (C * R * S)
        + cols[None, :],
        acc,
        (oc[:, None] < O) & (cols[None, :] < C * R * S),
    )


@tr.jit
def _sum_parts(
    PART, OUT, SIZE: tl.constexpr, SPLITS: tl.constexpr,
    BS: tl.constexpr, BP: tl.constexpr,
):
    index = tl.program_id(0) * BS + tl.arange(0, BS)
    part = tl.arange(0, BP)
    values = tl.load(
        PART + part[:, None] * SIZE + index[None, :],
        (part[:, None] < SPLITS) & (index[None, :] < SIZE),
        other=0.0,
    )
    result = tl.sum(values, axis=0)
    tl.store(OUT + index, result, index < SIZE)


class ModelNew(nn.Module):
    def __init__(
        self, variant: str = "dgrad",
        stride_h: int = 1, stride_w: int = 1,
        pad_h: int = 1, pad_w: int = 1,
        dil_h: int = 1, dil_w: int = 1,
    ):
        super().__init__()
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)

    def forward(self, dy, weight, x):
        n, c, h, w = x.shape
        o, _, r, s = weight.shape
        oh, ow = dy.shape[2:]
        common = dict(
            C=c, H=h, W=w, O=o, R=r, S=s, OH=oh, OW=ow,
            SH=self.stride_h, SW=self.stride_w,
            PH=self.pad_h, PW=self.pad_w,
            DH=self.dil_h, DW=self.dil_w,
        )

        if self.variant == "dgrad":
            out = torch.empty((n, c, h, w), device=x.device, dtype=x.dtype)
            _input_grad[(tr.cdiv(c, 16), tr.cdiv(h * w, 32), n)](
                dy, weight, out, **common,
                BM=16, BN=32, BK=16, num_warps=4,
            )
            return out

        out = torch.empty((o, c, r, s), device=x.device, dtype=x.dtype)
        reduction = n * oh * ow
        chunk = max(256, tr.cdiv(tr.cdiv(reduction, 64), 32) * 32)
        splits = tr.cdiv(reduction, chunk)
        size = o * c * r * s
        if splits == 1:
            partial = out
        else:
            partial = torch.empty((splits, size), device=x.device, dtype=x.dtype)

        _weight_grad[(tr.cdiv(o, 16), tr.cdiv(c * r * s, 32), splits)](
            dy, x, partial, N=n, **common,
            CHUNK=chunk, BM=16, BN=32, BK=32, num_warps=4,
        )
        if splits > 1:
            _sum_parts[(tr.cdiv(size, 128),)](
                partial, out, SIZE=size, SPLITS=splits,
                BS=128, BP=tr.next_power_of_2(splits), num_warps=4,
            )
        return out
```