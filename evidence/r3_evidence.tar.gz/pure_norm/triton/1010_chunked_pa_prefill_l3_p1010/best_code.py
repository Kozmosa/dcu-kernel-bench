import math

import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _attention_parts(
    Q, K, V, KC, VC, BT, START, LENGTH,
    PART, MAXIMUM, DENOM,
    QS: tl.constexpr, KS: tl.constexpr, VS: tl.constexpr,
    KCS: tl.constexpr, VCS: tl.constexpr, BTS: tl.constexpr,
    SS: tl.constexpr, LS: tl.constexpr,
    H: tl.constexpr, D: tl.constexpr, GROUP: tl.constexpr,
    NS: tl.constexpr, BS: tl.constexpr, X: tl.constexpr,
    SCALE: tl.constexpr, SPLITS: tl.constexpr,
    SPAN: tl.constexpr, BD: tl.constexpr, BN: tl.constexpr,
):
    token = tl.program_id(0)
    head = tl.program_id(1)
    split = tl.program_id(2)

    # Upper bound handles sequences with zero query tokens as well.
    lo = 0
    hi = NS
    while lo < hi:
        mid = (lo + hi) // 2
        start_mid = tl.load(START + mid * SS)
        go_right = start_mid <= token
        lo = tl.where(go_right, mid + 1, lo)
        hi = tl.where(go_right, hi, mid)
    seq = lo - 1

    first = tl.load(START + seq * SS)
    last = tl.load(START + (seq + 1) * SS)
    length = tl.load(LENGTH + seq * LS)
    context = length - (last - first)
    end = context + token - first + 1
    kv_head = head // GROUP

    d = tl.arange(0, BD)
    n = tl.arange(0, BN)
    q = tl.load(
        Q + token * QS[0] + head * QS[1] + d * QS[2],
        d < D, other=0,
    ).to(tl.float32) * SCALE

    running_max = tl.full((), -float("inf"), tl.float32)
    running_sum = tl.full((), 0.0, tl.float32)
    acc = tl.full((BD,), 0.0, tl.float32)

    begin = split * SPAN
    stop = tl.minimum(begin + SPAN, end)
    for base in range(begin, stop, BN):
        pos = base + n
        valid = pos < stop
        cached = valid & (pos < context)
        fresh = valid & (pos >= context)

        physical = tl.load(
            BT + seq * BTS[0] + (pos // BS) * BTS[1],
            cached, other=0,
        )
        cache_k = tl.load(
            KC
            + physical[:, None] * KCS[0]
            + kv_head * KCS[1]
            + (d[None, :] // X) * KCS[2]
            + (pos[:, None] % BS) * KCS[3]
            + (d[None, :] % X) * KCS[4],
            cached[:, None] & (d[None, :] < D),
            other=0,
        ).to(tl.float32)
        new_token = first + pos - context
        new_k = tl.load(
            K + new_token[:, None] * KS[0]
            + kv_head * KS[1] + d[None, :] * KS[2],
            fresh[:, None] & (d[None, :] < D),
            other=0,
        ).to(tl.float32)
        kval = tl.where(cached[:, None], cache_k, new_k)
        score = tl.sum(kval * q[None, :], axis=1)
        score = tl.where(valid, score, -float("inf"))

        block_max = tl.max(score, axis=0)
        next_max = tl.maximum(running_max, block_max)
        correction = tl.exp(running_max - next_max)
        p = tl.exp(score - next_max)

        cache_v = tl.load(
            VC
            + physical[:, None] * VCS[0]
            + kv_head * VCS[1]
            + d[None, :] * VCS[2]
            + (pos[:, None] % BS) * VCS[3],
            cached[:, None] & (d[None, :] < D),
            other=0,
        ).to(tl.float32)
        new_v = tl.load(
            V + new_token[:, None] * VS[0]
            + kv_head * VS[1] + d[None, :] * VS[2],
            fresh[:, None] & (d[None, :] < D),
            other=0,
        ).to(tl.float32)
        vval = tl.where(cached[:, None], cache_v, new_v)

        acc = acc * correction + tl.sum(p[:, None] * vval, axis=0)
        running_sum = running_sum * correction + tl.sum(p, axis=0)
        running_max = next_max

    idx = (token * H + head) * SPLITS + split
    tl.store(PART + idx * D + d, acc, d < D)
    tl.store(MAXIMUM + idx, running_max)
    tl.store(DENOM + idx, running_sum)


@tr.jit
def _attention_merge(
    PART, MAXIMUM, DENOM, OUT,
    OS: tl.constexpr, H: tl.constexpr, D: tl.constexpr,
    SPLITS: tl.constexpr, BP: tl.constexpr, BD: tl.constexpr,
):
    token = tl.program_id(0)
    head = tl.program_id(1)
    s = tl.arange(0, BP)
    d = tl.arange(0, BD)
    idx = (token * H + head) * SPLITS + s
    m = tl.load(MAXIMUM + idx, s < SPLITS, other=-float("inf"))
    z = tl.load(DENOM + idx, s < SPLITS, other=0)
    global_max = tl.max(m, axis=0)
    weight = tl.exp(m - global_max)
    denominator = tl.sum(z * weight, axis=0)
    a = tl.load(
        PART + idx[:, None] * D + d[None, :],
        (s[:, None] < SPLITS) & (d[None, :] < D),
        other=0,
    )
    result = tl.sum(a * weight[:, None], axis=0) / denominator
    tl.store(
        OUT + token * OS[0] + head * OS[1] + d * OS[2],
        result, d < D,
    )


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(
        self, query, key, value, key_cache, value_cache,
        block_tables, query_start_loc, seq_lens,
    ):
        tokens, heads, dim = query.shape
        kv_heads = key_cache.shape[1]
        assert heads % kv_heads == 0
        out = torch.empty_like(query)
        if tokens == 0:
            return out

        block_size = value_cache.shape[3]
        capacity = block_tables.shape[1] * block_size
        # More partitions help decode; prefill already supplies abundant work.
        target = 256 if tokens * heads < 512 else 1024
        splits = min(16, max(1, tr.cdiv(capacity, target)))
        span = tr.cdiv(max(1, capacity), splits * 64) * 64

        partial = torch.empty(
            (tokens, heads, splits, dim),
            device=query.device, dtype=torch.float32,
        )
        maxima = torch.empty(
            (tokens, heads, splits), device=query.device, dtype=torch.float32,
        )
        denominators = torch.empty_like(maxima)
        bd = tr.next_power_of_2(dim)

        _attention_parts[(tokens, heads, splits)](
            query, key, value, key_cache, value_cache,
            block_tables, query_start_loc, seq_lens,
            partial, maxima, denominators,
            query.stride(), key.stride(), value.stride(),
            key_cache.stride(), value_cache.stride(), block_tables.stride(),
            query_start_loc.stride(0), seq_lens.stride(0),
            heads, dim, heads // kv_heads, seq_lens.numel(),
            block_size, key_cache.shape[4],
            self.scale, splits, span, bd, 64,
            num_warps=4 if bd <= 128 else 8,
            enable_fp_fusion=False,
        )
        _attention_merge[(tokens, heads)](
            partial, maxima, denominators, out,
            out.stride(), heads, dim, splits,
            tr.next_power_of_2(splits), bd,
            num_warps=4,
        )
        return out
