import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _rearrange(X, Y, N: tl.constexpr, C: tl.constexpr,
               H: tl.constexpr, W: tl.constexpr, BS: tl.constexpr,
               CRD: tl.constexpr, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    ow = W * BS
    oh = H * BS
    d = i % ow
    r = (i // ow) % oh
    c = (i // (ow * oh)) % C
    n = i // (C * ow * oh)
    sub = (r % BS) * BS + d % BS
    if CRD:
        k = c * BS * BS + sub
    else:
        k = sub * C + c
    src = ((n * (C * BS * BS) + k) * H + r // BS) * W + d // BS
    v = tl.load(X + src, i < N * C * oh * ow, other=0)
    tl.store(Y + i, v, i < N * C * oh * ow)


@tr.jit
def _small_conv(X, F, Bias, Y,
                CI: tl.constexpr, K: tl.constexpr,
                H: tl.constexpr, W: tl.constexpr,
                BS: tl.constexpr, CRD: tl.constexpr,
                B: tl.constexpr):
    p = tl.program_id(0) * B + tl.arange(0, B)
    k = tl.program_id(1)
    n = tl.program_id(2)
    h = p // W
    w = p % W
    acc = tl.full((B,), 0, tl.float32)
    for ci in range(CI):
        for rh in tl.static_range(3):
            for rw in tl.static_range(3):
                ih = h + rh - 1
                iw = w + rw - 1
                v = tl.load(
                    X + ((n * CI + ci) * H + ih) * W + iw,
                    (p < H * W) & (ih >= 0) & (ih < H) &
                    (iw >= 0) & (iw < W), other=0
                ).to(tl.float32)
                f = tl.load(F + ((k * CI + ci) * 3 + rh) * 3 + rw).to(tl.float32)
                acc = tl.fma(v, f, acc)
    acc += tl.load(Bias + k).to(tl.float32)
    C: tl.constexpr = K // (BS * BS)
    if CRD:
        c = k // (BS * BS)
        sub = k % (BS * BS)
    else:
        c = k % C
        sub = k // C
    dst = ((n * C + c) * (H * BS) + h * BS + sub // BS) * (W * BS)
    dst += w * BS + sub % BS
    tl.store(Y + dst, acc, p < H * W)


@tr.jit
def _conv(X, F, Bias, Y,
          CI: tl.constexpr, K: tl.constexpr,
          H: tl.constexpr, W: tl.constexpr,
          BS: tl.constexpr, CRD: tl.constexpr,
          BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    p = tl.program_id(0) * BM + tl.arange(0, BM)
    k = tl.program_id(1) * BN + tl.arange(0, BN)
    n = tl.program_id(2)
    h = p // W
    w = p % W
    rr = tl.arange(0, BK)
    acc = tl.full((BM, BN), 0, tl.float32)

    for start in range(tr.cdiv(CI * 9, BK)):
        q = start * BK + rr
        ci = q // 9
        rh = (q % 9) // 3
        rw = q % 3
        ih = h[:, None] + rh[None, :] - 1
        iw = w[:, None] + rw[None, :] - 1
        xp = ((n * CI + ci[None, :]) * H + ih) * W + iw
        a = tl.load(
            X + xp,
            (p[:, None] < H * W) & (q[None, :] < CI * 9) &
            (ih >= 0) & (ih < H) & (iw >= 0) & (iw < W),
            other=0
        ).to(tl.float32)
        b = tl.load(
            F + k[None, :] * (CI * 9) + q[:, None],
            (k[None, :] < K) & (q[:, None] < CI * 9),
            other=0
        ).to(tl.float32)
        acc = tl.dot(a, b, acc, input_precision="ieee")

    acc += tl.load(Bias + k, k < K, other=0).to(tl.float32)[None, :]
    C: tl.constexpr = K // (BS * BS)
    if CRD:
        c = k // (BS * BS)
        sub = k % (BS * BS)
    else:
        c = k % C
        sub = k // C
    dst = (
        (n * C + c[None, :]) * (H * BS)
        + h[:, None] * BS + sub[None, :] // BS
    ) * (W * BS) + w[:, None] * BS + sub[None, :] % BS
    tl.store(Y + dst, acc, (p[:, None] < H * W) & (k[None, :] < K))


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)

    def __init__(self, variant: str = "conv_bias_dts", mode: str = "CRD", block_size: int = 2):
        super().__init__()
        assert variant in ("conv_bias_dts", "dts"), \
            "variant must be either conv_bias_dts or dts"
        assert mode in ("CRD", "DCR"), "mode must be either CRD or DCR"
        assert block_size in (2, 3, 4), "block_size must be 2 / 3 / 4"
        self.variant = variant
        self.mode = mode
        self.block_size = block_size

    def forward(self, x, weight=None, bias=None):
        n, ci, h, w = x.shape
        bs = self.block_size
        crd = self.mode == "CRD"
        k = ci if self.variant == "dts" else weight.shape[0]
        c = k // (bs * bs)
        out = torch.empty((n, c, h * bs, w * bs), device=x.device, dtype=x.dtype)
        with torch.cuda.device(x.device):
            if self.variant == "dts":
                _rearrange[(tr.cdiv(n * k * h * w, 256),)](
                    x, out, n, c, h, w, bs, crd, 256,
                    num_warps=4,
                )
            elif ci <= 4:
                _small_conv[(tr.cdiv(h * w, 128), k, n)](
                    x, weight, bias, out, ci, k, h, w, bs, crd, 128,
                    num_warps=4,
                )
            else:
                _conv[(tr.cdiv(h * w, 32), tr.cdiv(k, 32), n)](
                    x, weight, bias, out, ci, k, h, w, bs, crd,
                    32, 32, 16, num_warps=4,
                )
        return out
