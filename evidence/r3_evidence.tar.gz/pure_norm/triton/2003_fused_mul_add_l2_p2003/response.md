```python
import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _multiply_add(
    X, A, B, Y,
    N: tl.constexpr,
    A_KIND: tl.constexpr,
    B_KIND: tl.constexpr,
    BLOCK: tl.constexpr,
):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = offsets < N
    x = tl.load(X + offsets, valid, other=0).to(tl.float32)

    if A_KIND == 0:
        a = tl.full((), A, tl.float32)
    elif A_KIND == 1:
        a = tl.load(A).to(tl.float32)
    else:
        a = tl.load(A + offsets, valid, other=0).to(tl.float32)

    if B_KIND == 0:
        b = tl.full((), B, tl.float32)
    elif B_KIND == 1:
        b = tl.load(B).to(tl.float32)
    else:
        b = tl.load(B + offsets, valid, other=0).to(tl.float32)

    product = x * a
    result = product + b
    tl.store(Y + offsets, result, valid)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x, a, b):
        n = x.numel()
        out = torch.empty_like(x)
        if n == 0:
            return out

        if isinstance(a, torch.Tensor):
            a_kind = 1 if a.numel() == 1 else 2
        else:
            a_kind = 0
            a = float(a)

        if isinstance(b, torch.Tensor):
            b_kind = 1 if b.numel() == 1 else 2
        else:
            b_kind = 0
            b = float(b)

        block = 1024
        _multiply_add[(triton.cdiv(n, block),)](
            x, a, b, out,
            N=n,
            A_KIND=a_kind,
            B_KIND=b_kind,
            BLOCK=block,
            num_warps=4,
            enable_fp_fusion=False,
        )
        return out
```