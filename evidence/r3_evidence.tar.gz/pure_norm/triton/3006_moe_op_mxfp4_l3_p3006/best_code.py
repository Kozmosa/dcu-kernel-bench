import torch
import torch.nn as nn
import triton as tr
import triton.language as tl


@tr.jit
def _decode_e2m1(n):
    magnitude = n & 7
    value = tl.where(
        magnitude < 4,
        magnitude.to(tl.float32) * 0.5,
        tl.where(
            magnitude < 6,
            magnitude.to(tl.float32) - 2.0,
            2.0 * magnitude.to(tl.float32) - 8.0,
        ),
    )
    return tl.where((n & 8) != 0, -value, value)


@tr.jit
def _moe_kernel(
    AQ, AS, BQ, BS, RW, IDS, OUT,
    N: tl.constexpr, K: tl.constexpr, TOPK: tl.constexpr,
    AQ0: tl.constexpr, AQ1: tl.constexpr,
    AS0: tl.constexpr, AS1: tl.constexpr,
    BQ0: tl.constexpr, BQ1: tl.constexpr, BQ2: tl.constexpr,
    BS0: tl.constexpr, BS1: tl.constexpr, BS2: tl.constexpr,
    RW0: tl.constexpr, RW1: tl.constexpr,
    ID0: tl.constexpr, ID1: tl.constexpr,
    BN: tl.constexpr, BK: tl.constexpr,
):
    slot = tl.program_id(0)
    token = slot // TOPK
    route = slot % TOPK
    expert = tl.load(IDS + token * ID0 + route * ID1)
    weight = tl.load(RW + token * RW0 + route * RW1).to(tl.float32)

    ns = tl.program_id(1) * BN + tl.arange(0, BN)
    ks = tl.arange(0, BK)
    accumulator = tl.full((BN, BK), 0.0, tl.float32)

    for base in range(tr.cdiv(K, BK)):
        k = base * BK + ks
        valid_k = k < K
        a_byte = tl.load(
            AQ + token * AQ0 + (k // 2) * AQ1,
            mask=valid_k, other=0,
        ).to(tl.int32)
        a_nibble = (a_byte >> ((k & 1) * 4)) & 15
        a_scale = tl.load(
            AS + token * AS0 + (k // 32) * AS1,
            mask=valid_k, other=127,
        ).to(tl.int32)
        a = _decode_e2m1(a_nibble) * tl.exp2(
            (a_scale - 127).to(tl.float32)
        )

        b_byte = tl.load(
            BQ + expert * BQ0 + ns[:, None] * BQ1
            + (k[None, :] // 2) * BQ2,
            mask=(ns[:, None] < N) & valid_k[None, :],
            other=0,
        ).to(tl.int32)
        b_nibble = (b_byte >> ((k[None, :] & 1) * 4)) & 15
        b_scale = tl.load(
            BS + expert * BS0 + ns[:, None] * BS1
            + (k[None, :] // 32) * BS2,
            mask=(ns[:, None] < N) & valid_k[None, :],
            other=127,
        ).to(tl.int32)
        b = _decode_e2m1(b_nibble) * tl.exp2(
            (b_scale - 127).to(tl.float32)
        )
        accumulator += a[None, :] * b

    result = tl.sum(accumulator, axis=1) * weight
    tl.store(OUT + slot * N + ns, result, mask=ns < N)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, a_q, a_scales, b_q, b_scales, topk_weights, topk_ids):
        a_q = a_q.to(torch.uint8)
        a_scales = a_scales.to(torch.uint8)
        b_q = b_q.to(torch.uint8)
        b_scales = b_scales.to(torch.uint8)
        topk_ids = topk_ids.to(torch.long)
        topk_weights = topk_weights.to(torch.float32)

        m, kh = a_q.shape
        k = kh * 2
        n = b_q.shape[1]
        top_k = topk_ids.shape[1]
        output = torch.empty(
            (m, top_k, n), device=a_q.device, dtype=torch.bfloat16
        )
        if m == 0 or n == 0:
            return output

        bk = min(tr.next_power_of_2(k), 2048)
        bn = 4
        _moe_kernel[(m * top_k, tr.cdiv(n, bn))](
            a_q, a_scales, b_q, b_scales, topk_weights, topk_ids, output,
            n, k, top_k,
            *a_q.stride(),
            *a_scales.stride(),
            *b_q.stride(),
            *b_scales.stride(),
            *topk_weights.stride(),
            *topk_ids.stride(),
            BN=bn,
            BK=bk,
            num_warps=4,
            enable_fp_fusion=False,
        )
        return output
