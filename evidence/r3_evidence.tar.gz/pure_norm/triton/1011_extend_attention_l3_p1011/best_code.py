import math

import torch
import torch.nn as nn
import triton
import triton.language as tl


@triton.jit
def _attention_kernel(
    Q, KE, VE, KB, VB, QPTR, KPTR, INDICES, OUT,
    HQ: tl.constexpr,
    HK: tl.constexpr,
    DQ: tl.constexpr,
    DV: tl.constexpr,
    GROUP: tl.constexpr,
    NSEQS: tl.constexpr,
    SCALE: tl.constexpr,
    CAUSAL: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BQ: tl.constexpr,
    BV: tl.constexpr,
):
    task = tl.program_id(0)
    head = tl.program_id(1)

    # Sequence i owns tasks [floor(qptr[i]/BM)+i,
    #                         floor(qptr[i+1]/BM)+i+1).
    # This gives a compact grid without reading metadata back to the CPU.
    lo = 0
    hi = NSEQS
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        start = tl.load(QPTR + mid).to(tl.int32)
        boundary = start // BM + mid
        take_right = boundary <= task
        lo = tl.where(take_right, mid, lo)
        hi = tl.where(take_right, hi, mid)

    seq = lo
    qs = tl.load(QPTR + seq).to(tl.int32)
    qe = tl.load(QPTR + seq + 1).to(tl.int32)
    local_block = task - (qs // BM + seq)
    first = local_block * BM
    length = qe - qs

    if first < length:
        ps = tl.load(KPTR + seq).to(tl.int32)
        pe = tl.load(KPTR + seq + 1).to(tl.int32)
        prefix = pe - ps
        kv_head = head // GROUP

        rows = first + tl.arange(0, BM)
        channels_q = tl.arange(0, BQ)
        channels_v = tl.arange(0, BV)
        columns = tl.arange(0, BN)
        row_valid = rows < length

        q = tl.load(
            Q + (qs + rows[:, None]).to(tl.int64) * (HQ * DQ)
            + head * DQ + channels_q[None, :],
            mask=row_valid[:, None] & (channels_q[None, :] < DQ),
            other=0,
        ).to(tl.float32)

        maximum = tl.full((BM,), -float("inf"), tl.float32)
        denominator = tl.zeros((BM,), tl.float32)
        accumulator = tl.zeros((BM, BV), tl.float32)

        limit = prefix + length
        if CAUSAL:
            limit = prefix + tl.minimum(first + BM, length)

        for offset in range(0, limit, BN):
            positions = offset + columns
            is_prefix = positions < prefix
            is_extend = (positions >= prefix) & (positions < prefix + length)

            pool_rows = tl.load(
                INDICES + ps + positions,
                mask=is_prefix & (positions < limit),
                other=0,
            ).to(tl.int64)
            extend_rows = (qs + positions - prefix).to(tl.int64)

            kp = tl.load(
                KB + pool_rows[None, :] * (HK * DQ)
                + kv_head * DQ + channels_q[:, None],
                mask=(channels_q[:, None] < DQ)
                & is_prefix[None, :]
                & (positions[None, :] < limit),
                other=0,
            ).to(tl.float32)
            ke = tl.load(
                KE + extend_rows[None, :] * (HK * DQ)
                + kv_head * DQ + channels_q[:, None],
                mask=(channels_q[:, None] < DQ)
                & is_extend[None, :]
                & (positions[None, :] < limit),
                other=0,
            ).to(tl.float32)
            k = tl.where(is_prefix[None, :], kp, ke)

            scores = tl.dot(q, k, input_precision="ieee") * SCALE
            visible = row_valid[:, None] & (positions[None, :] < limit)
            if CAUSAL:
                visible = visible & (
                    positions[None, :] <= prefix + rows[:, None]
                )
            scores = tl.where(visible, scores, -float("inf"))

            new_maximum = tl.maximum(maximum, tl.max(scores, axis=1))
            new_maximum = tl.where(row_valid, new_maximum, 0.0)
            correction = tl.exp(maximum - new_maximum)
            probabilities = tl.exp(scores - new_maximum[:, None])

            vp = tl.load(
                VB + pool_rows[:, None] * (HK * DV)
                + kv_head * DV + channels_v[None, :],
                mask=is_prefix[:, None]
                & (positions[:, None] < limit)
                & (channels_v[None, :] < DV),
                other=0,
            ).to(tl.float32)
            ve = tl.load(
                VE + extend_rows[:, None] * (HK * DV)
                + kv_head * DV + channels_v[None, :],
                mask=is_extend[:, None]
                & (positions[:, None] < limit)
                & (channels_v[None, :] < DV),
                other=0,
            ).to(tl.float32)
            v = tl.where(is_prefix[:, None], vp, ve)

            accumulator = accumulator * correction[:, None]
            accumulator = tl.dot(
                probabilities, v, accumulator, input_precision="ieee"
            )
            denominator = denominator * correction + tl.sum(
                probabilities, axis=1
            )
            maximum = new_maximum

        result = accumulator / tl.where(
            row_valid, denominator, 1.0
        )[:, None]
        tl.store(
            OUT + (qs + rows[:, None]).to(tl.int64) * (HQ * DV)
            + head * DV + channels_v[None, :],
            result,
            mask=row_valid[:, None] & (channels_v[None, :] < DV),
        )


class ModelNew(nn.Module):
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)

    def forward(
        self,
        q_extend,
        k_extend,
        v_extend,
        k_buffer,
        v_buffer,
        qo_indptr,
        kv_indptr,
        kv_indices,
    ):
        total_extend, num_q_heads, head_dim_q = q_extend.shape
        num_kv_heads = k_extend.shape[1]
        head_dim_v = v_extend.shape[2]
        num_seqs = qo_indptr.numel() - 1
        assert num_q_heads % num_kv_heads == 0

        out = torch.empty(
            (total_extend, num_q_heads, head_dim_v),
            device=q_extend.device,
            dtype=q_extend.dtype,
        )
        if total_extend == 0:
            return out

        scale = (
            self.sm_scale
            if self.sm_scale is not None
            else 1.0 / math.sqrt(head_dim_q)
        )
        block_m = 16
        _attention_kernel[
            (total_extend // block_m + num_seqs, num_q_heads)
        ](
            q_extend, k_extend, v_extend, k_buffer, v_buffer,
            qo_indptr, kv_indptr, kv_indices, out,
            HQ=num_q_heads,
            HK=num_kv_heads,
            DQ=head_dim_q,
            DV=head_dim_v,
            GROUP=num_q_heads // num_kv_heads,
            NSEQS=num_seqs,
            SCALE=scale,
            CAUSAL=self.causal,
            BM=block_m,
            BN=32,
            BQ=max(16, triton.next_power_of_2(head_dim_q)),
            BV=max(16, triton.next_power_of_2(head_dim_v)),
            num_warps=4,
            num_stages=1,
        )
        return out
