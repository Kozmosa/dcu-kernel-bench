import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_decode(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor pages, torch::Tensor lengths,
    int64_t splits, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_decode", &paged_decode);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <stdint.h>
#include <cmath>

struct Args {
    const float *q, *k, *v;
    const void *pages, *lengths;
    int64_t qs0, qs1, qs2;
    int64_t ks0, ks1, ks2, ks3;
    int64_t vs0, vs1, vs2, vs3;
    int64_t ps0, ps1, ls0;
    int H, HK, D, V, P, S;
    bool pages64, lengths64;
    float scale;
};

__device__ __forceinline__ int64_t index_read(
    const void* ptr, int64_t i, bool wide) {
    return wide ? static_cast<const int64_t*>(ptr)[i]
                : static_cast<const int32_t*>(ptr)[i];
}

// Each block handles a sequence, a query head, and a disjoint KV slice.
// Four wavefronts compute a tile of 64 logits. The same block then
// accumulates the value channels using an online stable softmax.
__global__ void decode_slices(Args a, float* partial, float* stats) {
    const int tid = threadIdx.x;
    const int lane = tid & 63;
    const int wave = tid >> 6;
    const int h = blockIdx.x;
    const int b = blockIdx.y;
    const int split = blockIdx.z;
    const int kh = h / (a.H / a.HK);
    const int64_t length = index_read(a.lengths, b * a.ls0, a.lengths64);
    const int64_t span = (length + a.S - 1) / a.S;
    const int64_t begin = span * split;
    const int64_t end = min(begin + span, length);
    const int64_t part = ((int64_t)b * a.H + h) * a.S + split;

    extern __shared__ float smem[];
    float* query = smem;
    float* accum = query + a.D;
    float* weights = accum + a.V;
    float* state = weights + 64;
    __shared__ int64_t slots[64];

    for (int d = tid; d < a.D; d += 256)
        query[d] = a.q[b * a.qs0 + h * a.qs1 + d * a.qs2] * a.scale;
    for (int d = tid; d < a.V; d += 256)
        accum[d] = 0.0f;
    if (tid == 0) {
        state[0] = -INFINITY; // Running maximum.
        state[1] = 0.0f;     // Running exponential sum.
        state[2] = 0.0f;     // Rescaling factor for previous values.
    }
    __syncthreads();

    for (int64_t base = begin; base < end; base += 64) {
        if (tid < 64) {
            const int64_t token = base + tid;
            if (token < end) {
                const int64_t page = index_read(
                    a.pages, b * a.ps0 + (token / a.P) * a.ps1,
                    a.pages64);
                slots[tid] = page * a.P + token % a.P;
            } else {
                slots[tid] = 0;
            }
        }
        __syncthreads();

        for (int t = wave; t < 64; t += 4) {
            float dot = 0.0f;
            if (base + t < end) {
                const int64_t slot = slots[t];
                const float* key = a.k + (slot / a.P) * a.ks0
                    + (slot % a.P) * a.ks1 + kh * a.ks2;
                for (int d = lane; d < a.D; d += 64)
                    dot = fmaf(query[d], key[d * a.ks3], dot);
            }
            #pragma unroll
            for (int delta = 32; delta; delta >>= 1)
                dot += __shfl_down(dot, delta, 64);
            if (lane == 0)
                weights[t] = base + t < end ? dot : -INFINITY;
        }
        __syncthreads();

        if (tid == 0) {
            float tile_max = -INFINITY;
            const int count = (int)min((int64_t)64, end - base);
            for (int t = 0; t < count; ++t)
                tile_max = fmaxf(tile_max, weights[t]);
            const float next_max = fmaxf(state[0], tile_max);
            const float alpha = expf(state[0] - next_max);
            float sum = 0.0f;
            for (int t = 0; t < count; ++t) {
                const float w = expf(weights[t] - next_max);
                weights[t] = w;
                sum += w;
            }
            state[0] = next_max;
            state[1] = state[1] * alpha + sum;
            state[2] = alpha;
        }
        __syncthreads();

        const int count = (int)min((int64_t)64, end - base);
        for (int d = tid; d < a.V; d += 256) {
            float sum = accum[d] * state[2];
            for (int t = 0; t < count; ++t) {
                const int64_t slot = slots[t];
                const int64_t offset = (slot / a.P) * a.vs0
                    + (slot % a.P) * a.vs1 + kh * a.vs2
                    + d * a.vs3;
                sum = fmaf(weights[t], a.v[offset], sum);
            }
            accum[d] = sum;
        }
        __syncthreads();
    }

    for (int d = tid; d < a.V; d += 256)
        partial[part * a.V + d] = accum[d];
    if (tid == 0) {
        stats[part * 2] = state[0];
        stats[part * 2 + 1] = state[1];
    }
}

__global__ void merge_slices(
    const float* partial, const float* stats, float* output,
    int H, int V, int S) {
    const int64_t head = blockIdx.x;
    extern __shared__ float factors[];
    __shared__ float denominator;

    if (threadIdx.x == 0) {
        float maximum = -INFINITY;
        for (int s = 0; s < S; ++s)
            maximum = fmaxf(maximum, stats[(head * S + s) * 2]);
        float sum = 0.0f;
        for (int s = 0; s < S; ++s) {
            const int64_t i = (head * S + s) * 2;
            const float f = stats[i + 1] > 0.0f
                ? expf(stats[i] - maximum) : 0.0f;
            factors[s] = f;
            sum = fmaf(f, stats[i + 1], sum);
        }
        denominator = sum;
    }
    __syncthreads();

    for (int d = threadIdx.x; d < V; d += blockDim.x) {
        float sum = 0.0f;
        for (int s = 0; s < S; ++s)
            sum = fmaf(factors[s], partial[(head * S + s) * V + d], sum);
        output[head * V + d] = sum / denominator;
    }
}

torch::Tensor paged_decode(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor pages, torch::Tensor lengths,
    int64_t requested_splits, double scale) {
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda()
                && pages.is_cuda() && lengths.is_cuda(), "Inputs must be on GPU");
    TORCH_CHECK(q.scalar_type() == at::kFloat
                && k.scalar_type() == at::kFloat
                && v.scalar_type() == at::kFloat, "Expected fp32 inputs");
    TORCH_CHECK(pages.scalar_type() == at::kInt || pages.scalar_type() == at::kLong,
                "Expected int32 or int64 page tables");
    TORCH_CHECK(lengths.scalar_type() == at::kInt || lengths.scalar_type() == at::kLong,
                "Expected int32 or int64 sequence lengths");
    TORCH_CHECK(q.dim() == 3 && k.dim() == 4 && v.dim() == 4
                && pages.dim() == 2 && lengths.dim() == 1, "Invalid input ranks");
    TORCH_CHECK(k.size(2) > 0 && q.size(1) % k.size(2) == 0,
                "Invalid query head grouping");
    TORCH_CHECK(k.size(3) == q.size(2) && k.size(1) > 0,
                "Invalid key cache shape");

    const c10::cuda::CUDAGuard guard(q.device());
    const int B = q.size(0), H = q.size(1), V = v.size(3);
    const int64_t capacity = pages.size(1) * k.size(1);
    const int S = (int)std::max<int64_t>(
        1, std::min<int64_t>(std::max<int64_t>(1, requested_splits),
                            std::max<int64_t>(1, (capacity + 63) / 64)));
    auto output = torch::empty({B, H, V}, q.options());
    if (B == 0 || H == 0 || V == 0) return output;
    auto partial = torch::empty({B, H, S, V}, q.options());
    auto stats = torch::empty({B, H, S, 2}, q.options());

    Args a{};
    a.q = q.data_ptr<float>();
    a.k = k.data_ptr<float>();
    a.v = v.data_ptr<float>();
    a.pages = pages.data_ptr();
    a.lengths = lengths.data_ptr();
    a.qs0=q.stride(0); a.qs1=q.stride(1); a.qs2=q.stride(2);
    a.ks0=k.stride(0); a.ks1=k.stride(1);
    a.ks2=k.stride(2); a.ks3=k.stride(3);
    a.vs0=v.stride(0); a.vs1=v.stride(1);
    a.vs2=v.stride(2); a.vs3=v.stride(3);
    a.ps0=pages.stride(0); a.ps1=pages.stride(1);
    a.ls0=lengths.stride(0);
    a.H=H; a.HK=k.size(2); a.D=q.size(2);
    a.V=V; a.P=k.size(1); a.S=S;
    a.pages64=pages.scalar_type()==at::kLong;
    a.lengths64=lengths.scalar_type()==at::kLong;
    a.scale=(float)scale;

    auto stream = at::cuda::getCurrentCUDAStream();
    const size_t shared_bytes = (a.D + a.V + 67) * sizeof(float);
    decode_slices<<<dim3(H, B, S), 256, shared_bytes, stream>>>(
        a, partial.data_ptr<float>(), stats.data_ptr<float>());
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    merge_slices<<<B * H, 256, S * sizeof(float), stream>>>(
        partial.data_ptr<float>(), stats.data_ptr<float>(),
        output.data_ptr<float>(), H, V, S);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="paged_decode_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, page_size: int, head_dim_qk: int, head_dim_v: int,
                 num_kv_splits: int = 8, scale=None):
        super().__init__()
        self.page_size = int(page_size)
        self.head_dim_qk = int(head_dim_qk)
        self.head_dim_v = int(head_dim_v)
        self.num_kv_splits = int(num_kv_splits)
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim_qk)

    def forward(self, q, key_cache, value_cache, page_tables, seq_lens):
        assert key_cache.shape[1] == self.page_size
        return _get_extension().paged_decode(
            q, key_cache, value_cache, page_tables, seq_lens,
            self.num_kv_splits, self.scale,
        )
