```python
import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>

torch::Tensor paged_attention(
    torch::Tensor query, torch::Tensor key, torch::Tensor value,
    torch::Tensor key_cache, torch::Tensor value_cache,
    torch::Tensor block_tables, torch::Tensor query_start_loc,
    torch::Tensor seq_lens, c10::optional<torch::Tensor> slopes,
    double scale);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention", &paged_attention);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

struct FloatView {
    const float* p;
    int64_t s[5];
};

struct IndexView {
    const void* p;
    int64_t s0, s1;
    bool wide;
};

static FloatView float_view(const torch::Tensor& t) {
    FloatView v{};
    v.p = t.data_ptr<float>();
    for (int i = 0; i < t.dim(); ++i) v.s[i] = t.stride(i);
    return v;
}

static IndexView index_view(const torch::Tensor& t) {
    TORCH_CHECK(t.scalar_type() == at::kInt ||
                t.scalar_type() == at::kLong, "Indices must be int32 or int64");
    return {t.data_ptr(), t.stride(0),
            t.dim() > 1 ? t.stride(1) : 0,
            t.scalar_type() == at::kLong};
}

__device__ __forceinline__ int index_at(IndexView a, int i, int j = 0) {
    int64_t off = int64_t(i) * a.s0 + int64_t(j) * a.s1;
    return a.wide ? int(static_cast<const int64_t*>(a.p)[off])
                  : static_cast<const int32_t*>(a.p)[off];
}

__global__ __launch_bounds__(256)
void attention_kernel(
    FloatView q, FloatView k, FloatView v,
    FloatView kc, FloatView vc, IndexView tables,
    IndexView starts, IndexView lengths,
    const float* slopes, int64_t slope_stride,
    float* output, int heads, int kv_heads, int dim,
    int block_size, int pack, int sequences, float scale)
{
    const int token = blockIdx.x;
    const int head = blockIdx.y;
    const int tid = threadIdx.x;
    const int lane = tid & 3;
    const int row = tid >> 2;
    const int kv_head = head / (heads / kv_heads);

    __shared__ int seq, first, context, position;
    __shared__ float weights[64];
    __shared__ float running_max, denominator, alpha;
    extern __shared__ float storage[];
    float* query = storage;
    float* accum = storage + dim;

    if (tid == 0) {
        int lo = 0, hi = sequences;
        while (lo < hi) {
            int mid = (lo + hi) >> 1;
            if (index_at(starts, mid + 1) <= token) lo = mid + 1;
            else hi = mid;
        }
        seq = lo;
        first = index_at(starts, lo);
        context = index_at(lengths, lo) -
                  (index_at(starts, lo + 1) - first);
        position = context + token - first;
        running_max = -INFINITY;
        denominator = 0.0f;
    }
    for (int d = tid; d < dim; d += 256) {
        query[d] = q.p[int64_t(token) * q.s[0] +
                       int64_t(head) * q.s[1] +
                       int64_t(d) * q.s[2]] * scale;
        accum[d] = 0.0f;
    }
    __syncthreads();

    const float slope = slopes ? slopes[int64_t(head) * slope_stride] : 0.0f;

    for (int base = 0; base <= position; base += 64) {
        const int logical = base + row;
        const bool valid = logical <= position;
        const bool prefix = logical < context;
        int physical = 0;
        int slot = 0;
        int new_token = 0;
        if (valid) {
            if (prefix) {
                physical = index_at(tables, seq, logical / block_size);
                slot = logical % block_size;
            } else {
                new_token = first + logical - context;
            }
        }

        float dot = 0.0f;
        if (valid) {
            for (int d = lane; d < dim; d += 4) {
                float kval;
                if (prefix) {
                    kval = kc.p[int64_t(physical) * kc.s[0] +
                                int64_t(kv_head) * kc.s[1] +
                                int64_t(d / pack) * kc.s[2] +
                                int64_t(slot) * kc.s[3] +
                                int64_t(d % pack) * kc.s[4]];
                } else {
                    kval = k.p[int64_t(new_token) * k.s[0] +
                               int64_t(kv_head) * k.s[1] +
                               int64_t(d) * k.s[2]];
                }
                dot = fmaf(query[d], kval, dot);
            }
        }
        dot += __shfl_down(dot, 2, 4);
        dot += __shfl_down(dot, 1, 4);
        if (lane == 0) {
            weights[row] = valid
                ? dot + slope * float(logical - position)
                : -INFINITY;
        }
        __syncthreads();

        if (tid == 0) {
            float maximum = running_max;
            const int count = min(64, position - base + 1);
            for (int i = 0; i < count; ++i)
                maximum = fmaxf(maximum, weights[i]);
            alpha = expf(running_max - maximum);
            running_max = maximum;
        }
        __syncthreads();

        if (tid < 64)
            weights[tid] = expf(weights[tid] - running_max);
        __syncthreads();

        if (tid == 0) {
            float sum = 0.0f;
            for (int i = 0; i < 64; ++i) sum += weights[i];
            denominator = denominator * alpha + sum;
        }

        const int count = min(64, position - base + 1);
        for (int d = tid; d < dim; d += 256) {
            float result = accum[d] * alpha;
            for (int i = 0; i < count; ++i) {
                const int l = base + i;
                float val;
                if (l < context) {
                    const int block = index_at(tables, seq, l / block_size);
                    val = vc.p[int64_t(block) * vc.s[0] +
                               int64_t(kv_head) * vc.s[1] +
                               int64_t(d) * vc.s[2] +
                               int64_t(l % block_size) * vc.s[3]];
                } else {
                    val = v.p[int64_t(first + l - context) * v.s[0] +
                              int64_t(kv_head) * v.s[1] +
                              int64_t(d) * v.s[2]];
                }
                result = fmaf(weights[i], val, result);
            }
            accum[d] = result;
        }
        __syncthreads();
    }

    for (int d = tid; d < dim; d += 256)
        output[(int64_t(token) * heads + head) * dim + d] =
            accum[d] / denominator;
}

torch::Tensor paged_attention(
    torch::Tensor query, torch::Tensor key, torch::Tensor value,
    torch::Tensor key_cache, torch::Tensor value_cache,
    torch::Tensor block_tables, torch::Tensor query_start_loc,
    torch::Tensor seq_lens, c10::optional<torch::Tensor> slopes,
    double scale)
{
    c10::cuda::CUDAGuard guard(query.device());
    TORCH_CHECK(query.is_cuda(), "Expected accelerator tensors");
    TORCH_CHECK(query.scalar_type() == at::kFloat &&
                key.scalar_type() == at::kFloat &&
                value.scalar_type() == at::kFloat &&
                key_cache.scalar_type() == at::kFloat &&
                value_cache.scalar_type() == at::kFloat,
                "Expected float32 inputs");
    const int tokens = query.size(0);
    const int heads = query.size(1);
    const int dim = query.size(2);
    const int kv_heads = key_cache.size(1);
    TORCH_CHECK(kv_heads > 0 && heads % kv_heads == 0,
                "Invalid grouped-query head counts");
    auto out = torch::empty(query.sizes(), query.options());
    if (tokens == 0 || heads == 0) return out;

    const float* slope_ptr = nullptr;
    int64_t slope_stride = 0;
    if (slopes.has_value()) {
        TORCH_CHECK(slopes->scalar_type() == at::kFloat,
                    "Expected float32 ALiBi slopes");
        slope_ptr = slopes->data_ptr<float>();
        slope_stride = slopes->stride(0);
    }

    attention_kernel<<<dim3(tokens, heads), 256,
                       size_t(2 * dim) * sizeof(float),
                       at::cuda::getCurrentCUDAStream()>>>(
        float_view(query), float_view(key), float_view(value),
        float_view(key_cache), float_view(value_cache),
        index_view(block_tables), index_view(query_start_loc),
        index_view(seq_lens), slope_ptr, slope_stride,
        out.data_ptr<float>(), heads, kv_heads, dim,
        value_cache.size(3), key_cache.size(4), seq_lens.size(0),
        float(scale));
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="paged_prefix_attention_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key, value, key_cache, value_cache, block_tables,
                query_start_loc, seq_lens, alibi_slopes=None):
        return _get_extension().paged_attention(
            query, key, value, key_cache, value_cache, block_tables,
            query_start_loc, seq_lens, alibi_slopes, self.scale
        )
```