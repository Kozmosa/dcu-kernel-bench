import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXTENSION = None

_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor rmsnorm_forward(
    torch::Tensor x,
    torch::Tensor weight,
    torch::Tensor residual,
    double eps,
    bool fused);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("rmsnorm_forward", &rmsnorm_forward, "Fused RMSNorm forward");
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <cmath>

template <typename scalar_t>
__global__ void rmsnorm_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ weight,
    const scalar_t* __restrict__ residual,
    scalar_t* __restrict__ out,
    int64_t rows,
    int64_t cols,
    float eps,
    bool fused)
{
    int64_t row = static_cast<int64_t>(blockIdx.x);
    if (row >= rows) return;

    int tid = threadIdx.x;
    extern __shared__ float smem[];

    const scalar_t* xr = x + row * cols;
    const scalar_t* rr = residual + row * cols;
    scalar_t* orow = out + row * (fused ? 2 * cols : cols);

    float sum = 0.0f;

    for (int64_t i = tid; i < cols; i += blockDim.x) {
        scalar_t v;
        if (fused) {
            v = static_cast<scalar_t>(xr[i] + rr[i]);
        } else {
            v = xr[i];
        }
        float fv = static_cast<float>(v);
        sum += fv * fv;
    }

    smem[tid] = sum;
    __syncthreads();

    for (int stride = blockDim.x >> 1; stride > 0; stride >>= 1) {
        if (tid < stride) {
            smem[tid] += smem[tid + stride];
        }
        __syncthreads();
    }

    float inv_rms = rsqrtf(smem[0] / static_cast<float>(cols) + eps);

    for (int64_t i = tid; i < cols; i += blockDim.x) {
        scalar_t v;
        if (fused) {
            v = static_cast<scalar_t>(xr[i] + rr[i]);
        } else {
            v = xr[i];
        }

        float y = static_cast<float>(v) *
                  inv_rms *
                  static_cast<float>(weight[i]);

        orow[i] = static_cast<scalar_t>(y);

        if (fused) {
            orow[cols + i] = v;
        }
    }
}

torch::Tensor rmsnorm_forward(
    torch::Tensor x,
    torch::Tensor weight,
    torch::Tensor residual,
    double eps,
    bool fused)
{
    TORCH_CHECK(x.is_cuda(), "x must be a CUDA/HIP tensor");
    TORCH_CHECK(weight.is_cuda(), "weight must be a CUDA/HIP tensor");
    TORCH_CHECK(residual.is_cuda(), "residual must be a CUDA/HIP tensor");
    TORCH_CHECK(x.is_contiguous(), "x must be contiguous");
    TORCH_CHECK(weight.is_contiguous(), "weight must be contiguous");
    TORCH_CHECK(residual.is_contiguous(), "residual must be contiguous");
    TORCH_CHECK(x.dim() == 2, "x must be 2D");
    TORCH_CHECK(weight.dim() == 1, "weight must be 1D");
    TORCH_CHECK(residual.dim() == 2, "residual must be 2D");
    TORCH_CHECK(x.scalar_type() == weight.scalar_type(), "dtype mismatch");
    TORCH_CHECK(x.scalar_type() == residual.scalar_type(), "dtype mismatch");

    const int64_t rows = x.size(0);
    const int64_t cols = x.size(1);

    TORCH_CHECK(weight.size(0) == cols, "weight shape mismatch");
    TORCH_CHECK(residual.size(0) == rows && residual.size(1) == cols,
                "residual shape mismatch");

    auto out_sizes = fused
        ? std::vector<int64_t>{rows, cols * 2}
        : std::vector<int64_t>{rows, cols};

    auto out = torch::empty(out_sizes, x.options());

    constexpr int threads = 256;
    const dim3 grid(static_cast<unsigned int>(rows));
    const dim3 block(threads);
    const size_t shmem = threads * sizeof(float);

    hipStream_t stream =
        at::cuda::getDefaultCUDAStream(x.device().index());

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "rmsnorm_forward_hip",
        [&] {
            hipLaunchKernelGGL(
                rmsnorm_kernel<scalar_t>,
                grid,
                block,
                shmem,
                stream,
                x.data_ptr<scalar_t>(),
                weight.data_ptr<scalar_t>(),
                residual.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(),
                rows,
                cols,
                static_cast<float>(eps),
                fused);
        });

    return out;
}
"""

def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        _EXTENSION = load_inline(
            name="hygon_fused_rmsnorm_hip",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "fused_add", eps: float = 1e-5):
        super().__init__()
        assert variant in ("rmsnorm", "fused_add"), \
            "variant must be one of rmsnorm / fused_add"
        self.variant = variant
        self.eps = float(eps)

    def forward(self, x, weight, residual):
        return _get_extension().rmsnorm_forward(
            x,
            weight,
            residual,
            self.eps,
            self.variant == "fused_add",
        )
