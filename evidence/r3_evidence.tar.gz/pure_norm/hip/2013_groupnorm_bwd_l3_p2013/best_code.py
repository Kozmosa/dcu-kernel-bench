import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_EXTENSION = None

_CPP_SRC = r"""
#include <torch/extension.h>

void groupnorm_backward_cuda(
    torch::Tensor x,
    torch::Tensor dy,
    torch::Tensor scale,
    torch::Tensor mean,
    torch::Tensor inv_var,
    torch::Tensor out,
    int64_t groups);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("groupnorm_backward", &groupnorm_backward_cuda,
          "GroupNorm backward");
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/ATen.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/util/BFloat16.h>
#include <hip/hip_runtime.h>

template <typename T>
__device__ __forceinline__ float to_float(T v) {
    return static_cast<float>(v);
}

template <>
__device__ __forceinline__ float to_float<c10::Half>(c10::Half v) {
    return static_cast<float>(v);
}

template <>
__device__ __forceinline__ float to_float<c10::BFloat16>(c10::BFloat16 v) {
    return static_cast<float>(v);
}

template <typename scalar_t>
__global__ void reduce_group_tiles_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ dy,
    const scalar_t* __restrict__ scale,
    const float* __restrict__ mean,
    const float* __restrict__ inv_var,
    float* __restrict__ partial_s,
    float* __restrict__ partial_t,
    int N, int C, int H, int W, int G, int rep, int D, int tiles)
{
    int tile = blockIdx.y;
    int ng = blockIdx.x;
    int n = ng / G;
    int g = ng - n * G;
    int tid = threadIdx.x;
    int q = tile * blockDim.x + tid;

    float s = 0.0f;
    float t = 0.0f;

    if (q < D) {
        int cc = q / (H * W);
        int p = q - cc * H * W;
        int c = g * rep + cc;
        int64_t base = (static_cast<int64_t>(n) * C + c) * H * W + p;

        float xv = to_float(x[base]);
        float gv = to_float(dy[base]);
        float sc = to_float(scale[c]);
        float xhat = (xv - mean[ng]) * inv_var[ng];
        float v = gv * sc;

        s = v;
        t = v * xhat;
    }

    extern __shared__ float smem[];
    float* ss = smem;
    float* st = smem + blockDim.x;
    ss[tid] = s;
    st[tid] = t;
    __syncthreads();

    for (int stride = blockDim.x >> 1; stride > 0; stride >>= 1) {
        if (tid < stride) {
            ss[tid] += ss[tid + stride];
            st[tid] += st[tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0) {
        partial_s[ng * tiles + tile] = ss[0];
        partial_t[ng * tiles + tile] = st[0];
    }
}

__global__ void finalize_group_kernel(
    const float* __restrict__ partial_s,
    const float* __restrict__ partial_t,
    float* __restrict__ sums,
    int groups_count, int tiles)
{
    int ng = blockIdx.x;
    if (ng >= groups_count || threadIdx.x != 0) return;

    float s = 0.0f;
    float t = 0.0f;
    const int64_t off = static_cast<int64_t>(ng) * tiles;

    for (int i = 0; i < tiles; ++i) {
        s += partial_s[off + i];
        t += partial_t[off + i];
    }

    sums[2 * ng] = s;
    sums[2 * ng + 1] = t;
}

template <typename scalar_t>
__global__ void channel_reduce_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ dy,
    const float* __restrict__ mean,
    const float* __restrict__ inv_var,
    float* __restrict__ dgamma,
    float* __restrict__ dbeta,
    int N, int C, int H, int W, int G, int rep)
{
    int c = blockIdx.x;
    int tid = threadIdx.x;
    int spatial = H * W;
    int nhw = N * spatial;

    float sg = 0.0f;
    float sb = 0.0f;

    for (int k = tid; k < nhw; k += blockDim.x) {
        int n = k / spatial;
        int p = k - n * spatial;
        int ng = n * G + c / rep;
        int64_t idx = (static_cast<int64_t>(n) * C + c) * spatial + p;

        float xv = to_float(x[idx]);
        float gy = to_float(dy[idx]);
        float xhat = (xv - mean[ng]) * inv_var[ng];

        sg += gy * xhat;
        sb += gy;
    }

    extern __shared__ float smem[];
    float* s0 = smem;
    float* s1 = smem + blockDim.x;
    s0[tid] = sg;
    s1[tid] = sb;
    __syncthreads();

    for (int stride = blockDim.x >> 1; stride > 0; stride >>= 1) {
        if (tid < stride) {
            s0[tid] += s0[tid + stride];
            s1[tid] += s1[tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0) {
        dgamma[c] = s0[0];
        dbeta[c] = s1[0];
    }
}

template <typename scalar_t>
__global__ void dx_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ dy,
    const scalar_t* __restrict__ scale,
    const float* __restrict__ mean,
    const float* __restrict__ inv_var,
    const float* __restrict__ sums,
    float* __restrict__ dx,
    int N, int C, int H, int W, int G, int rep, int D)
{
    int64_t linear = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    int64_t total = static_cast<int64_t>(N) * C * H * W;
    if (linear >= total) return;

    int spatial = H * W;
    int c = (linear / spatial) % C;
    int n = linear / (static_cast<int64_t>(C) * spatial);
    int ng = n * G + c / rep;

    float xv = to_float(x[linear]);
    float gy = to_float(dy[linear]);
    float sc = to_float(scale[c]);
    float xhat = (xv - mean[ng]) * inv_var[ng];

    float S = sums[2 * ng];
    float T = sums[2 * ng + 1];
    float inv = inv_var[ng];

    dx[linear] = (inv / static_cast<float>(D)) *
                 (static_cast<float>(D) * gy * sc - S - xhat * T);
}

template <typename scalar_t>
void launch_groupnorm(
    torch::Tensor x,
    torch::Tensor dy,
    torch::Tensor scale,
    torch::Tensor mean,
    torch::Tensor inv_var,
    torch::Tensor out,
    int G)
{
    const int N = static_cast<int>(x.size(0));
    const int C = static_cast<int>(x.size(1));
    const int H = static_cast<int>(x.size(2));
    const int W = static_cast<int>(x.size(3));
    const int rep = C / G;
    const int D = rep * H * W;
    const int groups_count = N * G;
    const int threads = 256;
    const int tiles = (D + threads - 1) / threads;

    auto opts = x.options().dtype(torch::kFloat32);
    auto partial_s = torch::empty({groups_count * tiles}, opts);
    auto partial_t = torch::empty({groups_count * tiles}, opts);
    auto sums = torch::empty({groups_count * 2}, opts);

    float* outp = out.data_ptr<float>();
    float* dxp = outp;
    float* dgp = outp + static_cast<int64_t>(N) * C * H * W;
    float* dbp = dgp + C;

    hipStream_t stream = at::cuda::getDefaultCUDAStream();

    dim3 grid1(groups_count, tiles, 1);
    size_t shmem = static_cast<size_t>(threads) * 2 * sizeof(float);
    hipLaunchKernelGGL(
        (reduce_group_tiles_kernel<scalar_t>),
        grid1, dim3(threads), shmem, stream,
        x.data_ptr<scalar_t>(),
        dy.data_ptr<scalar_t>(),
        scale.data_ptr<scalar_t>(),
        mean.data_ptr<float>(),
        inv_var.data_ptr<float>(),
        partial_s.data_ptr<float>(),
        partial_t.data_ptr<float>(),
        N, C, H, W, G, rep, D, tiles);

    hipLaunchKernelGGL(
        finalize_group_kernel,
        dim3(groups_count), dim3(1), 0, stream,
        partial_s.data_ptr<float>(),
        partial_t.data_ptr<float>(),
        sums.data_ptr<float>(),
        groups_count, tiles);

    hipLaunchKernelGGL(
        (channel_reduce_kernel<scalar_t>),
        dim3(C), dim3(threads), shmem, stream,
        x.data_ptr<scalar_t>(),
        dy.data_ptr<scalar_t>(),
        mean.data_ptr<float>(),
        inv_var.data_ptr<float>(),
        dgp, dbp,
        N, C, H, W, G, rep);

    int64_t total = static_cast<int64_t>(N) * C * H * W;
    dim3 grid4(static_cast<unsigned int>((total + threads - 1) / threads));
    hipLaunchKernelGGL(
        (dx_kernel<scalar_t>),
        grid4, dim3(threads), 0, stream,
        x.data_ptr<scalar_t>(),
        dy.data_ptr<scalar_t>(),
        scale.data_ptr<scalar_t>(),
        mean.data_ptr<float>(),
        inv_var.data_ptr<float>(),
        sums.data_ptr<float>(),
        dxp,
        N, C, H, W, G, rep, D);
}

void groupnorm_backward_cuda(
    torch::Tensor x,
    torch::Tensor dy,
    torch::Tensor scale,
    torch::Tensor mean,
    torch::Tensor inv_var,
    torch::Tensor out,
    int64_t groups)
{
    TORCH_CHECK(x.is_cuda(), "x must be on CUDA/HIP device");
    TORCH_CHECK(dy.is_cuda() && scale.is_cuda() &&
                mean.is_cuda() && inv_var.is_cuda() && out.is_cuda(),
                "all tensors must be on CUDA/HIP device");
    TORCH_CHECK(x.is_contiguous() && dy.is_contiguous() &&
                scale.is_contiguous() && mean.is_contiguous() &&
                inv_var.is_contiguous() && out.is_contiguous(),
                "all tensors must be contiguous");
    TORCH_CHECK(x.scalar_type() == dy.scalar_type() &&
                x.scalar_type() == scale.scalar_type(),
                "x, dy, and scale must have the same dtype");
    TORCH_CHECK(mean.scalar_type() == torch::kFloat32 &&
                inv_var.scalar_type() == torch::kFloat32 &&
                out.scalar_type() == torch::kFloat32,
                "mean, inv_var, and out must be float32");

    const int64_t N = x.size(0);
    const int64_t C = x.size(1);
    TORCH_CHECK(groups >= 1 && groups <= C && C % groups == 0,
                "groups must divide C");
    TORCH_CHECK(mean.numel() == N * groups &&
                inv_var.numel() == N * groups,
                "invalid statistics size");

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::Half, at::BFloat16, x.scalar_type(),
        "groupnorm_backward_cuda",
        [&] {
            launch_groupnorm<scalar_t>(
                x, dy, scale, mean, inv_var, out,
                static_cast<int>(groups));
        });

    TORCH_CHECK(hipGetLastError() == hipSuccess,
                "GroupNorm HIP kernel launch failed");
}
"""

def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP_SRC + _HIP_SRC).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="groupnorm_backward_" + digest,
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, groups: int = 2, eps: float = 1e-5):
        super().__init__()
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.groups = int(groups)
        self.eps = float(eps)

    def forward(self, x, dy, scale, mean, inv_var):
        n, c, h, w = x.shape
        g = self.groups
        assert 1 <= g <= c and c % g == 0
        assert mean.numel() == n * g and inv_var.numel() == n * g

        out = torch.empty(
            n * c * h * w + 2 * c,
            device=x.device,
            dtype=torch.float32,
        )

        _get_extension().groupnorm_backward(
            x, dy, scale, mean, inv_var, out, g
        )
        return out
