import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor pyramid_select(torch::Tensor x, int64_t k);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("select", &pyramid_select);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cstdint>
#include <limits>

constexpr int TILE = 256;

__device__ __forceinline__ float2 empty_pair() {
    return make_float2(-INFINITY, -1.0f);
}

__device__ __forceinline__ bool better(float2 a, float2 b) {
    if (a.y < 0.0f) return false;
    if (b.y < 0.0f) return true;
    if (isnan(a.x)) return !isnan(b.x) || a.y < b.y;
    if (isnan(b.x)) return false;
    return a.x > b.x || (a.x == b.x && a.y < b.y);
}

__global__ void maximum_kernel(
    const float* __restrict__ x, float* __restrict__ out,
    int64_t rows, int cols
) {
    __shared__ float2 partial[4];
    const int lane = threadIdx.x & 63;
    const int wave = threadIdx.x >> 6;
    for (int64_t row = blockIdx.x; row < rows; row += gridDim.x) {
        float2 best = empty_pair();
        for (int col = threadIdx.x; col < cols; col += blockDim.x) {
            float2 candidate = make_float2(x[row * cols + col], float(col));
            if (better(candidate, best)) best = candidate;
        }
        #pragma unroll
        for (int delta = 32; delta; delta >>= 1) {
            float2 other;
            other.x = __shfl_down(best.x, delta, 64);
            other.y = __shfl_down(best.y, delta, 64);
            if (lane + delta < 64 && better(other, best)) best = other;
        }
        if (lane == 0) partial[wave] = best;
        __syncthreads();
        if (threadIdx.x == 0) {
            best = partial[0];
            #pragma unroll
            for (int j = 1; j < 4; ++j)
                if (better(partial[j], best)) best = partial[j];
            out[row * 2] = best.x;
            out[row * 2 + 1] = best.y;
        }
        __syncthreads();
    }
}

__global__ void tile_kernel(
    const float* __restrict__ x,
    float2* __restrict__ temporary,
    float* __restrict__ out,
    int64_t total_tiles, int cols, int chunks, int keep, int k,
    bool final_output
) {
    __shared__ float2 shared[TILE];
    const int tid = threadIdx.x;

    for (int64_t tile = blockIdx.x; tile < total_tiles; tile += gridDim.x) {
        const int64_t row = tile / chunks;
        const int chunk = int(tile - row * chunks);
        const int col = chunk * TILE + tid;
        float2 value = col < cols
            ? make_float2(x[row * cols + col], float(col))
            : empty_pair();

        #pragma unroll
        for (int size = 2; size <= TILE; size <<= 1) {
            #pragma unroll
            for (int distance = size >> 1; distance; distance >>= 1) {
                float2 other;
                if (distance < 64) {
                    other.x = __shfl_xor(value.x, distance, 64);
                    other.y = __shfl_xor(value.y, distance, 64);
                } else {
                    shared[tid] = value;
                    __syncthreads();
                    other = shared[tid ^ distance];
                    __syncthreads();
                }
                const bool take_best = ((tid & size) == 0) == ((tid & distance) == 0);
                if (take_best ? better(other, value) : better(value, other))
                    value = other;
            }
        }

        if (tid < keep) {
            if (final_output) {
                out[row * (2LL * k) + tid] = value.x;
                out[row * (2LL * k) + k + tid] = value.y;
            } else {
                temporary[tile * keep + tid] = value;
            }
        }
        __syncthreads();
    }
}

__device__ __forceinline__ float2 read_pair(
    const float2* input, int index, int length, bool present
) {
    return present && index >= 0 && index < length
        ? input[index] : empty_pair();
}

__global__ void merge_kernel(
    const float2* __restrict__ input,
    float2* __restrict__ output,
    float* __restrict__ result,
    int64_t count, int old_segments, int new_segments,
    int old_length, int new_length, int k, bool final_output
) {
    for (int64_t linear = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         linear < count;
         linear += int64_t(gridDim.x) * blockDim.x) {
        const int rank = int(linear % new_length);
        const int64_t segment_linear = linear / new_length;
        const int segment = int(segment_linear % new_segments);
        const int64_t row = segment_linear / new_segments;
        const int left_segment = segment * 2;
        const bool right_present = left_segment + 1 < old_segments;

        const float2* left = input +
            (row * old_segments + left_segment) * old_length;
        const float2* right = right_present ? left + old_length : left;

        int low = max(0, rank - old_length);
        int high = min(rank, old_length);
        while (low < high) {
            const int a = (low + high) >> 1;
            const int b = rank - a;
            float2 av = read_pair(left, a, old_length, true);
            float2 bv = read_pair(right, b - 1, old_length, right_present);
            if (b > 0 && a < old_length && better(av, bv))
                low = a + 1;
            else
                high = a;
        }

        const int a = low;
        const int b = rank - a;
        float2 av = read_pair(left, a, old_length, true);
        float2 bv = read_pair(right, b, old_length, right_present);
        float2 selected = better(bv, av) ? bv : av;

        if (final_output) {
            result[row * (2LL * k) + rank] = selected.x;
            result[row * (2LL * k) + k + rank] = selected.y;
        } else {
            output[linear] = selected;
        }
    }
}

torch::Tensor pyramid_select(torch::Tensor x, int64_t k64) {
    TORCH_CHECK(x.is_cuda(), "x must be on the accelerator");
    TORCH_CHECK(x.scalar_type() == at::kFloat, "x must have dtype float32");
    TORCH_CHECK(x.dim() == 2 && x.is_contiguous(), "x must be contiguous and two-dimensional");
    const int64_t rows = x.size(0);
    TORCH_CHECK(x.size(1) > 0 && x.size(1) < (1LL << 24), "unsupported row length");
    const int cols = int(x.size(1));
    TORCH_CHECK(k64 >= 1 && k64 <= cols, "k must lie in [1, M]");
    const int k = int(k64);

    c10::cuda::CUDAGuard guard(x.device());
    auto stream = at::cuda::getCurrentCUDAStream(x.get_device());
    auto result = torch::empty({rows, 2 * k64}, x.options());
    if (rows == 0) return result;

    if (k == 1) {
        const unsigned blocks = unsigned(std::min<int64_t>(rows, 65535));
        maximum_kernel<<<blocks, 256, 0, stream>>>(
            x.data_ptr<float>(), result.data_ptr<float>(), rows, cols);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        return result;
    }

    int segments = (cols + TILE - 1) / TILE;
    int length = std::min(k, TILE);
    const int64_t tiles = rows * segments;
    const unsigned tile_blocks = unsigned(std::min<int64_t>(tiles, 65535));

    if (segments == 1) {
        tile_kernel<<<tile_blocks, TILE, 0, stream>>>(
            x.data_ptr<float>(), nullptr, result.data_ptr<float>(),
            tiles, cols, segments, length, k, true);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        return result;
    }

    // Every merge retains at most the combined number of input candidates.
    const int64_t capacity = tiles * length * 2;
    auto buffer_a = torch::empty({capacity}, x.options());
    auto buffer_b = torch::empty({capacity}, x.options());
    float2* a = reinterpret_cast<float2*>(buffer_a.data_ptr<float>());
    float2* b = reinterpret_cast<float2*>(buffer_b.data_ptr<float>());

    tile_kernel<<<tile_blocks, TILE, 0, stream>>>(
        x.data_ptr<float>(), a, nullptr, tiles, cols, segments, length, k, false);
    C10_CUDA_KERNEL_LAUNCH_CHECK();

    while (segments > 1) {
        const int next_segments = (segments + 1) / 2;
        const int next_length = std::min(k, length * 2);
        const int64_t count = rows * next_segments * next_length;
        const unsigned blocks = unsigned(std::min<int64_t>((count + 255) / 256, 65535));
        merge_kernel<<<blocks, 256, 0, stream>>>(
            a, b, result.data_ptr<float>(), count, segments, next_segments,
            length, next_length, k, next_segments == 1);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        std::swap(a, b);
        segments = next_segments;
        length = next_length;
    }
    return result;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode("utf-8")
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=f"pyramid_select_hip_{digest}",
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, k: int = 8):
        super().__init__()
        assert k >= 1, "k must be >= 1"
        self.k = int(k)

    def forward(self, x):
        return _get_extension().select(x, self.k)
