import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

void run_update(
    const torch::Tensor& data,
    const torch::Tensor& indices,
    const torch::Tensor& updates,
    torch::Tensor& out);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run_update", &run_update);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>
#include <algorithm>

struct Layout {
    int64_t size[6];
    int64_t row_stride;
    int64_t col_stride;
};

__global__ void copy_vectors(
    const uint4* __restrict__ src,
    uint4* __restrict__ dst,
    int64_t vectors,
    int tail)
{
    int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    const int64_t step = (int64_t)blockDim.x * gridDim.x;
    for (; i < vectors; i += step)
        dst[i] = src[i];

    int t = blockIdx.x * blockDim.x + threadIdx.x;
    if (t < tail) {
        const unsigned char* s =
            reinterpret_cast<const unsigned char*>(src) + vectors * 16;
        unsigned char* d =
            reinterpret_cast<unsigned char*>(dst) + vectors * 16;
        d[t] = s[t];
    }
}

template <typename Bits>
__global__ void copy_elements(
    const Bits* __restrict__ src,
    Bits* __restrict__ dst,
    int64_t n)
{
    int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    const int64_t step = (int64_t)blockDim.x * gridDim.x;
    for (; i < n; i += step)
        dst[i] = src[i];
}

template <typename Bits, typename Index, int Rank>
__global__ void write_updates(
    const Index* __restrict__ indices,
    const Bits* __restrict__ updates,
    Bits* __restrict__ out,
    int64_t count,
    Layout layout)
{
    int64_t k = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    const int64_t step = (int64_t)blockDim.x * gridDim.x;
    for (; k < count; k += step) {
        int64_t offset = 0;
        #pragma unroll
        for (int d = 0; d < Rank; ++d) {
            int64_t coordinate =
                static_cast<int64_t>(
                    indices[k * layout.row_stride + d * layout.col_stride]);
            offset = offset * layout.size[d] + coordinate;
        }
        out[offset] = updates[k];
    }
}

template <typename Bits, typename Index>
void launch_updates(
    const torch::Tensor& indices,
    const torch::Tensor& updates,
    torch::Tensor& out,
    int rank,
    int64_t count,
    Layout layout,
    hipStream_t stream)
{
    const Index* ip = reinterpret_cast<const Index*>(indices.data_ptr());
    const Bits* up = reinterpret_cast<const Bits*>(updates.data_ptr());
    Bits* op = reinterpret_cast<Bits*>(out.data_ptr());
    int blocks = static_cast<int>(std::min<int64_t>((count + 255) / 256, 4096));

    #define RUN_RANK(R) \
        case R: \
            hipLaunchKernelGGL((write_updates<Bits, Index, R>), \
                dim3(blocks), dim3(256), 0, stream, \
                ip, up, op, count, layout); \
            break;

    switch (rank) {
        RUN_RANK(1)
        RUN_RANK(2)
        RUN_RANK(3)
        RUN_RANK(4)
        RUN_RANK(5)
        RUN_RANK(6)
    }
    #undef RUN_RANK
}

template <typename Bits>
void launch_typed(
    const torch::Tensor& data,
    const torch::Tensor& indices,
    const torch::Tensor& updates,
    torch::Tensor& out,
    Layout layout,
    hipStream_t stream)
{
    const int64_t n = data.numel();
    const int64_t count = updates.numel();

    // A full permutation replaces every element, so no initial copy is needed.
    if (count != n && n != 0) {
        uintptr_t alignment =
            reinterpret_cast<uintptr_t>(data.data_ptr()) |
            reinterpret_cast<uintptr_t>(out.data_ptr());
        if ((alignment & 15) == 0) {
            int64_t bytes = n * sizeof(Bits);
            int64_t vectors = bytes / 16;
            int tail = static_cast<int>(bytes % 16);
            int blocks = static_cast<int>(std::min<int64_t>(
                std::max<int64_t>(1, (vectors + 255) / 256), 4096));
            hipLaunchKernelGGL(copy_vectors, dim3(blocks), dim3(256),
                0, stream,
                reinterpret_cast<const uint4*>(data.data_ptr()),
                reinterpret_cast<uint4*>(out.data_ptr()), vectors, tail);
        } else {
            int blocks = static_cast<int>(
                std::min<int64_t>((n + 255) / 256, 4096));
            hipLaunchKernelGGL((copy_elements<Bits>),
                dim3(blocks), dim3(256), 0, stream,
                reinterpret_cast<const Bits*>(data.data_ptr()),
                reinterpret_cast<Bits*>(out.data_ptr()), n);
        }
    }

    if (count == 0)
        return;

    switch (indices.scalar_type()) {
        case at::kLong:
            launch_updates<Bits, int64_t>(
                indices, updates, out, data.dim(), count, layout, stream);
            break;
        case at::kFloat:
            launch_updates<Bits, float>(
                indices, updates, out, data.dim(), count, layout, stream);
            break;
        case at::kInt:
            launch_updates<Bits, int32_t>(
                indices, updates, out, data.dim(), count, layout, stream);
            break;
        case at::kDouble:
            launch_updates<Bits, double>(
                indices, updates, out, data.dim(), count, layout, stream);
            break;
        default:
            TORCH_CHECK(false, "Unsupported index dtype");
    }
}

void run_update(
    const torch::Tensor& data,
    const torch::Tensor& indices,
    const torch::Tensor& updates,
    torch::Tensor& out)
{
    TORCH_CHECK(data.is_cuda() && indices.is_cuda() && updates.is_cuda(),
                "All inputs must be device tensors");
    TORCH_CHECK(data.device() == indices.device() &&
                data.device() == updates.device() &&
                data.device() == out.device(), "Device mismatch");
    TORCH_CHECK(data.dim() >= 1 && data.dim() <= 6, "Invalid rank");
    TORCH_CHECK(data.is_contiguous() && updates.is_contiguous() &&
                out.is_contiguous(), "Expected contiguous values");
    TORCH_CHECK(indices.dim() == 2 && indices.size(1) == data.dim() &&
                updates.dim() == 1 && updates.numel() == indices.size(0),
                "Invalid input shapes");
    TORCH_CHECK(data.scalar_type() == updates.scalar_type() &&
                data.scalar_type() == out.scalar_type(),
                "Value dtype mismatch");

    c10::cuda::CUDAGuard guard(data.device());
    hipStream_t stream = at::cuda::getCurrentCUDAStream(data.get_device());

    Layout layout{};
    for (int d = 0; d < data.dim(); ++d)
        layout.size[d] = data.size(d);
    layout.row_stride = indices.stride(0);
    layout.col_stride = indices.stride(1);

    if (data.scalar_type() == at::kFloat) {
        launch_typed<uint32_t>(data, indices, updates, out, layout, stream);
    } else if (data.scalar_type() == at::kHalf ||
               data.scalar_type() == at::kBFloat16) {
        launch_typed<uint16_t>(data, indices, updates, out, layout, stream);
    } else {
        TORCH_CHECK(false, "Expected float32, float16, or bfloat16");
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha256(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"coordinate_update_{digest}",
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, data, indices, updates):
        out = torch.empty(data.shape, dtype=data.dtype, device=data.device)
        _get_extension().run_update(data, indices, updates, out)
        return out
