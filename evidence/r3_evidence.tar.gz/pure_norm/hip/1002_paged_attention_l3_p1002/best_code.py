import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_decode(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                           torch::Tensor bt, torch::Tensor lens, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_decode", &paged_decode);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

constexpr int TILE = 256;
constexpr int THREADS = 256;
constexpr int WAVE = 64;

struct Layout {
    int64_t q0, q1, q2;
    int64_t k0, k1, k2, k3;
    int64_t v0, v1, v2, v3;
    int64_t b0, b1, l0;
    int heads, dim, group, block_size, splits;
    bool bt64, len64;
};

__device__ __forceinline__ int64_t read_index(
    const void* ptr, int64_t pos, bool wide) {
    return wide ? static_cast<const int64_t*>(ptr)[pos]
                : static_cast<const int32_t*>(ptr)[pos];
}

__device__ __forceinline__ float wave_sum(float x) {
    #pragma unroll
    for (int offset = 32; offset; offset >>= 1)
        x += __shfl_down(x, offset, WAVE);
    return x;
}

__device__ __forceinline__ float wave_max(float x) {
    #pragma unroll
    for (int offset = 32; offset; offset >>= 1)
        x = fmaxf(x, __shfl_down(x, offset, WAVE));
    return x;
}

__device__ __forceinline__ float block_reduce(
    float x, float* scratch, bool maximum) {
    int lane = threadIdx.x & 63;
    int wave = threadIdx.x >> 6;
    x = maximum ? wave_max(x) : wave_sum(x);
    if (lane == 0) scratch[wave] = x;
    __syncthreads();
    x = lane < 4 ? scratch[lane] : (maximum ? -INFINITY : 0.0f);
    x = maximum ? wave_max(x) : wave_sum(x);
    return __shfl(x, 0, WAVE);
}

__global__ void attention_parts(
    const float* __restrict__ q,
    const float* __restrict__ k,
    const float* __restrict__ v,
    const void* __restrict__ bt,
    const void* __restrict__ lens,
    float* __restrict__ parts,
    float* __restrict__ stats,
    Layout a, float scale) {

    int h = blockIdx.x % a.heads;
    int s = blockIdx.x / a.heads;
    int part = blockIdx.y;
    int t = threadIdx.x;
    int lane = t & 63;
    int wave = t >> 6;
    int kvh = h / a.group;
    int64_t length = read_index(lens, (int64_t)s * a.l0, a.len64);
    int64_t start = (int64_t)part * TILE;
    int count = (int)min((int64_t)TILE, max((int64_t)0, length - start));
    int64_t slot = (int64_t)blockIdx.x * a.splits + part;

    if (count == 0) {
        if (t == 0) {
            stats[slot * 2] = -INFINITY;
            stats[slot * 2 + 1] = 0.0f;
        }
        for (int d = t; d < a.dim; d += THREADS)
            parts[slot * a.dim + d] = 0.0f;
        return;
    }

    __shared__ float weights[TILE];
    __shared__ float scratch[4];
    __shared__ int64_t physical[TILE];

    if (t < count) {
        int64_t pos = start + t;
        physical[t] = read_index(
            bt, (int64_t)s * a.b0 + (pos / a.block_size) * a.b1, a.bt64);
    }
    __syncthreads();

    const float* query = q + (int64_t)s * a.q0 + (int64_t)h * a.q1;
    for (int j = wave; j < count; j += 4) {
        int offset = (start + j) % a.block_size;
        int64_t base = physical[j] * a.k0 + (int64_t)kvh * a.k1
                     + (int64_t)offset * a.k2;
        float dot = 0.0f;
        for (int d = lane; d < a.dim; d += WAVE)
            dot = fmaf(query[(int64_t)d * a.q2] * scale,
                       k[base + (int64_t)d * a.k3], dot);
        dot = wave_sum(dot);
        if (lane == 0) weights[j] = dot;
    }
    __syncthreads();

    float logit = t < count ? weights[t] : -INFINITY;
    float maximum = block_reduce(logit, scratch, true);
    float weight = t < count ? expf(logit - maximum) : 0.0f;
    __syncthreads();
    weights[t] = weight;
    float denominator = block_reduce(weight, scratch, false);

    if (t == 0) {
        stats[slot * 2] = maximum;
        stats[slot * 2 + 1] = denominator;
    }
    for (int d = t; d < a.dim; d += THREADS) {
        float result = 0.0f;
        for (int j = 0; j < count; ++j) {
            int offset = (start + j) % a.block_size;
            int64_t base = physical[j] * a.v0 + (int64_t)kvh * a.v1
                         + (int64_t)offset * a.v2 + (int64_t)d * a.v3;
            result = fmaf(weights[j], v[base], result);
        }
        parts[slot * a.dim + d] = result;
    }
}

__global__ void merge_parts(
    const float* __restrict__ parts,
    const float* __restrict__ stats,
    float* __restrict__ out,
    int dim, int splits) {
    int row = blockIdx.x;
    __shared__ float maximum;
    __shared__ float denominator;
    if (threadIdx.x == 0) {
        float m = -INFINITY;
        for (int p = 0; p < splits; ++p)
            m = fmaxf(m, stats[((int64_t)row * splits + p) * 2]);
        float sum = 0.0f;
        if (m != -INFINITY) {
            for (int p = 0; p < splits; ++p) {
                int64_t slot = (int64_t)row * splits + p;
                sum += expf(stats[slot * 2] - m) * stats[slot * 2 + 1];
            }
        }
        maximum = m;
        denominator = sum;
    }
    __syncthreads();
    for (int d = threadIdx.x; d < dim; d += blockDim.x) {
        float value = 0.0f;
        if (denominator > 0.0f) {
            for (int p = 0; p < splits; ++p) {
                int64_t slot = (int64_t)row * splits + p;
                value = fmaf(expf(stats[slot * 2] - maximum),
                             parts[slot * dim + d], value);
            }
            value /= denominator;
        }
        out[(int64_t)row * dim + d] = value;
    }
}

torch::Tensor paged_decode(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor bt, torch::Tensor lens, double scale) {
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda()
                && bt.is_cuda() && lens.is_cuda(), "All inputs must be on GPU");
    TORCH_CHECK(q.scalar_type() == at::kFloat &&
                k.scalar_type() == at::kFloat &&
                v.scalar_type() == at::kFloat, "Expected float32 inputs");
    TORCH_CHECK((bt.scalar_type() == at::kLong || bt.scalar_type() == at::kInt)
                && (lens.scalar_type() == at::kLong || lens.scalar_type() == at::kInt),
                "Indices must be int32 or int64");
    TORCH_CHECK(q.dim() == 3 && k.dim() == 4 && v.dim() == 4 &&
                bt.dim() == 2 && lens.dim() == 1, "Invalid input ranks");
    TORCH_CHECK(k.size(1) > 0 && q.size(1) % k.size(1) == 0,
                "Invalid query head grouping");
    c10::cuda::CUDAGuard guard(q.device());

    int64_t capacity = bt.size(1) * k.size(2);
    int splits = (int)((capacity + TILE - 1) / TILE);
    splits = std::max(splits, 1);
    Layout a;
    a.q0=q.stride(0); a.q1=q.stride(1); a.q2=q.stride(2);
    a.k0=k.stride(0); a.k1=k.stride(1); a.k2=k.stride(2); a.k3=k.stride(3);
    a.v0=v.stride(0); a.v1=v.stride(1); a.v2=v.stride(2); a.v3=v.stride(3);
    a.b0=bt.stride(0); a.b1=bt.stride(1); a.l0=lens.stride(0);
    a.heads=q.size(1); a.dim=q.size(2); a.group=q.size(1)/k.size(1);
    a.block_size=k.size(2); a.splits=splits;
    a.bt64=bt.scalar_type()==at::kLong; a.len64=lens.scalar_type()==at::kLong;

    auto out = torch::empty(q.sizes(), q.options());
    int64_t rows = q.size(0) * q.size(1);
    if (!rows || !a.dim) return out;
    auto parts = torch::empty({rows, (int64_t)splits, (int64_t)a.dim}, q.options());
    auto stats = torch::empty({rows, (int64_t)splits, 2}, q.options());
    auto stream = at::cuda::getCurrentCUDAStream();
    attention_parts<<<dim3(rows, splits), THREADS, 0, stream>>>(
        q.data_ptr<float>(), k.data_ptr<float>(), v.data_ptr<float>(),
        bt.data_ptr(), lens.data_ptr(), parts.data_ptr<float>(),
        stats.data_ptr<float>(), a, (float)scale);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    merge_parts<<<rows, THREADS, 0, stream>>>(
        parts.data_ptr<float>(), stats.data_ptr<float>(),
        out.data_ptr<float>(), a.dim, splits);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "paged_decode_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        return _extension().paged_decode(
            query, key_cache, value_cache, block_tables, seq_lens, self.scale
        )
