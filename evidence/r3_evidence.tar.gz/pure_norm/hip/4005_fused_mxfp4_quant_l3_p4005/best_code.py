import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor fused_forward(torch::Tensor x, torch::Tensor w,
                            torch::Tensor r, double eps);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &fused_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/hip/HIPException.h>
#include <stdint.h>

__device__ __forceinline__ unsigned encode_fp4(float x) {
    unsigned bits = __float_as_uint(x);
    unsigned e = (bits >> 23) & 255u;
    unsigned m = bits & 0x7fffffu;
    if (e < 127u) {
        unsigned shift = 126u - e;
        m = shift >= 32u ? 0u : ((0x400000u | (m >> 1)) >> shift);
    }
    unsigned qe = (e > 126u ? e : 126u) - 126u;
    unsigned code = (((qe << 2) | (m >> 21)) + 1u) >> 1;
    code = code < 7u ? code : 7u;
    return ((bits >> 28) & 8u) | code;
}

template<int THREADS>
__global__ void fused_kernel(
    const float* __restrict__ x,
    const float* __restrict__ w,
    const float* __restrict__ r,
    uint8_t* __restrict__ out,
    int64_t n, int64_t xs0, int64_t xs1,
    int64_t rs0, int64_t rs1, int64_t ws,
    float eps)
{
    const int tid = threadIdx.x;
    const int64_t row = blockIdx.x;
    const int64_t blocks = (n + 31) / 32;
    const int64_t output_stride = n / 2 + blocks;
    x += row * xs0;
    r += row * rs0;
    out += row * output_stride;

    float sum = 0.0f;
    for (int64_t j = tid; j < n; j += THREADS) {
        float s = x[j * xs1] + r[j * rs1];
        sum += s * s;
    }

    __shared__ float partial[THREADS / 64];
    __shared__ float inv_rms;
    #pragma unroll
    for (int offset = 32; offset; offset >>= 1)
        sum += __shfl_down(sum, offset, 64);

    if ((tid & 63) == 0)
        partial[tid >> 6] = sum;
    __syncthreads();

    if (tid < 64) {
        float total = tid < THREADS / 64 ? partial[tid] : 0.0f;
        #pragma unroll
        for (int offset = 32; offset; offset >>= 1)
            total += __shfl_down(total, offset, 64);
        if (tid == 0)
            inv_rms = rsqrtf(total / static_cast<float>(n) + eps);
    }
    __syncthreads();

    const int lane = tid & 31;
    const int group = tid >> 5;
    // Every 32-lane group processes an independent MXFP4 block.
    for (int64_t b = group; b < blocks; b += THREADS / 32) {
        const int64_t j = b * 32 + lane;
        float v = 0.0f;
        if (j < n) {
            float s = x[j * xs1] + r[j * rs1];
            v = (s * inv_rms) * w[j * ws];
        }

        float amax = fabsf(v);
        #pragma unroll
        for (int offset = 16; offset; offset >>= 1)
            amax = fmaxf(amax, __shfl_xor(amax, offset, 32));

        unsigned rounded = (__float_as_uint(amax) + 0x200000u)
                           & 0xff800000u;
        int e = static_cast<int>((rounded >> 23) & 255u) - 129;
        e = e < -127 ? -127 : (e > 127 ? 127 : e);

        if (lane == 0)
            out[n / 2 + b] = static_cast<uint8_t>(e + 127);

        // Construct the exact float32 power of two, including 2^-127.
        float scale = e == 127
            ? __uint_as_float(0x00400000u)
            : __uint_as_float(static_cast<unsigned>(127 - e) << 23);
        unsigned code = encode_fp4(v * scale);
        unsigned next = __shfl_down(code, 1, 32);
        if ((lane & 1) == 0 && j + 1 < n)
            out[j / 2] = static_cast<uint8_t>(code | (next << 4));
    }
}

torch::Tensor fused_forward(torch::Tensor x, torch::Tensor w,
                            torch::Tensor r, double eps) {
    TORCH_CHECK(x.is_cuda() && w.is_cuda() && r.is_cuda(),
                "All inputs must be on the accelerator");
    TORCH_CHECK(x.scalar_type() == torch::kFloat32 &&
                w.scalar_type() == torch::kFloat32 &&
                r.scalar_type() == torch::kFloat32,
                "Inputs must be float32");
    TORCH_CHECK(x.dim() == 2 && r.sizes() == x.sizes() &&
                w.dim() == 1 && w.size(0) == x.size(1),
                "Invalid input shapes");
    TORCH_CHECK(x.device() == r.device() && x.device() == w.device(),
                "Inputs must share a device");
    const int64_t m = x.size(0), n = x.size(1);
    TORCH_CHECK(n >= 2 && n % 2 == 0, "The row width must be positive and even");

    c10::cuda::CUDAGuard guard(x.device());
    auto out = torch::empty({m, n / 2 + (n + 31) / 32},
                            x.options().dtype(torch::kUInt8));
    if (m == 0) return out;
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
    hipLaunchKernelGGL(
        (fused_kernel<256>), dim3(static_cast<unsigned>(m)), dim3(256),
        0, stream.stream(),
        x.data_ptr<float>(), w.data_ptr<float>(), r.data_ptr<float>(),
        out.data_ptr<uint8_t>(), n,
        x.stride(0), x.stride(1), r.stride(0), r.stride(1), w.stride(0),
        static_cast<float>(eps));
    C10_HIP_CHECK(hipGetLastError());
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "residual_rms_mxfp4_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, dtype: str = "bfloat16", eps: float = 1e-6):
        super().__init__()
        self.dtype = getattr(torch, dtype)
        self.eps = float(eps)

    def forward(self, inp1, weight1, res1):
        return _get_extension().forward(inp1, weight1, res1, self.eps)
