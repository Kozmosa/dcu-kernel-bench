import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor run(torch::Tensor dy, torch::Tensor weight, torch::Tensor x,
                  torch::Tensor offset, torch::Tensor mask, bool wrw,
                  int sh, int sw, int ph, int pw, int dh, int dw);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &run);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>

struct Shape {
    int N, C, H, W, K, M, S, P, OW;
    int sh, sw, ph, pw, dh, dw;
};

__device__ __forceinline__ float pixel(
    const float* x, int y, int z, int h, int w) {
    return (y >= 0 && y < h && z >= 0 && z < w)
        ? x[(int64_t)y * w + z] : 0.0f;
}

__device__ __forceinline__ void coordinates(
    const float* off, Shape s, int b, int m, int p,
    int& y, int& z, float& fy, float& fx) {
    int64_t base = ((int64_t)b * 2 * s.M + 2 * m) * s.P + p;
    float yy = float((p / s.OW) * s.sh - s.ph + (m / s.S) * s.dh)
             + off[base];
    float xx = float((p % s.OW) * s.sw - s.pw + (m % s.S) * s.dw)
             + off[base + s.P];
    float yl = floorf(yy), xl = floorf(xx);
    fy = yy - yl;
    fx = xx - xl;
    // Coordinates entirely outside the image have zero contributions.
    y = (yl < -1.0f || yl >= float(s.H)) ? -2 : int(yl);
    z = (xl < -1.0f || xl >= float(s.W)) ? -2 : int(xl);
}

__device__ __forceinline__ float sample(
    const float* x, int y, int z, float fy, float fx, Shape s) {
    float a = pixel(x, y, z, s.H, s.W);
    float b = pixel(x, y, z + 1, s.H, s.W);
    float c = pixel(x, y + 1, z, s.H, s.W);
    float d = pixel(x, y + 1, z + 1, s.H, s.W);
    return ((1.0f-fy)*(1.0f-fx)*a + (1.0f-fy)*fx*b)
         + fy*(1.0f-fx)*c + fy*fx*d;
}

// Produce the channel-wise correlation with upstream gradients.
// Each block computes a 16 x 16 tile, keeping all accumulation in fp32.
__global__ void channel_product(
    const float* __restrict__ dy, const float* __restrict__ weight,
    float* __restrict__ g, Shape s) {
    __shared__ float a[16][17];
    __shared__ float b[16][17];
    int tx = threadIdx.x, ty = threadIdx.y;
    int p = blockIdx.x * 16 + tx;
    int q = blockIdx.y * 16 + ty;
    int n = blockIdx.z;
    int Q = s.C * s.M;
    float v = 0.0f;
    for (int k0 = 0; k0 < s.K; k0 += 16) {
        int ka = k0 + tx, kb = k0 + ty;
        a[ty][tx] = (q < Q && ka < s.K)
            ? weight[(int64_t)ka * Q + q] : 0.0f;
        b[ty][tx] = (p < s.P && kb < s.K)
            ? dy[((int64_t)n * s.K + kb) * s.P + p] : 0.0f;
        __syncthreads();
        #pragma unroll
        for (int t = 0; t < 16; ++t)
            v = fmaf(a[ty][t], b[t][tx], v);
        __syncthreads();
    }
    if (q < Q && p < s.P)
        g[((int64_t)n * Q + q) * s.P + p] = v;
}

__device__ __forceinline__ void scatter(
    float* out, int y, int z, int h, int w, float v) {
    if (y >= 0 && y < h && z >= 0 && z < w)
        atomicAdd(out + (int64_t)y * w + z, v);
}

__global__ void input_gradients(
    const float* __restrict__ g, const float* __restrict__ x,
    const float* __restrict__ off, const float* __restrict__ mask,
    float* __restrict__ result, Shape s) {
    int64_t index = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    int64_t count = (int64_t)s.N * s.M * s.P;
    if (index >= count) return;
    int p = index % s.P;
    int m = (index / s.P) % s.M;
    int n = index / ((int64_t)s.M * s.P);
    int y, z;
    float fy, fx;
    coordinates(off, s, n, m, p, y, z, fy, fx);
    float mod = mask[index];
    float gy = 0.0f, gx = 0.0f, gm = 0.0f;
    float w00 = (1.0f-fy)*(1.0f-fx);
    float w01 = (1.0f-fy)*fx;
    float w10 = fy*(1.0f-fx);
    float w11 = fy*fx;
    int64_t plane = (int64_t)s.H * s.W;
    for (int c = 0; c < s.C; ++c) {
        int64_t xb = ((int64_t)n * s.C + c) * plane;
        const float* xp = x + xb;
        float a = pixel(xp, y, z, s.H, s.W);
        float b = pixel(xp, y, z+1, s.H, s.W);
        float cc = pixel(xp, y+1, z, s.H, s.W);
        float d = pixel(xp, y+1, z+1, s.H, s.W);
        float v = ((w00*a + w01*b) + w10*cc) + w11*d;
        float t = g[(((int64_t)n*s.C+c)*s.M+m)*s.P+p];
        float tm = t * mod;
        gm += t * v;
        gy += tm * ((1.0f-fx)*(cc-a) + fx*(d-b));
        gx += tm * ((1.0f-fy)*(b-a) + fy*(d-cc));
        float* dx = result + xb;
        scatter(dx, y, z, s.H, s.W, tm*w00);
        scatter(dx, y, z+1, s.H, s.W, tm*w01);
        scatter(dx, y+1, z, s.H, s.W, tm*w10);
        scatter(dx, y+1, z+1, s.H, s.W, tm*w11);
    }
    int64_t nx = (int64_t)s.N*s.C*plane;
    int64_t oi = ((int64_t)n*2*s.M+2*m)*s.P+p;
    result[nx+oi] = gy;
    result[nx+oi+s.P] = gx;
    result[nx+2*count+index] = gm;
}

__global__ void sampling(
    const float* __restrict__ x, const float* __restrict__ off,
    float* __restrict__ values, Shape s) {
    int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    int64_t T = (int64_t)s.N * s.P;
    int64_t count = (int64_t)s.C*s.M*T;
    if (i >= count) return;
    int q = i / T;
    int t = i % T;
    int n = t / s.P, p = t % s.P;
    int c = q / s.M, m = q % s.M;
    int y, z;
    float fy, fx;
    coordinates(off, s, n, m, p, y, z, fy, fx);
    const float* xp = x + ((int64_t)n*s.C+c)*s.H*s.W;
    values[i] = sample(xp, y, z, fy, fx, s);
}

// Split the spatial reduction into independently scheduled tiles.
__global__ void weight_partials(
    const float* __restrict__ dy, const float* __restrict__ values,
    const float* __restrict__ mask, float* __restrict__ partial,
    Shape s, int splits, int chunk) {
    __shared__ float a[16][17];
    __shared__ float b[16][17];
    int tx = threadIdx.x, ty = threadIdx.y;
    int q = blockIdx.x*16+tx;
    int k = blockIdx.y*16+ty;
    int split = blockIdx.z;
    int Q = s.C*s.M;
    int T = s.N*s.P;
    int end = min(T, (split+1)*chunk);
    float acc = 0.0f;
    for (int start = split*chunk; start < end; start += 16) {
        int ta = start+tx, tb = start+ty;
        a[ty][tx] = (k < s.K && ta < end)
            ? dy[((int64_t)(ta/s.P)*s.K+k)*s.P+ta%s.P] : 0.0f;
        b[ty][tx] = (q < Q && tb < end)
            ? values[(int64_t)q*T+tb] : 0.0f;
        __syncthreads();
        #pragma unroll
        for (int j = 0; j < 16; ++j) {
            int t = start+j;
            float mv = (q < Q && t < end)
                ? mask[((int64_t)(t/s.P)*s.M+q%s.M)*s.P+t%s.P]
                : 0.0f;
            acc = fmaf(a[ty][j]*mv, b[j][tx], acc);
        }
        __syncthreads();
    }
    if (q < Q && k < s.K)
        partial[((int64_t)split*s.K+k)*Q+q] = acc;
}

__global__ void finish_weights(
    const float* __restrict__ partial, float* __restrict__ output,
    int64_t size, int splits) {
    int64_t i = (int64_t)blockIdx.x*blockDim.x+threadIdx.x;
    if (i >= size) return;
    float v = 0.0f;
    for (int j = 0; j < splits; ++j)
        v += partial[(int64_t)j*size+i];
    output[i] = v;
}

torch::Tensor run(torch::Tensor dy, torch::Tensor weight, torch::Tensor x,
                  torch::Tensor offset, torch::Tensor mask, bool wrw,
                  int sh, int sw, int ph, int pw, int dh, int dw) {
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
    Shape s;
    s.N=x.size(0); s.C=x.size(1); s.H=x.size(2); s.W=x.size(3);
    s.K=weight.size(0); s.S=weight.size(3);
    s.M=weight.size(2)*s.S;
    s.P=dy.size(2)*dy.size(3); s.OW=dy.size(3);
    s.sh=sh; s.sw=sw; s.ph=ph; s.pw=pw; s.dh=dh; s.dw=dw;
    int Q=s.C*s.M;
    if (!wrw) {
        int64_t nx=x.numel();
        int64_t nm=mask.numel();
        auto out=torch::empty({nx+3*nm}, x.options());
        C10_CUDA_CHECK(hipMemsetAsync(out.data_ptr<float>(), 0,
                                   nx*sizeof(float), stream.stream()));
        auto g=torch::empty({s.N, Q, s.P}, x.options());
        channel_product<<<dim3((s.P+15)/16, (Q+15)/16, s.N),
                          dim3(16,16), 0, stream.stream()>>>(
            dy.data_ptr<float>(), weight.data_ptr<float>(),
            g.data_ptr<float>(), s);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        input_gradients<<<(nm+255)/256,256,0,stream.stream()>>>(
            g.data_ptr<float>(), x.data_ptr<float>(),
            offset.data_ptr<float>(), mask.data_ptr<float>(),
            out.data_ptr<float>(), s);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        return out;
    }
    int T=s.N*s.P;
    auto values=torch::empty({Q,T},x.options());
    int64_t nv=(int64_t)Q*T;
    sampling<<<(nv+255)/256,256,0,stream.stream()>>>(
        x.data_ptr<float>(), offset.data_ptr<float>(),
        values.data_ptr<float>(),s);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    int chunk=256;
    int splits=(T+chunk-1)/chunk;
    auto partial=torch::empty({splits,s.K,Q},x.options());
    auto out=torch::empty(weight.sizes(),x.options());
    weight_partials<<<dim3((Q+15)/16,(s.K+15)/16,splits),
                      dim3(16,16),0,stream.stream()>>>(
        dy.data_ptr<float>(),values.data_ptr<float>(),
        mask.data_ptr<float>(),partial.data_ptr<float>(),s,splits,chunk);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    int64_t nw=weight.numel();
    finish_weights<<<(nw+255)/256,256,0,stream.stream()>>>(
        partial.data_ptr<float>(),out.data_ptr<float>(),nw,splits);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "dcu_sample_grad_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1, pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        assert variant in ("dgrad", "wrw"), "variant must be either dgrad or wrw"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)

    def forward(self, dy, weight, x, offset, mask):
        return _extension().run(
            dy, weight, x, offset, mask,
            self.variant == "wrw",
            self.stride_h, self.stride_w,
            self.pad_h, self.pad_w,
            self.dil_h, self.dil_w,
        )
