import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>

void sparse_forward(
    torch::Tensor features,
    torch::Tensor filters,
    torch::Tensor pairs,
    torch::Tensor counts,
    torch::Tensor output);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("sparse_forward", &sparse_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <stdint.h>

__global__ __launch_bounds__(256)
void gathered_product(
    const float* __restrict__ features,
    const float* __restrict__ weights,
    const int* __restrict__ pairs,
    const int* __restrict__ counts,
    float* __restrict__ output,
    int n, int ci, int co, int kv)
{
    constexpr int BM = 16;
    constexpr int BN = 32;
    constexpr int BK = 32;

    const int k = blockIdx.z;
    const int first = blockIdx.x * BM;
    const int count = counts[k];
    if (first >= count) return;

    const int tid = threadIdx.x;
    const int col = tid & 31;
    const int row = tid >> 5;
    const int oc = blockIdx.y * BN + col;

    __shared__ float xs[BM][BK];
    __shared__ float ws[BN][BK + 1];
    __shared__ int src[BM];
    __shared__ int dst[BM];

    if (tid < BM) {
        const int j = first + tid;
        if (j < count) {
            src[tid] = pairs[(int64_t)k * n + j];
            dst[tid] = pairs[((int64_t)kv + k) * n + j];
        } else {
            src[tid] = 0;
            dst[tid] = -1;
        }
    }
    __syncthreads();

    float a0 = 0.0f;
    float a1 = 0.0f;

    for (int base = 0; base < ci; base += BK) {
        #pragma unroll
        for (int t = 0; t < 2; ++t) {
            const int r = row + t * 8;
            const int ic = base + col;
            float x = 0.0f;
            if (first + r < count && ic < ci)
                x = features[(int64_t)src[r] * ci + ic];
            xs[r][col] = x;
        }

        #pragma unroll
        for (int t = 0; t < 4; ++t) {
            const int wr = row + t * 8;
            const int outc = blockIdx.y * BN + wr;
            const int ic = base + col;
            float w = 0.0f;
            if (outc < co && ic < ci)
                w = weights[((int64_t)outc * kv + k) * ci + ic];
            ws[wr][col] = w;
        }
        __syncthreads();

        #pragma unroll
        for (int i = 0; i < BK; ++i) {
            const float w = ws[col][i];
            a0 = fmaf(xs[row][i], w, a0);
            a1 = fmaf(xs[row + 8][i], w, a1);
        }
        __syncthreads();
    }

    if (oc < co) {
        if (first + row < count)
            atomicAdd(output + (int64_t)dst[row] * co + oc, a0);
        if (first + row + 8 < count)
            atomicAdd(output + (int64_t)dst[row + 8] * co + oc, a1);
    }
}

void sparse_forward(
    torch::Tensor features,
    torch::Tensor filters,
    torch::Tensor pairs,
    torch::Tensor counts,
    torch::Tensor output)
{
    TORCH_CHECK(features.is_cuda() && filters.is_cuda() &&
                pairs.is_cuda() && counts.is_cuda() && output.is_cuda(),
                "All compute tensors must be on the accelerator");
    TORCH_CHECK(features.scalar_type() == at::kFloat &&
                filters.scalar_type() == at::kFloat &&
                output.scalar_type() == at::kFloat,
                "Compute tensors must be float32");
    TORCH_CHECK(pairs.scalar_type() == at::kInt &&
                counts.scalar_type() == at::kInt,
                "Indices must be int32");

    const c10::cuda::CUDAGuard guard(features.device());
    const int n = features.size(0);
    const int ci = features.size(1);
    const int co = filters.size(0);
    const int kv = filters.size(2);
    if (n == 0 || co == 0 || kv == 0 || output.numel() == 0)
        return;

    dim3 grid((n + 15) / 16, (co + 31) / 32, kv);
    hipLaunchKernelGGL(
        gathered_product, grid, dim3(256), 0,
        at::cuda::getCurrentCUDAStream(),
        features.data_ptr<float>(),
        filters.data_ptr<float>(),
        pairs.data_ptr<int>(),
        counts.data_ptr<int>(),
        output.data_ptr<float>(),
        n, ci, co, kv);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "sparse_gather_hip_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(
        self, features, filters, indice_pairs, indice_num_per_loc, num_act_out
    ):
        rows = int(num_act_out)
        dtype = features.dtype
        device = features.device
        xf = features.to(dtype=torch.float32).contiguous()
        wf = filters.to(dtype=torch.float32).contiguous()
        pairs = indice_pairs.to(device=device, dtype=torch.int32).contiguous()
        counts = indice_num_per_loc.to(
            device=device, dtype=torch.int32
        ).contiguous()
        out = torch.zeros(
            (rows, filters.shape[0]), device=device, dtype=torch.float32
        )
        _get_extension().sparse_forward(xf, wf, pairs, counts, out)
        return out.to(dtype=dtype)
