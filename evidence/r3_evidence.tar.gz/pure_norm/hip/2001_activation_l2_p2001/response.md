```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor gated_mxfp4(torch::Tensor x, int64_t activation);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("gated_mxfp4", &gated_mxfp4);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>
#include <cmath>

template<int Activation>
__device__ __forceinline__ float activate(float x) {
    if constexpr (Activation == 0) {
        return x / (1.0f + expf(-x));
    } else if constexpr (Activation == 1) {
        return (x * 0.5f) *
               (1.0f + erff(x * 0.70710678118654752440f));
    } else {
        const float cube = (x * x) * x;
        const float inner =
            0.79788456080286535588f * (x + 0.044715f * cube);
        return (0.5f * x) * (1.0f + tanhf(inner));
    }
}

__device__ __forceinline__ unsigned quantize(float value, float scale) {
    const unsigned bits = __float_as_uint(value * scale);
    const unsigned sign = (bits >> 28) & 8u;
    const unsigned exponent = (bits >> 23) & 255u;
    unsigned mantissa = bits & 0x7fffffu;

    if (exponent < 127u) {
        const unsigned shift = 126u - exponent;
        mantissa = shift >= 32u
            ? 0u
            : (0x400000u | (mantissa >> 1)) >> shift;
    }

    const unsigned e = exponent > 126u ? exponent - 126u : 0u;
    unsigned code = (((e << 2) | (mantissa >> 21)) + 1u) >> 1;
    code = code < 7u ? code : 7u;
    return sign | code;
}

template<typename scalar_t, int Activation>
__global__ void gated_mxfp4_kernel(
    const scalar_t* __restrict__ input,
    uint8_t* __restrict__ output,
    int64_t rows,
    int64_t d,
    int64_t blocks_per_row,
    int64_t stride_row,
    int64_t stride_col
) {
    const int lane = threadIdx.x & 31;
    const int64_t block =
        static_cast<int64_t>(blockIdx.x) * 8 + (threadIdx.x >> 5);
    const int64_t total_blocks = rows * blocks_per_row;
    if (block >= total_blocks)
        return;

    const int64_t row = block / blocks_per_row;
    const int64_t column_block = block - row * blocks_per_row;
    const int64_t column = column_block * 32 + lane;

    float value = 0.0f;
    if (column < d) {
        const int64_t offset = row * stride_row + column * stride_col;
        const float a = static_cast<float>(input[offset]);
        const float b = static_cast<float>(input[offset + d * stride_col]);
        value = activate<Activation>(a) * b;
    }

    float maximum = fabsf(value);
    #pragma unroll
    for (int offset = 16; offset; offset >>= 1) {
        const float other = __shfl_xor(maximum, offset, 32);
        maximum = (isnan(maximum) || isnan(other))
            ? __uint_as_float(0x7fc00000u)
            : fmaxf(maximum, other);
    }

    const unsigned rounded =
        (__float_as_uint(maximum) + 0x200000u) & 0xff800000u;
    const unsigned exponent = (rounded >> 23) & 255u;

    int unbiased;
    if (exponent == 255u) {
        unbiased = 127;
    } else {
        unbiased = static_cast<int>(exponent) - 129;
        unbiased = unbiased < -127 ? -127 : unbiased;
    }

    // Construct 2^(-unbiased) exactly, including its subnormal endpoint.
    const unsigned scale_bits = unbiased == 127
        ? 0x00400000u
        : static_cast<unsigned>(127 - unbiased) << 23;
    const float scale = __uint_as_float(scale_bits);
    const unsigned code = quantize(value, scale);
    const unsigned next_code = __shfl_down(code, 1, 32);

    const int64_t packed_columns = d / 2;
    const int64_t output_stride = packed_columns + blocks_per_row;
    const int64_t output_row = row * output_stride;

    if ((lane & 1) == 0 && column < d) {
        output[output_row + column / 2] =
            static_cast<uint8_t>(code | (next_code << 4));
    }
    if (lane == 0) {
        output[output_row + packed_columns + column_block] =
            static_cast<uint8_t>(unbiased + 127);
    }
}

torch::Tensor gated_mxfp4(torch::Tensor x, int64_t activation) {
    TORCH_CHECK(x.is_cuda(), "x must be on a CUDA/HIP device");
    TORCH_CHECK(x.dim() == 2, "x must be two-dimensional");
    TORCH_CHECK(x.size(1) % 4 == 0, "N must be a multiple of 4");
    TORCH_CHECK(
        x.scalar_type() == at::kFloat ||
        x.scalar_type() == at::kHalf ||
        x.scalar_type() == at::kBFloat16,
        "x must have float32, float16, or bfloat16 dtype");
    TORCH_CHECK(activation >= 0 && activation <= 2, "invalid activation");

    const c10::cuda::CUDAGuard guard(x.device());
    const int64_t rows = x.size(0);
    const int64_t d = x.size(1) / 2;
    const int64_t blocks_per_row = (d + 31) / 32;

    auto output = torch::empty(
        {rows, d / 2 + blocks_per_row},
        x.options().dtype(at::kByte));

    if (rows == 0 || d == 0)
        return output;

    const int64_t grid_size = (rows * blocks_per_row + 7) / 8;
    TORCH_CHECK(grid_size <= 2147483647LL, "input is too large");
    const dim3 grid(static_cast<unsigned>(grid_size));
    const dim3 threads(256);
    const auto stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "gated_mxfp4", [&] {
            const scalar_t* input = x.data_ptr<scalar_t>();
            uint8_t* result = output.data_ptr<uint8_t>();

            #define LAUNCH(A) \
                hipLaunchKernelGGL( \
                    (gated_mxfp4_kernel<scalar_t, A>), \
                    grid, threads, 0, stream, \
                    input, result, rows, d, blocks_per_row, \
                    x.stride(0), x.stride(1))

            if (activation == 0) {
                LAUNCH(0);
            } else if (activation == 1) {
                LAUNCH(1);
            } else {
                LAUNCH(2);
            }
            #undef LAUNCH
        });

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (_CPP_SRC + _HIP_SRC).encode("utf-8")
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=f"gated_mxfp4_hip_{digest}",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, activation: str = "silu"):
        super().__init__()
        assert activation in ("silu", "gelu", "gelu_tanh"), (
            "activation must be one of silu / gelu / gelu_tanh"
        )
        self.activation = activation

    def forward(self, x):
        return _get_extension().gated_mxfp4(
            x, {"silu": 0, "gelu": 1, "gelu_tanh": 2}[self.activation]
        )
```