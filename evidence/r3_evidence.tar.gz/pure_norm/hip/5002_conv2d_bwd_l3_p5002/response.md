```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_run(
    torch::Tensor dy, torch::Tensor weight, torch::Tensor x,
    bool wgrad, int sh, int sw, int ph, int pw, int dh, int dw);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &pyramid_run);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cstdint>

struct Shape {
    int n, c, h, w, k, r, s, oh, ow;
    int sh, sw, ph, pw, dh, dw;
};

template<bool WG>
__global__ __launch_bounds__(256)
void correlation(
    const float* __restrict__ dy,
    const float* __restrict__ weight,
    const float* __restrict__ x,
    float* __restrict__ out,
    Shape p, int columns, int reduction, int chunk)
{
    __shared__ float aa[16][17];
    __shared__ float bb[16][65];

    const int tid = threadIdx.x;
    const int row = tid >> 4;
    const int col = tid & 15;
    const int row_base = blockIdx.y * 16;
    const int col_base = blockIdx.x * 64;
    const int plane = blockIdx.z;

    const int begin = WG ? plane * chunk : 0;
    const int end = WG ? min(begin + chunk, reduction) : reduction;
    const int rows = WG ? p.k : p.c;
    float acc0 = 0.0f;
    float acc1 = 0.0f;
    float acc2 = 0.0f;
    float acc3 = 0.0f;

    for (int base = begin; base < end; base += 16) {
        const int ar = row_base + row;
        const int ak = base + col;
        float av = 0.0f;
        if (ar < rows && ak < end) {
            if constexpr (WG) {
                int batch = ak / (p.oh * p.ow);
                int spatial = ak % (p.oh * p.ow);
                av = dy[((int64_t)batch * p.k + ar) * p.oh * p.ow + spatial];
            } else {
                int oc = ak / (p.r * p.s);
                int rs = ak % (p.r * p.s);
                av = weight[((int64_t)oc * p.c + ar) * p.r * p.s + rs];
            }
        }
        aa[row][col] = av;

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int index = tid + j * 256;
            const int bk = base + index / 64;
            const int bc = col_base + index % 64;
            float bv = 0.0f;
            if (bk < end && bc < columns) {
                if constexpr (WG) {
                    int ic = bc / (p.r * p.s);
                    int rs = bc % (p.r * p.s);
                    int rr = rs / p.s;
                    int ss = rs % p.s;
                    int batch = bk / (p.oh * p.ow);
                    int spatial = bk % (p.oh * p.ow);
                    int ih = (spatial / p.ow) * p.sh - p.ph + rr * p.dh;
                    int iw = (spatial % p.ow) * p.sw - p.pw + ss * p.dw;
                    if ((unsigned)ih < (unsigned)p.h &&
                        (unsigned)iw < (unsigned)p.w)
                        bv = x[((int64_t)batch * p.c + ic) * p.h * p.w
                               + ih * p.w + iw];
                } else {
                    int oc = bk / (p.r * p.s);
                    int rs = bk % (p.r * p.s);
                    int hh = bc / p.w + p.ph - (rs / p.s) * p.dh;
                    int ww = bc % p.w + p.pw - (rs % p.s) * p.dw;
                    if (hh >= 0 && ww >= 0 &&
                        hh % p.sh == 0 && ww % p.sw == 0) {
                        int oh = hh / p.sh;
                        int ow = ww / p.sw;
                        if (oh < p.oh && ow < p.ow)
                            bv = dy[((int64_t)plane * p.k + oc) * p.oh * p.ow
                                    + oh * p.ow + ow];
                    }
                }
            }
            bb[index / 64][index % 64] = bv;
        }
        __syncthreads();

        #pragma unroll
        for (int q = 0; q < 16; ++q) {
            float a = aa[row][q];
            acc0 = fmaf(a, bb[q][col], acc0);
            acc1 = fmaf(a, bb[q][col + 16], acc1);
            acc2 = fmaf(a, bb[q][col + 32], acc2);
            acc3 = fmaf(a, bb[q][col + 48], acc3);
        }
        __syncthreads();
    }

    int rr = row_base + row;
    if (rr < rows) {
        int64_t offset = ((int64_t)plane * rows + rr) * columns;
        if (col_base + col < columns)
            out[offset + col_base + col] = acc0;
        if (col_base + col + 16 < columns)
            out[offset + col_base + col + 16] = acc1;
        if (col_base + col + 32 < columns)
            out[offset + col_base + col + 32] = acc2;
        if (col_base + col + 48 < columns)
            out[offset + col_base + col + 48] = acc3;
    }
}

__global__ void combine(
    const float* __restrict__ partial,
    float* __restrict__ out,
    int64_t size, int splits)
{
    int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= size) return;
    float sum = 0.0f;
    float correction = 0.0f;
    for (int j = 0; j < splits; ++j) {
        float value = partial[(int64_t)j * size + i] - correction;
        float next = sum + value;
        correction = (next - sum) - value;
        sum = next;
    }
    out[i] = sum;
}

torch::Tensor pyramid_run(
    torch::Tensor dy, torch::Tensor weight, torch::Tensor x,
    bool wgrad, int sh, int sw, int ph, int pw, int dh, int dw)
{
    TORCH_CHECK(x.is_cuda() && dy.is_cuda() && weight.is_cuda(),
                "Inputs must be accelerator tensors");
    TORCH_CHECK(x.scalar_type() == at::kFloat &&
                dy.scalar_type() == at::kFloat &&
                weight.scalar_type() == at::kFloat, "Expected float32 inputs");
    TORCH_CHECK(x.is_contiguous() && dy.is_contiguous() &&
                weight.is_contiguous(), "Expected contiguous inputs");
    TORCH_CHECK(x.device() == dy.device() && x.device() == weight.device(),
                "Inputs must share a device");
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = at::cuda::getCurrentCUDAStream();

    Shape p;
    p.n = x.size(0); p.c = x.size(1);
    p.h = x.size(2); p.w = x.size(3);
    p.k = weight.size(0); p.r = weight.size(2); p.s = weight.size(3);
    p.oh = dy.size(2); p.ow = dy.size(3);
    p.sh = sh; p.sw = sw; p.ph = ph; p.pw = pw; p.dh = dh; p.dw = dw;

    if (!wgrad) {
        auto out = torch::empty(x.sizes(), x.options());
        int columns = p.h * p.w;
        int reduction = p.k * p.r * p.s;
        dim3 grid((columns + 63) / 64, (p.c + 15) / 16, p.n);
        correlation<false><<<grid, 256, 0, stream>>>(
            dy.data_ptr<float>(), weight.data_ptr<float>(), x.data_ptr<float>(),
            out.data_ptr<float>(), p, columns, reduction, reduction);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        return out;
    }

    auto out = torch::empty(weight.sizes(), weight.options());
    int columns = p.c * p.r * p.s;
    int reduction = p.n * p.oh * p.ow;
    int chunk = 512;
    int splits = (reduction + chunk - 1) / chunk;
    // Bound temporary storage and the third grid dimension.
    int64_t size = (int64_t)p.k * columns;
    int max_splits = (int)std::max<int64_t>(
        1, std::min<int64_t>(4096, (64LL * 1024 * 1024) / (4 * size)));
    if (splits > max_splits) {
        chunk = ((reduction + max_splits - 1) / max_splits + 15) / 16 * 16;
        splits = (reduction + chunk - 1) / chunk;
    }

    auto partial = splits == 1
        ? out
        : torch::empty({(int64_t)splits, size}, out.options());

    dim3 grid((columns + 63) / 64, (p.k + 15) / 16, splits);
    correlation<true><<<grid, 256, 0, stream>>>(
        dy.data_ptr<float>(), weight.data_ptr<float>(), x.data_ptr<float>(),
        partial.data_ptr<float>(), p, columns, reduction, chunk);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    if (splits > 1) {
        combine<<<(size + 255) / 256, 256, 0, stream>>>(
            partial.data_ptr<float>(), out.data_ptr<float>(), size, splits);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode("utf-8")
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=f"pyramid_correlation_{digest}",
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3", "-std=c++17"],
            extra_cuda_cflags=["-O3", "-std=c++17"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1, pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)

    def forward(self, dy, weight, x):
        return _get_extension().run(
            dy, weight, x, self.variant == "wgrad",
            self.stride_h, self.stride_w,
            self.pad_h, self.pad_w,
            self.dil_h, self.dil_w,
        )
```