import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                        torch::Tensor lens, torch::Tensor causal, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("attention", &attention);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <hip/hip_runtime.h>
#include <cmath>

template<class T, int D>
__global__ void attend(const T* __restrict__ q,
                       const T* __restrict__ k,
                       const T* __restrict__ v,
                       const int* lens, const int* causal,
                       float* partial, float* stats,
                       int H, int QL, int S, float scale) {
    const int row = blockIdx.x;
    const int split = blockIdx.y;
    const int t = threadIdx.x;
    const int lane = t & 31;
    const int warp = t >> 5;
    const int h = row % H;
    const int qi = row / H;
    const int b = qi / QL;
    __shared__ int start, lo, hi;
    __shared__ float scores[64];
    __shared__ float weights[64];
    __shared__ float old_factor, denominator, maximum;
    if (t == 0) {
        int off = 0;
        for (int i = 0; i < b; ++i) off += lens[i];
        int n = lens[b];
        if (*causal) n = min(n, qi % QL + 1);
        int chunk = (n + S - 1) / S;
        start = off;
        lo = min(split * chunk, n);
        hi = min((split + 1) * chunk, n);
        maximum = -INFINITY;
        denominator = 0.f;
    }
    __syncthreads();

    float qr[(D + 31) / 32];
    #pragma unroll
    for (int z = 0; z < (D + 31) / 32; ++z) {
        int d = lane + z * 32;
        qr[z] = d < D ? float(q[(long long)row * D + d]) : 0.f;
    }
    float acc = 0.f;
    for (int base = lo; base < hi; base += 64) {
        int count = min(64, hi - base);
        #pragma unroll
        for (int j = warp; j < 64; j += 8) {
            float dot = 0.f;
            if (j < count) {
                long long offset = ((long long)(start + base + j) * H + h) * D;
                #pragma unroll
                for (int z = 0; z < (D + 31) / 32; ++z) {
                    int d = lane + z * 32;
                    if (d < D) dot += qr[z] * float(k[offset + d]);
                }
            }
            #pragma unroll
            for (int delta = 16; delta; delta >>= 1)
                dot += __shfl_down(dot, delta, 32);
            if (lane == 0) scores[j] = j < count ? dot * scale : -INFINITY;
        }
        __syncthreads();
        if (t == 0) {
            float m = maximum;
            for (int j = 0; j < count; ++j) m = fmaxf(m, scores[j]);
            old_factor = maximum == -INFINITY ? 0.f : expf(maximum - m);
            maximum = m;
        }
        __syncthreads();
        if (t < 64)
            weights[t] = t < count ? expf(scores[t] - maximum) : 0.f;
        __syncthreads();
        if (t == 0) {
            float sum = 0.f;
            for (int j = 0; j < count; ++j) sum += weights[j];
            denominator = denominator * old_factor + sum;
        }
        if (t < D) {
            acc *= old_factor;
            for (int j = 0; j < count; ++j) {
                long long offset = ((long long)(start + base + j) * H + h) * D + t;
                acc += weights[j] * float(v[offset]);
            }
        }
        __syncthreads();
    }
    if (t < D)
        partial[((long long)row * S + split) * D + t] = acc;
    if (t == 0) {
        stats[((long long)row * S + split) * 2] = maximum;
        stats[((long long)row * S + split) * 2 + 1] = denominator;
    }
}

template<class T>
__global__ void finish(const float* partial, const float* stats, T* out,
                       int D, int S, long long n) {
    long long idx = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n) return;
    long long row = idx / D;
    int d = idx % D;
    float m = -INFINITY;
    for (int s = 0; s < S; ++s)
        m = fmaxf(m, stats[(row * S + s) * 2]);
    float den = 0.f, val = 0.f;
    for (int s = 0; s < S; ++s) {
        float l = stats[(row * S + s) * 2 + 1];
        float w = l > 0.f ? expf(stats[(row * S + s) * 2] - m) : 0.f;
        den += w * l;
        val += w * partial[(row * S + s) * D + d];
    }
    out[idx] = T(val / den);
}

torch::Tensor attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                        torch::Tensor lens, torch::Tensor causal, double scale) {
    c10::cuda::CUDAGuard guard(q.device());
    int D = q.size(2), H = q.size(1);
    int QL = q.size(0) / lens.numel();
    int rows = q.size(0) * H;
    int S = QL <= 4 ? 16 : 1;
    auto out = torch::empty_like(q);
    auto partial = torch::empty({rows, S, D}, q.options().dtype(torch::kFloat32));
    auto stats = torch::empty({rows, S, 2}, q.options().dtype(torch::kFloat32));
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                   q.scalar_type(), "ragged_attention", [&] {
        #define LAUNCH(DIM) \
            attend<scalar_t, DIM><<<dim3(rows,S),256,0,stream>>>( \
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(), \
                lens.data_ptr<int>(), causal.data_ptr<int>(), partial.data_ptr<float>(), \
                stats.data_ptr<float>(), H, QL, S, float(scale))
        switch (D) {
            case 16: LAUNCH(16); break;
            case 32: LAUNCH(32); break;
            case 64: LAUNCH(64); break;
            case 128: LAUNCH(128); break;
            case 256: LAUNCH(256); break;
            default: TORCH_CHECK(false, "Unsupported head dimension");
        }
        #undef LAUNCH
        finish<scalar_t><<<(out.numel()+255)/256,256,0,stream>>>(
            partial.data_ptr<float>(), stats.data_ptr<float>(),
            out.data_ptr<scalar_t>(), D, S, out.numel());
    });
    return out;
}
"""

_extension = None


def _get_extension():
    global _extension
    if _extension is None:
        name = "ragged_attention_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _extension = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)

    def forward(self, q, k, v, kv_lens, causal):
        kv_lens = kv_lens.to(device=q.device, dtype=torch.int32).contiguous()
        if isinstance(causal, torch.Tensor):
            causal = causal.to(device=q.device, dtype=torch.int32).contiguous()
        else:
            causal = torch.tensor(causal, device=q.device, dtype=torch.int32)
        return _get_extension().attention(
            q.contiguous(), k.contiguous(), v.contiguous(),
            kv_lens, causal, self.sm_scale
        )
