import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_attention(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor kc, torch::Tensor vc, torch::Tensor bt,
    torch::Tensor starts, torch::Tensor lengths, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention", &paged_attention);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <stdint.h>
#include <cmath>

struct FloatView {
    const float* p;
    int64_t s[5];
};

struct IndexView {
    const void* p;
    int64_t s0, s1;
    bool wide;
    __device__ __forceinline__ int get(int i) const {
        int64_t off = (int64_t)i * s0;
        return wide ? (int)((const int64_t*)p)[off]
                    : ((const int32_t*)p)[off];
    }
    __device__ __forceinline__ int get(int i, int j) const {
        int64_t off = (int64_t)i * s0 + (int64_t)j * s1;
        return wide ? (int)((const int64_t*)p)[off]
                    : ((const int32_t*)p)[off];
    }
};

constexpr int THREADS = 128;
constexpr int CHUNK = 256;

__device__ __forceinline__ float reduce_max(float x, float* scratch) {
    int t = threadIdx.x;
    scratch[t] = x;
    __syncthreads();
    for (int step = THREADS / 2; step; step >>= 1) {
        if (t < step) scratch[t] = fmaxf(scratch[t], scratch[t + step]);
        __syncthreads();
    }
    return scratch[0];
}

__device__ __forceinline__ float reduce_sum(float x, float* scratch) {
    int t = threadIdx.x;
    scratch[t] = x;
    __syncthreads();
    for (int step = THREADS / 2; step; step >>= 1) {
        if (t < step) scratch[t] += scratch[t + step];
        __syncthreads();
    }
    return scratch[0];
}

__global__ void partial_attention(
    FloatView q, FloatView k, FloatView v, FloatView kc, FloatView vc,
    IndexView bt, IndexView starts, IndexView lengths,
    float* partial, int H, int HK, int D, int BS, int X,
    int N, int splits, float scale)
{
    const int t = threadIdx.x;
    const int token = blockIdx.x;
    const int h = blockIdx.y;
    const int split = blockIdx.z;
    int lo = 0, hi = N;
    while (lo + 1 < hi) {
        int mid = (lo + hi) >> 1;
        if (starts.get(mid) <= token) lo = mid;
        else hi = mid;
    }
    const int b = lo;
    const int first = starts.get(b);
    const int qlen = starts.get(b + 1) - first;
    const int ctx = lengths.get(b) - qlen;
    const int end = ctx + token - first + 1;
    const int begin = split * CHUNK;
    const int count = min(CHUNK, max(0, end - begin));
    const int kh = h / (H / HK);
    float* dst = partial +
        (((int64_t)token * H + h) * splits + split) * (D + 2);

    if (!count) {
        if (t == 0) {
            dst[D] = -INFINITY;
            dst[D + 1] = 0.0f;
        }
        for (int d = t; d < D; d += THREADS) dst[d] = 0.0f;
        return;
    }

    __shared__ float logits[CHUNK];
    __shared__ float scratch[THREADS];
    __shared__ int physical[CHUNK];
    __shared__ float query[512];

    for (int d = t; d < D; d += THREADS)
        query[d] = q.p[(int64_t)token*q.s[0] + h*q.s[1] + d*q.s[2]] * scale;
    for (int i = t; i < count; i += THREADS) {
        int pos = begin + i;
        physical[i] = pos < ctx ? bt.get(b, pos / BS) : -1;
    }
    __syncthreads();

    const int lane = t & 7;
    const int group = t >> 3;
    for (int i = group; i < CHUNK; i += THREADS / 8) {
        float dot = 0.0f;
        if (i < count) {
            int pos = begin + i;
            int pb = physical[i];
            for (int d = lane; d < D; d += 8) {
                float kval;
                if (pos < ctx) {
                    kval = kc.p[(int64_t)pb*kc.s[0] + kh*kc.s[1]
                        + (d/X)*kc.s[2] + (pos%BS)*kc.s[3] + (d%X)*kc.s[4]];
                } else {
                    kval = k.p[(int64_t)(first + pos - ctx)*k.s[0]
                        + kh*k.s[1] + d*k.s[2]];
                }
                dot = fmaf(query[d], kval, dot);
            }
        }
        dot += __shfl_down(dot, 4, 8);
        dot += __shfl_down(dot, 2, 8);
        dot += __shfl_down(dot, 1, 8);
        if (lane == 0) logits[i] = i < count ? dot : -INFINITY;
    }
    __syncthreads();

    float local_max = -INFINITY;
    for (int i = t; i < count; i += THREADS)
        local_max = fmaxf(local_max, logits[i]);
    float m = reduce_max(local_max, scratch);
    // Ensure every thread has consumed the reduction before reusing scratch.
    __syncthreads();
    float local_sum = 0.0f;
    for (int i = t; i < count; i += THREADS) {
        float p = expf(logits[i] - m);
        logits[i] = p;
        local_sum += p;
    }
    float z = reduce_sum(local_sum, scratch);
    __syncthreads();
    if (t == 0) {
        dst[D] = m;
        dst[D + 1] = z;
    }
    for (int d = t; d < D; d += THREADS) {
        float acc = 0.0f;
        for (int i = 0; i < count; ++i) {
            int pos = begin + i;
            float val;
            if (pos < ctx) {
                val = vc.p[(int64_t)physical[i]*vc.s[0] + kh*vc.s[1]
                    + d*vc.s[2] + (pos%BS)*vc.s[3]];
            } else {
                val = v.p[(int64_t)(first + pos - ctx)*v.s[0]
                    + kh*v.s[1] + d*v.s[2]];
            }
            acc = fmaf(logits[i], val, acc);
        }
        dst[d] = acc;
    }
}

__global__ void combine_attention(
    const float* partial, float* out, int D, int splits)
{
    int row = blockIdx.x;
    const float* base = partial + (int64_t)row * splits * (D + 2);
    extern __shared__ float weights[];
    __shared__ float denominator;
    if (threadIdx.x == 0) {
        float m = -INFINITY;
        for (int s = 0; s < splits; ++s)
            m = fmaxf(m, base[(int64_t)s*(D+2) + D]);
        float z = 0.0f;
        for (int s = 0; s < splits; ++s) {
            const float* p = base + (int64_t)s*(D+2);
            float w = p[D+1] > 0.0f ? expf(p[D] - m) : 0.0f;
            weights[s] = w;
            z = fmaf(w, p[D+1], z);
        }
        denominator = z;
    }
    __syncthreads();
    for (int d = threadIdx.x; d < D; d += blockDim.x) {
        float acc = 0.0f;
        for (int s = 0; s < splits; ++s)
            acc = fmaf(weights[s], base[(int64_t)s*(D+2) + d], acc);
        out[(int64_t)row*D + d] = acc / denominator;
    }
}

static FloatView fv(const torch::Tensor& x) {
    TORCH_CHECK(x.is_cuda() && x.scalar_type() == torch::kFloat32,
                "Attention data must be device fp32 tensors");
    FloatView r{};
    r.p = x.data_ptr<float>();
    for (int i = 0; i < x.dim(); ++i) r.s[i] = x.stride(i);
    return r;
}

static IndexView iv(const torch::Tensor& x) {
    TORCH_CHECK(x.is_cuda(), "Index tensors must reside on the device");
    TORCH_CHECK(x.scalar_type() == torch::kInt32 ||
                x.scalar_type() == torch::kInt64, "Expected int32 or int64 indices");
    return {x.data_ptr(), x.stride(0), x.dim() > 1 ? x.stride(1) : 0,
            x.scalar_type() == torch::kInt64};
}

torch::Tensor paged_attention(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor kc, torch::Tensor vc, torch::Tensor bt,
    torch::Tensor starts, torch::Tensor lengths, double scale)
{
    c10::cuda::CUDAGuard guard(q.device());
    const int T = q.size(0), H = q.size(1), D = q.size(2);
    const int HK = kc.size(1), BS = vc.size(3), X = kc.size(4);
    TORCH_CHECK(D <= 512 && D > 0 && H % HK == 0,
                "Unsupported attention dimensions");
    auto out = torch::empty({T, H, D}, q.options());
    if (T == 0) return out;
    int splits = ((int64_t)bt.size(1)*BS + CHUNK - 1) / CHUNK;
    TORCH_CHECK(splits > 0, "Empty block table");
    auto tmp = torch::empty({T, H, splits, D+2}, q.options());
    auto stream = at::cuda::getCurrentCUDAStream();
    hipLaunchKernelGGL(partial_attention, dim3(T,H,splits), dim3(THREADS),
        0, stream, fv(q), fv(k), fv(v), fv(kc), fv(vc),
        iv(bt), iv(starts), iv(lengths), tmp.data_ptr<float>(),
        H, HK, D, BS, X, (int)lengths.numel(), splits, (float)scale);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    hipLaunchKernelGGL(combine_attention, dim3(T*H), dim3(THREADS),
        splits*sizeof(float), stream, tmp.data_ptr<float>(),
        out.data_ptr<float>(), D, splits);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "paged_attention_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key, value, key_cache, value_cache,
                block_tables, query_start_loc, seq_lens):
        return _get_extension().paged_attention(
            query, key, value, key_cache, value_cache,
            block_tables, query_start_loc, seq_lens, self.scale,
        )
