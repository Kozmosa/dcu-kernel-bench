import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor qs, torch::Tensor ks, torch::Tensor mask, bool nhd);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &attention_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <hip/hip_fp16.h>
#include <stdint.h>
#include <cmath>

struct View {
    const void* ptr;
    int type;
    int64_t s0, s1, s2, s3;
};

static View view(const torch::Tensor& x) {
    View a;
    a.ptr = x.data_ptr();
    switch (x.scalar_type()) {
        case at::kFloat: a.type = 0; break;
        case at::kHalf: a.type = 1; break;
        case at::kChar: a.type = 2; break;
        case at::kBool: a.type = 3; break;
        default: TORCH_CHECK(false, "Unsupported input dtype");
    }
    a.s0 = x.dim() > 0 ? x.stride(0) : 0;
    a.s1 = x.dim() > 1 ? x.stride(1) : 0;
    a.s2 = x.dim() > 2 ? x.stride(2) : 0;
    a.s3 = x.dim() > 3 ? x.stride(3) : 0;
    return a;
}

__device__ __forceinline__ float read_value(View a, int64_t i) {
    if (a.type == 0) return ((const float*)a.ptr)[i];
    if (a.type == 1) return __half2float(((const __half*)a.ptr)[i]);
    if (a.type == 2) return (float)((const int8_t*)a.ptr)[i];
    return ((const bool*)a.ptr)[i] ? 1.0f : 0.0f;
}

static View logical_view(const torch::Tensor& x, bool nhd) {
    View a = view(x);
    if (nhd) {
        int64_t t = a.s1;
        a.s1 = a.s2;
        a.s2 = t;
    }
    return a;
}

__global__ void qk_kernel(
    View q, View k, View qs, View ks, View mask, float* p,
    int H, int HK, int M, int N, int D)
{
    __shared__ float qa[16][17];
    __shared__ float ka[16][17];

    int x = threadIdx.x, y = threadIdx.y;
    int i = blockIdx.y * 16 + y;
    int j = blockIdx.x * 16 + x;
    int bh = blockIdx.z, b = bh / H, h = bh % H;
    int kh = h / (H / HK);
    int64_t qb = b*q.s0 + h*q.s1;
    int64_t kb = b*k.s0 + kh*k.s1;
    float sum = 0.0f;

    for (int d = 0; d < D; d += 16) {
        qa[y][x] = i < M ? read_value(q, qb + i*q.s2 + (d+x)*q.s3) : 0.0f;
        int kj = blockIdx.x*16 + y;
        ka[y][x] = kj < N ? read_value(k, kb + kj*k.s2 + (d+x)*k.s3) : 0.0f;
        __syncthreads();
        #pragma unroll
        for (int t = 0; t < 16; ++t)
            sum = fmaf(qa[y][t], ka[x][t], sum);
        __syncthreads();
    }
    if (i < M && j < N) {
        float a = read_value(qs, b*qs.s0 + h*qs.s1 + (i/128)*qs.s2);
        float c = read_value(ks, b*ks.s0 + kh*ks.s1 + (j/64)*ks.s2);
        float z = ((sum * a) * c) * 0.6931471805599453f;
        if (read_value(mask, i*mask.s0 + j*mask.s1) == 0.0f)
            z = -INFINITY;
        p[((int64_t)bh*M+i)*N+j] = z;
    }
}

__global__ void softmax_kernel(float* p, int N) {
    __shared__ float red[256];
    int t = threadIdx.x;
    float* row = p + (int64_t)blockIdx.x*N;
    float mx = -INFINITY;
    for (int j = t; j < N; j += 256) mx = fmaxf(mx, row[j]);
    red[t] = mx;
    __syncthreads();
    for (int s = 128; s; s >>= 1) {
        if (t < s) red[t] = fmaxf(red[t], red[t+s]);
        __syncthreads();
    }
    mx = red[0];
    float total = 0.0f;
    for (int j = t; j < N; j += 256) {
        float e = expf(row[j] - mx);
        row[j] = e;
        total += e;
    }
    red[t] = total;
    __syncthreads();
    for (int s = 128; s; s >>= 1) {
        if (t < s) red[t] += red[t+s];
        __syncthreads();
    }
    float inv = 1.0f/red[0];
    for (int j = t; j < N; j += 256) row[j] *= inv;
}

__global__ void pv_kernel(
    const float* p, View v, __half* out,
    int H, int HK, int M, int N, int D, bool nhd)
{
    __shared__ float pa[16][17];
    __shared__ float va[16][17];
    int x = threadIdx.x, y = threadIdx.y;
    int i = blockIdx.y*16+y;
    int d = blockIdx.x*16+x;
    int bh = blockIdx.z, b = bh/H, h = bh%H;
    int kh = h/(H/HK);
    int64_t vb = b*v.s0 + kh*v.s1;
    float acc = 0.0f;
    for (int j = 0; j < N; j += 16) {
        pa[y][x] = i < M && j+x < N
            ? p[((int64_t)bh*M+i)*N+j+x] : 0.0f;
        float val = j+y < N
            ? read_value(v, vb+(j+y)*v.s2+d*v.s3) : 0.0f;
        // The reference restores V to fp16 before performing attention.
        va[y][x] = __half2float(__float2half_rn(val));
        __syncthreads();
        #pragma unroll
        for (int t = 0; t < 16; ++t)
            acc = fmaf(pa[y][t], va[t][x], acc);
        __syncthreads();
    }
    if (i < M) {
        int64_t oi = nhd
            ? (((int64_t)b*M+i)*H+h)*D+d
            : ((int64_t)bh*M+i)*D+d;
        out[oi] = __float2half_rn(acc);
    }
}

torch::Tensor attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor qs, torch::Tensor ks, torch::Tensor mask, bool nhd)
{
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda() &&
                qs.is_cuda() && ks.is_cuda() && mask.is_cuda(),
                "All inputs must be on the accelerator");
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim() == 4 && k.dim() == 4 && v.dim() == 4,
                "Q, K and V must have four dimensions");
    int B = q.size(0);
    int H = q.size(nhd ? 2 : 1);
    int M = q.size(nhd ? 1 : 2);
    int HK = k.size(nhd ? 2 : 1);
    int N = k.size(nhd ? 1 : 2);
    int D = q.size(3);
    TORCH_CHECK(HK > 0 && H % HK == 0 && (D == 64 || D == 128),
                "Invalid head configuration");
    TORCH_CHECK(M > 0 && N > 0, "Sequence lengths must be positive");
    auto out = torch::empty(q.sizes(), q.options().dtype(at::kHalf));
    auto p = torch::empty({B, H, M, N}, q.options().dtype(at::kFloat));
    if (B == 0) return out;
    auto stream = at::cuda::getCurrentCUDAStream();
    dim3 threads(16,16);
    qk_kernel<<<dim3((N+15)/16,(M+15)/16,B*H), threads, 0, stream>>>(
        logical_view(q,nhd), logical_view(k,nhd), view(qs), view(ks),
        view(mask), p.data_ptr<float>(), H, HK, M, N, D);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    softmax_kernel<<<B*H*M,256,0,stream>>>(p.data_ptr<float>(),N);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    pv_kernel<<<dim3(D/16,(M+15)/16,B*H),threads,0,stream>>>(
        p.data_ptr<float>(), logical_view(v,nhd),
        reinterpret_cast<__half*>(out.data_ptr<at::Half>()),
        H,HK,M,N,D,nhd);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "hygon_attention_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, tensor_layout="HND"):
        super().__init__()
        assert tensor_layout in ("HND", "NHD"), \
            "tensor_layout only supports HND / NHD"
        self.tensor_layout = tensor_layout

    def forward(self, q_int8, k_int8, v, q_scale, k_scale, attn_mask):
        return _get_extension().forward(
            q_int8, k_int8, v, q_scale, k_scale, attn_mask,
            self.tensor_layout == "NHD",
        )
