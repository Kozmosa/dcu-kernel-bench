import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_attention(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor tables, torch::Tensor cumulative,
    int64_t page_size, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention", &paged_attention);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cmath>
#include <cstdint>

struct Strides {
    int64_t h, r, d;
};

__device__ __forceinline__ int64_t index_value(
    const void* p, int64_t i, bool wide) {
    return wide ? static_cast<const int64_t*>(p)[i]
                : static_cast<const int32_t*>(p)[i];
}

template<class T, int D>
__global__ void attention_parts(
    const T* __restrict__ q,
    const T* __restrict__ k,
    const T* __restrict__ v,
    const void* tables,
    const void* cumulative,
    float* __restrict__ partial,
    Strides qs, Strides ks, Strides vs,
    int64_t th, int64_t tr, int64_t cr,
    bool table_wide, bool cumulative_wide,
    int M, int queries_per_request, int splits, int page_size,
    float scale)
{
    constexpr int W = D < 64 ? D : 64;
    constexpr int ROWS = 256 / W;
    constexpr int GROUPS = 256 / D;

    const int tid = threadIdx.x;
    const int query = blockIdx.x;
    const int head = blockIdx.y;
    const int split = blockIdx.z;
    const int request = query / queries_per_request;

    const int64_t begin = request == 0 ? 0 :
        index_value(cumulative, (request - 1) * cr, cumulative_wide);
    const int64_t end =
        index_value(cumulative, request * cr, cumulative_wide);
    const int64_t count = end - begin;
    const int64_t per_split = (count + splits - 1) / splits;
    const int64_t first = begin + split * per_split;
    const int64_t last = first + per_split < end ? first + per_split : end;

    __shared__ float query_data[D];
    __shared__ float logits[64];
    __shared__ float weights[64];
    __shared__ float state[4];
    __shared__ float reductions[256];

    if (tid < D)
        query_data[tid] = float(q[int64_t(head) * qs.h +
                                  int64_t(query) * qs.r + tid * qs.d]);
    if (tid == 0) {
        state[0] = -INFINITY;
        state[1] = 0.0f;
    }
    __syncthreads();

    const int dim = tid % D;
    const int group = tid / D;
    float accumulator = 0.0f;

    for (int64_t block = first; block < last; ++block) {
        const int64_t physical =
            index_value(tables, int64_t(head) * th + block * tr, table_wide);
        for (int tile = 0; tile < page_size; tile += 64) {
            const int valid = min(64, page_size - tile);
            const int lane = tid % W;
            const int row_group = tid / W;

            #pragma unroll
            for (int r = 0; r < 64 / ROWS; ++r) {
                const int row = r * ROWS + row_group;
                float dot = 0.0f;
                if (row < valid) {
                    const int64_t key_base = int64_t(head) * ks.h +
                        (physical * page_size + tile + row) * ks.r;
                    #pragma unroll
                    for (int d = lane; d < D; d += W)
                        dot = fmaf(query_data[d],
                                   float(k[key_base + d * ks.d]), dot);
                }
                #pragma unroll
                for (int offset = W / 2; offset > 0; offset >>= 1)
                    dot += __shfl_down(dot, offset, W);
                if (lane == 0)
                    logits[row] = row < valid ? dot * scale : -INFINITY;
            }
            __syncthreads();

            if (tid < 64) {
                float maximum = logits[tid];
                #pragma unroll
                for (int offset = 32; offset > 0; offset >>= 1)
                    maximum = fmaxf(maximum, __shfl_xor(maximum, offset, 64));
                const float new_maximum = fmaxf(state[0], maximum);
                const float alpha = expf(state[0] - new_maximum);
                const float weight = tid < valid ?
                    expf(logits[tid] - new_maximum) : 0.0f;
                weights[tid] = weight;
                float denominator = weight;
                #pragma unroll
                for (int offset = 32; offset > 0; offset >>= 1)
                    denominator += __shfl_xor(denominator, offset, 64);
                if (tid == 0) {
                    state[0] = new_maximum;
                    state[1] = state[1] * alpha + denominator;
                    state[2] = alpha;
                }
            }
            __syncthreads();

            accumulator *= state[2];
            for (int row = group; row < valid; row += GROUPS) {
                const int64_t value_offset = int64_t(head) * vs.h +
                    (physical * page_size + tile + row) * vs.r + dim * vs.d;
                accumulator = fmaf(weights[row], float(v[value_offset]),
                                   accumulator);
            }
            __syncthreads();
        }
    }

    reductions[tid] = accumulator;
    __syncthreads();
    const int64_t output_base =
        ((int64_t(head) * M + query) * splits + split) * (D + 2);
    if (tid < D) {
        float result = 0.0f;
        #pragma unroll
        for (int g = 0; g < GROUPS; ++g)
            result += reductions[g * D + tid];
        partial[output_base + tid] = result;
    }
    if (tid == 0) {
        partial[output_base + D] = state[0];
        partial[output_base + D + 1] = state[1];
    }
}

template<class T, int D>
__global__ void combine_parts(
    const float* __restrict__ partial, T* __restrict__ out,
    int splits, int64_t rows)
{
    const int64_t row = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
    if (row >= rows * D) return;
    const int d = row % D;
    const int64_t query = row / D;
    const float* p = partial + query * splits * (D + 2);
    float maximum = -INFINITY;
    for (int s = 0; s < splits; ++s)
        maximum = fmaxf(maximum, p[s * (D + 2) + D]);

    float numerator = 0.0f;
    float denominator = 0.0f;
    for (int s = 0; s < splits; ++s) {
        const float* a = p + s * (D + 2);
        const float factor = expf(a[D] - maximum);
        numerator = fmaf(factor, a[d], numerator);
        denominator = fmaf(factor, a[D + 1], denominator);
    }
    out[row] = T(numerator / denominator);
}

template<class T, int D>
void launch(
    const torch::Tensor& q, const torch::Tensor& k,
    const torch::Tensor& v, const torch::Tensor& tables,
    const torch::Tensor& cumulative, torch::Tensor& partial,
    torch::Tensor& out, int splits, int page_size, float scale,
    hipStream_t stream)
{
    const int heads = q.size(0);
    const int queries = q.size(1);
    const int nq = queries / cumulative.numel();
    Strides qs{q.stride(0), q.stride(1), q.stride(2)};
    Strides ks{k.stride(0), k.stride(1), k.stride(2)};
    Strides vs{v.stride(0), v.stride(1), v.stride(2)};

    attention_parts<T, D><<<dim3(queries, heads, splits), 256, 0, stream>>>(
        q.data_ptr<T>(), k.data_ptr<T>(), v.data_ptr<T>(),
        tables.data_ptr(), cumulative.data_ptr(), partial.data_ptr<float>(),
        qs, ks, vs, tables.stride(0), tables.stride(1),
        cumulative.stride(0), tables.scalar_type() == at::kLong,
        cumulative.scalar_type() == at::kLong,
        queries, nq, splits, page_size, scale);

    const int64_t rows = int64_t(heads) * queries;
    combine_parts<T, D><<<(rows * D + 255) / 256, 256, 0, stream>>>(
        partial.data_ptr<float>(), out.data_ptr<T>(), splits, rows);
}

torch::Tensor paged_attention(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor tables, torch::Tensor cumulative,
    int64_t page_size, double scale)
{
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda() &&
                tables.is_cuda() && cumulative.is_cuda(),
                "All inputs must be on the accelerator");
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim() == 3 && k.dim() == 3 && v.dim() == 3);
    TORCH_CHECK(tables.dim() == 2 && cumulative.dim() == 1);
    TORCH_CHECK(cumulative.numel() > 0 &&
                q.size(1) % cumulative.numel() == 0);
    TORCH_CHECK(page_size > 0);
    TORCH_CHECK(k.scalar_type() == q.scalar_type() &&
                v.scalar_type() == q.scalar_type());
    TORCH_CHECK(tables.scalar_type() == at::kInt ||
                tables.scalar_type() == at::kLong);
    TORCH_CHECK(cumulative.scalar_type() == at::kInt ||
                cumulative.scalar_type() == at::kLong);

    const int64_t average_blocks =
        (tables.size(1) + cumulative.numel() - 1) / cumulative.numel();
    const int splits = int(std::min<int64_t>(
        16, std::max<int64_t>(1, (average_blocks + 3) / 4)));
    const int D = q.size(2);
    auto out = torch::empty(q.sizes(), q.options());
    auto partial = torch::empty(
        {q.size(0), q.size(1), int64_t(splits), int64_t(D + 2)},
        q.options().dtype(torch::kFloat32));
    hipStream_t stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "paged_attention", [&] {
            switch (D) {
#define DISPATCH_D(N) \
                case N: launch<scalar_t, N>(q, k, v, tables, cumulative, \
                    partial, out, splits, int(page_size), float(scale), stream); break;
                DISPATCH_D(16)
                DISPATCH_D(32)
                DISPATCH_D(64)
                DISPATCH_D(128)
                DISPATCH_D(256)
#undef DISPATCH_D
                default: TORCH_CHECK(false, "Unsupported head size");
            }
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="paged_decode_hip_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, page_size: int = 64, sm_scale=0.5):
        super().__init__()
        self.head_size = int(head_size)
        self.page_size = int(page_size)
        self.sm_scale = float(sm_scale)

    def forward(self, q, k, v, kv_block_tables, batch_num_block_n):
        return _get_extension().paged_attention(
            q, k, v, kv_block_tables, batch_num_block_n,
            self.page_size, self.sm_scale,
        )
