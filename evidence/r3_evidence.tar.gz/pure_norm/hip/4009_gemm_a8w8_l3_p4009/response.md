```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>

void quant_gemm(
    torch::Tensor x, torch::Tensor w,
    torch::Tensor xs, torch::Tensor ws, torch::Tensor bias,
    torch::Tensor out, bool use_bias);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("quant_gemm", &quant_gemm);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template<typename Output, bool Bias>
__global__ __launch_bounds__(256)
void gemm_kernel(
    const float* __restrict__ x,
    const float* __restrict__ w,
    const float* __restrict__ xs,
    const float* __restrict__ ws,
    const float* __restrict__ bias,
    Output* __restrict__ out,
    int64_t M, int64_t N, int64_t K,
    int64_t x0, int64_t x1,
    int64_t w0, int64_t w1,
    int64_t xs0, int64_t ws1, int64_t bs1)
{
    constexpr int BM = 64;
    constexpr int BN = 64;
    constexpr int BK = 16;

    __shared__ float ax[BK][BM + 1];
    __shared__ float bw[BK][BN + 1];

    const int tid = threadIdx.x;
    const int tm = tid >> 4;
    const int tn = tid & 15;
    const int64_t row0 = int64_t(blockIdx.y) * BM;
    const int64_t col0 = int64_t(blockIdx.x) * BN;

    float acc[4][4] = {};

    for (int64_t kb = 0; kb < K; kb += BK) {
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            const int linear = tid + i * 256;
            const int row = linear / BK;
            const int k = linear % BK;
            const int64_t gk = kb + k;
            ax[k][row] =
                row0 + row < M && gk < K
                ? x[(row0 + row) * x0 + gk * x1] : 0.0f;
            bw[k][row] =
                col0 + row < N && gk < K
                ? w[(col0 + row) * w0 + gk * w1] : 0.0f;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < BK; ++k) {
            float av[4], bv[4];
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                av[i] = ax[k][tm + i * 16];
                bv[i] = bw[k][tn + i * 16];
            }
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                #pragma unroll
                for (int j = 0; j < 4; ++j) {
                    acc[i][j] = fmaf(av[i], bv[j], acc[i][j]);
                }
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const int64_t row = row0 + tm + i * 16;
        if (row < M) {
            const float sx = xs[row * xs0];
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                const int64_t col = col0 + tn + j * 16;
                if (col < N) {
                    const float scale = sx * ws[col * ws1];
                    float value = acc[i][j] * scale;
                    if (Bias) value = value + bias[col * bs1];
                    out[row * N + col] = Output(value);
                }
            }
        }
    }
}

template<typename Output>
void launch(
    const torch::Tensor& x, const torch::Tensor& w,
    const torch::Tensor& xs, const torch::Tensor& ws,
    const torch::Tensor& bias, torch::Tensor& out,
    bool use_bias, hipStream_t stream)
{
    const int64_t M = x.size(0);
    const int64_t N = w.size(0);
    const int64_t K = x.size(1);
    const dim3 grid((N + 63) / 64, (M + 63) / 64);
    const float* bp = use_bias ? bias.data_ptr<float>() : nullptr;
    const int64_t bs = use_bias ? bias.stride(1) : 0;
    if (use_bias) {
        gemm_kernel<Output, true><<<grid, 256, 0, stream>>>(
            x.data_ptr<float>(), w.data_ptr<float>(),
            xs.data_ptr<float>(), ws.data_ptr<float>(), bp,
            out.data_ptr<Output>(), M, N, K,
            x.stride(0), x.stride(1), w.stride(0), w.stride(1),
            xs.stride(0), ws.stride(1), bs);
    } else {
        gemm_kernel<Output, false><<<grid, 256, 0, stream>>>(
            x.data_ptr<float>(), w.data_ptr<float>(),
            xs.data_ptr<float>(), ws.data_ptr<float>(), bp,
            out.data_ptr<Output>(), M, N, K,
            x.stride(0), x.stride(1), w.stride(0), w.stride(1),
            xs.stride(0), ws.stride(1), bs);
    }
}

void quant_gemm(
    torch::Tensor x, torch::Tensor w,
    torch::Tensor xs, torch::Tensor ws, torch::Tensor bias,
    torch::Tensor out, bool use_bias)
{
    TORCH_CHECK(x.is_cuda() && w.is_cuda() && xs.is_cuda() &&
                ws.is_cuda() && out.is_cuda(), "Expected GPU tensors");
    TORCH_CHECK(x.scalar_type() == at::kFloat &&
                w.scalar_type() == at::kFloat &&
                xs.scalar_type() == at::kFloat &&
                ws.scalar_type() == at::kFloat,
                "Expected fp32 inputs containing quantization code words");
    TORCH_CHECK(x.dim() == 2 && w.dim() == 2 &&
                x.size(1) == w.size(1), "Invalid GEMM dimensions");
    TORCH_CHECK(!use_bias ||
                (bias.is_cuda() && bias.scalar_type() == at::kFloat),
                "Expected fp32 GPU bias");
    c10::cuda::CUDAGuard guard(x.device());
    if (out.numel() == 0) return;
    const auto stream = at::cuda::getCurrentCUDAStream(x.get_device());
    if (out.scalar_type() == at::kBFloat16) {
        launch<at::BFloat16>(x, w, xs, ws, bias, out, use_bias, stream);
    } else {
        launch<at::Half>(x, w, xs, ws, bias, out, use_bias, stream);
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="quant_gemm_hip_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, in_dtype="fp8e4m3", out_dtype="bfloat16", use_bias=True):
        super().__init__()
        self.in_dtype = {
            "fp8e4m3": torch.float8_e4m3fn,
            "fp8e5m2": torch.float8_e5m2,
            "int8": torch.int8,
        }[in_dtype]
        self.out_dtype = {
            "bfloat16": torch.bfloat16,
            "float16": torch.float16,
        }[out_dtype]
        self.use_bias = bool(use_bias)

    def forward(self, x, w, x_scale, w_scale, bias):
        M, K = x.shape
        N = w.shape[0]
        assert K == w.shape[1], "x and w must agree on the K dimension"
        out = torch.empty((M, N), device=x.device, dtype=self.out_dtype)
        _get_extension().quant_gemm(
            x, w, x_scale, w_scale, bias, out, self.use_bias
        )
        return out
```