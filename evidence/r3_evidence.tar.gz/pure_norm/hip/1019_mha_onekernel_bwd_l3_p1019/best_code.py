import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_backward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor o, torch::Tensor lse, torch::Tensor grad,
    double scale, bool causal);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("attention_backward", &attention_backward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/Dispatch.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

constexpr int TILE = 16;

template<typename T>
__global__ void delta_kernel(
    const T* __restrict__ o, const T* __restrict__ grad,
    float* __restrict__ delta, int M, int H, int D)
{
    int64_t row = blockIdx.x;
    int i = row % M;
    int h = (row / M) % H;
    int b = row / (int64_t(M) * H);
    int64_t base = ((int64_t(b) * M + i) * H + h) * D;
    float sum = 0.f;
    for (int d = threadIdx.x; d < D; d += blockDim.x)
        sum += float(o[base + d]) * float(grad[base + d]);
    __shared__ float buf[256];
    buf[threadIdx.x] = sum;
    __syncthreads();
    for (int step = 128; step; step >>= 1) {
        if (threadIdx.x < step)
            buf[threadIdx.x] += buf[threadIdx.x + step];
        __syncthreads();
    }
    if (threadIdx.x == 0)
        delta[row] = buf[0];
}

template<typename T>
__global__ void probability_kernel(
    const T* __restrict__ q, const T* __restrict__ k,
    const T* __restrict__ v, const T* __restrict__ grad,
    const float* __restrict__ lse, const float* __restrict__ delta,
    float* __restrict__ prob, float* __restrict__ ds,
    int M, int N, int H, int HK, int D, float scale, bool causal)
{
    const int x = threadIdx.x, y = threadIdx.y;
    const int i = blockIdx.y * TILE + y;
    const int j = blockIdx.x * TILE + x;
    const int h = blockIdx.z % H, b = blockIdx.z / H;
    const int hk = h / (H / HK);

    if (causal && int(blockIdx.x) * TILE >
                  int(blockIdx.y) * TILE + TILE - 1 + N - M) {
        if (i < M && j < N) {
            int64_t off = ((int64_t(b) * H + h) * M + i) * N + j;
            prob[off] = 0.f;
            ds[off] = 0.f;
        }
        return;
    }

    __shared__ float sq[TILE][TILE];
    __shared__ float sg[TILE][TILE];
    __shared__ float sk[TILE][TILE];
    __shared__ float sv[TILE][TILE];

    float score = 0.f, dp = 0.f;
    for (int d0 = 0; d0 < D; d0 += TILE) {
        int d = d0 + x;
        int kj = blockIdx.x * TILE + y;
        int64_t qo = ((int64_t(b) * M + i) * H + h) * D + d;
        int64_t ko = ((int64_t(b) * N + kj) * HK + hk) * D + d;
        sq[y][x] = i < M && d < D ? float(q[qo]) : 0.f;
        sg[y][x] = i < M && d < D ? float(grad[qo]) : 0.f;
        sk[y][x] = kj < N && d < D ? float(k[ko]) : 0.f;
        sv[y][x] = kj < N && d < D ? float(v[ko]) : 0.f;
        __syncthreads();
        #pragma unroll
        for (int t = 0; t < TILE; ++t) {
            score = fmaf(sq[y][t], sk[x][t], score);
            dp = fmaf(sg[y][t], sv[x][t], dp);
        }
        __syncthreads();
    }
    if (i < M && j < N) {
        int64_t row = (int64_t(b) * H + h) * M + i;
        int64_t off = row * N + j;
        float p = (!causal || j <= i + N - M)
                    ? expf(score * scale - lse[row]) : 0.f;
        prob[off] = p;
        ds[off] = p == 0.f ? 0.f : p * (dp - delta[row]);
    }
}

template<typename T>
__global__ void dq_kernel(
    const float* __restrict__ ds, const T* __restrict__ k,
    float* __restrict__ out, int M, int N, int H, int HK,
    int D, float scale, bool causal)
{
    const int x = threadIdx.x, y = threadIdx.y;
    const int d = blockIdx.x * TILE + x;
    const int i = blockIdx.y * TILE + y;
    const int h = blockIdx.z % H, b = blockIdx.z / H;
    const int hk = h / (H / HK);
    __shared__ float a[TILE][TILE];
    __shared__ float c[TILE][TILE];
    float sum = 0.f;
    int end = N;
    if (causal) {
        int limit = int(blockIdx.y) * TILE + TILE + N - M;
        end = limit < end ? limit : end;
    }
    for (int j0 = 0; j0 < end; j0 += TILE) {
        int j = j0 + x;
        a[y][x] = i < M && j < N
            ? ds[((int64_t(b) * H + h) * M + i) * N + j] : 0.f;
        j = j0 + y;
        c[y][x] = j < N && d < D
            ? float(k[((int64_t(b) * N + j) * HK + hk) * D + d]) : 0.f;
        __syncthreads();
        #pragma unroll
        for (int t = 0; t < TILE; ++t)
            sum = fmaf(a[y][t], c[t][x], sum);
        __syncthreads();
    }
    if (i < M && d < D) {
        int64_t off = ((int64_t(b) * M + i) * H + h) * D + d;
        out[off] = float(T(sum * scale));
    }
}

template<typename T>
__global__ void dkv_kernel(
    const float* __restrict__ prob, const float* __restrict__ ds,
    const T* __restrict__ q, const T* __restrict__ grad,
    float* __restrict__ out_k, float* __restrict__ out_v,
    int M, int N, int H, int HK, int D, float scale, bool causal)
{
    const int x = threadIdx.x, y = threadIdx.y;
    const int d = blockIdx.x * TILE + x;
    const int j = blockIdx.y * TILE + y;
    const int hk = blockIdx.z % HK, b = blockIdx.z / HK;
    const int group = H / HK;
    __shared__ float sp[TILE][TILE + 1];
    __shared__ float ss[TILE][TILE + 1];
    __shared__ float sq[TILE][TILE];
    __shared__ float sg[TILE][TILE];

    float total_k = 0.f, total_v = 0.f;
    int begin = 0;
    if (causal) {
        int first = int(blockIdx.y) * TILE + M - N;
        if (first > 0) begin = (first / TILE) * TILE;
    }
    for (int gh = 0; gh < group; ++gh) {
        int h = hk * group + gh;
        float ak = 0.f, av = 0.f;
        for (int i0 = begin; i0 < M; i0 += TILE) {
            // Coalesced loads from the score matrices, transposed in shared memory.
            int i = i0 + y;
            int jj = blockIdx.y * TILE + x;
            int64_t off = ((int64_t(b) * H + h) * M + i) * N + jj;
            sp[x][y] = i < M && jj < N ? prob[off] : 0.f;
            ss[x][y] = i < M && jj < N ? ds[off] : 0.f;
            int64_t qo = ((int64_t(b) * M + i) * H + h) * D + d;
            sq[y][x] = i < M && d < D ? float(q[qo]) : 0.f;
            sg[y][x] = i < M && d < D ? float(grad[qo]) : 0.f;
            __syncthreads();
            #pragma unroll
            for (int t = 0; t < TILE; ++t) {
                ak = fmaf(ss[y][t], sq[t][x], ak);
                av = fmaf(sp[y][t], sg[t][x], av);
            }
            __syncthreads();
        }
        total_k += ak * scale;
        total_v += av;
    }
    if (j < N && d < D) {
        int64_t off = ((int64_t(b) * N + j) * HK + hk) * D + d;
        out_k[off] = float(T(total_k));
        out_v[off] = float(T(total_v));
    }
}

torch::Tensor attention_backward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor o, torch::Tensor lse, torch::Tensor grad,
    double scale, bool causal)
{
    TORCH_CHECK(q.is_cuda(), "Inputs must be accelerator tensors");
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim() == 4 && k.dim() == 4, "Expected rank-four q and k");
    const int B = q.size(0), M = q.size(1), H = q.size(2), D = q.size(3);
    const int N = k.size(1), HK = k.size(2);
    TORCH_CHECK(HK > 0 && H % HK == 0, "Invalid head grouping");
    TORCH_CHECK(D >= 1 && D <= 256 && M > 0 && N > 0, "Invalid dimensions");
    TORCH_CHECK(k.size(0) == B && k.size(3) == D, "Invalid k shape");
    TORCH_CHECK(v.sizes() == k.sizes() && o.sizes() == q.sizes()
                && grad.sizes() == q.sizes(), "Invalid input shapes");
    TORCH_CHECK(lse.dim() == 3 && lse.size(0) == B &&
                lse.size(1) == H && lse.size(2) == M, "Invalid lse shape");
    TORCH_CHECK(k.scalar_type() == q.scalar_type() &&
                v.scalar_type() == q.scalar_type() &&
                o.scalar_type() == q.scalar_type() &&
                grad.scalar_type() == q.scalar_type(), "Input dtypes must match");
    TORCH_CHECK(lse.scalar_type() == at::kFloat, "lse must be float32");
    TORCH_CHECK(k.device() == q.device() && v.device() == q.device() &&
                o.device() == q.device() && grad.device() == q.device() &&
                lse.device() == q.device(), "Input devices must match");

    q = q.contiguous();
    k = k.contiguous();
    v = v.contiguous();
    o = o.contiguous();
    grad = grad.contiguous();
    lse = lse.contiguous();

    auto options = q.options().dtype(at::kFloat);
    const int64_t nq = int64_t(B) * M * H * D;
    const int64_t nk = int64_t(B) * N * HK * D;
    auto output = torch::empty({nq + 2 * nk}, options);
    if (B == 0) return output;
    auto delta = torch::empty({int64_t(B) * H * M}, options);
    auto prob = torch::empty({int64_t(B) * H * M * N}, options);
    auto ds = torch::empty_like(prob);
    auto stream = at::cuda::getCurrentCUDAStream();
    dim3 threads(TILE, TILE);

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "attention_backward_hip", [&] {
        delta_kernel<scalar_t><<<B * H * M, 256, 0, stream>>>(
            o.data_ptr<scalar_t>(), grad.data_ptr<scalar_t>(),
            delta.data_ptr<float>(), M, H, D);
        C10_CUDA_KERNEL_LAUNCH_CHECK();

        probability_kernel<scalar_t>
            <<<dim3((N + TILE - 1) / TILE, (M + TILE - 1) / TILE, B * H),
               threads, 0, stream>>>(
            q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(),
            v.data_ptr<scalar_t>(), grad.data_ptr<scalar_t>(),
            lse.data_ptr<float>(), delta.data_ptr<float>(),
            prob.data_ptr<float>(), ds.data_ptr<float>(),
            M, N, H, HK, D, float(scale), causal);
        C10_CUDA_KERNEL_LAUNCH_CHECK();

        dq_kernel<scalar_t>
            <<<dim3((D + TILE - 1) / TILE, (M + TILE - 1) / TILE, B * H),
               threads, 0, stream>>>(
            ds.data_ptr<float>(), k.data_ptr<scalar_t>(),
            output.data_ptr<float>(), M, N, H, HK, D, float(scale), causal);
        C10_CUDA_KERNEL_LAUNCH_CHECK();

        dkv_kernel<scalar_t>
            <<<dim3((D + TILE - 1) / TILE, (N + TILE - 1) / TILE, B * HK),
               threads, 0, stream>>>(
            prob.data_ptr<float>(), ds.data_ptr<float>(),
            q.data_ptr<scalar_t>(), grad.data_ptr<scalar_t>(),
            output.data_ptr<float>() + nq,
            output.data_ptr<float>() + nq + nk,
            M, N, H, HK, D, float(scale), causal);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    });
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "gqa_backward_hip_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, causal: int, scale=None):
        super().__init__()
        self.head_dim = int(head_dim)
        self.causal = bool(int(causal))
        self.sm_scale = (
            float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v, o, lse, do):
        return _get_extension().attention_backward(
            q, k, v, o, lse, do, self.sm_scale, self.causal
        )
