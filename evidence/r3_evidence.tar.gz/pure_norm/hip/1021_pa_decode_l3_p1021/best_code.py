import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_decode(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                           torch::Tensor tables, torch::Tensor lengths,
                           double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_decode", &paged_decode);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>
#include <cmath>

constexpr int TILE = 256;
constexpr int THREADS = 256;

struct Layout {
    int heads, kv_heads, dim, block_size, parts;
    int64_t q0, q1, q2;
    int64_t k0, k1, k2, k3;
    int64_t v0, v1, v2, v3;
    int64_t t0, t1, l0;
};

__device__ __forceinline__ float wave_sum(float x) {
    #pragma unroll
    for (int delta = 32; delta; delta >>= 1)
        x += __shfl_down(x, delta, 64);
    return x;
}

template <typename T, typename I, typename L>
__global__ void attention_parts(
    const T* __restrict__ q,
    const T* __restrict__ k,
    const T* __restrict__ v,
    const I* __restrict__ tables,
    const L* __restrict__ lengths,
    float* __restrict__ partial,
    float* __restrict__ statistics,
    Layout a, float scale)
{
    const int h = blockIdx.x;
    const int s = blockIdx.y;
    const int part = blockIdx.z;
    const int tid = threadIdx.x;
    const int lane = tid & 63;
    const int wave = tid >> 6;
    const int begin = part * TILE;
    const int length = static_cast<int>(lengths[s * a.l0]);
    const int count = min(TILE, max(0, length - begin));
    const int kh = h / (a.heads / a.kv_heads);
    const int64_t slot = ((int64_t)s * a.heads + h) * a.parts + part;

    if (count == 0) {
        if (tid == 0) {
            statistics[slot * 2] = -INFINITY;
            statistics[slot * 2 + 1] = 0.0f;
        }
        return;
    }

    __shared__ float logits[TILE];
    __shared__ float reduction[THREADS];
    __shared__ float maximum;
    __shared__ float denominator;

    const T* query = q + s * a.q0 + h * a.q1;
    for (int j = wave; j < TILE; j += 4) {
        float dot = 0.0f;
        if (j < count) {
            const int pos = begin + j;
            const int64_t physical =
                static_cast<int64_t>(tables[s * a.t0 + (pos / a.block_size) * a.t1]);
            const T* key = k + physical * a.k0 + kh * a.k1
                            + (pos % a.block_size) * a.k2;
            for (int d = lane; d < a.dim; d += 64) {
                const float qs = static_cast<float>(query[d * a.q2]) * scale;
                dot = fmaf(qs, static_cast<float>(key[d * a.k3]), dot);
            }
        }
        dot = wave_sum(dot);
        if (lane == 0)
            logits[j] = j < count ? dot : -INFINITY;
    }
    __syncthreads();

    reduction[tid] = logits[tid];
    __syncthreads();
    for (int stride = THREADS / 2; stride > 0; stride >>= 1) {
        if (tid < stride)
            reduction[tid] = fmaxf(reduction[tid], reduction[tid + stride]);
        __syncthreads();
    }
    if (tid == 0)
        maximum = reduction[0];
    __syncthreads();

    float weight = tid < count ? expf(logits[tid] - maximum) : 0.0f;
    logits[tid] = weight;
    reduction[tid] = weight;
    __syncthreads();
    for (int stride = THREADS / 2; stride > 0; stride >>= 1) {
        if (tid < stride)
            reduction[tid] += reduction[tid + stride];
        __syncthreads();
    }
    if (tid == 0) {
        denominator = reduction[0];
        statistics[slot * 2] = maximum;
        statistics[slot * 2 + 1] = reduction[0];
    }
    __syncthreads();

    // Four independent wavefronts sum disjoint token subsets.
    // Shared memory combines their contributions for each output dimension.
    for (int base = 0; base < a.dim; base += 64) {
        const int d = base + lane;
        float acc = 0.0f;
        if (d < a.dim) {
            for (int j = wave; j < count; j += 4) {
                const int pos = begin + j;
                const int64_t physical =
                    static_cast<int64_t>(tables[s * a.t0 + (pos / a.block_size) * a.t1]);
                const int64_t offset = physical * a.v0 + kh * a.v1
                                     + (pos % a.block_size) * a.v2 + d * a.v3;
                acc = fmaf(logits[j], static_cast<float>(v[offset]), acc);
            }
        }
        reduction[tid] = acc;
        __syncthreads();
        if (wave == 0 && d < a.dim) {
            const float total = (reduction[lane] + reduction[64 + lane])
                              + (reduction[128 + lane] + reduction[192 + lane]);
            partial[slot * a.dim + d] = total / denominator;
        }
        __syncthreads();
    }
}

template <typename T>
__global__ void merge_parts(
    const float* __restrict__ partial,
    const float* __restrict__ statistics,
    T* __restrict__ out,
    int heads, int dim, int parts)
{
    const int row = blockIdx.x;
    const int tid = threadIdx.x;
    extern __shared__ float weights[];
    __shared__ float inv_sum;

    if (tid == 0) {
        float maximum = -INFINITY;
        for (int p = 0; p < parts; ++p)
            maximum = fmaxf(maximum, statistics[((int64_t)row * parts + p) * 2]);
        float sum = 0.0f;
        for (int p = 0; p < parts; ++p) {
            const int64_t index = ((int64_t)row * parts + p) * 2;
            const float z = statistics[index + 1];
            float w = z > 0.0f ? z * expf(statistics[index] - maximum) : 0.0f;
            weights[p] = w;
            sum += w;
        }
        inv_sum = 1.0f / sum;
    }
    __syncthreads();
    for (int d = tid; d < dim; d += blockDim.x) {
        float result = 0.0f;
        for (int p = 0; p < parts; ++p) {
            if (weights[p] > 0.0f)
                result = fmaf(weights[p],
                              partial[((int64_t)row * parts + p) * dim + d],
                              result);
        }
        out[(int64_t)row * dim + d] = static_cast<T>(result * inv_sum);
    }
}

template <typename T, typename I, typename L>
void launch_parts(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                  torch::Tensor tables, torch::Tensor lengths,
                  torch::Tensor partial, torch::Tensor stats,
                  Layout a, float scale, hipStream_t stream) {
    attention_parts<T, I, L><<<dim3(a.heads, q.size(0), a.parts), THREADS, 0, stream>>>(
        q.data_ptr<T>(), k.data_ptr<T>(), v.data_ptr<T>(),
        tables.data_ptr<I>(), lengths.data_ptr<L>(),
        partial.data_ptr<float>(), stats.data_ptr<float>(), a, scale);
}

torch::Tensor paged_decode(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                           torch::Tensor tables, torch::Tensor lengths,
                           double scale) {
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda() &&
                tables.is_cuda() && lengths.is_cuda(), "Inputs must be on device");
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim() == 3 && k.dim() == 4 && v.sizes() == k.sizes(),
                "Invalid query/cache shapes");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type(), "Cache dtype mismatch");
    TORCH_CHECK(q.size(2) == k.size(3) && k.size(1) > 0 &&
                q.size(1) % k.size(1) == 0, "Invalid head dimensions");
    TORCH_CHECK(tables.scalar_type() == at::kInt || tables.scalar_type() == at::kLong,
                "Block tables must be int32 or int64");
    TORCH_CHECK(lengths.scalar_type() == at::kInt || lengths.scalar_type() == at::kLong,
                "Sequence lengths must be int32 or int64");

    Layout a;
    a.heads = q.size(1);
    a.kv_heads = k.size(1);
    a.dim = q.size(2);
    a.block_size = k.size(2);
    a.parts = (tables.size(1) * a.block_size + TILE - 1) / TILE;
    a.q0=q.stride(0); a.q1=q.stride(1); a.q2=q.stride(2);
    a.k0=k.stride(0); a.k1=k.stride(1); a.k2=k.stride(2); a.k3=k.stride(3);
    a.v0=v.stride(0); a.v1=v.stride(1); a.v2=v.stride(2); a.v3=v.stride(3);
    a.t0=tables.stride(0); a.t1=tables.stride(1); a.l0=lengths.stride(0);

    auto out = torch::empty(q.sizes(), q.options());
    if (q.numel() == 0) return out;
    TORCH_CHECK(a.parts > 0, "Empty block table");
    auto options = q.options().dtype(at::kFloat);
    auto partial = torch::empty({q.size(0), q.size(1), (int64_t)a.parts, q.size(2)}, options);
    auto stats = torch::empty({q.size(0), q.size(1), (int64_t)a.parts, 2}, options);
    auto stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  q.scalar_type(), "paged_decode", [&] {
        if (tables.scalar_type() == at::kInt) {
            if (lengths.scalar_type() == at::kInt)
                launch_parts<scalar_t,int32_t,int32_t>(q,k,v,tables,lengths,partial,stats,a,scale,stream);
            else
                launch_parts<scalar_t,int32_t,int64_t>(q,k,v,tables,lengths,partial,stats,a,scale,stream);
        } else {
            if (lengths.scalar_type() == at::kInt)
                launch_parts<scalar_t,int64_t,int32_t>(q,k,v,tables,lengths,partial,stats,a,scale,stream);
            else
                launch_parts<scalar_t,int64_t,int64_t>(q,k,v,tables,lengths,partial,stats,a,scale,stream);
        }
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        merge_parts<scalar_t><<<q.size(0)*a.heads, 256,
                               a.parts*sizeof(float), stream>>>(
            partial.data_ptr<float>(), stats.data_ptr<float>(),
            out.data_ptr<scalar_t>(), a.heads, a.dim, a.parts);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    });
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "paged_decode_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        return _get_extension().paged_decode(
            query, key_cache, value_cache, block_tables, seq_lens, self.scale
        )
