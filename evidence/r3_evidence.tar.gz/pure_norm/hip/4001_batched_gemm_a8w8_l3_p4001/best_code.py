import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>

torch::Tensor quant_gemm(
    torch::Tensor x, torch::Tensor w,
    torch::Tensor xs, torch::Tensor ws,
    torch::Tensor bias, bool use_bias, int dtype);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("quant_gemm", &quant_gemm);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>

struct Strides {
    int64_t b, r, c;
};

__device__ __forceinline__ float read_bias(
    const void* p, int type, int64_t offset)
{
    if (type == 0)
        return static_cast<const float*>(p)[offset];
    if (type == 1)
        return float(static_cast<const at::Half*>(p)[offset]);
    return float(static_cast<const at::BFloat16*>(p)[offset]);
}

template <typename Input, typename Output, bool Bias>
__global__ __launch_bounds__(256)
void gemm_kernel(
    const Input* __restrict__ x,
    const Input* __restrict__ w,
    const float* __restrict__ xs,
    const float* __restrict__ ws,
    const void* __restrict__ bias,
    Output* __restrict__ out,
    int64_t M, int64_t N, int64_t K,
    Strides sx, Strides sw, Strides ssx, Strides ssw,
    Strides sb, int bias_type)
{
    __shared__ float ax[64][17];
    __shared__ float aw[64][17];

    const int t = threadIdx.x;
    const int lr = t >> 4;
    const int lc = t & 15;
    const int64_t batch = blockIdx.z;
    const int64_t row0 = int64_t(blockIdx.y) * 64;
    const int64_t col0 = int64_t(blockIdx.x) * 64;

    float acc[4][4] = {};

    for (int64_t k0 = 0; k0 < K; k0 += 16) {
        #pragma unroll
        for (int q = 0; q < 4; ++q) {
            const int r = lr + q * 16;
            const int64_t k = k0 + lc;
            float a = 0.0f;
            float b = 0.0f;
            if (row0 + r < M && k < K) {
                a = float(static_cast<int8_t>(
                    x[batch * sx.b + (row0 + r) * sx.r + k * sx.c]));
            }
            if (col0 + r < N && k < K) {
                b = float(static_cast<int8_t>(
                    w[batch * sw.b + (col0 + r) * sw.r + k * sw.c]));
            }
            ax[r][lc] = a;
            aw[r][lc] = b;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < 16; ++k) {
            float a[4], b[4];
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                a[i] = ax[lr + i * 16][k];
                b[i] = aw[lc + i * 16][k];
            }
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                #pragma unroll
                for (int j = 0; j < 4; ++j) {
                    acc[i][j] = fmaf(a[i], b[j], acc[i][j]);
                }
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const int64_t m = row0 + lr + i * 16;
        if (m < M) {
            const float scale_x = xs[batch * ssx.b + m * ssx.r];
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                const int64_t n = col0 + lc + j * 16;
                if (n < N) {
                    const float scale_w = ws[batch * ssw.b + n * ssw.c];
                    float value = (acc[i][j] * scale_x) * scale_w;
                    Output result = Output(value);
                    if (Bias) {
                        const Output bv = Output(read_bias(
                            bias, bias_type, batch * sb.b + n * sb.c));
                        result = Output(float(result) + float(bv));
                    }
                    out[(batch * M + m) * N + n] = result;
                }
            }
        }
    }
}

static Strides strides(const torch::Tensor& t) {
    return {t.stride(0), t.stride(1), t.stride(2)};
}

template <typename Input, typename Output>
void launch(
    const torch::Tensor& x, const torch::Tensor& w,
    const torch::Tensor& xs, const torch::Tensor& ws,
    const torch::Tensor& bias, torch::Tensor& out,
    bool use_bias, hipStream_t stream)
{
    const int64_t B = x.size(0), M = x.size(1);
    const int64_t K = x.size(2), N = w.size(1);
    Strides sb{0, 0, 0};
    int bt = 0;
    const void* bp = nullptr;
    if (use_bias) {
        sb = strides(bias);
        bp = bias.data_ptr();
        bt = bias.scalar_type() == at::kFloat ? 0 :
             bias.scalar_type() == at::kHalf ? 1 : 2;
    }
    dim3 grid((N + 63) / 64, (M + 63) / 64, B);
    if (use_bias) {
        gemm_kernel<Input, Output, true><<<grid, 256, 0, stream>>>(
            x.data_ptr<Input>(), w.data_ptr<Input>(),
            xs.data_ptr<float>(), ws.data_ptr<float>(), bp,
            out.data_ptr<Output>(), M, N, K,
            strides(x), strides(w), strides(xs), strides(ws), sb, bt);
    } else {
        gemm_kernel<Input, Output, false><<<grid, 256, 0, stream>>>(
            x.data_ptr<Input>(), w.data_ptr<Input>(),
            xs.data_ptr<float>(), ws.data_ptr<float>(), bp,
            out.data_ptr<Output>(), M, N, K,
            strides(x), strides(w), strides(xs), strides(ws), sb, bt);
    }
}

template <typename Input>
void launch_output(
    const torch::Tensor& x, const torch::Tensor& w,
    const torch::Tensor& xs, const torch::Tensor& ws,
    const torch::Tensor& bias, torch::Tensor& out,
    bool use_bias, int dtype, hipStream_t stream)
{
    if (dtype == 0)
        launch<Input, at::BFloat16>(x, w, xs, ws, bias, out, use_bias, stream);
    else if (dtype == 1)
        launch<Input, at::Half>(x, w, xs, ws, bias, out, use_bias, stream);
    else
        launch<Input, float>(x, w, xs, ws, bias, out, use_bias, stream);
}

torch::Tensor quant_gemm(
    torch::Tensor x, torch::Tensor w,
    torch::Tensor xs, torch::Tensor ws,
    torch::Tensor bias, bool use_bias, int dtype)
{
    TORCH_CHECK(x.is_cuda() && w.is_cuda() && xs.is_cuda() && ws.is_cuda(),
                "Inputs must reside on the accelerator");
    TORCH_CHECK(x.dim() == 3 && w.dim() == 3 &&
                xs.dim() == 3 && ws.dim() == 3, "Expected rank-three inputs");
    TORCH_CHECK(x.size(0) == w.size(0) && x.size(2) == w.size(2),
                "Incompatible GEMM dimensions");
    TORCH_CHECK(x.scalar_type() == w.scalar_type() &&
                (x.scalar_type() == at::kFloat || x.scalar_type() == at::kChar),
                "Code words must both be float32 or int8");
    TORCH_CHECK(xs.scalar_type() == at::kFloat && ws.scalar_type() == at::kFloat,
                "Scales must be float32");
    TORCH_CHECK(x.device() == w.device() && x.device() == xs.device() &&
                x.device() == ws.device(), "Inputs must share a device");
    if (use_bias) {
        TORCH_CHECK(bias.device() == x.device() && bias.dim() == 3,
                    "Invalid bias device or shape");
        TORCH_CHECK(bias.scalar_type() == at::kFloat ||
                    bias.scalar_type() == at::kHalf ||
                    bias.scalar_type() == at::kBFloat16,
                    "Unsupported bias dtype");
    }

    c10::cuda::CUDAGuard guard(x.device());
    auto type = dtype == 0 ? at::kBFloat16 :
                dtype == 1 ? at::kHalf : at::kFloat;
    auto out = torch::empty(
        {x.size(0), x.size(1), w.size(1)}, x.options().dtype(type));
    if (out.numel() == 0)
        return out;
    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    if (x.scalar_type() == at::kFloat)
        launch_output<float>(x, w, xs, ws, bias, out, use_bias, dtype, stream);
    else
        launch_output<int8_t>(x, w, xs, ws, bias, out, use_bias, dtype, stream);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "quant_tn_gemm_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        dtype_codes = {
            torch.bfloat16: 0,
            torch.float16: 1,
            torch.float32: 2,
        }
        if self.out_dtype not in dtype_codes:
            raise ValueError("out_dtype must be bfloat16, float16, or float32")
        self._dtype_code = dtype_codes[self.out_dtype]

    def forward(self, xq, wq, x_scale, w_scale, bias):
        return _get_extension().quant_gemm(
            xq,
            wq,
            x_scale,
            w_scale,
            bias if self.use_bias else x_scale,
            self.use_bias,
            self._dtype_code,
        )
