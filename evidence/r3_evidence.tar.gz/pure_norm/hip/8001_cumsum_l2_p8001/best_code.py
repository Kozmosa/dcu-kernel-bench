import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor prefix_forward(torch::Tensor x, int64_t dim);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &prefix_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

// A compensated accumulator keeps all arithmetic in float32.
struct Acc {
    float hi, lo;
};

__device__ __forceinline__ Acc add(Acc a, Acc b) {
    float s = a.hi + b.hi;
    float v = s - a.hi;
    float e = (a.hi - (s - v)) + (b.hi - v);
    e = e + (a.lo + b.lo);
    float h = s + e;
    return {h, e - (h - s)};
}

__device__ __forceinline__ Acc warp_prefix(Acc a, int lane) {
    #pragma unroll
    for (int d = 1; d < 64; d <<= 1) {
        Acc b;
        b.hi = __shfl_up(a.hi, d, 64);
        b.lo = __shfl_up(a.lo, d, 64);
        if (lane >= d) a = add(b, a);
    }
    return a;
}

template<typename T, bool TOTALS>
__global__ void contiguous_scan(
    const T* __restrict__ x, T* __restrict__ y,
    Acc* __restrict__ totals, const Acc* __restrict__ offsets,
    int length, int chunks, int64_t jobs)
{
    __shared__ Acc waves[4];
    int t = threadIdx.x;
    int lane = t & 63;
    int wave = t >> 6;
    int64_t job = blockIdx.x;
    if (job >= jobs) return;
    int chunk = job % chunks;
    int64_t row = job / chunks;
    int start = chunk * 1024 + t * 4;
    int64_t base = row * length;
    Acc vals[4];
    Acc sum = {0.0f, 0.0f};
    #pragma unroll
    for (int k = 0; k < 4; ++k) {
        float f = start + k < length ? float(x[base + start + k]) : 0.0f;
        sum = add(sum, {f, 0.0f});
        vals[k] = sum;
    }
    Acc inclusive = warp_prefix(sum, lane);
    if (lane == 63) waves[wave] = inclusive;
    __syncthreads();

    Acc prior_waves = {0.0f, 0.0f};
    #pragma unroll
    for (int w = 0; w < 4; ++w)
        if (w < wave) prior_waves = add(prior_waves, waves[w]);

    if (TOTALS) {
        if (t == 255) totals[job] = add(prior_waves, inclusive);
    } else {
        Acc prior;
        prior.hi = __shfl_up(inclusive.hi, 1, 64);
        prior.lo = __shfl_up(inclusive.lo, 1, 64);
        if (lane == 0) prior = {0.0f, 0.0f};
        prior = add(prior_waves, prior);
        if (offsets != nullptr) prior = add(offsets[job], prior);
        #pragma unroll
        for (int k = 0; k < 4; ++k) {
            if (start + k < length) {
                Acc value = add(prior, vals[k]);
                y[base + start + k] = T(value.hi + value.lo);
            }
        }
    }
}

template<typename T, bool TOTALS>
__global__ void strided_scan(
    const T* __restrict__ x, T* __restrict__ y,
    Acc* __restrict__ totals, const Acc* __restrict__ offsets,
    int length, int64_t inner, int64_t chains, int chunks)
{
    int64_t chain = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
    int chunk = blockIdx.y;
    if (chain >= chains) return;
    int64_t outer = chain / inner;
    int64_t column = chain - outer * inner;
    int64_t base = outer * int64_t(length) * inner + column;
    int first = chunk * 256;
    int last = min(first + 256, length);
    Acc s = {0.0f, 0.0f};
    if (!TOTALS && offsets != nullptr)
        s = offsets[int64_t(chunk) * chains + chain];
    for (int j = first; j < last; ++j) {
        s = add(s, {float(x[base + int64_t(j) * inner]), 0.0f});
        if (!TOTALS)
            y[base + int64_t(j) * inner] = T(s.hi + s.lo);
    }
    if (TOTALS) totals[int64_t(chunk) * chains + chain] = s;
}

__global__ void scan_totals(Acc* data, int64_t chains, int chunks, bool contiguous) {
    int64_t chain = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
    if (chain >= chains) return;
    Acc sum = {0.0f, 0.0f};
    for (int c = 0; c < chunks; ++c) {
        int64_t idx = contiguous ? chain * chunks + c : int64_t(c) * chains + chain;
        Acc value = data[idx];
        data[idx] = sum;
        sum = add(sum, value);
    }
}

torch::Tensor prefix_forward(torch::Tensor x, int64_t dim) {
    TORCH_CHECK(x.is_cuda(), "Expected an accelerator tensor");
    TORCH_CHECK(x.is_contiguous(), "Expected contiguous input");
    TORCH_CHECK(x.dim() >= 1 && x.dim() <= 4, "Expected 1 to 4 dimensions");
    TORCH_CHECK(dim >= -x.dim() && dim < x.dim(), "Invalid scan dimension");
    if (dim < 0) dim += x.dim();
    c10::cuda::CUDAGuard guard(x.device());
    int length = int(x.size(dim));
    TORCH_CHECK(length >= 1 && length <= 65536, "Invalid scan length");
    if (length == 1) return x;

    int64_t inner = 1;
    for (int d = int(dim) + 1; d < x.dim(); ++d) inner *= x.size(d);
    int64_t chains = x.numel() / length;
    auto out = torch::empty_like(x);
    bool contiguous = inner == 1;
    int chunk_length = contiguous ? 1024 : 256;
    int chunks = (length + chunk_length - 1) / chunk_length;
    torch::Tensor workspace;
    Acc* scratch = nullptr;
    if (chunks > 1) {
        workspace = torch::empty(
            {chains * chunks * 2}, x.options().dtype(torch::kFloat32));
        scratch = reinterpret_cast<Acc*>(workspace.data_ptr<float>());
    }
    auto stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "prefix_forward", [&] {
            const scalar_t* src = x.data_ptr<scalar_t>();
            scalar_t* dst = out.data_ptr<scalar_t>();
            if (contiguous) {
                int64_t jobs = chains * chunks;
                if (chunks > 1) {
                    contiguous_scan<scalar_t, true><<<jobs, 256, 0, stream>>>(
                        src, dst, scratch, nullptr, length, chunks, jobs);
                    scan_totals<<<(chains + 255) / 256, 256, 0, stream>>>(
                        scratch, chains, chunks, true);
                }
                contiguous_scan<scalar_t, false><<<jobs, 256, 0, stream>>>(
                    src, dst, scratch, scratch, length, chunks, jobs);
            } else {
                dim3 grid((chains + 255) / 256, chunks);
                if (chunks > 1) {
                    strided_scan<scalar_t, true><<<grid, 256, 0, stream>>>(
                        src, dst, scratch, nullptr, length, inner, chains, chunks);
                    scan_totals<<<(chains + 255) / 256, 256, 0, stream>>>(
                        scratch, chains, chunks, false);
                }
                strided_scan<scalar_t, false><<<grid, 256, 0, stream>>>(
                    src, dst, scratch, scratch, length, inner, chains, chunks);
            }
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="compensated_prefix_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, dim: int = 2):
        super().__init__()
        self.dim = int(dim)

    def forward(self, x):
        return _get_extension().forward(x, self.dim)
