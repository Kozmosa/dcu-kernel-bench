import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP_SRC = r"""
#include <torch/extension.h>
void block_scaled_gemm(
    torch::Tensor a, torch::Tensor b,
    torch::Tensor as, torch::Tensor bs,
    torch::Tensor out);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("block_scaled_gemm", &block_scaled_gemm);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/Dispatch.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

template <typename A, typename B, typename O>
__global__ __launch_bounds__(256)
void gemm_kernel(
    const A* __restrict__ a,
    const B* __restrict__ b,
    const float* __restrict__ as,
    const float* __restrict__ bs,
    O* __restrict__ out,
    int64_t M, int64_t N, int64_t K,
    int64_t a0, int64_t a1,
    int64_t b0, int64_t b1,
    int64_t as0, int64_t as1,
    int64_t bs0, int64_t bs1)
{
    __shared__ float sa[64][33];
    __shared__ float sb[64][33];

    const int tid = threadIdx.x;
    const int x = tid & 15;
    const int y = tid >> 4;
    const int64_t row_base = int64_t(blockIdx.y) * 64;
    const int64_t col_base = int64_t(blockIdx.x) * 64;

    float acc[4][4];
    #pragma unroll
    for (int i = 0; i < 4; ++i)
        #pragma unroll
        for (int j = 0; j < 4; ++j)
            acc[i][j] = 0.0f;

    for (int64_t kb = 0; kb < K; kb += 32) {
        const int64_t group = kb >> 7;

        #pragma unroll
        for (int p = 0; p < 8; ++p) {
            const int index = tid + p * 256;
            const int r = index >> 5;
            const int k = index & 31;
            const int64_t ak = kb + k;
            const int64_t ar = row_base + r;
            const int64_t br = col_base + r;

            float av = 0.0f;
            float bv = 0.0f;
            if (ar < M && ak < K) {
                av = float(a[ar * a0 + ak * a1])
                   * as[ar * as0 + group * as1];
            }
            if (br < N && ak < K) {
                bv = float(b[br * b0 + ak * b1])
                   * bs[(br >> 7) * bs0 + group * bs1];
            }
            sa[r][k] = av;
            sb[r][k] = bv;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < 32; ++k) {
            float av[4], bv[4];
            #pragma unroll
            for (int i = 0; i < 4; ++i)
                av[i] = sa[y + 16 * i][k];
            #pragma unroll
            for (int j = 0; j < 4; ++j)
                bv[j] = sb[x + 16 * j][k];

            #pragma unroll
            for (int i = 0; i < 4; ++i)
                #pragma unroll
                for (int j = 0; j < 4; ++j)
                    acc[i][j] = fmaf(av[i], bv[j], acc[i][j]);
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const int64_t row = row_base + y + 16 * i;
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int64_t col = col_base + x + 16 * j;
            if (row < M && col < N)
                out[row * N + col] = static_cast<O>(acc[i][j]);
        }
    }
}

template <typename A, typename B>
void launch(
    const torch::Tensor& a, const torch::Tensor& b,
    const torch::Tensor& as, const torch::Tensor& bs,
    torch::Tensor& out)
{
    const int64_t M = a.size(0);
    const int64_t N = b.size(0);
    const int64_t K = a.size(1);
    if (M == 0 || N == 0)
        return;

    const dim3 grid((N + 63) / 64, (M + 63) / 64);
    const auto stream = c10::cuda::getCurrentCUDAStream(a.get_device());

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        out.scalar_type(), "block_scaled_gemm_output", [&] {
            hipLaunchKernelGGL(
                (gemm_kernel<A, B, scalar_t>),
                grid, dim3(256), 0, stream.stream(),
                a.data_ptr<A>(), b.data_ptr<B>(),
                as.data_ptr<float>(), bs.data_ptr<float>(),
                out.data_ptr<scalar_t>(),
                M, N, K,
                a.stride(0), a.stride(1),
                b.stride(0), b.stride(1),
                as.stride(0), as.stride(1),
                bs.stride(0), bs.stride(1));
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

void block_scaled_gemm(
    torch::Tensor a, torch::Tensor b,
    torch::Tensor as, torch::Tensor bs,
    torch::Tensor out)
{
    TORCH_CHECK(a.is_cuda() && b.is_cuda() &&
                as.is_cuda() && bs.is_cuda() && out.is_cuda(),
                "All tensors must be on the accelerator");
    TORCH_CHECK(a.device() == b.device() &&
                a.device() == as.device() &&
                a.device() == bs.device() &&
                a.device() == out.device(), "Device mismatch");
    TORCH_CHECK(a.dim() == 2 && b.dim() == 2 &&
                as.dim() == 2 && bs.dim() == 2,
                "Inputs must be two-dimensional");
    TORCH_CHECK(a.size(1) == b.size(1), "K dimensions must match");
    const int64_t groups = (a.size(1) + 127) / 128;
    TORCH_CHECK(as.size(0) == a.size(0) && as.size(1) == groups,
                "Invalid activation scale shape");
    TORCH_CHECK(bs.size(0) == (b.size(0) + 127) / 128 &&
                bs.size(1) == groups, "Invalid weight scale shape");
    TORCH_CHECK(as.scalar_type() == at::kFloat &&
                bs.scalar_type() == at::kFloat, "Scales must be float32");
    TORCH_CHECK((a.scalar_type() == at::kFloat || a.scalar_type() == at::kChar) &&
                (b.scalar_type() == at::kFloat || b.scalar_type() == at::kChar),
                "Code words must be float32 or int8");

    const c10::cuda::CUDAGuard guard(a.device());
    if (a.scalar_type() == at::kFloat) {
        if (b.scalar_type() == at::kFloat)
            launch<float, float>(a, b, as, bs, out);
        else
            launch<float, int8_t>(a, b, as, bs, out);
    } else {
        if (b.scalar_type() == at::kFloat)
            launch<int8_t, float>(a, b, as, bs, out);
        else
            launch<int8_t, int8_t>(a, b, as, bs, out);
    }
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha256(
            (_CPP_SRC + _HIP_SRC).encode("utf-8")
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"block_scaled_gemm_hip_{digest}",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, out_dtype: str = "bfloat16"):
        super().__init__()
        self.out_dtype = getattr(torch, out_dtype)
        self.block_n = 128
        self.block_k = 128

    def forward(self, aq, bq, a_scale, b_scale):
        out = torch.empty(
            (aq.shape[0], bq.shape[0]),
            device=aq.device,
            dtype=self.out_dtype,
        )
        _get_extension().block_scaled_gemm(aq, bq, a_scale, b_scale, out)
        return out
