```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor bn_backward_hip(
    torch::Tensor dy, torch::Tensor x, torch::Tensor scale,
    torch::Tensor mean, torch::Tensor inv, bool data_gradient);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &bn_backward_hip);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cstdint>

constexpr int BLOCK = 256;
constexpr int TILE = 4096;

__device__ __forceinline__ void reduce_pair(
    float a, float b, float* sa, float* sb)
{
    const int t = threadIdx.x;
    sa[t] = a;
    sb[t] = b;
    __syncthreads();
    for (int stride = BLOCK / 2; stride; stride >>= 1) {
        if (t < stride) {
            sa[t] += sa[t + stride];
            sb[t] += sb[t + stride];
        }
        __syncthreads();
    }
}

template<bool DX>
__global__ void small_kernel(
    const float* __restrict__ dy, const float* __restrict__ x,
    const float* __restrict__ scale, const float* __restrict__ mean,
    const float* __restrict__ inv, float* __restrict__ out,
    int64_t C, int64_t S, int64_t M)
{
    __shared__ float sa[BLOCK], sb[BLOCK];
    const int64_t c = blockIdx.x;
    const float mu = mean[c], iv = inv[c];
    float a = 0.0f, b = 0.0f;
    for (int64_t j = threadIdx.x; j < M; j += BLOCK) {
        const int64_t p = (j / S * C + c) * S + j % S;
        const float g = dy[p];
        const float h = (x[p] - mu) * iv;
        a += g * h;
        b += g;
    }
    reduce_pair(a, b, sa, sb);
    if constexpr (DX) {
        const float dg = sa[0], db = sb[0];
        const float factor = (scale[c] * iv) / float(M);
        for (int64_t j = threadIdx.x; j < M; j += BLOCK) {
            const int64_t p = (j / S * C + c) * S + j % S;
            const float h = (x[p] - mu) * iv;
            out[p] = factor * ((float(M) * dy[p] - db) - h * dg);
        }
    } else {
        if (threadIdx.x == 0) {
            out[c] = sa[0];
            out[C + c] = sb[0];
        }
    }
}

__global__ void partial_kernel(
    const float* __restrict__ dy, const float* __restrict__ x,
    const float* __restrict__ mean, const float* __restrict__ inv,
    float* __restrict__ partial,
    int64_t C, int64_t S, int64_t M, int64_t P)
{
    __shared__ float sa[BLOCK], sb[BLOCK];
    const int64_t c = blockIdx.x / P;
    const int64_t part = blockIdx.x % P;
    const int64_t begin = part * TILE;
    const int64_t end = min(begin + int64_t(TILE), M);
    const float mu = mean[c], iv = inv[c];
    float a = 0.0f, b = 0.0f;
    for (int64_t j = begin + threadIdx.x; j < end; j += BLOCK) {
        const int64_t p = (j / S * C + c) * S + j % S;
        const float g = dy[p];
        const float h = (x[p] - mu) * iv;
        a += g * h;
        b += g;
    }
    reduce_pair(a, b, sa, sb);
    if (threadIdx.x == 0) {
        partial[c * P + part] = sa[0];
        partial[(C + c) * P + part] = sb[0];
    }
}

__global__ void finish_kernel(
    const float* __restrict__ partial, float* __restrict__ stats,
    int64_t C, int64_t P)
{
    __shared__ float sa[BLOCK], sb[BLOCK];
    const int64_t c = blockIdx.x;
    float a = 0.0f, b = 0.0f;
    for (int64_t j = threadIdx.x; j < P; j += BLOCK) {
        a += partial[c * P + j];
        b += partial[(C + c) * P + j];
    }
    reduce_pair(a, b, sa, sb);
    if (threadIdx.x == 0) {
        stats[c] = sa[0];
        stats[C + c] = sb[0];
    }
}

__global__ void dx_kernel(
    const float* __restrict__ dy, const float* __restrict__ x,
    const float* __restrict__ scale, const float* __restrict__ mean,
    const float* __restrict__ inv, const float* __restrict__ stats,
    float* __restrict__ out, int64_t count, int64_t C,
    int64_t S, int64_t M)
{
    for (int64_t p = int64_t(blockIdx.x) * BLOCK + threadIdx.x;
         p < count; p += int64_t(gridDim.x) * BLOCK) {
        const int64_t c = (p / S) % C;
        const float iv = inv[c];
        const float h = (x[p] - mean[c]) * iv;
        const float factor = (scale[c] * iv) / float(M);
        out[p] = factor *
            ((float(M) * dy[p] - stats[C + c]) - h * stats[c]);
    }
}

torch::Tensor bn_backward_hip(
    torch::Tensor dy, torch::Tensor x, torch::Tensor scale,
    torch::Tensor mean, torch::Tensor inv, bool data_gradient)
{
    TORCH_CHECK(x.is_cuda() && dy.is_cuda(), "Inputs must be on the accelerator");
    TORCH_CHECK(x.dim() == 4 && x.sizes() == dy.sizes(), "Expected matching NCHW inputs");
    for (const auto& t : {dy, x, scale, mean, inv}) {
        TORCH_CHECK(t.scalar_type() == at::kFloat, "Expected float32 inputs");
        TORCH_CHECK(t.is_contiguous(), "Expected contiguous inputs");
        TORCH_CHECK(t.device() == x.device(), "Inputs must share a device");
    }
    const c10::cuda::CUDAGuard guard(x.device());
    const int64_t C = x.size(1);
    const int64_t S = x.size(2) * x.size(3);
    const int64_t M = x.size(0) * S;
    TORCH_CHECK(C > 0 && M > 0, "Expected nonempty dimensions");
    TORCH_CHECK(scale.numel() == C && mean.numel() == C && inv.numel() == C,
                "Expected one statistic and scale per channel");

    auto out = data_gradient ? torch::empty_like(x) : torch::empty({2 * C}, x.options());
    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    const float* gp = dy.data_ptr<float>();
    const float* xp = x.data_ptr<float>();
    const float* sp = scale.data_ptr<float>();
    const float* mp = mean.data_ptr<float>();
    const float* ip = inv.data_ptr<float>();

    if (M <= 2048) {
        if (data_gradient) {
            small_kernel<true><<<C, BLOCK, 0, stream>>>(
                gp, xp, sp, mp, ip, out.data_ptr<float>(), C, S, M);
        } else {
            small_kernel<false><<<C, BLOCK, 0, stream>>>(
                gp, xp, sp, mp, ip, out.data_ptr<float>(), C, S, M);
        }
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        return out;
    }

    const int64_t P = (M + TILE - 1) / TILE;
    auto partial = torch::empty({2 * C * P}, x.options());
    auto stats = data_gradient ? torch::empty({2 * C}, x.options()) : out;
    partial_kernel<<<C * P, BLOCK, 0, stream>>>(
        gp, xp, mp, ip, partial.data_ptr<float>(), C, S, M, P);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    finish_kernel<<<C, BLOCK, 0, stream>>>(
        partial.data_ptr<float>(), stats.data_ptr<float>(), C, P);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    if (data_gradient) {
        const int64_t count = x.numel();
        const int blocks = int(std::min<int64_t>((count + BLOCK - 1) / BLOCK, 65535));
        dx_kernel<<<blocks, BLOCK, 0, stream>>>(
            gp, xp, sp, mp, ip, stats.data_ptr<float>(),
            out.data_ptr<float>(), count, C, S, M);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"bn_backward_hip_{digest}",
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-std=c++17", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dx"):
        super().__init__()
        assert variant in ("dx", "dgamma_dbeta"), (
            "variant must be one of dx / dgamma_dbeta"
        )
        self.variant = variant

    def forward(self, dy, x, scale, saved_mean, saved_inv_variance):
        return _get_extension().run(
            dy, x, scale, saved_mean, saved_inv_variance, self.variant == "dx"
        )
```