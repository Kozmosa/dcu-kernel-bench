```python
import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor paged_attention(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor tables, torch::Tensor lengths, torch::Tensor offsets,
    torch::Tensor sinks, double scale, int64_t window, double cap, bool use_sinks);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention", &paged_attention);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <algorithm>

constexpr int TILE = 256;

__device__ __forceinline__ float wave_sum(float x) {
    #pragma unroll
    for (int delta = 32; delta; delta >>= 1)
        x += __shfl_down(x, delta, 64);
    return x;
}

template<int ND>
__global__ void partial_kernel(
    const float* __restrict__ q, const float* __restrict__ k,
    const float* __restrict__ v, const int* __restrict__ tables,
    const int* __restrict__ lengths, const int* __restrict__ offsets,
    float* __restrict__ partial, float* __restrict__ stats,
    int H, int G, int D, int BS, int NS, int MT, int SPLITS,
    int CHUNK, int window, float scale, float cap)
{
    int rh = blockIdx.x;
    int split = blockIdx.y;
    int r = rh / H, h = rh % H;
    int t = threadIdx.x, lane = t & 63, wave = t >> 6;

    int lo = 0, hi = NS;
    while (lo < hi) {
        int mid = (lo + hi) >> 1;
        if (offsets[mid + 1] <= r) lo = mid + 1;
        else hi = mid;
    }
    int s = lo;
    int end = lengths[s] - (offsets[s + 1] - offsets[s]) + r - offsets[s] + 1;
    int start = window > 0 ? max(0, end - window) : 0;
    int begin = start + split * CHUNK;
    int finish = min(end, begin + CHUNK);
    int g = h / (H / G);

    __shared__ float scores[TILE];
    __shared__ float red[TILE];
    __shared__ float running_max, running_sum, alpha, tile_max;
    __shared__ int physical[TILE];

    float acc[ND];
    #pragma unroll
    for (int a = 0; a < ND; ++a) acc[a] = 0.0f;
    if (t == 0) {
        running_max = -INFINITY;
        running_sum = 0.0f;
    }
    __syncthreads();

    for (int base = begin; base < finish; base += TILE) {
        int count = min(TILE, finish - base);
        int pos = base + t;
        if (t < count)
            physical[t] = tables[(int64_t)s * MT + pos / BS] * BS + pos % BS;
        __syncthreads();

        for (int j = wave; j < TILE; j += 4) {
            float dot = 0.0f;
            if (j < count) {
                int64_t kp = ((int64_t)physical[j] * G + g) * D;
                int64_t qp = (int64_t)rh * D;
                for (int d = lane; d < D; d += 64)
                    dot = fmaf(q[qp + d] * scale, k[kp + d], dot);
            }
            dot = wave_sum(dot);
            if (lane == 0) {
                if (cap > 0.0f) dot = cap * tanhf(dot / cap);
                scores[j] = j < count ? dot : -INFINITY;
            }
        }
        __syncthreads();
        red[t] = scores[t];
        __syncthreads();
        for (int stride = 128; stride; stride >>= 1) {
            if (t < stride) red[t] = fmaxf(red[t], red[t + stride]);
            __syncthreads();
        }
        if (t == 0) {
            float m = fmaxf(running_max, red[0]);
            alpha = expf(running_max - m);
            tile_max = m;
        }
        __syncthreads();
        float weight = t < count ? expf(scores[t] - tile_max) : 0.0f;
        scores[t] = weight;
        red[t] = weight;
        __syncthreads();
        for (int stride = 128; stride; stride >>= 1) {
            if (t < stride) red[t] += red[t + stride];
            __syncthreads();
        }

        #pragma unroll
        for (int a = 0; a < ND; ++a) {
            int d = t + a * TILE;
            if (d < D) {
                float z = acc[a] * alpha;
                for (int j = 0; j < count; ++j) {
                    int64_t vp = ((int64_t)physical[j] * G + g) * D + d;
                    z = fmaf(scores[j], v[vp], z);
                }
                acc[a] = z;
            }
        }
        if (t == 0) {
            running_sum = running_sum * alpha + red[0];
            running_max = tile_max;
        }
        __syncthreads();
    }
    int64_t p = (int64_t)rh * SPLITS + split;
    #pragma unroll
    for (int a = 0; a < ND; ++a) {
        int d = t + a * TILE;
        if (d < D) partial[p * D + d] = acc[a];
    }
    if (t == 0) {
        stats[p * 2] = running_max;
        stats[p * 2 + 1] = running_sum;
    }
}

__global__ void merge_kernel(
    const float* __restrict__ partial, const float* __restrict__ stats,
    const float* __restrict__ sinks, float* __restrict__ out,
    int H, int D, int splits, float cap, bool use_sinks)
{
    int rh = blockIdx.x;
    int t = threadIdx.x;
    __shared__ float weights[32];
    __shared__ float denominator;
    if (t == 0) {
        float sink = -INFINITY;
        if (use_sinks) {
            sink = sinks[rh % H];
            if (cap > 0.0f) sink = cap * tanhf(sink / cap);
        }
        float m = sink;
        int64_t p = (int64_t)rh * splits;
        for (int j = 0; j < splits; ++j)
            m = fmaxf(m, stats[(p + j) * 2]);
        float sum = use_sinks ? expf(sink - m) : 0.0f;
        for (int j = 0; j < splits; ++j) {
            float w = expf(stats[(p + j) * 2] - m);
            weights[j] = w;
            sum += w * stats[(p + j) * 2 + 1];
        }
        denominator = sum;
    }
    __syncthreads();
    for (int d = t; d < D; d += blockDim.x) {
        float z = 0.0f;
        for (int j = 0; j < splits; ++j)
            z = fmaf(weights[j], partial[((int64_t)rh * splits + j) * D + d], z);
        out[(int64_t)rh * D + d] = z / denominator;
    }
}

torch::Tensor paged_attention(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor tables, torch::Tensor lengths, torch::Tensor offsets,
    torch::Tensor sinks, double scale, int64_t window, double cap, bool use_sinks)
{
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.scalar_type() == at::kFloat &&
                k.scalar_type() == at::kFloat && v.scalar_type() == at::kFloat,
                "Expected float32 query, keys, and values");
    int H = q.size(1), D = q.size(2), G = k.size(2);
    int BS = k.size(1), NS = lengths.numel(), MT = tables.size(1);
    TORCH_CHECK(G > 0 && H % G == 0, "Invalid grouped-query head count");
    TORCH_CHECK(D > 0 && D <= 4096, "Supported head sizes are 1 through 4096");
    auto out = torch::empty_like(q);
    if (!q.numel()) return out;

    int capacity = BS * MT;
    if (window > 0) capacity = std::min<int64_t>(capacity, window);
    int splits = std::max(1, std::min(32, (capacity + 511) / 512));
    int chunk = std::max(256, ((capacity + splits * 256 - 1) / (splits * 256)) * 256);
    int64_t rows = q.size(0) * H;
    auto partial = torch::empty({rows, splits, D}, q.options());
    auto stats = torch::empty({rows, splits, 2}, q.options());
    auto stream = at::cuda::getCurrentCUDAStream();

    dim3 grid(rows, splits);
    #define LAUNCH(N) \
        partial_kernel<N><<<grid, 256, 0, stream>>>( \
            q.data_ptr<float>(), k.data_ptr<float>(), v.data_ptr<float>(), \
            tables.data_ptr<int>(), lengths.data_ptr<int>(), offsets.data_ptr<int>(), \
            partial.data_ptr<float>(), stats.data_ptr<float>(), \
            H, G, D, BS, NS, MT, splits, chunk, (int)window, (float)scale, (float)cap)
    if (D <= 256) { LAUNCH(1); }
    else if (D <= 512) { LAUNCH(2); }
    else if (D <= 1024) { LAUNCH(4); }
    else if (D <= 2048) { LAUNCH(8); }
    else { LAUNCH(16); }
    #undef LAUNCH
    C10_CUDA_KERNEL_LAUNCH_CHECK();

    merge_kernel<<<rows, 256, 0, stream>>>(
        partial.data_ptr<float>(), stats.data_ptr<float>(),
        use_sinks ? sinks.data_ptr<float>() : nullptr,
        out.data_ptr<float>(), H, D, splits, (float)cap, use_sinks);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="paged_attention_gfx936_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, sliding_window: int = 0, softcap: float = 0.0, use_sinks: bool = True):
        super().__init__()
        self.scale = 1.0 / math.sqrt(head_size)
        self.sliding_window = int(sliding_window)
        self.softcap = float(softcap)
        self.use_sinks = bool(use_sinks)

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens, cu_seqlens_q, sinks):
        return _get_extension().paged_attention(
            query,
            key_cache,
            value_cache,
            block_tables.to(dtype=torch.int32),
            seq_lens.to(dtype=torch.int32),
            cu_seqlens_q.to(dtype=torch.int32),
            sinks,
            self.scale,
            self.sliding_window,
            self.softcap,
            self.use_sinks,
        )
```