import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_forward(torch::Tensor q, torch::Tensor k,
    torch::Tensor v, torch::Tensor causal, torch::Tensor slopes, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &attention_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>

struct Layout {
    int64_t b, s, h, d;
};
static Layout layout(const torch::Tensor& x) {
    return {x.stride(0), x.stride(1), x.stride(2), x.stride(3)};
}

template<class T>
__global__ void scores_kernel(
    const T* __restrict__ q, const T* __restrict__ k,
    const float* __restrict__ slopes, const int* causal,
    int causal_host, float* __restrict__ scores,
    int Q, int K, int H, int HK, int D, float scale,
    Layout qs, Layout ks, int64_t sb, int64_t sh)
{
    __shared__ float qa[16][17], ka[16][17];
    int x = threadIdx.x, y = threadIdx.y;
    int i = blockIdx.y * 16 + y;
    int j = blockIdx.x * 16 + x;
    int bh = blockIdx.z, b = bh / H, h = bh % H;
    int kh = h / (H / HK);
    float acc = 0.f;
    for (int t = 0; t < D; t += 16) {
        qa[y][x] = (i < Q && t + x < D)
            ? float(q[b*qs.b + i*qs.s + h*qs.h + (t+x)*qs.d]) : 0.f;
        int kj = blockIdx.x * 16 + y;
        ka[y][x] = (kj < K && t + x < D)
            ? float(k[b*ks.b + kj*ks.s + kh*ks.h + (t+x)*ks.d]) : 0.f;
        __syncthreads();
        #pragma unroll
        for (int d = 0; d < 16; ++d)
            acc = fmaf(qa[y][d], ka[x][d], acc);
        __syncthreads();
    }
    if (i < Q && j < K) {
        float z = acc * scale;
        z = z - slopes[b*sb + h*sh] * float(abs(i + K - Q - j));
        if ((causal ? *causal : causal_host) && j > i + K - Q)
            z = -INFINITY;
        scores[((int64_t)bh*Q+i)*K+j] = z;
    }
}

__global__ void normalize_kernel(float* scores, float* packed,
                                 int Q, int K, int H, int D, int B) {
    __shared__ float reduction[256];
    int tid = threadIdx.x;
    int row = blockIdx.x;
    float* p = scores + (int64_t)row*K;
    float mx = -INFINITY;
    for (int j = tid; j < K; j += 256) mx = fmaxf(mx, p[j]);
    reduction[tid] = mx;
    __syncthreads();
    for (int s = 128; s; s >>= 1) {
        if (tid < s) reduction[tid] = fmaxf(reduction[tid], reduction[tid+s]);
        __syncthreads();
    }
    mx = reduction[0];
    float sum = 0.f;
    for (int j = tid; j < K; j += 256) {
        float e = mx == -INFINITY ? 0.f : expf(p[j] - mx);
        p[j] = e;
        sum += e;
    }
    reduction[tid] = sum;
    __syncthreads();
    for (int s = 128; s; s >>= 1) {
        if (tid < s) reduction[tid] += reduction[tid+s];
        __syncthreads();
    }
    sum = reduction[0];
    float inv = sum > 0.f ? 1.f / sum : 0.f;
    for (int j = tid; j < K; j += 256) p[j] *= inv;
    if (!tid)
        packed[(int64_t)B*Q*H*D + row] = sum > 0.f ? mx + logf(sum) : 0.f;
}

template<class T>
__global__ void output_kernel(
    const float* __restrict__ p, const T* __restrict__ v,
    float* __restrict__ out, int Q, int K, int H, int HK, int D,
    Layout vs)
{
    __shared__ float pa[16][17], va[16][17];
    int x = threadIdx.x, y = threadIdx.y;
    int i = blockIdx.y * 16 + y;
    int d = blockIdx.x * 16 + x;
    int bh = blockIdx.z, b = bh/H, h = bh%H, kh = h/(H/HK);
    float acc = 0.f;
    for (int t = 0; t < K; t += 16) {
        pa[y][x] = i < Q && t+x < K
            ? p[((int64_t)bh*Q+i)*K+t+x] : 0.f;
        va[y][x] = t+y < K && d < D
            ? float(v[b*vs.b + (t+y)*vs.s + kh*vs.h + d*vs.d]) : 0.f;
        __syncthreads();
        #pragma unroll
        for (int z = 0; z < 16; ++z)
            acc = fmaf(pa[y][z], va[z][x], acc);
        __syncthreads();
    }
    if (i < Q && d < D)
        out[(((int64_t)b*Q+i)*H+h)*D+d] = float(T(acc));
}

torch::Tensor attention_forward(torch::Tensor q, torch::Tensor k,
    torch::Tensor v, torch::Tensor causal, torch::Tensor slopes, double scale)
{
    c10::cuda::CUDAGuard guard(q.device());
    int B=q.size(0), Q=q.size(1), H=q.size(2), D=q.size(3);
    int K=k.size(1), HK=k.size(2);
    TORCH_CHECK(HK > 0 && H % HK == 0, "Invalid head counts");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type(), "Dtypes must match");
    auto options = q.options().dtype(torch::kFloat32);
    auto result = torch::empty({(int64_t)B*Q*H*(D+1)}, options);
    auto scores = torch::empty({(int64_t)B*H*Q*K}, options);
    const int* cp = nullptr;
    int ch = 0;
    if (causal.is_cuda()) {
        TORCH_CHECK(causal.scalar_type() == torch::kInt32, "causal must be int32");
        cp = causal.data_ptr<int>();
    } else {
        ch = causal.item<int>();
    }
    auto stream = at::cuda::getCurrentCUDAStream();
    dim3 block(16,16);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  q.scalar_type(), "attention_forward", [&] {
        scores_kernel<scalar_t><<<dim3((K+15)/16,(Q+15)/16,B*H),block,0,stream>>>(
            q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(),
            slopes.data_ptr<float>(), cp, ch, scores.data_ptr<float>(),
            Q,K,H,HK,D,float(scale),layout(q),layout(k),
            slopes.stride(0),slopes.stride(1));
        normalize_kernel<<<B*H*Q,256,0,stream>>>(
            scores.data_ptr<float>(),result.data_ptr<float>(),Q,K,H,D,B);
        output_kernel<scalar_t><<<dim3((D+15)/16,(Q+15)/16,B*H),block,0,stream>>>(
            scores.data_ptr<float>(),v.data_ptr<scalar_t>(),
            result.data_ptr<float>(),Q,K,H,HK,D,layout(v));
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return result;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "dense_attention_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, sm_scale=None):
        super().__init__()
        self.sm_scale = float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(head_dim)

    def forward(self, q, k, v, causal, alibi_slopes):
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal, dtype=torch.int32)
        elif causal.dtype != torch.int32:
            causal = causal.to(dtype=torch.int32)
        if alibi_slopes.dtype != torch.float32 or alibi_slopes.device != q.device:
            alibi_slopes = alibi_slopes.to(device=q.device, dtype=torch.float32)
        return _get_extension().forward(q, k, v, causal, alibi_slopes, self.sm_scale)
