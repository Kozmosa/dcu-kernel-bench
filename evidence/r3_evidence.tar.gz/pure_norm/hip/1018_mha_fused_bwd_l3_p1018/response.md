```python
import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_backward(torch::Tensor q, torch::Tensor k,
                                 torch::Tensor v, torch::Tensor dout,
                                 double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("attention_backward", &attention_backward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>
#include <cmath>

template<class T>
struct View {
    const T* p;
    int64_t s0, s1, s2, s3;
    __device__ __forceinline__ float get(int b, int i, int h, int d) const {
        return float(p[int64_t(b)*s0 + int64_t(i)*s1 +
                       int64_t(h)*s2 + int64_t(d)*s3]);
    }
};

template<class T>
View<T> view(const torch::Tensor& t) {
    return {t.data_ptr<T>(), t.stride(0), t.stride(1),
            t.stride(2), t.stride(3)};
}

// Each block forms two 16x16 products, sharing the dimension traversal.
template<class T>
__global__ void scores_kernel(
    View<T> q, View<T> k, View<T> v, View<T> dout,
    float* scores, float* dp,
    int M, int N, int H, int HK, int D, float scale)
{
    const int x = threadIdx.x, y = threadIdx.y;
    const int i = blockIdx.y * 16 + y;
    const int j = blockIdx.x * 16 + x;
    const int bh = blockIdx.z;
    const int b = bh / H, h = bh % H, kh = h / (H / HK);

    __shared__ float qs[16][17], ks[16][17];
    __shared__ float os[16][17], vs[16][17];
    float a = 0.f, c = 0.f;
    for (int d0 = 0; d0 < D; d0 += 16) {
        const int d = d0 + x;
        qs[y][x] = i < M && d < D ? q.get(b, i, h, d) : 0.f;
        os[y][x] = i < M && d < D ? dout.get(b, i, h, d) : 0.f;
        const int kj = blockIdx.x * 16 + y;
        ks[y][x] = kj < N && d < D ? k.get(b, kj, kh, d) : 0.f;
        vs[y][x] = kj < N && d < D ? v.get(b, kj, kh, d) : 0.f;
        __syncthreads();
        #pragma unroll
        for (int t = 0; t < 16; ++t) {
            a = fmaf(qs[y][t], ks[x][t], a);
            c = fmaf(os[y][t], vs[x][t], c);
        }
        __syncthreads();
    }
    if (i < M && j < N) {
        int64_t idx = (int64_t(bh) * M + i) * N + j;
        scores[idx] = a * scale;
        dp[idx] = c;
    }
}

__device__ __forceinline__ float block_sum(float a, float* tmp) {
    int t = threadIdx.x;
    tmp[t] = a;
    __syncthreads();
    #pragma unroll
    for (int s = 128; s; s >>= 1) {
        if (t < s) tmp[t] += tmp[t + s];
        __syncthreads();
    }
    return tmp[0];
}

__device__ __forceinline__ float block_max(float a, float* tmp) {
    int t = threadIdx.x;
    tmp[t] = a;
    __syncthreads();
    #pragma unroll
    for (int s = 128; s; s >>= 1) {
        if (t < s) tmp[t] = fmaxf(tmp[t], tmp[t + s]);
        __syncthreads();
    }
    return tmp[0];
}

// Convert scores to P and dP to dS in place.
__global__ void normalize_kernel(float* p, float* ds, int N) {
    const int t = threadIdx.x;
    const int64_t base = int64_t(blockIdx.x) * N;
    __shared__ float scratch[256];
    float mx = -INFINITY;
    for (int j = t; j < N; j += 256)
        mx = fmaxf(mx, p[base + j]);
    mx = block_max(mx, scratch);
    __syncthreads();

    float sum = 0.f;
    for (int j = t; j < N; j += 256) {
        float e = expf(p[base + j] - mx);
        p[base + j] = e;
        sum += e;
    }
    sum = block_sum(sum, scratch);
    __syncthreads();

    float delta = 0.f;
    const float inv = 1.f / sum;
    for (int j = t; j < N; j += 256) {
        float prob = p[base + j] * inv;
        p[base + j] = prob;
        delta = fmaf(prob, ds[base + j], delta);
    }
    delta = block_sum(delta, scratch);
    __syncthreads();
    for (int j = t; j < N; j += 256)
        ds[base + j] = p[base + j] * (ds[base + j] - delta);
}

template<class T>
__global__ void dq_kernel(
    const float* ds, View<T> k, T* output,
    int M, int N, int H, int HK, int D, float scale)
{
    const int x = threadIdx.x, y = threadIdx.y;
    const int i = blockIdx.y * 16 + y;
    const int d = blockIdx.x * 16 + x;
    const int bh = blockIdx.z;
    const int b = bh / H, h = bh % H, kh = h / (H / HK);
    __shared__ float a[16][17], z[16][17];
    float acc = 0.f;
    for (int j0 = 0; j0 < N; j0 += 16) {
        const int j = j0 + x;
        a[y][x] = i < M && j < N ?
            ds[(int64_t(bh) * M + i) * N + j] : 0.f;
        const int kj = j0 + y;
        z[y][x] = kj < N && d < D ? k.get(b, kj, kh, d) : 0.f;
        __syncthreads();
        #pragma unroll
        for (int t = 0; t < 16; ++t)
            acc = fmaf(a[y][t], z[t][x], acc);
        __syncthreads();
    }
    if (i < M && d < D)
        output[((int64_t(b) * M + i) * H + h) * D + d] = T(acc * scale);
}

template<class T>
__global__ void dkv_kernel(
    const float* p, const float* ds, View<T> q, View<T> dout,
    T* dk, T* dv, int M, int N, int H, int HK, int D, float scale)
{
    const int x = threadIdx.x, y = threadIdx.y;
    const int j = blockIdx.y * 16 + y;
    const int d = blockIdx.x * 16 + x;
    const int bkh = blockIdx.z;
    const int b = bkh / HK, kh = bkh % HK, group = H / HK;
    __shared__ float a[16][17], psh[16][17];
    __shared__ float qs[16][17], os[16][17];
    float total_k = 0.f, total_v = 0.f;
    for (int g = 0; g < group; ++g) {
        const int h = kh * group + g;
        const int64_t base = int64_t(b * H + h) * M * N;
        float ak = 0.f, av = 0.f;
        for (int i0 = 0; i0 < M; i0 += 16) {
            // Coalesced loads from the untransposed probability matrices.
            const int si = i0 + y;
            const int sj = blockIdx.y * 16 + x;
            a[x][y] = si < M && sj < N ? ds[base + int64_t(si)*N + sj] : 0.f;
            psh[x][y] = si < M && sj < N ? p[base + int64_t(si)*N + sj] : 0.f;
            qs[y][x] = si < M && d < D ? q.get(b, si, h, d) : 0.f;
            os[y][x] = si < M && d < D ? dout.get(b, si, h, d) : 0.f;
            __syncthreads();
            #pragma unroll
            for (int t = 0; t < 16; ++t) {
                ak = fmaf(a[y][t], qs[t][x], ak);
                av = fmaf(psh[y][t], os[t][x], av);
            }
            __syncthreads();
        }
        total_k += ak * scale;
        total_v += av;
    }
    if (j < N && d < D) {
        int64_t idx = ((int64_t(b) * N + j) * HK + kh) * D + d;
        dk[idx] = T(total_k);
        dv[idx] = T(total_v);
    }
}

torch::Tensor attention_backward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor dout, double scale)
{
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda() && dout.is_cuda(),
                "All inputs must be on the accelerator");
    TORCH_CHECK(q.dim() == 4 && k.dim() == 4 && v.dim() == 4 && dout.dim() == 4,
                "Expected four-dimensional bshd inputs");
    TORCH_CHECK(q.device() == k.device() && q.device() == v.device() &&
                q.device() == dout.device(), "Input devices must agree");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type() &&
                q.scalar_type() == dout.scalar_type(), "Input dtypes must agree");

    const int B = q.size(0), M = q.size(1), H = q.size(2), D = q.size(3);
    const int N = k.size(1), HK = k.size(2);
    TORCH_CHECK(HK > 0 && H > 0 && H % HK == 0 && D > 0 && D <= 256 &&
                M > 0 && N > 0, "Invalid attention dimensions");
    TORCH_CHECK(k.size(0) == B && k.size(3) == D &&
                v.sizes() == k.sizes() && dout.sizes() == q.sizes(),
                "Input shapes do not agree");

    const c10::cuda::CUDAGuard guard(q.device());
    auto stream = at::cuda::getCurrentCUDAStream();
    const int64_t nq = int64_t(B) * M * H * D;
    const int64_t nk = int64_t(B) * N * HK * D;
    auto output = torch::empty({nq + 2 * nk}, q.options());
    if (B == 0) return output;
    auto workspace = torch::empty({2, int64_t(B) * H * M * N},
                                 q.options().dtype(torch::kFloat32));
    float* p = workspace.data_ptr<float>();
    float* ds = p + int64_t(B) * H * M * N;
    dim3 threads(16, 16);

    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                   q.scalar_type(), "attention_backward", [&] {
        auto qv = view<scalar_t>(q);
        auto kv = view<scalar_t>(k);
        auto vv = view<scalar_t>(v);
        auto ov = view<scalar_t>(dout);
        auto out = output.data_ptr<scalar_t>();
        scores_kernel<scalar_t><<<dim3((N+15)/16, (M+15)/16, B*H),
                                   threads, 0, stream>>>(
            qv, kv, vv, ov, p, ds, M, N, H, HK, D, float(scale));
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        normalize_kernel<<<int64_t(B)*H*M, 256, 0, stream>>>(p, ds, N);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        dq_kernel<scalar_t><<<dim3((D+15)/16, (M+15)/16, B*H),
                               threads, 0, stream>>>(
            ds, kv, out, M, N, H, HK, D, float(scale));
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        dkv_kernel<scalar_t><<<dim3((D+15)/16, (N+15)/16, B*HK),
                                threads, 0, stream>>>(
            p, ds, qv, ov, out+nq, out+nq+nk,
            M, N, H, HK, D, float(scale));
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    });
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "attention_bwd_" + hashlib.sha256(
            (_CPP + _HIP).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)

    def forward(self, q, k, v, do):
        return _get_extension().attention_backward(q, k, v, do, self.sm_scale)
```