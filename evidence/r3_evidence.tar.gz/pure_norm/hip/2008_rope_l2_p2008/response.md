```python
import hashlib

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor rope_forward(
    torch::Tensor x,
    torch::Tensor freqs,
    int64_t rotate_style,
    bool nope_first,
    bool reuse_freqs_front_part);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("rope_forward", &rope_forward);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cstdint>

template <typename scalar_t, int STYLE, bool REUSE>
__global__ void rope_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ freqs,
    scalar_t* __restrict__ out,
    int64_t row_size,
    int64_t tiles_per_row,
    int64_t total_tiles,
    int d,
    int f,
    int r,
    int start)
{
    __shared__ float cos_table[256];
    __shared__ float sin_table[256];

    constexpr int TILE = 2048;
    for (int64_t tile = blockIdx.x;
         tile < total_tiles;
         tile += gridDim.x) {
        const int64_t seq = tile / tiles_per_row;
        const int64_t tile_in_row = tile - seq * tiles_per_row;
        const int64_t begin = tile_in_row * TILE;
        const int64_t base = seq * row_size;

        if (threadIdx.x < f) {
            float angle = static_cast<float>(freqs[seq * f + threadIdx.x]);
            float s, c;
            sincosf(angle, &s, &c);
            sin_table[threadIdx.x] = s;
            cos_table[threadIdx.x] = c;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < TILE / 256; ++k) {
            const int64_t offset = begin + threadIdx.x + k * 256;
            if (offset < row_size) {
                const int channel = static_cast<int>(offset & (d - 1));
                const int j = channel - start;
                const int64_t index = base + offset;

                if (static_cast<unsigned>(j) < static_cast<unsigned>(r)) {
                    int partner;
                    int angle_index;
                    bool negative;

                    if (STYLE == 0) {
                        const int half = r >> 1;
                        negative = j < half;
                        partner = negative ? j + half : j - half;
                        angle_index = REUSE ? (j & (half - 1)) : j;
                    } else {
                        negative = (j & 1) == 0;
                        partner = j ^ 1;
                        angle_index = REUSE ? (j >> 1) : j;
                    }

                    float a = static_cast<float>(x[index]);
                    float b = static_cast<float>(
                        x[index + static_cast<int64_t>(partner - j)]);
                    if (negative) b = -b;

                    // Match the reference's separately rounded products and sum.
                    float ac = a * cos_table[angle_index];
                    float bs = b * sin_table[angle_index];
                    out[index] = static_cast<scalar_t>(ac + bs);
                } else {
                    out[index] = x[index];
                }
            }
        }
        __syncthreads();
    }
}

torch::Tensor rope_forward(
    torch::Tensor x,
    torch::Tensor freqs,
    int64_t rotate_style,
    bool nope_first,
    bool reuse_freqs_front_part)
{
    TORCH_CHECK(x.is_cuda() && freqs.is_cuda(), "Inputs must be on the accelerator");
    TORCH_CHECK(x.device() == freqs.device(), "Inputs must share a device");
    TORCH_CHECK(x.is_contiguous() && freqs.is_contiguous(), "Inputs must be contiguous");
    TORCH_CHECK(x.dim() == 4 && freqs.dim() == 4, "Inputs must have four dimensions");
    TORCH_CHECK(x.scalar_type() == freqs.scalar_type(), "Input dtypes must match");
    TORCH_CHECK(rotate_style == 0 || rotate_style == 1, "Invalid rotation style");
    TORCH_CHECK(freqs.size(0) == x.size(0) &&
                freqs.size(1) == 1 && freqs.size(2) == 1,
                "Invalid frequency shape");

    const int d = static_cast<int>(x.size(3));
    const int f = static_cast<int>(freqs.size(3));
    const int r = f * (reuse_freqs_front_part ? 2 : 1);
    TORCH_CHECK(d >= 4 && d <= 256 && (d & (d - 1)) == 0,
                "Head dimension must be a power of two from 4 through 256");
    TORCH_CHECK(r == d || r == d / 2, "Invalid rotation width");

    const c10::cuda::CUDAGuard guard(x.device());
    auto out = torch::empty_like(x);
    if (x.numel() == 0) return out;

    const int start = nope_first ? d - r : 0;
    const int64_t row_size = x.size(1) * x.size(2) * d;
    const int64_t tiles_per_row = (row_size + 2047) / 2048;
    const int64_t total_tiles = x.size(0) * tiles_per_row;
    const unsigned blocks = static_cast<unsigned>(
        std::min<int64_t>(total_tiles, 2147483647LL));
    auto stream = at::cuda::getCurrentCUDAStream(x.get_device());

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "rope_forward", [&] {
            const scalar_t* xp = x.data_ptr<scalar_t>();
            const scalar_t* fp = freqs.data_ptr<scalar_t>();
            scalar_t* op = out.data_ptr<scalar_t>();

            #define LAUNCH(STYLE, REUSE) \
                hipLaunchKernelGGL( \
                    (rope_kernel<scalar_t, STYLE, REUSE>), \
                    dim3(blocks), dim3(256), 0, stream.stream(), \
                    xp, fp, op, row_size, tiles_per_row, total_tiles, \
                    d, f, r, start)

            if (rotate_style == 0) {
                if (reuse_freqs_front_part) {
                    LAUNCH(0, true);
                } else {
                    LAUNCH(0, false);
                }
            } else {
                if (reuse_freqs_front_part) {
                    LAUNCH(1, true);
                } else {
                    LAUNCH(1, false);
                }
            }
            #undef LAUNCH
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha256((_CPP_SRC + _HIP_SRC).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"rope_sbhd_hip_{digest}",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, rotate_style: int, nope_first: bool, reuse_freqs_front_part: bool):
        super().__init__()
        self.rotate_style = int(rotate_style)
        self.nope_first = bool(nope_first)
        self.reuse_freqs_front_part = bool(reuse_freqs_front_part)

    def forward(self, x, freqs):
        return _get_extension().rope_forward(
            x,
            freqs,
            self.rotate_style,
            self.nope_first,
            self.reuse_freqs_front_part,
        )
```