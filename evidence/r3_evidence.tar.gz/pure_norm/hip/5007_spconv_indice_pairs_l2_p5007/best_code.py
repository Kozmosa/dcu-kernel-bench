import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor build_map(
    torch::Tensor x, int64_t batch,
    std::vector<int64_t> sizes, std::vector<int64_t> steps,
    std::vector<int64_t> pads, std::vector<int64_t> dilations,
    std::vector<int64_t> output_dims);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("build_map", &build_map);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <hipcub/hipcub.hpp>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <climits>
#include <algorithm>

#define HIP_CHECK(expr) do { \
    hipError_t e = (expr); \
    TORCH_CHECK(e == hipSuccess, hipGetErrorString(e)); \
} while (0)

struct Geometry {
    int ndim, batch;
    int64_t k[3], s[3], p[3], l[3], out[3];
};

__device__ __forceinline__ unsigned long long mix_key(unsigned long long x) {
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

__global__ void init_table(unsigned long long* keys, int* first, int64_t h) {
    for (int64_t j = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
         j < h; j += (int64_t)blockDim.x * gridDim.x) {
        keys[j] = ~0ULL;
        first[j] = INT_MAX;
    }
}

template<typename T>
__global__ void make_pairs(
    const T* x, int n, int total, Geometry g,
    unsigned long long* keys, int* first, int64_t mask,
    int64_t* locations, int* valid) {
    for (int64_t t = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
         t < total; t += (int64_t)blockDim.x * gridDim.x) {
        int i = t % n;
        int k = t / n;
        int b = (int)x[(int64_t)i * (g.ndim + 1)];
        int64_t q[3];
        bool ok = b >= 0 && b < g.batch;
        for (int d = g.ndim - 1; d >= 0; --d) {
            int64_t o = k % g.k[d];
            k /= g.k[d];
            int64_t v = (int64_t)x[(int64_t)i * (g.ndim + 1) + d + 1]
                        + g.p[d] - o * g.l[d];
            q[d] = v / g.s[d];
            ok = ok && v % g.s[d] == 0 &&
                 q[d] >= 0 && q[d] < g.out[d];
        }
        valid[t] = ok ? 1 : 0;
        locations[t] = -1;
        if (!ok) continue;
        unsigned long long key = b;
        for (int d = 0; d < g.ndim; ++d)
            key = key * g.out[d] + q[d];
        int64_t pos = mix_key(key) & mask;
        while (true) {
            unsigned long long old = atomicCAS(keys + pos, ~0ULL, key);
            if (old == ~0ULL || old == key) break;
            pos = (pos + 1) & mask;
        }
        locations[t] = pos;
        atomicMin(first + pos, (int)t);
    }
}

__global__ void mark_first(
    const int64_t* locations, const int* first, int* flags, int total) {
    for (int64_t t = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
         t < total; t += (int64_t)blockDim.x * gridDim.x) {
        int64_t pos = locations[t];
        flags[t] = pos >= 0 && first[pos] == t ? 1 : 0;
    }
}

__global__ void write_result(
    const int64_t* locations, const unsigned long long* keys,
    const int* first, const int* ranks, const int* counts,
    int* result, int n, int total, int64_t cap, Geometry g) {
    int64_t base = cap * (g.ndim + 1);
    for (int64_t t = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
         t < total; t += (int64_t)blockDim.x * gridDim.x) {
        int k = t / n;
        int start = k * n;
        int preceding = start ? counts[start - 1] : 0;
        if (t == start + n - 1)
            result[base + 2LL * total + k] = counts[t] - preceding;
        int64_t pos = locations[t];
        if (pos < 0) continue;
        int initial = first[pos];
        int r = ranks[initial] - 1;
        int c = counts[t] - preceding - 1;
        result[base + start + c] = t - start;
        result[base + total + start + c] = r;
        if (initial == t) {
            unsigned long long key = keys[pos];
            int64_t dst = (int64_t)r * (g.ndim + 1);
            for (int d = g.ndim - 1; d >= 0; --d) {
                result[dst + d + 1] = key % g.out[d];
                key /= g.out[d];
            }
            result[dst] = key;
        }
    }
}

torch::Tensor build_map(
    torch::Tensor x, int64_t batch,
    std::vector<int64_t> sizes, std::vector<int64_t> steps,
    std::vector<int64_t> pads, std::vector<int64_t> dilations,
    std::vector<int64_t> output_dims) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous());
    TORCH_CHECK(x.scalar_type() == at::kFloat || x.scalar_type() == at::kInt);
    c10::cuda::CUDAGuard guard(x.device());
    hipStream_t stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    Geometry g{};
    g.ndim = sizes.size();
    g.batch = batch;
    int64_t kv = 1, volume = batch;
    for (int d = 0; d < g.ndim; ++d) {
        g.k[d] = sizes[d];
        g.s[d] = steps[d];
        g.p[d] = pads[d];
        g.l[d] = dilations[d];
        g.out[d] = output_dims[d];
        kv *= sizes[d];
        volume *= output_dims[d];
    }
    int64_t n64 = x.size(0), total64 = n64 * kv;
    TORCH_CHECK(total64 < INT_MAX, "Pair capacity exceeds int32 range");
    int n = n64, total = total64;
    int64_t cap = std::min(total64, volume);
    auto opts = x.options().dtype(at::kInt);
    auto result = torch::empty({cap * (g.ndim + 1) + 2 * total64 + kv}, opts);
    HIP_CHECK(hipMemsetAsync(result.data_ptr(), 0xff,
                            result.numel() * sizeof(int), stream));
    if (!total) {
        HIP_CHECK(hipMemsetAsync(result.data_ptr(), 0,
                                result.numel() * sizeof(int), stream));
        return result;
    }
    int64_t h = 2;
    while (h < cap * 2) h <<= 1;
    auto keys = torch::empty({h}, opts.dtype(at::kLong));
    auto first = torch::empty({h}, opts);
    auto locations = torch::empty({total64}, opts.dtype(at::kLong));
    auto valid = torch::empty({total64}, opts);
    auto flags = torch::empty({total64}, opts);
    auto counts = torch::empty({total64}, opts);
    auto ranks = torch::empty({total64}, opts);
    int blocks = std::min<int64_t>((total64 + 255) / 256, 65535);
    int hblocks = std::min<int64_t>((h + 255) / 256, 65535);
    auto kp = reinterpret_cast<unsigned long long*>(keys.data_ptr<int64_t>());
    init_table<<<hblocks, 256, 0, stream>>>(kp, first.data_ptr<int>(), h);
    if (x.scalar_type() == at::kFloat) {
        make_pairs<float><<<blocks, 256, 0, stream>>>(
            x.data_ptr<float>(), n, total, g, kp, first.data_ptr<int>(),
            h - 1, locations.data_ptr<int64_t>(), valid.data_ptr<int>());
    } else {
        make_pairs<int><<<blocks, 256, 0, stream>>>(
            x.data_ptr<int>(), n, total, g, kp, first.data_ptr<int>(),
            h - 1, locations.data_ptr<int64_t>(), valid.data_ptr<int>());
    }
    mark_first<<<blocks, 256, 0, stream>>>(
        locations.data_ptr<int64_t>(), first.data_ptr<int>(),
        flags.data_ptr<int>(), total);
    size_t bytes = 0;
    HIP_CHECK(hipcub::DeviceScan::InclusiveSum(
        nullptr, bytes, valid.data_ptr<int>(), counts.data_ptr<int>(), total, stream));
    auto workspace = torch::empty({(int64_t)bytes}, opts.dtype(at::kByte));
    HIP_CHECK(hipcub::DeviceScan::InclusiveSum(
        workspace.data_ptr(), bytes, valid.data_ptr<int>(),
        counts.data_ptr<int>(), total, stream));
    HIP_CHECK(hipcub::DeviceScan::InclusiveSum(
        workspace.data_ptr(), bytes, flags.data_ptr<int>(),
        ranks.data_ptr<int>(), total, stream));
    write_result<<<blocks, 256, 0, stream>>>(
        locations.data_ptr<int64_t>(), kp, first.data_ptr<int>(),
        ranks.data_ptr<int>(), counts.data_ptr<int>(), result.data_ptr<int>(),
        n, total, cap, g);
    HIP_CHECK(hipGetLastError());
    return result;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "ordered_sparse_map_" + hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, batch_size: int = 2, input_dims=None, ksize=None, stride=None, padding=None, dilation=None):
        super().__init__()
        self.batch_size = int(batch_size)
        self.input_dims = list(input_dims if input_dims is not None else [4, 32, 32])
        self.ksize = list(ksize if ksize is not None else [3, 3, 3])
        self.stride = list(stride if stride is not None else [1, 1, 1])
        self.padding = list(padding if padding is not None else [1, 1, 1])
        self.dilation = list(dilation if dilation is not None else [1, 1, 1])
        ndim = len(self.input_dims)
        assert self.batch_size >= 1 and 1 <= ndim <= 3
        assert all(len(v) == ndim for v in (
            self.ksize, self.stride, self.padding, self.dilation
        ))
        self.output_dims = []
        for d in range(ndim):
            assert self.input_dims[d] >= 1 and self.ksize[d] >= 1
            assert self.stride[d] >= 1 and self.padding[d] >= 0 and self.dilation[d] >= 1
            out = (
                self.input_dims[d] + 2 * self.padding[d]
                - self.dilation[d] * (self.ksize[d] - 1) - 1
            ) // self.stride[d] + 1
            assert out >= 1
            self.output_dims.append(out)

    def forward(self, indices):
        if indices.dtype not in (torch.float32, torch.int32):
            indices = indices.to(dtype=torch.int32)
        return _get_extension().build_map(
            indices.contiguous(),
            self.batch_size,
            self.ksize,
            self.stride,
            self.padding,
            self.dilation,
            self.output_dims,
        )
