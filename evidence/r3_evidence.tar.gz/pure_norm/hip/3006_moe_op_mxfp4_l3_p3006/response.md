```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>

torch::Tensor mxfp4_moe(
    torch::Tensor a, torch::Tensor as,
    torch::Tensor b, torch::Tensor bs,
    torch::Tensor weights, torch::Tensor ids);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &mxfp4_moe);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

__device__ __forceinline__ float decode(unsigned int x) {
    unsigned int v = x & 7;
    float magnitude = v < 4 ? 0.5f * float(v)
                            : float(2 + (v & 1)) * float(1 << ((v >> 1) - 2));
    return (x & 8) ? -magnitude : magnitude;
}

__device__ __forceinline__ float scale_value(unsigned int s) {
    // Preserve the reference's subnormal scale at s=0 and infinity at s=255.
    if (s == 0) return __uint_as_float(0x00400000u);
    if (s == 255) return __uint_as_float(0x7f800000u);
    return __uint_as_float(s << 23);
}

__device__ __forceinline__ uint16_t to_bf16(float x) {
    unsigned int u = __float_as_uint(x);
    if ((u & 0x7fffffffu) > 0x7f800000u)
        return uint16_t((u >> 16) | 0x0040u);
    u += 0x7fffu + ((u >> 16) & 1u);
    return uint16_t(u >> 16);
}

template<int GROUP>
__global__ void moe_kernel(
    const uint8_t* __restrict__ a,
    const uint8_t* __restrict__ as,
    const uint8_t* __restrict__ b,
    const uint8_t* __restrict__ bs,
    const float* __restrict__ weights,
    const int64_t* __restrict__ ids,
    uint16_t* __restrict__ out,
    int64_t N, int64_t Kh, int64_t S,
    int64_t topk, int64_t total)
{
    constexpr int OUTPUTS = 256 / GROUP;
    const int lane = threadIdx.x % GROUP;
    const int group = threadIdx.x / GROUP;
    const int64_t index = int64_t(blockIdx.x) * OUTPUTS + group;
    const bool valid = index < total;
    float sum = 0.0f;

    if (valid) {
        const int64_t slot = index / N;
        const int64_t n = index - slot * N;
        const int64_t token = slot / topk;
        const int64_t expert = ids[slot];
        const int64_t brow = expert * N + n;

        const uint8_t* ap = a + token * Kh;
        const uint8_t* bp = b + brow * Kh;
        const uint8_t* asp = as + token * S;
        const uint8_t* bsp = bs + brow * S;

        for (int64_t byte = lane; byte < Kh; byte += GROUP) {
            const unsigned int ac = ap[byte];
            const unsigned int bc = bp[byte];
            const float sa = scale_value(asp[byte >> 4]);
            const float sb = scale_value(bsp[byte >> 4]);
            const float a0 = decode(ac & 15) * sa;
            const float a1 = decode(ac >> 4) * sa;
            const float b0 = decode(bc & 15) * sb;
            const float b1 = decode(bc >> 4) * sb;
            sum = fmaf(a0, b0, sum);
            sum = fmaf(a1, b1, sum);
        }
    }

    #pragma unroll
    for (int offset = GROUP / 2; offset > 0; offset >>= 1)
        sum += __shfl_down(sum, offset, GROUP);

    if (valid && lane == 0)
        out[index] = to_bf16(sum * weights[index / N]);
}

torch::Tensor mxfp4_moe(
    torch::Tensor a, torch::Tensor as,
    torch::Tensor b, torch::Tensor bs,
    torch::Tensor weights, torch::Tensor ids)
{
    TORCH_CHECK(a.is_cuda(), "Inputs must be on the accelerator");
    c10::cuda::CUDAGuard guard(a.device());

    const int64_t M = a.size(0);
    const int64_t Kh = a.size(1);
    const int64_t N = b.size(1);
    const int64_t topk = ids.size(1);
    TORCH_CHECK(Kh % 16 == 0, "K must be divisible by 32");

    auto out = torch::empty(
        {M, topk, N}, a.options().dtype(torch::kBFloat16));
    const int64_t total = M * topk * N;
    if (total == 0) return out;

    auto stream = at::cuda::getCurrentCUDAStream();
    if (Kh <= 512) {
        moe_kernel<16><<< (total + 15) / 16, 256, 0, stream >>>(
            a.data_ptr<uint8_t>(), as.data_ptr<uint8_t>(),
            b.data_ptr<uint8_t>(), bs.data_ptr<uint8_t>(),
            weights.data_ptr<float>(), ids.data_ptr<int64_t>(),
            reinterpret_cast<uint16_t*>(out.data_ptr<at::BFloat16>()),
            N, Kh, Kh / 16, topk, total);
    } else {
        moe_kernel<32><<< (total + 7) / 8, 256, 0, stream >>>(
            a.data_ptr<uint8_t>(), as.data_ptr<uint8_t>(),
            b.data_ptr<uint8_t>(), bs.data_ptr<uint8_t>(),
            weights.data_ptr<float>(), ids.data_ptr<int64_t>(),
            reinterpret_cast<uint16_t*>(out.data_ptr<at::BFloat16>()),
            N, Kh, Kh / 16, topk, total);
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "mxfp4_moe_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, a_q, a_scales, b_q, b_scales, topk_weights, topk_ids):
        return _extension().run(
            a_q.to(dtype=torch.uint8).contiguous(),
            a_scales.to(dtype=torch.uint8).contiguous(),
            b_q.to(dtype=torch.uint8).contiguous(),
            b_scales.to(dtype=torch.uint8).contiguous(),
            topk_weights.to(dtype=torch.float32).contiguous(),
            topk_ids.to(dtype=torch.int64).contiguous(),
        )
```