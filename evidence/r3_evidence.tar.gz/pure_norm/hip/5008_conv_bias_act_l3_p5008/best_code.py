import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor pyramid_forward(
    torch::Tensor x,
    torch::Tensor weight,
    torch::Tensor bias,
    torch::Tensor slope,
    int64_t activation);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &pyramid_forward);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template<int ACT>
__device__ __forceinline__ float activate(float z, const float* slope) {
    if constexpr (ACT == 0) {
        return fmaxf(z, 0.0f);
    } else if constexpr (ACT == 1) {
        return z / (1.0f + expf(-z));
    } else {
        return z > 0.0f ? z : z * slope[0];
    }
}

template<int ACT, int FIXED_R, int FIXED_S>
__global__ __launch_bounds__(256)
void pyramid_kernel(
    const float* __restrict__ x,
    const float* __restrict__ weight,
    const float* __restrict__ bias,
    const float* __restrict__ slope,
    float* __restrict__ out,
    int C, int H, int W, int K, int runtime_r, int runtime_s,
    int OH, int OW)
{
    constexpr int TM = 32;
    constexpr int TN = 64;
    constexpr int TK = 16;

    __shared__ float a[TM][TK + 1];
    __shared__ float b[TK][TN];

    const int R = FIXED_R ? FIXED_R : runtime_r;
    const int S = FIXED_S ? FIXED_S : runtime_s;
    const int RS = R * S;
    const int D = C * RS;
    const int P = OH * OW;
    const int tid = threadIdx.x;
    const int lane = tid & 31;
    const int group = tid >> 5;
    const int mbase = blockIdx.y * TM;
    const int pbase = blockIdx.x * TN;
    const int batch = blockIdx.z;

    const float* xb = x + (int64_t)batch * C * H * W;

    float acc[4][2];
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        acc[i][0] = 0.0f;
        acc[i][1] = 0.0f;
    }

    for (int base = 0; base < D; base += TK) {
        #pragma unroll
        for (int j = 0; j < 2; ++j) {
            const int linear = tid + j * 256;
            const int row = linear / TK;
            const int d = base + linear % TK;
            const int k = mbase + row;
            float v = 0.0f;
            if (k < K && d < D)
                v = weight[(int64_t)k * D + d];
            a[row][linear % TK] = v;
        }

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int linear = tid + j * 256;
            const int dr = linear / TN;
            const int col = linear % TN;
            const int d = base + dr;
            const int p = pbase + col;
            float v = 0.0f;
            if (d < D && p < P) {
                const int c = d / RS;
                const int rs = d % RS;
                const int ih = p / OW + rs / S - 1;
                const int iw = p % OW + rs % S - 1;
                if ((unsigned)ih < (unsigned)H &&
                    (unsigned)iw < (unsigned)W)
                    v = xb[((int64_t)c * H + ih) * W + iw];
            }
            b[dr][col] = v;
        }
        __syncthreads();

        #pragma unroll
        for (int d = 0; d < TK; ++d) {
            const float b0 = b[d][lane];
            const float b1 = b[d][lane + 32];
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                const float av = a[group + i * 8][d];
                acc[i][0] = fmaf(av, b0, acc[i][0]);
                acc[i][1] = fmaf(av, b1, acc[i][1]);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const int k = mbase + group + i * 8;
        if (k < K) {
            const float bv = bias[k];
            #pragma unroll
            for (int j = 0; j < 2; ++j) {
                const int p = pbase + lane + j * 32;
                if (p < P) {
                    const float z = acc[i][j] + bv;
                    out[((int64_t)batch * K + k) * P + p] =
                        activate<ACT>(z, slope);
                }
            }
        }
    }
}

template<int ACT>
void launch_pyramid(
    const torch::Tensor& x,
    const torch::Tensor& weight,
    const torch::Tensor& bias,
    const torch::Tensor& slope,
    torch::Tensor& out,
    hipStream_t stream)
{
    const int N = x.size(0);
    const int C = x.size(1);
    const int H = x.size(2);
    const int W = x.size(3);
    const int K = weight.size(0);
    const int R = weight.size(2);
    const int S = weight.size(3);
    const int OH = out.size(2);
    const int OW = out.size(3);
    const dim3 grid((OH * OW + 63) / 64, (K + 31) / 32, N);
    const float* sp = ACT == 2 ? slope.data_ptr<float>() : nullptr;

    #define LAUNCH(RR, SS) \
        hipLaunchKernelGGL((pyramid_kernel<ACT, RR, SS>), \
            grid, dim3(256), 0, stream, \
            x.data_ptr<float>(), weight.data_ptr<float>(), \
            bias.data_ptr<float>(), sp, out.data_ptr<float>(), \
            C, H, W, K, R, S, OH, OW)

    if (R == 3 && S == 3) {
        LAUNCH(3, 3);
    } else if (R == 1 && S == 1) {
        LAUNCH(1, 1);
    } else {
        LAUNCH(0, 0);
    }
    #undef LAUNCH
}

torch::Tensor pyramid_forward(
    torch::Tensor x,
    torch::Tensor weight,
    torch::Tensor bias,
    torch::Tensor slope,
    int64_t activation)
{
    TORCH_CHECK(x.is_cuda() && weight.is_cuda() && bias.is_cuda(),
                "Inputs must reside on the accelerator");
    TORCH_CHECK(x.scalar_type() == at::kFloat &&
                weight.scalar_type() == at::kFloat &&
                bias.scalar_type() == at::kFloat,
                "Expected float32 inputs");
    TORCH_CHECK(x.dim() == 4 && weight.dim() == 4,
                "Expected four-dimensional input and weight");
    TORCH_CHECK(x.is_contiguous() && weight.is_contiguous() &&
                bias.is_contiguous(), "Expected contiguous inputs");
    TORCH_CHECK(x.device() == weight.device() &&
                x.device() == bias.device(), "Device mismatch");
    TORCH_CHECK(weight.size(1) == x.size(1) &&
                bias.numel() == weight.size(0), "Channel mismatch");
    TORCH_CHECK(activation >= 0 && activation <= 2,
                "Invalid activation");
    if (activation == 2) {
        TORCH_CHECK(slope.is_cuda() && slope.device() == x.device() &&
                    slope.scalar_type() == at::kFloat && slope.numel() == 1,
                    "Expected a float32 device scalar slope");
    }

    const c10::cuda::CUDAGuard guard(x.device());
    const int64_t OH = x.size(2) - weight.size(2) + 3;
    const int64_t OW = x.size(3) - weight.size(3) + 3;
    TORCH_CHECK(OH > 0 && OW > 0, "Invalid output dimensions");

    auto out = torch::empty(
        {x.size(0), weight.size(0), OH, OW}, x.options());
    if (out.numel() == 0)
        return out;

    hipStream_t stream = at::cuda::getCurrentCUDAStream().stream();
    if (activation == 0)
        launch_pyramid<0>(x, weight, bias, slope, out, stream);
    else if (activation == 1)
        launch_pyramid<1>(x, weight, bias, slope, out, stream);
    else
        launch_pyramid<2>(x, weight, bias, slope, out, stream);

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode("utf-8")
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"pyramid_fused_hip_{digest}",
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3", "-std=c++17"],
            extra_cuda_cflags=["-O3", "-std=c++17"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)

    def __init__(self, variant: str = "relu"):
        super().__init__()
        assert variant in ("relu", "swish", "prelu"), (
            "variant must be one of relu / swish / prelu"
        )
        self.variant = variant

    def forward(self, x, weight, bias, slope):
        activation = {"relu": 0, "swish": 1, "prelu": 2}[self.variant]
        return _get_extension().forward(x, weight, bias, slope, activation)
