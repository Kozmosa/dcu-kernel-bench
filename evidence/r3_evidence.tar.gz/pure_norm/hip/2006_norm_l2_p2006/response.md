```python
import hashlib

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_CPP_SOURCE = r"""
#include <torch/extension.h>

torch::Tensor fused_residual_layer_norm(
    torch::Tensor x,
    torch::Tensor residual,
    torch::Tensor weight,
    torch::Tensor bias,
    double eps);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &fused_residual_layer_norm);
}
"""

_HIP_SOURCE = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template<int BLOCK>
__device__ __forceinline__ float block_sum(float v, float* scratch) {
    constexpr int WARP = 64;
    constexpr int NW = BLOCK / WARP;
    const int lane = threadIdx.x & (WARP - 1);
    const int warp = threadIdx.x / WARP;

    #pragma unroll
    for (int delta = 32; delta > 0; delta >>= 1)
        v += __shfl_down(v, delta, WARP);

    if constexpr (NW == 1) {
        return __shfl(v, 0, WARP);
    } else {
        if (lane == 0)
            scratch[warp] = v;
        __syncthreads();
        if (warp == 0) {
            float t = lane < NW ? scratch[lane] : 0.0f;
            #pragma unroll
            for (int delta = 32; delta > 0; delta >>= 1)
                t += __shfl_down(t, delta, WARP);
            if (lane == 0)
                scratch[0] = t;
        }
        __syncthreads();
        float result = scratch[0];
        __syncthreads();
        return result;
    }
}

template<int BLOCK, int ITEMS>
__global__ __launch_bounds__(BLOCK)
void fused_rows(
    const float* __restrict__ x,
    const float* __restrict__ residual,
    const float* __restrict__ weight,
    const float* __restrict__ bias,
    float* __restrict__ out,
    int64_t n,
    float eps)
{
    __shared__ float scratch[BLOCK / 64];
    const int64_t row = blockIdx.x;
    const int64_t input_base = row * n;
    const int64_t output_base = row * (2 * n);
    const int tid = threadIdx.x;
    float values[ITEMS];
    float sum = 0.0f;

    #pragma unroll
    for (int k = 0; k < ITEMS; ++k) {
        const int64_t col = tid + k * BLOCK;
        float v = 0.0f;
        if (col < n) {
            v = x[input_base + col] + residual[input_base + col];
            out[output_base + n + col] = v;
        }
        values[k] = v;
        sum += v;
    }

    const float mean = block_sum<BLOCK>(sum, scratch) / float(n);
    float squares = 0.0f;
    #pragma unroll
    for (int k = 0; k < ITEMS; ++k) {
        const int64_t col = tid + k * BLOCK;
        const float d = col < n ? values[k] - mean : 0.0f;
        squares += d * d;
    }
    const float variance = block_sum<BLOCK>(squares, scratch) / float(n);
    const float inv_std = rsqrtf(variance + eps);

    #pragma unroll
    for (int k = 0; k < ITEMS; ++k) {
        const int64_t col = tid + k * BLOCK;
        if (col < n) {
            const float normalized = (values[k] - mean) * inv_std;
            out[output_base + col] = normalized * weight[col] + bias[col];
        }
    }
}

__global__ __launch_bounds__(256)
void long_rows(
    const float* __restrict__ x,
    const float* __restrict__ residual,
    const float* __restrict__ weight,
    const float* __restrict__ bias,
    float* __restrict__ out,
    int64_t n,
    float eps)
{
    __shared__ float scratch[4];
    const int64_t input_base = int64_t(blockIdx.x) * n;
    const int64_t output_base = int64_t(blockIdx.x) * (2 * n);
    float sum = 0.0f;
    for (int64_t col = threadIdx.x; col < n; col += 256) {
        const float v = x[input_base + col] + residual[input_base + col];
        out[output_base + n + col] = v;
        sum += v;
    }
    const float mean = block_sum<256>(sum, scratch) / float(n);
    float squares = 0.0f;
    for (int64_t col = threadIdx.x; col < n; col += 256) {
        const float d = out[output_base + n + col] - mean;
        squares += d * d;
    }
    const float variance = block_sum<256>(squares, scratch) / float(n);
    const float inv_std = rsqrtf(variance + eps);
    for (int64_t col = threadIdx.x; col < n; col += 256) {
        const float normalized =
            (out[output_base + n + col] - mean) * inv_std;
        out[output_base + col] = normalized * weight[col] + bias[col];
    }
}

torch::Tensor fused_residual_layer_norm(
    torch::Tensor x,
    torch::Tensor residual,
    torch::Tensor weight,
    torch::Tensor bias,
    double eps)
{
    TORCH_CHECK(x.is_cuda(), "x must be on the accelerator");
    TORCH_CHECK(x.scalar_type() == at::kFloat, "inputs must be float32");
    TORCH_CHECK(x.dim() == 2 && x.size(0) > 0 && x.size(1) > 0,
                "x must have shape (M, N), M and N positive");
    TORCH_CHECK(residual.sizes() == x.sizes(), "residual shape mismatch");
    TORCH_CHECK(weight.dim() == 1 && weight.size(0) == x.size(1),
                "weight shape mismatch");
    TORCH_CHECK(bias.dim() == 1 && bias.size(0) == x.size(1),
                "bias shape mismatch");
    TORCH_CHECK(
        residual.device() == x.device() &&
        weight.device() == x.device() &&
        bias.device() == x.device(),
        "all inputs must be on the same device");
    TORCH_CHECK(
        residual.scalar_type() == at::kFloat &&
        weight.scalar_type() == at::kFloat &&
        bias.scalar_type() == at::kFloat,
        "all inputs must be float32");
    TORCH_CHECK(x.is_contiguous() && residual.is_contiguous() &&
                weight.is_contiguous() && bias.is_contiguous(),
                "all inputs must be contiguous");

    const c10::cuda::CUDAGuard guard(x.device());
    const int64_t m = x.size(0);
    const int64_t n = x.size(1);
    auto out = torch::empty({m, 2 * n}, x.options());
    const auto stream = at::cuda::getCurrentCUDAStream(x.get_device());

    const float* xp = x.data_ptr<float>();
    const float* rp = residual.data_ptr<float>();
    const float* wp = weight.data_ptr<float>();
    const float* bp = bias.data_ptr<float>();
    float* op = out.data_ptr<float>();
    const float epsilon = static_cast<float>(eps);

    #define LAUNCH(B, K) \
        hipLaunchKernelGGL((fused_rows<B, K>), dim3(m), dim3(B), \
                           0, stream.stream(), xp, rp, wp, bp, op, n, epsilon)

    if      (n <= 64)    { LAUNCH(64, 1); }
    else if (n <= 128)   { LAUNCH(64, 2); }
    else if (n <= 256)   { LAUNCH(128, 2); }
    else if (n <= 512)   { LAUNCH(128, 4); }
    else if (n <= 1024)  { LAUNCH(256, 4); }
    else if (n <= 2048)  { LAUNCH(256, 8); }
    else if (n <= 4096)  { LAUNCH(256, 16); }
    else if (n <= 8192)  { LAUNCH(256, 32); }
    else if (n <= 16384) { LAUNCH(256, 64); }
    else {
        hipLaunchKernelGGL(long_rows, dim3(m), dim3(256), 0,
                           stream.stream(), xp, rp, wp, bp, op, n, epsilon);
    }
    #undef LAUNCH

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (_CPP_SOURCE + _HIP_SOURCE).encode("utf-8")
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"fused_residual_ln_{digest}",
            cpp_sources=_CPP_SOURCE,
            cuda_sources=_HIP_SOURCE,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        self.eps = float(eps)

    def forward(self, x, residual, weight, bias):
        return _get_extension().forward(x, residual, weight, bias, self.eps)
```