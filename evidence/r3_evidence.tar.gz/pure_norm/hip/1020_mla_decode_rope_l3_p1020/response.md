```python
import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

void pyramid_run(
    torch::Tensor q,
    torch::Tensor kv_cache,
    torch::Tensor cos_sin_cache,
    torch::Tensor positions,
    torch::Tensor kv_indptr,
    torch::Tensor kv_indices,
    torch::Tensor out,
    double sm_scale,
    int64_t c,
    int64_t rd,
    bool neox);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &pyramid_run, "Fused MLA decode attention");
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>
#include <limits>

template <typename T>
__device__ __forceinline__ float cvt(T x) {
    return static_cast<float>(x);
}

template <typename T>
__device__ __forceinline__ float rotated_value(
    const T* x,
    const T* cs,
    int d,
    int r,
    int rd,
    int half,
    bool neox)
{
    if (d >= rd) return cvt(x[d]);

    int pair;
    bool first;
    if (neox) {
        if (d < half) {
            pair = d;
            first = true;
        } else {
            pair = d - half;
            first = false;
        }
    } else {
        pair = d >> 1;
        first = ((d & 1) == 0);
    }

    float a, b;
    if (neox) {
        a = cvt(x[pair]);
        b = cvt(x[pair + half]);
    } else {
        a = cvt(x[pair * 2]);
        b = cvt(x[pair * 2 + 1]);
    }

    float co = cvt(cs[pair]);
    float si = cvt(cs[half + pair]);
    return first ? (a * co - b * si) : (b * co + a * si);
}

template <typename scalar_t>
__global__ void mla_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ kv,
    const scalar_t* __restrict__ cs_cache,
    const int32_t* __restrict__ positions,
    const int32_t* __restrict__ indptr,
    const int32_t* __restrict__ indices,
    scalar_t* __restrict__ out,
    float* __restrict__ logits,
    int B,
    int H,
    int D,
    int c,
    int r,
    int rd,
    int half,
    int total_tokens,
    float sm_scale,
    bool neox)
{
    int bh = blockIdx.x;
    int b = bh / H;
    int h = bh - b * H;
    int tid = threadIdx.x;

    if (b >= B) return;

    int s0 = indptr[b];
    int s1 = indptr[b + 1];
    int S = s1 - s0;
    int pos = positions[b];

    const scalar_t* qh = q + ((int64_t)b * H + h) * D;
    const scalar_t* cs = cs_cache + (int64_t)pos * rd;
    float* lbase = logits + ((int64_t)b * H + h) * total_tokens;

    for (int j = tid; j < S; j += blockDim.x) {
        int phys = indices[s0 + j];
        const scalar_t* row = kv + (int64_t)phys * D;
        float dot = 0.0f;

        for (int d = 0; d < c; ++d)
            dot += cvt(qh[d]) * cvt(row[d]);

        for (int d = 0; d < r; ++d) {
            float qv = rotated_value(qh + c, cs, d, r, rd, half, neox);
            float kvv;
            if (j == S - 1)
                kvv = rotated_value(row + c, cs, d, r, rd, half, neox);
            else
                kvv = cvt(row[c + d]);
            dot += qv * kvv;
        }

        lbase[s0 + j] = dot * sm_scale;
    }

    __shared__ float red[256];
    float local_max = -CUDART_INF_F;
    for (int j = tid; j < S; j += blockDim.x)
        local_max = fmaxf(local_max, lbase[s0 + j]);

    red[tid] = local_max;
    __syncthreads();

    for (int stride = blockDim.x >> 1; stride > 0; stride >>= 1) {
        if (tid < stride)
            red[tid] = fmaxf(red[tid], red[tid + stride]);
        __syncthreads();
    }
    float maxv = red[0];

    float local_sum = 0.0f;
    for (int j = tid; j < S; j += blockDim.x) {
        float e = expf(lbase[s0 + j] - maxv);
        lbase[s0 + j] = e;
        local_sum += e;
    }

    red[tid] = local_sum;
    __syncthreads();

    for (int stride = blockDim.x >> 1; stride > 0; stride >>= 1) {
        if (tid < stride)
            red[tid] += red[tid + stride];
        __syncthreads();
    }
    float denom = red[0];

    for (int d = tid; d < c; d += blockDim.x) {
        float acc = 0.0f;
        for (int j = 0; j < S; ++j) {
            int phys = indices[s0 + j];
            const scalar_t* row = kv + (int64_t)phys * D;
            acc += (lbase[s0 + j] / denom) * cvt(row[d]);
        }
        out[((int64_t)b * H + h) * c + d] = static_cast<scalar_t>(acc);
    }

    if (h == 0) {
        int phys = indices[s1 - 1];
        const scalar_t* row = kv + (int64_t)phys * D;
        scalar_t* kout = out + (int64_t)B * H * c + (int64_t)b * r;

        for (int d = tid; d < r; d += blockDim.x) {
            float v = rotated_value(row + c, cs, d, r, rd, half, neox);
            kout[d] = static_cast<scalar_t>(v);
        }
    }
}

void pyramid_run(
    torch::Tensor q,
    torch::Tensor kv_cache,
    torch::Tensor cos_sin_cache,
    torch::Tensor positions,
    torch::Tensor kv_indptr,
    torch::Tensor kv_indices,
    torch::Tensor out,
    double sm_scale,
    int64_t c,
    int64_t rd,
    bool neox)
{
    int B = static_cast<int>(q.size(0));
    int H = static_cast<int>(q.size(1));
    int D = static_cast<int>(q.size(2));
    int r = D - static_cast<int>(c);
    int total = static_cast<int>(kv_indices.numel());
    int half = static_cast<int>(rd / 2);

    auto opts = torch::TensorOptions()
        .dtype(torch::kFloat32)
        .device(q.device());
    auto logits = torch::empty({(int64_t)B * H * total}, opts);

    hipStream_t stream = at::cuda::getDefaultCUDAStream(q.device().index());

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        q.scalar_type(),
        "mla_kernel",
        [&] {
            mla_kernel<scalar_t><<<B * H, 256, 0, stream>>>(
                q.data_ptr<scalar_t>(),
                kv_cache.data_ptr<scalar_t>(),
                cos_sin_cache.data_ptr<scalar_t>(),
                positions.data_ptr<int32_t>(),
                kv_indptr.data_ptr<int32_t>(),
                kv_indices.data_ptr<int32_t>(),
                out.data_ptr<scalar_t>(),
                logits.data_ptr<float>(),
                B, H, D, static_cast<int>(c), r,
                static_cast<int>(rd), half, total,
                static_cast<float>(sm_scale), neox);
        });
}

"""

def _strip_markers(s):
    return "\n".join(
        line for line in s.splitlines()
        if not line.lstrip().startswith("# <<<")
    )

def _extension_name():
    digest = hashlib.sha1(
        (_strip_markers(CUDA_CPP_SRC) + _strip_markers(CUDA_CU_SRC)).encode()
    ).hexdigest()[:12]
    return "pyramidkernel_mla_" + digest

def _get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_extension_name(),
            cpp_sources=_strip_markers(CUDA_CPP_SRC),
            cuda_sources=_strip_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION


class ModelNew(nn.Module):
    def __init__(
        self,
        kv_lora_rank: int,
        qk_rope_head_dim: int,
        rotary_dim: int,
        sm_scale=None,
        is_neox_style=True,
    ):
        super().__init__()
        self.kv_lora_rank = int(kv_lora_rank)
        self.qk_rope_head_dim = int(qk_rope_head_dim)
        self.rotary_dim = int(rotary_dim)
        self.sm_scale = (
            float(sm_scale)
            if sm_scale is not None
            else 1.0 / math.sqrt(self.kv_lora_rank + self.qk_rope_head_dim)
        )
        self.is_neox_style = bool(is_neox_style)

    def forward(self, q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices):
        q = q.contiguous()
        kv_cache = kv_cache.contiguous()
        cos_sin_cache = cos_sin_cache.contiguous()
        positions = positions.to(dtype=torch.int32).contiguous()
        kv_indptr = kv_indptr.to(dtype=torch.int32).contiguous()
        kv_indices = kv_indices.to(dtype=torch.int32).contiguous()

        B, H, D = q.shape
        c = self.kv_lora_rank
        r = D - c

        if r != self.qk_rope_head_dim:
            raise ValueError("q's last dim must equal kv_lora_rank + qk_rope_head_dim")
        if self.rotary_dim > r or (self.rotary_dim & (self.rotary_dim - 1)) != 0:
            raise ValueError("rotary_dim must be a power of two and no larger than r")

        out = torch.empty(
            B * H * c + B * r,
            dtype=q.dtype,
            device=q.device,
        )

        _get_extension().run(
            q,
            kv_cache,
            cos_sin_cache,
            positions,
            kv_indptr,
            kv_indices,
            out,
            float(self.sm_scale),
            int(c),
            int(self.rotary_dim),
            bool(self.is_neox_style),
        )
        return out
```