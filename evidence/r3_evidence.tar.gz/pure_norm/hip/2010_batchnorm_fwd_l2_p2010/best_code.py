import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None


def _strip_markers(source):
    return "\n".join(
        line for line in source.splitlines()
        if not line.lstrip().startswith("# <<<")
    )


def _extension_name():
    payload = _strip_markers(CUDA_CPP_SRC) + _strip_markers(CUDA_CU_SRC)
    return "pyramidkernel_bn_" + hashlib.sha1(payload.encode()).hexdigest()[:12]


def _get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_extension_name(),
            cpp_sources=_strip_markers(CUDA_CPP_SRC),
            cuda_sources=_strip_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION


CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor bn_inference(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor mean,
    torch::Tensor variance,
    double eps);

torch::Tensor bn_training(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor running_mean,
    torch::Tensor running_var,
    double eps,
    double momentum);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("bn_inference", &bn_inference);
    m.def("bn_training", &bn_training);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cmath>

template <typename T>
__device__ __forceinline__ float as_float(T v) {
    return static_cast<float>(v);
}

template <typename T>
__device__ __forceinline__ T from_float(float v) {
    return static_cast<T>(v);
}

template <typename scalar_t>
__global__ void inference_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ scale,
    const scalar_t* __restrict__ bias,
    const scalar_t* __restrict__ mean,
    const scalar_t* __restrict__ variance,
    scalar_t* __restrict__ out,
    int64_t total,
    int C,
    int HW,
    float eps) {
    int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= total) return;

    int c = static_cast<int>((i / HW) % C);
    float xv = as_float(x[i]);
    float s = as_float(scale[c]);
    float b = as_float(bias[c]);
    float mu = as_float(mean[c]);
    float var = as_float(variance[c]);

    float y = (xv - mu) * rsqrtf(var + eps) * s + b;
    out[i] = from_float<scalar_t>(y);
}

template <typename scalar_t>
__global__ void statistics_kernel(
    const scalar_t* __restrict__ x,
    float* __restrict__ batch_mean,
    float* __restrict__ batch_inv,
    float* __restrict__ batch_var,
    int C,
    int M,
    int HW,
    float eps) {
    int c = blockIdx.x;
    int tid = threadIdx.x;

    __shared__ float smem[256];

    float sum = 0.0f;
    for (int j = tid; j < M; j += blockDim.x) {
        int n = j / HW;
        int k = j - n * HW;
        sum += as_float(x[(static_cast<int64_t>(n) * C + c) * HW + k]);
    }

    smem[tid] = sum;
    __syncthreads();

    for (int stride = 128; stride > 0; stride >>= 1) {
        if (tid < stride) smem[tid] += smem[tid + stride];
        __syncthreads();
    }

    float mu = smem[0] / static_cast<float>(M);
    if (tid == 0) batch_mean[c] = mu;
    __syncthreads();

    float sq = 0.0f;
    for (int j = tid; j < M; j += blockDim.x) {
        int n = j / HW;
        int k = j - n * HW;
        float v = as_float(x[(static_cast<int64_t>(n) * C + c) * HW + k]);
        float d = v - mu;
        sq += d * d;
    }

    smem[tid] = sq;
    __syncthreads();

    for (int stride = 128; stride > 0; stride >>= 1) {
        if (tid < stride) smem[tid] += smem[tid + stride];
        __syncthreads();
    }

    if (tid == 0) {
        float var = smem[0] / static_cast<float>(M);
        batch_var[c] = var;
        batch_inv[c] = rsqrtf(var + eps);
    }
}

template <typename scalar_t>
__global__ void training_output_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ scale,
    const scalar_t* __restrict__ bias,
    const scalar_t* __restrict__ running_mean,
    const scalar_t* __restrict__ running_var,
    const float* __restrict__ batch_mean,
    const float* __restrict__ batch_inv,
    const float* __restrict__ batch_var,
    float* __restrict__ out,
    int64_t total_x,
    int C,
    int HW,
    int M,
    float momentum) {
    int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    int64_t total = total_x + static_cast<int64_t>(4) * C;
    if (i >= total) return;

    if (i < total_x) {
        int c = static_cast<int>((i / HW) % C);
        float xv = as_float(x[i]);
        float y = (xv - batch_mean[c]) * batch_inv[c] *
                  as_float(scale[c]) + as_float(bias[c]);
        out[i] = y;
        return;
    }

    int64_t q = i - total_x;
    if (q < C) {
        int c = static_cast<int>(q);
        out[total_x + c] = batch_mean[c];
    } else if (q < 2LL * C) {
        int c = static_cast<int>(q - C);
        out[total_x + C + c] = batch_inv[c];
    } else if (q < 3LL * C) {
        int c = static_cast<int>(q - 2LL * C);
        float oldv = as_float(running_mean[c]);
        out[total_x + 2LL * C + c] =
            (1.0f - momentum) * oldv + momentum * batch_mean[c];
    } else {
        int c = static_cast<int>(q - 3LL * C);
        float oldv = as_float(running_var[c]);
        float unbiased = batch_var[c] *
                         (static_cast<float>(M) / static_cast<float>(M - 1));
        out[total_x + 3LL * C + c] =
            (1.0f - momentum) * oldv + momentum * unbiased;
    }
}

template <typename scalar_t>
void launch_inference(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor mean,
    torch::Tensor variance,
    torch::Tensor out,
    float eps) {
    int N = static_cast<int>(x.size(0));
    int C = static_cast<int>(x.size(1));
    int H = static_cast<int>(x.size(2));
    int W = static_cast<int>(x.size(3));
    int HW = H * W;
    int64_t total = x.numel();

    auto stream = at::cuda::getDefaultCUDAStream();
    constexpr int threads = 256;
    int blocks = static_cast<int>((total + threads - 1) / threads);

    hipLaunchKernelGGL(
        inference_kernel<scalar_t>,
        dim3(blocks), dim3(threads), 0, stream,
        x.data_ptr<scalar_t>(),
        scale.data_ptr<scalar_t>(),
        bias.data_ptr<scalar_t>(),
        mean.data_ptr<scalar_t>(),
        variance.data_ptr<scalar_t>(),
        out.data_ptr<scalar_t>(),
        total, C, HW, eps);
}

template <typename scalar_t>
void launch_training(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor running_mean,
    torch::Tensor running_var,
    torch::Tensor out,
    float eps,
    float momentum) {
    int N = static_cast<int>(x.size(0));
    int C = static_cast<int>(x.size(1));
    int H = static_cast<int>(x.size(2));
    int W = static_cast<int>(x.size(3));
    int HW = H * W;
    int M = N * HW;
    int64_t total_x = x.numel();

    auto mean = torch::empty({C}, x.options().dtype(torch::kFloat));
    auto inv = torch::empty({C}, x.options().dtype(torch::kFloat));
    auto var = torch::empty({C}, x.options().dtype(torch::kFloat));

    auto stream = at::cuda::getDefaultCUDAStream();
    constexpr int threads = 256;

    hipLaunchKernelGGL(
        statistics_kernel<scalar_t>,
        dim3(C), dim3(threads), 0, stream,
        x.data_ptr<scalar_t>(),
        mean.data_ptr<float>(),
        inv.data_ptr<float>(),
        var.data_ptr<float>(),
        C, M, HW, eps);

    int64_t total = total_x + static_cast<int64_t>(4) * C;
    int blocks = static_cast<int>((total + threads - 1) / threads);

    hipLaunchKernelGGL(
        training_output_kernel<scalar_t>,
        dim3(blocks), dim3(threads), 0, stream,
        x.data_ptr<scalar_t>(),
        scale.data_ptr<scalar_t>(),
        bias.data_ptr<scalar_t>(),
        running_mean.data_ptr<scalar_t>(),
        running_var.data_ptr<scalar_t>(),
        mean.data_ptr<float>(),
        inv.data_ptr<float>(),
        var.data_ptr<float>(),
        out.data_ptr<float>(),
        total_x, C, HW, M, momentum);
}

torch::Tensor bn_inference(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor mean,
    torch::Tensor variance,
    double eps) {
    auto out = torch::empty_like(x);

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "bn_inference",
        [&] {
            launch_inference<scalar_t>(
                x, scale, bias, mean, variance, out,
                static_cast<float>(eps));
        });

    return out;
}

torch::Tensor bn_training(
    torch::Tensor x,
    torch::Tensor scale,
    torch::Tensor bias,
    torch::Tensor running_mean,
    torch::Tensor running_var,
    double eps,
    double momentum) {
    int64_t total = x.numel() + static_cast<int64_t>(4) * x.size(1);
    auto out = torch::empty(
        {total},
        x.options().dtype(torch::kFloat));

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half,
        at::ScalarType::BFloat16,
        x.scalar_type(),
        "bn_training",
        [&] {
            launch_training<scalar_t>(
                x, scale, bias, running_mean, running_var, out,
                static_cast<float>(eps),
                static_cast<float>(momentum));
        });

    return out;
}
"""


class ModelNew(nn.Module):
    def __init__(self, variant: str = "training", eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        assert variant in ("inference", "training"), \
            "variant must be one of inference / training"
        assert eps > 0, "eps must be positive"
        assert 0.0 <= momentum <= 1.0, "momentum must be in [0, 1]"
        self.variant = variant
        self.eps = float(eps)
        self.momentum = float(momentum)

    def forward(self, x, scale, bias, mean, variance):
        ext = _get_extension()

        if self.variant == "inference":
            return ext.bn_inference(
                x, scale, bias, mean, variance, self.eps
            )

        m = x.shape[0] * x.shape[2] * x.shape[3]
        assert m >= 2, (
            "the training variant requires N*H*W >= 2 "
            "(the m/(m-1) unbiased correction factor of the running variance)"
        )

        return ext.bn_training(
            x, scale, bias, mean, variance,
            self.eps, self.momentum
        )
