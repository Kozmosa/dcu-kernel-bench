```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor deform_forward(
    torch::Tensor x, torch::Tensor offset, torch::Tensor weight,
    torch::Tensor bias, torch::Tensor mask,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw, bool modulated);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &deform_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template<class T, bool Modulated>
__global__ void sample_kernel(
    const T* __restrict__ x, const T* __restrict__ offset,
    const T* __restrict__ mask, float* __restrict__ columns,
    int C, int H, int W, int R, int S, int OH, int OW,
    int sh, int sw, int ph, int pw, int dh, int dw,
    int64_t count)
{
    const int P = R*S;
    const int L = OH*OW;
    for (int64_t index = (int64_t)blockIdx.x*blockDim.x + threadIdx.x;
         index < count; index += (int64_t)gridDim.x*blockDim.x) {
        const int t = index % L;
        const int p = (index / L) % P;
        const int c = (index / ((int64_t)L*P)) % C;
        const int n = index / ((int64_t)L*P*C);
        const int64_t offbase = ((int64_t)n*2*P + 2*p)*L + t;
        const float y = float((t/OW)*sh - ph + (p/S)*dh)
                      + float(offset[offbase]);
        const float z = float((t%OW)*sw - pw + (p%S)*dw)
                      + float(offset[offbase + L]);
        float value = 0.0f;
        if (y > -1.0f && y < H && z > -1.0f && z < W) {
            const int iy = (int)floorf(y);
            const int ix = (int)floorf(z);
            const float wy = y - float(iy);
            const float wx = z - float(ix);
            const float a = (1.0f-wy)*(1.0f-wx);
            const float b = (1.0f-wy)*wx;
            const float cc = wy*(1.0f-wx);
            const float d = wy*wx;
            const T* image = x + ((int64_t)n*C+c)*H*W;
            float v00 = 0, v01 = 0, v10 = 0, v11 = 0;
            if (iy >= 0 && ix >= 0)
                v00 = float(image[(int64_t)iy*W+ix]);
            if (iy >= 0 && ix+1 < W)
                v01 = float(image[(int64_t)iy*W+ix+1]);
            if (iy+1 < H && ix >= 0)
                v10 = float(image[(int64_t)(iy+1)*W+ix]);
            if (iy+1 < H && ix+1 < W)
                v11 = float(image[(int64_t)(iy+1)*W+ix+1]);
            value = ((v00*a + v01*b) + v10*cc) + v11*d;
        }
        if (Modulated)
            value *= float(mask[((int64_t)n*P+p)*L+t]);
        columns[index] = value;
    }
}

template<class T>
__global__ __launch_bounds__(256)
void product_kernel(
    const T* __restrict__ weight,
    const float* __restrict__ columns,
    const T* __restrict__ bias,
    T* __restrict__ output, int K, int D, int L)
{
    __shared__ float as[32][16];
    __shared__ float bs[16][64];
    const int tid = threadIdx.x;
    const int tx = tid & 15;
    const int ty = tid >> 4;
    const int rowbase = blockIdx.y*32;
    const int colbase = blockIdx.x*64;
    const int n = blockIdx.z;
    const float* bptr = columns + (int64_t)n*D*L;
    float acc[2][4] = {};
    for (int base = 0; base < D; base += 16) {
        #pragma unroll
        for (int j = 0; j < 2; ++j) {
            const int z = tid+j*256;
            const int r = z/16;
            const int q = z%16;
            as[r][q] = (rowbase+r < K && base+q < D)
                ? float(weight[(int64_t)(rowbase+r)*D+base+q]) : 0.0f;
        }
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int z = tid+j*256;
            const int q = z/64;
            const int t = z%64;
            bs[q][t] = (base+q < D && colbase+t < L)
                ? bptr[(int64_t)(base+q)*L+colbase+t] : 0.0f;
        }
        __syncthreads();
        #pragma unroll
        for (int q = 0; q < 16; ++q) {
            float aa0 = as[ty][q];
            float aa1 = as[ty+16][q];
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                const float bb = bs[q][tx+16*j];
                acc[0][j] = fmaf(aa0, bb, acc[0][j]);
                acc[1][j] = fmaf(aa1, bb, acc[1][j]);
            }
        }
        __syncthreads();
    }
    #pragma unroll
    for (int i = 0; i < 2; ++i) {
        const int row = rowbase+ty+16*i;
        if (row < K) {
            const float bv = float(bias[row]);
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                const int col = colbase+tx+16*j;
                if (col < L)
                    output[((int64_t)n*K+row)*L+col] = T(acc[i][j]+bv);
            }
        }
    }
}

torch::Tensor deform_forward(
    torch::Tensor x, torch::Tensor offset, torch::Tensor weight,
    torch::Tensor bias, torch::Tensor mask,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw, bool modulated)
{
    TORCH_CHECK(x.is_cuda(), "Expected accelerator tensors");
    c10::cuda::CUDAGuard guard(x.device());
    TORCH_CHECK(x.is_contiguous() && offset.is_contiguous() &&
                weight.is_contiguous() && bias.is_contiguous() &&
                mask.is_contiguous(), "Expected contiguous tensors");
    TORCH_CHECK(x.scalar_type() == offset.scalar_type() &&
                x.scalar_type() == weight.scalar_type() &&
                x.scalar_type() == bias.scalar_type() &&
                x.scalar_type() == mask.scalar_type(), "Dtypes must match");
    const int N=x.size(0), C=x.size(1), H=x.size(2), W=x.size(3);
    const int K=weight.size(0), R=weight.size(2), S=weight.size(3);
    TORCH_CHECK(sh > 0 && sw > 0 && dh > 0 && dw > 0,
                "Stride and dilation must be positive");
    const int OH=(H+2*ph-dh*(R-1)-1)/sh+1;
    const int OW=(W+2*pw-dw*(S-1)-1)/sw+1;
    TORCH_CHECK(OH > 0 && OW > 0, "Invalid output dimensions");
    TORCH_CHECK(weight.size(1)==C && bias.numel()==K,
                "Invalid weight or bias shape");
    TORCH_CHECK(offset.size(0)==N && offset.size(1)==2*R*S &&
                offset.size(2)==OH && offset.size(3)==OW &&
                mask.size(0)==N && mask.size(1)==R*S &&
                mask.size(2)==OH && mask.size(3)==OW,
                "Invalid offset or mask shape");
    const int D=C*R*S, L=OH*OW;
    auto output=torch::empty({N,K,OH,OW},x.options());
    if (N==0 || K==0) return output;
    auto columns=torch::empty({N,D,L},x.options().dtype(at::kFloat));
    const int64_t count=(int64_t)N*D*L;
    const int blocks=(int)std::min<int64_t>((count+255)/256,65535);
    auto stream=at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "deform_forward", [&] {
            if (count) {
                if (modulated)
                    sample_kernel<scalar_t,true><<<blocks,256,0,stream>>>(
                        x.data_ptr<scalar_t>(),offset.data_ptr<scalar_t>(),
                        mask.data_ptr<scalar_t>(),columns.data_ptr<float>(),
                        C,H,W,R,S,OH,OW,sh,sw,ph,pw,dh,dw,count);
                else
                    sample_kernel<scalar_t,false><<<blocks,256,0,stream>>>(
                        x.data_ptr<scalar_t>(),offset.data_ptr<scalar_t>(),
                        mask.data_ptr<scalar_t>(),columns.data_ptr<float>(),
                        C,H,W,R,S,OH,OW,sh,sw,ph,pw,dh,dw,count);
            }
            product_kernel<scalar_t><<<dim3((L+63)/64,(K+31)/32,N),
                                        256,0,stream>>>(
                weight.data_ptr<scalar_t>(),columns.data_ptr<float>(),
                bias.data_ptr<scalar_t>(),output.data_ptr<scalar_t>(),K,D,L);
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "deform_hip_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(
        self, variant: str = "modulated",
        stride=(1, 1), padding=(1, 1), dilation=(1, 1)
    ):
        super().__init__()
        assert variant in ("modulated", "plain"), \
            "variant must be either modulated or plain"
        self.variant = variant
        self.stride = (int(stride[0]), int(stride[1]))
        self.padding = (int(padding[0]), int(padding[1]))
        self.dilation = (int(dilation[0]), int(dilation[1]))

    def forward(self, x, offset, weight, bias, mask):
        return _get_extension().forward(
            x, offset, weight, bias, mask,
            self.stride[0], self.stride[1],
            self.padding[0], self.padding[1],
            self.dilation[0], self.dilation[1],
            self.variant == "modulated",
        )
```