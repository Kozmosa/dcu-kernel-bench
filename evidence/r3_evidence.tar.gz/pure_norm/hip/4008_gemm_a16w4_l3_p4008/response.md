```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor awq_forward(
    torch::Tensor input, torch::Tensor qweight,
    torch::Tensor scales, torch::Tensor qzeros);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &awq_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>
#include <algorithm>

template<class A, class S>
__global__ __launch_bounds__(256)
void awq_kernel(
    const A* __restrict__ input,
    const unsigned char* __restrict__ weights,
    const S* __restrict__ scales,
    const unsigned char* __restrict__ zeros,
    A* __restrict__ output,
    int M, int N, int K, int G)
{
    constexpr int BM = 32;
    constexpr int BN = 64;
    constexpr int BK = 32;
    __shared__ float as[BM][BK];
    __shared__ float bs[BK][BN + 1];

    const int t = threadIdx.x;
    const int row = t / 16;
    const int col = (t % 16) * 4;
    const int mbase = blockIdx.y * BM;
    const int nbase = blockIdx.x * BN;

    float acc[2][4] = {};

    for (int kb = 0; kb < K; kb += BK) {
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            const int p = t + i * 256;
            const int r = p / BK;
            const int k = p % BK;
            as[r][k] = (mbase + r < M && kb + k < K)
                ? static_cast<float>(input[(int64_t)(mbase + r) * K + kb + k])
                : 0.0f;
        }

        // Adjacent lanes read consecutive packed weights along K.
        #pragma unroll
        for (int i = 0; i < 8; ++i) {
            const int p = t + i * 256;
            const int n = p / BK;
            const int k = p % BK;
            const int gn = nbase + n;
            const int gk = kb + k;
            float value = 0.0f;
            if (gn < N && gk < K) {
                const int group = gk / G;
                const unsigned int packed =
                    weights[(int64_t)gn * (K / 2) + gk / 2];
                const unsigned int zp =
                    zeros[(int64_t)group * (N / 2) + gn / 2];
                const int w = (packed >> ((gk & 1) * 4)) & 15;
                const int z = (zp >> ((gn & 1) * 4)) & 15;
                value = float(w - z) *
                    static_cast<float>(scales[(int64_t)group * N + gn]);
            }
            bs[k][n] = value;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < BK; ++k) {
            const float a0 = as[row][k];
            const float a1 = as[row + 16][k];
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                const float b = bs[k][col + j];
                acc[0][j] = fmaf(a0, b, acc[0][j]);
                acc[1][j] = fmaf(a1, b, acc[1][j]);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 2; ++i) {
        const int m = mbase + row + i * 16;
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int n = nbase + col + j;
            if (m < M && n < N)
                output[(int64_t)m * N + n] = static_cast<A>(acc[i][j]);
        }
    }
}

template<class A, class S>
void launch(
    const torch::Tensor& input, const torch::Tensor& qweight,
    const torch::Tensor& scales, const torch::Tensor& qzeros,
    torch::Tensor& output, int M, int N, int K, int G,
    hipStream_t stream)
{
    const dim3 grid((N + 63) / 64, (M + 31) / 32);
    hipLaunchKernelGGL(
        (awq_kernel<A, S>), grid, dim3(256), 0, stream,
        input.data_ptr<A>(),
        reinterpret_cast<const unsigned char*>(qweight.data_ptr<int8_t>()),
        scales.data_ptr<S>(),
        reinterpret_cast<const unsigned char*>(qzeros.data_ptr<int8_t>()),
        output.data_ptr<A>(), M, N, K, G);
}

torch::Tensor awq_forward(
    torch::Tensor input, torch::Tensor qweight,
    torch::Tensor scales, torch::Tensor qzeros)
{
    TORCH_CHECK(input.is_cuda() && qweight.is_cuda() &&
                scales.is_cuda() && qzeros.is_cuda(), "Expected GPU tensors");
    TORCH_CHECK(input.device() == qweight.device() &&
                input.device() == scales.device() &&
                input.device() == qzeros.device(), "Device mismatch");
    TORCH_CHECK(input.dim() == 2 && qweight.dim() == 2 &&
                scales.dim() == 2 && qzeros.dim() == 2,
                "Expected two-dimensional tensors");
    TORCH_CHECK(input.is_contiguous() && qweight.is_contiguous() &&
                scales.is_contiguous() && qzeros.is_contiguous(),
                "Expected contiguous tensors");
    TORCH_CHECK(qweight.scalar_type() == at::kChar &&
                qzeros.scalar_type() == at::kChar,
                "Packed weights and zeros must be int8");
    TORCH_CHECK(input.scalar_type() == at::kFloat ||
                input.scalar_type() == at::kHalf,
                "Activations must be float32 or float16");
    TORCH_CHECK(scales.scalar_type() == at::kFloat ||
                scales.scalar_type() == at::kHalf,
                "Scales must be float32 or float16");

    const int64_t M64 = input.size(0);
    const int64_t K64 = input.size(1);
    const int64_t N64 = qweight.size(0);
    TORCH_CHECK(M64 <= INT_MAX && N64 <= INT_MAX && K64 <= INT_MAX,
                "Dimensions exceed supported range");
    const int M = M64, N = N64, K = K64;
    TORCH_CHECK(K > 0 && K % 2 == 0 && N % 2 == 0,
                "Packed dimensions must be even");
    TORCH_CHECK(qzeros.size(0) > 0 && K % qzeros.size(0) == 0,
                "Invalid quantization groups");
    TORCH_CHECK(qweight.size(1) == K / 2 &&
                qzeros.size(1) == N / 2 &&
                scales.size(0) == qzeros.size(0) &&
                scales.size(1) == N, "Invalid quantization shapes");

    const c10::cuda::CUDAGuard guard(input.device());
    auto output = torch::empty({M64, N64}, input.options());
    if (M == 0 || N == 0) return output;
    const int G = K / qzeros.size(0);
    hipStream_t stream = c10::cuda::getCurrentCUDAStream(input.get_device()).stream();

    if (input.scalar_type() == at::kFloat) {
        if (scales.scalar_type() == at::kFloat)
            launch<float, float>(input, qweight, scales, qzeros, output,
                                 M, N, K, G, stream);
        else
            launch<float, at::Half>(input, qweight, scales, qzeros, output,
                                    M, N, K, G, stream);
    } else {
        if (scales.scalar_type() == at::kFloat)
            launch<at::Half, float>(input, qweight, scales, qzeros, output,
                                    M, N, K, G, stream);
        else
            launch<at::Half, at::Half>(input, qweight, scales, qzeros, output,
                                       M, N, K, G, stream);
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha256((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"awq_fused_hip_{digest}",
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int, group_size: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.group_size = group_size

    def forward(self, input, qweight, scales, qzeros):
        return _get_extension().forward(input, qweight, scales, qzeros)
```