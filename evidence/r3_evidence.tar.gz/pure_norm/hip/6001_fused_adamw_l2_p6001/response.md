```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_PyramidKernel_EXTENSION = None


CUDA_CPP_SRC = r"""
#include <torch/extension.h>

at::Tensor pyramidkernel_adamw_forward(
    const at::Tensor& params,
    const at::Tensor& grads,
    const at::Tensor& exp_avg,
    const at::Tensor& exp_avg_sq,
    const at::Tensor& step,
    double lr,
    double beta1,
    double beta2,
    double eps,
    double weight_decay,
    bool bias_correction);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("adamw_forward", &pyramidkernel_adamw_forward);
}
"""


CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <ATen/Dispatch.h>
#include <hip/hip_runtime.h>
#include <c10/util/Half.h>

template <typename scalar_t>
__global__ void pyramidkernel_adamw_kernel(
    const scalar_t* __restrict__ params,
    const scalar_t* __restrict__ grads,
    const scalar_t* __restrict__ exp_avg,
    const scalar_t* __restrict__ exp_avg_sq,
    const float* __restrict__ step,
    scalar_t* __restrict__ output,
    int64_t n,
    float lr,
    float beta1,
    float beta2,
    float eps,
    float weight_decay,
    bool bias_correction) {
    const int64_t i =
        static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;

    if (i >= n) {
        return;
    }

    const float p = static_cast<float>(params[i]);
    const float g = static_cast<float>(grads[i]);
    const float m0 = static_cast<float>(exp_avg[i]);
    const float v0 = static_cast<float>(exp_avg_sq[i]);

    const float m = beta1 * m0 + (1.0f - beta1) * g;
    const float v = beta2 * v0 + (1.0f - beta2) * g * g;

    float update;
    if (bias_correction) {
        const float s = step[0];
        const float bc1 = 1.0f - powf(beta1, s);
        const float bc2 = 1.0f - powf(beta2, s);
        const float denom = sqrtf(v / bc2) + eps;
        update = (m / bc1) / denom;
    } else {
        const float denom = sqrtf(v) + eps;
        update = m / denom;
    }

    const float decayed = p * (1.0f - lr * weight_decay);
    output[i] = static_cast<scalar_t>(decayed - lr * update);
}


at::Tensor pyramidkernel_adamw_forward(
    const at::Tensor& params,
    const at::Tensor& grads,
    const at::Tensor& exp_avg,
    const at::Tensor& exp_avg_sq,
    const at::Tensor& step,
    double lr,
    double beta1,
    double beta2,
    double eps,
    double weight_decay,
    bool bias_correction) {
    TORCH_CHECK(params.is_cuda(), "params must be a CUDA/HIP tensor");
    TORCH_CHECK(grads.is_cuda(), "grads must be a CUDA/HIP tensor");
    TORCH_CHECK(exp_avg.is_cuda(), "exp_avg must be a CUDA/HIP tensor");
    TORCH_CHECK(exp_avg_sq.is_cuda(), "exp_avg_sq must be a CUDA/HIP tensor");
    TORCH_CHECK(step.is_cuda(), "step must be a CUDA/HIP tensor");

    TORCH_CHECK(params.is_contiguous(), "params must be contiguous");
    TORCH_CHECK(grads.is_contiguous(), "grads must be contiguous");
    TORCH_CHECK(exp_avg.is_contiguous(), "exp_avg must be contiguous");
    TORCH_CHECK(exp_avg_sq.is_contiguous(), "exp_avg_sq must be contiguous");

    TORCH_CHECK(params.scalar_type() == at::kFloat ||
                params.scalar_type() == at::kHalf,
                "params must be float32 or float16");
    TORCH_CHECK(grads.scalar_type() == params.scalar_type(),
                "grads dtype must match params dtype");
    TORCH_CHECK(exp_avg.scalar_type() == params.scalar_type(),
                "exp_avg dtype must match params dtype");
    TORCH_CHECK(exp_avg_sq.scalar_type() == params.scalar_type(),
                "exp_avg_sq dtype must match params dtype");
    TORCH_CHECK(step.scalar_type() == at::kFloat,
                "step must be float32");
    TORCH_CHECK(step.dim() == 0 && step.numel() == 1,
                "step must be a scalar tensor");
    TORCH_CHECK(params.sizes() == grads.sizes() &&
                params.sizes() == exp_avg.sizes() &&
                params.sizes() == exp_avg_sq.sizes(),
                "all state tensors must have the same shape");

    auto output = torch::empty_like(params);
    const int64_t n = params.numel();
    constexpr int threads = 256;
    const int blocks = static_cast<int>((n + threads - 1) / threads);
    auto stream = at::cuda::getDefaultCUDAStream(params.device().index());

    AT_DISPATCH_FLOATING_TYPES_AND_HALF(
        params.scalar_type(),
        "pyramidkernel_adamw_forward",
        [&] {
            pyramidkernel_adamw_kernel<scalar_t>
                <<<blocks, threads, 0, stream.stream()>>>(
                    params.data_ptr<scalar_t>(),
                    grads.data_ptr<scalar_t>(),
                    exp_avg.data_ptr<scalar_t>(),
                    exp_avg_sq.data_ptr<scalar_t>(),
                    step.data_ptr<float>(),
                    output.data_ptr<scalar_t>(),
                    n,
                    static_cast<float>(lr),
                    static_cast<float>(beta1),
                    static_cast<float>(beta2),
                    static_cast<float>(eps),
                    static_cast<float>(weight_decay),
                    bias_correction);
        });

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""


def _pyramidkernel_extension_name():
    digest = hashlib.sha1(
        (CUDA_CPP_SRC + CUDA_CU_SRC).encode("utf-8")
    ).hexdigest()[:12]
    return f"pyramidkernel_adamw_{digest}"


def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION


class ModelNew(nn.Module):
    def __init__(
        self,
        variant: str = "adamw",
        lr: float = 1e-3,
        beta1: float = 0.9,
        beta2: float = 0.999,
        eps: float = 1e-8,
        weight_decay: float = 0.01,
    ):
        super().__init__()
        assert variant in ("adamw", "transformer_adamw"), (
            "variant must be one of adamw / transformer_adamw"
        )
        self.variant = variant
        self.lr = float(lr)
        self.beta1 = float(beta1)
        self.beta2 = float(beta2)
        self.eps = float(eps)
        self.weight_decay = float(weight_decay)

    def forward(self, params, grads, exp_avg, exp_avg_sq, step):
        if not torch.is_tensor(step):
            step = torch.tensor(
                float(step),
                dtype=torch.float32,
                device=params.device,
            )

        return _pyramidkernel_get_extension().adamw_forward(
            params,
            grads,
            exp_avg,
            exp_avg_sq,
            step,
            self.lr,
            self.beta1,
            self.beta2,
            self.eps,
            self.weight_decay,
            self.variant == "adamw",
        )
```