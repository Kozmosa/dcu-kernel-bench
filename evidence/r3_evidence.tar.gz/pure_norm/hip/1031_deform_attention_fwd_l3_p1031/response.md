```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor deform_forward(
    torch::Tensor value,
    torch::Tensor shapes,
    torch::Tensor starts,
    torch::Tensor locations,
    torch::Tensor scores);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &deform_forward);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>
#include <algorithm>

namespace {

constexpr int BLOCK = 128;
constexpr int TILE = 64;

__device__ __forceinline__ int64_t read_index(
    const void* p, int64_t i, int kind)
{
    if (kind == 0) return static_cast<const int64_t*>(p)[i];
    if (kind == 1) return static_cast<int64_t>(static_cast<const float*>(p)[i]);
    return static_cast<const int32_t*>(p)[i];
}

template <typename scalar_t>
__global__ void deform_kernel(
    const scalar_t* __restrict__ value,
    const void* __restrict__ shapes,
    const void* __restrict__ starts,
    const scalar_t* __restrict__ locations,
    const scalar_t* __restrict__ scores,
    scalar_t* __restrict__ output,
    int64_t rows, int64_t keys, int64_t heads, int64_t channels,
    int64_t queries, int64_t points, int64_t samples,
    int shape_kind, int start_kind)
{
    __shared__ float reduction[BLOCK];
    __shared__ int64_t indices[4][TILE];
    __shared__ float coefficients[4][TILE];
    __shared__ float probabilities[TILE];

    const int t = threadIdx.x;
    const int64_t d = static_cast<int64_t>(blockIdx.y) * BLOCK + t;

    for (int64_t row = blockIdx.x; row < rows; row += gridDim.x) {
        const int64_t head = row % heads;
        const int64_t batch = row / (queries * heads);
        const int64_t sample_base = row * samples;

        float maximum = -INFINITY;
        for (int64_t k = t; k < samples; k += BLOCK)
            maximum = fmaxf(maximum, static_cast<float>(scores[sample_base + k]));

        reduction[t] = maximum;
        __syncthreads();
        for (int stride = BLOCK / 2; stride; stride >>= 1) {
            if (t < stride)
                reduction[t] = fmaxf(reduction[t], reduction[t + stride]);
            __syncthreads();
        }
        maximum = reduction[0];
        __syncthreads();

        float denominator = 0.0f;
        for (int64_t k = t; k < samples; k += BLOCK)
            denominator += expf(static_cast<float>(scores[sample_base + k]) - maximum);
        reduction[t] = denominator;
        __syncthreads();
        for (int stride = BLOCK / 2; stride; stride >>= 1) {
            if (t < stride)
                reduction[t] += reduction[t + stride];
            __syncthreads();
        }
        const float reciprocal = 1.0f / reduction[0];
        __syncthreads();

        float result = 0.0f;
        for (int64_t first = 0; first < samples; first += TILE) {
            const int count = static_cast<int>(
                samples - first < TILE ? samples - first : TILE);
            if (t < count) {
                const int64_t k = first + t;
                const int64_t level = k / points;
                const int64_t height = read_index(shapes, level * 2, shape_kind);
                const int64_t width = read_index(shapes, level * 2 + 1, shape_kind);
                const int64_t base = read_index(starts, level, start_kind);

                const float x = static_cast<float>(
                    locations[(sample_base + k) * 2]) * static_cast<float>(width);
                const float y = static_cast<float>(
                    locations[(sample_base + k) * 2 + 1]) * static_cast<float>(height);
                const float floor_x = floorf(x);
                const float floor_y = floorf(y);
                const float fx = x - floor_x;
                const float fy = y - floor_y;

                // Check floating coordinates before converting to integer indices.
                const bool nearby =
                    floor_x >= -1.0f && floor_x < static_cast<float>(width) &&
                    floor_y >= -1.0f && floor_y < static_cast<float>(height);
                const int64_t ix = nearby ? static_cast<int64_t>(floor_x) : -2;
                const int64_t iy = nearby ? static_cast<int64_t>(floor_y) : -2;

                coefficients[0][t] = (1.0f - fy) * (1.0f - fx);
                coefficients[1][t] = (1.0f - fy) * fx;
                coefficients[2][t] = fy * (1.0f - fx);
                coefficients[3][t] = fy * fx;

                #pragma unroll
                for (int corner = 0; corner < 4; ++corner) {
                    const int64_t cx = ix + (corner & 1);
                    const int64_t cy = iy + (corner >> 1);
                    const bool valid = nearby &&
                        cx >= 0 && cx < width && cy >= 0 && cy < height;
                    indices[corner][t] = valid
                        ? ((batch * keys + base + cy * width + cx) * heads + head)
                              * channels
                        : -1;
                }

                probabilities[t] = samples == 1 ? 1.0f :
                    expf(static_cast<float>(scores[sample_base + k]) - maximum)
                    * reciprocal;
            }
            __syncthreads();

            if (d < channels) {
                for (int k = 0; k < count; ++k) {
                    float corners[4];
                    #pragma unroll
                    for (int corner = 0; corner < 4; ++corner) {
                        const int64_t address = indices[corner][k];
                        corners[corner] = address >= 0
                            ? static_cast<float>(value[address + d])
                                  * coefficients[corner][k]
                            : 0.0f;
                    }
                    const float sampled =
                        ((corners[0] + corners[1]) + corners[2]) + corners[3];
                    result += probabilities[k] * sampled;
                }
            }
            __syncthreads();
        }

        if (d < channels)
            output[row * channels + d] = static_cast<scalar_t>(result);
        __syncthreads();
    }
}

int index_kind(const torch::Tensor& tensor) {
    if (tensor.scalar_type() == at::kLong) return 0;
    if (tensor.scalar_type() == at::kFloat) return 1;
    TORCH_CHECK(tensor.scalar_type() == at::kInt,
                "Index tensors must have float32, int64, or int32 dtype");
    return 2;
}

} // namespace

torch::Tensor deform_forward(
    torch::Tensor value,
    torch::Tensor shapes,
    torch::Tensor starts,
    torch::Tensor locations,
    torch::Tensor scores)
{
    TORCH_CHECK(value.is_cuda(), "value must be on the accelerator");
    const c10::cuda::CUDAGuard guard(value.device());

    if (shapes.device() != value.device())
        shapes = shapes.to(value.device());
    if (starts.device() != value.device())
        starts = starts.to(value.device());

    TORCH_CHECK(value.is_contiguous() && shapes.is_contiguous() &&
                starts.is_contiguous() && locations.is_contiguous() &&
                scores.is_contiguous(), "All inputs must be contiguous");
    TORCH_CHECK(locations.device() == value.device() &&
                scores.device() == value.device(), "Device mismatch");
    TORCH_CHECK(locations.scalar_type() == value.scalar_type() &&
                scores.scalar_type() == value.scalar_type(), "Dtype mismatch");

    const int64_t n = value.size(0);
    const int64_t keys = value.size(1);
    const int64_t heads = value.size(2);
    const int64_t channels = value.size(3);
    const int64_t queries = locations.size(1);
    const int64_t points = locations.size(4);
    const int64_t samples = shapes.size(0) * points;
    const int64_t rows = n * queries * heads;

    auto output = torch::empty({n, queries, heads * channels}, value.options());
    if (rows == 0 || channels == 0) return output;

    const dim3 grid(
        static_cast<unsigned>(std::min<int64_t>(rows, 65535)),
        static_cast<unsigned>((channels + BLOCK - 1) / BLOCK));
    const auto stream = at::cuda::getCurrentCUDAStream(value.get_device());
    const int sk = index_kind(shapes);
    const int bk = index_kind(starts);

    AT_DISPATCH_FLOATING_TYPES_AND_HALF(value.scalar_type(), "deform_forward", [&] {
        hipLaunchKernelGGL(
            (deform_kernel<scalar_t>), grid, dim3(BLOCK), 0, stream.stream(),
            value.data_ptr<scalar_t>(), shapes.data_ptr(), starts.data_ptr(),
            locations.data_ptr<scalar_t>(), scores.data_ptr<scalar_t>(),
            output.data_ptr<scalar_t>(), rows, keys, heads, channels,
            queries, points, samples, sk, bk);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP_SRC + _HIP_SRC).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"deform_attention_hip_{digest}",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, value, spatial_shapes, level_start_index,
                sampling_locations, attention_weights):
        return _get_extension().forward(
            value, spatial_shapes, level_start_index,
            sampling_locations, attention_weights,
        )
```