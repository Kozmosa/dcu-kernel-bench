```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor schedule(torch::Tensor ids, int64_t experts, int64_t block_size);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("schedule", &schedule);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <hipcub/hipcub.hpp>

constexpr int THREADS = 256;

template<typename T>
__global__ void count_tiles(
    const T* __restrict__ ids, int* __restrict__ counts,
    int n, int tiles)
{
    const int tile = blockIdx.x;
    const int expert = blockIdx.y;
    const int t = threadIdx.x;
    const int i = tile * THREADS + t;
    const bool match = i < n && static_cast<int>(ids[i]) == expert;
    const unsigned long long bits = __ballot(match);
    __shared__ int wave_counts[THREADS / 32];
    const int lane = t % warpSize;
    const int wave = t / warpSize;
    if (lane == 0)
        wave_counts[wave] = __popcll(bits);
    __syncthreads();
    if (t == 0) {
        int sum = 0;
        for (int w = 0; w < THREADS / warpSize; ++w)
            sum += wave_counts[w];
        counts[expert * tiles + tile] = sum;
    }
}

__global__ void prefix_tiles(
    int* __restrict__ counts, int* __restrict__ padded,
    int tiles, int block_size)
{
    using Scan = hipcub::BlockScan<int, THREADS>;
    __shared__ typename Scan::TempStorage storage;
    __shared__ int carry;
    const int t = threadIdx.x;
    const int expert = blockIdx.x;
    if (t == 0) carry = 0;
    __syncthreads();
    for (int base = 0; base < tiles; base += THREADS) {
        const int j = base + t;
        const int v = j < tiles ? counts[expert * tiles + j] : 0;
        int prefix, aggregate;
        Scan(storage).ExclusiveSum(v, prefix, aggregate);
        const int previous = carry;
        if (j < tiles)
            counts[expert * tiles + j] = previous + prefix;
        __syncthreads();
        if (t == 0) carry = previous + aggregate;
        __syncthreads();
    }
    if (t == 0)
        padded[expert] = ((carry + block_size - 1) / block_size) * block_size;
}

__global__ void initialize_and_prefix(
    float* __restrict__ out, const int* __restrict__ padded,
    int* __restrict__ starts, int experts, int n, int l1, int l2)
{
    const int i = blockIdx.x * blockDim.x + threadIdx.x;
    const int stride = gridDim.x * blockDim.x;
    for (int j = i; j < l1 + l2; j += stride)
        out[j] = j < l1 ? static_cast<float>(n) : -1.0f;
    if (i == 0) {
        int sum = 0;
        for (int e = 0; e < experts; ++e) {
            starts[e] = sum;
            sum += padded[e];
        }
        starts[experts] = sum;
        out[l1 + l2] = static_cast<float>(sum);
    }
}

template<typename T>
__global__ void scatter_tiles(
    const T* __restrict__ ids, const int* __restrict__ counts,
    const int* __restrict__ starts, float* __restrict__ out,
    int n, int tiles, int block_size, int l1)
{
    const int tile = blockIdx.x;
    const int expert = blockIdx.y;
    const int t = threadIdx.x;
    const int i = tile * THREADS + t;
    const bool match = i < n && static_cast<int>(ids[i]) == expert;
    const unsigned long long bits = __ballot(match);
    const int lane = t % warpSize;
    const int wave = t / warpSize;
    __shared__ int wave_counts[THREADS / 32];
    if (lane == 0)
        wave_counts[wave] = __popcll(bits);
    __syncthreads();
    if (match) {
        const unsigned long long lower = (1ULL << lane) - 1ULL;
        int rank = __popcll(bits & lower);
        for (int w = 0; w < wave; ++w)
            rank += wave_counts[w];
        const int dst = starts[expert] + counts[expert * tiles + tile] + rank;
        out[dst] = static_cast<float>(i);
    }
    if (tile == 0) {
        const int first = starts[expert] / block_size;
        const int last = starts[expert + 1] / block_size;
        for (int b = first + t; b < last; b += THREADS)
            out[l1 + b] = static_cast<float>(expert);
    }
}

template<typename T>
void launch(
    const torch::Tensor& ids, torch::Tensor& counts,
    torch::Tensor& padded, torch::Tensor& starts, torch::Tensor& out,
    int n, int experts, int block_size, int tiles, int l1, int l2,
    hipStream_t stream)
{
    const dim3 grid(tiles, experts);
    count_tiles<T><<<grid, THREADS, 0, stream>>>(
        ids.data_ptr<T>(), counts.data_ptr<int>(), n, tiles);
    prefix_tiles<<<experts, THREADS, 0, stream>>>(
        counts.data_ptr<int>(), padded.data_ptr<int>(), tiles, block_size);
    int init_blocks = (l1 + l2 + THREADS - 1) / THREADS;
    if (init_blocks > 4096) init_blocks = 4096;
    initialize_and_prefix<<<init_blocks, THREADS, 0, stream>>>(
        out.data_ptr<float>(), padded.data_ptr<int>(), starts.data_ptr<int>(),
        experts, n, l1, l2);
    scatter_tiles<T><<<grid, THREADS, 0, stream>>>(
        ids.data_ptr<T>(), counts.data_ptr<int>(), starts.data_ptr<int>(),
        out.data_ptr<float>(), n, tiles, block_size, l1);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

torch::Tensor schedule(torch::Tensor ids, int64_t experts64, int64_t block64)
{
    TORCH_CHECK(ids.is_cuda(), "topk_ids must be on the accelerator");
    TORCH_CHECK(ids.is_contiguous() && ids.dim() == 2,
                "topk_ids must be a contiguous two-dimensional tensor");
    TORCH_CHECK(experts64 > 0 && experts64 <= 65535 && block64 > 0,
                "invalid expert count or block size");
    const int64_t n64 = ids.numel();
    const int64_t l164 = n64 + experts64 * (block64 - 1);
    TORCH_CHECK(n64 > 0 && l164 <= (1LL << 24), "invalid output size");
    c10::cuda::CUDAGuard guard(ids.device());
    const int n = static_cast<int>(n64);
    const int experts = static_cast<int>(experts64);
    const int block_size = static_cast<int>(block64);
    const int l1 = static_cast<int>(l164);
    const int l2 = (l1 + block_size - 1) / block_size;
    const int tiles = (n + THREADS - 1) / THREADS;
    auto int_options = ids.options().dtype(torch::kInt32);
    auto counts = torch::empty({experts, tiles}, int_options);
    auto padded = torch::empty({experts}, int_options);
    auto starts = torch::empty({experts + 1}, int_options);
    auto out = torch::empty({static_cast<int64_t>(l1) + l2 + 1},
                            ids.options().dtype(torch::kFloat32));
    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    switch (ids.scalar_type()) {
        case at::kLong:
            launch<int64_t>(ids, counts, padded, starts, out, n, experts,
                            block_size, tiles, l1, l2, stream);
            break;
        case at::kInt:
            launch<int32_t>(ids, counts, padded, starts, out, n, experts,
                            block_size, tiles, l1, l2, stream);
            break;
        case at::kFloat:
            launch<float>(ids, counts, padded, starts, out, n, experts,
                          block_size, tiles, l1, l2, stream);
            break;
        default:
            TORCH_CHECK(false, "supported input dtypes are int64, int32, float32");
    }
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"stable_expert_schedule_{digest}",
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, num_experts: int, block_size: int):
        super().__init__()
        self.num_experts = int(num_experts)
        self.block_size = int(block_size)

    def forward(self, topk_ids):
        return _get_extension().schedule(
            topk_ids, self.num_experts, self.block_size
        )
```