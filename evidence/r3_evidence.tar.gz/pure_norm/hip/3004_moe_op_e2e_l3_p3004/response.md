```python
import hashlib
import threading

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor moe_forward(
    torch::Tensor a,
    torch::Tensor w1,
    torch::Tensor w2,
    torch::Tensor routing_weights,
    torch::Tensor routing_ids);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &moe_forward);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template <typename T>
__device__ __forceinline__ float read_float(const T* p) {
    return static_cast<float>(*p);
}

__device__ __forceinline__ float wave_sum(float x) {
    #pragma unroll
    for (int delta = 32; delta; delta >>= 1)
        x += __shfl_down(x, delta, 64);
    return x;
}

// Each wave computes one gate/up pair. Its input vector is shared by
// all four waves through the device's caches.
template <typename T, typename I>
__global__ __launch_bounds__(256)
void first_layer(
    const T* __restrict__ a,
    const T* __restrict__ w1,
    const I* __restrict__ ids,
    float* __restrict__ hidden,
    int64_t K,
    int64_t H,
    int64_t slots,
    int64_t pairs,
    int64_t tiles)
{
    const int lane = threadIdx.x & 63;
    const int wave = threadIdx.x >> 6;
    const int64_t pair = static_cast<int64_t>(blockIdx.x) / tiles;
    const int64_t tile = static_cast<int64_t>(blockIdx.x) - pair * tiles;
    const int64_t n = tile * 4 + wave;
    if (pair >= pairs || n >= H)
        return;

    const int64_t expert = static_cast<int64_t>(ids[pair]);
    const T* input = a + (pair / slots) * K;
    const T* gate = w1 + (expert * (2 * H) + n) * K;
    const T* up = gate + H * K;

    float g0 = 0.0f, g1 = 0.0f;
    float u0 = 0.0f, u1 = 0.0f;
    for (int64_t k = lane; k < K; k += 128) {
        const float x0 = read_float(input + k);
        g0 = fmaf(x0, read_float(gate + k), g0);
        u0 = fmaf(x0, read_float(up + k), u0);
        if (k + 64 < K) {
            const float x1 = read_float(input + k + 64);
            g1 = fmaf(x1, read_float(gate + k + 64), g1);
            u1 = fmaf(x1, read_float(up + k + 64), u1);
        }
    }
    const float g = wave_sum(g0 + g1);
    const float u = wave_sum(u0 + u1);
    if (lane == 0)
        hidden[pair * H + n] = (g / (1.0f + expf(-g))) * u;
}

template <typename T, typename I>
__global__ __launch_bounds__(256)
void second_layer(
    const float* __restrict__ hidden,
    const T* __restrict__ w2,
    const T* __restrict__ routing_weights,
    const I* __restrict__ ids,
    T* __restrict__ output,
    int64_t K,
    int64_t H,
    int64_t pairs,
    int64_t tiles)
{
    const int lane = threadIdx.x & 63;
    const int wave = threadIdx.x >> 6;
    const int64_t pair = static_cast<int64_t>(blockIdx.x) / tiles;
    const int64_t tile = static_cast<int64_t>(blockIdx.x) - pair * tiles;
    const int64_t k = tile * 4 + wave;
    if (pair >= pairs || k >= K)
        return;

    const int64_t expert = static_cast<int64_t>(ids[pair]);
    const float* input = hidden + pair * H;
    const T* weight = w2 + (expert * K + k) * H;

    float s0 = 0.0f, s1 = 0.0f;
    for (int64_t n = lane; n < H; n += 128) {
        s0 = fmaf(input[n], read_float(weight + n), s0);
        if (n + 64 < H)
            s1 = fmaf(input[n + 64], read_float(weight + n + 64), s1);
    }
    const float sum = wave_sum(s0 + s1);
    if (lane == 0)
        output[pair * K + k] =
            static_cast<T>(sum * read_float(routing_weights + pair));
}

template <typename T, typename I>
void launch(
    const torch::Tensor& a,
    const torch::Tensor& w1,
    const torch::Tensor& w2,
    const torch::Tensor& routing_weights,
    const torch::Tensor& routing_ids,
    torch::Tensor& hidden,
    torch::Tensor& output,
    hipStream_t stream)
{
    const int64_t K = a.size(1);
    const int64_t H = w1.size(1) / 2;
    const int64_t slots = routing_ids.size(1);
    const int64_t pairs = a.size(0) * slots;
    if (pairs == 0 || K == 0)
        return;

    const int64_t first_tiles = (H + 3) / 4;
    const int64_t second_tiles = (K + 3) / 4;

    if (H != 0) {
        hipLaunchKernelGGL(
            (first_layer<T, I>),
            dim3(pairs * first_tiles), dim3(256), 0, stream,
            a.data_ptr<T>(), w1.data_ptr<T>(), routing_ids.data_ptr<I>(),
            hidden.data_ptr<float>(), K, H, slots, pairs, first_tiles);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }

    hipLaunchKernelGGL(
        (second_layer<T, I>),
        dim3(pairs * second_tiles), dim3(256), 0, stream,
        hidden.data_ptr<float>(), w2.data_ptr<T>(),
        routing_weights.data_ptr<T>(), routing_ids.data_ptr<I>(),
        output.data_ptr<T>(), K, H, pairs, second_tiles);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

template <typename T>
void dispatch_ids(
    const torch::Tensor& a,
    const torch::Tensor& w1,
    const torch::Tensor& w2,
    const torch::Tensor& weights,
    const torch::Tensor& ids,
    torch::Tensor& hidden,
    torch::Tensor& output,
    hipStream_t stream)
{
    switch (ids.scalar_type()) {
        case at::kLong:
            launch<T, int64_t>(a, w1, w2, weights, ids, hidden, output, stream);
            break;
        case at::kInt:
            launch<T, int32_t>(a, w1, w2, weights, ids, hidden, output, stream);
            break;
        case at::kFloat:
            launch<T, float>(a, w1, w2, weights, ids, hidden, output, stream);
            break;
        default:
            TORCH_CHECK(false, "Routing ids must be int64, int32, or float32");
    }
}

torch::Tensor moe_forward(
    torch::Tensor a,
    torch::Tensor w1,
    torch::Tensor w2,
    torch::Tensor routing_weights,
    torch::Tensor routing_ids)
{
    TORCH_CHECK(a.is_cuda(), "Inputs must reside on the accelerator");
    const c10::cuda::CUDAGuard guard(a.device());
    TORCH_CHECK(
        a.dim() == 2 && w1.dim() == 3 && w2.dim() == 3 &&
        routing_weights.dim() == 2 && routing_ids.dim() == 2,
        "Invalid tensor ranks");
    TORCH_CHECK(
        a.is_contiguous() && w1.is_contiguous() && w2.is_contiguous() &&
        routing_weights.is_contiguous() && routing_ids.is_contiguous(),
        "Inputs must be contiguous");
    TORCH_CHECK(
        w1.device() == a.device() && w2.device() == a.device() &&
        routing_weights.device() == a.device() &&
        routing_ids.device() == a.device(),
        "Inputs must be on the same device");
    TORCH_CHECK(
        w1.scalar_type() == a.scalar_type() &&
        w2.scalar_type() == a.scalar_type() &&
        routing_weights.scalar_type() == a.scalar_type(),
        "Activation, expert, and routing weight dtypes must match");

    const int64_t M = a.size(0);
    const int64_t K = a.size(1);
    const int64_t H = w1.size(1) / 2;
    const int64_t slots = routing_ids.size(1);
    TORCH_CHECK(
        w1.size(1) % 2 == 0 && w1.size(2) == K &&
        w2.size(0) == w1.size(0) && w2.size(1) == K &&
        w2.size(2) == H && routing_ids.size(0) == M &&
        routing_weights.size(0) == M && routing_weights.size(1) == slots,
        "Incompatible tensor shapes");

    auto hidden = torch::empty(
        {M * slots, H}, a.options().dtype(at::kFloat));
    auto output = torch::empty({M, slots, K}, a.options());
    hipStream_t stream = at::cuda::getCurrentCUDAStream(a.get_device());

    if (a.scalar_type() == at::kFloat) {
        dispatch_ids<float>(
            a, w1, w2, routing_weights, routing_ids, hidden, output, stream);
    } else if (a.scalar_type() == at::kBFloat16) {
        dispatch_ids<at::BFloat16>(
            a, w1, w2, routing_weights, routing_ids, hidden, output, stream);
    } else {
        TORCH_CHECK(false, "Only float32 and bfloat16 are supported");
    }
    return output;
}
"""

_EXTENSION = None
_EXTENSION_LOCK = threading.Lock()


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        with _EXTENSION_LOCK:
            if _EXTENSION is None:
                digest = hashlib.sha256(
                    (_CPP_SRC + _HIP_SRC).encode("utf-8")
                ).hexdigest()[:16]
                _EXTENSION = load_inline(
                    name=f"moe_wave_fused_{digest}",
                    cpp_sources=_CPP_SRC,
                    cuda_sources=_HIP_SRC,
                    functions=None,
                    extra_cflags=["-O3"],
                    extra_cuda_cflags=["-O3"],
                    with_cuda=True,
                    verbose=False,
                )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, top_k: int, num_experts: int):
        super().__init__()
        self.top_k = top_k
        self.num_experts = num_experts

    def forward(self, a, w1, w2, topk_weights, topk_ids):
        return _get_extension().forward(a, w1, w2, topk_weights, topk_ids)
```