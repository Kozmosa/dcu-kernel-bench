```python
import hashlib
import threading

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor activation_forward(
    torch::Tensor x, int64_t mode, double alpha, double limit);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &activation_forward);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>
#include <algorithm>
#include <cstdint>

template<int MODE>
__device__ __forceinline__ float evaluate(float g, float u, float a, float l) {
    if constexpr (MODE == 1 || MODE == 2 || MODE == 6) {
        g = fminf(g, l);
        u = fminf(fmaxf(u, -l), l);
    }

    if constexpr (MODE == 0 || MODE == 1 || MODE == 7) {
        float v = g * (1.0f / (1.0f + expf(-g)));
        if constexpr (MODE == 7) return v;
        else return v * u;
    } else if constexpr (MODE == 2 || MODE == 6) {
        return (g * (1.0f / (1.0f + expf(-(a * g))))) * (u + 1.0f);
    } else if constexpr (MODE == 3 || MODE == 8) {
        float v = (0.5f * g) * (1.0f + erff(g * 0.7071067811865476f));
        if constexpr (MODE == 8) return v;
        else return v * u;
    } else if constexpr (MODE == 4 || MODE == 9) {
        float inner = 0.7978845608028654f *
                      (g + ((0.044715f * g) * g) * g);
        float v = (0.5f * g) * (1.0f + tanhf(inner));
        if constexpr (MODE == 9) return v;
        else return v * u;
    } else if constexpr (MODE == 5) {
        float v = g * (1.0f / (1.0f + expf(-g)));
        return fminf(v, l) * fminf(fmaxf(u, -l), l);
    } else {
        float v = fmaxf(g, 0.0f);
        return v * v;
    }
}

template<typename T, int MODE>
__global__ __launch_bounds__(256)
void activation_kernel(
    const T* __restrict__ x,
    T* __restrict__ y,
    int64_t total,
    int64_t width,
    float alpha,
    float limit)
{
    constexpr int ITEMS = 4;
    int64_t base = static_cast<int64_t>(blockIdx.x) * (256 * ITEMS)
                 + threadIdx.x;
    int64_t step = static_cast<int64_t>(gridDim.x) * (256 * ITEMS);

    for (; base < total; base += step) {
        #pragma unroll
        for (int j = 0; j < ITEMS; ++j) {
            int64_t i = base + j * 256;
            if (i < total) {
                float g;
                float u = 1.0f;
                if constexpr (MODE >= 7) {
                    g = static_cast<float>(x[i]);
                } else if constexpr (MODE == 6) {
                    g = static_cast<float>(x[2 * i]);
                    u = static_cast<float>(x[2 * i + 1]);
                } else {
                    int64_t row = i / width;
                    int64_t offset = i + row * width;
                    g = static_cast<float>(x[offset]);
                    u = static_cast<float>(x[offset + width]);
                }
                y[i] = static_cast<T>(evaluate<MODE>(g, u, alpha, limit));
            }
        }
    }
}

template<typename T>
void launch(
    const torch::Tensor& x, torch::Tensor& y, int mode,
    float alpha, float limit, hipStream_t stream)
{
    int64_t total = y.numel();
    int64_t width = y.size(1);
    unsigned blocks = static_cast<unsigned>(
        std::min<int64_t>((total + 1023) / 1024, 65535));

    #define RUN(M) \
        case M: \
            hipLaunchKernelGGL((activation_kernel<T, M>), \
                dim3(blocks), dim3(256), 0, stream, \
                x.data_ptr<T>(), y.data_ptr<T>(), total, width, alpha, limit); \
            break

    switch (mode) {
        RUN(0);
        RUN(1);
        RUN(2);
        RUN(3);
        RUN(4);
        RUN(5);
        RUN(6);
        RUN(7);
        RUN(8);
        RUN(9);
        RUN(10);
    }
    #undef RUN
}

torch::Tensor activation_forward(
    torch::Tensor x, int64_t mode, double alpha, double limit)
{
    TORCH_CHECK(x.is_cuda(), "input must be on a CUDA/HIP device");
    TORCH_CHECK(x.dim() == 2, "input must be two-dimensional");
    TORCH_CHECK(x.is_contiguous(), "input must be contiguous");
    TORCH_CHECK(mode >= 0 && mode <= 10, "invalid activation mode");
    TORCH_CHECK(
        x.scalar_type() == at::kFloat ||
        x.scalar_type() == at::kHalf ||
        x.scalar_type() == at::kBFloat16,
        "input must have floating-point dtype float32, float16 or bfloat16");
    TORCH_CHECK(mode >= 7 || x.size(1) % 2 == 0,
                "gated input width must be even");

    c10::cuda::CUDAGuard guard(x.device());
    int64_t width = mode >= 7 ? x.size(1) : x.size(1) / 2;
    auto y = torch::empty({x.size(0), width}, x.options());
    if (y.numel() == 0) return y;

    hipStream_t stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    if (x.scalar_type() == at::kFloat) {
        launch<float>(x, y, mode, alpha, limit, stream);
    } else if (x.scalar_type() == at::kHalf) {
        launch<at::Half>(x, y, mode, alpha, limit, stream);
    } else {
        launch<at::BFloat16>(x, y, mode, alpha, limit, stream);
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return y;
}
"""

_EXTENSION = None
_EXTENSION_LOCK = threading.Lock()


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        with _EXTENSION_LOCK:
            if _EXTENSION is None:
                digest = hashlib.sha256(
                    (_CPP_SRC + _HIP_SRC).encode()
                ).hexdigest()[:16]
                _EXTENSION = load_inline(
                    name=f"moe_activation_hip_{digest}",
                    cpp_sources=_CPP_SRC,
                    cuda_sources=_HIP_SRC,
                    functions=None,
                    extra_cflags=["-O3", "-std=c++17"],
                    extra_cuda_cflags=[
                        "-O3", "-std=c++17", "-ffp-contract=off"
                    ],
                    with_cuda=True,
                    verbose=False,
                )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, activation: str = "silu", alpha=None, limit=None):
        super().__init__()
        gated = ("silu", "gelu", "gelu_tanh", "swiglustep", "swiglu_interleaved")
        nomul = ("silu_no_mul", "gelu_no_mul", "gelu_tanh_no_mul", "relu2")
        name = str(activation).lower()
        assert name in gated or name in nomul, (
            "activation must be one of " + "/".join(gated + nomul) + " variants"
        )
        if name in ("gelu", "gelu_tanh"):
            assert alpha is None and limit is None, (
                "gelu / gelu_tanh do not accept alpha / limit"
            )
        if name == "swiglustep":
            assert alpha is None, "swiglustep does not accept alpha"
        if name == "silu" and alpha is not None:
            assert limit is not None, (
                "silu must set limit as well when alpha is set"
            )
        if name == "swiglustep" and limit is None:
            limit = 7.0
        if name == "swiglu_interleaved":
            alpha = 1.702 if alpha is None else alpha
            limit = 7.0 if limit is None else limit

        self.activation = name
        self.is_gated = name in gated
        self.alpha = None if alpha is None else float(alpha)
        self.limit = None if limit is None else float(limit)

    def forward(self, x):
        assert x.dim() == 2, "the input must be a 2D (M, n) tensor"
        if self.is_gated:
            assert x.shape[-1] % 2 == 0, (
                "the gated variants require the last dimension n to be even"
            )

        if self.activation == "silu":
            mode = 2 if self.alpha is not None else (
                1 if self.limit is not None else 0
            )
        else:
            mode = {
                "gelu": 3,
                "gelu_tanh": 4,
                "swiglustep": 5,
                "swiglu_interleaved": 6,
                "silu_no_mul": 7,
                "gelu_no_mul": 8,
                "gelu_tanh_no_mul": 9,
                "relu2": 10,
            }[self.activation]

        return _get_extension().forward(
            x,
            mode,
            1.0 if self.alpha is None else self.alpha,
            0.0 if self.limit is None else self.limit,
        )
```