import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP_SRC = r"""
#include <torch/extension.h>
#include <vector>

std::vector<torch::Tensor> deform_attn_backward(
    torch::Tensor value,
    torch::Tensor spatial_shapes,
    torch::Tensor level_start_index,
    torch::Tensor sampling_locations,
    torch::Tensor attention_weights,
    torch::Tensor grad_output);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_attn_backward", &deform_attn_backward,
          "Hand-written deformable attention backward");
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <vector>
#include <cmath>
#include <cstdint>

__device__ __forceinline__ float load_value(
    const float* __restrict__ value,
    int64_t n, int64_t key, int64_t head, int64_t c,
    int64_t nkeys, int64_t heads, int64_t d,
    int64_t h, int64_t w,
    int iy, int ix)
{
    if (iy < 0 || iy >= h || ix < 0 || ix >= w)
        return 0.0f;
    int64_t flat = static_cast<int64_t>(iy) * w + ix;
    int64_t off = (((n * nkeys + key + flat) * heads + head) * d + c);
    return value[off];
}

__global__ void deform_backward_kernel(
    const float* __restrict__ value,
    const int64_t* __restrict__ spatial_shapes,
    const int64_t* __restrict__ level_start,
    const float* __restrict__ locations,
    const float* __restrict__ attention,
    const float* __restrict__ grad_output,
    float* __restrict__ grad_value,
    float* __restrict__ grad_locations,
    float* __restrict__ grad_attention,
    int64_t N, int64_t Q, int64_t Hh, int64_t D,
    int64_t L, int64_t P, int64_t K)
{
    int64_t tid = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    int64_t total = N * Q * Hh * L * P;
    if (tid >= total)
        return;

    int64_t x = tid;
    int64_t p = x % P; x /= P;
    int64_t l = x % L; x /= L;
    int64_t h = x % Hh; x /= Hh;
    int64_t q = x % Q; x /= Q;
    int64_t n = x;

    int64_t lp_count = L * P;
    int64_t nhq = ((n * Q + q) * Hh + h);

    float max_score = -INFINITY;
    for (int64_t ll = 0; ll < L; ++ll) {
        for (int64_t pp = 0; pp < P; ++pp) {
            int64_t ai = (((nhq * L + ll) * P) + pp);
            float s = attention[ai];
            if (s > max_score)
                max_score = s;
        }
    }

    float sum_exp = 0.0f;
    for (int64_t ll = 0; ll < L; ++ll) {
        for (int64_t pp = 0; pp < P; ++pp) {
            int64_t ai = (((nhq * L + ll) * P) + pp);
            sum_exp += expf(attention[ai] - max_score);
        }
    }

    int64_t hsize = spatial_shapes[l * 2 + 0];
    int64_t wsize = spatial_shapes[l * 2 + 1];
    int64_t base = level_start[l];

    int64_t li = (((nhq * L + l) * P) + p) * 2;
    float sx = locations[li + 0] * static_cast<float>(wsize);
    float sy = locations[li + 1] * static_cast<float>(hsize);

    float fx = sx - floorf(sx);
    float fy = sy - floorf(sy);
    int ix0 = static_cast<int>(floorf(sx));
    int iy0 = static_cast<int>(floorf(sy));

    float weight = expf(attention[(((nhq * L + l) * P) + p)] - max_score)
                   / sum_exp;

    float t = 0.0f;
    float dx = 0.0f;
    float dy = 0.0f;

    for (int64_t c = 0; c < D; ++c) {
        int64_t goi = (n * Q * Hh * D) + (q * Hh * D) + h * D + c;
        float go = grad_output[goi];

        float v00 = load_value(value, n, base, h, c, K, Hh, D,
                               hsize, wsize, iy0,     ix0);
        float v01 = load_value(value, n, base, h, c, K, Hh, D,
                               hsize, wsize, iy0,     ix0 + 1);
        float v10 = load_value(value, n, base, h, c, K, Hh, D,
                               hsize, wsize, iy0 + 1, ix0);
        float v11 = load_value(value, n, base, h, c, K, Hh, D,
                               hsize, wsize, iy0 + 1, ix0 + 1);

        float a00 = (1.0f - fy) * (1.0f - fx);
        float a01 = (1.0f - fy) * fx;
        float a10 = fy * (1.0f - fx);
        float a11 = fy * fx;

        float sampled = a00 * v00 + a01 * v01 + a10 * v10 + a11 * v11;
        t += go * sampled;

        dx += go * ((1.0f - fy) * (v01 - v00) +
                    fy * (v11 - v10));
        dy += go * ((1.0f - fx) * (v10 - v00) +
                    fx * (v11 - v01));

        int64_t k00 = static_cast<int64_t>(iy0) * wsize + ix0;
        int64_t k01 = static_cast<int64_t>(iy0) * wsize + ix0 + 1;
        int64_t k10 = static_cast<int64_t>(iy0 + 1) * wsize + ix0;
        int64_t k11 = static_cast<int64_t>(iy0 + 1) * wsize + ix0 + 1;

        if (iy0 >= 0 && iy0 < hsize && ix0 >= 0 && ix0 < wsize) {
            int64_t oi = (((n * K + base + k00) * Hh + h) * D + c);
            atomicAdd(&grad_value[oi], weight * go * a00);
        }
        if (iy0 >= 0 && iy0 < hsize &&
            ix0 + 1 >= 0 && ix0 + 1 < wsize) {
            int64_t oi = (((n * K + base + k01) * Hh + h) * D + c);
            atomicAdd(&grad_value[oi], weight * go * a01);
        }
        if (iy0 + 1 >= 0 && iy0 + 1 < hsize &&
            ix0 >= 0 && ix0 < wsize) {
            int64_t oi = (((n * K + base + k10) * Hh + h) * D + c);
            atomicAdd(&grad_value[oi], weight * go * a10);
        }
        if (iy0 + 1 >= 0 && iy0 + 1 < hsize &&
            ix0 + 1 >= 0 && ix0 + 1 < wsize) {
            int64_t oi = (((n * K + base + k11) * Hh + h) * D + c);
            atomicAdd(&grad_value[oi], weight * go * a11);
        }
    }

    float weighted_t = 0.0f;
    for (int64_t ll = 0; ll < L; ++ll) {
        int64_t hh = spatial_shapes[ll * 2 + 0];
        int64_t ww = spatial_shapes[ll * 2 + 1];
        int64_t bb = level_start[ll];

        for (int64_t pp = 0; pp < P; ++pp) {
            int64_t lidx = (((nhq * L + ll) * P) + pp) * 2;
            float xx = locations[lidx + 0] * static_cast<float>(ww);
            float yy = locations[lidx + 1] * static_cast<float>(hh);
            int ixx = static_cast<int>(floorf(xx));
            int iyy = static_cast<int>(floorf(yy));
            float fxx = xx - floorf(xx);
            float fyy = yy - floorf(yy);

            float wwgt = expf(attention[(((nhq * L + ll) * P) + pp)]
                              - max_score) / sum_exp;
            float dot = 0.0f;

            for (int64_t c = 0; c < D; ++c) {
                int64_t goi = n * Q * Hh * D + q * Hh * D + h * D + c;
                float go = grad_output[goi];

                float z00 = load_value(value, n, bb, h, c, K, Hh, D,
                                        hh, ww, iyy, ixx);
                float z01 = load_value(value, n, bb, h, c, K, Hh, D,
                                        hh, ww, iyy, ixx + 1);
                float z10 = load_value(value, n, bb, h, c, K, Hh, D,
                                        hh, ww, iyy + 1, ixx);
                float z11 = load_value(value, n, bb, h, c, K, Hh, D,
                                        hh, ww, iyy + 1, ixx + 1);

                float sample =
                    (1.0f - fyy) * (1.0f - fxx) * z00 +
                    (1.0f - fyy) * fxx * z01 +
                    fyy * (1.0f - fxx) * z10 +
                    fyy * fxx * z11;
                dot += go * sample;
            }
            weighted_t += wwgt * dot;
        }
    }

    int64_t out_idx = (((nhq * L + l) * P) + p);
    grad_locations[out_idx * 2 + 0] = weight * dx * static_cast<float>(wsize);
    grad_locations[out_idx * 2 + 1] = weight * dy * static_cast<float>(hsize);
    grad_attention[out_idx] = weight * (t - weighted_t);
}

std::vector<torch::Tensor> deform_attn_backward(
    torch::Tensor value,
    torch::Tensor spatial_shapes,
    torch::Tensor level_start_index,
    torch::Tensor sampling_locations,
    torch::Tensor attention_weights,
    torch::Tensor grad_output)
{
    TORCH_CHECK(value.is_cuda(), "value must be on accelerator");
    TORCH_CHECK(value.scalar_type() == torch::kFloat32,
                "inputs must be float32");
    TORCH_CHECK(value.is_contiguous(), "value must be contiguous");
    TORCH_CHECK(spatial_shapes.is_contiguous(), "spatial_shapes must be contiguous");
    TORCH_CHECK(level_start_index.is_contiguous(),
                "level_start_index must be contiguous");
    TORCH_CHECK(sampling_locations.is_contiguous(),
                "sampling_locations must be contiguous");
    TORCH_CHECK(attention_weights.is_contiguous(),
                "attention_weights must be contiguous");
    TORCH_CHECK(grad_output.is_contiguous(),
                "grad_output must be contiguous");

    int64_t N = value.size(0);
    int64_t K = value.size(1);
    int64_t Hh = value.size(2);
    int64_t D = value.size(3);
    int64_t L = spatial_shapes.size(0);
    int64_t Q = sampling_locations.size(1);
    int64_t P = sampling_locations.size(4);

    auto opts = value.options().dtype(torch::kFloat32);
    auto grad_value = torch::zeros({N, K, Hh, D}, opts);
    auto grad_locations = torch::empty({N, Q, Hh, L, P, 2}, opts);
    auto grad_attention = torch::empty({N, Q, Hh, L, P}, opts);

    int64_t total = N * Q * Hh * L * P;
    int threads = 256;
    int blocks = static_cast<int>((total + threads - 1) / threads);

    hipStream_t stream = at::cuda::getDefaultCUDAStream();
    hipLaunchKernelGGL(
        deform_backward_kernel,
        dim3(blocks), dim3(threads), 0, stream,
        value.data_ptr<float>(),
        spatial_shapes.data_ptr<int64_t>(),
        level_start_index.data_ptr<int64_t>(),
        sampling_locations.data_ptr<float>(),
        attention_weights.data_ptr<float>(),
        grad_output.data_ptr<float>(),
        grad_value.data_ptr<float>(),
        grad_locations.data_ptr<float>(),
        grad_attention.data_ptr<float>(),
        N, Q, Hh, D, L, P, K);

    return {grad_value, grad_locations, grad_attention};
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        _EXTENSION = load_inline(
            name="deform_attn_backward_hip_gfx936",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(
        self,
        value,
        spatial_shapes,
        level_start_index,
        sampling_locations,
        attention_weights,
        grad_output,
    ):
        spatial_shapes = spatial_shapes.to(device=value.device, dtype=torch.long)
        level_start_index = level_start_index.to(
            device=value.device, dtype=torch.long
        )

        value_c = value.contiguous().to(torch.float32)
        locations_c = sampling_locations.contiguous().to(torch.float32)
        attention_c = attention_weights.contiguous().to(torch.float32)
        grad_output_c = grad_output.contiguous().to(torch.float32)

        grad_value, grad_locations, grad_attention = _get_extension().deform_attn_backward(
            value_c,
            spatial_shapes.contiguous(),
            level_start_index.contiguous(),
            locations_c,
            attention_c,
            grad_output_c,
        )

        packed = torch.cat(
            [
                grad_value.reshape(-1),
                grad_locations.reshape(-1),
                grad_attention.reshape(-1),
            ],
            dim=0,
        )
        return packed.to(dtype=value.dtype)
