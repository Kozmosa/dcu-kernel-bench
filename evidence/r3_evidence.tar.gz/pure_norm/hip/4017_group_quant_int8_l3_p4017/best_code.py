import hashlib

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor quantize_groups(torch::Tensor x, int64_t group_size, double eps);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("quantize_groups", &quantize_groups);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>
#include <cstdint>

__device__ __forceinline__ float quantized_code(float x, float scale) {
    float q = __fdiv_rn(x, scale);
    q = fminf(127.0f, fmaxf(-128.0f, q));
    return static_cast<float>(static_cast<int>(q));
}

template<int GROUP, int WIDTH>
__global__ void quantize_fixed(
    const float* __restrict__ x,
    float* __restrict__ out,
    int64_t n,
    int64_t groups,
    float eps
) {
    constexpr int ITEMS = (GROUP + WIDTH - 1) / WIDTH;
    const int lane = threadIdx.x % WIDTH;
    const int64_t group =
        static_cast<int64_t>(blockIdx.x) * (256 / WIDTH)
        + threadIdx.x / WIDTH;
    if (group >= groups) return;

    const int64_t base = group * GROUP;
    float values[ITEMS];
    float maximum = 0.0f;

    #pragma unroll
    for (int i = 0; i < ITEMS; ++i) {
        const int j = lane + i * WIDTH;
        float v = 0.0f;
        if (j < GROUP) v = x[base + j];
        values[i] = v;
        maximum = fmaxf(maximum, fabsf(v));
    }

    #pragma unroll
    for (int offset = WIDTH / 2; offset; offset >>= 1)
        maximum = fmaxf(maximum, __shfl_xor(maximum, offset, WIDTH));

    const float scale = __fdiv_rn(fmaxf(maximum, eps), 127.0f);
    if (lane == 0) out[n + group] = scale;

    #pragma unroll
    for (int i = 0; i < ITEMS; ++i) {
        const int j = lane + i * WIDTH;
        if (j < GROUP)
            out[base + j] = quantized_code(values[i], scale);
    }
}

__global__ void quantize_general(
    const float* __restrict__ x,
    float* __restrict__ out,
    int64_t n,
    int64_t groups,
    int64_t group_size,
    float eps
) {
    const int64_t group = blockIdx.x;
    const int tid = threadIdx.x;
    const int lane = tid & 63;
    const int wave = tid >> 6;
    const int64_t base = group * group_size;
    __shared__ float wave_maximum[4];
    __shared__ float shared_scale;

    float maximum = 0.0f;
    for (int64_t j = tid; j < group_size; j += 256)
        maximum = fmaxf(maximum, fabsf(x[base + j]));

    #pragma unroll
    for (int offset = 32; offset; offset >>= 1)
        maximum = fmaxf(maximum, __shfl_xor(maximum, offset, 64));

    if (lane == 0) wave_maximum[wave] = maximum;
    __syncthreads();

    if (tid == 0) {
        float m = fmaxf(
            fmaxf(wave_maximum[0], wave_maximum[1]),
            fmaxf(wave_maximum[2], wave_maximum[3]));
        shared_scale = __fdiv_rn(fmaxf(m, eps), 127.0f);
        out[n + group] = shared_scale;
    }
    __syncthreads();

    const float scale = shared_scale;
    for (int64_t j = tid; j < group_size; j += 256)
        out[base + j] = quantized_code(x[base + j], scale);
}

torch::Tensor quantize_groups(torch::Tensor x, int64_t group_size, double eps) {
    TORCH_CHECK(x.is_cuda(), "x must be on a CUDA/HIP device");
    TORCH_CHECK(x.scalar_type() == at::kFloat, "x must have dtype float32");
    TORCH_CHECK(x.dim() == 2, "x must be a 2D tensor");
    TORCH_CHECK(group_size > 0, "group_size must be positive");
    TORCH_CHECK(x.size(1) % group_size == 0,
                "the last dimension must be divisible by group_size");
    TORCH_CHECK(x.is_contiguous(), "x must be contiguous");

    c10::cuda::CUDAGuard guard(x.device());
    const int64_t n = x.numel();
    const int64_t groups = n / group_size;
    auto out = torch::empty({n + groups}, x.options());
    if (groups == 0) return out;

    const float* xp = x.data_ptr<float>();
    float* op = out.data_ptr<float>();
    const float epsilon = static_cast<float>(eps);
    hipStream_t stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();

    #define DISPATCH_GROUP(G, W)                                          \
        case G:                                                          \
            quantize_fixed<G, W><<<                                      \
                static_cast<unsigned int>((groups + 256 / W - 1) /       \
                                          (256 / W)),                    \
                256, 0, stream>>>(xp, op, n, groups, epsilon);             \
            break

    switch (group_size) {
        DISPATCH_GROUP(1, 1);
        DISPATCH_GROUP(2, 2);
        DISPATCH_GROUP(4, 4);
        DISPATCH_GROUP(8, 8);
        DISPATCH_GROUP(16, 16);
        DISPATCH_GROUP(32, 32);
        DISPATCH_GROUP(64, 64);
        DISPATCH_GROUP(128, 64);
        DISPATCH_GROUP(256, 64);
        DISPATCH_GROUP(512, 64);
        DISPATCH_GROUP(1024, 64);
        default:
            quantize_general<<<
                static_cast<unsigned int>(groups), 256, 0, stream>>>(
                    xp, op, n, groups, group_size, epsilon);
            break;
    }
    #undef DISPATCH_GROUP

    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha256(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"group_quantization_hip_{digest}",
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, group_size: int = 128, eps: float = 1e-10):
        super().__init__()
        self.group_size = int(group_size)
        self.eps = float(eps)

    def forward(self, x):
        assert x.dim() == 2, "x must be a 2D tensor"
        assert self.group_size > 0, "group_size must be positive"
        assert x.shape[-1] % self.group_size == 0, (
            "the last dimension must be divisible by group_size"
        )
        assert x.is_contiguous(), "x must be contiguous"
        if x.dtype != torch.float32:
            x = x.to(dtype=torch.float32)
        return _get_extension().quantize_groups(x, self.group_size, self.eps)
