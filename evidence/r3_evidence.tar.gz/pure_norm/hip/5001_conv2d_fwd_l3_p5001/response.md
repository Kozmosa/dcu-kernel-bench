```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor pyramid_forward(torch::Tensor x, torch::Tensor weight, int64_t pad);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &pyramid_forward);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>

__global__ void direct_kernel(
    const float* __restrict__ x,
    const float* __restrict__ w,
    float* __restrict__ out,
    int C, int H, int W, int K, int R, int S,
    int OH, int OW, int pad, int64_t count)
{
    const int64_t index = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (index >= count) return;
    int j = index % OW;
    int i = (index / OW) % OH;
    int k = (index / ((int64_t)OH * OW)) % K;
    int64_t n = index / ((int64_t)K * OH * OW);
    float sum = 0.0f;
    for (int c = 0; c < C; ++c) {
        for (int r = 0; r < R; ++r) {
            int h = i + r - pad;
            if ((unsigned)h >= (unsigned)H) continue;
            for (int s = 0; s < S; ++s) {
                int v = j + s - pad;
                if ((unsigned)v < (unsigned)W) {
                    float a = x[((n * C + c) * H + h) * W + v];
                    float b = w[((int64_t)k * C + c) * R * S + r * S + s];
                    sum = fmaf(a, b, sum);
                }
            }
        }
    }
    out[index] = sum;
}

__global__ __launch_bounds__(256) void tiled_kernel(
    const float* __restrict__ x,
    const float* __restrict__ w,
    float* __restrict__ out,
    int C, int H, int W, int K, int R, int S,
    int OH, int OW, int pad)
{
    __shared__ float a[32][16];
    __shared__ float b[16][64];

    const int t = threadIdx.x;
    const int tx = t & 15;
    const int ty = t >> 4;
    const int spatial_base = blockIdx.x * 64;
    const int channel_base = blockIdx.y * 32;
    const int64_t batch = blockIdx.z;
    const int P = OH * OW;
    const int D = C * R * S;
    const int RS = R * S;

    float acc[2][4] = {};

    for (int base = 0; base < D; base += 16) {
        #pragma unroll
        for (int z = 0; z < 2; ++z) {
            int q = t + z * 256;
            int k = channel_base + q / 16;
            int d = base + q % 16;
            a[q / 16][q % 16] =
                (k < K && d < D) ? w[(int64_t)k * D + d] : 0.0f;
        }
        #pragma unroll
        for (int z = 0; z < 4; ++z) {
            int q = t + z * 256;
            int d = base + q / 64;
            int p = spatial_base + q % 64;
            float value = 0.0f;
            if (d < D && p < P) {
                int c = d / RS;
                int rs = d - c * RS;
                int h = p / OW + rs / S - pad;
                int v = p % OW + rs % S - pad;
                if ((unsigned)h < (unsigned)H &&
                    (unsigned)v < (unsigned)W) {
                    value = x[((batch * C + c) * H + h) * W + v];
                }
            }
            b[q / 64][q % 64] = value;
        }
        __syncthreads();

        #pragma unroll
        for (int d = 0; d < 16; ++d) {
            float a0 = a[ty][d];
            float a1 = a[ty + 16][d];
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                float bv = b[d][tx + j * 16];
                acc[0][j] = fmaf(a0, bv, acc[0][j]);
                acc[1][j] = fmaf(a1, bv, acc[1][j]);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 2; ++i) {
        int k = channel_base + ty + i * 16;
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            int p = spatial_base + tx + j * 16;
            if (k < K && p < P)
                out[(batch * K + k) * P + p] = acc[i][j];
        }
    }
}

torch::Tensor pyramid_forward(torch::Tensor x, torch::Tensor weight, int64_t pad) {
    TORCH_CHECK(x.is_cuda() && weight.is_cuda(), "Inputs must be on the accelerator");
    TORCH_CHECK(x.device() == weight.device(), "Inputs must share a device");
    TORCH_CHECK(x.scalar_type() == at::kFloat &&
                weight.scalar_type() == at::kFloat, "Inputs must be float32");
    TORCH_CHECK(x.dim() == 4 && weight.dim() == 4, "Inputs must have four dimensions");
    TORCH_CHECK(x.is_contiguous() && weight.is_contiguous(), "Inputs must be contiguous");
    TORCH_CHECK(x.size(1) == weight.size(1), "Channel dimensions must match");

    c10::cuda::CUDAGuard guard(x.device());
    int N = x.size(0), C = x.size(1), H = x.size(2), W = x.size(3);
    int K = weight.size(0), R = weight.size(2), S = weight.size(3);
    int OH = H - R + pad + 2;
    int OW = W - S + pad + 2;
    TORCH_CHECK(OH > 0 && OW > 0, "Invalid output dimensions");
    auto output = torch::empty({N, K, OH, OW}, x.options());
    if (output.numel() == 0) return output;
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();

    if (K < 8 || (C * R * S <= 9)) {
        int64_t count = output.numel();
        hipLaunchKernelGGL(
            direct_kernel, dim3((count + 255) / 256), dim3(256), 0, stream,
            x.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(),
            C, H, W, K, R, S, OH, OW, (int)pad, count);
    } else {
        hipLaunchKernelGGL(
            tiled_kernel, dim3((OH * OW + 63) / 64, (K + 31) / 32, N),
            dim3(256), 0, stream,
            x.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(),
            C, H, W, K, R, S, OH, OW, (int)pad);
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "pyramid_hip_" + hashlib.sha1(
            (_CPP_SRC + _HIP_SRC).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _DILATION = (1, 1)
    _PAD_SYMMETRIC = (1, 1)
    _PRE_PADDING = (2, 2)
    _POST_PADDING = (1, 1)

    def __init__(self, variant: str = "standard"):
        super().__init__()
        assert variant in ("standard", "asymmetric"), (
            "variant must be either standard or asymmetric"
        )
        self.variant = variant

    def forward(self, x, weight):
        return _get_extension().forward(
            x, weight, 2 if self.variant == "asymmetric" else 1
        )
```