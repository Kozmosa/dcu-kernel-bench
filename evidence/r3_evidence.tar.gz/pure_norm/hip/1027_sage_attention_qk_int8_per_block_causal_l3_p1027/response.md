```python
import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &attention_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

template<typename T, int D>
__global__ __launch_bounds__(256)
void causal_attention(
    const T* __restrict__ q,
    const T* __restrict__ k,
    const T* __restrict__ v,
    T* __restrict__ out,
    int L, int Hq, int Hkv, float scale,
    int64_t qb, int64_t qh, int64_t qr, int64_t qd,
    int64_t kb, int64_t kh, int64_t kr, int64_t kd,
    int64_t vb, int64_t vh, int64_t vr, int64_t vd)
{
    const int row = blockIdx.x;
    const int head = blockIdx.y;
    const int batch = blockIdx.z;
    const int kvhead = head / (Hq / Hkv);
    const int tid = threadIdx.x;
    const int lane = tid & 63;
    const int wave = tid >> 6;

    q += batch * qb + head * qh + row * qr;
    k += batch * kb + kvhead * kh;
    v += batch * vb + kvhead * vh;
    out += ((int64_t(batch) * Hq + head) * L + row) * D;

    if (row == 0) {
        if (tid < D) out[tid] = v[tid * vd];
        return;
    }

    __shared__ float sq[D];
    __shared__ float logits[64];
    __shared__ float weights[64];
    __shared__ float correction;
    __shared__ float denominator;
    __shared__ float maximum;

    if (tid < D) sq[tid] = float(q[tid * qd]) * scale;
    if (tid == 0) {
        maximum = -INFINITY;
        denominator = 0.0f;
    }
    __syncthreads();

    float acc = 0.0f;

    for (int start = 0; start <= row; start += 64) {
        #pragma unroll
        for (int r = 0; r < 16; ++r) {
            const int j = start + wave + r * 4;
            float dot = 0.0f;
            if (j <= row) {
                dot = sq[lane] * float(k[int64_t(j) * kr + lane * kd]);
                if constexpr (D == 128) {
                    dot = fmaf(sq[lane + 64],
                               float(k[int64_t(j) * kr + (lane + 64) * kd]),
                               dot);
                }
            }
            #pragma unroll
            for (int offset = 32; offset > 0; offset >>= 1)
                dot += __shfl_down(dot, offset, 64);
            if (lane == 0)
                logits[wave + r * 4] = j <= row ? dot : -INFINITY;
        }
        __syncthreads();

        if (tid < 64) {
            float m = logits[tid];
            #pragma unroll
            for (int offset = 32; offset > 0; offset >>= 1)
                m = fmaxf(m, __shfl_xor(m, offset, 64));
            m = fmaxf(m, maximum);
            float p = expf(logits[tid] - m);
            weights[tid] = p;
            float sum = p;
            #pragma unroll
            for (int offset = 32; offset > 0; offset >>= 1)
                sum += __shfl_xor(sum, offset, 64);
            if (tid == 0) {
                float alpha = expf(maximum - m);
                correction = alpha;
                denominator = denominator * alpha + sum;
                maximum = m;
            }
        }
        __syncthreads();

        if (tid < D) {
            acc *= correction;
            const int count = min(64, row - start + 1);
            for (int j = 0; j < count; ++j)
                acc = fmaf(weights[j],
                           float(v[int64_t(start + j) * vr + tid * vd]),
                           acc);
        }
        __syncthreads();
    }
    if (tid < D) out[tid] = T(acc / denominator);
}

torch::Tensor attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v, double scale)
{
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda(),
                "Inputs must be accelerator tensors");
    TORCH_CHECK(q.device() == k.device() && q.device() == v.device(),
                "Inputs must be on the same device");
    TORCH_CHECK(q.dim() == 4 && k.dim() == 4 && v.dim() == 4,
                "Expected HND tensors");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type(), "Dtypes must match");
    const int64_t B = q.size(0), Hq = q.size(1);
    const int64_t L = q.size(2), D = q.size(3), Hkv = k.size(1);
    TORCH_CHECK(Hkv > 0 && Hq % Hkv == 0, "Invalid GQA head count");
    TORCH_CHECK(k.size(0) == B && k.size(2) == L && k.size(3) == D &&
                v.sizes() == k.sizes(), "Incompatible input shapes");
    TORCH_CHECK(D == 64 || D == 128, "Head dimension must be 64 or 128");

    c10::cuda::CUDAGuard guard(q.device());
    auto out = torch::empty(q.sizes(), q.options());
    if (out.numel() == 0) return out;
    auto stream = at::cuda::getCurrentCUDAStream();
    dim3 grid(L, Hq, B);

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "causal_attention", [&] {
        #define LAUNCH(DIM) \
            hipLaunchKernelGGL((causal_attention<scalar_t, DIM>), \
                grid, dim3(256), 0, stream.stream(), \
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), \
                v.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), \
                int(L), int(Hq), int(Hkv), float(scale), \
                q.stride(0), q.stride(1), q.stride(2), q.stride(3), \
                k.stride(0), k.stride(1), k.stride(2), k.stride(3), \
                v.stride(0), v.stride(1), v.stride(2), v.stride(3))
        if (D == 64) { LAUNCH(64); }
        else { LAUNCH(128); }
        #undef LAUNCH
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "hygon_causal_attention_" + hashlib.sha256(
            (_CPP + _HIP).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-std=c++17"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = (
            float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        )

    def forward(self, q, k, v):
        return _get_extension().forward(q, k, v, self.sm_scale)
```