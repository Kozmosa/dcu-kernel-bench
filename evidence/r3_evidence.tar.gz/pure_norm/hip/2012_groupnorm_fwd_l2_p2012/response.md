```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor groupnorm_forward(torch::Tensor x, torch::Tensor scale,
                                torch::Tensor bias, int64_t groups,
                                double eps, bool swish);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &groupnorm_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>
#include <algorithm>
#include <cstdint>

constexpr int THREADS = 256;
constexpr int TILE = 4096;

__device__ __forceinline__ float reduce_sum(float v, float* smem) {
    const int t = threadIdx.x;
    smem[t] = v;
    __syncthreads();
    for (int stride = THREADS / 2; stride; stride >>= 1) {
        if (t < stride) smem[t] += smem[t + stride];
        __syncthreads();
    }
    float result = smem[0];
    __syncthreads();
    return result;
}

template<bool SWISH>
__device__ __forceinline__ float affine(
    float x, float mean, float inv, float scale, float bias) {
    float y = ((x - mean) * inv) * scale + bias;
    if (SWISH) y = y / (1.0f + expf(-y));
    return y;
}

template<bool SWISH>
__global__ void fused_group(
    const float* __restrict__ x,
    const float* __restrict__ scale,
    const float* __restrict__ bias,
    float* __restrict__ out,
    int64_t D, int64_t spatial, int64_t C,
    int64_t count, int64_t total, float eps) {
    __shared__ float smem[THREADS];
    const int64_t group = blockIdx.x;
    const int64_t base = group * D;
    float sum = 0.0f;
    for (int64_t i = threadIdx.x; i < D; i += THREADS)
        sum += x[base + i];
    const float mean = reduce_sum(sum, smem) / float(D);

    float variance = 0.0f;
    for (int64_t i = threadIdx.x; i < D; i += THREADS) {
        float d = x[base + i] - mean;
        variance += d * d;
    }
    const float inv = rsqrtf(reduce_sum(variance, smem) / float(D) + eps);
    if (threadIdx.x == 0) {
        out[total + group] = mean;
        out[total + count + group] = inv;
    }
    for (int64_t i = threadIdx.x; i < D; i += THREADS) {
        int64_t c = ((base + i) / spatial) % C;
        out[base + i] = affine<SWISH>(
            x[base + i], mean, inv, scale[c], bias[c]);
    }
}

__global__ void partial_stats(
    const float* __restrict__ x, float* __restrict__ partial,
    int64_t D, int parts) {
    __shared__ float smem[THREADS];
    int64_t group = blockIdx.x / parts;
    int part = blockIdx.x % parts;
    int64_t start = int64_t(part) * TILE;
    int length = int(D - start < TILE ? D - start : TILE);
    int64_t base = group * D + start;

    float values[TILE / THREADS];
    float sum = 0.0f;
    #pragma unroll
    for (int j = 0; j < TILE / THREADS; ++j) {
        int i = threadIdx.x + j * THREADS;
        float v = i < length ? x[base + i] : 0.0f;
        values[j] = v;
        sum += v;
    }
    float mean = reduce_sum(sum, smem) / float(length);
    float variance = 0.0f;
    #pragma unroll
    for (int j = 0; j < TILE / THREADS; ++j) {
        int i = threadIdx.x + j * THREADS;
        float d = i < length ? values[j] - mean : 0.0f;
        variance += d * d;
    }
    variance = reduce_sum(variance, smem);
    if (threadIdx.x == 0) {
        int64_t p = (group * parts + part) * 2;
        partial[p] = mean;
        partial[p + 1] = variance;
    }
}

__global__ void finish_stats(
    const float* __restrict__ partial, float* __restrict__ out,
    int64_t D, int parts, int64_t count, int64_t total, float eps) {
    __shared__ float smem[THREADS];
    int64_t group = blockIdx.x;
    float sum = 0.0f;
    for (int p = threadIdx.x; p < parts; p += THREADS) {
        int length = int(D - int64_t(p) * TILE < TILE
                         ? D - int64_t(p) * TILE : TILE);
        sum += partial[(group * parts + p) * 2] * float(length);
    }
    float mean = reduce_sum(sum, smem) / float(D);
    float variance = 0.0f;
    for (int p = threadIdx.x; p < parts; p += THREADS) {
        int length = int(D - int64_t(p) * TILE < TILE
                         ? D - int64_t(p) * TILE : TILE);
        int64_t offset = (group * parts + p) * 2;
        float d = partial[offset] - mean;
        variance += partial[offset + 1] + d * d * float(length);
    }
    float inv = rsqrtf(reduce_sum(variance, smem) / float(D) + eps);
    if (threadIdx.x == 0) {
        out[total + group] = mean;
        out[total + count + group] = inv;
    }
}

template<bool SWISH>
__global__ void apply_norm(
    const float* __restrict__ x,
    const float* __restrict__ scale,
    const float* __restrict__ bias,
    float* __restrict__ out,
    int64_t D, int64_t spatial, int64_t C,
    int64_t count, int64_t total) {
    int64_t i = int64_t(blockIdx.x) * THREADS * 4 + threadIdx.x;
    #pragma unroll
    for (int j = 0; j < 4; ++j, i += THREADS) {
        if (i < total) {
            int64_t group = i / D;
            int64_t c = (i / spatial) % C;
            out[i] = affine<SWISH>(
                x[i], out[total + group], out[total + count + group],
                scale[c], bias[c]);
        }
    }
}

torch::Tensor groupnorm_forward(
    torch::Tensor x, torch::Tensor scale, torch::Tensor bias,
    int64_t groups, double eps, bool swish) {
    TORCH_CHECK(x.is_cuda() && scale.is_cuda() && bias.is_cuda(),
                "Inputs must be on the accelerator");
    TORCH_CHECK(x.device() == scale.device() && x.device() == bias.device(),
                "Inputs must share a device");
    TORCH_CHECK(x.scalar_type() == at::kFloat &&
                scale.scalar_type() == at::kFloat &&
                bias.scalar_type() == at::kFloat, "Expected float32 inputs");
    TORCH_CHECK(x.dim() == 4 && x.is_contiguous() &&
                scale.is_contiguous() && bias.is_contiguous(),
                "Expected contiguous NCHW input and affine parameters");
    int64_t N = x.size(0), C = x.size(1);
    int64_t spatial = x.size(2) * x.size(3);
    TORCH_CHECK(N > 0 && C > 0 && spatial > 0 &&
                groups > 0 && groups <= C && C % groups == 0,
                "Invalid shape or groups");
    TORCH_CHECK(scale.dim() == 1 && bias.dim() == 1 &&
                scale.numel() == C && bias.numel() == C,
                "Affine parameters must have shape (C,)");

    c10::cuda::CUDAGuard guard(x.device());
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
    int64_t total = x.numel(), count = N * groups;
    int64_t D = (C / groups) * spatial;
    auto out = torch::empty({total + 2 * count}, x.options());
    const float* xp = x.data_ptr<float>();
    const float* sp = scale.data_ptr<float>();
    const float* bp = bias.data_ptr<float>();
    float* op = out.data_ptr<float>();

    if (D <= 4096 || (D <= 16384 && count >= 128)) {
        if (swish)
            fused_group<true><<<count, THREADS, 0, stream.stream()>>>(
                xp, sp, bp, op, D, spatial, C, count, total, float(eps));
        else
            fused_group<false><<<count, THREADS, 0, stream.stream()>>>(
                xp, sp, bp, op, D, spatial, C, count, total, float(eps));
    } else {
        int parts = int((D + TILE - 1) / TILE);
        auto partial = torch::empty({count * parts * 2}, x.options());
        partial_stats<<<count * parts, THREADS, 0, stream.stream()>>>(
            xp, partial.data_ptr<float>(), D, parts);
        finish_stats<<<count, THREADS, 0, stream.stream()>>>(
            partial.data_ptr<float>(), op, D, parts, count, total, float(eps));
        int64_t blocks = (total + THREADS * 4 - 1) / (THREADS * 4);
        if (swish)
            apply_norm<true><<<blocks, THREADS, 0, stream.stream()>>>(
                xp, sp, bp, op, D, spatial, C, count, total);
        else
            apply_norm<false><<<blocks, THREADS, 0, stream.stream()>>>(
                xp, sp, bp, op, D, spatial, C, count, total);
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "hip_packed_groupnorm_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "groupnorm", groups: int = 2, eps: float = 1e-5):
        super().__init__()
        assert variant in ("groupnorm", "groupnorm_swish")
        assert int(groups) >= 1
        assert eps > 0
        self.variant = variant
        self.groups = int(groups)
        self.eps = float(eps)

    def forward(self, x, scale, bias):
        return _get_extension().forward(
            x, scale, bias, self.groups, self.eps,
            self.variant == "groupnorm_swish",
        )
```