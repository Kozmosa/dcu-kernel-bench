```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>

torch::Tensor pyramid_forward(
    torch::Tensor x, torch::Tensor weight, torch::Tensor bias,
    bool use_bias, int64_t output_type);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &pyramid_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>

__device__ __forceinline__ float round_bf16(float value) {
    unsigned int bits = __float_as_uint(value);
    if ((bits & 0x7fffffffU) > 0x7f800000U)
        return __uint_as_float(bits | 0x00400000U);
    bits += 0x7fffU + ((bits >> 16) & 1U);
    return __uint_as_float(bits & 0xffff0000U);
}

template <typename Output, bool Bias>
__global__ __launch_bounds__(256)
void batched_gemm(
    const float* __restrict__ x,
    const float* __restrict__ w,
    const float* __restrict__ bias,
    Output* __restrict__ output,
    int64_t M, int64_t N, int64_t K,
    int64_t xb, int64_t xm, int64_t xk,
    int64_t wb, int64_t wn, int64_t wk,
    int64_t bb, int64_t bn)
{
    __shared__ float a[64][17];
    __shared__ float v[64][17];

    const int tid = threadIdx.x;
    const int tx = tid & 15;
    const int ty = tid >> 4;
    const int64_t batch = blockIdx.z;
    const int64_t row_base = int64_t(blockIdx.y) * 64;
    const int64_t col_base = int64_t(blockIdx.x) * 64;

    x += batch * xb;
    w += batch * wb;

    float accum[4][4] = {};

    for (int64_t kb = 0; kb < K; kb += 16) {
        #pragma unroll
        for (int q = 0; q < 4; ++q) {
            const int index = tid + q * 256;
            const int row = index >> 4;
            const int k = index & 15;
            const int64_t kk = kb + k;
            a[row][k] = row_base + row < M && kk < K
                ? round_bf16(x[(row_base + row) * xm + kk * xk])
                : 0.0f;
            v[row][k] = col_base + row < N && kk < K
                ? round_bf16(w[(col_base + row) * wn + kk * wk])
                : 0.0f;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < 16; ++k) {
            float av[4], bv[4];
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                av[i] = a[ty + i * 16][k];
                bv[i] = v[tx + i * 16][k];
            }
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                #pragma unroll
                for (int j = 0; j < 4; ++j)
                    accum[i][j] = fmaf(av[i], bv[j], accum[i][j]);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int j = 0; j < 4; ++j) {
        const int64_t col = col_base + tx + j * 16;
        float bias_value = 0.0f;
        if (Bias && col < N)
            bias_value = round_bf16(bias[batch * bb + col * bn]);

        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            const int64_t row = row_base + ty + i * 16;
            if (row < M && col < N) {
                float result = accum[i][j];
                if (Bias)
                    result = round_bf16(round_bf16(result) + bias_value);
                output[(batch * M + row) * N + col] =
                    static_cast<Output>(result);
            }
        }
    }
}

torch::Tensor pyramid_forward(
    torch::Tensor x, torch::Tensor weight, torch::Tensor bias,
    bool use_bias, int64_t output_type)
{
    TORCH_CHECK(x.is_cuda() && weight.is_cuda(),
                "x and weight must reside on the accelerator");
    TORCH_CHECK(x.scalar_type() == at::kFloat &&
                weight.scalar_type() == at::kFloat,
                "x and weight must be fp32");
    TORCH_CHECK(x.dim() == 3 && weight.dim() == 3,
                "x and weight must have three dimensions");
    TORCH_CHECK(x.device() == weight.device(),
                "x and weight must be on the same device");

    const int64_t B = x.size(0), M = x.size(1), K = x.size(2);
    const int64_t N = weight.size(1);
    TORCH_CHECK(weight.size(0) == B && weight.size(2) == K,
                "incompatible batch or K dimensions");

    if (use_bias) {
        TORCH_CHECK(bias.is_cuda() && bias.device() == x.device() &&
                    bias.scalar_type() == at::kFloat,
                    "bias must be fp32 on the input device");
        TORCH_CHECK(bias.dim() == 3 && bias.size(0) == B &&
                    bias.size(1) == 1 && bias.size(2) == N,
                    "bias must have shape (B, 1, N)");
    }

    c10::cuda::CUDAGuard guard(x.device());
    const auto dtype = static_cast<at::ScalarType>(output_type);
    auto output = torch::empty({B, M, N}, x.options().dtype(dtype));
    if (output.numel() == 0)
        return output;

    TORCH_CHECK(B <= 65535 && (M + 63) / 64 <= 65535,
                "batch or row dimension exceeds launch limits");

    const dim3 grid((N + 63) / 64, (M + 63) / 64, B);
    auto stream = at::cuda::getCurrentCUDAStream(x.get_device());
    const float* bp = use_bias ? bias.data_ptr<float>() : nullptr;
    const int64_t bb = use_bias ? bias.stride(0) : 0;
    const int64_t bn = use_bias ? bias.stride(2) : 0;

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        dtype, "pyramid_batched_gemm", [&] {
            if (use_bias) {
                batched_gemm<scalar_t, true><<<grid, 256, 0, stream>>>(
                    x.data_ptr<float>(), weight.data_ptr<float>(), bp,
                    output.data_ptr<scalar_t>(), M, N, K,
                    x.stride(0), x.stride(1), x.stride(2),
                    weight.stride(0), weight.stride(1), weight.stride(2),
                    bb, bn);
            } else {
                batched_gemm<scalar_t, false><<<grid, 256, 0, stream>>>(
                    x.data_ptr<float>(), weight.data_ptr<float>(), bp,
                    output.data_ptr<scalar_t>(), M, N, K,
                    x.stride(0), x.stride(1), x.stride(2),
                    weight.stride(0), weight.stride(1), weight.stride(2),
                    bb, bn);
            }
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha256((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"pyramid_batched_gemm_{digest}",
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        type_codes = {
            torch.float16: 5,
            torch.float32: 6,
            torch.float64: 7,
            torch.bfloat16: 15,
        }
        if self.out_dtype not in type_codes:
            raise ValueError(f"Unsupported output dtype: {out_dtype}")
        self._output_type = type_codes[self.out_dtype]

    def forward(self, x, weight, bias):
        return _get_extension().forward(
            x, weight, bias if self.use_bias else x,
            self.use_bias, self._output_type
        )
```