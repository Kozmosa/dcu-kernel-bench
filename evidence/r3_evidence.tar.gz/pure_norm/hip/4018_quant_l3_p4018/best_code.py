import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
void quantize_hip(torch::Tensor x, torch::Tensor scale,
                  torch::Tensor out, torch::Tensor scratch,
                  int64_t mode, bool fp8);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("quantize", &quantize_hip);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/hip/HIPException.h>
#include <cmath>
#include <cstdint>

constexpr int BLOCK = 256;

__device__ __forceinline__ float block_max(float v) {
    __shared__ float partial[BLOCK / 64];
    const int lane = threadIdx.x & 63;
    const int wave = threadIdx.x >> 6;
    #pragma unroll
    for (int d = 32; d; d >>= 1)
        v = fmaxf(v, __shfl_down(v, d, 64));
    if (lane == 0) partial[wave] = v;
    __syncthreads();
    v = threadIdx.x < BLOCK / 64 ? partial[lane] : 0.0f;
    if (wave == 0) {
        #pragma unroll
        for (int d = 32; d; d >>= 1)
            v = fmaxf(v, __shfl_down(v, d, 64));
    }
    return v;
}

template<bool FP8>
__device__ __forceinline__ float encode(float v) {
    if constexpr (!FP8) {
        return nearbyintf(v);
    } else {
        // E4M3 has three fraction bits and subnormal spacing 2^-9.
        const float a = fabsf(v);
        const unsigned bits = __float_as_uint(a);
        int exponent = int((bits >> 23) & 255) - 127;
        exponent = exponent < -6 ? -6 : exponent;
        const float step = __uint_as_float(unsigned(exponent - 3 + 127) << 23);
        const float inv_step = __uint_as_float(unsigned(127 - exponent + 3) << 23);
        const float rounded = nearbyintf(a * inv_step) * step;
        return copysignf(rounded, v);
    }
}

template<bool FP8>
__global__ void per_row(const float* __restrict__ x,
                        float* __restrict__ out,
                        int64_t rows, int64_t cols) {
    const int64_t row = blockIdx.x;
    const int64_t base = row * cols;
    float mx = 0.0f;
    for (int64_t c = threadIdx.x; c < cols; c += BLOCK)
        mx = fmaxf(mx, fabsf(x[base + c]));
    mx = block_max(mx);
    __shared__ float reciprocal;
    if (threadIdx.x == 0) {
        const float s = fmaxf(mx, 1.0e-10f) / (FP8 ? 448.0f : 127.0f);
        out[rows * cols + row] = s;
        reciprocal = 1.0f / s;
    }
    __syncthreads();
    const float inv = reciprocal;
    for (int64_t c = threadIdx.x; c < cols; c += BLOCK)
        out[base + c] = encode<FP8>(x[base + c] * inv);
}

__global__ void reduce_tiles(const float* __restrict__ x,
                             float* __restrict__ scratch, int64_t n) {
    float mx = 0.0f;
    for (int64_t i = int64_t(blockIdx.x) * BLOCK + threadIdx.x;
         i < n; i += int64_t(gridDim.x) * BLOCK)
        mx = fmaxf(mx, fabsf(x[i]));
    mx = block_max(mx);
    if (threadIdx.x == 0) scratch[blockIdx.x] = mx;
}

template<bool FP8>
__global__ void reduce_scale(const float* __restrict__ scratch,
                             float* __restrict__ out, int count, int64_t n) {
    float mx = 0.0f;
    for (int i = threadIdx.x; i < count; i += BLOCK)
        mx = fmaxf(mx, scratch[i]);
    mx = block_max(mx);
    if (threadIdx.x == 0)
        out[n] = mx / (FP8 ? 448.0f : 127.0f);
}

template<bool FP8, bool STATIC>
__global__ void tensor_quantize(const float* __restrict__ x,
                                const float* __restrict__ scale,
                                float* __restrict__ out, int64_t n) {
    const float s = STATIC ? scale[0] : out[n];
    if (STATIC && blockIdx.x == 0 && threadIdx.x == 0) out[n] = s;
    for (int64_t i = int64_t(blockIdx.x) * BLOCK + threadIdx.x;
         i < n; i += int64_t(gridDim.x) * BLOCK)
        out[i] = encode<FP8>(x[i] / s);
}

template<bool FP8>
void launch(const torch::Tensor& x, const torch::Tensor& scale,
            torch::Tensor& out, torch::Tensor& scratch,
            int mode, hipStream_t stream) {
    const int64_t rows = x.size(0), cols = x.size(1), n = x.numel();
    const float* xp = x.data_ptr<float>();
    float* yp = out.data_ptr<float>();
    if (mode == 2) {
        if (rows)
            hipLaunchKernelGGL((per_row<FP8>), dim3(rows), dim3(BLOCK),
                               0, stream, xp, yp, rows, cols);
        return;
    }
    int blocks = int((n + BLOCK - 1) / BLOCK);
    blocks = blocks < 1 ? 1 : (blocks > 4096 ? 4096 : blocks);
    if (mode == 0) {
        hipLaunchKernelGGL((tensor_quantize<FP8, true>),
                           dim3(blocks), dim3(BLOCK), 0, stream,
                           xp, scale.data_ptr<float>(), yp, n);
    } else {
        const int tiles = int(scratch.numel());
        hipLaunchKernelGGL(reduce_tiles, dim3(tiles), dim3(BLOCK),
                           0, stream, xp, scratch.data_ptr<float>(), n);
        hipLaunchKernelGGL((reduce_scale<FP8>), dim3(1), dim3(BLOCK),
                           0, stream, scratch.data_ptr<float>(), yp, tiles, n);
        hipLaunchKernelGGL((tensor_quantize<FP8, false>),
                           dim3(blocks), dim3(BLOCK), 0, stream,
                           xp, nullptr, yp, n);
    }
}

void quantize_hip(torch::Tensor x, torch::Tensor scale,
                  torch::Tensor out, torch::Tensor scratch,
                  int64_t mode, bool fp8) {
    TORCH_CHECK(x.is_cuda() && x.scalar_type() == at::kFloat,
                "x must be a GPU float32 tensor");
    TORCH_CHECK(x.dim() == 2 && x.is_contiguous(),
                "x must be contiguous and two-dimensional");
    c10::cuda::CUDAGuard guard(x.device());
    hipStream_t stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    if (fp8)
        launch<true>(x, scale, out, scratch, int(mode), stream);
    else
        launch<false>(x, scale, out, scratch, int(mode), stream);
    C10_HIP_CHECK(hipGetLastError());
}
"""

_EXTENSION = None


def _extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name="quantization_hip_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-fno-fast-math", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, mode: str = "dynamic_per_token", quant_dtype: str = "int8"):
        super().__init__()
        assert mode in (
            "static_per_tensor", "dynamic_per_tensor", "dynamic_per_token"
        ), "invalid mode"
        assert quant_dtype in ("int8", "float8_e4m3"), (
            "quant_dtype must be int8 or float8_e4m3"
        )
        self.mode = mode
        self.quant_dtype = (
            torch.int8 if quant_dtype == "int8" else torch.float8_e4m3fn
        )

    def forward(self, x, scale=None):
        assert x.dim() == 2, "x must be a 2D tensor"
        assert x.is_contiguous(), "x must be contiguous"
        x = x.to(dtype=torch.float32)
        rows, cols = x.shape
        n = rows * cols
        mode = {
            "static_per_tensor": 0,
            "dynamic_per_tensor": 1,
            "dynamic_per_token": 2,
        }[self.mode]
        out = torch.empty(
            n + (rows if mode == 2 else 1),
            dtype=torch.float32,
            device=x.device,
        )
        tiles = min(1024, max(1, (n + 4095) // 4096))
        scratch = torch.empty(
            tiles if mode == 1 else 0, dtype=torch.float32, device=x.device
        )
        if mode == 0:
            assert scale is not None and scale.numel() == 1
            scale_arg = scale.to(device=x.device, dtype=torch.float32).contiguous()
        else:
            scale_arg = scratch
        _extension().quantize(
            x, scale_arg, out, scratch, mode, self.quant_dtype != torch.int8
        )
        return out
