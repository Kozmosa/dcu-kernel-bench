```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor run_ctc(torch::Tensor probs, torch::Tensor labels,
                      torch::Tensor lengths, torch::Tensor times, int64_t blank);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run_ctc", &run_ctc);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <algorithm>

__device__ __forceinline__ float lse3(float a, float b, float c) {
    float m = fmaxf(a, fmaxf(b, c));
    if (m == -INFINITY) return m;
    return m + logf(expf(a - m) + expf(b - m) + expf(c - m));
}

__device__ __forceinline__ int symbol(
    const int64_t* labels, int64_t offset, int s, int blank) {
    return (s & 1) ? int(labels[offset + (s >> 1)]) : blank;
}

template <typename scalar_t>
__global__ void make_logp(const scalar_t* __restrict__ p,
                         float* __restrict__ lp, int64_t count) {
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         i < count; i += int64_t(gridDim.x) * blockDim.x)
        lp[i] = logf(float(p[i]));
}

template <typename scalar_t>
__global__ void recurrence(
    const float* __restrict__ lp,
    const int64_t* __restrict__ labels,
    const int64_t* __restrict__ lengths,
    const int64_t* __restrict__ times,
    float* __restrict__ states,
    float* __restrict__ scratch,
    scalar_t* __restrict__ out,
    int T, int N, int C, int M, int blank) {

    int n = blockIdx.x;
    int L = int(lengths[n]);
    int S = 2 * L + 1;
    int tb = int(times[n]);
    int64_t offset = 0;
    for (int i = 0; i < n; ++i) offset += lengths[i];

    float* a = states + int64_t(n) * T * M;
    float* b0 = scratch + int64_t(n) * 2 * M;
    float* b1 = b0 + M;

    for (int s = threadIdx.x; s < S; s += blockDim.x) {
        int k = symbol(labels, offset, s, blank);
        a[s] = s < 2 ? lp[int64_t(n) * C + k] : -INFINITY;
    }
    __syncthreads();

    for (int t = 1; t < tb; ++t) {
        float* prev = a + int64_t(t - 1) * M;
        float* cur = a + int64_t(t) * M;
        for (int s = threadIdx.x; s < S; s += blockDim.x) {
            int k = symbol(labels, offset, s, blank);
            float x = prev[s];
            float y = s > 0 ? prev[s - 1] : -INFINITY;
            float z = -INFINITY;
            if (s >= 2 && k != blank &&
                k != symbol(labels, offset, s - 2, blank))
                z = prev[s - 2];
            cur[s] = lp[(int64_t(t) * N + n) * C + k] + lse3(x, y, z);
        }
        __syncthreads();
    }

    __shared__ float logz;
    if (threadIdx.x == 0) {
        float* last = a + int64_t(tb - 1) * M;
        logz = lse3(last[S - 1], S > 1 ? last[S - 2] : -INFINITY,
                    -INFINITY);
        out[n] = scalar_t(-logz);
    }
    for (int s = threadIdx.x; s < S; s += blockDim.x)
        b0[s] = s >= S - 2 ? 0.0f : -INFINITY;
    __syncthreads();

    for (int t = tb - 1; t >= 0; --t) {
        for (int s = threadIdx.x; s < S; s += blockDim.x) {
            int64_t i = int64_t(t) * M + s;
            a[i] = expf((a[i] + b0[s]) - logz);
        }
        if (t > 0) {
            for (int s = threadIdx.x; s < S; s += blockDim.x) {
                int k = symbol(labels, offset, s, blank);
                int64_t base = (int64_t(t) * N + n) * C;
                float x = b0[s] + lp[base + k];
                float y = -INFINITY;
                float z = -INFINITY;
                if (s + 1 < S) {
                    int k1 = symbol(labels, offset, s + 1, blank);
                    y = b0[s + 1] + lp[base + k1];
                }
                if (s + 2 < S && k != blank) {
                    int k2 = symbol(labels, offset, s + 2, blank);
                    if (k != k2) z = b0[s + 2] + lp[base + k2];
                }
                b1[s] = lse3(x, y, z);
            }
        }
        __syncthreads();
        float* tmp = b0;
        b0 = b1;
        b1 = tmp;
    }
}

template <typename scalar_t>
__global__ void assemble(
    const scalar_t* __restrict__ p,
    float* __restrict__ workspace,
    const float* __restrict__ states,
    const int64_t* __restrict__ labels,
    const int64_t* __restrict__ lengths,
    const int64_t* __restrict__ times,
    scalar_t* __restrict__ out,
    int T, int N, int C, int M, int blank) {

    int n = blockIdx.x;
    int t = blockIdx.y;
    int64_t input_base = (int64_t(t) * N + n) * C;
    int64_t output_base = N + (int64_t(n) * T + t) * C;

    if (t >= times[n]) {
        for (int k = threadIdx.x; k < C; k += blockDim.x)
            out[output_base + k] = scalar_t(0.0f);
        return;
    }

    float* sums = workspace + input_base;
    for (int k = threadIdx.x; k < C; k += blockDim.x)
        sums[k] = 0.0f;
    __syncthreads();

    int64_t offset = 0;
    for (int i = 0; i < n; ++i) offset += lengths[i];
    int S = 2 * int(lengths[n]) + 1;
    const float* gamma = states + (int64_t(n) * T + t) * M;
    for (int s = threadIdx.x; s < S; s += blockDim.x) {
        int k = symbol(labels, offset, s, blank);
        atomicAdd(sums + k, -gamma[s]);
    }
    __syncthreads();

    for (int k = threadIdx.x; k < C; k += blockDim.x)
        out[output_base + k] =
            scalar_t(sums[k] / float(p[input_base + k]));
}

torch::Tensor run_ctc(torch::Tensor probs, torch::Tensor labels,
                      torch::Tensor lengths, torch::Tensor times,
                      int64_t blank) {
    TORCH_CHECK(probs.is_cuda() && probs.is_contiguous(),
                "probs must be contiguous on the accelerator");
    TORCH_CHECK(probs.dim() == 3, "probs must have shape (T,N,C)");
    c10::cuda::CUDAGuard guard(probs.device());
    int T = probs.size(0);
    int N = probs.size(1);
    int C = probs.size(2);
    int M = int(2 * std::min<int64_t>(T, labels.numel()) + 1);

    auto opts = probs.options().dtype(torch::kFloat32);
    auto lp = torch::empty({T, N, C}, opts);
    auto states = torch::empty({N, T, M}, opts);
    auto scratch = torch::empty({N, 2, M}, opts);
    auto out = torch::empty({int64_t(N) + int64_t(N) * T * C},
                            probs.options());
    if (N == 0) return out;

    auto stream = at::cuda::getCurrentCUDAStream();
    int blocks = int(std::min<int64_t>((probs.numel() + 255) / 256, 65535));
    int threads = M <= 64 ? 64 : (M <= 128 ? 128 : 256);

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        probs.scalar_type(), "custom_ctc", [&] {
            make_logp<scalar_t><<<blocks, 256, 0, stream>>>(
                probs.data_ptr<scalar_t>(), lp.data_ptr<float>(),
                probs.numel());
            recurrence<scalar_t><<<N, threads, 0, stream>>>(
                lp.data_ptr<float>(), labels.data_ptr<int64_t>(),
                lengths.data_ptr<int64_t>(), times.data_ptr<int64_t>(),
                states.data_ptr<float>(), scratch.data_ptr<float>(),
                out.data_ptr<scalar_t>(), T, N, C, M, int(blank));
            assemble<scalar_t><<<dim3(N, T), 256, 0, stream>>>(
                probs.data_ptr<scalar_t>(), lp.data_ptr<float>(),
                states.data_ptr<float>(), labels.data_ptr<int64_t>(),
                lengths.data_ptr<int64_t>(), times.data_ptr<int64_t>(),
                out.data_ptr<scalar_t>(), T, N, C, M, int(blank));
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "ctc_forward_hip_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, blank: int = 0):
        super().__init__()
        self.blank = int(blank)

    def forward(self, probs, labels, label_lengths, input_lengths):
        labels = labels.to(device=probs.device, dtype=torch.long).contiguous()
        label_lengths = label_lengths.to(
            device=probs.device, dtype=torch.long
        ).contiguous()
        input_lengths = input_lengths.to(
            device=probs.device, dtype=torch.long
        ).contiguous()
        return _get_extension().run_ctc(
            probs, labels, label_lengths, input_lengths, self.blank
        )
```