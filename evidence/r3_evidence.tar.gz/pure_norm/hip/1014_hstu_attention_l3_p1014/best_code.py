import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor hstu_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor offsets, torch::Tensor targets,
    int64_t n, double alpha, bool causal, int64_t window, int64_t context);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &hstu_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cstdint>

constexpr int TILE = 32;

template<typename scalar_t>
__global__ __launch_bounds__(256)
void scores_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k,
    const int64_t* __restrict__ offsets,
    const int32_t* __restrict__ targets,
    float* __restrict__ weights,
    int H, int D, int N, float alpha, float inv_n,
    bool causal, int window, int context,
    int64_t qs0, int64_t qs1, int64_t qs2,
    int64_t ks0, int64_t ks1, int64_t ks2)
{
    const int h = blockIdx.z % H;
    const int b = blockIdx.z / H;
    const int64_t start = offsets[b];
    const int L = int(offsets[b + 1] - start);
    const int row0 = blockIdx.y * TILE;
    const int col0 = blockIdx.x * TILE;
    if (row0 >= L || col0 >= L) return;

    const int cap = (context ? L - context + 1 : L) - targets[b];
    const int tx = threadIdx.x;
    const int ty = threadIdx.y;
    const int tid = ty * 16 + tx;

    __shared__ float a[TILE][TILE + 1];
    __shared__ float bt[TILE][TILE + 1];
    float accum[2][2] = {{0.f, 0.f}, {0.f, 0.f}};

    for (int base = 0; base < D; base += TILE) {
        #pragma unroll
        for (int p = 0; p < 4; ++p) {
            const int u = tid + p * 256;
            const int r = u / TILE;
            const int d = u % TILE;
            const int dim = base + d;
            a[r][d] = (row0 + r < L && dim < D)
                ? float(q[(start + row0 + r) * qs0 + h * qs1 + dim * qs2])
                : 0.f;
            bt[r][d] = (col0 + r < L && dim < D)
                ? float(k[(start + col0 + r) * ks0 + h * ks1 + dim * ks2])
                : 0.f;
        }
        __syncthreads();
        #pragma unroll
        for (int d = 0; d < TILE; ++d) {
            const float a0 = a[ty][d];
            const float a1 = a[ty + 16][d];
            const float b0 = bt[tx][d];
            const float b1 = bt[tx + 16][d];
            accum[0][0] = fmaf(a0, b0, accum[0][0]);
            accum[0][1] = fmaf(a0, b1, accum[0][1]);
            accum[1][0] = fmaf(a1, b0, accum[1][0]);
            accum[1][1] = fmaf(a1, b1, accum[1][1]);
        }
        __syncthreads();
    }

    #pragma unroll
    for (int ir = 0; ir < 2; ++ir) {
        const int i = row0 + ty + ir * 16;
        int mi = context ? max(i - context + 1, 0) : i;
        mi = min(mi, cap);
        #pragma unroll
        for (int jc = 0; jc < 2; ++jc) {
            const int j = col0 + tx + jc * 16;
            if (i < L && j < L) {
                int mj = context ? max(j - context + 1, 0) : j;
                mj = min(mj, cap);
                int distance = mi - mj;
                if (!causal) distance = abs(distance);
                bool valid = i == j || distance > 0;
                if (window > 0) valid = valid && distance <= window;
                if (context > 0)
                    valid = valid || (mi == 0 && mj < cap);
                float w = 0.f;
                if (valid) {
                    const float x = accum[ir][jc] * alpha;
                    w = (x / (1.f + expf(-x))) * inv_n;
                }
                weights[((start + i) * H + h) * int64_t(N) + j] = w;
            }
        }
    }
}

template<typename scalar_t>
__global__ __launch_bounds__(256)
void output_kernel(
    const float* __restrict__ weights,
    const scalar_t* __restrict__ v,
    const int64_t* __restrict__ offsets,
    scalar_t* __restrict__ out,
    int H, int V, int N,
    int64_t vs0, int64_t vs1, int64_t vs2)
{
    const int h = blockIdx.z % H;
    const int b = blockIdx.z / H;
    const int64_t start = offsets[b];
    const int L = int(offsets[b + 1] - start);
    const int row0 = blockIdx.y * TILE;
    const int col0 = blockIdx.x * TILE;
    if (row0 >= L || col0 >= V) return;

    const int tx = threadIdx.x;
    const int ty = threadIdx.y;
    const int tid = ty * 16 + tx;
    __shared__ float a[TILE][TILE + 1];
    __shared__ float bv[TILE][TILE + 1];
    float accum[2][2] = {{0.f, 0.f}, {0.f, 0.f}};

    for (int base = 0; base < L; base += TILE) {
        #pragma unroll
        for (int p = 0; p < 4; ++p) {
            const int u = tid + p * 256;
            const int r = u / TILE;
            const int c = u % TILE;
            a[r][c] = (row0 + r < L && base + c < L)
                ? weights[((start + row0 + r) * H + h) * int64_t(N) + base + c]
                : 0.f;
            bv[r][c] = (base + r < L && col0 + c < V)
                ? float(v[(start + base + r) * vs0 + h * vs1 + (col0 + c) * vs2])
                : 0.f;
        }
        __syncthreads();
        #pragma unroll
        for (int d = 0; d < TILE; ++d) {
            const float a0 = a[ty][d];
            const float a1 = a[ty + 16][d];
            const float b0 = bv[d][tx];
            const float b1 = bv[d][tx + 16];
            accum[0][0] = fmaf(a0, b0, accum[0][0]);
            accum[0][1] = fmaf(a0, b1, accum[0][1]);
            accum[1][0] = fmaf(a1, b0, accum[1][0]);
            accum[1][1] = fmaf(a1, b1, accum[1][1]);
        }
        __syncthreads();
    }

    #pragma unroll
    for (int ir = 0; ir < 2; ++ir) {
        const int row = row0 + ty + ir * 16;
        #pragma unroll
        for (int jc = 0; jc < 2; ++jc) {
            const int col = col0 + tx + jc * 16;
            if (row < L && col < V)
                out[((start + row) * H + h) * int64_t(V) + col]
                    = scalar_t(accum[ir][jc]);
        }
    }
}

torch::Tensor hstu_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor offsets, torch::Tensor targets,
    int64_t n, double alpha, bool causal, int64_t window, int64_t context)
{
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda(),
                "q, k and v must be device tensors");
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type(), "dtype mismatch");
    TORCH_CHECK(q.dim() == 3 && k.sizes() == q.sizes() &&
                v.dim() == 3 && v.size(0) == q.size(0) &&
                v.size(1) == q.size(1), "invalid input shapes");

    c10::cuda::CUDAGuard guard(q.device());
    auto out = torch::empty(v.sizes(), v.options());
    const int64_t total = q.size(0);
    if (total == 0 || v.numel() == 0) return out;
    TORCH_CHECK(n > 0, "max_seq_len must be positive");

    offsets = offsets.to(q.device(), at::kLong).contiguous();
    targets = targets.to(q.device(), at::kInt).contiguous();
    const int B = offsets.numel() - 1;
    const int H = q.size(1);
    const int D = q.size(2);
    const int V = v.size(2);
    TORCH_CHECK(B > 0 && targets.numel() == B, "invalid sequence metadata");
    TORCH_CHECK(int64_t(B) * H <= 65535, "too many batch/head pairs");

    auto weights = torch::empty({total, int64_t(H), n},
                               q.options().dtype(at::kFloat));
    const auto stream = at::cuda::getCurrentCUDAStream(q.get_device());
    const dim3 threads(16, 16);
    const dim3 score_grid((n + 31) / 32, (n + 31) / 32, B * H);
    const dim3 output_grid((V + 31) / 32, (n + 31) / 32, B * H);

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "hstu_forward", [&] {
            scores_kernel<scalar_t><<<score_grid, threads, 0, stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(),
                offsets.data_ptr<int64_t>(), targets.data_ptr<int32_t>(),
                weights.data_ptr<float>(), H, D, int(n),
                float(alpha), 1.f / float(n), causal, int(window), int(context),
                q.stride(0), q.stride(1), q.stride(2),
                k.stride(0), k.stride(1), k.stride(2));
            C10_CUDA_KERNEL_LAUNCH_CHECK();
            output_kernel<scalar_t><<<output_grid, threads, 0, stream>>>(
                weights.data_ptr<float>(), v.data_ptr<scalar_t>(),
                offsets.data_ptr<int64_t>(), out.data_ptr<scalar_t>(),
                H, V, int(n), v.stride(0), v.stride(1), v.stride(2));
            C10_CUDA_KERNEL_LAUNCH_CHECK();
        });
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "hstu_tiled_" + hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, max_seq_len: int, alpha=None, causal=True, max_attn_len=0, contextual_seq_len=0):
        super().__init__()
        self.max_seq_len = int(max_seq_len)
        self.alpha = float(alpha) if alpha is not None else None
        self.causal = bool(causal)
        self.max_attn_len = int(max_attn_len)
        self.contextual_seq_len = int(contextual_seq_len)

    def forward(self, q, k, v, seq_offsets, num_targets):
        alpha = self.alpha if self.alpha is not None else 1.0 / math.sqrt(q.shape[2])
        return _get_extension().forward(
            q, k, v, seq_offsets, num_targets,
            self.max_seq_len, alpha, self.causal,
            self.max_attn_len, self.contextual_seq_len,
        )
