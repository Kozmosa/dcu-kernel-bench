```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor pyramid_linear(torch::Tensor x, torch::Tensor weight);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("linear", &pyramid_linear);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template <typename T>
__global__ void small_linear(
    const T* __restrict__ x,
    const T* __restrict__ w,
    T* __restrict__ out,
    int64_t M, int64_t N, int64_t K,
    int64_t xs0, int64_t xs1,
    int64_t ws0, int64_t ws1)
{
    const int lane = threadIdx.x & 63;
    const int64_t index = int64_t(blockIdx.x) * 4 + threadIdx.x / 64;
    if (index >= M * N) return;

    const int64_t m = index / N;
    const int64_t n = index % N;
    float sum = 0.0f;
    for (int64_t k = lane; k < K; k += 64) {
        sum = fmaf(float(x[m * xs0 + k * xs1]),
                   float(w[n * ws0 + k * ws1]), sum);
    }
    #pragma unroll
    for (int delta = 32; delta > 0; delta >>= 1)
        sum += __shfl_down(sum, delta, 64);
    if (lane == 0) out[index] = T(sum);
}

template <typename T, int BM, int BN, int BK>
__global__ __launch_bounds__(256) void tiled_linear(
    const T* __restrict__ x,
    const T* __restrict__ w,
    T* __restrict__ out,
    int64_t M, int64_t N, int64_t K,
    int64_t xs0, int64_t xs1,
    int64_t ws0, int64_t ws1)
{
    constexpr int RM = BM / 16;
    constexpr int RN = BN / 16;
    __shared__ float a[BK][BM];
    __shared__ float b[BK][BN];

    const int tid = threadIdx.x;
    const int tx = tid & 15;
    const int ty = tid >> 4;
    const int64_t row0 = int64_t(blockIdx.y) * BM;
    const int64_t col0 = int64_t(blockIdx.x) * BN;
    float acc[RM][RN] = {};

    for (int64_t base = 0; base < K; base += BK) {
        #pragma unroll
        for (int p = tid; p < BM * BK; p += 256) {
            const int r = p / BK;
            const int k = p % BK;
            a[k][r] = (row0 + r < M && base + k < K)
                ? float(x[(row0 + r) * xs0 + (base + k) * xs1])
                : 0.0f;
        }
        #pragma unroll
        for (int p = tid; p < BN * BK; p += 256) {
            const int n = p / BK;
            const int k = p % BK;
            b[k][n] = (col0 + n < N && base + k < K)
                ? float(w[(col0 + n) * ws0 + (base + k) * ws1])
                : 0.0f;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < BK; ++k) {
            float av[RM];
            float bv[RN];
            #pragma unroll
            for (int i = 0; i < RM; ++i)
                av[i] = a[k][ty + 16 * i];
            #pragma unroll
            for (int j = 0; j < RN; ++j)
                bv[j] = b[k][tx + 16 * j];
            #pragma unroll
            for (int i = 0; i < RM; ++i) {
                #pragma unroll
                for (int j = 0; j < RN; ++j)
                    acc[i][j] = fmaf(av[i], bv[j], acc[i][j]);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < RM; ++i) {
        const int64_t m = row0 + ty + 16 * i;
        #pragma unroll
        for (int j = 0; j < RN; ++j) {
            const int64_t n = col0 + tx + 16 * j;
            if (m < M && n < N)
                out[m * N + n] = T(acc[i][j]);
        }
    }
}

template <typename T>
void launch_linear(
    const torch::Tensor& x, const torch::Tensor& w,
    torch::Tensor& out, hipStream_t stream)
{
    const int64_t M = x.size(0);
    const int64_t N = w.size(0);
    const int64_t K = x.size(1);
    const T* xp = x.data_ptr<T>();
    const T* wp = w.data_ptr<T>();
    T* op = out.data_ptr<T>();
    if (M * N <= 256) {
        small_linear<T><<<dim3((M * N + 3) / 4), 256, 0, stream>>>(
            xp, wp, op, M, N, K,
            x.stride(0), x.stride(1), w.stride(0), w.stride(1));
    } else if (M <= 32) {
        tiled_linear<T, 32, 64, 16>
            <<<dim3((N + 63) / 64, (M + 31) / 32), 256, 0, stream>>>(
                xp, wp, op, M, N, K,
                x.stride(0), x.stride(1), w.stride(0), w.stride(1));
    } else {
        tiled_linear<T, 64, 64, 16>
            <<<dim3((N + 63) / 64, (M + 63) / 64), 256, 0, stream>>>(
                xp, wp, op, M, N, K,
                x.stride(0), x.stride(1), w.stride(0), w.stride(1));
    }
}

torch::Tensor pyramid_linear(torch::Tensor x, torch::Tensor weight)
{
    TORCH_CHECK(x.is_cuda() && weight.is_cuda(), "Expected accelerator tensors");
    TORCH_CHECK(x.device() == weight.device(), "Inputs must share a device");
    TORCH_CHECK(x.dim() == 2 && weight.dim() == 2, "Expected two matrices");
    TORCH_CHECK(x.size(1) == weight.size(1), "K dimensions must agree");
    TORCH_CHECK(x.scalar_type() == weight.scalar_type(), "Dtypes must agree");
    TORCH_CHECK(
        x.scalar_type() == at::kFloat ||
        x.scalar_type() == at::kHalf ||
        x.scalar_type() == at::kBFloat16,
        "Supported dtypes are float32, float16, and bfloat16");

    c10::cuda::CUDAGuard guard(x.device());
    auto out = torch::empty({x.size(0), weight.size(0)}, x.options());
    if (out.numel() == 0) return out;

    hipStream_t stream = at::cuda::getCurrentCUDAStream(x.get_device());
    switch (x.scalar_type()) {
        case at::kFloat:
            launch_linear<float>(x, weight, out, stream);
            break;
        case at::kHalf:
            launch_linear<at::Half>(x, weight, out, stream);
            break;
        case at::kBFloat16:
            launch_linear<at::BFloat16>(x, weight, out, stream);
            break;
        default:
            TORCH_CHECK(false, "Unsupported dtype");
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha256((_CPP_SRC + _HIP_SRC).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"pyramid_linear_hip_{digest}",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

    def forward(self, x, weight):
        return _get_extension().linear(x, weight)
```