```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>

void rearrange_hip(torch::Tensor x, torch::Tensor out, int64_t bs, bool dcr);
void fused_hip(torch::Tensor x, torch::Tensor weight, torch::Tensor bias,
               torch::Tensor out, int64_t bs, bool dcr);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("rearrange", &rearrange_hip);
    m.def("fused", &fused_hip);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>

__global__ void rearrange_kernel(
    const float* __restrict__ x, float* __restrict__ out,
    int64_t total, int C, int H, int W, int bs, bool dcr)
{
    const int OW = W * bs;
    const int OH = H * bs;
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         i < total; i += int64_t(blockDim.x) * gridDim.x) {
        int64_t t = i;
        int ow = t % OW; t /= OW;
        int oh = t % OH; t /= OH;
        int c = t % C;
        int64_t n = t / C;
        int sub = (oh % bs) * bs + ow % bs;
        int k = dcr ? sub * C + c : c * bs * bs + sub;
        out[i] = x[((n * (C * bs * bs) + k) * H + oh / bs) * W + ow / bs];
    }
}

// A block computes sixteen output channels at sixty-four spatial positions.
// The shared input tile is constructed directly from the unpadded input.
__global__ __launch_bounds__(256) void fused_kernel(
    const float* __restrict__ x,
    const float* __restrict__ weight,
    const float* __restrict__ bias,
    float* __restrict__ out,
    int CI, int K, int H, int W, int bs, bool dcr)
{
    __shared__ float a[16][17];
    __shared__ float v[16][64];

    const int tid = threadIdx.x;
    const int lane = tid & 63;
    const int group = tid >> 6;
    const int p0 = blockIdx.x * 64;
    const int k0 = blockIdx.y * 16;
    const int n = blockIdx.z;
    const int S = H * W;
    const int R = CI * 9;

    float sum0 = 0.0f;
    float sum1 = 0.0f;
    float sum2 = 0.0f;
    float sum3 = 0.0f;

    for (int r0 = 0; r0 < R; r0 += 16) {
        const int ak = tid >> 4;
        const int ar = tid & 15;
        const int r = r0 + ar;
        a[ak][ar] = (k0 + ak < K && r < R)
            ? weight[int64_t(k0 + ak) * R + r] : 0.0f;

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int vr = group + j * 4;
            const int rr = r0 + vr;
            const int p = p0 + lane;
            const int ci = rr / 9;
            const int rem = rr - ci * 9;
            const int ih = p / W + rem / 3 - 1;
            const int iw = p % W + rem % 3 - 1;
            float value = 0.0f;
            if (rr < R && p < S &&
                static_cast<unsigned>(ih) < static_cast<unsigned>(H) &&
                static_cast<unsigned>(iw) < static_cast<unsigned>(W)) {
                value = x[((int64_t(n) * CI + ci) * H + ih) * W + iw];
            }
            v[vr][lane] = value;
        }
        __syncthreads();

        #pragma unroll
        for (int rj = 0; rj < 16; ++rj) {
            const float xv = v[rj][lane];
            sum0 = fmaf(a[group     ][rj], xv, sum0);
            sum1 = fmaf(a[group +  4][rj], xv, sum1);
            sum2 = fmaf(a[group +  8][rj], xv, sum2);
            sum3 = fmaf(a[group + 12][rj], xv, sum3);
        }
        __syncthreads();
    }

    const int p = p0 + lane;
    if (p < S) {
        const int C = K / (bs * bs);
        const int h = p / W;
        const int w = p % W;
        const int OH = H * bs;
        const int OW = W * bs;
        float sums[4] = {sum0, sum1, sum2, sum3};

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int k = k0 + group + j * 4;
            if (k < K) {
                const int c = dcr ? k % C : k / (bs * bs);
                const int sub = dcr ? k / C : k % (bs * bs);
                const int oh = h * bs + sub / bs;
                const int ow = w * bs + sub % bs;
                out[((int64_t(n) * C + c) * OH + oh) * OW + ow]
                    = sums[j] + bias[k];
            }
        }
    }
}

static void check_tensor(const torch::Tensor& t) {
    TORCH_CHECK(t.is_cuda(), "Expected an accelerator tensor");
    TORCH_CHECK(t.scalar_type() == at::kFloat, "Expected float32");
    TORCH_CHECK(t.is_contiguous(), "Expected contiguous storage");
}

void rearrange_hip(torch::Tensor x, torch::Tensor out, int64_t bs, bool dcr) {
    check_tensor(x);
    check_tensor(out);
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
    int64_t count = out.numel();
    if (!count) return;
    int blocks = int(std::min<int64_t>((count + 255) / 256, 65535));
    hipLaunchKernelGGL(rearrange_kernel, dim3(blocks), dim3(256), 0,
                      stream.stream(), x.data_ptr<float>(), out.data_ptr<float>(),
                      count, int(out.size(1)), int(x.size(2)), int(x.size(3)),
                      int(bs), dcr);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

void fused_hip(torch::Tensor x, torch::Tensor weight, torch::Tensor bias,
               torch::Tensor out, int64_t bs, bool dcr) {
    check_tensor(x);
    check_tensor(weight);
    check_tensor(bias);
    check_tensor(out);
    TORCH_CHECK(weight.device() == x.device() && bias.device() == x.device(),
                "All tensors must be on the same device");
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
    const int N = x.size(0);
    const int CI = x.size(1);
    const int H = x.size(2);
    const int W = x.size(3);
    const int K = weight.size(0);
    if (!out.numel()) return;
    dim3 grid((H * W + 63) / 64, (K + 15) / 16, N);
    hipLaunchKernelGGL(fused_kernel, grid, dim3(256), 0, stream.stream(),
                      x.data_ptr<float>(), weight.data_ptr<float>(),
                      bias.data_ptr<float>(), out.data_ptr<float>(),
                      CI, K, H, W, int(bs), dcr);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode("utf-8")
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="fused_dts_hip_" + digest,
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)

    def __init__(self, variant: str = "conv_bias_dts", mode: str = "CRD", block_size: int = 2):
        super().__init__()
        assert variant in ("conv_bias_dts", "dts")
        assert mode in ("CRD", "DCR")
        assert block_size in (2, 3, 4)
        self.variant = variant
        self.mode = mode
        self.block_size = block_size

    def forward(self, x, weight=None, bias=None):
        n, ci, h, w = x.shape
        bs = self.block_size
        if self.variant == "conv_bias_dts":
            assert weight is not None and bias is not None
            assert weight.ndim == 4
            assert tuple(weight.shape[1:]) == (ci, 3, 3)
            k = weight.shape[0]
            assert bias.numel() == k
        else:
            k = ci
        assert k % (bs * bs) == 0
        out = torch.empty(
            (n, k // (bs * bs), h * bs, w * bs),
            device=x.device,
            dtype=x.dtype,
        )
        ext = _get_extension()
        if self.variant == "conv_bias_dts":
            ext.fused(x, weight, bias, out, bs, self.mode == "DCR")
        else:
            ext.rearrange(x, out, bs, self.mode == "DCR")
        return out
```