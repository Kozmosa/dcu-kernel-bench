import hashlib
import threading

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor routed_gemm(
    torch::Tensor A,
    torch::Tensor B,
    torch::Tensor weights,
    torch::Tensor sorted_ids,
    torch::Tensor expert_ids,
    torch::Tensor padded_count,
    int64_t top_k);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("routed_gemm", &routed_gemm);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <stdint.h>

template <typename scalar_t>
__global__ __launch_bounds__(256)
void routed_gemm_kernel(
    const scalar_t* __restrict__ A,
    const scalar_t* __restrict__ B,
    const float* __restrict__ W,
    const int32_t* __restrict__ sorted_ids,
    const int32_t* __restrict__ expert_ids,
    const int32_t* __restrict__ padded_count,
    scalar_t* __restrict__ C,
    int64_t slots,
    int64_t N,
    int64_t K,
    int64_t top_k,
    int64_t as0,
    int64_t as1,
    int64_t bs0,
    int64_t bs1,
    int64_t bs2,
    int64_t ws0,
    int64_t ws1,
    int64_t ss0,
    int64_t es0)
{
    constexpr int BM = 64;
    constexpr int BN = 64;
    constexpr int BK = 16;

    const int64_t first = int64_t(blockIdx.y) * BM;
    if (first >= int64_t(padded_count[0])) return;

    const int tid = threadIdx.x;
    const int tx = tid & 15;
    const int ty = tid >> 4;
    const int64_t nbase = int64_t(blockIdx.x) * BN;
    const int64_t expert = expert_ids[int64_t(blockIdx.y) * es0];

    __shared__ int32_t routing[BM];
    __shared__ float tile_a[BM][BK + 1];
    __shared__ float tile_b[BK][BN + 1];

    if (tid < BM)
        routing[tid] = sorted_ids[(first + tid) * ss0];
    __syncthreads();

    float acc[4][4];
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        #pragma unroll
        for (int j = 0; j < 4; ++j)
            acc[i][j] = 0.0f;
    }

    for (int64_t kb = 0; kb < K; kb += BK) {
        #pragma unroll
        for (int q = 0; q < 4; ++q) {
            const int idx = tid + q * 256;
            const int row = idx / BK;
            const int kk = idx % BK;
            const int64_t p = routing[row];
            float av = 0.0f;
            if (p >= 0 && p < slots && kb + kk < K)
                av = static_cast<float>(
                    A[(p / top_k) * as0 + (kb + kk) * as1]);
            tile_a[row][kk] = av;

            const int col = idx / BK;
            float bv = 0.0f;
            if (nbase + col < N && kb + kk < K)
                bv = static_cast<float>(
                    B[expert * bs0 + (nbase + col) * bs1
                      + (kb + kk) * bs2]);
            tile_b[kk][col] = bv;
        }
        __syncthreads();

        #pragma unroll
        for (int kk = 0; kk < BK; ++kk) {
            float av[4];
            float bv[4];
            #pragma unroll
            for (int i = 0; i < 4; ++i)
                av[i] = tile_a[ty + i * 16][kk];
            #pragma unroll
            for (int j = 0; j < 4; ++j)
                bv[j] = tile_b[kk][tx + j * 16];

            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                #pragma unroll
                for (int j = 0; j < 4; ++j)
                    acc[i][j] = fmaf(av[i], bv[j], acc[i][j]);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const int64_t p = routing[ty + i * 16];
        if (p >= 0 && p < slots) {
            const float weight = W[(p / top_k) * ws0 + (p % top_k) * ws1];
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                const int64_t n = nbase + tx + j * 16;
                if (n < N)
                    C[p * N + n] = static_cast<scalar_t>(acc[i][j] * weight);
            }
        }
    }
}

torch::Tensor routed_gemm(
    torch::Tensor A,
    torch::Tensor B,
    torch::Tensor weights,
    torch::Tensor sorted_ids,
    torch::Tensor expert_ids,
    torch::Tensor padded_count,
    int64_t top_k)
{
    TORCH_CHECK(A.is_cuda() && B.is_cuda() && weights.is_cuda()
                && sorted_ids.is_cuda() && expert_ids.is_cuda()
                && padded_count.is_cuda(), "All inputs must be on the GPU");
    TORCH_CHECK(A.dim() == 2 && B.dim() == 3, "Invalid input dimensions");
    TORCH_CHECK(top_k > 0 && B.size(2) == A.size(1), "Invalid GEMM shape");
    TORCH_CHECK(A.scalar_type() == B.scalar_type(), "A/B dtype mismatch");
    TORCH_CHECK(weights.scalar_type() == at::kFloat, "Weights must be float32");
    TORCH_CHECK(sorted_ids.scalar_type() == at::kInt
                && expert_ids.scalar_type() == at::kInt
                && padded_count.scalar_type() == at::kInt,
                "Routing layout must use int32");
    TORCH_CHECK(weights.dim() == 2 && weights.size(0) == A.size(0)
                && weights.size(1) == top_k, "Invalid weights shape");
    TORCH_CHECK(padded_count.numel() == 1, "Invalid padded count");
    TORCH_CHECK(B.device() == A.device() && weights.device() == A.device()
                && sorted_ids.device() == A.device()
                && expert_ids.device() == A.device()
                && padded_count.device() == A.device(), "Device mismatch");

    const c10::cuda::CUDAGuard guard(A.device());
    const int64_t M = A.size(0);
    const int64_t N = B.size(1);
    const int64_t K = A.size(1);
    auto output = torch::empty({M, top_k, N}, A.options());
    if (M == 0 || N == 0) return output;

    const int64_t blocks = (sorted_ids.numel() + 63) / 64;
    TORCH_CHECK(blocks <= 65535, "Routing layout exceeds grid limit");
    const dim3 grid(static_cast<unsigned>((N + 63) / 64),
                    static_cast<unsigned>(blocks));
    const auto stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        A.scalar_type(), "routed_gemm", [&] {
            routed_gemm_kernel<scalar_t><<<grid, 256, 0, stream>>>(
                A.data_ptr<scalar_t>(),
                B.data_ptr<scalar_t>(),
                weights.data_ptr<float>(),
                sorted_ids.data_ptr<int32_t>(),
                expert_ids.data_ptr<int32_t>(),
                padded_count.data_ptr<int32_t>(),
                output.data_ptr<scalar_t>(),
                M * top_k, N, K, top_k,
                A.stride(0), A.stride(1),
                B.stride(0), B.stride(1), B.stride(2),
                weights.stride(0), weights.stride(1),
                sorted_ids.stride(0), expert_ids.stride(0));
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_extension = None
_extension_lock = threading.Lock()


def _get_extension():
    global _extension
    if _extension is None:
        with _extension_lock:
            if _extension is None:
                digest = hashlib.sha256(
                    (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
                ).hexdigest()[:16]
                _extension = load_inline(
                    name=f"routed_gemm_hip_{digest}",
                    cpp_sources=CUDA_CPP_SRC,
                    cuda_sources=CUDA_CU_SRC,
                    functions=None,
                    extra_cflags=["-O3"],
                    extra_cuda_cflags=["-O3"],
                    with_cuda=True,
                    verbose=False,
                )
    return _extension


class ModelNew(nn.Module):
    def __init__(self, num_experts: int, top_k: int):
        super().__init__()
        self.num_experts = num_experts
        self.top_k = top_k

    def forward(
        self,
        A,
        B,
        topk_weights,
        topk_ids,
        sorted_token_ids,
        expert_ids,
        num_tokens_post_padded,
    ):
        return _get_extension().routed_gemm(
            A,
            B,
            topk_weights,
            sorted_token_ids,
            expert_ids,
            num_tokens_post_padded,
            topk_ids.shape[1],
        )
