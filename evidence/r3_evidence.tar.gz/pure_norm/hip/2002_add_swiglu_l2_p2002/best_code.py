import hashlib
import threading

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_CPP = r"""
#include <torch/extension.h>

torch::Tensor fused_swiglu(
    torch::Tensor base,
    torch::Tensor delta,
    torch::Tensor grad_out);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_swiglu", &fused_swiglu);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cstdint>

template <typename scalar_t>
__global__ void fused_swiglu_kernel(
    const scalar_t* __restrict__ base,
    const scalar_t* __restrict__ delta,
    const scalar_t* __restrict__ grad,
    scalar_t* __restrict__ output,
    int64_t count,
    int64_t d)
{
    const int64_t stride = int64_t(blockDim.x) * gridDim.x;
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         i < count; i += stride) {
        const int64_t row = i / d;
        const int64_t input_index = i + row * d;
        const int64_t output_index = i + row * (2 * d);

        const float gate =
            float(base[input_index]) + float(delta[input_index]);
        const float up =
            float(base[input_index + d]) + float(delta[input_index + d]);
        const float upstream = float(grad[i]);
        const float sig = 1.0f / (1.0f + expf(-gate));
        const float silu = gate * sig;
        const float derivative = sig + silu * (1.0f - sig);

        output[output_index] = scalar_t(silu * up);
        output[output_index + d] = scalar_t((upstream * up) * derivative);
        output[output_index + 2 * d] = scalar_t(upstream * silu);
    }
}

torch::Tensor fused_swiglu(
    torch::Tensor base,
    torch::Tensor delta,
    torch::Tensor grad_out)
{
    TORCH_CHECK(base.is_cuda() && delta.is_cuda() && grad_out.is_cuda(),
                "Inputs must be accelerator tensors");
    TORCH_CHECK(base.dim() == 2 && delta.dim() == 2 && grad_out.dim() == 2,
                "Inputs must be two-dimensional");
    TORCH_CHECK(base.device() == delta.device() &&
                base.device() == grad_out.device(),
                "Inputs must be on the same device");
    TORCH_CHECK(base.scalar_type() == delta.scalar_type() &&
                base.scalar_type() == grad_out.scalar_type(),
                "Inputs must have the same dtype");
    TORCH_CHECK(base.scalar_type() == at::kFloat ||
                base.scalar_type() == at::kHalf ||
                base.scalar_type() == at::kBFloat16,
                "Supported dtypes are float32, float16, and bfloat16");

    const int64_t rows = base.size(0);
    const int64_t width = base.size(1);
    TORCH_CHECK(width > 0 && width % 2 == 0,
                "Width must be positive and even");
    const int64_t d = width / 2;
    TORCH_CHECK(delta.sizes() == base.sizes(), "delta shape mismatch");
    TORCH_CHECK(grad_out.size(0) == rows && grad_out.size(1) == d,
                "grad_out shape mismatch");

    const c10::cuda::CUDAGuard guard(base.device());
    auto output = torch::empty({rows, 3 * d}, base.options());
    if (rows == 0)
        return output;

    base = base.contiguous();
    delta = delta.contiguous();
    grad_out = grad_out.contiguous();

    const int64_t count = rows * d;
    constexpr int threads = 256;
    const int blocks = static_cast<int>(
        std::min<int64_t>((count + threads - 1) / threads, 65535));
    const auto stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        base.scalar_type(), "fused_swiglu", [&] {
            hipLaunchKernelGGL(
                (fused_swiglu_kernel<scalar_t>),
                dim3(blocks), dim3(threads), 0, stream.stream(),
                base.data_ptr<scalar_t>(),
                delta.data_ptr<scalar_t>(),
                grad_out.data_ptr<scalar_t>(),
                output.data_ptr<scalar_t>(),
                count, d);
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_EXTENSION = None
_EXTENSION_LOCK = threading.Lock()


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        with _EXTENSION_LOCK:
            if _EXTENSION is None:
                digest = hashlib.sha256((_CPP + _HIP).encode()).hexdigest()[:16]
                _EXTENSION = load_inline(
                    name=f"fused_add_swiglu_hip_{digest}",
                    cpp_sources=_CPP,
                    cuda_sources=_HIP,
                    functions=None,
                    extra_cflags=["-O3"],
                    extra_cuda_cflags=["-O3", "-ffp-contract=off"],
                    with_cuda=True,
                    verbose=False,
                )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, base, delta, grad_out):
        return _get_extension().fused_swiglu(base, delta, grad_out)
