import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>

torch::Tensor pyramid_forward(
    torch::Tensor x, torch::Tensor w,
    torch::Tensor xs, torch::Tensor ws,
    int64_t gk, int64_t gn, int64_t dtype);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &pyramid_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/util/Half.h>
#include <c10/util/BFloat16.h>
#include <c10/util/Float8_e4m3fn.h>

template<typename Out>
__global__ __launch_bounds__(256)
void pyramid_gemm(
    const float* __restrict__ x,
    const float* __restrict__ w,
    const float* __restrict__ xs,
    const float* __restrict__ ws,
    Out* __restrict__ out,
    int M, int N, int K, int gk, int gn,
    int64_t x0, int64_t x1, int64_t w0, int64_t w1,
    int64_t s0, int64_t s1, int64_t t0, int64_t t1)
{
    __shared__ float A[32][33];
    __shared__ float B[32][64];

    const int tid = threadIdx.x;
    const int mr = tid / 16;
    const int nr = tid % 16;
    const int mb = blockIdx.y * 32;
    const int nb = blockIdx.x * 64;

    float acc[2][4] = {};

    for (int kb = 0; kb < K; kb += 32) {
        #pragma unroll
        for (int i = 0; i < 4; ++i) {
            const int p = tid + i * 256;
            const int r = p / 32;
            const int k = kb + p % 32;
            float v = 0.0f;
            if (mb + r < M && k < K) {
                float q = static_cast<float>(
                    c10::Float8_e4m3fn(x[(int64_t)(mb + r) * x0 + (int64_t)k * x1]));
                v = q * xs[(int64_t)(mb + r) * s0 + (int64_t)(k / gk) * s1];
            }
            A[r][p % 32] = v;
        }
        #pragma unroll
        for (int i = 0; i < 8; ++i) {
            const int p = tid + i * 256;
            const int r = p / 32;
            const int k = kb + p % 32;
            float v = 0.0f;
            if (nb + r < N && k < K) {
                float q = static_cast<float>(
                    c10::Float8_e4m3fn(w[(int64_t)(nb + r) * w0 + (int64_t)k * w1]));
                v = q * ws[(int64_t)((nb + r) / gn) * t0 + (int64_t)(k / gk) * t1];
            }
            B[p % 32][r] = v;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < 32; ++k) {
            float a0 = A[mr][k];
            float a1 = A[mr + 16][k];
            #pragma unroll
            for (int j = 0; j < 4; ++j) {
                float b = B[k][nr + j * 16];
                acc[0][j] = fmaf(a0, b, acc[0][j]);
                acc[1][j] = fmaf(a1, b, acc[1][j]);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 2; ++i) {
        const int m = mb + mr + i * 16;
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int n = nb + nr + j * 16;
            if (m < M && n < N)
                out[(int64_t)m * N + n] = static_cast<Out>(acc[i][j]);
        }
    }
}

torch::Tensor pyramid_forward(
    torch::Tensor x, torch::Tensor w,
    torch::Tensor xs, torch::Tensor ws,
    int64_t gk, int64_t gn, int64_t dtype)
{
    TORCH_CHECK(x.is_cuda() && w.is_cuda() && xs.is_cuda() && ws.is_cuda(),
                "All inputs must be on the accelerator");
    TORCH_CHECK(x.device() == w.device() && x.device() == xs.device() &&
                x.device() == ws.device(), "Inputs must share a device");
    TORCH_CHECK(x.scalar_type() == at::kFloat && w.scalar_type() == at::kFloat &&
                xs.scalar_type() == at::kFloat && ws.scalar_type() == at::kFloat,
                "Inputs must be float32");
    TORCH_CHECK(x.dim() == 2 && w.dim() == 2 && xs.dim() == 2 && ws.dim() == 2,
                "Inputs must have two dimensions");
    TORCH_CHECK(gk > 0 && gn > 0, "Group sizes must be positive");

    int64_t M = x.size(0), K = x.size(1), N = w.size(0);
    TORCH_CHECK(M > 0 && N > 0 && K > 0 && w.size(1) == K,
                "Invalid matrix dimensions");
    TORCH_CHECK(xs.size(0) == M && xs.size(1) == (K + gk - 1) / gk,
                "Invalid activation scale shape");
    TORCH_CHECK(ws.size(0) == (N + gn - 1) / gn &&
                ws.size(1) == (K + gk - 1) / gk,
                "Invalid weight scale shape");

    c10::cuda::CUDAGuard guard(x.device());
    auto type = dtype == 0 ? at::kBFloat16 : (dtype == 1 ? at::kHalf : at::kFloat);
    auto out = torch::empty({M, N}, x.options().dtype(type));
    auto stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    dim3 grid((N + 63) / 64, (M + 31) / 32);

    #define LAUNCH(T) \
        hipLaunchKernelGGL((pyramid_gemm<T>), grid, dim3(256), 0, stream, \
            x.data_ptr<float>(), w.data_ptr<float>(), \
            xs.data_ptr<float>(), ws.data_ptr<float>(), out.data_ptr<T>(), \
            (int)M, (int)N, (int)K, (int)gk, (int)gn, \
            x.stride(0), x.stride(1), w.stride(0), w.stride(1), \
            xs.stride(0), xs.stride(1), ws.stride(0), ws.stride(1))

    if (dtype == 0) {
        LAUNCH(c10::BFloat16);
    } else if (dtype == 1) {
        LAUNCH(c10::Half);
    } else {
        LAUNCH(float);
    }
    #undef LAUNCH

    hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess, hipGetErrorString(error));
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "pyramid_hip_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, group_k=128, group_n=128, out_dtype="bfloat16"):
        super().__init__()
        if isinstance(group_k, (list, tuple)):
            group_k, group_n, out_dtype = group_k
        self.group_k = int(group_k)
        self.group_n = int(group_n)
        self.out_dtype = getattr(torch, out_dtype)
        self._dtype_code = {
            torch.bfloat16: 0,
            torch.float16: 1,
            torch.float32: 2,
        }[self.out_dtype]

    def forward(self, x, w, x_scale, w_scale):
        return _get_extension().forward(
            x, w, x_scale, w_scale,
            self.group_k, self.group_n, self._dtype_code,
        )
