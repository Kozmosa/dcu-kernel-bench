import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor moe_forward(
    torch::Tensor A, torch::Tensor B,
    torch::Tensor AS, torch::Tensor BS,
    torch::Tensor W, torch::Tensor IDs,
    bool weighted, bool quantized, int64_t bn, int64_t bk);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &moe_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

struct Layout {
    int64_t a0, a1, b0, b1, b2;
    int64_t as0, as1, bs0, bs1, bs2;
    int64_t w0, w1, i0, i1;
};

__device__ __forceinline__ int read_id(
    const void* ids, int type, int64_t offset) {
    if (type == 0)
        return static_cast<int>(static_cast<const int64_t*>(ids)[offset]);
    if (type == 1)
        return static_cast<const int32_t*>(ids)[offset];
    return static_cast<int>(static_cast<const float*>(ids)[offset]);
}

template<bool QUANT, bool WEIGHTED>
__global__ __launch_bounds__(256)
void moe_kernel(
    const float* __restrict__ a,
    const float* __restrict__ b,
    const float* __restrict__ as,
    const float* __restrict__ bs,
    const float* __restrict__ weights,
    const void* __restrict__ ids,
    float* __restrict__ out,
    int id_type, int K, int N, int topk, int bn, int bk,
    Layout s)
{
    const int lane = threadIdx.x & 63;
    const int wave = threadIdx.x >> 6;
    const int64_t row = blockIdx.y;
    const int64_t token = row / topk;
    const int slot = row % topk;
    const int expert = read_id(ids, id_type, token * s.i0 + slot * s.i1);
    const int first = blockIdx.x * 16 + wave * 4;

    float gate[4] = {0.f, 0.f, 0.f, 0.f};
    float up[4] = {0.f, 0.f, 0.f, 0.f};

    for (int k = lane; k < K; k += 64) {
        float av = a[token * s.a0 + int64_t(k) * s.a1];
        if (QUANT)
            av *= as[token * s.as0 + int64_t(k / bk) * s.as1];

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int n = first + j;
            if (n < N) {
                const int64_t base = int64_t(expert) * s.b0 + int64_t(k) * s.b2;
                float gv = b[base + int64_t(n) * s.b1];
                float uv = b[base + int64_t(N + n) * s.b1];
                if (QUANT) {
                    const int64_t scale_base =
                        int64_t(expert) * s.bs0 + int64_t(k / bk) * s.bs2;
                    gv *= bs[scale_base + int64_t(n / bn) * s.bs1];
                    uv *= bs[scale_base + int64_t((N + n) / bn) * s.bs1];
                }
                gate[j] = fmaf(av, gv, gate[j]);
                up[j] = fmaf(av, uv, up[j]);
            }
        }
    }

    #pragma unroll
    for (int delta = 32; delta > 0; delta >>= 1) {
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            gate[j] += __shfl_down(gate[j], delta, 64);
            up[j] += __shfl_down(up[j], delta, 64);
        }
    }

    if (lane == 0) {
        float weight = 1.f;
        if (WEIGHTED)
            weight = weights[token * s.w0 + int64_t(slot) * s.w1];

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int n = first + j;
            if (n < N) {
                float g = gate[j] * weight;
                float u = up[j] * weight;
                out[row * N + n] = (g / (1.f + expf(-g))) * u;
            }
        }
    }
}

torch::Tensor moe_forward(
    torch::Tensor A, torch::Tensor B,
    torch::Tensor AS, torch::Tensor BS,
    torch::Tensor W, torch::Tensor IDs,
    bool weighted, bool quantized, int64_t bn, int64_t bk)
{
    TORCH_CHECK(A.is_cuda() && B.is_cuda() && W.is_cuda() && IDs.is_cuda(),
                "Inputs must reside on the accelerator");
    TORCH_CHECK(A.scalar_type() == at::kFloat &&
                B.scalar_type() == at::kFloat &&
                W.scalar_type() == at::kFloat, "Expected fp32 inputs");
    TORCH_CHECK(A.dim() == 2 && B.dim() == 3 &&
                W.dim() == 2 && IDs.dim() == 2, "Invalid input ranks");
    TORCH_CHECK(B.size(2) == A.size(1) && B.size(1) % 2 == 0 &&
                IDs.size(0) == A.size(0) && W.sizes() == IDs.sizes(),
                "Invalid input shapes");

    c10::cuda::CUDAGuard guard(A.device());
    const int64_t M = A.size(0), K = A.size(1);
    const int64_t N = B.size(1) / 2, topk = IDs.size(1);
    auto out = torch::empty({M * topk, N}, W.options());

    int id_type;
    if (IDs.scalar_type() == at::kLong) id_type = 0;
    else if (IDs.scalar_type() == at::kInt) id_type = 1;
    else {
        TORCH_CHECK(IDs.scalar_type() == at::kFloat,
                    "Routing IDs must be int64, int32, or float32");
        id_type = 2;
    }

    Layout s{};
    s.a0 = A.stride(0); s.a1 = A.stride(1);
    s.b0 = B.stride(0); s.b1 = B.stride(1); s.b2 = B.stride(2);
    s.w0 = W.stride(0); s.w1 = W.stride(1);
    s.i0 = IDs.stride(0); s.i1 = IDs.stride(1);

    const float* asp = nullptr;
    const float* bsp = nullptr;
    if (quantized) {
        TORCH_CHECK(K % bk == 0 && (2 * N) % bn == 0,
                    "Quantization blocks must divide the dimensions");
        TORCH_CHECK(AS.is_cuda() && BS.is_cuda() &&
                    AS.scalar_type() == at::kFloat &&
                    BS.scalar_type() == at::kFloat, "Expected fp32 device scales");
        TORCH_CHECK(AS.dim() == 2 && AS.size(0) == M && AS.size(1) == K / bk &&
                    BS.dim() == 3 && BS.size(0) == B.size(0) &&
                    BS.size(1) == 2 * N / bn && BS.size(2) == K / bk,
                    "Invalid scale shapes");
        s.as0 = AS.stride(0); s.as1 = AS.stride(1);
        s.bs0 = BS.stride(0); s.bs1 = BS.stride(1); s.bs2 = BS.stride(2);
        asp = AS.data_ptr<float>();
        bsp = BS.data_ptr<float>();
    }
    if (M * topk == 0 || N == 0) return out;

    auto stream = at::cuda::getCurrentCUDAStream();
    // Chunk the routing dimension to respect the grid.y limit.
    for (int64_t start = 0; start < M; ) {
        int64_t count = std::min<int64_t>(M - start, 65535 / topk);
        TORCH_CHECK(count > 0, "top_k exceeds the supported grid dimension");
        dim3 grid((N + 15) / 16, count * topk);
        const float* ap = A.data_ptr<float>() + start * s.a0;
        const float* wp = W.data_ptr<float>() + start * s.w0;
        const char* ip = static_cast<const char*>(IDs.data_ptr()) +
                        start * s.i0 * IDs.element_size();
        const float* local_as = quantized ? asp + start * s.as0 : nullptr;
        float* op = out.data_ptr<float>() + start * topk * N;
        #define LAUNCH(Q, WGT) \
            hipLaunchKernelGGL((moe_kernel<Q, WGT>), grid, dim3(256), 0, stream, \
                ap, B.data_ptr<float>(), local_as, bsp, wp, ip, op, \
                id_type, int(K), int(N), int(topk), int(bn), int(bk), s)
        if (quantized) {
            if (weighted) { LAUNCH(true, true); }
            else { LAUNCH(true, false); }
        } else {
            if (weighted) { LAUNCH(false, true); }
            else { LAUNCH(false, false); }
        }
        #undef LAUNCH
        start += count;
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "fused_moe_swiglu_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, mul_routed_weight=True, quant="dense", block_n=128, block_k=128):
        super().__init__()
        assert quant in ("dense", "fp8_block"), "quant must be one of dense / fp8_block"
        assert block_n >= 1 and block_k >= 1, "block_n / block_k must be >= 1"
        self.mul_routed_weight = bool(mul_routed_weight)
        self.quant = quant
        self.block_n = int(block_n)
        self.block_k = int(block_k)

    def forward(self, A, B, A_scale, B_scale, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        return _get_extension().forward(
            A, B, A_scale, B_scale, topk_weights, topk_ids,
            self.mul_routed_weight, self.quant == "fp8_block",
            self.block_n, self.block_k,
        )
