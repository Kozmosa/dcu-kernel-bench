import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor kb, torch::Tensor vb, torch::Tensor qi,
    torch::Tensor ki, torch::Tensor ids, bool causal, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &attention_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>

constexpr int THREADS = 256;
constexpr int TILE = 32;

template <typename scalar_t>
__global__ void partial_attention(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k,
    const scalar_t* __restrict__ v,
    const scalar_t* __restrict__ kb,
    const scalar_t* __restrict__ vb,
    const int* __restrict__ qi,
    const int* __restrict__ ki,
    const int* __restrict__ ids,
    float* __restrict__ partial,
    int B, int H, int HK, int D, int V, int splits,
    bool causal, float scale)
{
    int row = blockIdx.x;
    int head = blockIdx.y;
    int split = blockIdx.z;
    int tid = threadIdx.x;
    int lane = tid & 31;
    int warp = tid >> 5;
    int lo = 0, hi = B;
    while (lo + 1 < hi) {
        int mid = (lo + hi) >> 1;
        if (qi[mid] <= row) lo = mid;
        else hi = mid;
    }
    int start = qi[lo], end = qi[lo + 1];
    int ps = ki[lo], plen = ki[lo + 1] - ps;
    int length = plen + (causal ? row - start + 1 : end - start);
    int chunk = (length + splits - 1) / splits;
    int first = split * chunk;
    int last = min(length, first + chunk);
    int kh = head / (H / HK);

    extern __shared__ float shared[];
    float* sq = shared;
    float* weights = sq + D;
    float* accum = weights + TILE;
    float* stats = accum + V;

    for (int d = tid; d < D; d += THREADS)
        sq[d] = float(q[((int64_t)row * H + head) * D + d]);
    for (int d = tid; d < V; d += THREADS) accum[d] = 0.f;
    if (tid == 0) {
        stats[0] = -INFINITY;
        stats[1] = 0.f;
    }
    __syncthreads();

    for (int base = first; base < last; base += TILE) {
        for (int j = warp; j < TILE; j += THREADS / 32) {
            int pos = base + j;
            float dot = 0.f;
            if (pos < last) {
                int kr = pos < plen ? ids[ps + pos] : start + pos - plen;
                const scalar_t* kp = (pos < plen ? kb : k)
                    + ((int64_t)kr * HK + kh) * D;
                for (int d = lane; d < D; d += 32)
                    dot = fmaf(sq[d], float(kp[d]), dot);
            }
            for (int offset = 16; offset; offset >>= 1)
                dot += __shfl_down(dot, offset, 32);
            if (lane == 0)
                weights[j] = pos < last ? dot * scale : -INFINITY;
        }
        __syncthreads();
        if (tid == 0) {
            float m = stats[0];
            int count = min(TILE, last - base);
            for (int j = 0; j < count; ++j) m = fmaxf(m, weights[j]);
            float rescale = expf(stats[0] - m);
            float sum = 0.f;
            for (int j = 0; j < count; ++j) {
                float p = expf(weights[j] - m);
                weights[j] = p;
                sum += p;
            }
            stats[0] = m;
            stats[1] = stats[1] * rescale + sum;
            stats[2] = rescale;
        }
        __syncthreads();
        int count = min(TILE, last - base);
        for (int d = tid; d < V; d += THREADS) {
            float a = accum[d] * stats[2];
            for (int j = 0; j < count; ++j) {
                int pos = base + j;
                int vr = pos < plen ? ids[ps + pos] : start + pos - plen;
                const scalar_t* vp = pos < plen ? vb : v;
                a = fmaf(weights[j],
                         float(vp[((int64_t)vr * HK + kh) * V + d]), a);
            }
            accum[d] = a;
        }
        __syncthreads();
    }

    float* dst = partial
        + (((int64_t)row * H + head) * splits + split) * (V + 2);
    for (int d = tid; d < V; d += THREADS) dst[d] = accum[d];
    if (tid == 0) {
        dst[V] = stats[0];
        dst[V + 1] = stats[1];
    }
}

template <typename scalar_t>
__global__ void merge_attention(
    const float* __restrict__ partial,
    scalar_t* __restrict__ out, int H, int V, int splits)
{
    int row = blockIdx.x, head = blockIdx.y;
    const float* src = partial + ((int64_t)row * H + head) * splits * (V + 2);
    __shared__ float factors[32];
    __shared__ float denominator;
    if (threadIdx.x == 0) {
        float m = -INFINITY;
        for (int s = 0; s < splits; ++s)
            m = fmaxf(m, src[s * (V + 2) + V]);
        float den = 0.f;
        for (int s = 0; s < splits; ++s) {
            float f = expf(src[s * (V + 2) + V] - m);
            factors[s] = f;
            den += f * src[s * (V + 2) + V + 1];
        }
        denominator = den;
    }
    __syncthreads();
    for (int d = threadIdx.x; d < V; d += blockDim.x) {
        float value = 0.f;
        for (int s = 0; s < splits; ++s)
            value = fmaf(factors[s], src[s * (V + 2) + d], value);
        out[((int64_t)row * H + head) * V + d] =
            scalar_t(value / denominator);
    }
}

torch::Tensor attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor kb, torch::Tensor vb, torch::Tensor qi,
    torch::Tensor ki, torch::Tensor ids, bool causal, double scale)
{
    c10::cuda::CUDAGuard guard(q.device());
    int N = q.size(0), H = q.size(1), D = q.size(2);
    int HK = k.size(1), V = v.size(2), B = qi.numel() - 1;
    TORCH_CHECK(HK > 0 && H % HK == 0, "Invalid GQA head counts");
    auto out = torch::empty({N, H, V}, q.options());
    if (!N) return out;
    int splits = N * H >= 2048 ? 4 : 8;
    auto partial = torch::empty({N, H, splits, V + 2},
                                q.options().dtype(torch::kFloat32));
    auto stream = at::cuda::getCurrentCUDAStream();
    size_t smem = (D + TILE + V + 3) * sizeof(float);
    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "ragged_attention", [&] {
            partial_attention<scalar_t><<<dim3(N,H,splits), THREADS, smem, stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(),
                v.data_ptr<scalar_t>(), kb.data_ptr<scalar_t>(),
                vb.data_ptr<scalar_t>(), qi.data_ptr<int>(),
                ki.data_ptr<int>(), ids.data_ptr<int>(),
                partial.data_ptr<float>(), B,H,HK,D,V,splits,causal,float(scale));
            merge_attention<scalar_t><<<dim3(N,H), THREADS, 0, stream>>>(
                partial.data_ptr<float>(), out.data_ptr<scalar_t>(), H,V,splits);
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "ragged_mixed_attention_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)

    def forward(self, q_extend, k_extend, v_extend, k_buffer, v_buffer,
                qo_indptr, kv_indptr, kv_indices):
        scale = self.sm_scale
        if scale is None:
            scale = 1.0 / math.sqrt(q_extend.shape[-1])
        return _get_extension().forward(
            q_extend, k_extend, v_extend, k_buffer, v_buffer,
            qo_indptr.to(dtype=torch.int32),
            kv_indptr.to(dtype=torch.int32),
            kv_indices.to(dtype=torch.int32),
            self.causal, scale,
        )
