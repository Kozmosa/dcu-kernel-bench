```python
import hashlib
import math

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


_CPP = r"""
#include <torch/extension.h>

torch::Tensor ragged_attention(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor starts, torch::Tensor lengths,
    bool causal, double scale);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("ragged_attention", &ragged_attention);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

__device__ __forceinline__ int metadata(const void* p, int type, int i) {
    if (type == 0) return static_cast<int>(static_cast<const float*>(p)[i]);
    if (type == 1) return static_cast<const int32_t*>(p)[i];
    return static_cast<int>(static_cast<const int64_t*>(p)[i]);
}

template<class T, int SLOTS, bool CAUSAL>
__global__ __launch_bounds__(256)
void attention_kernel(
    const T* __restrict__ q,
    const T* __restrict__ k,
    const T* __restrict__ v,
    T* __restrict__ out,
    const void* starts, const void* lengths,
    int start_type, int length_type,
    int batch, int hq, int hkv, int dim, float scale)
{
    constexpr int TILE = 64;
    const int row = blockIdx.x;
    const int head = blockIdx.y;
    const int tid = threadIdx.x;
    const int lane = tid & 63;
    const int wave = tid >> 6;

    // Locate the sequence entirely on device; no host synchronization.
    int lo = 0, hi = batch;
    while (lo + 1 < hi) {
        int mid = (lo + hi) >> 1;
        if (metadata(starts, start_type, mid) <= row) lo = mid;
        else hi = mid;
    }
    const int start = metadata(starts, start_type, lo);
    const int length = metadata(lengths, length_type, lo);
    const int count = CAUSAL ? row - start + 1 : length;
    const int kvhead = head / (hq / hkv);
    const int64_t qbase = (int64_t(row) * hq + head) * dim;
    const int64_t kvbase = (int64_t(start) * hkv + kvhead) * dim;
    const int64_t kvstride = int64_t(hkv) * dim;

    extern __shared__ float query[];
    __shared__ float scores[TILE];
    __shared__ float reduction[4];
    __shared__ float correction;
    __shared__ float running_max;
    __shared__ float denominator;

    for (int d = tid; d < dim; d += 256)
        query[d] = static_cast<float>(q[qbase + d]);

    float accum[SLOTS];
    #pragma unroll
    for (int s = 0; s < SLOTS; ++s) accum[s] = 0.0f;

    if (tid == 0) {
        running_max = -INFINITY;
        denominator = 0.0f;
    }
    __syncthreads();

    for (int first = 0; first < count; first += TILE) {
        #pragma unroll
        for (int j = wave; j < TILE; j += 4) {
            float dot = 0.0f;
            if (first + j < count) {
                const int64_t base = kvbase + int64_t(first + j) * kvstride;
                for (int d = lane; d < dim; d += 64)
                    dot = fmaf(query[d], static_cast<float>(k[base + d]), dot);
            }
            #pragma unroll
            for (int delta = 32; delta; delta >>= 1)
                dot += __shfl_down(dot, delta, 64);
            if (lane == 0)
                scores[j] = first + j < count ? dot * scale : -INFINITY;
        }
        __syncthreads();

        float mx = tid < TILE ? scores[tid] : -INFINITY;
        #pragma unroll
        for (int delta = 32; delta; delta >>= 1)
            mx = fmaxf(mx, __shfl_down(mx, delta, 64));
        if (tid == 0) {
            const float new_max = fmaxf(running_max, mx);
            correction = expf(running_max - new_max);
            running_max = new_max;
        }
        __syncthreads();

        float p = tid < TILE ? expf(scores[tid] - running_max) : 0.0f;
        if (tid < TILE) scores[tid] = p;
        #pragma unroll
        for (int delta = 32; delta; delta >>= 1)
            p += __shfl_down(p, delta, 64);
        if (lane == 0) reduction[wave] = p;
        __syncthreads();

        if (tid == 0)
            denominator = denominator * correction + reduction[0];

        const int valid = min(TILE, count - first);
        #pragma unroll
        for (int s = 0; s < SLOTS; ++s) {
            const int d = tid + s * 256;
            if (d < dim) {
                float sum = 0.0f;
                for (int j = 0; j < valid; ++j)
                    sum = fmaf(scores[j],
                               static_cast<float>(
                                   v[kvbase + int64_t(first + j) * kvstride + d]),
                               sum);
                accum[s] = fmaf(accum[s], correction, sum);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int s = 0; s < SLOTS; ++s) {
        const int d = tid + s * 256;
        if (d < dim)
            out[qbase + d] = static_cast<T>(accum[s] / denominator);
    }
}

// Unbounded head-dimension fallback, with constant local storage.
template<class T, bool CAUSAL>
__global__ void large_head_kernel(
    const T* q, const T* k, const T* v, T* out,
    const void* starts, const void* lengths, int st, int lt,
    int batch, int hq, int hkv, int dim, float scale)
{
    const int row = blockIdx.x;
    const int head = blockIdx.y;
    const int d = blockIdx.z * blockDim.x + threadIdx.x;
    if (d >= dim) return;
    int lo = 0, hi = batch;
    while (lo + 1 < hi) {
        int m = (lo + hi) >> 1;
        if (metadata(starts, st, m) <= row) lo = m;
        else hi = m;
    }
    int start = metadata(starts, st, lo);
    int n = CAUSAL ? row - start + 1 : metadata(lengths, lt, lo);
    int g = head / (hq / hkv);
    int64_t qb = (int64_t(row) * hq + head) * dim;
    float maximum = -INFINITY, denominator = 0, numerator = 0;
    for (int j = 0; j < n; ++j) {
        int64_t kb = (int64_t(start + j) * hkv + g) * dim;
        float score = 0;
        for (int c = 0; c < dim; ++c)
            score = fmaf(float(q[qb + c]), float(k[kb + c]), score);
        score *= scale;
        float next = fmaxf(maximum, score);
        float a = expf(maximum - next), b = expf(score - next);
        numerator = fmaf(a, numerator, b * float(v[kb + d]));
        denominator = fmaf(a, denominator, b);
        maximum = next;
    }
    out[qb + d] = T(numerator / denominator);
}

int metadata_type(const torch::Tensor& t) {
    if (t.scalar_type() == at::kFloat) return 0;
    if (t.scalar_type() == at::kInt) return 1;
    TORCH_CHECK(t.scalar_type() == at::kLong,
                "Metadata must be float32, int32, or int64");
    return 2;
}

template<class T, bool CAUSAL>
void launch(
    const torch::Tensor& q, const torch::Tensor& k, const torch::Tensor& v,
    torch::Tensor& out, const torch::Tensor& starts,
    const torch::Tensor& lengths, float scale, hipStream_t stream)
{
    int dim = q.size(2);
    int st = metadata_type(starts), lt = metadata_type(lengths);
    dim3 grid(q.size(0), q.size(1));
    #define LAUNCH(S) \
        hipLaunchKernelGGL((attention_kernel<T, S, CAUSAL>), \
            grid, dim3(256), dim * sizeof(float), stream, \
            q.data_ptr<T>(), k.data_ptr<T>(), v.data_ptr<T>(), out.data_ptr<T>(), \
            starts.data_ptr(), lengths.data_ptr(), st, lt, \
            int(lengths.numel()), int(q.size(1)), int(k.size(1)), dim, scale)

    if (dim <= 256) { LAUNCH(1); }
    else if (dim <= 512) { LAUNCH(2); }
    else if (dim <= 1024) { LAUNCH(4); }
    else if (dim <= 2048) { LAUNCH(8); }
    else {
        hipLaunchKernelGGL((large_head_kernel<T, CAUSAL>),
            dim3(q.size(0), q.size(1), (dim + 255) / 256), dim3(256), 0, stream,
            q.data_ptr<T>(), k.data_ptr<T>(), v.data_ptr<T>(), out.data_ptr<T>(),
            starts.data_ptr(), lengths.data_ptr(), st, lt,
            int(lengths.numel()), int(q.size(1)), int(k.size(1)), dim, scale);
    }
    #undef LAUNCH
}

torch::Tensor ragged_attention(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor starts, torch::Tensor lengths, bool causal, double scale)
{
    TORCH_CHECK(q.is_cuda() && k.is_cuda() && v.is_cuda()
                && starts.is_cuda() && lengths.is_cuda(), "Expected device tensors");
    TORCH_CHECK(q.is_contiguous() && k.is_contiguous() && v.is_contiguous()
                && starts.is_contiguous() && lengths.is_contiguous(),
                "Expected contiguous tensors");
    TORCH_CHECK(q.dim() == 3 && k.dim() == 3 && v.sizes() == k.sizes(),
                "Invalid Q/K/V shapes");
    TORCH_CHECK(q.size(0) == k.size(0) && q.size(2) == k.size(2)
                && k.size(1) > 0 && q.size(1) % k.size(1) == 0,
                "Invalid attention dimensions");
    TORCH_CHECK(q.scalar_type() == k.scalar_type()
                && q.scalar_type() == v.scalar_type(), "Q/K/V dtype mismatch");
    TORCH_CHECK(starts.numel() == lengths.numel(), "Metadata size mismatch");

    c10::cuda::CUDAGuard guard(q.device());
    auto out = torch::empty_like(q);
    if (q.numel() == 0) return out;
    TORCH_CHECK(lengths.numel() > 0, "Empty sequence metadata");
    auto stream = at::cuda::getCurrentCUDAStream(q.get_device());
    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16, q.scalar_type(),
        "ragged_attention", [&] {
            if (causal)
                launch<scalar_t, true>(q, k, v, out, starts, lengths,
                                      float(scale), stream.stream());
            else
                launch<scalar_t, false>(q, k, v, out, starts, lengths,
                                       float(scale), stream.stream());
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="ragged_attention_hip_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)

    def forward(self, q, k, v, b_start_loc, b_seq_len):
        scale = self.sm_scale
        if scale is None:
            scale = 1.0 / math.sqrt(q.shape[2])
        return _get_extension().ragged_attention(
            q, k, v, b_start_loc, b_seq_len, self.causal, scale
        )
```