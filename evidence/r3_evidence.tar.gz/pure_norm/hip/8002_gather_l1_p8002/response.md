```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor run_select(torch::Tensor data, torch::Tensor indices,
                         int64_t axis, bool elements);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run_select", &run_select);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>
#include <climits>
#include <algorithm>

struct IndexLayout {
    int rank;
    int64_t sizes[4];
    int64_t strides[4];
};

template<bool Contiguous, typename Offset>
__device__ __forceinline__ int64_t index_offset(Offset linear,
                                               const IndexLayout& layout) {
    if constexpr (Contiguous) {
        return static_cast<int64_t>(linear);
    } else {
        int64_t pos = 0;
        int64_t q = linear;
        for (int d = layout.rank - 1; d >= 0; --d) {
            const int64_t r = q % layout.sizes[d];
            q /= layout.sizes[d];
            pos += r * layout.strides[d];
        }
        return pos;
    }
}

template<typename Bits, typename Index, typename Offset,
         bool Elements, bool Contiguous, bool InnerOne>
__global__ void select_kernel(
    const Bits* __restrict__ data,
    const Index* __restrict__ indices,
    Bits* __restrict__ out,
    Offset count, Offset inner, Offset k, Offset axis_size,
    IndexLayout layout) {

    const Offset start = static_cast<Offset>(blockIdx.x) * blockDim.x
                       + threadIdx.x;
    const Offset step = static_cast<Offset>(gridDim.x) * blockDim.x;
    for (Offset p = start; p < count; p += step) {
        Offset outer, j, tail;
        if constexpr (InnerOne) {
            outer = p / k;
            j = p % k;
            tail = 0;
        } else {
            const Offset slice = p / inner;
            tail = p % inner;
            outer = slice / k;
            j = slice % k;
        }
        const Offset logical_index = Elements ? p : j;
        const Offset selected = static_cast<Offset>(
            indices[index_offset<Contiguous>(logical_index, layout)]);
        const Offset source = (outer * axis_size + selected) * inner + tail;
        out[p] = data[source];
    }
}

template<typename Bits, typename Index, typename Offset,
         bool Elements, bool Contiguous>
void launch_inner(const torch::Tensor& data, const torch::Tensor& indices,
                  torch::Tensor& out, int64_t inner, int64_t k,
                  int64_t axis_size, IndexLayout layout, hipStream_t stream) {
    constexpr int threads = 256;
    const int blocks = static_cast<int>(
        std::min<int64_t>((out.numel() + threads - 1) / threads, 65535));
    const Bits* src = reinterpret_cast<const Bits*>(data.data_ptr());
    const Index* idx = reinterpret_cast<const Index*>(indices.data_ptr());
    Bits* dst = reinterpret_cast<Bits*>(out.data_ptr());
    if (inner == 1) {
        select_kernel<Bits, Index, Offset, Elements, Contiguous, true>
            <<<blocks, threads, 0, stream>>>(
                src, idx, dst, static_cast<Offset>(out.numel()),
                static_cast<Offset>(inner), static_cast<Offset>(k),
                static_cast<Offset>(axis_size), layout);
    } else {
        select_kernel<Bits, Index, Offset, Elements, Contiguous, false>
            <<<blocks, threads, 0, stream>>>(
                src, idx, dst, static_cast<Offset>(out.numel()),
                static_cast<Offset>(inner), static_cast<Offset>(k),
                static_cast<Offset>(axis_size), layout);
    }
}

template<typename Bits, typename Index, typename Offset>
void launch_variant(const torch::Tensor& data, const torch::Tensor& indices,
                    torch::Tensor& out, int64_t inner, int64_t k,
                    int64_t axis_size, bool elements, IndexLayout layout,
                    hipStream_t stream) {
    if (elements) {
        if (indices.is_contiguous())
            launch_inner<Bits, Index, Offset, true, true>(
                data, indices, out, inner, k, axis_size, layout, stream);
        else
            launch_inner<Bits, Index, Offset, true, false>(
                data, indices, out, inner, k, axis_size, layout, stream);
    } else {
        if (indices.is_contiguous())
            launch_inner<Bits, Index, Offset, false, true>(
                data, indices, out, inner, k, axis_size, layout, stream);
        else
            launch_inner<Bits, Index, Offset, false, false>(
                data, indices, out, inner, k, axis_size, layout, stream);
    }
}

template<typename Bits, typename Index>
void launch_offsets(const torch::Tensor& data, const torch::Tensor& indices,
                    torch::Tensor& out, int64_t inner, int64_t k,
                    int64_t axis_size, bool elements, IndexLayout layout,
                    hipStream_t stream) {
    // Leave space for the final grid-stride increment without overflow.
    if (std::max(data.numel(), out.numel()) <= INT_MAX - 16777216LL) {
        launch_variant<Bits, Index, uint32_t>(
            data, indices, out, inner, k, axis_size, elements, layout, stream);
    } else {
        launch_variant<Bits, Index, uint64_t>(
            data, indices, out, inner, k, axis_size, elements, layout, stream);
    }
}

template<typename Bits>
void launch_indices(const torch::Tensor& data, const torch::Tensor& indices,
                    torch::Tensor& out, int64_t inner, int64_t k,
                    int64_t axis_size, bool elements, IndexLayout layout,
                    hipStream_t stream) {
    switch (indices.scalar_type()) {
        case at::kFloat:
            launch_offsets<Bits, float>(
                data, indices, out, inner, k, axis_size, elements, layout, stream);
            break;
        case at::kInt:
            launch_offsets<Bits, int32_t>(
                data, indices, out, inner, k, axis_size, elements, layout, stream);
            break;
        case at::kLong:
            launch_offsets<Bits, int64_t>(
                data, indices, out, inner, k, axis_size, elements, layout, stream);
            break;
        default:
            TORCH_CHECK(false, "indices must have float32, int32, or int64 dtype");
    }
}

torch::Tensor run_select(torch::Tensor data, torch::Tensor indices,
                         int64_t axis, bool elements) {
    TORCH_CHECK(data.is_cuda() && indices.is_cuda(), "inputs must be on device");
    TORCH_CHECK(data.device() == indices.device(), "input devices must match");
    TORCH_CHECK(data.is_contiguous(), "data must be contiguous");
    TORCH_CHECK(data.dim() >= 1 && data.dim() <= 4, "unsupported data rank");
    TORCH_CHECK(data.scalar_type() == at::kFloat ||
                data.scalar_type() == at::kHalf ||
                data.scalar_type() == at::kBFloat16, "unsupported data dtype");

    const c10::cuda::CUDAGuard guard(data.device());
    const int64_t rank = data.dim();
    axis = ((axis % rank) + rank) % rank;

    std::vector<int64_t> shape = data.sizes().vec();
    int64_t k;
    if (elements) {
        TORCH_CHECK(indices.dim() == rank, "index rank must match data rank");
        for (int d = 0; d < rank; ++d)
            TORCH_CHECK(d == axis || indices.size(d) == data.size(d),
                        "incompatible index shape");
        k = indices.size(axis);
        shape = indices.sizes().vec();
    } else {
        TORCH_CHECK(indices.dim() == 1, "indices must be a vector");
        k = indices.size(0);
        shape[axis] = k;
    }

    auto out = torch::empty(shape, data.options());
    if (out.numel() == 0)
        return out;

    int64_t inner = 1;
    for (int d = axis + 1; d < rank; ++d)
        inner *= data.size(d);

    IndexLayout layout{};
    layout.rank = indices.dim();
    for (int d = 0; d < layout.rank; ++d) {
        layout.sizes[d] = indices.size(d);
        layout.strides[d] = indices.stride(d);
    }

    hipStream_t stream = at::cuda::getCurrentCUDAStream(data.get_device());
    if (data.scalar_type() == at::kFloat)
        launch_indices<uint32_t>(data, indices, out, inner, k,
                                 data.size(axis), elements, layout, stream);
    else
        launch_indices<uint16_t>(data, indices, out, inner, k,
                                 data.size(axis), elements, layout, stream);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name="index_movement_hip_" + digest,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3", "-std=c++17"],
            extra_cuda_cflags=["-O3", "-std=c++17"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "gather", axis: int = 1):
        super().__init__()
        assert variant in ("gather", "gather_elements")
        self.variant = variant
        self.axis = int(axis)

    def forward(self, data, indices):
        return _get_extension().run_select(
            data, indices, self.axis, self.variant == "gather_elements"
        )
```