import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor softmax_hip(torch::Tensor x);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("softmax_hip", &softmax_hip);
}
"""

_HIP_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

__device__ __forceinline__ float wave_max(float v) {
    #pragma unroll
    for (int d = 32; d > 0; d >>= 1)
        v = fmaxf(v, __shfl_xor(v, d, 64));
    return v;
}

__device__ __forceinline__ float wave_sum(float v) {
    #pragma unroll
    for (int d = 32; d > 0; d >>= 1)
        v += __shfl_xor(v, d, 64);
    return v;
}

template<typename T, int ITEMS>
__global__ void softmax_wave(
    const T* __restrict__ x, T* __restrict__ y,
    int64_t rows, int64_t cols)
{
    const int lane = threadIdx.x & 63;
    const int64_t row = int64_t(blockIdx.x) * 4 + (threadIdx.x >> 6);
    if (row >= rows) return;

    const int64_t base = row * cols;
    float values[ITEMS];
    float maximum = -INFINITY;

    #pragma unroll
    for (int i = 0; i < ITEMS; ++i) {
        const int col = lane + i * 64;
        float v = col < cols ? float(x[base + col]) : -INFINITY;
        values[i] = v;
        maximum = fmaxf(maximum, v);
    }
    maximum = wave_max(maximum);

    float sum = 0.0f;
    #pragma unroll
    for (int i = 0; i < ITEMS; ++i) {
        values[i] = expf(values[i] - maximum);
        sum += values[i];
    }
    const float inv_sum = 1.0f / wave_sum(sum);

    #pragma unroll
    for (int i = 0; i < ITEMS; ++i) {
        const int col = lane + i * 64;
        if (col < cols)
            y[base + col] = T(values[i] * inv_sum);
    }
}

template<bool MAXIMUM>
__device__ __forceinline__ float block_reduce(float v, float* scratch) {
    const int lane = threadIdx.x & 63;
    const int wave = threadIdx.x >> 6;
    v = MAXIMUM ? wave_max(v) : wave_sum(v);
    if (lane == 0) scratch[wave] = v;
    __syncthreads();

    float total = MAXIMUM ? -INFINITY : 0.0f;
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        if (MAXIMUM) total = fmaxf(total, scratch[i]);
        else total += scratch[i];
    }
    __syncthreads();
    return total;
}

template<typename T>
__global__ void softmax_long(
    const T* __restrict__ x, T* __restrict__ y, int64_t cols)
{
    __shared__ float scratch[4];
    const int64_t base = int64_t(blockIdx.x) * cols;

    float maximum = -INFINITY;
    for (int64_t col = threadIdx.x; col < cols; col += 256)
        maximum = fmaxf(maximum, float(x[base + col]));
    maximum = block_reduce<true>(maximum, scratch);

    float sum = 0.0f;
    for (int64_t col = threadIdx.x; col < cols; col += 256)
        sum += expf(float(x[base + col]) - maximum);
    const float inv_sum = 1.0f / block_reduce<false>(sum, scratch);

    for (int64_t col = threadIdx.x; col < cols; col += 256)
        y[base + col] = T(expf(float(x[base + col]) - maximum) * inv_sum);
}

template<typename T>
void launch(
    const T* x, T* y, int64_t rows, int64_t cols, hipStream_t stream)
{
    const dim3 block(256);
    const dim3 grid((rows + 3) / 4);
    if (cols <= 64)
        softmax_wave<T, 1><<<grid, block, 0, stream>>>(x, y, rows, cols);
    else if (cols <= 128)
        softmax_wave<T, 2><<<grid, block, 0, stream>>>(x, y, rows, cols);
    else if (cols <= 256)
        softmax_wave<T, 4><<<grid, block, 0, stream>>>(x, y, rows, cols);
    else if (cols <= 512)
        softmax_wave<T, 8><<<grid, block, 0, stream>>>(x, y, rows, cols);
    else if (cols <= 1024)
        softmax_wave<T, 16><<<grid, block, 0, stream>>>(x, y, rows, cols);
    else if (cols <= 2048)
        softmax_wave<T, 32><<<grid, block, 0, stream>>>(x, y, rows, cols);
    else if (cols <= 4096)
        softmax_wave<T, 64><<<grid, block, 0, stream>>>(x, y, rows, cols);
    else
        softmax_long<T><<<dim3(rows), block, 0, stream>>>(x, y, cols);
}

torch::Tensor softmax_hip(torch::Tensor x) {
    TORCH_CHECK(x.is_cuda(), "Expected a GPU tensor");
    TORCH_CHECK(x.dim() == 2 && x.is_contiguous(),
                "Expected a contiguous (M, N) tensor");
    TORCH_CHECK(x.size(0) >= 1 && x.size(1) >= 1,
                "Both dimensions must be positive");
    TORCH_CHECK(x.scalar_type() == at::kFloat ||
                x.scalar_type() == at::kHalf ||
                x.scalar_type() == at::kBFloat16,
                "Expected float32, float16, or bfloat16");

    const c10::cuda::CUDAGuard guard(x.device());
    auto y = torch::empty_like(x);
    auto stream = at::cuda::getCurrentCUDAStream(x.get_device());

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "softmax_hip", [&] {
            launch<scalar_t>(
                x.data_ptr<scalar_t>(), y.data_ptr<scalar_t>(),
                x.size(0), x.size(1), stream.stream());
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return y;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha256(
            (_CPP_SRC + _HIP_SRC).encode("utf-8")
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"row_softmax_hip_{digest}",
            cpp_sources=_CPP_SRC,
            cuda_sources=_HIP_SRC,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return _get_extension().softmax_hip(x)
