```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

CUDA_CPP_SRC = r"""
#include <torch/extension.h>
torch::Tensor sparse_backward(
    torch::Tensor x, torch::Tensor w, torch::Tensor dy,
    torch::Tensor pairs, torch::Tensor counts, bool weight);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run", &sparse_backward);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <algorithm>

__device__ __forceinline__ int read_index(const void* p, int type, int64_t i) {
    if (type == 0) return ((const int*)p)[i];
    if (type == 1) return (int)((const int64_t*)p)[i];
    return (int)((const float*)p)[i];
}

template<class T>
__global__ void dgrad_kernel(
    const T* __restrict__ w, const T* __restrict__ dy,
    const void* pairs, const void* counts, int pt, int ct,
    float* __restrict__ result, int n, int ci, int co, int kv)
{
    __shared__ float a[16][17];
    __shared__ float b[16][17];
    __shared__ int src[16], dst[16];

    int tx = threadIdx.x, ty = threadIdx.y;
    int k = blockIdx.z;
    int j = blockIdx.y * 16 + ty;
    int i = blockIdx.x * 16 + tx;
    int count = read_index(counts, ct, k);
    if (blockIdx.y * 16 >= count) return;

    if (tx == 0) {
        src[ty] = j < count ? read_index(pairs, pt, (int64_t)k*n+j) : 0;
        dst[ty] = j < count ? read_index(pairs, pt, (int64_t)(kv+k)*n+j) : 0;
    }
    __syncthreads();

    float acc = 0.0f;
    for (int o = 0; o < co; o += 16) {
        a[ty][tx] = j < count && o+tx < co
            ? (float)dy[(int64_t)dst[ty]*co+o+tx] : 0.0f;
        b[ty][tx] = i < ci && o+ty < co
            ? (float)w[((int64_t)(o+ty)*kv+k)*ci+i] : 0.0f;
        __syncthreads();
        #pragma unroll
        for (int r = 0; r < 16; ++r)
            acc = fmaf(a[ty][r], b[r][tx], acc);
        __syncthreads();
    }
    if (j < count && i < ci)
        atomicAdd(result+(int64_t)src[ty]*ci+i, acc);
}

template<class T>
__global__ void wgrad_kernel(
    const T* __restrict__ x, const T* __restrict__ dy,
    const void* pairs, const void* counts, int pt, int ct,
    float* __restrict__ partial, int n, int ci, int co, int kv, int splits)
{
    __shared__ float a[16][17];
    __shared__ float b[16][17];
    __shared__ int src[16], dst[16];

    int tx = threadIdx.x, ty = threadIdx.y;
    int k = blockIdx.z % kv;
    int split = blockIdx.z / kv;
    int i = blockIdx.x*16+tx;
    int o = blockIdx.y*16+ty;
    int count = read_index(counts, ct, k);
    int tiles = (count+15)/16;
    int first = (tiles*split/splits)*16;
    int last = (tiles*(split+1)/splits)*16;
    float acc = 0.0f;

    for (int base = first; base < last; base += 16) {
        if (ty == 0) {
            int j = base+tx;
            src[tx] = j < count ? read_index(pairs, pt, (int64_t)k*n+j) : 0;
            dst[tx] = j < count ? read_index(pairs, pt, (int64_t)(kv+k)*n+j) : 0;
        }
        __syncthreads();
        a[ty][tx] = o < co && base+tx < count
            ? (float)dy[(int64_t)dst[tx]*co+o] : 0.0f;
        b[ty][tx] = i < ci && base+ty < count
            ? (float)x[(int64_t)src[ty]*ci+i] : 0.0f;
        __syncthreads();
        #pragma unroll
        for (int r = 0; r < 16; ++r)
            acc = fmaf(a[ty][r], b[r][tx], acc);
        __syncthreads();
    }
    if (o < co && i < ci) {
        int64_t size = (int64_t)co*kv*ci;
        partial[(int64_t)split*size+((int64_t)o*kv+k)*ci+i] = acc;
    }
}

template<class T>
__global__ void finish_kernel(
    const float* __restrict__ partial, T* __restrict__ out,
    int64_t size, int splits)
{
    int64_t i = (int64_t)blockIdx.x*256+threadIdx.x;
    if (i < size) {
        float acc = 0.0f;
        for (int s = 0; s < splits; ++s)
            acc += partial[(int64_t)s*size+i];
        out[i] = (T)acc;
    }
}

int index_type(const torch::Tensor& t) {
    if (t.scalar_type() == at::kInt) return 0;
    if (t.scalar_type() == at::kLong) return 1;
    TORCH_CHECK(t.scalar_type() == at::kFloat,
                "Indices must be int32, int64, or float32");
    return 2;
}

torch::Tensor sparse_backward(
    torch::Tensor x, torch::Tensor w, torch::Tensor dy,
    torch::Tensor pairs, torch::Tensor counts, bool weight)
{
    c10::cuda::CUDAGuard guard(x.device());
    TORCH_CHECK(x.is_contiguous() && w.is_contiguous() &&
                dy.is_contiguous() && pairs.is_contiguous() &&
                counts.is_contiguous(), "Inputs must be contiguous");
    TORCH_CHECK(x.scalar_type() == w.scalar_type() &&
                x.scalar_type() == dy.scalar_type(), "Feature dtypes must match");
    int n = x.size(0), ci = w.size(1), co = w.size(0), kv = w.size(2);
    int pt = index_type(pairs), ct = index_type(counts);
    auto stream = at::cuda::getCurrentCUDAStream();
    auto options = x.options().dtype(at::kFloat);
    dim3 threads(16,16);

    if (!weight) {
        auto accum = torch::empty({n,ci}, options);
        C10_CUDA_CHECK(hipMemsetAsync(
            accum.data_ptr<float>(), 0, accum.numel()*sizeof(float), stream));
        dim3 grid((ci+15)/16, (n+15)/16, kv);
        AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16,
            x.scalar_type(), "sparse_dgrad", [&] {
                dgrad_kernel<scalar_t><<<grid,threads,0,stream>>>(
                    w.data_ptr<scalar_t>(), dy.data_ptr<scalar_t>(),
                    pairs.data_ptr(), counts.data_ptr(), pt, ct,
                    accum.data_ptr<float>(), n,ci,co,kv);
            });
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        if (x.scalar_type() == at::kFloat) return accum;
        auto result = torch::empty({n,ci}, x.options());
        int64_t size = result.numel();
        AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16,
            x.scalar_type(), "sparse_dgrad_cast", [&] {
                finish_kernel<scalar_t><<<(size+255)/256,256,0,stream>>>(
                    accum.data_ptr<float>(), result.data_ptr<scalar_t>(), size,1);
            });
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        return result;
    }

    int splits = std::min(32, std::max(1, (n+255)/256));
    int64_t size = (int64_t)co*ci*kv;
    auto partial = torch::empty({splits,size}, options);
    auto result = torch::empty({co,ci,kv}, x.options());
    dim3 grid((ci+15)/16, (co+15)/16, kv*splits);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16,
        x.scalar_type(), "sparse_wgrad", [&] {
            wgrad_kernel<scalar_t><<<grid,threads,0,stream>>>(
                x.data_ptr<scalar_t>(), dy.data_ptr<scalar_t>(),
                pairs.data_ptr(), counts.data_ptr(), pt,ct,
                partial.data_ptr<float>(), n,ci,co,kv,splits);
            finish_kernel<scalar_t><<<(size+255)/256,256,0,stream>>>(
                partial.data_ptr<float>(), result.data_ptr<scalar_t>(), size,splits);
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return result;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=f"sparse_adjoint_hip_{digest}",
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, variant: str = "dgrad"):
        super().__init__()
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant

    def forward(self, features, filters, out_bp, indice_pairs, indice_num_per_loc):
        return _get_extension().run(
            features,
            filters,
            out_bp,
            indice_pairs,
            indice_num_per_loc,
            self.variant == "wgrad",
        )
```