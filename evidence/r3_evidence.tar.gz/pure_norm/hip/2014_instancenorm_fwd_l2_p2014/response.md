```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor instance_forward(torch::Tensor x, torch::Tensor scale,
                               torch::Tensor bias, double eps);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &instance_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cstdint>

template<int B>
__device__ __forceinline__ float reduce_sum(float value, float* shared) {
    const int t = threadIdx.x;
    shared[t] = value;
    __syncthreads();
    for (int offset = B / 2; offset; offset >>= 1) {
        if (t < offset)
            shared[t] += shared[t + offset];
        __syncthreads();
    }
    float result = shared[0];
    __syncthreads();
    return result;
}

template<typename T, int B, int K, bool PARTIAL>
__global__ void plane_kernel(
    const T* __restrict__ x,
    const T* __restrict__ scale,
    const T* __restrict__ bias,
    T* __restrict__ output,
    float* __restrict__ partial,
    int64_t spatial, int64_t channels, int parts, float eps)
{
    __shared__ float shared[B];
    const int64_t plane = blockIdx.x;
    const int part = PARTIAL ? blockIdx.y : 0;
    const int64_t start = int64_t(part) * B * K;
    const int count = int(min(int64_t(B * K), spatial - start));
    const int64_t base = plane * spatial + start;

    float values[K];
    float sum = 0.0f;
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        const int i = threadIdx.x + k * B;
        values[k] = i < count ? float(x[base + i]) : 0.0f;
        sum += values[k];
    }
    const float mean = reduce_sum<B>(sum, shared) / float(count);
    float m2 = 0.0f;
    #pragma unroll
    for (int k = 0; k < K; ++k) {
        const int i = threadIdx.x + k * B;
        const float d = values[k] - mean;
        if (i < count)
            m2 += d * d;
    }
    m2 = reduce_sum<B>(m2, shared);
    if (PARTIAL) {
        if (threadIdx.x == 0) {
            const int64_t index = (plane * parts + part) * 2;
            partial[index] = mean;
            partial[index + 1] = m2;
        }
    } else {
        const float inv = rsqrtf(m2 / float(count) + eps);
        const float s = float(scale[plane % channels]);
        const float b = float(bias[plane % channels]);
        #pragma unroll
        for (int k = 0; k < K; ++k) {
            const int i = threadIdx.x + k * B;
            if (i < count)
                output[base + i] = T(((values[k] - mean) * inv) * s + b);
        }
    }
}

__global__ void combine_kernel(
    const float* __restrict__ partial, float* __restrict__ stats,
    int64_t spatial, int parts, float eps)
{
    __shared__ float shared[256];
    const int64_t plane = blockIdx.x;
    float sum = 0.0f;
    for (int p = threadIdx.x; p < parts; p += 256) {
        const int count = int(min(int64_t(4096), spatial - int64_t(p) * 4096));
        sum += partial[(plane * parts + p) * 2] * float(count);
    }
    const float mean = reduce_sum<256>(sum, shared) / float(spatial);
    float m2 = 0.0f;
    for (int p = threadIdx.x; p < parts; p += 256) {
        const int count = int(min(int64_t(4096), spatial - int64_t(p) * 4096));
        const int64_t index = (plane * parts + p) * 2;
        const float delta = partial[index] - mean;
        m2 += partial[index + 1] + delta * delta * float(count);
    }
    m2 = reduce_sum<256>(m2, shared);
    if (threadIdx.x == 0) {
        stats[plane * 2] = mean;
        stats[plane * 2 + 1] = rsqrtf(m2 / float(spatial) + eps);
    }
}

template<typename T>
__global__ void apply_kernel(
    const T* __restrict__ x, const T* __restrict__ scale,
    const T* __restrict__ bias, const float* __restrict__ stats,
    T* __restrict__ output, int64_t spatial, int64_t channels)
{
    const int64_t plane = blockIdx.x;
    const int64_t start = int64_t(blockIdx.y) * 1024;
    const float mean = stats[plane * 2];
    const float inv = stats[plane * 2 + 1];
    const float s = float(scale[plane % channels]);
    const float b = float(bias[plane % channels]);
    #pragma unroll
    for (int k = 0; k < 4; ++k) {
        const int64_t i = start + threadIdx.x + k * 256;
        if (i < spatial) {
            const int64_t index = plane * spatial + i;
            output[index] = T(((float(x[index]) - mean) * inv) * s + b);
        }
    }
}

torch::Tensor instance_forward(torch::Tensor x, torch::Tensor scale,
                               torch::Tensor bias, double eps) {
    TORCH_CHECK(x.is_cuda() && scale.is_cuda() && bias.is_cuda(),
                "All inputs must be accelerator tensors");
    TORCH_CHECK(x.dim() == 4 && x.is_contiguous() &&
                scale.is_contiguous() && bias.is_contiguous(),
                "Expected contiguous NCHW input and affine tensors");
    TORCH_CHECK(scale.scalar_type() == x.scalar_type() &&
                bias.scalar_type() == x.scalar_type(),
                "Input dtypes must match");
    TORCH_CHECK(scale.device() == x.device() && bias.device() == x.device(),
                "Input devices must match");
    const int64_t channels = x.size(1);
    const int64_t planes = x.size(0) * channels;
    const int64_t spatial = x.size(2) * x.size(3);
    TORCH_CHECK(spatial > 0 && channels > 0 && planes > 0,
                "Dimensions must be positive");
    TORCH_CHECK(scale.numel() == channels && bias.numel() == channels,
                "Expected one affine parameter per channel");

    c10::cuda::CUDAGuard guard(x.device());
    auto output = torch::empty_like(x);
    auto stream = at::cuda::getCurrentCUDAStream();
    torch::Tensor partial, stats;
    const int parts = int((spatial + 4095) / 4096);
    if (spatial > 4096) {
        partial = torch::empty({planes, int64_t(parts), 2},
                               x.options().dtype(torch::kFloat32));
        stats = torch::empty({planes, 2}, x.options().dtype(torch::kFloat32));
    }

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "instance_forward", [&] {
            const scalar_t* xp = x.data_ptr<scalar_t>();
            const scalar_t* sp = scale.data_ptr<scalar_t>();
            const scalar_t* bp = bias.data_ptr<scalar_t>();
            scalar_t* op = output.data_ptr<scalar_t>();
            if (spatial <= 64) {
                plane_kernel<scalar_t, 64, 1, false>
                    <<<planes, 64, 0, stream>>>(
                        xp, sp, bp, op, nullptr, spatial, channels, 1, float(eps));
            } else if (spatial <= 256) {
                plane_kernel<scalar_t, 64, 4, false>
                    <<<planes, 64, 0, stream>>>(
                        xp, sp, bp, op, nullptr, spatial, channels, 1, float(eps));
            } else if (spatial <= 1024) {
                plane_kernel<scalar_t, 256, 4, false>
                    <<<planes, 256, 0, stream>>>(
                        xp, sp, bp, op, nullptr, spatial, channels, 1, float(eps));
            } else if (spatial <= 4096) {
                plane_kernel<scalar_t, 256, 16, false>
                    <<<planes, 256, 0, stream>>>(
                        xp, sp, bp, op, nullptr, spatial, channels, 1, float(eps));
            } else {
                plane_kernel<scalar_t, 256, 16, true>
                    <<<dim3(planes, parts), 256, 0, stream>>>(
                        xp, sp, bp, op, partial.data_ptr<float>(),
                        spatial, channels, parts, float(eps));
                combine_kernel<<<planes, 256, 0, stream>>>(
                    partial.data_ptr<float>(), stats.data_ptr<float>(),
                    spatial, parts, float(eps));
                apply_kernel<scalar_t>
                    <<<dim3(planes, (spatial + 1023) / 1024), 256, 0, stream>>>(
                        xp, sp, bp, stats.data_ptr<float>(), op, spatial, channels);
            }
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return output;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "instance_norm_hip_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        assert eps > 0, "eps must be positive"
        self.eps = float(eps)

    def forward(self, x, scale, bias):
        return _get_extension().forward(x, scale, bias, self.eps)
```