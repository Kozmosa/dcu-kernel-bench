```python
import math
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor cq, torch::Tensor ck, torch::Tensor causal,
    double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &attention_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <cmath>

template <typename T>
__global__ void attention_kernel(
    const T* __restrict__ q,
    const T* __restrict__ k,
    const T* __restrict__ v,
    const int* __restrict__ cq,
    const int* __restrict__ ck,
    const int* __restrict__ causal,
    T* __restrict__ out,
    int ns, int hq, int hk, int d,
    int64_t qs0, int64_t qs1, int64_t qs2,
    int64_t ks0, int64_t ks1, int64_t ks2,
    int64_t vs0, int64_t vs1, int64_t vs2,
    float scale)
{
    const int row = blockIdx.x;
    const int head = blockIdx.y;
    const int tid = threadIdx.x;
    const int lane = tid & 7;
    const int key_slot = tid >> 3;

    int lo = 0, hi = ns;
    while (lo + 1 < hi) {
        int mid = (lo + hi) >> 1;
        if (cq[mid] <= row) lo = mid;
        else hi = mid;
    }
    const int b = lo;
    const int nq = cq[b + 1] - cq[b];
    const int nk = ck[b + 1] - ck[b];
    const int begin = ck[b];
    const int count = causal[0] ? row - cq[b] + nk - nq + 1 : nk;
    const int kh = head / (hq / hk);

    __shared__ float query[256];
    __shared__ float weights[32];
    __shared__ float alpha;
    __shared__ float denominator;

    if (tid < d)
        query[tid] = float(q[int64_t(row) * qs0 + head * qs1 + tid * qs2]);
    __syncthreads();

    float accum = 0.0f;
    float running_max = -INFINITY;
    float running_sum = 0.0f;

    for (int base = 0; base < count; base += 32) {
        int j = base + key_slot;
        float score = 0.0f;
        if (j < count) {
            const T* kp = k + int64_t(begin + j) * ks0 + kh * ks1;
            for (int x = lane; x < d; x += 8)
                score = fmaf(query[x], float(kp[x * ks2]), score);
        }
        score += __shfl_down(score, 4, 8);
        score += __shfl_down(score, 2, 8);
        score += __shfl_down(score, 1, 8);
        if (lane == 0)
            weights[key_slot] = j < count ? score * scale : -INFINITY;
        __syncthreads();

        if (tid == 0) {
            float tile_max = -INFINITY;
            const int n = min(32, count - base);
            for (int x = 0; x < n; ++x)
                tile_max = fmaxf(tile_max, weights[x]);
            float next_max = fmaxf(running_max, tile_max);
            float rescale = expf(running_max - next_max);
            float tile_sum = 0.0f;
            for (int x = 0; x < n; ++x) {
                float p = expf(weights[x] - next_max);
                weights[x] = p;
                tile_sum += p;
            }
            running_sum = running_sum * rescale + tile_sum;
            running_max = next_max;
            alpha = rescale;
            denominator = running_sum;
        }
        __syncthreads();

        if (tid < d) {
            accum *= alpha;
            const int n = min(32, count - base);
            const T* vp = v + int64_t(begin + base) * vs0 + kh * vs1 + tid * vs2;
            for (int x = 0; x < n; ++x)
                accum = fmaf(weights[x], float(vp[int64_t(x) * vs0]), accum);
        }
        __syncthreads();
    }

    if (tid < d)
        out[(int64_t(row) * hq + head) * d + tid] = T(accum / denominator);
}

torch::Tensor attention_forward(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor cq, torch::Tensor ck, torch::Tensor causal,
    double scale)
{
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim() == 3 && k.dim() == 3 && v.dim() == 3);
    TORCH_CHECK(q.size(2) >= 1 && q.size(2) <= 256);
    TORCH_CHECK(k.size(1) > 0 && q.size(1) % k.size(1) == 0);
    TORCH_CHECK(q.scalar_type() == k.scalar_type() &&
                q.scalar_type() == v.scalar_type());

    auto out = torch::empty(q.sizes(), q.options());
    if (q.size(0) == 0) return out;
    auto stream = at::cuda::getCurrentCUDAStream();
    dim3 grid(q.size(0), q.size(1));
    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        q.scalar_type(), "varlen_attention_forward", [&] {
            attention_kernel<scalar_t><<<grid, 256, 0, stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(),
                v.data_ptr<scalar_t>(), cq.data_ptr<int>(),
                ck.data_ptr<int>(), causal.data_ptr<int>(),
                out.data_ptr<scalar_t>(),
                cq.numel() - 1, q.size(1), k.size(1), q.size(2),
                q.stride(0), q.stride(1), q.stride(2),
                k.stride(0), k.stride(1), k.stride(2),
                v.stride(0), v.stride(1), v.stride(2),
                float(scale));
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "varlen_row_attention_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)

    def forward(self, q, k, v, cu_seqlens_q, cu_seqlens_k, causal):
        cq = cu_seqlens_q.to(device=q.device, dtype=torch.int32).contiguous()
        ck = cu_seqlens_k.to(device=q.device, dtype=torch.int32).contiguous()
        if isinstance(causal, torch.Tensor):
            flag = causal.to(device=q.device, dtype=torch.int32).contiguous()
        else:
            flag = torch.tensor(causal, device=q.device, dtype=torch.int32)
        return _get_extension().forward(q, k, v, cq, ck, flag, self.sm_scale)
```