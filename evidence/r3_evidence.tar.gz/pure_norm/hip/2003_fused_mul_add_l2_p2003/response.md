```python
import hashlib

import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline


CUDA_CPP_SRC = r"""
#include <torch/extension.h>

torch::Tensor affine_forward(
    torch::Tensor x,
    torch::Tensor a,
    torch::Tensor b,
    double av,
    double bv,
    int64_t am,
    int64_t bm);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("affine_forward", &affine_forward);
}
"""

CUDA_CU_SRC = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <cstdint>

template <typename T, int Mode>
__device__ __forceinline__ float read_argument(
    const T* __restrict__ p, int64_t index, float scalar)
{
    if constexpr (Mode == 2)
        return static_cast<float>(p[index]);
    else
        return scalar;
}

template <typename T, int AM, int BM>
__global__ __launch_bounds__(256)
void affine_kernel(
    const T* __restrict__ x,
    const T* __restrict__ a,
    const T* __restrict__ b,
    T* __restrict__ out,
    int64_t n,
    float av,
    float bv)
{
    if constexpr (AM == 1)
        av = static_cast<float>(a[0]);
    if constexpr (BM == 1)
        bv = static_cast<float>(b[0]);

    constexpr int64_t Tile = 256 * 4;
    const int64_t base = static_cast<int64_t>(blockIdx.x) * Tile
                       + threadIdx.x;
    const int64_t step = static_cast<int64_t>(gridDim.x) * Tile;

    for (int64_t start = base; start < n; start += step) {
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int64_t i = start + j * 256;
            if (i < n) {
                const float xv = static_cast<float>(x[i]);
                const float aa = read_argument<T, AM>(a, i, av);
                const float bb = read_argument<T, BM>(b, i, bv);
                const float product = aa * xv;
                out[i] = static_cast<T>(product + bb);
            }
        }
    }
}

template <typename T, int AM>
void launch_b(
    const T* x, const T* a, const T* b, T* out,
    int64_t n, float av, float bv, int bm,
    unsigned int blocks, hipStream_t stream)
{
    switch (bm) {
        case 0:
            affine_kernel<T, AM, 0><<<blocks, 256, 0, stream>>>(
                x, a, b, out, n, av, bv);
            break;
        case 1:
            affine_kernel<T, AM, 1><<<blocks, 256, 0, stream>>>(
                x, a, b, out, n, av, bv);
            break;
        default:
            affine_kernel<T, AM, 2><<<blocks, 256, 0, stream>>>(
                x, a, b, out, n, av, bv);
            break;
    }
}

torch::Tensor affine_forward(
    torch::Tensor x,
    torch::Tensor a,
    torch::Tensor b,
    double av,
    double bv,
    int64_t am,
    int64_t bm)
{
    TORCH_CHECK(x.is_cuda() && x.is_contiguous(),
                "x must be a contiguous accelerator tensor");
    TORCH_CHECK(am >= 0 && am <= 2 && bm >= 0 && bm <= 2,
                "invalid argument mode");

    for (int k = 0; k < 2; ++k) {
        const auto& t = k == 0 ? a : b;
        const auto mode = k == 0 ? am : bm;
        if (mode != 0) {
            TORCH_CHECK(t.device() == x.device() &&
                        t.scalar_type() == x.scalar_type() &&
                        t.is_contiguous(),
                        "tensor arguments must match x's device and dtype "
                        "and be contiguous");
            TORCH_CHECK(t.numel() == (mode == 1 ? 1 : x.numel()),
                        "tensor arguments must have one or x.numel() elements");
        }
    }

    const c10::cuda::CUDAGuard device_guard(x.device());
    auto out = torch::empty_like(x);
    const int64_t n = x.numel();
    if (n == 0)
        return out;

    const unsigned int blocks = static_cast<unsigned int>(
        std::min<int64_t>((n + 1023) / 1024, 65535));
    const auto stream = at::cuda::getCurrentCUDAStream(x.get_device());

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "affine_forward", [&] {
            const auto* xp = x.data_ptr<scalar_t>();
            const auto* ap = am == 0 ? nullptr : a.data_ptr<scalar_t>();
            const auto* bp = bm == 0 ? nullptr : b.data_ptr<scalar_t>();
            auto* op = out.data_ptr<scalar_t>();
            switch (am) {
                case 0:
                    launch_b<scalar_t, 0>(
                        xp, ap, bp, op, n, float(av), float(bv),
                        bm, blocks, stream);
                    break;
                case 1:
                    launch_b<scalar_t, 1>(
                        xp, ap, bp, op, n, float(av), float(bv),
                        bm, blocks, stream);
                    break;
                default:
                    launch_b<scalar_t, 2>(
                        xp, ap, bp, op, n, float(av), float(bv),
                        bm, blocks, stream);
                    break;
            }
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha1(
            (CUDA_CPP_SRC + CUDA_CU_SRC).encode("utf-8")
        ).hexdigest()[:12]
        _EXTENSION = load_inline(
            name=f"affine_hip_{digest}",
            cpp_sources=CUDA_CPP_SRC,
            cuda_sources=CUDA_CU_SRC,
            functions=None,
            extra_cflags=["-O3", "-std=c++17"],
            extra_cuda_cflags=["-O3", "-std=c++17", "-ffp-contract=off"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x, a, b):
        if isinstance(a, torch.Tensor):
            at, av, am = a, 0.0, 1 if a.numel() == 1 else 2
        else:
            at, av, am = x, float(a), 0

        if isinstance(b, torch.Tensor):
            bt, bv, bm = b, 0.0, 1 if b.numel() == 1 else 2
        else:
            bt, bv, bm = x, float(b), 0

        return _get_extension().affine_forward(x, at, bt, av, bv, am, bm)
```