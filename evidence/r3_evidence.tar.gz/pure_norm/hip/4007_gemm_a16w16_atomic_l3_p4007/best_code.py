import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor pyramid_linear(torch::Tensor x, torch::Tensor weight);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &pyramid_linear);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>

template <typename T>
__global__ void linear_small(
    const T* __restrict__ x, const T* __restrict__ w,
    T* __restrict__ y, int64_t M, int64_t N, int64_t K,
    int64_t xs0, int64_t xs1, int64_t ws0, int64_t ws1)
{
    const int lane = threadIdx.x & 63;
    const int64_t p = int64_t(blockIdx.x) * 4 + (threadIdx.x >> 6);
    if (p >= M * N) return;
    const int64_t m = p / N, n = p % N;
    float sum = 0.0f;
    for (int64_t k = lane; k < K; k += 64)
        sum = fmaf(float(x[m * xs0 + k * xs1]),
                   float(w[n * ws0 + k * ws1]), sum);
    #pragma unroll
    for (int d = 32; d > 0; d >>= 1)
        sum += __shfl_down(sum, d, 64);
    if (lane == 0) y[p] = T(sum);
}

template <typename T>
__global__ __launch_bounds__(256) void linear_tiled(
    const T* __restrict__ x, const T* __restrict__ w,
    T* __restrict__ y, int64_t M, int64_t N, int64_t K,
    int64_t xs0, int64_t xs1, int64_t ws0, int64_t ws1)
{
    __shared__ float a[32][65];
    __shared__ float b[32][65];

    const int tid = threadIdx.x;
    const int tr = tid >> 4;
    const int tc = tid & 15;
    const int64_t row0 = int64_t(blockIdx.y) * 64;
    const int64_t col0 = int64_t(blockIdx.x) * 64;

    float acc[4][4] = {};

    for (int64_t k0 = 0; k0 < K; k0 += 32) {
        #pragma unroll
        for (int q = 0; q < 8; ++q) {
            const int index = tid + q * 256;
            const int r = index >> 5;
            const int k = index & 31;
            const int64_t gk = k0 + k;
            a[k][r] = (row0 + r < M && gk < K)
                ? float(x[(row0 + r) * xs0 + gk * xs1]) : 0.0f;
            b[k][r] = (col0 + r < N && gk < K)
                ? float(w[(col0 + r) * ws0 + gk * ws1]) : 0.0f;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < 32; ++k) {
            float av[4], bv[4];
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                av[i] = a[k][tr + 16 * i];
                bv[i] = b[k][tc + 16 * i];
            }
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                #pragma unroll
                for (int j = 0; j < 4; ++j)
                    acc[i][j] = fmaf(av[i], bv[j], acc[i][j]);
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        const int64_t m = row0 + tr + 16 * i;
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int64_t n = col0 + tc + 16 * j;
            if (m < M && n < N)
                y[m * N + n] = T(acc[i][j]);
        }
    }
}

torch::Tensor pyramid_linear(torch::Tensor x, torch::Tensor weight)
{
    TORCH_CHECK(x.is_cuda() && weight.is_cuda(), "Inputs must be on the GPU");
    TORCH_CHECK(x.device() == weight.device(), "Inputs must share a device");
    TORCH_CHECK(x.dim() == 2 && weight.dim() == 2, "Inputs must be matrices");
    TORCH_CHECK(x.size(1) == weight.size(1), "K dimensions must match");
    TORCH_CHECK(x.scalar_type() == weight.scalar_type(), "Dtypes must match");
    TORCH_CHECK(
        x.scalar_type() == at::kFloat ||
        x.scalar_type() == at::kHalf ||
        x.scalar_type() == at::kBFloat16,
        "Supported dtypes: float32, float16, bfloat16");

    c10::cuda::CUDAGuard guard(x.device());
    const int64_t M = x.size(0), N = weight.size(0), K = x.size(1);
    auto out = torch::empty({M, N}, x.options());
    if (M == 0 || N == 0) return out;
    auto stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "pyramid_linear", [&] {
            if (M * N <= 1024 || M == 1 || N == 1) {
                linear_small<scalar_t><<<
                    dim3((M * N + 3) / 4), dim3(256), 0, stream>>>(
                    x.data_ptr<scalar_t>(), weight.data_ptr<scalar_t>(),
                    out.data_ptr<scalar_t>(), M, N, K,
                    x.stride(0), x.stride(1),
                    weight.stride(0), weight.stride(1));
            } else {
                linear_tiled<scalar_t><<<
                    dim3((N + 63) / 64, (M + 63) / 64),
                    dim3(256), 0, stream>>>(
                    x.data_ptr<scalar_t>(), weight.data_ptr<scalar_t>(),
                    out.data_ptr<scalar_t>(), M, N, K,
                    x.stride(0), x.stride(1),
                    weight.stride(0), weight.stride(1));
            }
        });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        digest = hashlib.sha256((_CPP + _HIP).encode()).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=f"pyramid_linear_hip_{digest}",
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

    def forward(self, x, weight):
        return _get_extension().forward(x, weight)
