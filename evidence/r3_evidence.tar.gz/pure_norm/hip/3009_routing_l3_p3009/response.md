```python
import hashlib
import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_CPP = r"""
#include <torch/extension.h>
torch::Tensor route_forward(torch::Tensor x, torch::Tensor w, bool fused);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("route_forward", &route_forward);
}
"""

_HIP = r"""
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <hip/hip_runtime.h>
#include <climits>

__device__ __forceinline__ bool better(float a, int ai, float b, int bi) {
    return (isnan(a) && !isnan(b)) ||
           (isnan(a) && isnan(b) && ai < bi) ||
           a > b || (a == b && ai < bi);
}

template<bool FUSED>
__device__ __forceinline__ void write_output(
    float* out, int row, int n, int id, float value) {
    constexpr int C = FUSED ? 2 : 1;
    const int64_t base = int64_t(row) * (2 * C);
    out[base] = float(id);
    out[base + C] = value;
    if (FUSED) {
        out[base + 1] = float(n);
        out[base + 3] = 1.0f;
    }
}

template<typename scalar_t, bool FUSED>
__global__ __launch_bounds__(256) void routing_tiles(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ w,
    float* __restrict__ partial,
    float* __restrict__ out,
    int M, int K, int N, int tiles) {
    __shared__ float xs[16][16];
    __shared__ float ws[16][64];

    const int tid = threadIdx.x;
    const int lane = tid & 63;
    const int group = tid >> 6;
    const int row_base = blockIdx.x * 16;
    const int col = blockIdx.y * 64 + lane;
    float a0 = 0.0f, a1 = 0.0f, a2 = 0.0f, a3 = 0.0f;

    for (int kb = 0; kb < K; kb += 16) {
        const int xr = tid >> 4;
        const int xk = tid & 15;
        xs[xr][xk] = row_base + xr < M && kb + xk < K
            ? float(x[int64_t(row_base + xr) * K + kb + xk])
            : 0.0f;

        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            const int wk = group + j * 4;
            ws[wk][lane] = kb + wk < K && col < N
                ? float(w[int64_t(kb + wk) * N + col])
                : 0.0f;
        }
        __syncthreads();

        #pragma unroll
        for (int k = 0; k < 16; ++k) {
            const float v = ws[k][lane];
            a0 = fmaf(xs[group][k], v, a0);
            a1 = fmaf(xs[group + 4][k], v, a1);
            a2 = fmaf(xs[group + 8][k], v, a2);
            a3 = fmaf(xs[group + 12][k], v, a3);
        }
        __syncthreads();
    }

    float accum[4] = {a0, a1, a2, a3};
    #pragma unroll
    for (int j = 0; j < 4; ++j) {
        // Selection must follow sigmoid: distinct large logits can tie at 1.
        float best = col < N
            ? 1.0f / (1.0f + expf(-accum[j]))
            : -INFINITY;
        int id = col < N ? col : INT_MAX;

        #pragma unroll
        for (int delta = 32; delta > 0; delta >>= 1) {
            const float other = __shfl_down(best, delta, 64);
            const int other_id = __shfl_down(id, delta, 64);
            if (lane + delta < 64 && better(other, other_id, best, id)) {
                best = other;
                id = other_id;
            }
        }

        const int row = row_base + group + j * 4;
        if (lane == 0 && row < M) {
            if (tiles == 1) {
                write_output<FUSED>(out, row, N, id, best);
            } else {
                const int64_t p = (int64_t(row) * tiles + blockIdx.y) * 2;
                partial[p] = best;
                partial[p + 1] = float(id);
            }
        }
    }
}

template<bool FUSED>
__global__ __launch_bounds__(256) void routing_finish(
    const float* __restrict__ partial,
    float* __restrict__ out,
    int M, int N, int tiles) {
    const int row = blockIdx.x * 4 + (threadIdx.x >> 6);
    const int lane = threadIdx.x & 63;
    if (row >= M) return;

    float best = -INFINITY;
    int id = INT_MAX;
    for (int t = lane; t < tiles; t += 64) {
        const int64_t p = (int64_t(row) * tiles + t) * 2;
        const float v = partial[p];
        const int i = int(partial[p + 1]);
        if (better(v, i, best, id)) {
            best = v;
            id = i;
        }
    }

    #pragma unroll
    for (int delta = 32; delta > 0; delta >>= 1) {
        const float v = __shfl_down(best, delta, 64);
        const int i = __shfl_down(id, delta, 64);
        if (lane + delta < 64 && better(v, i, best, id)) {
            best = v;
            id = i;
        }
    }
    if (lane == 0) write_output<FUSED>(out, row, N, id, best);
}

template<typename scalar_t, bool FUSED>
void launch_route(
    const torch::Tensor& x, const torch::Tensor& w,
    torch::Tensor& partial, torch::Tensor& out,
    int M, int K, int N, int tiles, hipStream_t stream) {
    routing_tiles<scalar_t, FUSED><<<dim3((M + 15) / 16, tiles), 256, 0, stream>>>(
        x.data_ptr<scalar_t>(), w.data_ptr<scalar_t>(),
        partial.data_ptr<float>(), out.data_ptr<float>(), M, K, N, tiles);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    if (tiles > 1) {
        routing_finish<FUSED><<<(M + 3) / 4, 256, 0, stream>>>(
            partial.data_ptr<float>(), out.data_ptr<float>(), M, N, tiles);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
}

torch::Tensor route_forward(torch::Tensor x, torch::Tensor w, bool fused) {
    TORCH_CHECK(x.is_cuda() && w.is_cuda(), "Inputs must be device tensors");
    TORCH_CHECK(x.device() == w.device(), "Inputs must share a device");
    TORCH_CHECK(x.dim() == 2 && w.dim() == 2, "Inputs must be matrices");
    TORCH_CHECK(x.size(1) == w.size(0), "Incompatible matrix dimensions");
    TORCH_CHECK(x.scalar_type() == w.scalar_type(), "Input dtypes must match");
    TORCH_CHECK(x.is_contiguous() && w.is_contiguous(), "Inputs must be contiguous");
    TORCH_CHECK(x.size(0) <= INT_MAX && x.size(1) <= INT_MAX &&
                w.size(1) > 0 && w.size(1) < (1 << 24), "Unsupported dimensions");

    c10::cuda::CUDAGuard guard(x.device());
    const int M = x.size(0), K = x.size(1), N = w.size(1);
    const int tiles = (N + 63) / 64;
    auto options = x.options().dtype(torch::kFloat32);
    auto out = torch::empty({M, fused ? 4 : 2}, options);
    if (M == 0) return out;
    auto partial = torch::empty(
        {tiles > 1 ? int64_t(M) * tiles * 2 : int64_t(0)}, options);
    hipStream_t stream = at::cuda::getCurrentCUDAStream();

    AT_DISPATCH_FLOATING_TYPES_AND2(
        at::ScalarType::Half, at::ScalarType::BFloat16,
        x.scalar_type(), "routing_forward", [&] {
            if (fused)
                launch_route<scalar_t, true>(x, w, partial, out, M, K, N, tiles, stream);
            else
                launch_route<scalar_t, false>(x, w, partial, out, M, K, N, tiles, stream);
        });
    return out;
}
"""

_EXTENSION = None


def _get_extension():
    global _EXTENSION
    if _EXTENSION is None:
        name = "hip_sigmoid_router_" + hashlib.sha1(
            (_CPP + _HIP).encode()
        ).hexdigest()[:16]
        _EXTENSION = load_inline(
            name=name,
            cpp_sources=_CPP,
            cuda_sources=_HIP,
            functions=None,
            extra_cflags=["-O3"],
            extra_cuda_cflags=["-O3"],
            with_cuda=True,
            verbose=False,
        )
    return _EXTENSION


class ModelNew(nn.Module):
    def __init__(self, fused_shared_experts: bool = True):
        super().__init__()
        self.fused_shared_experts = bool(fused_shared_experts)

    def forward(self, x, w):
        return _get_extension().route_forward(x, w, self.fused_shared_experts)
```