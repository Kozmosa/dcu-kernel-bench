#!/bin/bash
# 收尾：合并产物 → 两轨并行离线终审 → 汇总在线/离线/严格口径。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$ROOT" || exit 1

echo "== 合并产物到 final2 =="
python3 - <<'PY'
import glob, pathlib, shutil, re, sys
sys.path.insert(0, "/root/dcudeploy/kw_full_b_d_20261101_r3/KernelWeaver")
root = pathlib.Path("/root/dcudeploy/kw_full_b_d_20261101_r3")
for track in ("hip", "triton"):
    view = root / "final2" / track
    if view.exists():
        shutil.rmtree(view)
    view.mkdir(parents=True)
    n = 0
    for d in glob.glob(str(root / "groups/dcu_d_combined" / track / "shard*" / "*")):
        p = pathlib.Path(d)
        if (p / "run.json").exists():
            dst = view / p.name
            dst.mkdir()
            for f in ("run.json", "best_code.py"):
                if (p / f).exists():
                    shutil.copy2(p / f, dst / f)
            n += 1
    print(f"{track}: {n} 题")
PY

echo "== 两轨并行离线终审 =="
for t in hip triton; do
  python3 -u metric_tools/audit_batch.py \
      --run-root "final2/$t" --manifest "manifest_$t.yaml" \
      --impl aiter --timeout 900 > "reports/final2_audit_$t.log" 2>&1 &
done
wait
echo "== 汇总 =="
python3 - <<'PY'
import json, glob, re
def key(s):
    m = re.search(r"(\d{4})", str(s or "")); return m.group(1) if m else str(s)
def offline(p):
    out = {}
    try:
        for r in json.load(open(p)).get("rows", []):
            out[key(r.get("task") or r.get("alias"))] = bool(r.get("correctness_passed"))
    except FileNotFoundError:
        pass
    return out
def online(track):
    m = {}
    for f in glob.glob(f"/root/dcudeploy/kw_full_b_d_20261101_r3/final2/{track}/*/run.json"):
        d = json.load(open(f))
        nodes = {k: v for k, v in d.get("nodes", {}).items() if k not in ("root", "phase2_root")}
        m[key(d.get("task_name") or f.split("/")[-2])] = any(v.get("correct") for v in nodes.values())
    return m
for t in ("hip", "triton"):
    on = online(t)
    off = offline(f"/root/dcudeploy/kw_full_b_d_20261101_r3/final2/{t}/offline_audit.json")
    strict = sum(1 for k in on if on[k] and off.get(k))
    print("%-6s 在线正确 %d/66 | 离线通过 %d/66 | 在线∩离线 %d/66" % (t, sum(on.values()), sum(off.values()), strict))
PY
echo "DONE $(date +%H:%M:%S)"
