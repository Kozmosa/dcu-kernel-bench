# DCU 上机部署手册

> 目标：**拿到 SSH 后，一条命令完成上传 + 部署，再两条命令完成验收与采基线。**
> 打包版本：`main-merge` @ `7e06b01`（47 题 / 44 个 aiter 适配器）

---

## 0. 我需要你给的东西

| 项 | 说明 |
|---|---|
| **host** | 服务器地址 |
| **port** | SSH 端口 |
| **user** | 用户名（如 `root`） |
| **密钥 或 密码** | 有 `id_rsa` 私钥最省事；只有密码也行（脚本用 askpass 处理，无需交互终端） |

给出后我执行的是这一条：

```powershell
# 密钥认证
.dcu_runs\deploy\push.ps1 -Server <host> -Port <port> -User <user> -Key $HOME\.ssh\id_rsa -Deploy

# 或密码认证
.dcu_runs\deploy\push.ps1 -Server <host> -Port <port> -User <user> -Password '<pwd>' -Deploy
```

它会做四件事：本地打包 → 建远端目录 → 上传 → 跑 `deploy.sh`。

服务器上已有 triton wheel 与离线依赖时，加 `-SkipWheel -SkipDeps` 可省 163 MB 上传。

---

## 1. 环境硬条件

镜像本身**只需提供 DTK 环境**，其余都是我们自带：

| 条件 | 要求 | 不满足的后果 |
|---|---|---|
| **DTK** | **26.04** | wheel 是 `dtk2604` 编的，装不上 |
| **Python** | **3.11** | wheel tag 是 `cp311` |
| **PyTorch** | **2.9.0** | wheel tag 是 `torch290`，ABI 需匹配 |
| **架构** | **gfx936** | `arch_info` 映射为 `BW200`；换架构基线不可比 |

```bash
source /opt/dtk/env.sh
python3 -V                                   # 3.11.x
python3 -c "import torch;print(torch.__version__, torch.cuda.is_available())"   # 2.9.0 True
python3 -c "import torch;print(torch.cuda.get_device_properties(0).gcnArchName)" # gfx936...
```

`deploy.sh --check` 就是把上面这套自动跑一遍，不改动任何文件。

---

## 2. 包内容

| 文件 | 体积 | 说明 |
|---|---|---|
| `dcu-kernel-bench.tar` | 2.43 MB | 评测集（`git archive` 自 `7e06b01`）：47 题 / 44 适配器 / `dcukb.py` / `record_baseline.py` / 8 个测试模块 |
| `aiter_shim.tar.gz` | 0.31 MB | **aiter 最小导入垫片**：60 个纯 Python 模块 + 309 个 tuner config |
| `py311deps.tar.gz` | 61 MB | 离线依赖（含 **PyYAML 6.0.3**、pytest、litellm 等 128 个包） |
| `triton-...dtk2604.torch290-cp311....whl` | 102 MB | DTK 26.04 版 Triton |
| `deploy.sh` | | 服务器端一键部署 + 环境自检 |
| `verify.sh` | | 验收：镜像一致性 → 配置齐备性 → reference 自检 → 测试套件 |
| `collect_baselines.sh` | | 逐题采集基线，支持号段选择 |
| `check_configs.py` | | 逐题静态检查 tuner 配置在目标架构上是否齐备 |
| `run_all_tests.py` | | 无 pytest 时的测试驱动（服务器上有 pytest，一般用不到） |
| `push.ps1` | | 本地侧上传器 |

### 垫片是什么、为什么必须有

真 `aiter/__init__.py` 会 `from .jit import core`、`from .ops.aiter_operator import *` 等一堆
CK / 编译扩展模块，服务器上没有预编译的 `aiter_`，**直接放真 aiter 上 PYTHONPATH 会崩**。

垫片做了三件事：

1. **8 个 `__init__.py` 全部换成存根**（顶层 `aiter/__init__.py` 提供 `logger`，因为
   `unified_attention.py` 等 8 处 `from aiter import logger`）
2. **只复制 44 个适配器实际需要的模块闭包** —— 从适配器收集 `from aiter...` 引用后递归解析，
   48 个直接引用 → 57 个模块文件，**0 个未解析**
3. **带上 `configs/`**（309 个 json）：`AITER_TRITON_CONFIGS_PATH` 指向
   `aiter/ops/triton/configs`，35 道题要读它

垫片必须排在 `PYTHONPATH` **最前**，确保 `aiter.*` 解析到垫片。

---

## 3. 部署（服务器端）

`push.ps1 -Deploy` 已自动执行；手动则是：

```bash
cd /root/dcudeploy/upload
bash deploy.sh              # 全流程
bash deploy.sh --check      # 只做环境自检，不改动
```

`deploy.sh` 的 5 个阶段：环境自检 → 解包（并校验 47 题/44 适配器、垫片 `__init__.py` 是存根）
→ 装 triton → 生成 `env.sh` → 冒烟（pyyaml 可导入、垫片可导入）。

生成的 `env.sh`：

```bash
source /opt/dtk/env.sh
export PYTHONPATH=/root/dcudeploy/aiter_shim:/root/dcudeploy/py311deps:/root/dcudeploy/dcu-kernel-bench:$PYTHONPATH
```

---

## 4. 验收

```bash
source /root/dcudeploy/env.sh
bash /root/dcudeploy/upload/verify.sh
```

四步：镜像一致性（45 题逐字节）→ 配置齐备性 → **逐题 reference 真机自检**（每題跑首个
perf case，验证 reference 在 GPU 上不崩 —— 这一步会直接暴露 2001/4005 那类 device 问题）
→ 测试套件。

---

## 5. 采基线

```bash
source /root/dcudeploy/env.sh
bash /root/dcudeploy/upload/collect_baselines.sh 2xxx     # 先做 2xxx（9 题，风险最低）
bash /root/dcudeploy/upload/collect_baselines.sh 1xxx
bash /root/dcudeploy/upload/collect_baselines.sh all
DRY=1 bash .../collect_baselines.sh 2xxx                  # 只校验不写回
```

采集器 `record_baseline.py --task <id>` 会**先与 reference 按 task.yaml 容差比对通过才记录**，
不通过则拒收 —— 这是防止记下错误基线的保护，不是 bug。

日志落在 `/root/dcudeploy/baseline_logs/<时间戳>/<task>.log`。

---

## 6. ⚠️ 已知问题：13 道题在 BW 上可能采不了基线

`check_configs.py` 静态扫描发现：**13 道题的调用路径会落到缺失的 tuner 配置读取点，且该读取无
`exists` 保护**。`arch_info` 的映射是 `gfx936→BW200`、`gfx938→BW200B`，而 pin 住的 aiter
里这些文件对 gfx936 根本不存在：

| 缺的配置 | 影响的题 |
|---|---|
| `BW200-EXTEND_ATTENTION-V2-FP16.json`、`...-V2-DECODE-FP16.json` | `1011_extend_attention` |
| `hstu_attn/BW200-HSTU_ATTN_FWD.json`、`...BWD.json` | `1014_hstu_attention` |
| `BW200-MHA-DEFAULT.json` | `1017` / `1018` / `1019` |
| `BW200-MLA_DECODE_ROPE-DEFAULT.json` | `1020_mla_decode_rope` |
| `sage_attention/*device=gfx936*`（全树 0 个） | `1026` / `1027` |
| `gemm/BW200-BATCHED_GEMM-A8W8.json` | `4001_batched_gemm_a8w8` |
| `gemm/BW200-BATCHED_GEMM-A16W16.json` | `4004_batched_gemm_bf16` |
| `gemm/BW200-GEMM-A16W16.json` | `4006_gemm_a16w16` |
| `gemm/BW200-GEMM-A8W8.json` | `4009_gemm_a8w8` |
| `gemm/BW200-GEMM_BLOCKSCALE-A8W8.json` | `4010_gemm_a8w8_blockscale` |

补充说明：

- 这批文件里 `MHA` / `MLA_DECODE_ROPE` / `sage_attention` **全树一个都没有**（不只缺 BW200），
  说明这条代码路径在 pin 的 commit 里就没配过；`gemm/` 顶层 46 个配置**全是 MI300X/MI350X**。
- 有 BW200 配置的是：`gemm/awq_w4a16`（38 个，对应 `4008`）、`gemm/block_w8a8`（16 个，对应
  `4016`）、`moe/`（104 个）、`group_quant/`（2 个，对应 `4017`）。
- **这是静态命中，不等于必然触发** —— 实际是否走到该读取点取决于调用路径。上机时以
  `verify.sh` 的 reference 自检和 `collect_baselines.sh` 的实际结果为准。
- 缺失会导致两种后果：
  - **无保护** → 直接 `FileNotFoundError`，该题基线采不了
  - 有保护 → 回退默认配置，**能跑但基线偏慢 → 高估 agent 加速比**
- `4007_gemm_a16w16_atomic` 本来就没有适配器（同一原因），故不在 44 之内。

**处置建议**：先采 `2xxx`（9 题全 OK）与 `3xxx`/部分 `1xxx`，把能采的 31 道跑完；
缺配置的 13 道再决定是补配置、还是从基线集合中排除并在文档中标注。

---

## 7. 排错

| 现象 | 原因 / 处置 |
|---|---|
| `import aiter` 拉起了真 aiter 或报 `aiter_` 缺失 | `PYTHONPATH` 里垫片不在最前；或垫片打包误带真 `aiter/__init__.py`（`deploy.sh` 会校验） |
| `ModuleNotFoundError: yaml` | `py311deps` 没解包或没进 `PYTHONPATH` |
| `ModuleNotFoundError: triton` | wheel 没装；确认 `pip3 install --no-deps` 用的是 DTK 26.04 那个包 |
| `FileNotFoundError: .../BW200-*.json` | 见 §6，属已知缺配置 |
| `torch.cuda.is_available() = False` | 没 `source /opt/dtk/env.sh`，或卡被占用 |
| 显存 / 内存 OOM | 最大的 perf case 单张量约 4.3 GB（bf16），如 `1002` 的 `b64_h16kv16_d128_bs32_l8192` |
| `copy_` 跨设备静默跑 CPU | 已在 `7e06b01` 修掉 2001/4005 两处；若 13 道里仍有类似写法，`verify.sh` 的 reference 自检会暴露 |

---

## 8. 上机后的建议顺序

1. `deploy.sh --check` —— 先确认 DTK/Python/torch/gfx936 四项，不对就别往下走
2. `deploy.sh` —— 部署
3. `verify.sh` —— 验收（含逐题 reference 真机自检，这一步最有价值）
4. `collect_baselines.sh 2xxx` —— 先采风险最低的 9 题，验证整条链路
5. 再铺 `3xxx` → `1xxx` → 剩下能采的
6. 把 §6 的 13 道单独归档：要么补配置，要么明确排除
