"""逐题静态检查 aiter tuner 配置在目标架构上是否齐备。

原理：
  适配器 -> 它 import 的 aiter 模块（含传递依赖）-> 这些模块里所有
  `AITER_TRITON_CONFIGS_PATH/...` 的读取点 -> 把 {dev}/{device_name} 等占位符
  替换成目标架构名，检查文件是否存在；并判断该读取点是否有 exists 保护。

结论分三类：
  OK        该题用到的配置在目标架构上都存在
  降级      缺配置但有 exists 保护 -> 用默认/回退，能跑，但基线可能偏慢
  会崩      缺配置且无保护 -> 上机直接 FileNotFoundError

用法：
  python3 check_configs.py                     # 默认目标 BW200（gfx936）
  python3 check_configs.py --dev BW200B        # 换架构
  python3 check_configs.py --verbose
"""
import argparse
import ast
import pathlib
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

REPO = pathlib.Path(__file__).resolve().parent


# 允许两种部署布局：仓库根下（本地）或 /root/dcudeploy 下（服务器）
def locate():
    """从脚本位置逐级向上找，兼容本地(.dcu_runs/)与服务器(/root/dcudeploy)布局。"""
    bases = [REPO, *REPO.parents]
    for base in bases:
        for shim, tasks in (
            (base / ".dcu_runs/deploy/aiter_shim", base / "benchmark/private"),
            (base / "aiter_shim", base / "dcu-kernel-bench/benchmark/private"),
            (base / "aiter_shim", base / "benchmark/private"),
        ):
            if shim.is_dir() and tasks.is_dir():
                return shim, tasks
    raise SystemExit(f"找不到 aiter_shim 与 benchmark/private（从 {REPO} 向上找过）")


SHIM, TASKS_DIR = locate()
CFG_REL = pathlib.Path("aiter/ops/triton/configs")


def aiter_mods(src):
    mods, fallback = set(), set()
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return mods
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith("aiter"):
            mods.add(node.module)
            for a in node.names:
                if a.name != "*":
                    fallback.add(f"{node.module}.{a.name}")
        elif isinstance(node, ast.Import):
            for a in node.names:
                if a.name.startswith("aiter"):
                    mods.add(a.name)
    for f in fallback:
        rel = f.replace(".", "/")
        if (SHIM / f"{rel}.py").is_file() or (SHIM / rel / "__init__.py").is_file():
            mods.add(f)
    return mods


def mod_file(mod):
    rel = mod.replace(".", "/")
    for c in (SHIM / f"{rel}.py", SHIM / rel / "__init__.py"):
        if c.is_file():
            return c
    return None


def closure(mods):
    out, queue = set(), list(mods)
    while queue:
        m = queue.pop()
        if m in out:
            continue
        f = mod_file(m)
        if f is None:
            continue
        out.add(m)
        for sub in aiter_mods(f.read_text(encoding="utf-8", errors="replace")):
            if sub not in out:
                queue.append(sub)
    return out


CFG = SHIM / CFG_REL
READ_RE = re.compile(r'AITER_TRITON_CONFIGS_PATH[^\n]*?"([^"]+)"|AITER_TRITON_CONFIGS_PATH\}?/([A-Za-z0-9_]+)')


def reading_points(mods):
    """-> [(module, lineno, template, guarded, literal_ok)]"""
    pts = []
    for m in sorted(mods):
        f = mod_file(m)
        if f is None:
            continue
        lines = f.read_text(encoding="utf-8", errors="replace").splitlines()
        for i, l in enumerate(lines):
            if "AITER_TRITON_CONFIGS_PATH" not in l:
                continue
            win = lines[i:i + 8]
            if not any(("open(" in w or "json.load" in w or "check_and_load" in w) for w in win):
                continue
            guarded = any(("os.path.exists" in w or "isfile" in w) for w in win)
            pts.append((m, i + 1, l.strip(), guarded))
    return pts


def template_paths(line, dev, dev_label):
    """从一行代码里尽量抽出会去读的配置相对路径（可能多个）。"""
    out = []
    # 形如 f"{AITER_TRITON_CONFIGS_PATH}/gemm/{dev}-GEMM-A16W16.json"
    for m in re.finditer(r'AITER_TRITON_CONFIGS_PATH\}?/([^"\']+)', line):
        t = m.group(1)
        t = t.split('"')[0].split("'")[0]
        t = t.replace("{dev}", dev).replace("{device_name}", dev)
        t = t.replace("{get_gpu_label()}", dev_label).replace("{get_gpu_label}", dev_label)
        if "{" in t:      # 还有未解析占位符（如 {N}/{K}）
            out.append((t, False))
        else:
            out.append((t, True))
    # 形如 os.path.join(AITER_TRITON_CONFIGS_PATH, "gemm/block_w8a8", json_file_name)
    for m in re.finditer(r'AITER_TRITON_CONFIGS_PATH"?\s*,\s*"([^"]+)"', line):
        out.append((m.group(1) + "/*", False))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dev", default="BW200", help="arch 名（gfx936->BW200）")
    ap.add_argument("--dev-label", default="gfx936", help="get_gpu_label() 的返回值")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()
    dev, dev_label = args.dev, args.dev_label

    print("=" * 82)
    print(f"aiter tuner 配置齐备性检查   目标架构 = {dev} / {dev_label}")
    print(f"垫片: {SHIM}")
    print(f"配置: {CFG}  (顶层 json {len(list(CFG.glob('*.json')))} 个, 共 {len(list(CFG.rglob('*.json')))} 个)")
    print("=" * 82)

    buckets = {"OK": [], "降级": [], "会崩": []}
    detail = {}
    for ad in sorted(TASKS_DIR.glob("*/aiter_impl.py")):
        task = ad.parent.name
        mods = closure(aiter_mods(ad.read_text(encoding="utf-8")))
        pts = reading_points(mods)
        status = "OK"
        notes = []
        for mod, ln, line, guarded in pts:
            for rel, literal in template_paths(line, dev, dev_label):
                if not literal:
                    notes.append(f"[?] {mod}:{ln} 路径含运行期变量，需上机确认 -> {rel}")
                    continue
                p = CFG / rel
                if p.exists():
                    continue
                if guarded:
                    status = "降级" if status == "OK" else status
                    notes.append(f"[降级] {mod}:{ln} 缺 {rel}（有保护）")
                else:
                    status = "会崩"
                    notes.append(f"[会崩] {mod}:{ln} 缺 {rel}（无保护）")
        buckets[status].append(task)
        detail[task] = notes

    for k in ("会崩", "降级", "OK"):
        v = buckets[k]
        print(f"\n### {k}（{len(v)} 道）")
        for t in v:
            print(f"   {t}")

    if args.verbose:
        print("\n" + "=" * 82)
        print("明细")
        print("=" * 82)
        for t, notes in sorted(detail.items()):
            if not notes:
                continue
            print(f"\n{t}")
            for n in notes:
                print(f"    {n}")
    else:
        print("\n（加 --verbose 看每题的具体缺哪个配置）")

    print()
    print(f"合计 {sum(len(v) for v in buckets.values())} 道："
          f"会崩 {len(buckets['会崩'])} / 降级 {len(buckets['降级'])} / OK {len(buckets['OK'])}")


if __name__ == "__main__":
    main()
