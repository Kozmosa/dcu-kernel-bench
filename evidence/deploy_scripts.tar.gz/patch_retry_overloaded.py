"""修复 provider 重试判定：把"上游过载"类错误当作可重试，避免烧掉候选预算。

背景：上游返回 "Our servers are currently overloaded. Please try again later."，
原 _is_retryable_llm_error 的关键字表里没有 overloaded，于是被判成不可重试，
直接抛到 workflow 层 -> 每次消耗一个候选 attempt -> 10 次预算被错误吃光。

用法：python3 patch_retry_overloaded.py <KernelWeaver 根目录>
"""
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
P = ROOT / "src" / "providers" / "openai_provider.py"
text = P.read_text(encoding="utf-8")

if "currently overloaded" in text:
    print("已打过补丁，跳过")
    sys.exit(0)

old = '''    retryable_tokens = (
        "http 429",'''
new = '''    retryable_tokens = (
        # 上游过载/限流：中转常回 "Our servers are currently overloaded" 或裸 429 文本，
        # 不含任何 http 状态码，必须显式列出，否则会被当成不可重试而烧掉候选预算。
        "currently overloaded",
        "overloaded",
        "please try again later",
        "rate limit",
        "too many requests",
        "http 429",'''
assert text.count(old) == 1, f"锚点计数异常: {text.count(old)}"
text = text.replace(old, new)

# 余额不足属于致命错误：不要重试，直接抛出并带上可读原因
old2 = '''def _is_retryable_llm_error(exc: RuntimeError) -> bool:
    message = str(exc).lower()'''
new2 = '''def _is_fatal_billing_error(exc: RuntimeError) -> bool:
    message = str(exc).lower()
    return "insufficient balance" in message or "insufficient_quota" in message or "billing" in message


def _is_retryable_llm_error(exc: RuntimeError) -> bool:
    if _is_fatal_billing_error(exc):
        return False
    message = str(exc).lower()'''
assert text.count(old2) == 1
text = text.replace(old2, new2)

P.write_text(text, encoding="utf-8", newline="\n")
import ast
ast.parse(P.read_text(encoding="utf-8"))
print("补丁已应用，语法 OK")
