"""给 TaskExperienceJournal 加"共享记忆池"支持。

改动三处：
1. 环境变量 KW_MEMORY_POOL 指定池文件时，所有分片进程共用这一份（而不是各自 output_dir 里的）；
2. retrieve() 前用共享锁重读，能看到别的进程刚写入的条目；
3. record() 用独占锁做"读-改-写"，并做去重，避免并发互相覆盖。

用法：python3 patch_memory_pool.py <KernelWeaver 根目录>
"""
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
P = ROOT / "src" / "core" / "long_term_memory.py"
text = P.read_text(encoding="utf-8")
if "KW_MEMORY_POOL" in text:
    print("已打过共享池补丁，跳过")
    sys.exit(0)

# --- 1) import
old_imp = """import json
import re
from pathlib import Path
from typing import Any"""
new_imp = """import json
import os
import re
from pathlib import Path
from typing import Any

try:  # POSIX 才有；Windows 上退化为无锁（服务端就是 Linux）
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None

POOL_ENV = "KW_MEMORY_POOL"
POOL_MAX_ENV = "KW_MEMORY_MAX"
DEDUPE_KEYS = ("task_name", "strategy", "outcome", "failure_type", "speedup", "lesson")


def _pool_override() -> Path | None:
    raw = os.environ.get(POOL_ENV)
    return Path(raw) if raw and raw.strip() else None


def _read_entries(path: Path | None) -> list[dict[str, Any]]:
    if path is None or not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return []
    return list(payload.get("entries") or [])


def _dedupe(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[tuple] = set()
    kept: list[dict[str, Any]] = []
    for entry in entries:
        key = tuple(str(entry.get(k)) for k in DEDUPE_KEYS)
        if key in seen:
            continue
        seen.add(key)
        kept.append(entry)
    return kept


def _write_entries(path: Path, entries: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps({"version": 1, "entries": entries}, indent=2, ensure_ascii=False),
                   encoding="utf-8")
    tmp.replace(path)"""
assert text.count(old_imp) == 1
text = text.replace(old_imp, new_imp)

# --- 2) __init__：池路径 + shared 标记 + 上限
old_init = """        self.path = Path(path) if path else None
        self.platform = dict(platform or {})
        self.top_k = max(1, int(top_k))
        self.entries: list[dict[str, Any]] = []
        if self.path and self.path.exists():
            try:
                payload = json.loads(self.path.read_text(encoding="utf-8"))
                self.entries = list(payload.get("entries") or [])
            except (OSError, ValueError, TypeError):
                self.entries = []"""
new_init = """        override = _pool_override()
        self.shared = override is not None
        self.path = override if self.shared else (Path(path) if path else None)
        self.platform = dict(platform or {})
        self.top_k = max(1, int(top_k))
        self.max_entries = int(os.environ.get(POOL_MAX_ENV, "512" if self.shared else "256"))
        self.entries: list[dict[str, Any]] = []
        if self.path and self.path.exists():
            self.entries = _read_entries(self.path)
        if self.shared and not self.entries and path:
            # 池还没有内容时，用本进程 output_dir 里已有的按题日志当种子
            seed = _read_entries(Path(path))
            if seed:
                self.entries = seed
                try:
                    self._locked_write(list(seed))
                except OSError:
                    pass"""
assert text.count(old_init) == 1
text = text.replace(old_init, new_init)

# --- 3) retrieve 前重读（池模式）
old_retr = """    def retrieve(self, task) -> list[dict[str, Any]]:
        if not self.entries:
            return []"""
new_retr = """    def _locked_write(self, entries: list[dict[str, Any]]) -> None:
        \"\"\"池模式下的读-改-写：独占锁 → 重读 → 合并去重 → 截断 → 原子替换。\"\"\"
        target = self.path
        if target is None:
            return
        target.parent.mkdir(parents=True, exist_ok=True)
        lock_path = target.with_suffix(target.suffix + ".lock")
        with open(lock_path, "a+") as lock_handle:
            if fcntl is not None:
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
            try:
                merged = _dedupe(_read_entries(target) + list(entries))
                merged = merged[-self.max_entries:]
                _write_entries(target, merged)
                self.entries = merged
            finally:
                if fcntl is not None:
                    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)

    def _reload_shared(self) -> None:
        \"\"\"池模式下每次检索前重读，确保看到别的进程刚写入的经验。\"\"\"
        if not self.shared or self.path is None:
            return
        lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        with open(lock_path, "a+") as lock_handle:
            if fcntl is not None:
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_SH)
            try:
                self.entries = _read_entries(self.path)
            finally:
                if fcntl is not None:
                    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)

    def retrieve(self, task) -> list[dict[str, Any]]:
        self._reload_shared()
        if not self.entries:
            return []"""
assert text.count(old_retr) == 1
text = text.replace(old_retr, new_retr)

# --- 4) record 走池写入
old_tail = """        self.entries = self.entries[-256:]
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps({"version": 1, "entries": self.entries}, indent=2, ensure_ascii=False), encoding="utf-8")"""
new_tail = """        if self.shared:
            self._locked_write(self.entries[-(len(self.entries)):])
        else:
            self.entries = self.entries[-256:]
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps({"version": 1, "entries": self.entries}, indent=2, ensure_ascii=False), encoding="utf-8")"""
assert text.count(old_tail) == 1
text = text.replace(old_tail, new_tail)

P.write_text(text, encoding="utf-8", newline="\n")
import ast
ast.parse(P.read_text(encoding="utf-8"))
print("记忆池补丁已应用，语法 OK ->", P)
