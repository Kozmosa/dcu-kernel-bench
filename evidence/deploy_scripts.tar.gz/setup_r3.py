"""建 r3：r2 的冻结快照 + 流式传输补丁 + 4 分片 manifest + 空输出目录。

用法：python3 setup_r3.py            （在 /root/dcudeploy 下执行）
产物：/root/dcudeploy/kw_full_b_d_20261101_r3
"""
import json
import os
import shutil
import sys
from pathlib import Path

BASE = Path("/root/dcudeploy")
SRC = BASE / "kw_full_b_d_20261101_r2"
DST = BASE / "kw_full_b_d_20261101_r3"
PROFILES = ["dcu_b_longterm", "dcu_d_combined"]
TRACKS = ["hip", "triton"]
SHARDS = 8

PATCH_ANCHOR_CALL = "                payload = self._sdk_http(\"POST\", url, request_body, self.config.timeout_seconds)"
PATCH_NEW_CALL = """                if _http_stream_enabled() and "messages" in request_body:
                    payload = self._sdk_stream_chat(request_body, self.config.timeout_seconds)
                else:
                    payload = self._sdk_http("POST", url, request_body, self.config.timeout_seconds)"""

PATCH_ANCHOR_SDKHTTP = """            if method == "GET":
                return client.get(url, cast_to=Dict[str, Any])
            return client.post(url, cast_to=Dict[str, Any], body=body)"""

PATCH_STREAM_METHOD = '''            if method == "GET":
                return client.get(url, cast_to=Dict[str, Any])
            return client.post(url, cast_to=Dict[str, Any], body=body)

    def _sdk_stream_chat(self, request_body: dict[str, Any], timeout: int) -> dict[str, Any]:
        """流式取 chat/completions，聚合成与非流式相同的 payload 形状。

        为什么必须流式：网关（Cloudflare）对**非流式**响应的源站读超时约 120s；
        kernel 任务上模型思考常超过这个窗口，于是每次请求都 524、重试再 524。
        SSE 一旦开始推送，网关不再按"无响应"计时，长请求才能正常跑完。
        """
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("SDK transport requires pip install 'kernelweaver[api]'") from exc
        body = dict(request_body)
        body.pop("stream", None)
        body.pop("stream_options", None)
        with OpenAI(api_key=self.config.api_key, base_url=self.config.base_url,
                    timeout=timeout, max_retries=0) as client:
            def _open(with_usage: bool):
                opts = {"include_usage": True} if with_usage else None
                kwargs = dict(body)
                kwargs["stream"] = True
                if opts:
                    kwargs["stream_options"] = opts
                return client.chat.completions.create(**kwargs)

            try:
                stream = _open(True)
            except Exception as exc:  # noqa: BLE001 - 少数中转不认 stream_options
                if "stream_options" in str(exc).lower() or "usage" in str(exc).lower():
                    stream = _open(False)
                else:
                    raise
            parts: list[str] = []
            usage: dict[str, Any] | None = None
            finish: str | None = None
            for chunk in stream:
                chunk_usage = getattr(chunk, "usage", None)
                if chunk_usage is not None:
                    try:
                        usage = chunk_usage.model_dump()
                    except AttributeError:
                        usage = dict(chunk_usage)
                choices = getattr(chunk, "choices", None) or []
                if not choices:
                    continue
                delta = getattr(choices[0], "delta", None)
                piece = getattr(delta, "content", None) if delta is not None else None
                if piece:
                    parts.append(piece)
                if getattr(choices[0], "finish_reason", None):
                    finish = choices[0].finish_reason
        text = "".join(parts)
        allowed = {k: v for k, v in body.items() if k in ("model", "temperature", "max_tokens")}
        payload: dict[str, Any] = {
            "object": "chat.completion",
            "created": int(time.time()),
            "model": str(allowed.get("model", self.config.model)),
            "choices": [{"index": 0, "finish_reason": finish or "stop",
                         "message": {"role": "assistant", "content": text}}],
        }
        if usage:
            payload["usage"] = usage
        return payload'''

PATCH_ANCHOR_HELPER = "def _is_retryable_llm_error(exc: RuntimeError) -> bool:"
PATCH_HELPER = '''def _http_stream_enabled() -> bool:
    """OPENAI_HTTP_STREAM=0 可关掉流式（回退到原来的非流式 JSON）。"""
    value = os.environ.get("OPENAI_HTTP_STREAM", "1")
    return str(value).strip().lower() not in ("0", "false", "no", "off")


def _is_retryable_llm_error(exc: RuntimeError) -> bool:'''


def die(msg: str) -> None:
    print("FAIL:", msg)
    sys.exit(1)


def patch_provider(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    if "_sdk_stream_chat" in text:
        print("  provider already patched, skip")
        return
    if "\nimport os" not in text and "\nimport os," not in text and "import os\n" not in text:
        die("provider 没有 import os，流式补丁需要它")
    if "\nimport time" not in text and "import time\n" not in text:
        die("provider 没有 import time")
    for anchor in (PATCH_ANCHOR_CALL, PATCH_ANCHOR_SDKHTTP, PATCH_ANCHOR_HELPER):
        if text.count(anchor) != 1:
            die("锚点不唯一/缺失: %r (count=%d)" % (anchor[:40], text.count(anchor)))
    text = text.replace(PATCH_ANCHOR_CALL, PATCH_NEW_CALL)
    text = text.replace(PATCH_ANCHOR_SDKHTTP, PATCH_STREAM_METHOD)
    text = text.replace(PATCH_ANCHOR_HELPER, PATCH_HELPER)
    path.write_text(text, encoding="utf-8", newline="\n")
    print("  patched:", path)


def main() -> None:
    if DST.exists():
        shutil.rmtree(DST)
    print("copying snapshot ...")
    shutil.copytree(SRC, DST, symlinks=True,
                    ignore=shutil.ignore_patterns("groups", "logs", "status.json", "reports"))
    (DST / "groups").mkdir(exist_ok=True)
    (DST / "logs").mkdir(exist_ok=True)
    (DST / "reports").mkdir(exist_ok=True)


    import yaml
    print("patching provider (streaming for Clash-path) ...")
    patch_provider(DST / "KernelWeaver" / "src" / "providers" / "openai_provider.py")

    print("sharding manifests ...")
    shards_info = {}
    for track in TRACKS:
        man = yaml.safe_load((DST / f"manifest_{track}.yaml").read_text(encoding="utf-8"))
        tasks = man["tasks"]
        n = len(tasks)
        base, extra = divmod(n, SHARDS)
        shards_info[track] = []
        start = 0
        for k in range(SHARDS):
            size = base + (1 if k < extra else 0)
            part = tasks[start:start + size]
            start += size
            if not part:
                continue
            shard_man = {"name": f"{man.get('name', track)}_s{k + 1}",
                         "backend": man.get("backend", tasks[0].get("backend")),
                         "tasks": part}
            path = DST / f"manifest_{track}_s{k + 1}.yaml"
            with path.open("w", encoding="utf-8", newline="\n") as fh:
                yaml.safe_dump(shard_man, fh, sort_keys=False, allow_unicode=True)
            shards_info[track].append({"shard": k + 1, "manifest": path.name,
                                       "tasks": [t["alias"] for t in part]})
            print("  %-6s shard%d: %d tasks" % (track, k + 1, len(part)))

    print("creating output dirs ...")
    for profile in PROFILES:
        for track in TRACKS:
            for k in range(1, SHARDS + 1):
                (DST / "groups" / profile / track / f"shard{k}").mkdir(parents=True, exist_ok=True)

    plan = {
        "root": str(DST),
        "profiles": PROFILES,
        "tracks": TRACKS,
        "shards": SHARDS,
        "streaming_fix": "provider uses SSE (stream=true) to avoid HTTP 524",
        "concurrency": len(PROFILES) * len(TRACKS) * SHARDS,
        "max_attempts": 10,
        "shard_layout": shards_info,
        "note": ("分片是连续切分：每组每轨 66 题切成 4 段，段内顺序不变、段间并行。"
                 "长期记忆链因此变成 4 段独立链（原 r2 设计是每组一条 66 题链）。"),
    }
    (DST / "plan_r3.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n",
                                      encoding="utf-8", newline="\n")
    print("done ->", DST)


if __name__ == "__main__":
    main()
