#!/usr/bin/env bash
# verify.sh —— 上机后的验收：配置齐备性 → 镜像一致性 → 全部测试 → reference 自检
# 用法： bash verify.sh
# 不能开 set -u：/opt/dtk/env.sh 引用未定义变量
set -o pipefail

ROOT="${ROOT:-/root/dcudeploy}"
# shellcheck disable=SC1091
source "$ROOT/env.sh"
REPO="$ROOT/dcu-kernel-bench"
cd "$REPO"

DRED=$'\033[31m'; DGRN=$'\033[32m'; DYLW=$'\033[33m'; DOFF=$'\033[0m'
ok(){ printf '  %s[ok]%s   %s\n' "$DGRN" "$DOFF" "$*"; }
bad(){ printf '  %s[FAIL]%s %s\n' "$DRED" "$DOFF" "$*"; }
wrn(){ printf '  %s[warn]%s %s\n' "$DYLW" "$DOFF" "$*"; }
hr(){ printf '\n=== %s ===\n' "$*"; }

FAIL=0

# 辅助脚本位置：deploy.sh 会复制到 $ROOT，也兼容只在 upload/ 的情况
HELPERS="$ROOT"
[ -f "$HELPERS/check_configs.py" ] || HELPERS="$ROOT/upload"
[ -f "$HELPERS/check_configs.py" ] || { bad "找不到 check_configs.py（deploy.sh 是否跑过？）"; exit 1; }

# ------------------------------------------------------------------ 1
hr "1. 镜像一致性（tasks <-> kernelbench_compat 逐字节）"
if python3 benchmark/tools/dcukb.py mirror --all --check 2>&1 | tail -2; then
  ok "镜像检查通过"
else
  bad "镜像不一致"; FAIL=1
fi

# ------------------------------------------------------------------ 2
hr "2. aiter tuner 配置齐备性（目标架构 BW200/gfx936）"
CFG_REPORT=$(mktemp)
if python3 "$HELPERS/check_configs.py" --verbose >"$CFG_REPORT" 2>&1; then
  tail -4 "$CFG_REPORT" | sed 's/^/  /'
  # 注意：报告里的标记行有缩进，不能锚定行首
  CRASH=$(grep -c '\[会崩\]' "$CFG_REPORT" 2>/dev/null || true)
  if [ "${CRASH:-0}" -gt 0 ] 2>/dev/null; then
    wrn "有 $CRASH 处静态命中缺配置且无保护 —— 这些题的基线可能采不了"
    wrn "明细见 $CFG_REPORT ；仅代表静态命中，实际是否触发取决于调用路径，以采集结果为准"
    cp "$CFG_REPORT" "$ROOT/config_report.txt"
  else
    ok "所有题用到的 tuner 配置都在"
  fi
else
  bad "配置检查脚本执行失败"; sed 's/^/  /' "$CFG_REPORT" | tail -5; FAIL=1
fi

# ------------------------------------------------------------------ 3
hr "3. reference 真机自检（逐题跑最小的 hidden case）"
inf=""
SELF_OK=0; SELF_SKIP=0; SELF_BAD=0
for d in benchmark/tasks/*/; do
  t=$(basename "$d")
  [ -f "benchmark/private/$t/hidden_cases.json" ] || continue
  # 用 hidden case（小、面向正确性）；超过元素上限的跳过，避免 verify 阶段 OOM/跑几小时
  RES=$(python3 - "$t" <<'PY' 2>&1
import importlib.util, json, sys
from pathlib import Path
sys.path.insert(0, "benchmark/evaluator")
import torch
from audit_model_class import case_init_kwargs, case_inputs, move_inputs_to_device

MAX_ELEMS = 1 << 24          # 约 1600 万元素，够验证 GPU 路径且不会 OOM
t = sys.argv[1]
pr = Path("benchmark/private")/t
td = Path("benchmark/tasks")/t
spec = importlib.util.spec_from_file_location("ref_"+t, td/"reference.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
raw = json.loads((pr/"hidden_cases.json").read_text())
cases = raw if isinstance(raw, list) else raw.get("cases", raw.get("hidden_cases", []))
if isinstance(cases, dict):
    cases = [v for v in cases.values() if isinstance(v, dict)]
cases = [c for c in cases if isinstance(c, dict)]
if not cases:
    print("SKIP 无 hidden case"); raise SystemExit(0)

for c in cases:
    try:
        kw = case_init_kwargs(td, m, c)
        model = m.Model(**kw).eval()
        ins = move_inputs_to_device(case_inputs(m, c), "cuda")
        n = sum(x.numel() for x in ins if torch.is_tensor(x))
        if n > MAX_ELEMS:
            continue
        with torch.no_grad():
            out = model(*ins)
        assert torch.is_tensor(out), "forward 未返回单个张量"
        assert bool(torch.isfinite(out).all()), "输出含非有限值"
        assert out.device.type == "cuda", f"输出不在 GPU 上（{out.device}）—— device 敏感写法？"
        print(f"OK {c.get('name','?')} elems={n} dev={out.device}")
        raise SystemExit(0)
    except SystemExit:
        raise
    except Exception as e:
        print(f"FAIL {c.get('name','?')} {type(e).__name__}: {str(e)[:120]}")
        raise SystemExit(1)
print("SKIP 所有 case 都超过元素上限")
PY
)
  case "$RES" in
    OK*)   SELF_OK=$((SELF_OK+1)) ;;
    SKIP*) SELF_SKIP=$((SELF_SKIP+1)) ;;
    *)     SELF_BAD=$((SELF_BAD+1)); wrn "$t: $RES" ;;
  esac
done
ok "reference 真机自检：通过 $SELF_OK / 跳过 $SELF_SKIP / 失败 $SELF_BAD"
[ "$SELF_BAD" -gt 0 ] && wrn "有 $SELF_BAD 道题的 reference 在 GPU 上跑不通（上面有明细），这些题采基线会失败"

# ------------------------------------------------------------------ 4
hr "4. 测试套件"
if python3 -c 'import pytest' 2>/dev/null; then
  if python3 -m pytest tests/ -q 2>&1 | tail -8; then
    ok "pytest 通过"
  else
    bad "pytest 有失败"; FAIL=1
  fi
else
  wrn "无 pytest，改用自带驱动"
  # run_all_tests.py 用 Path(__file__).parents[1]/"tests" 定位测试目录，
  # 所以必须放在 $REPO/.dcu_runs/ 下，直接从 $ROOT 跑会找不到模块（已踩过）
  DRIVER="$REPO/.dcu_runs/run_all_tests.py"
  if [ ! -f "$DRIVER" ]; then
    mkdir -p "$REPO/.dcu_runs"
    cp -f "$HELPERS/run_all_tests.py" "$DRIVER" 2>/dev/null || true
  fi
  if [ -f "$DRIVER" ]; then
    if python3 "$DRIVER" 2>&1 | tail -6; then ok "驱动通过"; else bad "驱动有失败"; FAIL=1; fi
  else
    bad "找不到 run_all_tests.py 驱动"; FAIL=1
  fi
fi

# ------------------------------------------------------------------ 5
hr "5. GPU 环境记录（写进基线，供可比性核对）"
python3 - <<'PY' | sed 's/^/  /'
import torch, os
print(f"torch      : {torch.__version__}")
try:
    p = torch.cuda.get_device_properties(0)
    print(f"device     : {p.name}")
    print(f"gcnArchName: {getattr(p,'gcnArchName','?')}")
    print(f"显存       : {p.total_memory/1024**3:.1f} GB")
except Exception as e:
    print("device     : 读取失败", e)
try:
    import triton; print(f"triton     : {triton.__version__}")
except Exception as e:
    print("triton     : ", e)
print(f"CPU 核     : {os.cpu_count()}")
PY

hr "结果"
[ "$FAIL" = "0" ] && ok "验收通过，可以开始采基线（collect_baselines.sh）" || bad "有 $FAIL 项未通过"
exit "$FAIL"
