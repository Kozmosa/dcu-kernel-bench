#!/bin/bash
# 三组全指标：Compile/Correct/Success@K/Fast1@K/Geo/Med/Mean/Best/FCM/RG + 在线/离线/真解
cd /root/dcudeploy/kw_full_b_d_20261101_r3 || exit 1
python3 - <<'PY'
import glob, json, math, re, statistics
from pathlib import Path

ROOT = Path("/root/dcudeploy/kw_full_b_d_20261101_r3")

def key(s):
    m = re.search(r"(\d{4})", str(s or ""))
    return m.group(1) if m else str(s)

def load(run_dirs, off_dirs):
    on, off = {}, {}
    for d in run_dirs:
        for f in glob.glob(str(ROOT / d / "*" / "run.json")):
            data = json.load(open(f))
            nodes = [(k, v) for k, v in data.get("nodes", {}).items() if k not in ("root", "phase2_root")]
            nodes.sort(key=lambda kv: (kv[1].get("depth", 0), kv[0]))
            seq = []
            for nid, n in nodes:
                seq.append((bool(n.get("correct")), n.get("speedup") or 0, bool(n.get("compile_ok"))))
            on[key(data.get("task_name") or f.split("/")[-2])] = seq
    for d in off_dirs:
        for f in glob.glob(str(ROOT / d / "offline_audit" / "*.json")):
            data = json.load(open(f))
            off[key(data.get("task"))] = (bool(data.get("static_audit_passed")), data.get("correctness_passed"))
    return on, off

def stats(seq, k):
    """(success@k, fast1@k)"""
    head = seq[:k]
    ok = any(c for c, _, _ in head)
    fast = any(c and s > 1 for c, s, _ in head)
    return ok, fast

def report(label, run_dirs, off_dirs):
    on, off = load(run_dirs, off_dirs)
    tasks = sorted(on)
    n = len(tasks)
    compile_ok = sum(1 for t in tasks if any(cmp for _, _, cmp in on[t]))
    correct = sum(1 for t in tasks if any(c for c, _, _ in on[t]))
    res = {}
    for k in (1, 5, 10):
        s = sum(1 for t in tasks if stats(on[t], k)[0])
        f = sum(1 for t in tasks if stats(on[t], k)[1])
        res[k] = (s, f)
    best = [max([s for _, s, _ in on[t]] or [0]) for t in tasks if any(c for c, _, _ in on[t])]
    best = [b for b in best if b]
    gm = math.exp(sum(math.log(b) for b in best) / len(best)) if best else 0
    fcm = []
    rg = []
    for t in tasks:
        idx = next((i for i, (c, _, _) in enumerate(on[t], start=1) if c), None)
        if not idx:
            continue
        fcm.append(idx)
        fsp = on[t][idx - 1][1]
        bsp = max(s for _, s, _ in on[t])
        if fsp and bsp and fsp > 0:
            rg.append(bsp / fsp)
    offline = sum(1 for t in tasks if off.get(key(t), (False, None))[1] is True)
    static_fail = sum(1 for t in tasks if off.get(key(t), (True, None))[0] is False)
    numeric_fail = sum(1 for t in tasks if off.get(key(t), (True, None))[0] and off.get(key(t), (True, None))[1] is False)
    strict = sum(1 for t in tasks if any(c for c, _, _ in on[t]) and off.get(key(t), (False, None))[1] is True)
    print(f"{label}|{n}|{compile_ok}|{correct}|{res[1][0]}|{res[5][0]}|{res[10][0]}|{res[1][1]}|{res[5][1]}|{res[10][1]}|"
          f"{gm:.2f}|{statistics.median(best) if best else 0:.2f}|{statistics.mean(best) if best else 0:.1f}|{max(best) if best else 0:.1f}|"
          f"{statistics.median(fcm) if fcm else 0:.1f}|{statistics.median(rg) if rg else 0:.2f}|"
          f"{offline}|{static_fail}|{numeric_fail}|{strict}")

print("组|题数|Compile|Correct|S@1|S@5|S@10|F1@1|F1@5|F1@10|Geo|Med|Mean|Best|FCM|RG|离线通过|静态违规|数值错|真解")
report("框架v2-HIP", ["final2/hip"], ["final2/hip"])
report("框架v2-Triton", ["final2/triton", "subset_view"], ["final2/triton", "subset_view"])
report("纯API-HIP", ["pure_norm/hip"], ["pure_norm/hip"])
report("纯API-Triton", ["pure_norm/triton"], ["pure_norm/triton"])
report("API+Wiki-HIP", ["pure_wiki_norm/hip"], ["pure_wiki_norm/hip"])
report("API+Wiki-Triton", ["pure_wiki_norm/triton"], ["pure_wiki_norm/triton"])
PY
