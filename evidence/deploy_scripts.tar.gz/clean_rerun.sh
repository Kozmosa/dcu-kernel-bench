#!/bin/bash
# 清理受污染的结果并从头重跑（provider 已同时具备流式 + 过载重试）。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$ROOT" || exit 1

echo "== 停掉当前 run =="
pkill -TERM -f supervise_r3.py 2>/dev/null
sleep 5
pkill -9 -f run-kernelbench-batch 2>/dev/null
sleep 2

echo "== 备份受污染的 33 题（留档，不参与统计）=="
mkdir -p reports_prev
tar czf reports_prev/contaminated_partial_$(date +%H%M).tar.gz groups pools 2>/dev/null
ls -lh reports_prev/contaminated_partial_*.tar.gz | tail -1

echo "== 清空 =="
rm -rf groups pools status_resume.json
mkdir -p groups pools logs

echo "== 启动（9 流，流式 + 重试）=="
export OPENAI_HTTP_STREAM=1
export OPENAI_MAX_RETRIES=6
export OPENAI_RETRY_BACKOFF_SECONDS=3
export R3_MAX_CONCURRENT=9
export R3_MEM_GUARD_GB=25
setsid nohup python3 -u supervise_r3.py --profiles d > logs/supervisor_clean.out 2>&1 < /dev/null &
sleep 15
echo "sup=$(ps -eo args | grep -c '[s]upervise_r3.py') batch=$(ps -eo args | grep -c '[r]un-kernelbench-batch')"
head -5 logs/supervisor_clean.out
