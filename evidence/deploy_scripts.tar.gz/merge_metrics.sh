#!/bin/bash
# 合并主跑 + 23 题验证集，输出 Triton/HIP/总分口径指标。
cd /root/dcudeploy/kw_full_b_d_20261101_r3 || exit 1
python3 - <<'PY'
import json, glob, math, re, statistics, pathlib

ROOT = pathlib.Path("/root/dcudeploy/kw_full_b_d_20261101_r3")

def key(s):
    m = re.search(r"(\d{4})", str(s or ""))
    return m.group(1) if m else str(s)

def load_run(dirs):
    """task -> (online_correct, best_speedup)"""
    out = {}
    for d in dirs:
        for f in glob.glob(str(ROOT / d / "*" / "run.json")):
            data = json.load(open(f))
            nodes = {k: v for k, v in data.get("nodes", {}).items() if k not in ("root", "phase2_root")}
            best = max([v.get("speedup") or 0 for v in nodes.values()] or [0])
            out[key(data.get("task_name") or f.split("/")[-2])] = (any(v.get("correct") for v in nodes.values()), best)
    return out

def load_off(dirs):
    out = {}
    for d in dirs:
        for f in glob.glob(str(ROOT / d / "offline_audit" / "*.json")):
            data = json.load(open(f))
            out[key(data.get("task"))] = (bool(data.get("static_audit_passed")), data.get("correctness_passed") is True)
    return out

# Triton: 主跑 66 题，其中 23 题用验证集结果覆盖
main_on = load_run(["final2/triton"])
main_off = load_off(["final2/triton"])
sub_on = load_run(["subset_view"])
sub_off = load_off(["subset_view"])
tri_on = dict(main_on); tri_off = dict(main_off)
tri_on.update(sub_on); tri_off.update(sub_off)

hip_on = load_run(["final2/hip"])
hip_off = load_off(["final2/hip"])

def summarize(name, on, off):
    tasks = sorted(set(on) & set(off))
    online = sum(1 for t in tasks if on[t][0])
    offline = sum(1 for t in tasks if off[t][1])
    strict = sum(1 for t in tasks if on[t][0] and off[t][1])
    static_ok = sum(1 for t in tasks if off[t][0])
    sp = [on[t][1] for t in tasks if on[t][0] and on[t][1]]
    gm = math.exp(sum(math.log(x) for x in sp) / len(sp)) if sp else 0
    print("%-8s 题数 %2d | 在线正确 %2d | 静态审计通过 %2d | 离线通过 %2d | 在线∩离线 %2d | Geomean %.2fx Median %.2fx" % (
        name, len(tasks), online, static_ok, offline, strict, gm, statistics.median(sp) if sp else 0))
    return len(tasks), online, offline, strict

print("== 合并后（Triton 的 23 题采用验证集结果）==")
h = summarize("HIP", hip_on, hip_off)
t = summarize("Triton", tri_on, tri_off)
print("%-8s 题数 %2d | 在线正确 %2d | 离线通过 %2d | 在线∩离线 %2d" % (
    "合计", h[0] + t[0], h[1] + t[1], h[2] + t[2], h[3] + t[3]))
print()
print("对照：主跑时 Triton 离线通过 45/66；验证集 23 题中 7 题由未通过转为通过。")
PY
