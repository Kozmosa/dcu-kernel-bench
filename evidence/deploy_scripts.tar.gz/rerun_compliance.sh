#!/bin/bash
# 部署"合规"改动并重跑 d 组（全新记忆池）。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$ROOT" || exit 1

echo "=== 1. 语料审计 ==="
python3 - <<'PY'
import sys
sys.path.insert(0, "/root/dcudeploy/kw_full_b_d_20261101_r3/KernelWeaver")
from pathlib import Path
from src.knowledge.public_wiki import audit_public_corpus, PublicKernelWiki
p = Path("KernelWeaver/knowledge/kernelwiki_dcu")
print("sha256:", audit_public_corpus(p)["sha256"][:16])
wiki = PublicKernelWiki(p, target_arch="gfx936")

class T:
    def __init__(self, backend, code):
        self.backend = backend; self.reference_code = code
        self.name = "t"; self.description = ""; self.tags = []

for backend, code in (("cuda", "torch.matmul(a,b)"), ("triton", "torch.softmax(x,-1)")):
    ids = [pg.get("id") for pg in wiki.retrieve(T(backend, code))]
    print(backend, "检索 ->", ids, "含合规页:", "public-compliance" in ids)
PY

echo "=== 2. 备份旧报告 ==="
mkdir -p reports_prev && cp -f reports/*.md reports/*.csv reports_prev/ 2>/dev/null
ls reports_prev | wc -l

echo "=== 3. 清空结果与记忆（重新测量） ==="
pkill -9 -f supervise_r3.py 2>/dev/null
pkill -9 -f run-kernelbench-batch 2>/dev/null
sleep 2
rm -rf groups pools status_resume.json
mkdir -p groups pools logs

echo "=== 4. 启动（9 条流，双轨轮转） ==="
export OPENAI_HTTP_STREAM=1 R3_MAX_CONCURRENT=9 R3_MEM_GUARD_GB=25
setsid nohup python3 -u supervise_r3.py --profiles d > logs/supervisor_compliance.out 2>&1 < /dev/null &
sleep 12
echo "batch=$(ps -eo args | grep -c '[r]un-kernelbench-batch')"
head -6 logs/supervisor_compliance.out
