#!/usr/bin/env bash
# One compact status line for the running batch, for the local monitor loop.
set +u
RUN_ROOT=${1:-/root/dcudeploy/runs/dcukb_en_1019_1027}
source /root/dcudeploy/llm.env

procs=$(ps -ef | grep -c '[p]yramidkernel.cli run-kernelbench-batch')
dirs=$(find "$RUN_ROOT" -maxdepth 2 -mindepth 2 -type d 2>/dev/null | wc -l)
done_n=$(find "$RUN_ROOT" -maxdepth 3 -name run.json 2>/dev/null | wc -l)
api=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 -x "$HTTPS_PROXY" \
          "$OPENAI_BASE_URL/models" -H "Authorization: Bearer $OPENAI_API_KEY" 2>/dev/null)
echo "ts=$(date '+%m-%d %H:%M:%S') procs=$procs taskdirs=$dirs runjson=$done_n api=$api"
