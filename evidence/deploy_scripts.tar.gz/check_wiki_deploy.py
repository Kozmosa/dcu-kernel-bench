"""部署后校验：语料审计 + 检索是否仍带合规页。"""
import sys

sys.path.insert(0, "/root/dcudeploy/kw_full_b_d_20261101_r3/KernelWeaver")
from pathlib import Path  # noqa: E402
from src.knowledge.public_wiki import PublicKernelWiki, audit_public_corpus  # noqa: E402

p = Path("/root/dcudeploy/kw_full_b_d_20261101_r3/KernelWeaver/knowledge/kernelwiki_dcu")
print("部署后 sha256:", audit_public_corpus(p)["sha256"][:16])
wiki = PublicKernelWiki(p, target_arch="gfx936")


class T:
    def __init__(self, backend, code):
        self.backend = backend
        self.reference_code = code
        self.name = "t"
        self.description = ""
        self.tags = []


for backend, code in (("cuda", "torch.matmul(a,b)"), ("triton", "torch.softmax(x,-1)")):
    ids = [x.get("id") for x in wiki.retrieve(T(backend, code))]
    print(backend, "->", ids, "含合规页:", "public-compliance" in ids)
