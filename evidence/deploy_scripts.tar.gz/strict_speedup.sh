#!/bin/bash
# 只在"真解"（在线正确 ∩ 离线合规）上算加速比指标，三组对照。
cd /root/dcudeploy/kw_full_b_d_20261101_r3 || exit 1
python3 - <<'PY'
import glob, json, math, re, statistics
from pathlib import Path

ROOT = Path("/root/dcudeploy/kw_full_b_d_20261101_r3")

def key(s):
    m = re.search(r"(\d{4})", str(s or ""))
    return m.group(1) if m else str(s)

def load(run_dirs, off_dirs):
    on, off = {}, {}
    for d in run_dirs:
        for f in glob.glob(str(ROOT / d / "*" / "run.json")):
            data = json.load(open(f))
            nodes = {k: v for k, v in data.get("nodes", {}).items() if k not in ("root", "phase2_root")}
            best = max([v.get("speedup") or 0 for v in nodes.values()] or [0])
            on[key(data.get("task_name") or f.split("/")[-2])] = (any(v.get("correct") for v in nodes.values()), best)
    for d in off_dirs:
        for f in glob.glob(str(ROOT / d / "offline_audit" / "*.json")):
            data = json.load(open(f))
            off[key(data.get("task"))] = data.get("correctness_passed") is True
    return on, off

def report(label, run_dirs, off_dirs):
    on, off = load(run_dirs, off_dirs)
    tasks = sorted(set(on) & set(off))
    online_solved = [t for t in tasks if on[t][0]]
    strict = [t for t in tasks if on[t][0] and off[t]]
    def agg(ids):
        sp = [on[t][1] for t in ids if on[t][1]]
        if not sp:
            return (0, 0, 0, 0)
        return (math.exp(sum(math.log(x) for x in sp) / len(sp)), statistics.median(sp),
                statistics.mean(sp), max(sp))
    a_all = agg(online_solved)
    a_strict = agg(strict)
    print("%-18s 在线解 %2d: Geo %6.2fx Med %6.2fx Mean %6.1fx Best %7.1fx" % (label + "(在线集)", len(online_solved), *a_all))
    print("%-18s 真解   %2d: Geo %6.2fx Med %6.2fx Mean %6.1fx Best %7.1fx" % ("", len(strict), *a_strict))

print("== 纯 API ==")
report("HIP", ["pure_norm/hip"], ["pure_norm/hip"])
report("Triton", ["pure_norm/triton"], ["pure_norm/triton"])
print("== 纯 API + Wiki ==")
report("HIP", ["pure_wiki_norm/hip"], ["pure_wiki_norm/hip"])
report("Triton", ["pure_wiki_norm/triton"], ["pure_wiki_norm/triton"])
print("== 框架 v2 ==")
report("HIP", ["final2/hip"], ["final2/hip"])
report("Triton(合并)", ["final2/triton", "subset_view"], ["final2/triton", "subset_view"])
PY
