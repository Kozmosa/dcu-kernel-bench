#!/usr/bin/env bash
# 并行运行进度总览
set -o pipefail
set +u
RUN_ROOT="${RUN_ROOT:-/root/dcudeploy/runs/dcukb_par}"
ROOT=/root/dcudeploy
BENCH=$ROOT/dcu-kernel-bench

echo "=== $(date '+%F %T')   $RUN_ROOT ==="
echo
printf '  %-8s %-7s %-7s %-10s %s\n' "shard" "完成" "进程" "日志大小" "最近一行日志"
for d in "$RUN_ROOT"/par_s*; do
  [ -d "$d" ] || continue
  s=$(basename "$d")
  n=$(ls -d "$d"/*/ 2>/dev/null | wc -l)
  pid=$(pgrep -f "manifest $RUN_ROOT/shard_${s#par_s}.yaml" | head -1)
  log="$RUN_ROOT/$s.log"
  sz=$([ -f "$log" ] && du -h "$log" | cut -f1 || echo "-")
  last=$([ -f "$log" ] && grep -vE 'rocm_smi|LiteLLM' "$log" | tail -1 | cut -c1-60 || echo "-")
  printf '  %-8s %-7s %-7s %-10s %s\n' "$s" "$n" "${pid:-已退出}" "$sz" "$last"
done

echo
TOTAL=$(ls -d "$RUN_ROOT"/par_s*/*/ 2>/dev/null | wc -l)
echo "  合计完成: $TOTAL 题"

if [ -f "$BENCH/benchmark/kernelbench_compat/manifest_dcukb.yaml" ]; then
  echo
  echo "  已完成题目:"
  for d in "$RUN_ROOT"/par_s*/*/; do
    [ -d "$d" ] || continue
    b=$(basename "$d")
    if [ -f "$d/run.json" ]; then
      r=$(python3 -c "
import json,sys
try:
    d=json.load(open('$d/run.json'))
    n=d['nodes'].get(d.get('best_node_id') or '',{})
    print(f\"correct={n.get('correct')} speedup={n.get('speedup') if isinstance(n.get('speedup'),(int,float)) else '-'}\")
except Exception as e:
    print('(解析失败)')
" 2>/dev/null)
      echo "    $b  $r"
    else
      echo "    $b  (无 run.json)"
    fi
  done
fi
