import glob
import json
import os
import statistics
import sys

root = sys.argv[1] if len(sys.argv) > 1 else "/root/dcudeploy/runs/dcukb_en_1019_1027"
rjs = sorted(glob.glob(os.path.join(root, "par_s*", "*", "run.json")))
manifest = "/root/dcudeploy/dcukb_bench/benchmark/kernelbench_compat/manifest_dcukb.yaml"
total_expected = 66

rows = []
for rj in rjs:
    d = json.load(open(rj, encoding="utf-8"))
    nodes = d.get("nodes") or {}
    nl = list(nodes.values()) if isinstance(nodes, dict) else nodes
    best = next((n for n in nl if n.get("node_id") == d.get("best_node_id") or n.get("id") == d.get("best_node_id")), None)
    stats = d.get("stats") or {}
    rows.append(
        dict(
            task=os.path.basename(os.path.dirname(rj)).rsplit("_l", 1)[0],
            nodes=len(nl),
            attempts=stats.get("attempt_count", 0),
            correct=bool(best and best.get("correct")),
            compile_ok=bool(best and best.get("compile_ok")),
            speedup=(best or {}).get("speedup"),
            best_id=d.get("best_node_id"),
            transient=stats.get("provider_transient_error_count", 0),
            stages=(stats.get("failure_stage_counts") or {}),
        )
    )

done = len(rows)
correct = [r for r in rows if r["correct"]]
sp = [r["speedup"] for r in correct if isinstance(r["speedup"], float)]
root_only = [r for r in rows if r["best_id"] in ("root", "phase2_root") or r["best_id"] is None]
stages = {}
for r in rows:
    for k, v in r["stages"].items():
        stages[k] = stages.get(k, 0) + v

print(f"completed {done}/{total_expected}   correct {len(correct)}   best==root {len(root_only)}")
if sp:
    sp_sorted = sorted(sp)
    print(f"speedup  median {statistics.median(sp_sorted):.2f}x   max {max(sp_sorted):.2f}x   min {min(sp_sorted):.2f}x")
print(f"failure stages across nodes: {dict(sorted(stages.items(), key=lambda kv: -kv[1]))}")
print(f"provider transient errors: {sum(r['transient'] for r in rows)}")
bad = [r for r in rows if not r["correct"]]
if bad:
    print("not-correct tasks:")
    for r in bad:
        print(f"   {r['task']:<36} nodes={r['nodes']:<3} best={r['best_id']:<8} compile_ok={r['compile_ok']} stages={r['stages']}")
print("top speedups:")
for r in sorted(correct, key=lambda r: -(r["speedup"] or 0))[:6]:
    print(f"   {r['task']:<36} {r['speedup']:.2f}x")
