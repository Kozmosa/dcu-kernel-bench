#!/bin/bash
# 关机前清理：删 core dump（几十 GB 的崩溃转储）+ 冗余副本，保留结果与报告。
set -u
R=/root/dcudeploy
echo "== 清理前: $(du -sh $R 2>/dev/null | cut -f1) =="

# 1) 所有 core dump（>10MB）
find /root -maxdepth 4 -type f -name 'core.*' -size +10M -delete 2>/dev/null
echo "删除 core 后: $(du -sh $R 2>/dev/null | cut -f1)"

# 2) 只保留最新一份合并产物：final2（含 offline_audit），删掉旧的 final/（同一批数据的拷贝）
rm -rf "$R/kw_full_b_d_20261101_r3/final"
# 3) 删掉 pure_bench 的原始目录（内容已在 pure_norm / pure_wiki_norm 里规范化保留）
rm -rf "$R/kw_full_b_d_20261101_r3/pure"
rm -rf "$R/kw_full_b_d_20261101_r3/pure_wiki"
# 4) 删掉 23 题验证集的中间产物（已合并进 subset_view 与审计缓存）
rm -rf "$R/kw_full_b_d_20261101_r3/subset/triton/s"[2-8]
rm -rf "$R/kw_full_b_d_20261101_r3/pure_wiki_norm/triton/offline_audit.tmp" 2>/dev/null
# 5) 缓存与旧备份 tar
rm -rf /root/.cache
rm -f "$R"/*.tar /root/dcudeploy.tar

echo "== 清理后: $(du -sh $R 2>/dev/null | cut -f1) =="
echo "== 剩余大目录 =="
du -sh "$R"/* 2>/dev/null | sort -h | tail -6
echo "== 关键结果是否完好 =="
for f in "$R/kw_full_b_d_20261101_r3/reports"; do ls "$f"/*.md 2>/dev/null | wc -l; done
ls "$R/kw_full_b_d_20261101_r3/final2/hip/offline_audit.json" \
   "$R/kw_full_b_d_20261101_r3/final2/triton/offline_audit.json" \
   "$R/kw_full_b_d_20261101_r3/pure_norm/hip/offline_audit.json" \
   "$R/kw_full_b_d_20261101_r3/pure_norm/triton/offline_audit.json" \
   "$R/kw_full_b_d_20261101_r3/pure_wiki_norm/hip/offline_audit.json" \
   "$R/kw_full_b_d_20261101_r3/pure_wiki_norm/triton/offline_audit.json" 2>/dev/null | wc -l
df -h / | tail -1
