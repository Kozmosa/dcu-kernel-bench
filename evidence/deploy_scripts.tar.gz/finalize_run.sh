#!/bin/bash
# 收尾：对 r3 的 132 个产做离线终审（静态审计 → 隐藏 case → 性能），再出对比表。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$ROOT" || exit 1
mkdir -p reports

for t in hip triton; do
  echo "=== 终审 $t $(date +%H:%M:%S)"
  timeout 21600 python3 -u metric_tools/audit_batch.py \
      --run-root "final/$t" --manifest "manifest_$t.yaml" \
      --impl aiter --timeout 1800 > "reports/audit_$t.log" 2>&1
  echo "  exit=$? $(date +%H:%M:%S)"
done

echo "=== 带离线门槛重算指标 $(date +%H:%M:%S)"
for t in hip triton; do
  python3 metric_tools/collect_metrics.py --run-root "final/$t" \
      --offline-audit "final/$t/offline_audit.json" --audit-cache "final/$t/offline_audit" \
      --out "reports/${t}_metrics_gated.md" --csv "reports/${t}_metrics_gated.csv" \
      --note "r3 d 组（记忆池 + DCU Wiki）$t 轨，带离线门槛" > /dev/null 2>&1
  echo "  $t done"
done

python3 metric_tools/compare_tracks.py --hip final/hip --triton final/triton \
    --out reports/compare_tracks.md --note "r3 d 组双轨" > /dev/null 2>&1
echo "=== 全部完成 $(date +%H:%M:%S)"
