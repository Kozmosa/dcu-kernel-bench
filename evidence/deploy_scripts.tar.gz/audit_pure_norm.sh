#!/bin/bash
# 把 pure/<track>/<alias>/ 规范成 <alias>_l<L>_p<P>/（audit_batch 依赖这个命名），再跑终审。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
cd "$ROOT" || exit 1

python3 - <<'PY'
import shutil, yaml, sys
from pathlib import Path
sys.path.insert(0, "/root/dcudeploy/kw_full_b_d_20261101_r3/KernelWeaver")
from src.experiment import batch_output_dir_name

root = Path("/root/dcudeploy/kw_full_b_d_20261101_r3")
for track in ("hip", "triton"):
    src_root = root / "pure" / track
    dst_root = root / "pure_norm" / track
    if dst_root.exists():
        shutil.rmtree(dst_root)
    dst_root.mkdir(parents=True)
    tasks = yaml.safe_load((root / f"manifest_{track}.yaml").read_text())["tasks"]
    n = 0
    for item in tasks:
        name = batch_output_dir_name(item["alias"], item["level"], item["problem_id"])
        src = src_root / item["alias"]
        if not src.exists():
            continue
        dst = dst_root / name
        dst.mkdir()
        for f in ("run.json", "best_code.py", "response.md"):
            if (src / f).exists():
                shutil.copy2(src / f, dst / f)
        n += 1
    print(f"{track}: 规范化 {n} 题 -> {dst_root}")
PY

for t in hip triton; do
  echo "=== pure_norm 终审 $t $(date +%H:%M:%S)"
  python3 -u metric_tools/audit_batch.py \
      --run-root "pure_norm/$t" --manifest "manifest_$t.yaml" \
      --impl aiter --timeout 1800 > "reports/pure_audit_$t.log" 2>&1
  echo "  exit=$? $(date +%H:%M:%S)"
done
echo "PURE NORM AUDIT DONE $(date +%H:%M:%S)"
