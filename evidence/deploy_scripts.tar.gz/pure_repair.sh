#!/bin/bash
# 补跑：把 pure/ 里缺失（网络失败/评测崩溃）的题反复重试，直到补齐或到轮次上限。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
export PYTHONPATH=/root/dcudeploy/PyramidKernel/KernelBench/src:${PYTHONPATH:-}
cd "$ROOT" || exit 1
: > reports/pure_repair.txt

for round in 1 2 3 4; do
  for track in hip triton; do
    backend=cuda; [ "$track" = "triton" ] && backend=triton
    total=$(python3 -c "import yaml;print(len(yaml.safe_load(open('manifest_$track.yaml'))['tasks']))")
    done=$(find "pure/$track" -name run.json 2>/dev/null | wc -l)
    echo "round$round $track: $done/$total" >> reports/pure_repair.txt
    [ "$done" -ge "$total" ] && continue
    python3 -u pure_bench.py \
        --manifest "manifest_$track.yaml" \
        --kernelbench-root "tasks/$track/kernelbench_compat" \
        --backend "$backend" \
        --out "pure/$track" --workers 3 --missing \
        >> "reports/pure_repair_$track.log" 2>&1
  done
  h=$(find pure/hip -name run.json 2>/dev/null | wc -l)
  t=$(find pure/triton -name run.json 2>/dev/null | wc -l)
  [ "$h" -ge 66 ] && [ "$t" -ge 66 ] && break
done
echo "REPAIR DONE $(date +%H:%M:%S) hip=$(find pure/hip -name run.json | wc -l) triton=$(find pure/triton -name run.json | wc -l)" >> reports/pure_repair.txt
