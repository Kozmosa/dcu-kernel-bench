#!/bin/bash
# Configure the hejuapi relay on the DCU server and verify real generation.
# Network: the server has no outbound internet; we reach the API through a
# reverse SSH tunnel that maps server 127.0.0.1:17890 -> local machine proxy 7890.
# NOTE: hejuapi 在 Cloudflare 后面，按 User-Agent 做指纹拦截（裸 Python UA 会返回 1010），
#       所以所有请求都必须带 `User-Agent: curl/8.5.0`——PyramidKernel 的
#       providers/openai-compatible.yaml 里 user_agent 已配成同一个值。
set -o pipefail
ROOT=/root/dcudeploy
KEY='sk-ZwpZEz8qgxX6rUWxU7bOvWFBxMctdCdgns81pky3lZ3eOuqH'
BASE='https://www.hejuapi.com/v1'
MODEL='gpt-6-astra'
PROXY='http://127.0.0.1:17890'

echo "=== 1. write PyramidKernel/.env ==="
mkdir -p "$ROOT/PyramidKernel"
cat > "$ROOT/PyramidKernel/.env" <<EOF
OPENAI_API_KEY=$KEY
OPENAI_BASE_URL=$BASE
OPENAI_MODEL=$MODEL
OPENAI_WIRE_API=chat_completions
OPENAI_TIMEOUT_SECONDS=1200
EOF
chmod 600 "$ROOT/PyramidKernel/.env"
echo "  written: $ROOT/PyramidKernel/.env (mode 600)"
sed 's/\(OPENAI_API_KEY=sk-....\).*/\1***/' "$ROOT/PyramidKernel/.env" | sed 's/^/    /'

echo
echo "=== 2. write shared llm.env (source this to get proxy + creds) ==="
cat > "$ROOT/llm.env" <<EOF
# hejuapi relay over reverse SSH tunnel. Re-established by tunnel.ps1.
export OPENAI_API_KEY=$KEY
export OPENAI_BASE_URL=$BASE
export OPENAI_MODEL=$MODEL
export OPENAI_WIRE_API=chat_completions
export OPENAI_TIMEOUT_SECONDS=1200
export HTTPS_PROXY=$PROXY
export HTTP_PROXY=$PROXY
export NO_PROXY=127.0.0.1,localhost,::1
EOF
chmod 600 "$ROOT/llm.env"
echo "  written: $ROOT/llm.env (mode 600)"

source "$ROOT/llm.env"

echo
echo "=== 3. tunnel listening? ==="
if ss -ltn 2>/dev/null | grep -q 17890; then echo "  OK 127.0.0.1:17890 listening"; else echo "  !! tunnel NOT listening"; fi

echo
echo "=== 4. curl through tunnel ==="
curl -s -o /dev/null -w '  /v1/models -> HTTP %{http_code}  %{time_total}s\n' --max-time 25 "$BASE/models" \
  -H "Authorization: Bearer $KEY"

echo
echo "=== 5. python generation test (streaming, like PyramidKernel does) ==="
python3 - <<'PY'
import json, os, ssl, sys, time, urllib.request

base = os.environ["OPENAI_BASE_URL"]
key = os.environ["OPENAI_API_KEY"]
model = os.environ["OPENAI_MODEL"]
proxy = os.environ.get("HTTPS_PROXY")
print(f"  base={base}  model={model}  proxy={proxy}")

opener = urllib.request.build_opener(
    urllib.request.ProxyHandler({"http": proxy, "https": proxy})
)

# 1) model list
try:
    req = urllib.request.Request(base + "/models",
                                 headers={"Authorization": f"Bearer {key}",
                                          "User-Agent": "curl/8.5.0"})
    with opener.open(req, timeout=30) as r:
        ids = [m["id"] for m in json.loads(r.read().decode())["data"]]
        print(f"  models: {ids}")
except Exception as e:
    print(f"  model list FAILED: {type(e).__name__}: {e}")

# 2) streaming completion
payload = {"model": model,
           "messages": [{"role": "user",
                         "content": "Write a minimal Triton vector-add kernel. Output code only."}],
           "max_tokens": 700, "stream": True}
req = urllib.request.Request(base + "/chat/completions",
                             data=json.dumps(payload).encode(),
                             headers={"Authorization": f"Bearer {key}",
                                      "Content-Type": "application/json",
                                      "User-Agent": "curl/8.5.0"},
                             method="POST")
try:
    t0 = time.time()
    chunks, text = 0, []
    with opener.open(req, timeout=180) as r:
        for raw in r:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            d = line[5:].strip()
            if d == "[DONE]":
                break
            chunks += 1
            try:
                delta = (json.loads(d).get("choices") or [{}])[0].get("delta", {})
                if delta.get("content"):
                    text.append(delta["content"])
            except Exception:
                pass
    out = "".join(text)
    print(f"  stream: {chunks} chunks in {time.time()-t0:.1f}s, {len(out)} chars")
    print(f"  has @triton.jit: {'@triton.jit' in out}")
    print("  --- first 300 chars ---")
    for l in out[:300].splitlines():
        print("    " + l)
except Exception as e:
    print(f"  generation FAILED: {type(e).__name__}: {str(e)[:300]}")
PY

echo
echo "=== done ==="
