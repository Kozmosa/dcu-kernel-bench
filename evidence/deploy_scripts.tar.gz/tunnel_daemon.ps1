# 反向隧道常驻守护：本机直连代理 17891 <-> 评测机 127.0.0.1:17890
#
# 用途：评测机无外网，靠这条隧道把 HTTPS_PROXY=http://127.0.0.1:17890 打通。
# 与 agent 会话解耦，断线自愈：ssh 退出 -> 清理远端残留监听 -> 等 5s -> 重连。
#
# 启动（脱离当前会话，隐藏窗口）：
#   Start-Process pwsh -ArgumentList '-NoProfile','-File','<本文件绝对路径>' -WindowStyle Hidden
# 查看：Get-Content .dcu_runs\deploy\tunnel_daemon.log -Tail 20
# 停止：Stop-Process -Id (Get-Content .dcu_runs\deploy\tunnel_daemon.pid)
param(
    [string]$Target = 'root@ssh.zzai.scnet.cn',
    [int]$Port = 11556,
    [string]$LocalProxy = '127.0.0.1:17891',
    [int]$RemotePort = 17890,
    [int]$RetrySeconds = 5
)

$ErrorActionPreference = 'Continue'
$here = $PSScriptRoot
$log = Join-Path $here 'tunnel_daemon.log'
$pidFile = Join-Path $here 'tunnel_daemon.pid'
Set-Content -Path $pidFile -Value $PID -Encoding ASCII

function Say($msg) {
    $line = "[{0}] {1}" -f (Get-Date -Format 'MM-dd HH:mm:ss'), $msg
    Add-Content -Path $log -Value $line -Encoding UTF8
}

$sshArgs = @('-N',
    '-o', 'BatchMode=yes',
    '-o', 'StrictHostKeyChecking=no',
    '-o', 'ExitOnForwardFailure=yes',
    '-o', 'ServerAliveInterval=15',
    '-o', 'ServerAliveCountMax=3',
    '-o', 'ConnectTimeout=15',
    '-p', "$Port",
    '-R', "${RemotePort}:$LocalProxy",
    $Target)

# 远端可能残留上次会话的 sshd 死监听（TCP 能连上但通道已断，症状 = "连接成功后被静默掐断"）
$cleanup = "pids=`$(netstat -tlnp 2>/dev/null | awk '/127.0.0.1:${RemotePort} /{print `$7}' | cut -d/ -f1 | sort -u); for x in `$pids; do kill -9 `$x 2>/dev/null; done; echo cleaned"

Say "daemon start pid=$PID  $LocalProxy -> remote :$RemotePort on $Target ($Port)"
$n = 0
while ($true) {
    $n++
    Say "connect #$n"
    & ssh @sshArgs 2>&1 | ForEach-Object { Add-Content -Path "$here\tunnel_daemon.err" -Value $_ -Encoding UTF8 }
    $delay = [Math]::Min($RetrySeconds * [Math]::Pow(2, [Math]::Min($n - 1, 4)), 120)
    Say "ssh exited code=$LASTEXITCODE; cleanup remote :$RemotePort then retry in ${delay}s"
    & ssh -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=15 -p "$Port" $Target $cleanup 2>&1 |
        ForEach-Object { Add-Content -Path "$here\tunnel_daemon.err" -Value "cleanup: $_" -Encoding UTF8 }
    Start-Sleep -Seconds $delay
}
