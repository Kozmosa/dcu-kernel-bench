import glob
import json
import os
import re
import statistics
import sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else "/root/dcudeploy/runs/dcukb_en_1019_1027"
MANIFEST = "/root/dcudeploy/dcu-kernel-bench/benchmark/kernelbench_compat/manifest_dcukb.yaml"

aliases = [m.group(1) for m in re.finditer(r"^\s*- alias:\s*(\S+)", open(MANIFEST, encoding="utf-8").read(), re.M)]
print(f"manifest tasks: {len(aliases)}")

rjs = sorted(glob.glob(os.path.join(ROOT, "par_s*", "*", "run.json")))
seen = {}
rows = []
for rj in rjs:
    name = os.path.basename(os.path.dirname(rj))
    alias = name.rsplit("_l", 1)[0]
    seen[alias] = name
    d = json.load(open(rj, encoding="utf-8"))
    nodes = d.get("nodes") or {}
    nl = list(nodes.values()) if isinstance(nodes, dict) else nodes
    bid = d.get("best_node_id")
    best = next((n for n in nl if n.get("node_id") == bid or n.get("id") == bid), None)
    st = d.get("stats") or {}
    rows.append(
        dict(
            alias=alias,
            nodes=len(nl),
            attempts=st.get("attempt_count", 0),
            correct=bool(best and best.get("correct")),
            speedup=(best or {}).get("speedup"),
            bid=bid,
            transient=st.get("provider_transient_error_count", 0),
            exhausted=st.get("provider_transient_budget_exhausted_count", 0),
        )
    )

missing = [a for a in aliases if a not in seen]
extra = [a for a in seen if a not in aliases]
print(f"done: {len(rows)}   missing: {len(missing)} {missing}   extra: {extra}")

correct = [r for r in rows if r["correct"]]
root_only = [r for r in rows if r["bid"] in ("root", "phase2_root", None)]
sp = [r["speedup"] for r in correct if isinstance(r["speedup"], float)]
print(f"correct {len(correct)}/{len(rows)}   best==root {len(root_only)}   real solutions {len(rows) - len(root_only)}")
if sp:
    print(f"speedup median {statistics.median(sp):.2f}x  max {max(sp):.2f}x  min {min(sp):.2f}x")

hot = sorted(rows, key=lambda r: -r["transient"])[:12]
print("\ntasks with the most provider transient errors (tunnel outage victims):")
for r in hot:
    print(f"   {r['alias']:<40} transient={r['transient']:<4} exhausted={r['exhausted']:<2} nodes={r['nodes']:<3} best={r['bid']} correct={r['correct']}")

print("\nbest==root tasks (no real solution):")
for r in root_only:
    print(f"   {r['alias']:<40} nodes={r['nodes']:<3} attempts={r['attempts']:<3} transient={r['transient']}")

print("\nnot correct:")
for r in [r for r in rows if not r["correct"]]:
    print(f"   {r['alias']:<40} nodes={r['nodes']} best={r['bid']} speedup={r['speedup']}")
