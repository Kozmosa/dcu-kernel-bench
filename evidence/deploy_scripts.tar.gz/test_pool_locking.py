"""并发对拍：两个进程各写 50 条到同一个共享记忆池，验证锁与去重是否生效。

期望：池中 100 条。用法：python3 test_pool_locking.py <r3 根目录>
"""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
CODE = ROOT / "KernelWeaver"
pool = ROOT / "pools" / "lock_test_pool.json"
pool.parent.mkdir(parents=True, exist_ok=True)
if pool.exists():
    pool.unlink()

worker = ROOT / "_pool_worker.py"
worker.write_text(
    '''import os, sys
sys.path.insert(0, {code!r})
os.environ["KW_MEMORY_POOL"] = {pool!r}
from src.core.long_term_memory import TaskExperienceJournal
j = TaskExperienceJournal(None, 4, {{"runtime": "hip"}})
tag = sys.argv[1]
for i in range(50):
    j.entries.append({{"task_name": "%s_%d" % (tag, i), "op_type": "t", "backend": "cuda",
                       "platform": j.platform, "strategy": "s", "outcome": "correct",
                       "failure_type": None, "speedup": 1.0, "lesson": "l"}})
    j._locked_write(j.entries)
print("worker", tag, "done", flush=True)
'''.format(code=str(CODE), pool=str(pool)),
    encoding="utf-8")

procs = [subprocess.Popen([sys.executable, str(worker), tag], stdout=subprocess.PIPE, text=True)
         for tag in ("A", "B")]
for p in procs:
    print(p.communicate()[0].strip())

entries = json.loads(pool.read_text(encoding="utf-8"))["entries"] if pool.exists() else []
names = {e["task_name"] for e in entries}
print("池中条目 %d 条（去重后 %d 个名字），期望 100" % (len(entries), len(names)))
print("RESULT:", "PASS" if len(names) == 100 else "FAIL")
worker.unlink(missing_ok=True)
pool.unlink(missing_ok=True)
