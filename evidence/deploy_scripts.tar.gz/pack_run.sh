#!/usr/bin/env bash
# Pack everything the report needs from a finished run into one tarball.
#   run.json for all 66 tasks, best_code.py, plus the summary.json if present.
set +u
RUN_ROOT=${1:-/root/dcudeploy/runs/dcukb_en_1019_1027}
OUT=${2:-/root/dcudeploy/upload/en66_pull.tar.gz}
cd "$RUN_ROOT" || { echo "no such run root: $RUN_ROOT"; exit 1; }
# keep only what the report/eval needs: avoids dragging logs and node dumps
find . -type f \( -name 'run.json' -o -name 'best_code.py' -o -name 'summary.json' \) -print0 \
  | tar --null -czf "$OUT" -T - 2>/dev/null
ls -la "$OUT"
echo "files in tar: $(tar -tzf "$OUT" | wc -l)"
tar -tzf "$OUT" | grep -c 'run.json$'
