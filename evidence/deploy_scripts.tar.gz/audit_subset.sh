#!/bin/bash
# 对 23 题验证集做离线终审，并与上一轮逐题对比。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
cd "$ROOT" || exit 1

echo "== 合并 8 份 manifest + 产物到 subset_view =="
python3 - <<'PY'
import glob, json, pathlib, shutil, yaml
root = pathlib.Path("/root/dcudeploy/kw_full_b_d_20261101_r3")
tasks, seen = [], set()
for p in sorted(root.glob("subset_manifest_s*.yaml")):
    for t in yaml.safe_load(p.read_text())["tasks"]:
        if t["alias"] not in seen:
            seen.add(t["alias"]); tasks.append(t)
(root / "subset_manifest_all.yaml").write_text(
    yaml.safe_dump({"name": "subset_all", "backend": "triton", "tasks": tasks}, sort_keys=False, allow_unicode=True))
print("manifest 合并:", len(tasks), "题")

view = root / "subset_view"
if view.exists():
    shutil.rmtree(view)
view.mkdir()
n = 0
for d in glob.glob(str(root / "subset/triton/s*/*")):
    p = pathlib.Path(d)
    if (p / "run.json").exists():
        dst = view / p.name
        if dst.exists():
            shutil.rmtree(dst)
        dst.mkdir()
        for f in ("run.json", "best_code.py"):
            if (p / f).exists():
                shutil.copy2(p / f, dst / f)
        n += 1
print("产物合并:", n, "题")
PY

echo "== 离线终审 =="
python3 -u metric_tools/audit_batch.py --run-root subset_view --manifest subset_manifest_all.yaml \
    --impl aiter --timeout 900 > reports/subset_audit.log 2>&1
echo "exit=$?"

echo "== 与上一轮逐题对比 =="
python3 - <<'PY'
import json, glob, pathlib
root = pathlib.Path("/root/dcudeploy/kw_full_b_d_20261101_r3")
def load_prev():
    out = {}
    for f in glob.glob(str(root / "final2/triton/offline_audit/*.json")):
        d = json.load(open(f))
        out[d.get("task")] = (bool(d.get("static_audit_passed")), d.get("correctness_passed"))
    return out
prev = load_prev()
now = {}
for f in glob.glob(str(root / "subset_view/offline_audit/*.json")):
    d = json.load(open(f))
    now[d.get("task")] = (bool(d.get("static_audit_passed")), d.get("correctness_passed"))
print("%-52s %-18s %-18s" % ("task", "上一轮(静态/正确)", "本轮(静态/正确)"))
better = same = worse = 0
for t in sorted(now):
    p = prev.get(t, (None, None))
    a, b = now[t]
    def fmt(v):
        return "%s/%s" % ("PASS" if v[0] else "FAIL", v[1])
    print("%-52s %-18s %-18s" % (t[:52], fmt(p) if p[0] is not None else "-", fmt((a, b))))
    pv = p[1] is True
    nv = b is True
    if nv and not pv: better += 1
    elif nv == pv: same += 1
    else: worse += 1
print("\n离线通过: 上一轮 %d -> 本轮 %d | 变好 %d 持平 %d 变差 %d" % (
    sum(1 for t in prev if prev[t][1] is True), sum(1 for t in now if now[t][1] is True), better, same, worse))
PY
