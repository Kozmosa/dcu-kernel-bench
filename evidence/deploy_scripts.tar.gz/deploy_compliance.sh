#!/bin/bash
# 部署"合规"改进：新 Wiki 页 + index 约束 + 新语料锁；然后验证检索能命中。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
CFG=$ROOT/KernelWeaver
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$CFG" || exit 1

echo "== 语料锁 =="
python3 -c "import json;print(json.load(open('knowledge/kernelwiki_dcu/corpus.lock.json'))['sha256'][:16])"

echo "== 审计（含锁校验） =="
python3 - <<'PY'
import sys
sys.path.insert(0, "/root/dcudeploy/kw_full_b_d_20261101_r3/KernelWeaver")
from pathlib import Path
from src.knowledge.public_wiki import audit_public_corpus
a = audit_public_corpus(Path("knowledge/kernelwiki_dcu"))
print("audit OK, sha256 =", a["sha256"][:16])
PY

echo "== 检索验证：任意算子题都能拿到合规页 =="
python3 - <<'PY'
import sys, yaml
sys.path.insert(0, "/root/dcudeploy/kw_full_b_d_20261101_r3/KernelWeaver")
from pathlib import Path
from src.knowledge.public_wiki import PublicKernelWiki

wiki = PublicKernelWiki(Path("knowledge/kernelwiki_dcu"), backend="triton")
root = Path("/root/dcudeploy/kw_full_b_d_20261101_r3")
hits = 0
total = 0
for track in ("hip", "triton"):
    for item in yaml.safe_load((root / f"manifest_{track}.yaml").read_text())["tasks"]:
        total += 1
        try:
            pages = wiki.select(alias=item["alias"], backend="cuda" if track == "hip" else "triton", limit=3)
            ids = [p.get("id") for p in pages]
        except Exception as exc:
            print("  select 失败", item["alias"], exc)
            continue
        if "public-compliance" in ids:
            hits += 1
print(f"命中合规页: {hits}/{total}")
PY
