#!/usr/bin/env bash
# deploy.sh —— 在 DCU 服务器上执行：环境自检 → 解包 → 装 triton → 铺 aiter 垫片
#
# 用法：
#   bash deploy.sh              # 全流程
#   bash deploy.sh --check      # 只做环境自检，不改动任何东西
#
# 目录布局（默认 ROOT=/root/dcudeploy）：
#   $ROOT/upload/                     <- push.ps1 把东西传到这里
#     dcu-kernel-bench.tar            <- 评测集（从 main-merge 打的包）
#     aiter_shim.tar.gz               <- aiter 最小导入垫片 + tuner configs
#     triton-*.whl                    <- DTK 26.04 版 Triton（可选，已装则跳过）
#     py311deps.tar.gz                <- 离线 Python 依赖（可选，已铺则跳过）
#     deploy.sh verify.sh check_configs.py run_all_tests.py
#   $ROOT/dcu-kernel-bench/           <- 解包后的评测集
#   $ROOT/aiter_shim/                 <- 解包后的垫片（放在 PYTHONPATH 最前）
#   $ROOT/py311deps/                  <- 离线依赖
#   $ROOT/env.sh                      <- 生成的环境变量文件，用 `source` 引入
set -eo pipefail
# 注意：不能开 set -u。/opt/dtk/env.sh 会引用未定义的 CMAKE_PREFIX_PATH，
# 开 -u 会让 `source /opt/dtk/env.sh` 直接失败（已踩过）。

ROOT="${ROOT:-/root/dcudeploy}"
UP="${UP:-$ROOT/upload}"
CHECK_ONLY=0
[ "${1:-}" = "--check" ] && CHECK_ONLY=1

DRED=$'\033[31m'; DGRN=$'\033[32m'; DYLW=$'\033[33m'; DOFF=$'\033[0m'
ok()  { printf '  %s[ok]%s   %s\n'   "$DGRN" "$DOFF" "$*"; }
bad() { printf '  %s[FAIL]%s %s\n'   "$DRED" "$DOFF" "$*"; }
wrn() { printf '  %s[warn]%s %s\n'   "$DYLW" "$DOFF" "$*"; }
inf() { printf '         %s\n' "$*"; }
hr()  { printf '\n=== %s ===\n' "$*"; }

FAIL=0

# ---------------------------------------------------------------- 1. 环境自检
hr "1. 环境自检"

if [ ! -f /opt/dtk/env.sh ]; then
  bad "/opt/dtk/env.sh 不存在 —— 这台机器没有 DTK 环境"
  exit 1
fi
# shellcheck disable=SC1091
source /opt/dtk/env.sh
ok "已 source /opt/dtk/env.sh"

PYV=$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null || echo "?")
if [ "$PYV" = "3.11" ]; then ok "Python $PYV（wheel 是 cp311，匹配）"
else bad "Python $PYV，需要 3.11（wheel 是 cp311）"; FAIL=1; fi

TORCHV=$(python3 -c 'import torch;print(torch.__version__)' 2>/dev/null || echo "无")
if [ "$TORCHV" = "无" ]; then bad "import torch 失败"; FAIL=1
else
  case "$TORCHV" in
    2.9.*) ok "torch $TORCHV（wheel 是 torch290，匹配）" ;;
    *)     bad "torch $TORCHV，期望 2.9.x"; FAIL=1 ;;
  esac
fi

CUDA=$(python3 -c 'import torch;print(torch.cuda.is_available())' 2>/dev/null || echo "False")
if [ "$CUDA" = "True" ]; then ok "torch.cuda.is_available() = True"
else bad "torch.cuda.is_available() = False —— 卡不可见"; FAIL=1; fi

ARCH=$(python3 - <<'PY' 2>/dev/null || echo "?"
import torch
try:
    print(torch.cuda.get_device_properties(0).gcnArchName)
except Exception:
    print("?")
PY
)
case "$ARCH" in
  gfx936*) ok "架构 $ARCH（gfx936 -> aiter 设备名 BW200，与本评测集记录一致）" ;;
  gfx938*) wrn "架构 $ARCH（gfx938 -> BW200B）；评测集基线记的是 gfx936，环境不同即不可比" ;;
  *)       wrn "架构 $ARCH —— 请确认与历史基线环境一致（记录为 gfx936）" ;;
esac

NPROC=$(nproc 2>/dev/null || echo "?")
MEMG=$(awk '/MemTotal/{printf "%.0f", $2/1024/1024}' /proc/meminfo 2>/dev/null || echo "?")
inf "CPU ${NPROC} 核, 内存 ${MEMG} GB"
if [ "$MEMG" != "?" ] && [ "$MEMG" -lt 60 ] 2>/dev/null; then
  wrn "内存 ${MEMG}GB 偏小：最大的 perf case 单张量约 4.3GB(bf16)，多张量叠加可能 OOM"
fi
DF=$(df -h "$ROOT" 2>/dev/null | awk 'NR==2{print $4}' || echo "?")
inf "$ROOT 可用空间 $DF（需 >= 2GB）"

if [ "$CHECK_ONLY" = "1" ]; then
  hr "只做自检（--check），未改动任何文件"
  [ "$FAIL" = "0" ] && ok "环境自检通过" || bad "环境自检有 $FAIL 项不通过"
  exit "$FAIL"
fi

[ "$FAIL" = "0" ] || { bad "环境自检未通过，停止部署（修好再跑，或用 --check 单独看）"; exit 1; }

[ -d "$UP" ] || { bad "上传目录不存在：$UP"; exit 1; }
mkdir -p "$ROOT"

# ---------------------------------------------------------------- 2. 解包
hr "2. 解包"

if [ -f "$UP/dcu-kernel-bench.tar" ]; then
  rm -rf "$ROOT/dcu-kernel-bench"
  mkdir -p "$ROOT/dcu-kernel-bench"
  tar -xf "$UP/dcu-kernel-bench.tar" -C "$ROOT/dcu-kernel-bench"
  NT=$(find "$ROOT/dcu-kernel-bench/benchmark/tasks" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l)
  NA=$(find "$ROOT/dcu-kernel-bench/benchmark/private" -name aiter_impl.py 2>/dev/null | wc -l)
  ok "评测集解包完成：${NT} 道题 / ${NA} 个 aiter 适配器"
  # 期望值随题库增长而更新：2026-10-12 上游新准入 21 道 hipDNN 样例题后为 68 道
  [ "$NT" = "68" ] || bad "题目数应为 68，实际 $NT（包可能过期）"
  [ "$NA" = "44" ] || bad "适配器数应为 44，实际 $NA（包可能过期）"
else
  bad "缺少 $UP/dcu-kernel-bench.tar"
  exit 1
fi

if [ -f "$UP/aiter_shim.tar.gz" ]; then
  rm -rf "$ROOT/aiter_shim"
  mkdir -p "$ROOT/aiter_shim"
  tar -xzf "$UP/aiter_shim.tar.gz" -C "$ROOT/aiter_shim"
  NM=$(find "$ROOT/aiter_shim" -name '*.py' | wc -l)
  NC=$(find "$ROOT/aiter_shim" -name '*.json' | wc -l)
  ok "aiter 垫片解包完成：${NM} 个模块 / ${NC} 个 tuner config"
  # 关键：垫片的 aiter/__init__.py 必须是存根，不能是真文件
  if grep -q 'from aiter_ import' "$ROOT/aiter_shim/aiter/__init__.py" 2>/dev/null; then
    bad "垫片里的 aiter/__init__.py 是真文件（会加载编译扩展）—— 垫片打包有误"
    FAIL=1
  else
    ok "aiter/__init__.py 是存根（不依赖编译扩展）"
  fi
else
  bad "缺少 $UP/aiter_shim.tar.gz"
  exit 1
fi

# 离线依赖（可选）
if [ ! -d "$ROOT/py311deps" ] && [ -f "$UP/py311deps.tar.gz" ]; then
  mkdir -p "$ROOT/py311deps"
  tar -xzf "$UP/py311deps.tar.gz" -C "$ROOT/py311deps"
  ok "离线依赖解包完成"
elif [ -d "$ROOT/py311deps" ]; then
  ok "离线依赖已存在，跳过"
else
  wrn "没有 py311deps —— 若系统已装 yaml/pytest 可忽略"
fi

# 辅助脚本复制到 ROOT，verify.sh / collect_baselines.sh / run_generation.sh 直接引用这里
for f in check_configs.py run_all_tests.py verify.sh collect_baselines.sh \
         run_generation.sh run_resume.sh resume_run.py _setup_llm.sh; do
  [ -f "$UP/$f" ] && cp -f "$UP/$f" "$ROOT/$f"
done
chmod +x "$ROOT/run_generation.sh" "$ROOT/run_resume.sh" 2>/dev/null
ok "辅助脚本已就位（verify / collect_baselines / run_generation / run_resume）"

# ---------------------------------------------------------------- 3. Triton
hr "3. Triton"

if python3 -c 'import triton' 2>/dev/null; then
  ok "triton 已可导入：$(python3 -c 'import triton;print(triton.__version__)')"
else
  WHL=$(ls "$UP"/triton-*.whl 2>/dev/null | head -1 || true)
  [ -z "$WHL" ] && WHL=$(ls "$ROOT"/triton-*.whl 2>/dev/null | head -1 || true)
  if [ -n "$WHL" ]; then
    inf "安装 $WHL"
    pip3 install --no-deps "$WHL" >/dev/null 2>&1 && ok "triton 安装完成" || { bad "triton 安装失败"; FAIL=1; }
  else
    bad "triton 不可导入，且找不到 triton-*.whl"
    FAIL=1
  fi
fi

# ---------------------------------------------------------------- 4. env.sh
hr "4. 生成 env.sh"

cat > "$ROOT/env.sh" <<EOF
# 由 deploy.sh 生成 —— 用 \`source $ROOT/env.sh\` 引入
# DTK 的 env.sh 会引用未定义变量，所以先关掉 -u，避免调用方开 -u 时炸掉
set +u
source /opt/dtk/env.sh
# 垫片必须排在 py311deps 之前，确保 aiter.* 解析到垫片而非真 aiter
export PYTHONPATH=$ROOT/aiter_shim:$ROOT/py311deps:$ROOT/dcu-kernel-bench\${PYTHONPATH:+:\$PYTHONPATH}
export DCU_KB_ROOT=$ROOT/dcu-kernel-bench
export AITER_SHIM=$ROOT/aiter_shim
# 这台机器有 128 核，torch 默认会把线程开满，小张量算子因超订被拖死：
# 实测 test_reference_case_contract 在默认线程下 >17 分钟（4 小时 CPU 时间），
# 限到 8 线程后 197s 通过。CPU 侧的 reference 自检/测试都受益。
export OMP_NUM_THREADS=\${OMP_NUM_THREADS:-8}
export MKL_NUM_THREADS=\${MKL_NUM_THREADS:-8}
export OPENBLAS_NUM_THREADS=\${OPENBLAS_NUM_THREADS:-8}
export NUMEXPR_NUM_THREADS=\${NUMEXPR_NUM_THREADS:-8}
EOF
ok "已写 $ROOT/env.sh"
# shellcheck disable=SC1090
source "$ROOT/env.sh"
ok "PYTHONPATH = $PYTHONPATH"

# ---------------------------------------------------------------- 5. 冒烟
hr "5. 冒烟测试"

if python3 -c 'import yaml' 2>/dev/null; then ok "pyyaml 可导入（record_baseline/audit 需要）"
else bad "pyyaml 不可导入 —— benchmark/evaluator 跑不了"; FAIL=1; fi

if python3 -c 'import aiter.ops.triton.utils.core as c; print(c.AITER_TRITON_CONFIGS_PATH)' >/tmp/_aiter_probe 2>&1; then
  ok "aiter 垫片可导入：$(cat /tmp/_aiter_probe)"
else
  bad "aiter 垫片导入失败："; sed 's/^/         /' /tmp/_aiter_probe
  FAIL=1
fi

if [ -f "$ROOT/dcu-kernel-bench/benchmark/tools/dcukb.py" ]; then
  ok "dcukb.py 就位"
else
  bad "dcukb.py 缺失（包过期）"; FAIL=1
fi

hr "结果"
if [ "$FAIL" = "0" ]; then
  ok "部署完成"
  inf "下一步：bash verify.sh"
else
  bad "有 $FAIL 项未通过"
fi
exit "$FAIL"
