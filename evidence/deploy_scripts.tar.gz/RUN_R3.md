# r3 运行说明（明天一条命令开跑）

> **方法上就是 Pyramid 那一套**：非流式 Chat Completions、同一中转、同模型 `gpt-6-astra`、
> 同样的 provider 重试、每题最多 10 次候选、同样的在线/离线指标口径。
> 换的只是框架（KernelWeaver 的 stark workflow，带 b/d 两种记忆配置），
> 外加两件纯工程的东西：**4 分片并行** 和 **断点续跑**。

## 一、开跑前只确认一件事

本机（Windows）要有 **local_direct_proxy(17891) + 反向隧道(17890)**，机器才能出网：

```bash
ssh -p 11556 root@ssh.zzai.scnet.cn \
  "curl -sS -o /dev/null -w '%{http_code}\n' --max-time 20 -x http://127.0.0.1:17890 \
   -H \"Authorization: Bearer \$OPENAI_API_KEY\" https://www.hejuapi.com/v1/models"
```

返回 `200` → 开跑。不是 200 → 本机查 `Test-NetConnection 127.0.0.1 -Port 17891`，
以及 `.dcu_runs/deploy/tunnel_daemon.log` 是否有 `connect #N`。
**隧道终点必须是 `127.0.0.1:17891`（直连出口），不是 Clash 7890。**

## 二、一条命令开跑（默认 64 条流）

```bash
ssh -p 11556 root@ssh.zzai.scnet.cn "bash /root/dcudeploy/kw_full_b_d_20261101_r3/launch_r3.sh"
```

自检 API → 后台起 `supervise_r3.py`（**16 分片 × 4 组 = 64 条流**，与 Pyramid 的 16 分片同量级）→ 打印开头几行。
若上游限流或 GPU 抢得太凶，可节流启动（不丢进度）：
`python3 supervise_r3.py --max-concurrent 32`
运行期间 **本机不能关机 / 断网 / 睡眠**（机器自身没有外网，全靠这条隧道）。

## 三、看进度 / 停止 / 续跑

```bash
cd /root/dcudeploy/kw_full_b_d_20261101_r3
python3 supervise_r3.py --status        # 每条流 已完成/总数、round、pid
tail -f logs/supervisor.out             # 启动/重启事件
tail -f logs/dcu_b_longterm_hip_s1.log   # 单条流细节
pkill -f supervise_r3.py                # 停止（子进程一并终止）
bash launch_r3.sh                       # 再次执行 = 续跑
```

**续跑语义**：`<分片>/<任务>/run.json` 存在即算完成、重启时跳过；
被打断的那道题从第 1 次候选重来（框架无更细检查点，这题多花一次预算）。

## 四、跑完收尾

```bash
ssh -p 11556 root@ssh.zzai.scnet.cn \
  "cd /root/dcudeploy/kw_full_b_d_20261101_r3 && python3 finalize_r3.py"
```

产出：
- `reports/<b|d>_<hip|triton>_metrics.md` + `.csv` —— 四份指标（Compile/Correct、Success@K、Fast1@K、Geomean/Median/Mean/Best、First Correct/Refine Gain + 离线终审门槛口径）
- `reports/compare_b_vs_d.md` —— b 与 d 四组并列对比
- `reports/metric_inputs/<组>/<轨>/offline_audit.json` —— 逐题离线终审

## 五、r3 相对 r2 的差异（报告里如实写这几句）

| 项 | r2（Codex） | r3 |
|---|---|---|
| 代码 | KernelWeaver 快照 | **与 r2 逐字节一致**（`diff -rq` 仅 `__pycache__` 不同） |
| 传输 | 非流式 chat completions | 同（**没有**流式，也没有改 reasoning_effort） |
| 并发 | 4 条流（每组一条 66 题串行） | **64 条流**（每组每轨切 16 段，每段 4–5 题） |
| 续跑 | 无，控制器拒绝重复启动 | 有，按 `run.json` 跳过已完成任务 |
| 记忆链 | 每组一条 66 题链 | 每组 **4 条连续链**（段内仍按原顺序累积） |

**唯一语义差异**：长期记忆的累积链从"66 题一条"变成"每段 4–5 题一条"（16 段）。
模型、题面、10 次预算、评测/测量配置、Wiki 语料哈希、指标口径全部不变。

## 六、预估时间（实测重算，2026-11-01 23:54–00:06 数据）

实测（非流式，与 Pyramid 同一传输，任务 `8002_gather` level-1，1 次候选，exit=0）：

| 项 | 实测 |
|---|---|
| 单次模型调用 | 31s / 93s / 131s / ~200s |
| 一次候选的调用数 | **4 次**（plan → code → 检视 → 修正） |
| 一次候选总耗时 | **570 秒**（≈9.5 分钟），其中 LLM ≈450s、GPU 评测+编译 ≈120s |
| 链路错误 | **0**（4 次调用全成功，没有 524） |

**两个瓶颈，都要处理：**

1. **LLM 等待**：2640 次候选 × ~450s ÷ 16 条流 ≈ **20 小时**；开 32 条流（`SHARDS=8`）≈ **10 小时**。
2. **GPU 评测串行**：`STARK_GPU_EVALUATION_LOCK` 把 16 条流的编译/正确性/计时**全部串成一条队**，
   2640 次 × ~120s ≈ **88 小时** —— 这才是最大瓶颈。
   旧 Pyramid 没有这个锁（16 分片并发直接抢 GPU），所以 85 分钟就跑完了。
   **建议：不设这个环境变量**（与 Pyramid 一致）；代价是计时噪声略大，收益是吞吐提升数倍。

当前配置：`SHARDS=16`（64 条流）+ 不设 GPU 锁 → 预计 **5–8 小时**。
若上游限流：`python3 supervise_r3.py --max-concurrent 32` 节流（进度保留）。

## 七、出问题时先看这三处

| 现象 | 先看 | 处理 |
|---|---|---|
| 全部流卡住 | `supervise_r3.py --status` + `logs/supervisor.out` | 多半隧道断了，恢复网络后自动续 |
| 单流反复重启 | `logs/<组>_<轨>_s<k>.log` 尾部 | 连续崩溃 6 次会标 `blocked`，修好后删 `status_resume.json` 里该槽位 |
| 出现 524 | `groups/<组>/<轨>/shard<k>/http_events.jsonl` | 中转侧的 120 秒窗口限制，provider 会自己重试；偶发不用管，成片出现说明上游过载 |
