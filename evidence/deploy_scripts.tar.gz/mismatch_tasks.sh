#!/bin/bash
# 列出"在线/离线"不一致的题：离线过但在线不过、在线过但离线不过
cd /root/dcudeploy/kw_full_b_d_20261101_r3 || exit 1
python3 - <<'PY'
import glob, json, re
from pathlib import Path

ROOT = Path("/root/dcudeploy/kw_full_b_d_20261101_r3")

def key(s):
    m = re.search(r"(\d{4})", str(s or ""))
    return m.group(1) if m else str(s)

def load(run_dirs, off_dirs):
    on, off = {}, {}
    for d in run_dirs:
        for f in glob.glob(str(ROOT / d / "*" / "run.json")):
            data = json.load(open(f))
            nodes = {k: v for k, v in data.get("nodes", {}).items() if k not in ("root", "phase2_root")}
            fails = [v.get("failure_type") for v in nodes.values() if not v.get("correct")]
            on[key(data.get("task_name") or f.split("/")[-2])] = (any(v.get("correct") for v in nodes.values()), fails)
    for d in off_dirs:
        for f in glob.glob(str(ROOT / d / "offline_audit" / "*.json")):
            data = json.load(open(f))
            off[key(data.get("task"))] = (bool(data.get("static_audit_passed")), data.get("correctness_passed"))
    return on, off

for label, run_dirs, off_dirs in (
    ("框架v2-HIP", ["final2/hip"], ["final2/hip"]),
    ("框架v2-Triton", ["final2/triton", "subset_view"], ["final2/triton", "subset_view"]),
    ("纯API-HIP", ["pure_norm/hip"], ["pure_norm/hip"]),
    ("纯API-Triton", ["pure_norm/triton"], ["pure_norm/triton"]),
):
    on, off = load(run_dirs, off_dirs)
    tasks = sorted(set(on) & set(off))
    off_no_on = [t for t in tasks if not on[t][0] and off[t][1] is True]
    on_no_off = [t for t in tasks if on[t][0] and off[t][1] is not True]
    print(f"== {label}: 离线过但在线不过 {len(off_no_on)} | 在线过但离线不过 {len(on_no_off)}")
    for t in off_no_on:
        print(f"   离线过/在线挂: {t}  在线失败类型={sorted(set(x for x in on[t][1] if x))}")
PY
