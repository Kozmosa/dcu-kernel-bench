#!/bin/bash
# 拆分：纯 API 与框架 v2 的离线失败，各有多少是"静态违规"vs"数值/编译错误"
cd /root/dcudeploy/kw_full_b_d_20261101_r3 || exit 1
python3 - <<'PY'
import glob, json, re, pathlib

ROOT = pathlib.Path("/root/dcudeploy/kw_full_b_d_20261101_r3")

def key(s):
    m = re.search(r"(\d{4})", str(s or ""))
    return m.group(1) if m else str(s)

def breakdown(label, paths):
    static_fail = numeric_or_compile = passed = missing = 0
    for p in paths:
        d = json.load(open(p))
        st = bool(d.get("static_audit_passed"))
        cp = d.get("correctness_passed")
        if not st:
            static_fail += 1
        elif cp is True:
            passed += 1
        elif cp is False:
            numeric_or_compile += 1
        else:
            missing += 1
    print("%-16s 通过 %2d | 静态违规 %2d | 数值/编译不过 %2d | 无结果 %2d" % (
        label, passed, static_fail, numeric_or_compile, missing))

for track in ("hip", "triton"):
    breakdown("纯API-" + track, glob.glob(str(ROOT / f"pure_norm/{track}/offline_audit/*.json")))
for track in ("hip", "triton"):
    breakdown("框架v2-" + track, glob.glob(str(ROOT / f"final2/{track}/offline_audit/*.json")))
PY
