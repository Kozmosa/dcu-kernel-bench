#!/bin/bash
# 只对比两组：纯 API 直出 vs 框架（合规页 v2）。输出完整在线/离线指标。
cd /root/dcudeploy/kw_full_b_d_20261101_r3 || exit 1
python3 - <<'PY'
import glob, json, math, re, statistics, pathlib

ROOT = pathlib.Path("/root/dcudeploy/kw_full_b_d_20261101_r3")

def key(s):
    m = re.search(r"(\d{4})", str(s or ""))
    return m.group(1) if m else str(s)

def load_run(dirs):
    out = {}
    for d in dirs:
        for f in glob.glob(str(ROOT / d / "*" / "run.json")):
            data = json.load(open(f))
            nodes = {k: v for k, v in data.get("nodes", {}).items() if k not in ("root", "phase2_root")}
            best = max([v.get("speedup") or 0 for v in nodes.values()] or [0])
            out[key(data.get("task_name") or f.split("/")[-2])] = (any(v.get("correct") for v in nodes.values()), best)
    return out

def load_off(dirs):
    out = {}
    for d in dirs:
        for f in glob.glob(str(ROOT / d / "offline_audit" / "*.json")):
            data = json.load(open(f))
            out[key(data.get("task"))] = data.get("correctness_passed") is True
    return out

def stats(name, on, off):
    tasks = sorted(set(on) & set(off))
    sol = [t for t in tasks if on[t][0]]
    sp = [on[t][1] for t in sol if on[t][1]]
    fast1 = sum(1 for t in sol if on[t][1] and on[t][1] > 1)
    gm = math.exp(sum(math.log(x) for x in sp) / len(sp)) if sp else 0
    strict = sum(1 for t in tasks if on[t][0] and off[t])
    print("%-14s 题 %2d | 在线正确 %2d | Fast1 %2d | 离线通过 %2d | 在线∩离线 %2d | Geo %.2fx | Med %.2fx | Mean %.1fx | Best %.1fx"
          % (name, len(tasks), len(sol), fast1, sum(1 for t in tasks if off[t]), strict,
             gm, statistics.median(sp) if sp else 0, statistics.mean(sp) if sp else 0, max(sp) if sp else 0))

# 纯 API
for track in ("hip", "triton"):
    on = load_run([f"pure_norm/{track}"])
    off = load_off([f"pure_norm/{track}"])
    stats(f"纯API-{track}", on, off)

# 框架 v2（Triton 用合并结果）
tri_on = load_run(["final2/triton"]); tri_off = load_off(["final2/triton"])
tri_on.update(load_run(["subset_view"])); tri_off.update(load_off(["subset_view"]))
stats("框架v2-hip", load_run(["final2/hip"]), load_off(["final2/hip"]))
stats("框架v2-triton", tri_on, tri_off)
PY
