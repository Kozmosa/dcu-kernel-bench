"""给 provider 加流式传输（与重试补丁可叠加）。

为什么必须流式：经 Clash 的隧道对非流式请求 60 秒无数据即掐断，且中转对
非流式请求有单独限流（429 gpt_nonstream_rate_limit_exceeded）。

用法：python3 patch_streaming_any.py <KernelWeaver 根目录>
"""
import ast
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
P = ROOT / "src" / "providers" / "openai_provider.py"
text = P.read_text(encoding="utf-8")
if "_sdk_stream_chat" in text:
    print("已有流式补丁，跳过")
    sys.exit(0)

OLD_CALL = ('                payload = self._sdk_http("POST", url, request_body, '
            'self.config.timeout_seconds)')
NEW_CALL = '''                if (os.environ.get("OPENAI_HTTP_STREAM", "1").strip().lower()
                        not in ("0", "false", "no", "off")) and "messages" in request_body:
                    payload = self._sdk_stream_chat(request_body, self.config.timeout_seconds)
                else:
                    payload = self._sdk_http("POST", url, request_body, self.config.timeout_seconds)'''

OLD_SDK = '''            if method == "GET":
                return client.get(url, cast_to=Dict[str, Any])
            return client.post(url, cast_to=Dict[str, Any], body=body)'''
NEW_SDK = OLD_SDK + '''

    def _sdk_stream_chat(self, request_body: dict[str, Any], timeout: int) -> dict[str, Any]:
        """流式取 chat/completions，聚合成与非流式相同的 payload 形状。"""
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("SDK transport requires pip install 'kernelweaver[api]'") from exc
        body = dict(request_body)
        body.pop("stream", None)
        body.pop("stream_options", None)
        with OpenAI(api_key=self.config.api_key, base_url=self.config.base_url,
                    timeout=timeout, max_retries=0) as client:
            def _open(with_usage: bool):
                kwargs = dict(body)
                kwargs["stream"] = True
                if with_usage:
                    kwargs["stream_options"] = {"include_usage": True}
                return client.chat.completions.create(**kwargs)

            try:
                stream = _open(True)
            except Exception as exc:  # noqa: BLE001
                if "stream_options" in str(exc).lower() or "usage" in str(exc).lower():
                    stream = _open(False)
                else:
                    raise
            parts: list[str] = []
            usage: dict[str, Any] | None = None
            finish: str | None = None
            for chunk in stream:
                cu = getattr(chunk, "usage", None)
                if cu is not None:
                    try:
                        usage = cu.model_dump()
                    except AttributeError:
                        usage = dict(cu)
                choices = getattr(chunk, "choices", None) or []
                if not choices:
                    continue
                delta = getattr(choices[0], "delta", None)
                piece = getattr(delta, "content", None) if delta is not None else None
                if piece:
                    parts.append(piece)
                if getattr(choices[0], "finish_reason", None):
                    finish = choices[0].finish_reason
        payload: dict[str, Any] = {
            "object": "chat.completion",
            "model": str(body.get("model", self.config.model)),
            "choices": [{"index": 0, "finish_reason": finish or "stop",
                         "message": {"role": "assistant", "content": "".join(parts)}}],
        }
        if usage:
            payload["usage"] = usage
        return payload'''

for old, new, tag in ((OLD_CALL, NEW_CALL, "call-site"), (OLD_SDK, NEW_SDK, "_sdk_http")):
    if text.count(old) != 1:
        print(f"FAIL 锚点 {tag} 计数={text.count(old)}")
        sys.exit(1)
    text = text.replace(old, new)

P.write_text(text, encoding="utf-8", newline="\n")
ast.parse(P.read_text(encoding="utf-8"))
print("流式补丁已应用，语法 OK")
