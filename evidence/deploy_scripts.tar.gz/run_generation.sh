#!/bin/bash
# 在 DCU 服务器上跑 PyramidKernel 的生成评测（dcu-kernel-bench 全量或小样例）。
#
# 用法（服务器上）：
#   bash /root/dcudeploy/run_generation.sh                # 全量 66 题
#   MANIFEST=smoke3 bash /root/dcudeploy/run_generation.sh # 先跑 3 题验链路
#   SEARCH=quick bash /root/dcudeploy/run_generation.sh    # 用 quick 搜索预算
#
# 前置：
#   1. 本机已建立反向隧道（push_tunnel.ps1），服务器 127.0.0.1:17890 可达本机代理
#   2. llm.env 已写入（bash upload/_setup_llm.sh 或手工）
#   3. PyramidKernel 已上传；本脚本会在缺失时自动从 upload/pyramidkernel.tar 解包
set -o pipefail
# 注意：不能开 set -u。/opt/dtk/env.sh 会引用未定义的 CMAKE_PREFIX_PATH。
set +u

ROOT="${ROOT:-/root/dcudeploy}"
UP="${UP:-$ROOT/upload}"
BENCH="$ROOT/dcu-kernel-bench"
PK="$ROOT/PyramidKernel"

# 全量 / 小样例 / 单题
case "${MANIFEST:-all}" in
  all)     MANIFEST_PATH="$BENCH/benchmark/kernelbench_compat/manifest_dcukb.yaml" ;;
  smoke3)  MANIFEST_PATH="$BENCH/benchmark/kernelbench_compat/manifest_dcukb_smoke.yaml" ;;
  one)     # 单题试跑：2009_softmax（最简单的行级归约，且它有 aiter 基线可后续对比）
           MANIFEST_PATH="$ROOT/one.yaml"
           cat > "$MANIFEST_PATH" <<'YAML'
name: dcukb_one
backend: triton
tasks:
  - alias: 2009_softmax
    level: 2
    problem_id: 2009
YAML
           ;;
  *)       MANIFEST_PATH="$MANIFEST" ;;   # 允许直接给路径
esac

PROFILE="${PROFILE:-main}"      # main | quick | pyramidkernel_paper
SEARCH="${SEARCH:-main}"        # main | quick | main_flat
BACKEND="${BACKEND:-triton}"
PROVIDER="${PROVIDER:-openai-compatible}"
ROUTE="${ROUTE:-all_gpt}"
STAMP="$(date +%Y%m%d_%H%M%S)"
OUT="${OUT:-$ROOT/runs/dcukb_${MANIFEST:-all}_$STAMP}"

echo "=== 0. DTK 环境 ==="
if [ ! -f /opt/dtk/env.sh ]; then echo "  [FAIL] /opt/dtk/env.sh 不存在"; exit 1; fi
source /opt/dtk/env.sh
echo "  [ok] sourced /opt/dtk/env.sh"

echo
echo "=== 1. 部署包 ==="
if [ -d "$UP" ] && [ ! -d "$PK/pyramidkernel" ]; then
  if [ -f "$UP/pyramidkernel.tar" ]; then
    mkdir -p "$PK"
    tar -xf "$UP/pyramidkernel.tar" -C "$PK"
    echo "  [ok] 已解包 PyramidKernel -> $PK"
  else
    echo "  [FAIL] 找不到 $UP/pyramidkernel.tar，先跑 push.ps1 上传"; exit 1
  fi
fi
[ -d "$PK/pyramidkernel" ] || { echo "  [FAIL] $PK/pyramidkernel 不存在"; exit 1; }

# KernelBench：在线评测器要 `from kernelbench.eval import eval_kernel_against_ref`。
# 它是 PyramidKernel 的 submodule，git archive 不含，故单独用 kernelbench.tar 传。
if [ ! -d "$PK/KernelBench/src/kernelbench" ]; then
  if [ -f "$UP/kernelbench.tar" ]; then
    mkdir -p "$PK/KernelBench"
    tar -xf "$UP/kernelbench.tar" -C "$PK/KernelBench"
    echo "  [ok] 已解包 KernelBench -> $PK/KernelBench"
  else
    echo "  [FAIL] 缺 $UP/kernelbench.tar —— 在线评测会 import kernelbench 失败"; exit 1
  fi
fi
[ -d "$PK/KernelBench/src/kernelbench" ] || { echo "  [FAIL] $PK/KernelBench/src/kernelbench 不存在"; exit 1; }
echo "  [ok] KernelBench: $PK/KernelBench/src/kernelbench"
[ -f "$MANIFEST_PATH" ]    || { echo "  [FAIL] manifest 不存在: $MANIFEST_PATH"; exit 1; }
echo "  [ok] PyramidKernel: $PK"
echo "  [ok] manifest    : $MANIFEST_PATH  ($(grep -c '^\s*- alias:' "$MANIFEST_PATH") 题)"

echo
echo "=== 2. 环境变量 ==="
[ -f "$ROOT/env.sh" ] && source "$ROOT/env.sh" && echo "  [ok] sourced $ROOT/env.sh"
if [ -f "$ROOT/llm.env" ]; then
  source "$ROOT/llm.env"
  echo "  [ok] sourced $ROOT/llm.env (model=$OPENAI_MODEL)"
else
  echo "  [warn] 没有 $ROOT/llm.env —— 真 LLM 会失败。先 bash $UP/_setup_llm.sh"
fi
# 垫片必须在最前：真 aiter 有未编译扩展，直接 import 会崩。
# $PK/KernelBench/src 提供 `kernelbench` 包（在线评测器的 eval/timing）。
export PYTHONPATH="$ROOT/aiter_shim:$ROOT/py311deps:$PK:$PK/KernelBench/src:$BENCH:$PYTHONPATH"
# 避免 128 核上的线程超订（吃过 17 分钟 -> 3 分钟的教训）
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-8}"
export PYTHONUTF8=1
export PYTHONUNBUFFERED=1
echo "  [ok] PYTHONPATH 前置: $ROOT/aiter_shim:$ROOT/py311deps:$PK:$PK/KernelBench/src:$BENCH"
echo "  [ok] OMP_NUM_THREADS=$OMP_NUM_THREADS"

echo
echo "=== 3. 连通性自检 ==="
# 隧道探测：不要用 `ss` 判断（实测在容器里会假阴性——17890 明明能通却报未监听）。
# 直接打一次 API 的 /models，那才是真正决定能否生成的条件。
if [ -n "${OPENAI_BASE_URL:-}" ]; then
  python3 - <<'PY'
import json, os, ssl, sys, time, urllib.request
base = os.environ.get("OPENAI_BASE_URL", "")
key = os.environ.get("OPENAI_API_KEY", "")
proxy = os.environ.get("HTTPS_PROXY")
ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
op = urllib.request.build_opener(
    urllib.request.HTTPSHandler(context=ctx),
    urllib.request.ProxyHandler({"http": proxy, "https": proxy}) if proxy else urllib.request.ProxyHandler({}),
)
req = urllib.request.Request(base + "/models",
                             headers={"Authorization": f"Bearer {key}", "User-Agent": "curl/8.5.0"})
try:
    t0 = time.time()
    with op.open(req, timeout=40) as r:
        n = len(json.loads(r.read().decode())["data"])
    print(f"  [ok] API 可达：{base}/models -> HTTP 200, {n} 个模型, {time.time()-t0:.1f}s")
except Exception as exc:
    print(f"  [warn] API 不可达（生成会失败）: {type(exc).__name__}: {str(exc)[:160]}")
    print(f"         检查：本机 tunnel.ps1 是否在跑 / 代理 7890 是否可用")
PY
fi
python3 - <<'PY'
import os, sys
try:
    import torch
    print(f"  [ok] torch {torch.__version__}  cuda_available={torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"  [ok] arch = {torch.cuda.get_device_properties(0).gcnArchName}")
except Exception as exc:
    print(f"  [FAIL] torch: {exc}"); sys.exit(1)
try:
    import triton
    print(f"  [ok] triton {triton.__version__}")
except Exception as exc:
    print(f"  [FAIL] triton: {exc}")
try:
    from kernelbench.eval import eval_kernel_against_ref          # noqa: F401
    from kernelbench.timing import measure_ref_program_time      # noqa: F401
    print("  [ok] kernelbench.eval / kernelbench.timing 可导入（在线评测器依赖）")
except Exception as exc:
    print(f"  [FAIL] kernelbench 导入失败（在线评测会挂）: {exc}")
    sys.exit(1)
PY

echo
echo "=== 4. 跑生成评测 ==="
echo "  manifest : $MANIFEST_PATH"
echo "  profile  : $PROFILE   search: $SEARCH   backend: $BACKEND"
echo "  provider : $PROVIDER  route: $ROUTE"
echo "  output   : $OUT"
echo
cd "$PK" || exit 1
python3 -u -m pyramidkernel.cli run-kernelbench-batch \
  --experiment "$PROFILE" \
  --manifest "$MANIFEST_PATH" \
  --kernelbench-root "$BENCH/benchmark/kernelbench_compat" \
  --backend "$BACKEND" \
  --search-config "$SEARCH" \
  --provider "$PROVIDER" \
  --route-config "$ROUTE" \
  --env-file "$PK/.env" \
  --output-dir "$OUT"
rc=$?

echo
echo "=== 5. 结果 ==="
if [ -f "$OUT/summary.json" ]; then
  echo "  summary: $OUT/summary.json"
  python3 - "$OUT/summary.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1], encoding="utf-8"))
rows = d.get("rows") or []
ok = [r for r in rows if r.get("best_correct")]
print(f"  题数 {len(rows)}   correct {len(ok)}   失败 {len(rows) - len(ok)}")
sp = [r["speedup"] for r in ok if isinstance(r.get("speedup"), (int, float))]
if sp:
    print(f"  speedup: 中位数 {sorted(sp)[len(sp)//2]:.2f}x  最大 {max(sp):.2f}x")
for r in rows:
    if not r.get("best_correct"):
        print(f"    x {r.get('alias')}  {r.get('failure_stage')}/{r.get('failure_type')}")
PY
else
  echo "  [FAIL] 没有 summary.json（exit $rc）"
fi
exit $rc
