#!/usr/bin/env bash
# 并行跑全量：把 manifest 切成 N 片，起 N 个 batch 进程，各写自己的输出目录。
#
#   N=6 bash /root/dcudeploy/run_parallel.sh
#   N=8 RUN_ROOT=/root/dcudeploy/runs/dcukb_par2 bash /root/dcudeploy/run_parallel.sh
#   SKIP_ROOTS=/root/dcudeploy/runs/dcukb_all_20261016_113111 bash ...   # 跳过已完成的题
#
# 为什么能并行：整条链路是纯 LLM I/O 等待（实测 24 分钟仅 3 秒 CPU），
# 而机器有 128 核 / 504GB 内存 / 64GB 显存（实测空闲 63.7GB），所以外部多进程
# 几乎线性加速。各片写 <RUN_ROOT>/par_sNN/，题目录名由 alias/level/pid 决定，
# 片间不重叠故不会冲突。
#
# 注意：不能开 set -u（/opt/dtk/env.sh 引用未定义的 CMAKE_PREFIX_PATH）。
set -o pipefail
set +u

ROOT=/root/dcudeploy
BENCH=$ROOT/dcu-kernel-bench
PK=$ROOT/PyramidKernel
COMPAT=$BENCH/benchmark/kernelbench_compat
FULL="${FULL:-$COMPAT/manifest_dcukb.yaml}"

RUN_ROOT="${RUN_ROOT:-$ROOT/runs/dcukb_par}"
N="${N:-6}"
SKIP_ROOTS="${SKIP_ROOTS:-}"
PROFILE="${PROFILE:-main}"
SEARCH="${SEARCH:-main}"
ROUTE="${ROUTE:-all_gpt}"

source /opt/dtk/env.sh
source "$ROOT/env.sh"
[ -f "$ROOT/llm.env" ] && source "$ROOT/llm.env"
export PYTHONPATH="$ROOT/aiter_shim:$ROOT/py311deps:$PK:$PK/KernelBench/src:$BENCH:$PYTHONPATH"
export LITELLM_LOCAL_MODEL_COST_MAP=True
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-8}"
export PYTHONUTF8=1 PYTHONUNBUFFERED=1

mkdir -p "$RUN_ROOT"
echo "=== 并行跑 ${N} 片  $(date '+%F %T') ==="
echo "  run_root=$RUN_ROOT"
echo "  profile=$PROFILE search=$SEARCH route=$ROUTE"
echo "  skip_roots=$SKIP_ROOTS"

python3 "$ROOT/split_manifest.py" --full "$FULL" --n "$N" \
        --out-dir "$RUN_ROOT" --skip-roots "$SKIP_ROOTS" || exit 1

[ -d "$PK/KernelBench/src/kernelbench" ] || { echo "  [FAIL] KernelBench 未解包"; exit 1; }
cd "$PK" || exit 1

echo
echo "=== 启动 ==="
# 注意：不能用 `seq -w 1 $N` —— 最大值为个位数时 seq -w 不补零（会得到 1..6，
# 而分片文件名是 shard_01..shard_06），导致全部 continue 跳过、一个进程都起不来。
for i in $(seq 1 "$N"); do
  ii=$(printf '%02d' "$i")
  SD="$RUN_ROOT/shard_$ii.yaml"
  [ -f "$SD" ] || { echo "  [skip] 缺 $SD"; continue; }
  OUT="$RUN_ROOT/par_s$ii"
  mkdir -p "$OUT"
  nohup python3 -u -m pyramidkernel.cli run-kernelbench-batch \
      --experiment "$PROFILE" \
      --manifest "$SD" \
      --kernelbench-root "$COMPAT" \
      --backend triton \
      --search-config "$SEARCH" \
      --provider openai-compatible \
      --route-config "$ROUTE" \
      --env-file "$PK/.env" \
      --output-dir "$OUT" >> "$RUN_ROOT/par_s$ii.log" 2>&1 &
  echo "  [started] shard $ii -> $OUT   pid=$!"
  sleep 2
done

echo
echo "=== 已启动，日志：$RUN_ROOT/par_s*.log ==="
echo "=== 查看进度：bash /root/dcudeploy/parallel_status.sh ==="
