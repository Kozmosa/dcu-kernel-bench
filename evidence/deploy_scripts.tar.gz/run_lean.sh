#!/usr/bin/env bash
# 跑 B 臂：精简题面（只留摘要 + I/O 契约 + 禁用列表 + 硬件 + 一句锚点规则）。
# 与 run_parallel.sh 的唯一区别是 --kernelbench-root 指向 lean 题面树，
# manifest 用 manifest_lean.yaml，输出落到独立 run root，A 臂的数据不受影响。
#
#   bash /root/dcudeploy/run_lean.sh            # 16 分片全量 66 道
#   N=4 bash /root/dcudeploy/run_lean.sh        # 小规模先验
set -o pipefail
set +u

ROOT=/root/dcudeploy
LEAN=$ROOT/lean/benchmark                 # 精简题面树（tasks/ + kernelbench_compat/ + manifest_lean.yaml）
COMPAT=$LEAN/kernelbench_compat
PK=$ROOT/PyramidKernel
FULL=${FULL:-$LEAN/manifest_lean.yaml}
RUN_ROOT=${RUN_ROOT:-$ROOT/runs/dcukb_lean_$(date +%m%d_%H%M)}
N=${N:-16}

source /opt/dtk/env.sh
source "$ROOT/env.sh"
[ -f "$ROOT/llm.env" ] && source "$ROOT/llm.env"
export PYTHONPATH="$ROOT/aiter_shim:$ROOT/py311deps:$PK:$PK/KernelBench/src:$LEAN:$ROOT/dcu-kernel-bench:$PYTHONPATH"
export LITELLM_LOCAL_MODEL_COST_MAP=True
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-8}"
export PYTHONUTF8=1 PYTHONUNBUFFERED=1

echo "=== B 臂（精简题面） $(date '+%F %T')"
echo "  lean     : $LEAN"
echo "  compat   : $COMPAT"
echo "  manifest : $FULL"
echo "  run_root : $RUN_ROOT   shards=$N"

[ -d "$COMPAT" ] || { echo "  [FAIL] 缺 $COMPAT —— 先上传精简题面树"; exit 1; }
[ -f "$FULL" ]   || { echo "  [FAIL] 缺 $FULL"; exit 1; }

code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 25 -x "$HTTPS_PROXY" \
            "$OPENAI_BASE_URL/models" -H "Authorization: Bearer $OPENAI_API_KEY")
echo "  preflight API HTTP $code"
[ "$code" = "200" ] || { echo "  [FAIL] 隧道/API 不可用，不启动"; exit 3; }

mkdir -p "$RUN_ROOT"
python3 "$ROOT/split_manifest.py" --full "$FULL" --n "$N" --out-dir "$RUN_ROOT" || exit 1

cd "$PK" || exit 1
for i in $(seq 1 "$N"); do
  ii=$(printf '%02d' "$i")
  SD="$RUN_ROOT/shard_$ii.yaml"
  [ -f "$SD" ] || { echo "  [skip] 缺 $SD"; continue; }
  OUT="$RUN_ROOT/par_s$ii"
  mkdir -p "$OUT"
  nohup python3 -u -m pyramidkernel.cli run-kernelbench-batch \
      --experiment main \
      --manifest "$SD" \
      --kernelbench-root "$COMPAT" \
      --backend triton \
      --search-config main \
      --provider openai-compatible \
      --route-config all_gpt \
      --env-file "$PK/.env" \
      --output-dir "$OUT" >> "$RUN_ROOT/par_s$ii.log" 2>&1 &
  echo "  [started] shard $ii -> $OUT pid=$!"
  sleep 2
done
echo "=== 已启动 $(date '+%F %T')，日志 $RUN_ROOT/par_s*.log"
