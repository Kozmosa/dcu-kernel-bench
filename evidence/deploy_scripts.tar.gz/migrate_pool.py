"""把各分片已有的 long_term_memory.json 合并进共享池（去重）。

用法：python3 migrate_pool.py <r3 根目录>
产出：<r3>/pools/memory_pool_<profile>_<track>.json
"""
import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
DEDUPE = ("task_name", "strategy", "outcome", "failure_type", "speedup", "lesson")
MAX = 512


def read(path: Path) -> list:
    try:
        return list(json.loads(path.read_text(encoding="utf-8")).get("entries") or [])
    except (OSError, ValueError):
        return []


def main() -> int:
    pools = {}
    for journal in sorted((ROOT / "groups").glob("*/*/shard*/long_term_memory.json")):
        profile, track = journal.parts[-4], journal.parts[-3]
        entries = read(journal)
        key = (profile, track)
        pools.setdefault(key, [])
        pools[key].extend(entries)
        print("%-58s %3d 条" % (str(journal.relative_to(ROOT)), len(entries)))

    out_dir = ROOT / "pools"
    out_dir.mkdir(exist_ok=True)
    for (profile, track), entries in sorted(pools.items()):
        seen, kept = set(), []
        for entry in entries:
            k = tuple(str(entry.get(x)) for x in DEDUPE)
            if k in seen:
                continue
            seen.add(k)
            kept.append(entry)
        kept = kept[-MAX:]
        path = out_dir / ("memory_pool_%s_%s.json" % (profile, track))
        path.write_text(json.dumps({"version": 1, "entries": kept}, indent=2, ensure_ascii=False),
                        encoding="utf-8", newline="\n")
        print("池 %-40s 原始 %3d 条 -> 去重后 %3d 条" % (path.name, len(entries), len(kept)))
    if not pools:
        print("没有找到任何分片日志")
    return 0


if __name__ == "__main__":
    sys.exit(main())
