#!/bin/bash
# 全新开跑：清空结果与记忆（旧的 38 题已备份成 tar），启用共享记忆池，9 并发。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
pkill -9 -f supervise_r3.py 2>/dev/null
pkill -9 -f run-kernelbench-batch 2>/dev/null
sleep 2

rm -rf "$ROOT/groups" "$ROOT/pools" "$ROOT/partial" "$ROOT/status_resume.json" "$ROOT/_pool_worker.py"
rm -f "$ROOT"/logs/*.log "$ROOT"/logs/*.out
mkdir -p "$ROOT/groups" "$ROOT/logs" "$ROOT/reports"

source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
export OPENAI_HTTP_STREAM=1
export R3_MAX_CONCURRENT=${R3_MAX_CONCURRENT:-9}
export R3_MEM_GUARD_GB=${R3_MEM_GUARD_GB:-25}

cd "$ROOT" || exit 1
setsid nohup python3 -u supervise_r3.py --profiles d > logs/supervisor_fresh.out 2>&1 < /dev/null &
sleep 12

echo "run.json=$(find groups -name run.json 2>/dev/null | wc -l)"
echo "batch=$(ps -eo args | grep -c '[r]un-kernelbench-batch')"
echo "--- supervisor 前几行:"
head -8 logs/supervisor_fresh.out
