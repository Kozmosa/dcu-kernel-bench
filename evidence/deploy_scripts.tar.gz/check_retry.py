"""验证重试判定：过载类可重试、余额类致命、连接类可重试。"""
import sys

sys.path.insert(0, "/root/dcudeploy/kw_full_b_d_20261101_r3/KernelWeaver")
from src.providers.openai_provider import (  # noqa: E402
    _is_fatal_billing_error,
    _is_retryable_llm_error,
)

cases = [
    "LLM request failed: Our servers are currently overloaded. Please try again later.",
    "LLM request failed: HTTP 403: insufficient balance",
    "LLM request failed: Connection error: Connection error.",
    "LLM request failed: HTTP 400: bad request",
]
for c in cases:
    exc = RuntimeError(c)
    print("%-14s %-8s %s" % ("retryable" if _is_retryable_llm_error(exc) else "no-retry",
                             "billing" if _is_fatal_billing_error(exc) else "", c[:64]))
