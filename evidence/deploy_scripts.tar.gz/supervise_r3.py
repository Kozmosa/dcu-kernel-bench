"""r3 断点续跑控制器：2 配置 × 2 轨 × 4 分片 = 16 条流，全部可续跑。

要点
  1. 已完成任务 = 该分片输出目录里存在 <task>/run.json；重启时自动剔除，只跑剩下的。
  2. 每条流独立进程、独立 manifest（连续切分）、独立长期记忆日志。
  3. 起流前做 API 探活（curl /models == 200），隧道断了就先等，等不恢复不启新进程。
  4. 流异常退出按指数退避重启；连续崩溃超过阈值才把该流标记 blocked，不影响其它流。

用法
  前台：python3 supervise_r3.py            （Ctrl-C 停止；再启动即续跑）
  后台：nohup python3 supervise_r3.py > logs/supervisor.out 2>&1 &
  只读：python3 supervise_r3.py --status
"""
import argparse
import json
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent
CODE = ROOT / "KernelWeaver"
sys.path.insert(0, str(CODE))

ALL_PROFILES = {"b": "dcu_b_longterm", "d": "dcu_d_combined"}
PROFILES = list(ALL_PROFILES.values())
TRACKS = ["hip", "triton"]
SHARDS = 16
MAX_ATTEMPTS = int(os.environ.get("R3_MAX_ATTEMPTS", "10"))
PROXY = "http://127.0.0.1:17890"
HEALTH_EVERY = 60
MEM_GUARD_GB = float(os.environ.get("R3_MEM_GUARD_GB", "20"))
MEM_KILL_GB = float(os.environ.get("R3_MEM_KILL_GB", "50"))   # cgroup 已用超过此值就杀掉最新起的一条流，防止整容器 OOM   # cgroup 剩余内存低于此值不再起新流
DEFAULT_MAX_CONCURRENT = int(os.environ.get("R3_MAX_CONCURRENT", "6"))
MAX_CRASHES = 6

ENV_BASE = dict(
    os.environ,
    OPENAI_HTTP_TRANSPORT="sdk",
    OPENAI_WIRE_API="chat_completions",
    PYTHONHASHSEED="0",
    MALLOC_ARENA_MAX="2",              # 多进程时抑制 glibc arena 膨胀（每进程最多 2 个 arena）
    MALLOC_TRIM_THRESHOLD_="131072",
    CUDA_VISIBLE_DEVICES="0",
)
ENV_BASE["PYTHONPATH"] = "/root/dcudeploy/PyramidKernel/KernelBench/src:" + ENV_BASE.get("PYTHONPATH", "")

STATE_PATH = ROOT / "status_resume.json"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def slots():
    """按分片轮转，保证两轨交替起流（否则 16 个同轨分片会占满并发，另一轨永远轮不到）。"""
    for k in range(1, SHARDS + 1):
        for profile in PROFILES:
            for track in TRACKS:
                yield profile, track, k


def slot_key(profile: str, track: str, k: int) -> str:
    return "%s|%s|s%d" % (profile, track, k)


def out_dir(profile: str, track: str, k: int) -> Path:
    return ROOT / "groups" / profile / track / ("shard%d" % k)


def shard_tasks(track: str, k: int) -> list:
    path = ROOT / ("manifest_%s_s%d.yaml" % (track, k))
    return yaml.safe_load(path.read_text(encoding="utf-8"))["tasks"]


def task_dir(profile: str, track: str, k: int, item) -> Path:
    from src.experiment import batch_output_dir_name
    return out_dir(profile, track, k) / batch_output_dir_name(item["alias"], item["level"], item["problem_id"])


def done_tasks(profile: str, track: str, k: int) -> list:
    done = []
    for item in shard_tasks(track, k):
        if (task_dir(profile, track, k, item) / "run.json").exists():
            done.append(item["alias"])
    return done


def write_manifest(profile: str, track: str, k: int, items: list, rnd: int) -> Path:
    man_dir = ROOT / "manifests"
    man_dir.mkdir(exist_ok=True)
    src = yaml.safe_load((ROOT / ("manifest_%s_s%d.yaml" % (track, k))).read_text(encoding="utf-8"))
    payload = {"name": "%s_r%d" % (src.get("name", track), rnd),
               "backend": src.get("backend", items[0].get("backend")),
               "tasks": items}
    path = man_dir / ("%s_%s_s%d_r%d.yaml" % (profile, track, k, rnd))
    with path.open("w", encoding="utf-8", newline="\n") as fh:
        yaml.safe_dump(payload, fh, sort_keys=False, allow_unicode=True)
    return path


def mem_available_gb() -> float:
    """返回 cgroup 里还能用的内存（GB）。

    容器的 `free` 显示的是宿主机内存，cgroup v2 才是真实配额；
    优先读 cgroup，读不到再退回 /proc/meminfo。
    """
    try:
        limit = open("/sys/fs/cgroup/memory.max", encoding="utf-8").read().strip()
        used = int(open("/sys/fs/cgroup/memory.current", encoding="utf-8").read().strip())
        if limit.isdigit():
            return (int(limit) - used) / 1024 ** 3
    except Exception:  # noqa: BLE001
        pass
    try:
        for line in open("/proc/meminfo", encoding="utf-8"):
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) / 1024 / 1024
    except Exception:  # noqa: BLE001
        pass
    return -1.0


def mem_used_gb() -> float:
    """cgroup 当前已用内存（GB）。"""
    try:
        used = int(open("/sys/fs/cgroup/memory.current", encoding="utf-8").read().strip())
        return used / 1024 ** 3
    except Exception:  # noqa: BLE001
        return -1.0


def api_healthy(timeout: int = 60, tries: int = 3) -> bool:
    """探活：任何 HTTP 响应都算通，只有连续 tries 次连接类失败才判不通。

    /models 的响应体较大，慢的时候会读超时；用 -o /dev/null 也可能触发读超时，
    所以这里只要求拿到状态码，且容忍偶发失败（避免把正常链路判死、卡住整个调度）。
    """
    key = os.environ.get("OPENAI_API_KEY", "")
    url = os.environ.get("OPENAI_BASE_URL", "https://www.hejuapi.com/v1").rstrip("/") + "/models"
    for attempt in range(tries):
        try:
            out = subprocess.run(
                ["curl", "-sS", "-o", "/dev/null", "-w", "%{http_code}", "--max-time", str(timeout),
                 "-x", PROXY, "-H", "Authorization: Bearer " + key, url],
                capture_output=True, text=True, timeout=timeout + 10)
            code = (out.stdout or "").strip()
            if code and code != "000":
                return True
        except Exception:  # noqa: BLE001
            pass
        if attempt + 1 < tries:
            time.sleep(5)
    return False


def build_cmd(manifest: Path, profile: str, track: str, k: int) -> list:
    directory = out_dir(profile, track, k)
    return [sys.executable, "-u", "-m", "src.cli", "run-kernelbench-batch",
            "--experiment", "main", "--provider", "openai-compatible", "--route-config", "all_gpt",
            "--backend", "cuda" if track == "hip" else "triton",
            "--runtime-config", "gpu_single", "--search-config", profile,
            "--max-attempts", str(MAX_ATTEMPTS), "--evaluator-config", "main",
            "--measurement-config", "main",
            "--manifest", str(manifest),
            "--kernelbench-root", str(ROOT / "tasks" / track / "kernelbench_compat"),
            "--output-dir", str(directory), "--verbose"]


def launch(profile: str, track: str, k: int, items: list, rnd: int) -> subprocess.Popen:
    manifest = write_manifest(profile, track, k, items, rnd)
    directory = out_dir(profile, track, k)
    directory.mkdir(parents=True, exist_ok=True)
    log = open(ROOT / "logs" / ("%s_%s_s%d.log" % (profile, track, k)), "a", buffering=1)
    log.write("\n===== [%s] round %d: %d tasks (%s)\n" % (now(), rnd, len(items),
                                                         ",".join(i["alias"] for i in items[:3]) + ("..." if len(items) > 3 else "")))
    log.flush()
    pool = ROOT / "pools" / ("memory_pool_%s_%s.json" % (profile, track))
    pool.parent.mkdir(parents=True, exist_ok=True)
    env = dict(ENV_BASE,
               KW_MEMORY_POOL=str(pool),
               PYRAMID_COST_LOG=str(directory / "http_events.jsonl"),
               PYRAMID_COST_METHOD="%s_%s_s%d" % (profile, track, k))
    cmd = build_cmd(manifest, profile, track, k)
    (ROOT / "logs" / ("%s_%s_s%d_command_r%d.json" % (profile, track, k, rnd))).write_text(
        json.dumps(cmd, indent=2), encoding="utf-8")
    return subprocess.Popen(cmd, cwd=str(CODE), env=env, stdout=log, stderr=subprocess.STDOUT,
                            start_new_session=True)


def load_state() -> dict:
    if STATE_PATH.exists():
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    return {"created_utc": now(), "slots": {}, "supervisor_pid": None}


def save_state(state: dict) -> None:
    state["heartbeat_utc"] = now()
    tmp = STATE_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(STATE_PATH)


def status() -> None:
    state = load_state()
    total_done = 0
    for profile, track, k in slots():
        key = slot_key(profile, track, k)
        done = len(done_tasks(profile, track, k))
        total = len(shard_tasks(track, k))
        total_done += done
        info = state["slots"].get(key, {})
        print("%-16s %-6s s%d  %2d/%-2d  status=%-9s pid=%s round=%s"
              % (profile, track, k, done, total, info.get("status", "pending"),
                 info.get("pid"), info.get("round", 0)))
    total_tasks = sum(len(shard_tasks(t, k)) for _, t, k in slots())
    print("TOTAL done=%d/%d" % (total_done, total_tasks))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--once", action="store_true", help="只起一轮，不等完成（冒烟用）")
    parser.add_argument("--max-tasks", type=int, default=0, help="冒烟用：每个分片最多取 N 题")
    parser.add_argument("--dry-run", action="store_true", help="只打印将要执行的命令，不启动")
    parser.add_argument("--profiles", default="b,d", help="要跑的组：b=记忆, d=记忆+Wiki, 或用逗号组合")
    parser.add_argument("--max-concurrent", type=int, default=DEFAULT_MAX_CONCURRENT,
                        help="同时最多跑几条流（0=不限，默认就是全开：16 分片×4 组=64）")
    args = parser.parse_args()
    global PROFILES
    wanted = [x.strip() for x in str(args.profiles).split(",") if x.strip()]
    bad = [w for w in wanted if w not in ALL_PROFILES]
    if bad:
        print("未知组:", bad, "可选 b / d")
        return 2
    PROFILES = [ALL_PROFILES[w] for w in wanted] if wanted else list(ALL_PROFILES.values())
    if args.status:
        status()
        return 0
    if args.dry_run:
        for profile, track, k in slots():
            todo = [i for i in shard_tasks(track, k) if i["alias"] not in done_tasks(profile, track, k)]
            man = ROOT / "manifests" / ("%s_%s_s%d_r1.yaml" % (profile, track, k))
            print("%-42s todo=%2d  %s" % (slot_key(profile, track, k), len(todo),
                                          " ".join(build_cmd(man, profile, track, k)[-8:])))
        print("总槽位:", len(list(slots())))
        return 0

    state = load_state()
    state["supervisor_pid"] = os.getpid()
    procs: dict = {}
    launch_order: list = []
    crashes: dict = {slot_key(*s): 0 for s in slots()}
    rounds: dict = {}
    save_state(state)
    stop = {"flag": False}

    def _term(signum, frame):
        stop["flag"] = True
    signal.signal(signal.SIGTERM, _term)
    signal.signal(signal.SIGINT, _term)

    if not api_healthy():
        print("API 不健康（隧道/代理没通），先等待恢复 ...", flush=True)
        while not stop["flag"] and not api_healthy():
            time.sleep(15)
        if stop["flag"]:
            return 130
    print("API 探活 OK，开始运行", flush=True)

    last_health = time.time()
    while not stop["flag"]:
        used = mem_used_gb()
        if 0 < used > MEM_KILL_GB and launch_order:
            victim = launch_order[-1]
            proc = procs.get(victim)
            if proc is not None and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                except OSError:
                    pass
                print("[mem-kill] 已用 %.1f GB > %.0f GB，杀掉最新起的流 %s，稍后续跑" % (used, MEM_KILL_GB, victim),
                      flush=True)
                procs.pop(victim, None)
                state["slots"].setdefault(victim, {})["status"] = "pending"
            launch_order.pop()
        alive = 0
        for profile, track, k in slots():
            key = slot_key(profile, track, k)
            proc = procs.get(key)
            if proc is not None and proc.poll() is None:
                alive += 1
                continue
            if proc is not None:
                code = proc.returncode
                state["slots"].setdefault(key, {})["last_exit_code"] = code
                if code == 0:
                    crashes[key] = 0
                else:
                    crashes[key] += 1
                procs.pop(key, None)
            info = state["slots"].setdefault(key, {})
            if info.get("status") == "blocked":
                continue
            todo = [i for i in shard_tasks(track, k) if i["alias"] not in done_tasks(profile, track, k)]
            if args.max_tasks:
                todo = todo[:args.max_tasks]
            if not todo:
                info.update(status="finished", finished_utc=now())
                continue
            if crashes[key] >= MAX_CRASHES:
                info.update(status="blocked", reason="too many crashes")
                print("[blocked] %s 连续崩溃 %d 次，跳过" % (key, crashes[key]), flush=True)
                continue
            if time.time() - last_health > HEALTH_EVERY:
                if not api_healthy():
                    print("[wait] API 不通，暂不启动新流", flush=True)
                    time.sleep(15)
                    continue
                last_health = time.time()
            if args.max_concurrent and alive >= args.max_concurrent:
                continue
            free_gb = mem_available_gb()
            if 0 < free_gb < MEM_GUARD_GB:
                print("[mem] 可用内存 %.1f GB < %.0f GB，暂不启动新流" % (free_gb, MEM_GUARD_GB), flush=True)
                break
            rounds[key] = rounds.get(key, info.get("round", 0)) + 1
            proc = launch(profile, track, k, todo, rounds[key])
            launch_order.append(key)
            procs[key] = proc
            info.update(status="running", pid=proc.pid, round=rounds[key], remaining=len(todo))
            alive += 1
            print("[start] %-42s %2d tasks round %d pid=%d" % (key, len(todo), rounds[key], proc.pid),
                  flush=True)
        for key, info in state["slots"].items():
            if info.get("status") == "running" and key not in procs:
                info["status"] = "finished" if info.get("last_exit_code") == 0 else "failed"
        done_total = sum(len(done_tasks(p, t, k)) for p, t, k in slots())
        state["completed_total"] = done_total
        save_state(state)
        if args.once and alive == 0:
            break
        if alive == 0:
            for profile, track, k in slots():
                key = slot_key(profile, track, k)
                info = state["slots"].setdefault(key, {})
                if info.get("status") not in ("finished", "blocked"):
                    break
            else:
                break
        time.sleep(20)

    if stop["flag"]:
        print("收到停止信号，终止子进程 ...", flush=True)
        for key, proc in procs.items():
            if proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except OSError:
                    pass
        time.sleep(3)
    state["completed_total"] = sum(len(done_tasks(p, t, k)) for p, t, k in slots())
    save_state(state)
    print("supervisor 退出：completed=%d/264" % state["completed_total"], flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
