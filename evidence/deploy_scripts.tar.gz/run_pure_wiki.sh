#!/bin/bash
# 纯 API + DCU Wiki 对照臂：一次调用 + 注入 Wiki，8 并发，两轨顺序跑。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
export PYTHONPATH=/root/dcudeploy/PyramidKernel/KernelBench/src:${PYTHONPATH:-}
cd "$ROOT" || exit 1

pkill -9 -f pure_bench.py 2>/dev/null
sleep 2
rm -rf pure_wiki
mkdir -p pure_wiki logs

for track in hip triton; do
  backend=cuda; [ "$track" = "triton" ] && backend=triton
  echo "=== pure+wiki $track 开始 $(date +%H:%M:%S)"
  python3 -u pure_bench.py \
      --manifest "manifest_$track.yaml" \
      --kernelbench-root "tasks/$track/kernelbench_compat" \
      --backend "$backend" \
      --out "pure_wiki/$track" --workers 8 --wiki \
      > "logs/pure_wiki_$track.log" 2>&1
  echo "=== pure+wiki $track 结束 $(date +%H:%M:%S) exit=$? 完成=$(find pure_wiki/$track -name run.json 2>/dev/null | wc -l)"
done

echo "=== 两轨完成，开始离线终审 $(date +%H:%M:%S)"
for t in hip triton; do
  python3 -u metric_tools/audit_batch.py --run-root "pure_wiki/$t" --manifest "manifest_$t.yaml" \
      --impl aiter --timeout 900 > "reports/pure_wiki_audit_$t.log" 2>&1 &
done
wait
echo "=== 全部完成 $(date +%H:%M:%S)"
