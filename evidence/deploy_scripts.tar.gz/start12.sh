#!/bin/bash
# 并发提到 12（保留已完成题，续跑）。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$ROOT" || exit 1

pkill -TERM -f supervise_r3.py 2>/dev/null
sleep 5
pkill -9 -f run-kernelbench-batch 2>/dev/null
sleep 2
pgrep -f supervise_r3.py >/dev/null && { echo "仍有 supervisor，强制清理"; pkill -9 -f supervise_r3.py; sleep 2; }

export OPENAI_HTTP_STREAM=1
export OPENAI_MAX_RETRIES=6
export OPENAI_RETRY_BACKOFF_SECONDS=3
export R3_MAX_CONCURRENT=12
export R3_MEM_GUARD_GB=20

setsid nohup python3 -u supervise_r3.py --profiles d > logs/supervisor12.out 2>&1 < /dev/null &
sleep 15
echo "sup=$(ps -eo args | grep -c '[s]upervise_r3.py') batch=$(ps -eo args | grep -c '[r]un-kernelbench-batch')"
head -4 logs/supervisor12.out
