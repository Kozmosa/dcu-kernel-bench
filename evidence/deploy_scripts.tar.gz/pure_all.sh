#!/bin/bash
# 纯 API 直出基线（自包含）：清残留 → HIP 66 题 → Triton 66 题 → 写状态文件。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
export PYTHONPATH=/root/dcudeploy/PyramidKernel/KernelBench/src:${PYTHONPATH:-}
cd "$ROOT" || exit 1

pkill -f pure_bench.py 2>/dev/null
sleep 2
rm -rf pure
mkdir -p pure reports
: > reports/pure_status.txt

for track in hip triton; do
  backend=cuda; [ "$track" = "triton" ] && backend=triton
  echo "start $track $(date +%H:%M:%S)" >> reports/pure_status.txt
  python3 -u pure_bench.py \
      --manifest "manifest_$track.yaml" \
      --kernelbench-root "tasks/$track/kernelbench_compat" \
      --backend "$backend" \
      --out "pure/$track" --workers 6 \
      > "reports/pure_$track.log" 2>&1
  rc=$?
  echo "end $track $(date +%H:%M:%S) exit=$rc done=$(find pure/$track -name run.json 2>/dev/null | wc -l)" >> reports/pure_status.txt
done
echo "ALL DONE $(date +%H:%M:%S)" >> reports/pure_status.txt
