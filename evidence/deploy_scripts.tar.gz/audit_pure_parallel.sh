#!/bin/bash
# 离线终审（纯 API 组）：两轨并行，缓存自动跳过已审题。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$ROOT" || exit 1

for t in hip triton; do
  nohup python3 -u metric_tools/audit_batch.py \
      --run-root "pure_norm/$t" --manifest "manifest_$t.yaml" \
      --impl aiter --timeout 900 \
      > "reports/pure_audit2_$t.log" 2>&1 &
done

echo "启动 $(date +%H:%M:%S)，两轨并行"
wait
echo "完成 $(date +%H:%M:%S)"
for t in hip triton; do
  echo "$t: $(ls pure_norm/$t/offline_audit/*.json 2>/dev/null | wc -l)/66"
done
