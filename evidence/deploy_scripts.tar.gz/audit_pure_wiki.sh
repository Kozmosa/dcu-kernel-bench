#!/bin/bash
# 规范化 pure_wiki 目录名并做离线终审，然后与纯 API(无 Wiki) 对比。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
cd "$ROOT" || exit 1

python3 - <<'PY'
import shutil, sys, yaml
from pathlib import Path
sys.path.insert(0, "/root/dcudeploy/kw_full_b_d_20261101_r3/KernelWeaver")
from src.experiment import batch_output_dir_name

root = Path("/root/dcudeploy/kw_full_b_d_20261101_r3")
for track in ("hip", "triton"):
    src_root = root / "pure_wiki" / track
    dst_root = root / "pure_wiki_norm" / track
    if dst_root.exists():
        shutil.rmtree(dst_root)
    dst_root.mkdir(parents=True)
    tasks = yaml.safe_load((root / f"manifest_{track}.yaml").read_text())["tasks"]
    n = 0
    for item in tasks:
        src = src_root / item["alias"]
        if not (src / "run.json").exists():
            continue
        dst = dst_root / batch_output_dir_name(item["alias"], item["level"], item["problem_id"])
        dst.mkdir()
        for f in ("run.json", "best_code.py"):
            if (src / f).exists():
                shutil.copy2(src / f, dst / f)
        n += 1
    print(f"{track}: 规范化 {n} 题")
PY

for t in hip triton; do
  python3 -u metric_tools/audit_batch.py --run-root "pure_wiki_norm/$t" --manifest "manifest_$t.yaml" \
      --impl aiter --timeout 900 > "reports/pure_wiki_audit_$t.log" 2>&1 &
done
wait
echo "审计完成 $(date +%H:%M:%S)"

python3 - <<'PY'
import glob, json, re
from pathlib import Path
root = Path("/root/dcudeploy/kw_full_b_d_20261101_r3")
def key(s):
    m = re.search(r"(\d{4})", str(s or ""))
    return m.group(1) if m else str(s)
def breakdown(label, pattern):
    passed = static_fail = other = 0
    for p in glob.glob(str(root / pattern)):
        d = json.load(open(p))
        if not d.get("static_audit_passed"):
            static_fail += 1
        elif d.get("correctness_passed") is True:
            passed += 1
        else:
            other += 1
    print("%-22s 离线通过 %2d | 静态违规 %2d | 数值/编译不过 %2d" % (label, passed, static_fail, other))
breakdown("纯API+Wiki HIP", "pure_wiki_norm/hip/offline_audit/*.json")
breakdown("纯API+Wiki Triton", "pure_wiki_norm/triton/offline_audit/*.json")
breakdown("纯API HIP（无Wiki）", "pure_norm/hip/offline_audit/*.json")
breakdown("纯API Triton（无Wiki）", "pure_norm/triton/offline_audit/*.json")
breakdown("框架v2 HIP", "final2/hip/offline_audit/*.json")
breakdown("框架v2 Triton(主跑)", "final2/triton/offline_audit/*.json")
PY
