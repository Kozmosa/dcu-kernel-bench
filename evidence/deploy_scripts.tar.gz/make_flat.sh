#!/usr/bin/env bash
# Build the flat symlink farm that benchmark/evaluator/audit_batch.py requires:
#   <flat>/<task-alias-like-dir>/best_code.py
# Sources are sharded run roots (<root>/par_sNN/<task>_lN_pNNNN). Newest wins, so a
# later retry run overrides an earlier degraded result for the same task.
set +u
FLAT=${1:-/root/dcudeploy/runs/dcukb_en_flat}
shift || true
ROOTS=${*:-"/root/dcudeploy/runs/dcukb_en_1019_1027 /root/dcudeploy/runs/dcukb_en_rerun_1019_1240"}

# 注意：offline_audit 缓存也放在 $FLAT 下，rm -rf 会把 66 道题的终审缓存一起删掉
# （2026-10-20 踩过：重建软链农场后缓存从 66 掉到 35）。先搬走再恢复。
CACHE_BAK=""
if [ -d "$FLAT/offline_audit" ]; then
  CACHE_BAK=$(mktemp -d)
  cp -a "$FLAT/offline_audit" "$CACHE_BAK/" 2>/dev/null
  [ -f "$FLAT/offline_audit.json" ] && cp -a "$FLAT/offline_audit.json" "$CACHE_BAK/"
fi
rm -rf "$FLAT"
mkdir -p "$FLAT"
if [ -n "$CACHE_BAK" ] && [ -d "$CACHE_BAK/offline_audit" ]; then
  cp -a "$CACHE_BAK/offline_audit" "$FLAT/"
  [ -f "$CACHE_BAK/offline_audit.json" ] && cp -a "$CACHE_BAK/offline_audit.json" "$FLAT/"
  rm -rf "$CACHE_BAK"
  echo "  (restored offline_audit cache)"
fi
for r in $ROOTS; do
  [ -d "$r" ] || { echo "  [skip] $r"; continue; }
  for d in "$r"/par_s*/*_l*_p*; do
    [ -d "$d" ] || continue
    name=$(basename "$d")
    if [ -e "$FLAT/$name" ]; then
      # newer run for the same task: replace only if it is indeed newer
      if [ "$d" -nt "$FLAT/$name" ]; then
        rm -f "$FLAT/$name"
        ln -s "$d" "$FLAT/$name"
      fi
    else
      ln -s "$d" "$FLAT/$name"
    fi
  done
done
echo "  flat: $FLAT"
echo "  tasks: $(find "$FLAT" -maxdepth 1 -mindepth 1 -type l | wc -l)"
echo "  with best_code.py: $(find "$FLAT" -maxdepth 2 -name best_code.py 2>/dev/null | wc -l)"
