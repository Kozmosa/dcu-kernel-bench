#!/bin/bash
# 对 pure（纯 API 直出）两个轨做离线终审：静态审计 → 隐藏 case → 性能。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$ROOT" || exit 1

for t in hip triton; do
  echo "=== pure 终审 $t $(date +%H:%M:%S)"
  python3 -u metric_tools/audit_batch.py \
      --run-root "pure/$t" --manifest "manifest_$t.yaml" \
      --impl aiter --timeout 1800 > "reports/pure_audit_$t.log" 2>&1
  echo "  exit=$? $(date +%H:%M:%S)"
done
echo "PURE AUDIT DONE $(date +%H:%M:%S)"
