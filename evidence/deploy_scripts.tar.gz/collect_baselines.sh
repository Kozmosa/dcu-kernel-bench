#!/usr/bin/env bash
# collect_baselines.sh —— 逐题采集 aiter 官方基线
#
# 用法：
#   bash collect_baselines.sh 2xxx                 # 先做 2xxx 号段（9 题，风险最低）
#   bash collect_baselines.sh 2xxx 1xxx            # 多段
#   bash collect_baselines.sh 2007_rmsnorm 2008_rope
#   bash collect_baselines.sh all
#   DRY=1 bash collect_baselines.sh 2xxx           # 只校验不写回
#
# 采到的基线写入 benchmark/private/<id>/baseline.json。
# 采集器会**先与 reference 按 task.yaml 容差比对通过才记录**，不通过则拒收。
# 不能开 set -u：/opt/dtk/env.sh 引用未定义变量
set -o pipefail

ROOT="${ROOT:-/root/dcudeploy}"
# shellcheck disable=SC1091
source "$ROOT/env.sh"
REPO="$ROOT/dcu-kernel-bench"
cd "$REPO"

DRED=$'\033[31m'; DGRN=$'\033[32m'; DYLW=$'\033[33m'; DOFF=$'\033[0m'
ok(){ printf '  %s[ok]%s   %s\n' "$DGRN" "$DOFF" "$*"; }
bad(){ printf '  %s[FAIL]%s %s\n' "$DRED" "$DOFF" "$*"; }
wrn(){ printf '  %s[warn]%s %s\n' "$DYLW" "$DOFF" "$*"; }

[ $# -gt 0 ] || { echo "用法: $0 <号段|任务id>...  例如: $0 2xxx"; exit 2; }

# 选出待采任务：有 perf_cases 且有 aiter_impl 的题
ALL=$(for d in benchmark/private/*/; do
        t=$(basename "$d")
        [ -f "$d/perf_cases.json" ] || continue
        [ -f "$d/aiter_impl.py" ] || continue
        echo "$t"
      done | sort)

SELECTED=""
for arg in "$@"; do
  if [ "$arg" = "all" ]; then
    SELECTED="$SELECTED
$ALL"
  elif [[ "$arg" =~ ^[0-9]xxx$ ]]; then
    pre="${arg%xxx}"
    SELECTED="$SELECTED
$(echo "$ALL" | grep "^${pre}[0-9]" || true)"
  else
    if echo "$ALL" | grep -qx "$arg"; then SELECTED="$SELECTED
$arg"
    else wrn "跳过 $arg（无 perf_cases 或无 aiter_impl）"; fi
  fi
done
TASKS=$(echo "$SELECTED" | grep -v '^$' | sort -u)
N=$(echo "$TASKS" | grep -cv '^$' || echo 0)

[ "$N" -gt 0 ] || { echo "没选中任何任务"; exit 2; }

LOGDIR="$ROOT/baseline_logs"
mkdir -p "$LOGDIR"
STAMP=$(date +%Y%m%d_%H%M%S)

echo "==================================================================="
echo " 采集 aiter 基线：$N 道题   $( [ "${DRY:-0}" = "1" ] && echo '(DRY RUN，不写回)' )"
echo " 日志目录：$LOGDIR/$STAMP"
echo "==================================================================="
mkdir -p "$LOGDIR/$STAMP"

PASS=0; FAILN=0; FAILED=""
for t in $TASKS; do
  printf '\n--- %s ---\n' "$t"
  ARGS=(--task "$t")
  [ "${DRY:-0}" = "1" ] && ARGS+=(--dry-run)
  if python3 benchmark/evaluator/record_baseline.py "${ARGS[@]}" 2>&1 | tee "$LOGDIR/$STAMP/$t.log" | tail -6; then
    if grep -q '"status": "measured"' "benchmark/private/$t/baseline.json" 2>/dev/null; then
      ok "$t 已记录"
      PASS=$((PASS+1))
    elif [ "${DRY:-0}" = "1" ]; then
      ok "$t DRY 校验通过"
      PASS=$((PASS+1))
    else
      bad "$t 未写入 measured（见日志）"
      FAILN=$((FAILN+1)); FAILED="$FAILED $t"
    fi
  else
    bad "$t 采集失败"
    FAILN=$((FAILN+1)); FAILED="$FAILED $t"
  fi
done

echo
echo "==================================================================="
echo " 汇总：成功 $PASS / 失败 $FAILN （共 $N）"
[ -n "$FAILED" ] && echo " 失败:$FAILED"
echo " 日志：$LOGDIR/$STAMP"
echo "==================================================================="
if [ "$FAILN" -gt 0 ]; then
  echo
  echo "常见失败原因："
  echo "  1) 缺 tuner 配置且读取无保护 -> FileNotFoundError（跑 check_configs.py 定位）"
  echo "  2) 显存/内存不足 -> 最大的 perf case 单张量约 4.3GB(bf16)"
  echo "  3) reference 与 aiter 输出超容差 -> 采集器会拒收，属预期保护"
  echo "  4) aiter 模块导入失败 -> 检查垫片是否覆盖该模块"
fi
exit 0
