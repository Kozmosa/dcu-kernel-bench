"""极简 HTTP CONNECT 代理：本机直连，强制 IPv4，无上游转发。带诊断日志。

为什么需要它：
  这台 Windows 机器有两个网络问题——
    1. Clash(127.0.0.1:7890) 的**境外节点全部不可用**，只有国内站能过；
    2. 直连时 **IPv6 路由黑洞**，每次先等约 40s 超时才回退 IPv4。
  实测强制 IPv4 直连：hejuapi 1.6s、baidu 0.2s、cloudflare 1.9s。

日志：每个 CONNECT 的目标、双向字节数、结束原因，都打到 stdout（受管作业可读）。
用法：python local_direct_proxy.py <port>
"""

import socket
import sys
import threading
import time

LISTEN_HOST = "127.0.0.1"
LISTEN_PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 17891
CONNECT_TIMEOUT = 30
IDLE_REPORT = 20  # 秒：连接存活超过这个时间就报一次进度
BUF = 65536


def log(msg: str) -> None:
    print("[%s] %s" % (time.strftime("%H:%M:%S"), msg), flush=True)


def _connect_ipv4(host: str, port: int) -> socket.socket:
    infos = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)
    last = None
    for fam, typ, proto, _, addr in infos:
        s = socket.socket(fam, typ, proto)
        s.settimeout(CONNECT_TIMEOUT)
        try:
            s.connect(addr)
            log("  connected %s:%d  via %s" % (host, port, addr[0]))
            return s
        except OSError as e:
            last = e
            s.close()
    raise last or OSError("no IPv4 address for %s" % host)


def _pump(a: socket.socket, b: socket.socket, tag: str, counter: list) -> None:
    try:
        while True:
            try:
                data = a.recv(BUF)
            except socket.timeout:
                # 转发阶段不允许超时：LLM 流式响应常有 >30s 的空档，把它当错误会
                # 掐断在途请求，应用侧表现为反复重试直至卡死（踩过）。
                continue
            if not data:
                break
            b.sendall(data)
            counter[0] += len(data)
    except OSError as e:
        log("  %s pump error: %s" % (tag, type(e).__name__))
    finally:
        # 只关写方向，别把对向的读也掐了（否则长流式响应会被截断）
        try:
            b.shutdown(socket.SHUT_WR)
        except OSError:
            pass


def handle(client: socket.socket, addr, seq: int) -> None:
    tag = "#%d" % seq
    t0 = time.time()
    up = down = 0
    try:
        client.settimeout(CONNECT_TIMEOUT)
        head = b""
        while b"\r\n\r\n" not in head:
            chunk = client.recv(BUF)
            if not chunk:
                return
            head += chunk
            if len(head) > 65536:
                return

        request_line = head.split(b"\r\n", 1)[0].decode("latin-1")
        parts = request_line.split(" ")
        method, target = parts[0], parts[1] if len(parts) > 1 else ""

        if method.upper() == "CONNECT":
            host, _, port_s = target.rpartition(":")
            log("%s CONNECT %s:%s" % (tag, host, port_s or "443"))
            remote = _connect_ipv4(host, int(port_s or "443"))
            remote.settimeout(None)          # 转发阶段改阻塞，见 _pump 注释
            client.settimeout(None)
            client.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            rc, wc = [0], [0]
            threading.Thread(target=_pump, args=(client, remote, tag + " up", rc),
                             daemon=True).start()
            _pump(remote, client, tag + " down", wc)
            up, down = rc[0], wc[0]
        else:
            from urllib.parse import urlsplit
            u = urlsplit(target)
            host = u.hostname or ""
            port = u.port or (443 if u.scheme == "https" else 80)
            log("%s %s http://%s:%d" % (tag, method, host, port))
            remote = _connect_ipv4(host, port)
            remote.settimeout(None)
            client.settimeout(None)
            path = (u.path or "/") + (("?" + u.query) if u.query else "")
            remote.sendall(("%s %s %s\r\n" % (method, path, parts[2])).encode("latin-1")
                           + head.split(b"\r\n", 1)[1])
            rc, wc = [0], [0]
            threading.Thread(target=_pump, args=(client, remote, tag + " up", rc),
                             daemon=True).start()
            _pump(remote, client, tag + " down", wc)
            up, down = rc[0], wc[0]
    except Exception as exc:  # noqa: BLE001
        log("%s ERROR %s: %s" % (tag, type(exc).__name__, str(exc)[:140]))
    finally:
        log("%s closed after %.1fs  up=%dB down=%dB" % (tag, time.time() - t0, up, down))
        try:
            client.close()
        except OSError:
            pass


def main() -> None:
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((LISTEN_HOST, LISTEN_PORT))
    srv.listen(64)
    log("direct-ipv4 CONNECT proxy listening on %s:%d" % (LISTEN_HOST, LISTEN_PORT))
    seq = 0
    while True:
        try:
            client, addr = srv.accept()
        except OSError:
            continue
        seq += 1
        threading.Thread(target=handle, args=(client, addr, seq), daemon=True).start()


if __name__ == "__main__":
    main()
