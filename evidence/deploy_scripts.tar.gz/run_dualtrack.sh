#!/usr/bin/env bash
# 双轨跑：同一批 66 道题，每题在 Triton 轨与 HIP 轨各跑一次（共 132 次）。
#
# 两条轨的题面不同（"Implementation language: Triton" vs "HIP + CUDA_CU_SRC 锚点"），
# 树由 benchmark/tools/make_dualtrack.py 生成，上传到 /root/dcudeploy/dual/{triton,hip}。
# 16 个分片：每轨 8 片，两轨并发（整条链路是 LLM I/O 等待，实测 16 进程稳定）。
set -o pipefail
set +u

ROOT=/root/dcudeploy
PK=$ROOT/PyramidKernel
DUAL=$ROOT/dual
RUN_ROOT=${RUN_ROOT:-$ROOT/runs/dualtrack_$(date +%m%d_%H%M)}
N_PER_TRACK=${N_PER_TRACK:-8}

source /opt/dtk/env.sh
source "$ROOT/env.sh"
[ -f "$ROOT/llm.env" ] && source "$ROOT/llm.env"
export PYTHONPATH="$ROOT/aiter_shim:$ROOT/py311deps:$PK:$PK/KernelBench/src:$ROOT/dcu-kernel-bench:$PYTHONPATH"
export LITELLM_LOCAL_MODEL_COST_MAP=True
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-8}"
export PYTHONUTF8=1 PYTHONUNBUFFERED=1

echo "=== 双轨跑 $(date '+%F %T')"
echo "  run_root : $RUN_ROOT"
echo "  每轨分片 : $N_PER_TRACK"

code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 25 -x "$HTTPS_PROXY" \
            "$OPENAI_BASE_URL/models" -H "Authorization: Bearer $OPENAI_API_KEY")
echo "  preflight API HTTP $code"
[ "$code" = "200" ] || { echo "  [FAIL] 隧道/API 不可用，不启动"; exit 3; }

mkdir -p "$RUN_ROOT"
idx=0
for track in triton hip; do
  COMPAT=$DUAL/$track/kernelbench_compat
  MANIFEST=$DUAL/manifest_$track.yaml
  [ -d "$COMPAT" ] || { echo "  [FAIL] 缺 $COMPAT"; exit 1; }
  [ -f "$MANIFEST" ] || { echo "  [FAIL] 缺 $MANIFEST"; exit 1; }
  OUTROOT=$RUN_ROOT/$track
  mkdir -p "$OUTROOT"
  python3 "$ROOT/split_manifest.py" --full "$MANIFEST" --n "$N_PER_TRACK" --out-dir "$OUTROOT" \
    2>&1 | tail -2
  cd "$PK" || exit 1
  for i in $(seq 1 "$N_PER_TRACK"); do
    ii=$(printf '%02d' "$i")
    SD="$OUTROOT/shard_$ii.yaml"
    [ -f "$SD" ] || { echo "  [skip] $track/$ii 缺 shard"; continue; }
    OUT="$OUTROOT/par_s$ii"
    mkdir -p "$OUT"
    nohup python3 -u -m pyramidkernel.cli run-kernelbench-batch \
        --experiment main \
        --manifest "$SD" \
        --kernelbench-root "$COMPAT" \
        --backend triton \
        --search-config main \
        --provider openai-compatible \
        --route-config all_gpt \
        --env-file "$PK/.env" \
        --output-dir "$OUT" >> "$OUTROOT/par_s$ii.log" 2>&1 &
    idx=$((idx + 1))
    echo "  [started] $track/$ii -> $OUT pid=$!"
    sleep 2
  done
done
echo "=== 已启动 $idx 个分片 $(date '+%F %T')，日志 $RUN_ROOT/*/par_s*.log"
