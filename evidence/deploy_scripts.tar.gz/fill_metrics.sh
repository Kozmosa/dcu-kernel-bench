#!/bin/bash
# 补算 S@1 / Fast1 / FCM（首次正确的中位尝试序号）/ RG（精修收益中位）
cd /root/dcudeploy/kw_full_b_d_20261101_r3 || exit 1
python3 - <<'PY'
import glob, json, math, re, statistics
from pathlib import Path

ROOT = Path("/root/dcudeploy/kw_full_b_d_20261101_r3")

def key(s):
    m = re.search(r"(\d{4})", str(s or ""))
    return m.group(1) if m else str(s)

def collect(dirs):
    tasks = {}
    for d in dirs:
        for f in glob.glob(str(ROOT / d / "*" / "run.json")):
            data = json.load(open(f))
            nodes = [(k, v) for k, v in data.get("nodes", {}).items() if k not in ("root", "phase2_root")]
            nodes.sort(key=lambda kv: (kv[1].get("depth", 0), kv[0]))
            first_correct_idx = None
            first_correct_sp = None
            best_sp = 0.0
            for i, (nid, n) in enumerate(nodes, start=1):
                sp = n.get("speedup") or 0
                best_sp = max(best_sp, sp)
                if n.get("correct") and first_correct_idx is None:
                    first_correct_idx = i
                    first_correct_sp = sp
            tasks[key(data.get("task_name") or f.split("/")[-2])] = (first_correct_idx, first_correct_sp, best_sp)
    return tasks

def report(label, dirs):
    t = collect(dirs)
    n = len(t)
    s1 = sum(1 for v in t.values() if v[0] == 1)
    fcm = [v[0] for v in t.values() if v[0]]
    rg = [v[2] / v[1] for v in t.values() if v[1] and v[2] and v[1] > 0]
    fast1 = sum(1 for v in t.values() if v[2] and v[2] > 1)
    print("%-22s 题 %2d | S@1 %2d | Fast1@all %2d | FCM %4.1f | RG %4.2fx" % (
        label, n, s1, fast1, statistics.median(fcm) if fcm else 0, statistics.median(rg) if rg else 0))

report("框架v2 HIP", ["final2/hip"])
report("框架v2 Triton(合并)", ["final2/triton", "subset_view"])
report("纯API HIP", ["pure_norm/hip"])
report("纯API Triton", ["pure_norm/triton"])
report("纯API+Wiki HIP", ["pure_wiki_norm/hip"])
report("纯API+Wiki Triton", ["pure_wiki_norm/triton"])
PY
