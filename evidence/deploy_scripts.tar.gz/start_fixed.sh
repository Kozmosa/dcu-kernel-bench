#!/bin/bash
# 修复后的重跑：provider 过载可重试（不烧候选预算），并发 6。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$ROOT" || exit 1

pkill -9 -f supervise_r3.py 2>/dev/null
pkill -9 -f run-kernelbench-batch 2>/dev/null
sleep 3

rm -rf groups pools status_resume.json
mkdir -p groups pools logs
: > logs/supervisor_fixed.out

export OPENAI_HTTP_STREAM=1
export OPENAI_MAX_RETRIES=6
export OPENAI_RETRY_BACKOFF_SECONDS=3
export R3_MAX_CONCURRENT=6
export R3_MEM_GUARD_GB=25

setsid nohup python3 -u supervise_r3.py --profiles d > logs/supervisor_fixed.out 2>&1 < /dev/null &
sleep 15
echo "batch=$(ps -eo args | grep -c '[r]un-kernelbench-batch')"
head -8 logs/supervisor_fixed.out
