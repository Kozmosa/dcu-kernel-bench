#!/bin/bash
# 8 并发续跑：ulimit -c 0（禁 core dump）+ 内存守卫 20GB + 熔断 50GB。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
cd "$ROOT" || exit 1

pkill -TERM -f supervise_r3.py 2>/dev/null
sleep 5
pkill -9 -f run-kernelbench-batch 2>/dev/null
pkill -9 -f supervise_r3.py 2>/dev/null
sleep 2
rm -f "$ROOT"/core.* "$ROOT"/KernelWeaver/core.* 2>/dev/null

export OPENAI_HTTP_STREAM=1
export OPENAI_MAX_RETRIES=6
export OPENAI_RETRY_BACKOFF_SECONDS=3
export R3_MAX_CONCURRENT=8
export R3_MEM_GUARD_GB=20
export R3_MEM_KILL_GB=50

ulimit -c 0

setsid nohup python3 -u supervise_r3.py --profiles d > logs/supervisor8.out 2>&1 < /dev/null &
sleep 15
echo "sup=$(ps -eo args | grep -c '[s]upervise_r3.py') batch=$(ps -eo args | grep -c '[r]un-kernelbench-batch')"
echo "完成=$(find groups -name run.json 2>/dev/null | wc -l)/132"
head -4 logs/supervisor8.out
