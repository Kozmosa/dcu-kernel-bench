#!/bin/bash
# 只重跑 Triton 轨离线未通过的 23 题（验证"放弃手写"指引）。
set -u
ROOT=/root/dcudeploy/kw_full_b_d_20261101_r3
source /root/dcudeploy/env.sh >/dev/null 2>&1
set -a; source /root/dcudeploy/llm.env; set +a
export PYTHONPATH=/root/dcudeploy/PyramidKernel/KernelBench/src:${PYTHONPATH:-}
cd "$ROOT" || exit 1

TASKS="1016_lean_atten_paged 1018_mha_fused_bwd 1024_prefill_attention 1026_sage_attention_qk_int8_per_block 1027_sage_attention_qk_int8_per_block_causal 1031_deform_attention_fwd 1032_deform_attention_bwd 2009_softmax 2013_groupnorm_bwd 3002_moe_align_block_size 3003_moe_op 3009_routing 4001_batched_gemm_a8w8 4007_gemm_a16w16_atomic 4008_gemm_a16w4 4009_gemm_a8w8 5001_conv2d_fwd 5002_conv2d_bwd 5004_deform_conv2d_bwd 5008_conv_bias_act 5009_conv_depthtospace 6001_fused_adamw 8001_cumsum"

pkill -9 -f supervise_r3.py 2>/dev/null
pkill -9 -f run-kernelbench-batch 2>/dev/null
sleep 2
rm -rf subset
mkdir -p subset/triton

# 把 23 题均分到 4 份 manifest
python3 - "$TASKS" <<'PY'
import sys, yaml, pathlib
root = pathlib.Path("/root/dcudeploy/kw_full_b_d_20261101_r3")
allt = yaml.safe_load((root / "manifest_triton.yaml").read_text())["tasks"]
want = set(sys.argv[1].split())
picked = [t for t in allt if t["alias"] in want]
print("待跑", len(picked), "题")
parts = 8
for i in range(parts):
    chunk = picked[i::parts]
    man = {"name": f"subset_triton_s{i+1}", "backend": "triton", "tasks": chunk}
    (root / f"subset_manifest_s{i+1}.yaml").write_text(yaml.safe_dump(man, sort_keys=False, allow_unicode=True))
    print(f"  s{i+1}: {len(chunk)} 题")
PY

# 复制现有 triton 记忆池作为起点（不污染原池）
cp -f pools/memory_pool_dcu_d_combined_triton.json subset/triton/pool_start.json 2>/dev/null || echo '{"version":1,"entries":[]}' > subset/triton/pool_start.json
cp -f subset/triton/pool_start.json subset/triton/memory_pool.json

export OPENAI_HTTP_STREAM=1 OPENAI_MAX_RETRIES=6 OPENAI_RETRY_BACKOFF_SECONDS=3
export KW_MEMORY_POOL="$ROOT/subset/triton/memory_pool.json"
cd "$ROOT/KernelWeaver" || exit 1

for i in 1 2 3 4 5 6 7 8; do
  setsid nohup python3 -u -m src.cli run-kernelbench-batch \
      --experiment main --provider openai-compatible --route-config all_gpt \
      --backend triton --runtime-config gpu_single --search-config dcu_d_combined \
      --max-attempts 10 --evaluator-config main --measurement-config main \
      --manifest "$ROOT/subset_manifest_s$i.yaml" \
      --kernelbench-root "$ROOT/tasks/triton/kernelbench_compat" \
      --output-dir "$ROOT/subset/triton/s$i" --verbose \
      > "$ROOT/logs/subset_s$i.log" 2>&1 &
done
sleep 12
echo "batch=$(ps -eo args | grep -c '[r]un-kernelbench-batch')"
