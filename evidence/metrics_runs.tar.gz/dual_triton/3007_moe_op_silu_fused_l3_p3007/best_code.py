import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _fused_experts(A, B, AS, BS, W, S, EX, P, O,
                   M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
                   T: tl.constexpr, L: tl.constexpr, ALIGN: tl.constexpr,
                   SA, SB, SS: tl.constexpr,
                   SX: tl.constexpr, SW,
                   SAS, SBS,
                   Q: tl.constexpr, QN: tl.constexpr, QK: tl.constexpr,
                   WEIGHT: tl.constexpr,
                   BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    pid = tl.program_id(0)
    subdivisions = tl.cdiv(ALIGN, BM)
    block = pid // subdivisions
    sub = pid % subdivisions
    padded = tl.load(P)
    if block * ALIGN < padded:
        pos = block * ALIGN + sub * BM + tl.arange(0, BM)
        valid_pos = (pos < L) & (pos < padded) & (pos < (block + 1) * ALIGN)
        rid = tl.load(S + pos * SS, valid_pos, other=M*T).to(tl.int32)
        valid = valid_pos & (rid < M*T) & (rid >= 0)
        if tl.sum(valid.to(tl.int32), 0) > 0:
            expert = tl.load(EX + block * SX).to(tl.int32)
            rows = rid // T
            cols = tl.program_id(1) * BN + tl.arange(0, BN)
            kk = tl.arange(0, BK)
            gate = tl.full((BM, BN), 0, tl.float32)
            up = tl.full((BM, BN), 0, tl.float32)
            for start in range(tl.cdiv(K, BK)):
                ks = start * BK + kk
                av = tl.load(A + rows[:, None]*SA[0] + ks[None, :]*SA[1], valid[:, None] & (ks[None, :] < K), other=0).to(tl.float32)
                bg = tl.load(B + expert*SB[0] + cols[None, :]*SB[1] + ks[:, None]*SB[2], (cols[None, :] < N) & (ks[:, None] < K), other=0).to(tl.float32)
                bu = tl.load(B + expert*SB[0] + (cols[None, :]+N)*SB[1] + ks[:, None]*SB[2], (cols[None, :] < N) & (ks[:, None] < K), other=0).to(tl.float32)
                if Q:
                    asc = tl.load(AS + rows[:, None]*SAS[0] + (ks[None, :]//QK)*SAS[1], valid[:, None] & (ks[None, :] < K), other=0)
                    gsc = tl.load(BS + expert*SBS[0] + (cols[None, :]//QN)*SBS[1] + (ks[:, None]//QK)*SBS[2], (cols[None, :] < N) & (ks[:, None] < K), other=0)
                    usc = tl.load(BS + expert*SBS[0] + ((cols[None, :]+N)//QN)*SBS[1] + (ks[:, None]//QK)*SBS[2], (cols[None, :] < N) & (ks[:, None] < K), other=0)
                    av = av * asc
                    bg = bg * gsc
                    bu = bu * usc
                gate = tl.dot(av, bg, gate, input_precision='ieee')
                up = tl.dot(av, bu, up, input_precision='ieee')
            if WEIGHT:
                weight = tl.load(W + rows*SW[0] + (rid % T)*SW[1], valid, other=0).to(tl.float32)
                gate = gate * weight[:, None]
                up = up * weight[:, None]
            result = gate / (1.0 + tl.exp(-gate)) * up
            tl.store(O + rid[:, None]*N + cols[None, :], result, valid[:, None] & (cols[None, :] < N))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """SiLU-and-multiply fused into the epilogue of an MoE (Mixture of Experts)
    single-layer expert FFN grouped GEMM: one kernel performs the grouped matrix
    multiply of tokens against expert weights, the routing weight weighting and
    the SwiGLU-style activation together, so no intermediate activation is
    materialized.

    Operator semantics: given
        A             activations (M, K)
        B             expert weights (E, 2N, K), the transposed weight matrix of
                      the e-th expert
        topk_ids      routing result (M, top_k), elements in [0, E), distinct
                      within a row
        topk_weights  routing weights (M, top_k), always positive within a row,
                      no normalization needed
        and the three scheduling tensors precomputed from topk_ids by the
        upstream alignment operator
        sorted_token_ids / expert_ids / num_tokens_post_padded (see the input
        specification).
    For each token m and its j-th selected expert e = topk_ids[m, j]:
        x[m, j, :] = A[m, :] @ B[e, :, :]^T          in R^{2N}
        if mul_routed_weight = True: x[m, j, :] *= topk_weights[m, j]
        out[m*top_k + j, i] = SiLU(x[m, j, i]) * x[m, j, N + i],  i in [0, N)
    where SiLU(u) = u / (1 + exp(-u)) = u * sigmoid(u). The 2N output dimensions
    of B use the chunked gating layout: the first N rows are gate and the last N
    rows are up (distinct from the interleaved layout). Every row of the output
    (M*top_k, N) is written by exactly one expert (routing guarantees that every
    row has an owner).

    fp8 block-quantized mode: with quant="fp8_block", A / B are float8_e4m3 code
    words taking part in the same math after dequantization:
        A_deq[m, k]  = A[m, k]  * A_scale[m,  k // block_k]
        B_deq[e, j, k] = B[e, j, k] * B_scale[e, j // block_n, k // block_k]
    This mode requires K % block_k == 0 and 2N % block_n == 0 (no scale tail
    block). With quant="dense", A / B are the raw weights and A_scale / B_scale
    are ignored one-element placeholder tensors.

    Boundary behaviour:
      - slots in sorted_token_ids whose value is >= M*top_k are alignment padding
        sentinels: they take no part in the computation and produce no output
        row; expert_ids is valid only inside the first ceil(num_tokens_post_padded
        / block_size_m) blocks (the valid prefix takes values in [0, E), with no
        cross-card -1 sentinel, and the tail holds unconsumed fill values).
      - an expert selected by no token does not read its B rows.
      - the three scheduling tensors and topk_ids are mutually redundant (all
        derived from the same topk_ids); the core scheduling may use either
        information source, but the output must match the math defined above in
        terms of topk_ids.

    Input/output specification:
        A            (M, K)    float16/bfloat16 (e4m3 code words in fp8_block
                               mode)
        B            (E, 2N, K) same as A (e4m3 code words in fp8_block mode)
        A_scale      (M, K//block_k) float32 ((1,) placeholder in dense mode)
        B_scale      (E, 2N//block_n, K//block_k) float32 ((1,) placeholder in
                     dense mode)
        topk_weights (M, top_k) float16/bfloat16, same dtype as the output
        topk_ids     (M, top_k) int64
        sorted_token_ids (M*top_k + E*(block_size_m-1),) int32
        expert_ids   (M*top_k + E,) int32
        num_tokens_post_padded (1,) int32
        out          (M*top_k, N), dtype same as topk_weights.
        M, K, E, top_k, block_size_m >= 1; 2N is even; input magnitudes are the
        usual randn/rand scale with no inf/NaN. The evaluator casts all inputs
        to fp32 before passing them in (integer types restore exactly,
        fp16/bf16/fp8 -> fp32 is lossless), so when topk_weights is fp32 the
        output is fp32 as well.

    Implementation constraints (violations are scored as failures):
      - Core computation (the grouped GEMM, fp8 dequantization, the routing
        weight multiply, the SiLU-and-multiply epilogue) must be done with a
        Triton kernel inside the submitted file, with intermediate accumulation
        always float32 and the output cast back to the dtype of topk_weights.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Materializing the intermediate activation (the 2N-wide GEMM result) to
        device memory and then activating it is forbidden -- the whole point of
        this operator is epilogue fusion, so the activation is done in place
        block by block.

    Disallowed list: torch.matmul / torch.bmm / torch.einsum /
    torch._scaled_mm / torch.nn.functional.silu / torch.SiLU / torch.sigmoid.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, mul_routed_weight=True, quant="dense", block_n=128, block_k=128):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert quant in ("dense", "fp8_block"), "quant must be one of dense / fp8_block"
        assert block_n >= 1 and block_k >= 1, "block_n / block_k must be >= 1"
        self.mul_routed_weight = bool(mul_routed_weight)
        self.quant = quant
        self.block_n = int(block_n)
        self.block_k = int(block_k)
        # <<<END_IMPROVE>>>

    def forward(self, A, B, A_scale, B_scale, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        # <<<IMPROVE:forward_stmt_1>>>
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        sorted_token_ids = sorted_token_ids.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        expert_ids = expert_ids.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens_post_padded = num_tokens_post_padded.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = A.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        E, N2, _ = B.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert N2 % 2 == 0, "the 2N output dimension of B must be even"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        N = N2 // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out_dtype = topk_weights.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        extra = sorted_token_ids.numel() - M * top_k
        assert extra >= 0 and extra % E == 0
        alignment = 1 + extra // E
        BM, BN, BK = 16, 32, 32
        grid = (triton.cdiv(sorted_token_ids.numel(), alignment) * triton.cdiv(alignment, BM), triton.cdiv(N, BN))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        a = A
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        b = B
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        if self.quant == "fp8_block":
            bk, bn = self.block_k, self.block_n
            assert K % bk == 0 and N2 % bn == 0
            assert A_scale.shape == (M, K // bk), "A_scale shape should be (M, K//block_k)"
            assert B_scale.shape == (E, N2 // bn, K // bk), "B_scale shape should be (E, 2N//block_n, K//block_k)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        tw = topk_weights
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        out = torch.empty((M * top_k, N), dtype=out_dtype, device=A.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        _fused_experts[grid](
            a, b, A_scale, B_scale, tw, sorted_token_ids, expert_ids,
            num_tokens_post_padded, out,
            M, N, K, top_k, sorted_token_ids.numel(), alignment,
            a.stride(), b.stride(), sorted_token_ids.stride(0),
            expert_ids.stride(0), tw.stride(), A_scale.stride(), B_scale.stride(),
            self.quant == "fp8_block", self.block_n, self.block_k,
            self.mul_routed_weight, BM, BN, BK, num_warps=4
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return out.to(out_dtype)
        # <<<END_IMPROVE>>>
