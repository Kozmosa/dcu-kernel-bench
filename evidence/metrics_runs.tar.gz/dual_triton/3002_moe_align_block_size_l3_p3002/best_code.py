import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _bucket_count(X, C, N: tl.constexpr, T: tl.constexpr):
    t = tl.program_id(0)
    e = tl.program_id(1)
    i = t * 256 + tl.arange(0, 256)
    x = tl.load(X + i, i < N, other=-1).to(tl.int32)
    c = tl.sum(((i < N) & (x == e)).to(tl.int32), 0)
    tl.store(C + e * T + t, c)

@triton.jit
def _scan_chunks(X, P, H, M: tl.constexpr, K: tl.constexpr):
    c = tl.program_id(0)
    r = tl.program_id(1)
    j = c * 256 + tl.arange(0, 256)
    v = tl.load(X + r * M + j, j < M, other=0)
    s = tl.cumsum(v, 0)
    tl.store(P + r * M + j, s - v, j < M)
    tl.store(H + r * K + c, tl.sum(v, 0))

@triton.jit
def _scan_carry(P, H, M: tl.constexpr, K: tl.constexpr):
    c = tl.program_id(0)
    r = tl.program_id(1)
    j = c * 256 + tl.arange(0, 256)
    v = tl.load(P + r * M + j, j < M, other=0)
    h = tl.load(H + r * K + c)
    tl.store(P + r * M + j, v + h, j < M)

def _integer_scan(x, rows, width):
    chunks = triton.cdiv(width, 256)
    p = torch.empty((rows, width), device=x.device, dtype=torch.int32)
    h = torch.empty((rows, chunks), device=x.device, dtype=torch.int32)
    _scan_chunks[(chunks, rows)](x, p, h, width, chunks, num_warps=4)
    if chunks == 1:
        return p, h
    carry, total = _integer_scan(h, rows, chunks)
    _scan_carry[(chunks, rows)](p, carry, width, chunks, num_warps=4)
    return p, total

@triton.jit
def _align_counts(C, P, E: tl.constexpr, B: tl.constexpr):
    e = tl.program_id(0) * 256 + tl.arange(0, 256)
    c = tl.load(C + e, e < E, other=0)
    tl.store(P + e, ((c + B - 1) // B) * B, e < E)

@triton.jit
def _bucket_scatter(X, P, A, D, O, C, S, N: tl.constexpr, T: tl.constexpr, B: tl.constexpr, L1: tl.constexpr, L2: tl.constexpr):
    t = tl.program_id(0)
    e = tl.program_id(1)
    lane = tl.arange(0, 256)
    i = t * 256 + lane
    x = tl.load(X + i, i < N, other=-1).to(tl.int32)
    match = (i < N) & (x == e)
    rank = tl.cumsum(match.to(tl.int32), 0) - 1
    base = tl.load(A + e)
    earlier = tl.load(P + e * T + t)
    tl.store(O + base + earlier + rank, i.to(tl.float32), match)
    if t == 0:
        blocks = tl.load(D + e) // B
        for start in range(0, blocks, 256):
            j = start + lane
            tl.store(O + L1 + base // B + j, e.to(tl.float32), j < blocks)
    count = tl.load(C + e)
    padded = tl.load(D + e)
    for start in range(t * 256, padded - count, T * 256):
        offset = start + lane
        tl.store(O + base + count + offset, N, offset < padded - count)
    if e == 0:
        s = tl.load(S)
        for start in range(t * 256, L1 - s, T * 256):
            offset = start + lane
            tl.store(O + s + offset, N, offset < L1 - s)
        for start in range(t * 256, L2 - s // B, T * 256):
            offset = start + lane
            tl.store(O + L1 + s // B + offset, -1, offset < L2 - s // B)
        if t == 0:
            tl.store(O + L1 + L2, s.to(tl.float32))

def _align_triton(flat_ids, N, E, B, L1, L2):
    tiles = triton.cdiv(N, 256)
    counts = torch.empty((E, tiles), device=flat_ids.device, dtype=torch.int32)
    _bucket_count[(tiles, E)](flat_ids, counts, N, tiles, num_warps=4)
    prefixes, totals = _integer_scan(counts, E, tiles)
    padded = torch.empty((E,), device=flat_ids.device, dtype=torch.int32)
    _align_counts[(triton.cdiv(E, 256),)](totals, padded, E, B, num_warps=4)
    bases, total = _integer_scan(padded, 1, E)
    out = torch.empty((L1 + L2 + 1,), device=flat_ids.device, dtype=torch.float32)
    _bucket_scatter[(tiles, E)](flat_ids, prefixes, bases, padded, out, totals, total, N, tiles, B, L1, L2, num_warps=4)
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Scheduling prologue of MoE grouped GEMM: tokens bucketized per expert and
    laid out aligned to block_size.

    The input topk_ids ([num_tokens, top_k], elements are expert ids in
    [0, num_experts), duplicates allowed within a row) holds the experts the
    router selected for each token. Write the flattened index
    i = t * top_k + j (t is the token row, j the column), N = num_tokens * top_k,
    E = num_experts, B = block_size. For every expert e:
        T_e = { i : the i-th element of flattened topk_ids == e } (ascending i)
        n_blocks_e = ceil(|T_e| / B)        # aligned blocks occupied by e
        padded_e   = n_blocks_e * B         # aligned slot count of e
    Produce the three scheduling tensors of grouped GEMM:
        sorted_token_ids  length L1 = N + E*(B-1): for e = 0..E-1 in order, all
          indices of T_e (ascending), then padded_e - |T_e| fill sentinels N;
          the buffer tail [S, L1) is also sentinel N, where S = sum_e padded_e
        expert_ids        length L2 = ceil(L1/B): for e = 0..E-1 in order,
          n_blocks_e copies of e (together the first S/B positions), the tail
          [S/B, L2) filled with the -1 sentinel
        num_tokens_post_pad  scalar S (total padded slot count, always a
          multiple of B)
    grouped GEMM takes every B consecutive slots of sorted_token_ids as one
    M-tile, uses expert_ids as that tile's expert id to fetch weights, skips
    fill slots whose value is sentinel N, and num_tokens_post_pad gives the
    valid total length. This task is that scheduling prologue itself and does
    not include the GEMM.

    Boundary behaviour: an expert with |T_e| = 0 occupies 0 blocks and yields no
    sorted entry and no expert entry; when |T_e| is an exact multiple of B no
    padding is produced; the same row may select the same expert more than once
    (different flattened indices are different entries); entries within an
    expert follow ascending flattened index i.

    Input/output specification:
      topk_ids  int64/int32 (or fp32 as cast by the evaluator, integer values
                unchanged), contiguous 2D [num_tokens, top_k]; num_tokens /
                top_k >= 1 and top_k <= num_experts; E and B are __init__
                hyperparameters and >= 1, non powers of two allowed
      returns   a single 1-D float32 tensor of length L1 + L2 + 1, packed in
                three segments:
                out[:L1] = the L1 integers of sorted_token_ids (sentinel N
                           included)
                out[L1:L1+L2] = the L2 integers of expert_ids (tail -1)
                out[L1+L2] = num_tokens_post_pad (scalar S)
                -- all of them are non-negative / minus-one integers; the
                global-domain constraint L1 = N + E*(B-1) <= 2^24 guarantees
                that sentinel N, every index, every expert id and S <= L1 are
                exactly representable in fp32
      __init__ hyperparameters: num_experts (int), block_size (int).

    Implementation constraints (violations are scored as failures):
      - Core computation (bucket counting, block-count prefix sums, scatter
        writes of the layout, block expert table generation) must be done in a
        Triton kernel inside the submitted file; forward may only do input/
        output arrangement (dtype restoration, three-segment cat packing).
        Calling torch.sort / torch.argsort / torch.bincount / torch.cumsum /
        torch.histc / torch.unique / torch.repeat_interleave, or any
        third-party MoE/scheduling operator library, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Integer arithmetic throughout (no floating-point accumulation); the
        output is packed into float32 integers per the protocol above.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: the pure scheduling prologue (sorting / alignment / block table
    generation); no grouped GEMM body and no routing scores (softmax/topk are
    already done upstream).
    """
    def __init__(self, num_experts: int, block_size: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = int(num_experts)
        self.block_size = int(block_size)
        # <<<END_IMPROVE>>>

    def forward(self, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        # Native input dtype is converted in Triton registers.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        E, B = self.num_experts, self.block_size
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Expert IDs satisfy the input contract.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        N = topk_ids.numel()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        flat_ids = topk_ids.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # Bucket counts are computed on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # Integer block counts are computed on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # Alignment is computed on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Ordered tile prefixes determine stable ranks.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # Expert bases are scanned on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # S remains on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Block table lengths remain on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # No global sorting is needed.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # Triton generates flattened indices.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # Destinations combine expert bases, tile prefixes and local ranks.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        L1 = N + E * (B - 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        L2 = (L1 + B - 1) // B
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        out = _align_triton(flat_ids, N, E, B, L1, L2)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        # Stable scatter is performed by the helper.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        # Expert IDs occupy the second packed segment.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        # Disjoint expert intervals are filled in Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        return out
        # <<<END_IMPROVE>>>
