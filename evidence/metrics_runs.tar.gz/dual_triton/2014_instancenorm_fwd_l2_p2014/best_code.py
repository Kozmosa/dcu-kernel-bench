import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _instancenorm_fwd(x_ptr, scale_ptr, bias_ptr, out_ptr, hw, channels, eps, BLOCK_SIZE: tl.constexpr):
    plane = tl.program_id(0)
    channel = plane % channels
    base = plane * hw
    total = tl.zeros((BLOCK_SIZE,), dtype=tl.float32)
    for start in tl.range(0, hw, BLOCK_SIZE):
        offs = start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hw
        vals = tl.load(x_ptr + base + offs, mask=mask, other=0.0).to(tl.float32)
        total += tl.where(mask, vals, 0.0)
    mean = tl.sum(total, axis=0) / hw
    sq_total = tl.zeros((BLOCK_SIZE,), dtype=tl.float32)
    for start in tl.range(0, hw, BLOCK_SIZE):
        offs = start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hw
        vals = tl.load(x_ptr + base + offs, mask=mask, other=0.0).to(tl.float32)
        centered = tl.where(mask, vals - mean, 0.0)
        sq_total += centered * centered
    var = tl.sum(sq_total, axis=0) / hw
    inv_std = tl.rsqrt(var + eps)
    sf = tl.load(scale_ptr + channel).to(tl.float32)
    bf = tl.load(bias_ptr + channel).to(tl.float32)
    for start in tl.range(0, hw, BLOCK_SIZE):
        offs = start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hw
        vals = tl.load(x_ptr + base + offs, mask=mask, other=0.0).to(tl.float32)
        result = (vals - mean) * inv_std * sf + bf
        tl.store(out_ptr + base + offs, result, mask=mask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    InstanceNorm forward pass: per-(N,C) spatial-statistics normalization plus
    per-channel affine (single variant).

    The input x (N, C, H, W) is NCHW contiguous; scale / bias are the (1, C, 1, 1)
    per-channel affine parameters, broadcast along the channel dimension; eps
    defaults to 1e-5. Statistics are taken over the spatial dimensions (H, W) for
    every (n, c) plane (HW = H*W elements per plane), in float32:
        mean_nc    = sum_{h,w} x[n,c,h,w] / HW                  (biased mean)
        var_nc     = sum_{h,w} (x[n,c,h,w] - mean_nc)^2 / HW    (biased variance)
        inv_std_nc = 1 / sqrt(var_nc + eps)
        y[n,c,h,w] = scale[c] * (x[n,c,h,w] - mean_nc) * inv_std_nc + bias[c]
    Instance norm has no train / inference semantic difference: the normalization
    statistics always come from the input itself. The convention is biased (divide
    by HW rather than HW-1), and eps sits inside the rsqrt (its only purpose is the
    division-by-zero guard; it takes part in no unbiased correction).

    Boundary behaviour: when HW == 1 (a single spatial element) var = 0 and
    x - mean = 0, so inv_std = 1/sqrt(eps) and y = bias (eps guarantees no division
    by zero); N/C/H/W are arbitrary (including 1, non-powers-of-two, and unaligned
    sizes); a large HW requires a blocked reduction, and out-of-range elements at
    the row tail must not participate in the statistics.

    Input/output specification:
        x     float32 / float16 / bfloat16 (N, C, H, W), contiguous,
              N/C/H/W >= 1
        scale same dtype as x, (1, C, 1, 1), contiguous
        bias  same dtype as x, (1, C, 1, 1), contiguous
        out   a single tensor, y itself: (N, C, H, W) with the same dtype as x
              (statistics and affine run in float32 intermediates, then cast back
              to the x dtype); no packing
        The inputs are ordinary randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before calling forward (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-(N,C) spatial reduction statistics, rsqrt,
          and the per-channel affine) must be completed with a Triton kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt and affine all run in float32 intermediates; y is
          cast back to the x dtype.
        - forward returns the single tensor `out` (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden list: torch.nn.InstanceNorm1d / torch.nn.InstanceNorm2d /
    torch.nn.InstanceNorm3d / torch.nn.functional.instance_norm /
    F.instance_norm / torch.instance_norm / native_instance_norm /
    torch.nn.GroupNorm / nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm /
    torch.nn.BatchNorm1d / torch.nn.BatchNorm2d / torch.nn.BatchNorm3d /
    torch.nn.SyncBatchNorm / torch.nn.functional.batch_norm /
    F.batch_norm / torch.batch_norm / torch.native_batch_norm /
    miopen / hipdnn.
    (GroupNorm with num_groups=C and BatchNorm via a (1, N*C, H, W) reshape both
    complete this task's core computation in a single step, so they are forbidden
    alongside the instance_norm family.)
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert eps > 0, "eps must be positive"
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        n, c, h, w = x.shape
        hw = h * w
        out = torch.empty_like(x)
        grid = (n * c,)
        _instancenorm_fwd[grid](
            x, scale, bias, out, hw, c, self.eps,
            BLOCK_SIZE=1024,
            num_warps=4,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Mean is computed by the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Variance is computed by the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # The epsilon-adjusted reciprocal square root is computed by the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # Channel scale is loaded and promoted to float32 inside the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # Channel bias is loaded and promoted to float32 inside the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # Normalization and affine application are fused into the Triton output pass.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return out
        # <<<END_IMPROVE>>>
