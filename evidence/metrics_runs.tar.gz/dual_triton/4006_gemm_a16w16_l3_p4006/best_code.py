import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _gemm_a16w16(X, W, Out, M: tl.constexpr, N: tl.constexpr,
                 K: tl.constexpr, BLOCK_M: tl.constexpr,
                 BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr):
    m = tl.program_id(0) * BLOCK_M + tl.arange(0, BLOCK_M)
    n = tl.program_id(1) * BLOCK_N + tl.arange(0, BLOCK_N)
    rk = tl.arange(0, BLOCK_K)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for block in range(tl.cdiv(K, BLOCK_K)):
        k = block * BLOCK_K + rk
        a = tl.load(X + m[:, None] * K + k[None, :],
                    mask=(m[:, None] < M) & (k[None, :] < K), other=0)
        b = tl.load(W + n[:, None] * K + k[None, :],
                    mask=(n[:, None] < N) & (k[None, :] < K), other=0)
        b = tl.trans(b)
        acc = tl.dot(a, b, acc)
    result = acc.to(Out.dtype.element_ty)
    tl.store(Out + m[:, None] * N + n[None, :], result,
             mask=(m[:, None] < M) & (n[None, :] < N))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Bias-free 16-bit floating-point matrix multiplication (regular blocked
    whole-reduction variant).

    Operator semantics:
      x has shape [M, K], weight has shape [N, K] (the linear-layer weight
      layout), and the output out has shape [M, N]:
        out[m, n] = sum_{k=0}^{K-1} x[m, k] * weight[n, k]
      equivalent to torch.nn.functional.linear(x, weight, bias=None). M, N, K are
      arbitrary positive integers (including 1 and non-powers-of-two; K need not
      align with any block size, and out-of-range lanes along K contribute 0 to the
      accumulation). Reduction strategy: the full K reduction is completed inside a
      single program -- each output tile is computed and written back by exactly
      one program (M/N boundaries are handled by masking, tiles never overlap),
      with no split-K, no atomics and no cross-writes to the same output; the
      float32 accumulated result is cast back to the input dtype once, so there is
      no intermediate half-precision rounding.

    Input/output specification:
      forward(x, weight) -> out
        x      [M, K], float16 or bfloat16, row-major contiguous
        weight [N, K], same dtype as x, row-major contiguous
        out    [M, N], same dtype as x
      __init__(in_features, out_features): in_features corresponds to K and
      out_features to N; they are instance metadata only. forward always follows
      the actual shapes of the runtime tensors and does not enforce a hard match
      against the init parameters.

    Implementation constraints (violations are scored as failures):
      - The core computation (the multiply-accumulate main loop) must be completed
        with a Triton kernel inside the submitted file; calling ATen GEMM shortcuts
        such as torch.matmul / torch.bmm / torch.mm / torch.addmm / torch.einsum /
        torch.nn.functional.linear / F.linear / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: row-major TN layout, no bias, no batch dimension, single output
    tensor, float16 and bfloat16 input dtypes; the block sizes, tile-group
    scheduling and parallel strategy are left to the implementation and judged by
    the output tolerance.
    """
    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.in_features = in_features
        self.out_features = out_features
        # <<<END_IMPROVE>>>

    def forward(self, x, weight):
        # <<<IMPROVE:forward_stmt_1>>>
        M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        N = weight.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        assert K == weight.shape[1], "x and weight must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        out = torch.empty((M, N), device=x.device, dtype=x.dtype)
        _gemm_a16w16[(triton.cdiv(M, 64), triton.cdiv(N, 64))](
            x, weight, out, M, N, K,
            BLOCK_M=64, BLOCK_N=64, BLOCK_K=32,
            num_warps=4, num_stages=2,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        return out
        # <<<END_IMPROVE>>>
