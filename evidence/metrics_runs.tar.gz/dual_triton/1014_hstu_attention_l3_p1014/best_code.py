import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _hstu_fused(Q, K, V, Off, Targets, O,
                QS: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
                KS: tl.constexpr, KH: tl.constexpr, KD: tl.constexpr,
                VS: tl.constexpr, VH: tl.constexpr, VD: tl.constexpr,
                OS: tl.constexpr, OH: tl.constexpr, OD: tl.constexpr,
                D: tl.constexpr, E: tl.constexpr, ALPHA: tl.constexpr,
                N: tl.constexpr, C: tl.constexpr, CAUSAL: tl.constexpr,
                A: tl.constexpr):
    tile = tl.program_id(0)
    h = tl.program_id(1)
    b = tl.program_id(2)
    s = tl.load(Off + b)
    length = tl.load(Off + b + 1) - s
    g = tl.load(Targets + b)
    if tile * 16 < length:
        i = tile * 16 + tl.arange(0, 16)
        d = tl.arange(0, D)
        ev = tl.arange(0, E)
        q = tl.load(Q + (s + i[:, None]) * QS + h * QH + d[None, :] * QD,
                    i[:, None] < length, other=0)
        if C > 0:
            limit = length - C + 1 - g
            mi = tl.minimum(tl.maximum(i - C + 1, 0), limit)
        else:
            limit = length - g
            mi = tl.minimum(i, limit)
        acc = tl.zeros((16, E), tl.float32)
        key_end = length
        if CAUSAL and C == 0:
            key_end = tl.minimum(length, tl.maximum(tile * 16 + 16, length - g + 1))
        for start in range(0, key_end, 32):
            j = start + tl.arange(0, 32)
            k = tl.load(K + (s + j[None, :]) * KS + h * KH + d[:, None] * KD,
                        j[None, :] < length, other=0)
            x = tl.dot(q, k).to(tl.float32) * ALPHA
            w = x * (1.0 / (1.0 + tl.exp(-x))) / N
            if C > 0:
                mj = tl.minimum(tl.maximum(j - C + 1, 0), limit)
            else:
                mj = tl.minimum(j, limit)
            dist = mi[:, None] - mj[None, :]
            if not CAUSAL:
                dist = tl.abs(dist)
            valid = (i[:, None] == j[None, :]) | (dist > 0)
            if A > 0:
                valid = valid & (dist <= A)
            if C > 0:
                valid = valid | ((mi[:, None] == 0) & (mj[None, :] < limit))
            valid = valid & (i[:, None] < length) & (j[None, :] < length)
            w = tl.where(valid, w, 0.0)
            v = tl.load(V + (s + j[:, None]) * VS + h * VH + ev[None, :] * VD,
                        j[:, None] < length, other=0).to(tl.float32)
            acc = tl.dot(w, v, acc, input_precision='ieee')
        tl.store(O + (s + i[:, None]) * OS + h * OH + ev[None, :] * OD,
                 acc, i[:, None] < length)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """HSTU attention forward (the attention of the generative-recommendation HSTU unit, no softmax / no normalization):
    dense Q/K/V are split by seq_offsets into batch variable-length sequences,
    and each sequence computes independently
    out = (valid * SiLU(alpha*Q*K^T) / N) * V, where N = max_seq_len.

    Mathematical definition (sequence b: s = seq_offsets[b],
    L = seq_offsets[b+1] - seq_offsets[b], g = num_targets[b],
    c = contextual_seq_len, A = max_attn_len; when c = 0, M = L and r[i] = i;
    when c > 0, M = L - c + 1 and r[i] = max(i - c + 1, 0)):
      position renumbering m[i] = min(r[i], M - g)
      d[i,j] = m[i] - m[j]; when causal = False, d[i,j] = abs(d[i,j])
      valid[i,j] = (i == j) or d[i,j] > 0
      when A > 0, valid[i,j] additionally requires d[i,j] <= A
      when c > 0, valid[i,j] is additionally relaxed to true when m[i] == 0 and
      m[j] < M - g
      out[s+i, h, :] = sum_j valid[i,j] * SiLU(alpha*<q[s+i,h,:], k[s+j,h,:]>) / N
                       * v[s+j,h,:]
    where SiLU(x) = x*sigmoid(x). When causal = True, valid is lower triangular
    (including the diagonal); the weights get no softmax and no sum
    normalization, and masked positions contribute exactly 0.
    Boundary behaviour: the last g tokens of a sequence are targets and are
    excluded from the key side by the renumbering truncation; g = 0 is equivalent
    to no target exclusion; when c > 0 the first c tokens (renumbered m = 0)
    additionally see all non-target keys (including each other); an empty
    sequence (L = 0) is legal and produces no output rows; a sequence may be
    shorter than N, and the scaling denominator is always N (not that sequence's
    own length).

    Input/output specification:
      q            [total, num_heads, qk_dim]   float16 / bfloat16
      k            [total, num_heads, qk_dim]   same dtype as q
      v            [total, num_heads, v_dim]    same dtype as q; v_dim may differ from qk_dim
      seq_offsets  [batch + 1] int64, monotonically non-decreasing, first element 0, last element total
      num_targets  [batch] int32, 0 <= num_targets[b] and c + num_targets[b] <= L_b
      out          [total, num_heads, v_dim], same dtype as v
    Global-domain constraints: 0 <= L_b <= max_seq_len; qk_dim / v_dim are powers
    of 2 (of order 64..256).

    Hyper-parameters (__init__): max_seq_len (scaling denominator and upper bound
    on length, N); alpha (logits scale, defaults to 1/sqrt(qk_dim)); causal
    (defaults to True); max_attn_len (defaults to 0 = distance not limited);
    contextual_seq_len (defaults to 0 = disabled).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / SiLU / mask / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / torch.matmul / torch.bmm / torch.einsum / torch.softmax /
        torch.nn.functional.silu and their alias forms (F.silu / F.softmax /
        torch.mm / the @ matrix-multiply operator) is forbidden (implement SiLU
        yourself as x*sigmoid(x)).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to v's
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: forward only, non-quantized inputs, no dropout, no
    backpropagation.
    """
    def __init__(self, max_seq_len: int, alpha=None, causal=True, max_attn_len=0, contextual_seq_len=0):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.max_seq_len = int(max_seq_len)
        self.alpha = float(alpha) if alpha is not None else None
        self.causal = bool(causal)
        self.max_attn_len = int(max_attn_len)
        self.contextual_seq_len = int(contextual_seq_len)
        # Target clipping cannot increase the renumbered position span.
        distance_bound = max(0, self.max_seq_len - max(self.contextual_seq_len, 1))
        if self.max_seq_len > 0 and self.max_attn_len > 0 and self.max_attn_len >= distance_bound:
            self.max_attn_len = 0
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, seq_offsets, num_targets):
        # <<<IMPROVE:forward_stmt_1>>>
        seq_offsets = seq_offsets.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        num_targets = num_targets.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B = int(seq_offsets.numel()) - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        alpha = self.alpha if self.alpha is not None else 1.0 / math.sqrt(q.shape[2])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = self.max_seq_len
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        c = self.contextual_seq_len
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        out = torch.empty_like(v)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if B > 0 and N > 0 and q.shape[0] > 0:
            _hstu_fused[(triton.cdiv(N, 16), q.shape[1], B)](
                q, k, v, seq_offsets, num_targets, out,
                *q.stride(), *k.stride(), *v.stride(), *out.stride(),
                q.shape[2], v.shape[2], alpha, N, c,
                self.causal, self.max_attn_len, num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        return out
        # <<<END_IMPROVE>>>
