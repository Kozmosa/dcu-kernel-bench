import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _online_attention(Q, K, V, S, O, L,
                      SQ: tl.constexpr, SK: tl.constexpr, H: tl.constexpr, D: tl.constexpr, G: tl.constexpr,
                      QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr, QS3: tl.constexpr,
                      KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr, KS3: tl.constexpr,
                      VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr, VS3: tl.constexpr,
                      SS0: tl.constexpr, SS1: tl.constexpr,
                      SCALE: tl.constexpr, CAUSAL: tl.constexpr, BD: tl.constexpr,
                      BM: tl.constexpr, BN: tl.constexpr):
    tile = tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    kh = h // G
    i = tile * BM + tl.arange(0, BM)
    d = tl.arange(0, BD)
    n = tl.arange(0, BN)
    q = tl.load(Q + b*QS0 + i[:, None]*QS1 + h*QS2 + d[None, :]*QS3,
                (i[:, None] < SQ) & (d[None, :] < D), 0)
    slope = tl.load(S + b*SS0 + h*SS1)
    m = tl.full((BM,), -float('inf'), tl.float32)
    z = tl.zeros((BM,), tl.float32)
    acc = tl.zeros((BM, BD), tl.float32)
    end = SK
    if CAUSAL:
        end = tl.minimum(SK, tl.maximum(0, (tile + 1)*BM + SK - SQ))
    for start in range(0, end, BN):
        j = start + n
        k = tl.load(K + b*KS0 + j[None, :]*KS1 + kh*KS2 + d[:, None]*KS3,
                    (j[None, :] < SK) & (d[:, None] < D), 0)
        scores = tl.dot(q, k) * SCALE
        rel = i[:, None] + SK - SQ - j[None, :]
        scores = scores - slope * tl.abs(rel).to(tl.float32)
        valid = (i[:, None] < SQ) & (j[None, :] < SK)
        if CAUSAL:
            valid = valid & (rel >= 0)
        scores = tl.where(valid, scores, -float('inf'))
        new_m = tl.maximum(m, tl.max(scores, 1))
        safe_m = tl.where(new_m == -float('inf'), 0.0, new_m)
        alpha = tl.exp(m - safe_m)
        p = tl.exp(scores - safe_m[:, None])
        z = z * alpha + tl.sum(p, 1)
        acc = acc * alpha[:, None]
        v = tl.load(V + b*VS0 + j[:, None]*VS1 + kh*VS2 + d[None, :]*VS3,
                    (j[:, None] < SK) & (d[None, :] < D), 0)
        acc = tl.dot(p, v.to(tl.float32), acc, input_precision='ieee')
        m = new_m
    denom = tl.where(z > 0, z, 1.0)
    out = acc / denom[:, None]
    tl.store(O + ((b*SQ + i[:, None])*H + h)*D + d[None, :], out,
             (i[:, None] < SQ) & (d[None, :] < D))
    lse = tl.where(z > 0, m + tl.log(denom), 0.0)
    tl.store(L + bh*SQ + i, lse, i < SQ)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Dense (padded 4D batch) FlashAttention forward: scaled dot-product attention
    with softmax, bottom-right-aligned causal mask, ALiBi positional bias,
    MHA/GQA, returning both the output and the per-row log-sum-exp (LSE).

    Mathematical definition (for batch element b, query head h, query position i,
    key position j, g = num_q_heads // num_kv_heads, query head h maps to KV head
    h // g):
      score[b,h,i,j] = sm_scale * <q[b,i,h,:], k[b,j,h//g,:]>
                       - alibi_slopes[b,h] * |i + seqlen_k - seqlen_q - j|
      With causal=1 the bottom-right-aligned causal mask is applied: positions
      j > i + seqlen_k - seqlen_q are set to -inf (i.e. query i only attends to
      keys j <= i + seqlen_k - seqlen_q); with causal=0 no mask is applied at all.
      The ALiBi bias is applied in both causal and non-causal mode; all-zero
      slopes are equivalent to no ALiBi.
      p[b,h,i,:] = softmax_j(score[b,h,i,:])   (numerically stable online form)
      out[b,i,h,:] = sum_j p[b,h,i,j] * v[b,j,h//g,:]
      lse[b,h,i] = ln( sum_j exp(score[b,h,i,j]) )   (natural logarithm)
    softmax/accumulation are done in float32, out is cast back to the input dtype,
    lse is float32.
    Boundary behaviour: with causal=1 and seqlen_q > seqlen_k, rows
    i < seqlen_q - seqlen_k are masked out entirely -- those rows have out = 0 and
    lse = 0 (not -inf).

    Input/output specification:
      q            [batch, seqlen_q, num_q_heads, head_dim]   float16/bfloat16
      k, v         [batch, seqlen_k, num_kv_heads, head_dim]  same dtype as q
      causal       0-dim int32 tensor, 1=causal mask, 0=no mask
      alibi_slopes [batch, num_q_heads] float32, elements >= 0 (all zeros = no ALiBi)
      Returns a single 1-D tensor packed (multi-output packing protocol):
      packed = cat([out.reshape(-1).to(float32), lse.reshape(-1)])
      where out [batch, seqlen_q, num_q_heads, head_dim] (computed in the input
      dtype, then cast to float32 for the concatenation) and lse
      [batch, num_q_heads, seqlen_q] float32; total length of packed =
      batch * seqlen_q * num_q_heads * (head_dim + 1).
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (equal means MHA, otherwise GQA); 1 <= seqlen_q, 1 <= seqlen_k (any
    combination, including seqlen_q > seqlen_k); 1 <= head_dim <= 256.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / ALiBi bias / causal mask / softmax / PV / LSE)
        must be completed inside the submitted file; calling ready-made attention /
        matrix-multiplication / softmax routines is forbidden:
        scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax / torch.logsumexp, as is any
        synonymous wrapper from a third-party operator library.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast out back to the input
        dtype, keep lse in float32.
      - forward must return a single 1-D float32 tensor following the packing
        protocol above (compute out and lse internally first, then flatten and
        concatenate them).

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: dense 4D forward, non-quantized inputs, no bias, no dropout, no
    sliding window.
    """
    def __init__(self, head_dim: int, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, causal, alibi_slopes):
        # <<<IMPROVE:forward_stmt_1>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        is_causal = bool(int(causal.to(torch.int32)))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        alibi_slopes = alibi_slopes.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        batch, seqlen_q, nheads_q, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        _, seqlen_k, nheads_k, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = nheads_q // nheads_k
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert nheads_q == nheads_k * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty((batch, seqlen_q, nheads_q, head_dim), device=q.device, dtype=q.dtype)
        lse = torch.empty((batch, nheads_q, seqlen_q), device=q.device, dtype=torch.float32)
        _online_attention[(triton.cdiv(seqlen_q, 32), batch*nheads_q)](
            q, k, v, alibi_slopes, out, lse,
            seqlen_q, seqlen_k, nheads_q, head_dim, group,
            *q.stride(), *k.stride(), *v.stride(), *alibi_slopes.stride(),
            self.sm_scale, is_causal, max(16, triton.next_power_of_2(head_dim)),
            32, 64, num_warps=4, num_stages=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        return torch.cat([out.reshape(-1).to(torch.float32), lse.reshape(-1)])
        # <<<END_IMPROVE>>>
