import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _owned_bwd(Q, K, V, O, LSE, DO, DQ, DK, DV,
               SQ, SK, SV, SO, SL, SD, SQO, SKO, SVO,
               M: tl.constexpr, N: tl.constexpr, D: tl.constexpr,
               G: tl.constexpr, SCALE: tl.constexpr, CAUSAL: tl.constexpr,
               BD: tl.constexpr):
    t = tl.program_id(0)
    hk = tl.program_id(1)
    b = tl.program_id(2)
    rr = tl.arange(0, 32)
    dd = tl.arange(0, BD)
    if t * 32 < N:
        j = t * 32 + rr
        km = (j[:, None] < N) & (dd[None, :] < D)
        kt = tl.load(K + b * SK[0] + j[:, None] * SK[1] + hk * SK[2] + dd[None, :] * SK[3], km, 0)
        vt = tl.load(V + b * SV[0] + j[:, None] * SV[1] + hk * SV[2] + dd[None, :] * SV[3], km, 0)
        ak = tl.full((32, BD), 0, tl.float32)
        av = tl.full((32, BD), 0, tl.float32)
        query_begin = 0
        if CAUSAL:
            query_begin = tl.maximum(0, t * 32 + M - N) // 32
        for gh in range(G):
            h = hk * G + gh
            for start in range(query_begin, tl.cdiv(M, 32)):
                i = start * 32 + rr
                qm = (i[:, None] < M) & (dd[None, :] < D)
                qt = tl.load(Q + b * SQ[0] + i[:, None] * SQ[1] + h * SQ[2] + dd[None, :] * SQ[3], qm, 0)
                dt = tl.load(DO + b * SD[0] + i[:, None] * SD[1] + h * SD[2] + dd[None, :] * SD[3], qm, 0)
                ot = tl.load(O + b * SO[0] + i[:, None] * SO[1] + h * SO[2] + dd[None, :] * SO[3], qm, 0)
                delta = tl.sum(ot.to(tl.float32) * dt.to(tl.float32), 1)
                ls = tl.load(LSE + b * SL[0] + h * SL[1] + i * SL[2], i < M, 0)
                score = tl.dot(qt, tl.trans(kt)) * SCALE
                valid = (i[:, None] < M) & (j[None, :] < N)
                if CAUSAL:
                    valid = valid & (j[None, :] <= i[:, None] + N - M)
                p = tl.exp(tl.where(valid, score - ls[:, None], -float('inf')))
                dp = tl.dot(dt, tl.trans(vt))
                ds = p * (dp - delta[:, None])
                av += tl.dot(tl.trans(p), dt.to(tl.float32), input_precision='ieee')
                ak += tl.dot(tl.trans(ds), qt.to(tl.float32), input_precision='ieee')
        tl.store(DK + b * SKO[0] + j[:, None] * SKO[1] + hk * SKO[2] + dd[None, :] * SKO[3], ak * SCALE, km)
        tl.store(DV + b * SVO[0] + j[:, None] * SVO[1] + hk * SVO[2] + dd[None, :] * SVO[3], av, km)
    if t * 32 < M:
        i = t * 32 + rr
        qm = (i[:, None] < M) & (dd[None, :] < D)
        key_end = tl.cdiv(N, 32)
        if CAUSAL:
            last_i = tl.minimum((t + 1) * 32, M) - 1
            key_limit = tl.minimum(N, tl.maximum(0, last_i + N - M + 1))
            key_end = tl.cdiv(key_limit, 32)
        for gh in range(G):
            h = hk * G + gh
            qt = tl.load(Q + b * SQ[0] + i[:, None] * SQ[1] + h * SQ[2] + dd[None, :] * SQ[3], qm, 0)
            dt = tl.load(DO + b * SD[0] + i[:, None] * SD[1] + h * SD[2] + dd[None, :] * SD[3], qm, 0)
            ot = tl.load(O + b * SO[0] + i[:, None] * SO[1] + h * SO[2] + dd[None, :] * SO[3], qm, 0)
            delta = tl.sum(ot.to(tl.float32) * dt.to(tl.float32), 1)
            ls = tl.load(LSE + b * SL[0] + h * SL[1] + i * SL[2], i < M, 0)
            aq = tl.full((32, BD), 0, tl.float32)
            for start in range(0, key_end):
                j = start * 32 + rr
                km = (j[:, None] < N) & (dd[None, :] < D)
                kt = tl.load(K + b * SK[0] + j[:, None] * SK[1] + hk * SK[2] + dd[None, :] * SK[3], km, 0)
                vt = tl.load(V + b * SV[0] + j[:, None] * SV[1] + hk * SV[2] + dd[None, :] * SV[3], km, 0)
                score = tl.dot(qt, tl.trans(kt)) * SCALE
                valid = (i[:, None] < M) & (j[None, :] < N)
                if CAUSAL:
                    valid = valid & (j[None, :] <= i[:, None] + N - M)
                p = tl.exp(tl.where(valid, score - ls[:, None], -float('inf')))
                dp = tl.dot(dt, tl.trans(vt))
                ds = p * (dp - delta[:, None])
                aq += tl.dot(ds, kt.to(tl.float32), input_precision='ieee')
            tl.store(DQ + b * SQO[0] + i[:, None] * SQO[1] + h * SQO[2] + dd[None, :] * SQO[3], aq * SCALE, qm)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """FlashAttention backward (one-kernel form): given the forward output o and the
    per-row log-sum-exp statistics lse, compute the gradients (dq, dk, dv) from
    (q, k, v, o, lse, do); dK/dV and dQ are produced inside the same kernel
    (dK/dV first, dQ after).

    Mathematical definition (let g = num_q_heads // num_kv_heads and the scaled
    score be s[b,h,i,j] = sm_scale * <q[b,i,h,:], k[b,j,h//g,:]>,
    with sm_scale defaulting to 1/sqrt(head_dim)):
      keep[b,i,j] = (j <= i + seqlen_k - seqlen_q) when causal=1 (bottom-right
                    aligned), always true when causal=0
      p[b,h,i,j]   = exp(s[b,h,i,j] - lse[b,h,i]), and masked positions (keep=0) are always 0
      delta[b,h,i] = sum_d o[b,i,h,d] * do[b,i,h,d]   (computed from the given o)
      dp[b,h,i,j]  = <do[b,i,h,:], v[b,j,h//g,:]>
      ds[b,h,i,j]  = p[b,h,i,j] * (dp[b,h,i,j] - delta[b,h,i])
      dv[b,j,h_k,d] = sum_{h = h_k*g .. h_k*g+g-1} sum_i p[b,h,i,j] * do[b,i,h,d]
      dk[b,j,h_k,d] = sm_scale * sum_{h in the same group} sum_i ds[b,h,i,j] * q[b,i,h,d]
      dq[b,i,h,d]   = sm_scale * sum_j ds[b,h,i,j] * k[b,j,h//g,d]
    Note that dK/dQ are multiplied by sm_scale at the end while dV is not; delta
    uses the input o (not the ideal forward output).
    Boundary behaviour: when causal=1 and i < seqlen_q - seqlen_k the row is fully
    masked -- p/ds are always 0, the dq row is all 0, and it contributes nothing to
    dk/dv (the task input convention sets o=0 and lse=0 for those rows).

    Input/output specification:
      q, o, do  [batch, seqlen_q, num_q_heads, head_dim] float16/bfloat16
      k, v      [batch, seqlen_k, num_kv_heads, head_dim] same dtype as q
      lse       [batch, num_q_heads, seqlen_q] float32 -- natural-log log-sum-exp of
                the scaled scores (0 for fully masked rows)
      returns a single 1-D tensor packed (multi-output packing protocol):
      packed = cat([dq flattened, dk flattened, dv flattened]) (each segment is
      first cast back to the input dtype, then converted to float32)
      where dq has the same shape as q and dk/dv the same shape as k; the total
      length of packed is
      (batch*seqlen_q*num_q_heads + 2*batch*seqlen_k*num_kv_heads) * head_dim.
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
      (GQA; equal means MHA); 1 <= head_dim <= 256 (need not be a power of 2);
      1 <= seqlen_q, seqlen_k; o and lse are the self-consistent forward statistics
      of (q, k, v) (guaranteed by the task's input generator).

    Implementation constraints (violations are scored as failures):
      - The core computation (all matrix multiplies and elementwise operations of
        delta / p / ds / dV / dK / dQ) must be done inside the submitted file;
        calling scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden, and so are
        automatic-differentiation shortcuts such as torch.autograd /
        autograd.grad / .backward(.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - forward must return a single 1-D float32 tensor following the packing
        protocol above (compute dq/dk/dv internally first, then flatten and
        concatenate each).

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: dense fixed-length (non-varlen), non-quantized inputs, no dropout /
    ALiBi / bias / fp8; causal and non-causal are selected by __init__'s causal
    switch.
    """
    def __init__(self, head_dim: int, causal: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.head_dim = int(head_dim)
        self.causal = bool(int(causal))
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, o, lse, do):
        # <<<IMPROVE:forward_stmt_1>>>
        B, M, H_Q, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        _, N, H_K, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        group = H_Q // H_K
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert H_Q == H_K * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        causal = bool(self.causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dq = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        dk = torch.zeros(B, N, H_K, D, dtype=torch.float32, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        dv = torch.zeros_like(dk)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _owned_bwd[(max(triton.cdiv(N, 32), triton.cdiv(M, 32)), H_K, B)](
            q, k, v, o, lse, do, dq, dk, dv,
            q.stride(), k.stride(), v.stride(), o.stride(), lse.stride(), do.stride(),
            dq.stride(), dk.stride(), dv.stride(),
            M, N, D, group, self.sm_scale, causal,
            max(16, triton.next_power_of_2(D)), num_warps=4, num_stages=1,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return torch.cat([
            dq.reshape(-1).to(k.dtype).to(torch.float32),
            dk.reshape(-1).to(k.dtype).to(torch.float32),
            dv.reshape(-1).to(v.dtype).to(torch.float32),
        ])
        # <<<END_IMPROVE>>>
