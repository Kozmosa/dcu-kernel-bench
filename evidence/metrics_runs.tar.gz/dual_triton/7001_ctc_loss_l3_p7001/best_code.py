import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _lse3(a, b, c):
    m = tl.maximum(a, tl.maximum(b, c))
    shift = tl.where(m == -float('inf'), 0.0, m)
    v = shift + tl.log(tl.exp(a - shift) + tl.exp(b - shift) + tl.exp(c - shift))
    return tl.where(m == -float('inf'), -float('inf'), v)

@triton.jit
def _persistent_ctc(P, Labels, LL, IL, A, Loss, G,
                    T: tl.constexpr, N: tl.constexpr, C: tl.constexpr,
                    B: tl.constexpr, BLANK: tl.constexpr, NB: tl.constexpr):
    n = tl.program_id(0)
    ns = tl.arange(0, NB)
    offset = tl.sum(tl.load(LL + ns, (ns < n) & (ns < N), other=0).to(tl.int32), 0)
    length = tl.load(LL + n).to(tl.int32)
    tb = tl.load(IL + n).to(tl.int32)
    S = 2 * length + 1
    s = tl.arange(0, B)
    valid = s < S
    ext = tl.load(Labels + offset + s // 2, valid & (s % 2 == 1), other=BLANK).to(tl.int32)
    prev_ext = tl.gather(ext, tl.maximum(s - 2, 0), 0)
    next_ext = tl.gather(ext, tl.minimum(s + 2, B - 1), 0)
    skip_left = (s >= 2) & (ext != BLANK) & (ext != prev_ext)
    skip_right = (s + 2 < S) & (ext != BLANK) & (ext != next_ext)
    emission = tl.log(tl.load(P + n * C + ext, valid, other=1.0))
    alpha = tl.where(s < 2, emission, -float('inf'))
    tl.store(A + (n * T) * B + s, alpha)
    for t in range(1, tb):
        left = tl.where(s >= 1, tl.gather(alpha, tl.maximum(s - 1, 0), 0), -float('inf'))
        jump = tl.where(skip_left, tl.gather(alpha, tl.maximum(s - 2, 0), 0), -float('inf'))
        emission = tl.log(tl.load(P + (t * N + n) * C + ext, valid, other=1.0))
        alpha = tl.where(valid, emission + _lse3(alpha, left, jump), -float('inf'))
        tl.store(A + (n * T + t) * B + s, alpha)
    end1 = tl.max(tl.where(s == S - 1, alpha, -float('inf')), 0)
    end2 = tl.max(tl.where(s == S - 2, alpha, -float('inf')), 0)
    z = _lse3(end1, end2, -float('inf'))
    tl.store(Loss + n, -z)
    beta = tl.where((s == S - 1) | (s == S - 2), 0.0, -float('inf'))
    for step in range(tb):
        t = tb - 1 - step
        alpha_t = tl.load(A + (n * T + t) * B + s)
        gamma = tl.exp((alpha_t + beta) - z)
        tl.atomic_add(G + (n * T + t) * C + ext, -gamma, valid, sem='relaxed')
        emission = tl.log(tl.load(P + (t * N + n) * C + ext, valid, other=1.0))
        nxt = beta + emission
        right = tl.where(s + 1 < S, tl.gather(nxt, tl.minimum(s + 1, B - 1), 0), -float('inf'))
        jump = tl.where(skip_right, tl.gather(nxt, tl.minimum(s + 2, B - 1), 0), -float('inf'))
        beta = tl.where(valid, _lse3(nxt, right, jump), -float('inf'))

@triton.jit
def _finish_ctc(P, G, T: tl.constexpr, N: tl.constexpr, C: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    mask = i < N * T * C
    k = i % C
    t = (i // C) % T
    n = i // (T * C)
    p = tl.load(P + (t * N + n) * C + k, mask, other=1.0)
    g = tl.load(G + i, mask, other=0.0)
    tl.store(G + i, g / p, mask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """CTC (Connectionist Temporal Classification) forward loss: one forward pass
    produces both the per-sequence CTC loss and the gradient with respect to the
    input probabilities. The input probs holds **probabilities**, not logits
    (equivalent to the production library's apply_softmax=False convention: take
    the log of probs directly, no softmax), positive every frame along the class
    dimension and summing to 1; the blank class id is given by a hyperparameter
    (always 0 in the generation domain).

    Layout and input contract (time-major inputs):
      probs          (T, N, C) floating-point probability tensor, T=max_time,
                     N=batch, C=num_classes
      labels         (sum(label_lengths),) integer, the flattened label sequences
                     concatenated in batch order; label values lie in [0, C-1]
                     and are not equal to blank ([1, C-1] in the generation
                     domain)
      label_lengths  (N,) integer, target length of each sequence
      input_lengths  (N,) integer, number of valid input frames of each sequence
                     (1 <= input_lengths[n] <= T)
    Mathematical definition (for each sequence n, write Tb=input_lengths[n], the
    target l_1..l_L (L=label_lengths[n]) and the extended state sequence
    ext = [b, l_1, b, l_2, ..., b, l_L, b] (blank inserted before and after and
    between every two labels), S = 2L+1 states, s = 0..S-1; every recurrence runs
    in log space in float32, with -inf meaning unreachable):
      forward variable alpha (shape (Tb, S)):
        alpha[0,0] = log p[0, blank]; alpha[0,1] = log p[0, ext[1]] (S>1);
        everything else -inf
        alpha[t,s] = log p[t, ext[s]] + LSE( alpha[t-1,s], alpha[t-1,s-1],
                     alpha[t-1,s-2] (only when ext[s] != blank and
                     ext[s] != ext[s-2]) )
      backward variable beta (symmetric; beta does not include the emission of
      the current frame, so that alpha+beta counts every emission factor exactly
      once along each complete alignment path through state s):
        beta[Tb-1,S-1] = beta[Tb-1,S-2] = 0 (S>1), everything else -inf
        beta[t,s] = LSE( log p[t+1,ext[s]] + beta[t+1,s],
                         log p[t+1,ext[s+1]] + beta[t+1,s+1],
                         log p[t+1,ext[s+2]] + beta[t+1,s+2]
                         (the last term only when ext[s] != blank and
                         ext[s] != ext[s+2]) )
      losses[n] = -log Z, Z = LSE( alpha[Tb-1,S-1], alpha[Tb-1,S-2] )
        (the probability sum over all legal alignment paths; the reduction is the
        per-sequence 'none')
      gamma[t,s] = exp( alpha[t,s] + beta[t,s] - log Z )
      gradients[n,t,k] = d losses[n] / d probs[n,t,k]
        = -(1 / p[t,k]) * sum_{s: ext[s]=k} gamma[t,s], t < Tb; 0 for t >= Tb
    forward returns **a single 1-D tensor** out (dtype same as probs, the
    single-tensor packing protocol):
      out[0:N]         = losses (N entries)
      out[N : N+N*T*C] = gradients flattened in (N, T, C) row-major order
    Boundary behaviour:
      - the generation domain guarantees probs strictly positive (the softmax
        convention), labels without consecutive repeats and L <= Tb, so Z is
        finite with no inf/NaN; losses are on the order of <= T*ln(C), which fp16
        can represent.
      - the alpha/beta of unreachable states are -inf and the matching gamma is 0.
      - the gradient is defined with respect to the probability input (not the
        log probability): the chain factor 1/p[t,k] is already part of the
        definition.

    Input/output specification:
      probs          float32 / float16 / bfloat16 (T, N, C), contiguous
      labels / label_lengths / input_lengths   integer (...,), contiguous
      out            a single 1-D tensor, same dtype as probs, length N + N*T*C
      The evaluator casts all inputs to fp32 before passing them in (integer
      tensors must be restored to long by the implementation; their integer
      values are losslessly representable in fp32).

    Implementation constraints (violations are scored as failures):
      - Core computation (log probabilities, the alpha/beta forward-backward
        recurrence, gradient assembly) must be done with a Triton kernel inside
        the submitted file.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate computation happens in float32 (cast probs to fp32 first,
        then take the log); the output is cast back to the probs dtype and then
        concatenated into a single tensor per the packing protocol above.
      - forward returns the single tensor out (the evaluator compares a single
        output).

    Disallowed list: aiter / torch.nn.functional.ctc_loss / torch.ctc_loss /
    F.ctc_loss / torch.nn.CTCLoss / torch.ops.aten.ctc_loss /
    torch.ops.aten._ctc_loss / aten.ctc_loss / .ctc_loss( (including every
    library-level one-step CTC primitive) / warpctc / warp_ctc / torch.autograd
    and .backward() (automatic differentiation must not be used to obtain the
    gradient).
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single blank, reduction='none' (per-sequence loss plus the full
    gradient), the input is already a probability (no apply_softmax branch), and
    there are no empty target sequences.
    """
    def __init__(self, blank: int = 0):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.blank = int(blank)
        # <<<END_IMPROVE>>>

    def forward(self, probs, labels, label_lengths, input_lengths):
        # <<<IMPROVE:forward_stmt_1>>>
        labels = labels.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        label_lengths = label_lengths.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        input_lengths = input_lengths.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pf = probs.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        max_time, batch, num_classes = pf.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        state_bound = triton.next_power_of_2(2 * min(max_time, labels.numel()) + 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        losses = torch.empty(batch, dtype=torch.float32, device=pf.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        grads = torch.zeros(batch, max_time, num_classes, dtype=torch.float32, device=pf.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        alpha_history = torch.empty((batch, max_time, state_bound), dtype=torch.float32, device=pf.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        _persistent_ctc[(batch,)](
            pf, labels, label_lengths, input_lengths, alpha_history, losses, grads,
            max_time, batch, num_classes, state_bound, self.blank,
            triton.next_power_of_2(batch), num_warps=4, enable_fp_fusion=False)
        _finish_ctc[(triton.cdiv(batch * max_time * num_classes, 256),)](
            pf, grads, max_time, batch, num_classes, 256, num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        losses = losses.to(probs.dtype).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        grads = grads.to(probs.dtype).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return torch.cat((losses, grads))
        # <<<END_IMPROVE>>>

    def _ctc_one(self, logp_b, p_b, target, tb, num_classes, max_time):
        # Single-sequence log-space forward-backward: logp_b / p_b are the (T, C)
        # fp32 log probabilities / probabilities, target is (L,) long, tb is the
        # number of valid frames; returns (loss_n, grad_n) with grad_n of shape
        # (max_time, C), always 0 outside the valid frames
        C = num_classes
        L = target.numel()
        S = 2 * L + 1
        neg_inf = float("-inf")
        # device=dev is required: every intermediate tensor built inside this
        # function must live on the same device as logp_b/p_b, which are already
        # on it; omitting device raises "Expected all tensors to be on the same
        # device" on CUDA/DCU (it works on CPU, so local unit tests cannot catch
        # it)
        dev = logp_b.device

        ext = torch.empty(S, dtype=torch.long, device=dev)
        ext[0::2] = self.blank
        ext[1::2] = target

        lp_ext = logp_b[:tb, ext]                      # (tb, S)
        alpha = torch.full((tb, S), neg_inf, dtype=torch.float32, device=dev)
        beta = torch.full((tb, S), neg_inf, dtype=torch.float32, device=dev)

        # Forward recurrence (stepping over the time dimension, the state
        # dimension vectorized as a whole)
        alpha[0, 0] = lp_ext[0, 0]
        alpha[0, 1] = lp_ext[0, 1]
        for t in range(1, tb):
            prev = alpha[t - 1]
            left = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            left[1:] = prev[:-1]
            jump = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            jump[2:] = prev[:-2]
            ok = (ext[2:] != self.blank) & (ext[2:] != ext[:-2])
            jump[2:] = torch.where(ok, jump[2:], torch.full((S - 2,), neg_inf, dtype=torch.float32, device=dev))
            alpha[t] = lp_ext[t] + torch.logsumexp(torch.stack((prev, left, jump)), dim=0)

        # Backward recurrence (beta excludes the current frame's emission:
        # alpha+beta counts every emission factor exactly once along a complete
        # path through state s, so gamma is the state posterior)
        beta[tb - 1, S - 1] = 0.0
        beta[tb - 1, S - 2] = 0.0
        for t in range(tb - 2, -1, -1):
            nxt = beta[t + 1] + lp_ext[t + 1]
            right = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            right[:-1] = nxt[1:]
            jump = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            jump[:-2] = nxt[2:]
            ok = (ext[:-2] != self.blank) & (ext[:-2] != ext[2:])
            jump[:-2] = torch.where(ok, jump[:-2], torch.full((S - 2,), neg_inf, dtype=torch.float32, device=dev))
            beta[t] = torch.logsumexp(torch.stack((nxt, right, jump)), dim=0)

        log_z = torch.logsumexp(alpha[tb - 1] + beta[tb - 1], dim=0)
        gamma = torch.exp(alpha + beta - log_z)        # (tb, S) state posterior

        # dL/dp[t,k] = -(1/p[t,k]) * sum_{s: ext[s]=k} gamma[t,s]
        grad = torch.zeros(tb, C, dtype=torch.float32, device=dev)
        grad.index_add_(1, ext, -gamma)
        grad = grad / p_b[:tb]                         # divide by p (probs is strictly positive)

        grad_full = torch.zeros(max_time, C, dtype=torch.float32, device=dev)
        grad_full[:tb] = grad
        return -log_z, grad_full
