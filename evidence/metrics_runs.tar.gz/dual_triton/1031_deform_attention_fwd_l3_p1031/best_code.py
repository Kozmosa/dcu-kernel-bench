import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _deform_attention_kernel(value, spatial_shapes, level_start_index, sampling_locations, attention_weights, out, n_queries: tl.constexpr, n_keys: tl.constexpr, num_heads: tl.constexpr, d: tl.constexpr, n_levels: tl.constexpr, n_points: tl.constexpr, BLOCK_S: tl.constexpr, BLOCK_D: tl.constexpr):
    row = tl.program_id(0)
    cb = tl.program_id(1)
    c = cb * BLOCK_D + tl.arange(0, BLOCK_D)
    cmask = c < d
    s = tl.arange(0, BLOCK_S)
    point_mask = s < n_levels * n_points

    qh = row % (n_queries * num_heads)
    bn = row // (n_queries * num_heads)
    q = qh // num_heads
    hd = qh % num_heads

    lp = n_levels * n_points
    safe_s = tl.where(point_mask, s, 0)
    lev = safe_s // n_points
    pt = safe_s - lev * n_points
    h_meta = tl.load(spatial_shapes + lev * 2, mask=point_mask, other=1.0).to(tl.int32)
    w_meta = tl.load(spatial_shapes + lev * 2 + 1, mask=point_mask, other=1.0).to(tl.int32)
    starts = tl.load(level_start_index + lev, mask=point_mask, other=0.0).to(tl.int32)

    score_base = (bn * n_queries + q) * num_heads * lp + hd * lp
    scores = tl.load(attention_weights + score_base + safe_s, mask=point_mask, other=-float('inf')).to(tl.float32)
    row_max = tl.max(scores, axis=0)
    ex = tl.exp(scores - row_max)
    ex = tl.where(point_mask, ex, 0.0)
    denom = tl.sum(ex, axis=0)
    weights = ex / denom

    loc_base = ((bn * n_queries + q) * num_heads + hd) * lp * 2
    loc_off = loc_base + safe_s * 2
    x = tl.load(sampling_locations + loc_off, mask=point_mask, other=0.0).to(tl.float32)
    y = tl.load(sampling_locations + loc_off + 1, mask=point_mask, other=0.0).to(tl.float32)
    sx = x * w_meta.to(tl.float32)
    sy = y * h_meta.to(tl.float32)
    ix = tl.floor(sx).to(tl.int32)
    iy = tl.floor(sy).to(tl.int32)
    fx = sx - ix.to(tl.float32)
    fy = sy - iy.to(tl.float32)

    acc = tl.zeros((BLOCK_S, BLOCK_D), dtype=tl.float32)
    value_base = bn * n_keys * num_heads * d + hd * d
    for corner_id in range(4):
        if corner_id == 0:
            cy = iy
            cx = ix
            cw = (1.0 - fy) * (1.0 - fx)
        elif corner_id == 1:
            cy = iy
            cx = ix + 1
            cw = (1.0 - fy) * fx
        elif corner_id == 2:
            cy = iy + 1
            cx = ix
            cw = fy * (1.0 - fx)
        else:
            cy = iy + 1
            cx = ix + 1
            cw = fy * fx
        valid = point_mask & (cy >= 0) & (cy < h_meta) & (cx >= 0) & (cx < w_meta)
        safe_y = tl.maximum(cy, 0)
        safe_y = tl.minimum(safe_y, h_meta - 1)
        safe_x = tl.maximum(cx, 0)
        safe_x = tl.minimum(safe_x, w_meta - 1)
        flat = starts + safe_y * w_meta + safe_x
        offs = value_base + flat[:, None] * num_heads * d + c[None, :]
        vals = tl.load(value + offs, mask=valid[:, None] & cmask[None, :], other=0.0).to(tl.float32)
        acc += vals * (weights * cw)[:, None]

    out_off = row * d + c
    tl.store(out + out_off, tl.sum(acc, axis=0), mask=cmask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Multi-Scale Deformable Attention forward: value sampling + hand-written
    bilinear interpolation + softmax normalization of the sampling weights.

    Semantics (all intermediate computation in float32): value (N, n_keys, heads,
    D) is the concatenation of the multi-scale feature levels -- level l
    contributes spatial_shapes[l] = (H_l, W_l) keys, laid out inside the level in
    row-major order (H first, then W) over
    [level_start_index[l], level_start_index[l] + H_l*W_l), where
    level_start_index must be the prefix sum of the per-level H_l*W_l (first
    element 0) and n_keys = sum_l H_l*W_l. sampling_locations
    (N, Q, heads, L, P, 2) gives the normalized coordinates of every
    (batch, query, head) at every sampling point of every level, with the last
    dimension being (x, y): channel 0 runs along W and channel 1 along H (the
    generation domain is [0,1)), so the actual sampling coordinates are
        loc_x = x * W_l,  loc_y = y * H_l
    The sampled value goes through four-corner bilinear interpolation:
        ix0 = floor(loc_x), iy0 = floor(loc_y), fx = loc_x - ix0, fy = loc_y - iy0
        the weights of the four corners (iy0,ix0), (iy0,ix0+1), (iy0+1,ix0),
        (iy0+1,ix0+1) are, in that order,
        (1-fy)(1-fx), (1-fy)fx, fy(1-fx), fy*fx
    When a corner's row or column is out of range (< 0 or > dim-1) that corner
    contributes 0 while the other corners are weighted as usual -- i.e. zero
    padding semantics, with no clamp / nearest-neighbour pull-back anywhere in the
    computation; when the coordinates are entirely out of range the sampled value
    is 0.
    attention_weights (N, Q, heads, L, P) are non-negative unnormalized scores:
    first flatten (levels x points) into one dimension and run a numerically
    stable softmax (max subtraction) to normalize them into convex-combination
    weights, then take the weighted sum against the interpolated value of each
    sampling point:
        out[n, q, h*D + d] = sum_{l, p} w[n,q,h,l,p] * bilinear(value_l)[n,q,h,p,d]
    The output is the single tensor out (N, Q, heads*D), cast back to the value
    dtype (naturally a single output, no multi-output packing). When L*P = 1 the
    softmax weights are identically 1.

    Input/output specification (all tensors contiguous):
      value              float32 / float16 (N, n_keys, heads, D)
      spatial_shapes     int64 (L, 2), each row (H_l, W_l), H_l / W_l >= 1
      level_start_index  int64 (L,), prefix sum of the per-level key counts
      sampling_locations same dtype as value (N, Q, heads, L, P, 2), generation domain [0,1)
      attention_weights  same dtype as value (N, Q, heads, L, P), non-negative
      out                single tensor, same dtype as value (N, Q, heads*D)
      every dimension is an arbitrary positive integer (including 1, non-powers
      of 2, and non-16-aligned sizes; a single-level single-pixel (H_l, W_l) =
      (1, 1), and 1xN / Nx1 thin-strip levels are all legal boundaries). The
      evaluator casts every input to fp32 before passing it in (lossless for both
      the low precision and the int64 indices -- an index value <= 2^24 is exactly
      representable in fp32), so the implementation must restore
      spatial_shapes / level_start_index to integer indices before using them.

    Implementation constraints (violations are scored as failures):
      - The core computation (coordinate expansion, four-corner bilinear
        interpolation, softmax normalization of the weights, and the cross-level
        cross-point weighted reduction) must be hand-written as a Triton kernel
        inside the submitted file.
      - The softmax, the interpolation and the weighted reduction are done in
        float32, and the output is cast back to the value dtype.
      - forward returns the single tensor out (N, Q, heads*D) (the evaluator
        compares a single output).
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden list: torchvision (including ready-made deformable attention /
    deformable convolution primitives such as torchvision.ops.ms_deform_attn),
    mmcv, miopen, hipdnn, aiter,
    torch.nn.functional.grid_sample (F.grid_sample),
    torch.nn.functional.interpolate (F.interpolate), torch.matmul /
    torch.bmm / torch.mm / torch.einsum / torch.tensordot,
    torch.softmax / torch.nn.functional.softmax (F.softmax).
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # Launch tuning deferred: forward_stmt_18 is frozen.
        # <<<END_IMPROVE>>>

    def forward(self, value, spatial_shapes, level_start_index, sampling_locations, attention_weights):
        # <<<IMPROVE:forward_stmt_1>>>
        # Metadata is restored to integer indices inside the Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Metadata remains on device for direct kernel loads.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        n, n_keys, num_heads, d = value.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        n_levels = spatial_shapes.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_queries = sampling_locations.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_points = sampling_locations.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert sampling_locations.dim() == 6 \
            and sampling_locations.shape[2] == num_heads \
            and sampling_locations.shape[3] == n_levels \
            and sampling_locations.shape[5] == 2, \
            "sampling_locations must be (N, Q, heads, L, P, 2)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert attention_weights.shape == (n, n_queries, num_heads, n_levels, n_points), \
            "attention_weights must be (N, Q, heads, L, P)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Inputs follow the specified valid prefix-sum and total-key-count contract.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # Value promotion to float32 is performed on kernel loads.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Sampling locations are loaded and promoted inside the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Attention scores are loaded and promoted inside the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Sampling points are indexed directly as a flattened level-point axis.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # Stable softmax normalization is implemented in the fused Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # Batch indices are derived from Triton program ids.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # Head indices are derived from Triton program ids.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        out = torch.empty((n, n_queries, num_heads * d), device=value.device, dtype=value.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        lp = n_levels * n_points
        sample_block = 1 << (lp - 1).bit_length()
        grid = (n * n_queries * num_heads, triton.cdiv(d, 32))
        _deform_attention_kernel[grid](
            value, spatial_shapes, level_start_index,
            sampling_locations, attention_weights, out,
            n_queries, n_keys, num_heads, d, n_levels, n_points,
            BLOCK_S=sample_block, BLOCK_D=32, num_warps=4
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        return out
        # <<<END_IMPROVE>>>
