import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _routed_gemm(A, B, W, S, E, P, C,
                 M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
                 TOP: tl.constexpr, EM: tl.constexpr,
                 AM: tl.constexpr, AK: tl.constexpr,
                 BE: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
                 WM: tl.constexpr, WJ: tl.constexpr,
                 SS: tl.constexpr, ES: tl.constexpr):
    row_start = tl.program_id(0) * 64
    padded = tl.load(P).to(tl.int32)
    if row_start < padded:
        expert = tl.load(E + tl.program_id(0) * ES).to(tl.int32)
        rows = row_start + tl.arange(0, 64)
        slots = tl.load(S + rows * SS, (rows < padded) & (rows < EM), other=M * TOP).to(tl.int32)
        valid = slots < M * TOP
        tokens = slots // TOP
        ns = tl.program_id(1) * 64 + tl.arange(0, 64)
        ks = tl.arange(0, 64)
        acc = tl.zeros((64, 64), tl.float32)
        for block in range(tl.cdiv(K, 64)):
            kk = block * 64 + ks
            av = tl.load(A + tokens[:, None] * AM + kk[None, :] * AK,
                         valid[:, None] & (kk[None, :] < K), other=0)
            bv = tl.load(B + expert * BE + ns[None, :] * BN + kk[:, None] * BK,
                         (ns[None, :] < N) & (kk[:, None] < K), other=0)
            acc = tl.dot(av, bv, acc)
        weight = tl.load(W + tokens * WM + (slots % TOP) * WJ, valid, other=0).to(tl.float32)
        result = acc * weight[:, None]
        tl.store(C + slots[:, None] * N + ns[None, :], result,
                 valid[:, None] & (ns[None, :] < N))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """MoE (Mixture-of-Experts) routed grouped GEMM: non-quantized weights, with
    routing weighting.

    Each token's feature vector A[m] (K dimensions) is dispatched by the routing
    table topk_ids to top_k of the num_experts experts; expert e owns the weight
    matrix B[e] (N x K). For each token m and its j-th routing slot (write
    e = topk_ids[m, j]), the output is defined as

        C[m, j, n] = topk_weights[m, j] * sum_k A[m, k] * B[e, n, k]

    i.e. grouped GEMM followed by a per-slot multiply by the routing weight;
    intermediate accumulation is float32 and the output is cast back to the
    input dtype. Every (m, j) slot hits a legal expert inside [0, num_experts),
    so no output is undefined.

    The inputs also carry the block-aligned layout of grouped GEMM (produced by
    the upstream router; fetching data through it is exactly equivalent to
    computing the formula above directly):
      - sorted_token_ids: int32, length EM = M*top_k + num_experts*(block_m-1),
        with block_m always 64 in this task. Number the slots flat as
        p = m*top_k + j, regroup them by ascending expert id, and pad each group
        up to a multiple of block_m; the intra-group padding positions and the
        array tail hold the sentinel value M*top_k (that is num_valid_tokens;
        offs_token >= it means padding and produces no output).
      - expert_ids: int32, length M*top_k + num_experts; the expert id owning
        block t (covering sorted_token_ids[t*block_m : (t+1)*block_m]), values
        in [0, num_experts), no -1; positions past the number of blocks implied
        by num_tokens_post_padded are sentinel fill and must not be read.
      - num_tokens_post_padded: int32 scalar (length 1), the valid length of
        sorted_token_ids (intra-block padding included), always a multiple of
        block_m.
    The kernel's BLOCK_SIZE_M must divide block_m (that is, be a factor of 64)
    so that every program block sees a single expert.

    Input/output specification:
        A                       (M, K)             float16/bfloat16
        B                       (E, N, K)          same as A (E = num_experts)
        topk_weights            (M, top_k)         float32
        topk_ids                (M, top_k)         int32
        sorted_token_ids        (EM,)              int32
        expert_ids              (M*top_k + E,)     int32
        num_tokens_post_padded  (1,)               int32
        returns C               (M, top_k, N)      dtype same as A

    Implementation constraints (violations are scored as failures):
        - Core computation (layout-driven data fetch + grouped GEMM + weighted
          routing write-out) must be done in a Triton kernel inside the
          submitted file; calling torch.matmul / torch.mm / torch.bmm /
          torch.baddbmm / torch.addmm / torch.einsum /
          torch.nn.functional.linear or any precompiled operator library for
          any matrix multiply is forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate accumulation; the output is cast back to
          the input dtype.
        - Sentinel padding slots must not contaminate any valid output.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: non-quantized fp16/bf16 weights and activations (no w8a8 / int4 /
    mxfp4 quantization), no fused activation (SiLU/GELU etc.), no bias,
    top_k <= 8, num_experts <= 256.
    """
    def __init__(self, num_experts: int, top_k: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = num_experts
        self.top_k = top_k
        # <<<END_IMPROVE>>>

    def forward(self, A, B, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        # <<<IMPROVE:forward_stmt_1>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens_post_padded = num_tokens_post_padded.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = A.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        E, N, _ = B.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty((M, top_k, N), dtype=A.dtype, device=A.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        if M > 0 and N > 0:
            _routed_gemm[(triton.cdiv(sorted_token_ids.numel(), 64), triton.cdiv(N, 64))](
                A, B, topk_weights, sorted_token_ids, expert_ids, num_tokens_post_padded, out,
                M, N, K, top_k, sorted_token_ids.numel(),
                A.stride(0), A.stride(1), B.stride(0), B.stride(1), B.stride(2),
                topk_weights.stride(0), topk_weights.stride(1),
                sorted_token_ids.stride(0), expert_ids.stride(0),
                num_warps=4, num_stages=1,
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return out
        # <<<END_IMPROVE>>>
