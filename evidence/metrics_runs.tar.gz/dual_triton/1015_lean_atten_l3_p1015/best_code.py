import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _ragged_attention(Q, K, V, O, Starts, Lens,
                      QLEN: tl.constexpr, H: tl.constexpr, D: tl.constexpr,
                      SCALE: tl.constexpr, CAUSAL: tl.constexpr,
                      QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
                      KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr,
                      VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr,
                      OS0: tl.constexpr, OS1: tl.constexpr, OS2: tl.constexpr,
                      BD: tl.constexpr, BK: tl.constexpr):
    pid = tl.program_id(0)
    row = pid // H
    head = pid % H
    batch = row // QLEN
    pos = row % QLEN
    start = tl.load(Starts + batch)
    length = tl.load(Lens + batch)
    if CAUSAL:
        length = tl.minimum(length, pos + 1)
    d = tl.arange(0, BD)
    j = tl.arange(0, BK)
    query = tl.load(Q + row * QS0 + head * QS1 + d * QS2,
                    d < D, other=0).to(tl.float32)
    maximum = tl.full((), -float('inf'), tl.float32)
    denominator = tl.full((), 0.0, tl.float32)
    acc = tl.full((BD,), 0.0, tl.float32)
    for base in range(0, length, BK):
        idx = base + j
        mask = (idx[:, None] < length) & (d[None, :] < D)
        keys = tl.load(K + (start + idx[:, None]) * KS0 + head * KS1
                       + d[None, :] * KS2, mask, other=0).to(tl.float32)
        scores = tl.sum(keys * query[None, :], axis=1) * SCALE
        scores = tl.where(idx < length, scores, -float('inf'))
        new_maximum = tl.maximum(maximum, tl.max(scores, axis=0))
        alpha = tl.exp(maximum - new_maximum)
        p = tl.exp(scores - new_maximum)
        values = tl.load(V + (start + idx[:, None]) * VS0 + head * VS1
                         + d[None, :] * VS2, mask, other=0).to(tl.float32)
        acc = acc * alpha + tl.sum(p[:, None] * values, axis=0)
        denominator = denominator * alpha + tl.sum(p, axis=0)
        maximum = new_maximum
    tl.store(O + row * OS0 + head * OS1 + d * OS2,
             acc / denominator, d < D)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Attention forward pass over ragged batches with variable-length KV (Lean
    Attention semantics: contiguous, non-paged KV, softmax inside a single
    kernel), covering both decode (independent KV lengths per batch entry) and
    prefill (square causal self-attention) forms, with MHA (Q/K/V head counts
    equal).

    Mathematical definition: the batch holds num_seqs sequences, sequence b has an
    actually participating KV length kv_lens[b] (>= 1), and every query segment has
    the same length q_len (total_q = num_seqs * q_len, with q stored in
    sequence-major order). Let start_k = kv_lens[0] + ... + kv_lens[b-1] (k/v are
    likewise stored contiguously in sequence-major order). For every sequence b,
    head h, query position i (0 <= i < q_len) and KV position j
    (0 <= j < kv_lens[b]):
      scores[i, j] = sm_scale * <q[b*q_len+i, h, :], k[start_k+j, h, :]>
      with causal=1 (the task constrains kv_lens[b] == q_len for all b in this form)
      a square causal mask is applied: positions with j > i are set to -inf; with
      causal=0 no mask is applied;
      p[i, :] = softmax_j(scores[i, :])
      out[b*q_len+i, h, :] = sum_j p[i, j] * v[start_k+j, h, :]
    The softmax uses a numerically stable (online) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.
    Boundary behaviour: kv_lens[b] >= 1 always holds, so the softmax denominator is
    always positive and no row is fully masked; sequences do not affect each other;
    slots in k/v beyond each sequence's cumulative length boundary do not
    participate in the computation.

    Input/output specification:
      q        [num_seqs*q_len, num_heads, head_dim]  float16/bfloat16, sequence-major
      k, v     [total_kv, num_heads, head_dim]        same dtype as q, total_kv = sum(kv_lens)
      kv_lens  [num_seqs] int32 -- the KV length actually participating per sequence
      causal   0-dim int32 tensor, 1 = square causal mask, 0 = no mask
      out      [num_seqs*q_len, num_heads, head_dim]  same dtype as q
    Global constraints: Q/K/V head counts are equal (MHA, no GQA); head_dim in
    {16, 32, 64, 128, 256} and identical across Q/K/V; q_len >= 1; with causal=1,
    kv_lens[b] == q_len for all b.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: contiguous non-paged KV, variable-length ragged batch, MHA, both
    causal states, fp16/bf16 non-quantized inputs; no GQA, no dropout, no
    bias/ALiBi, no LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, kv_lens, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        kv_lens = kv_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        is_causal = bool(int(causal.to(torch.int32)))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_heads = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        assert num_heads == k.shape[1] == v.shape[1], "MHA: Q/K/V must have the same number of heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_seqs = int(kv_lens.numel())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        q_len = q.shape[0] // num_seqs
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert q_len * num_seqs == q.shape[0], "total_q must be an integer multiple of num_seqs"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if is_causal:
            assert bool((kv_lens == q_len).all()), "with causal=1 every batch entry's kv_len must equal q_len"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        start_k = 0
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        device_lens = kv_lens.to(device=q.device)
        kv_starts = torch.cumsum(device_lens, dim=0) - device_lens
        _ragged_attention[(q.shape[0] * num_heads,)](
            q, k, v, out, kv_starts, device_lens,
            q_len, num_heads, q.shape[2], self.sm_scale, is_causal,
            *q.stride(), *k.stride(), *v.stride(), *out.stride(),
            BD=triton.next_power_of_2(q.shape[2]), BK=128,
            num_warps=4,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
