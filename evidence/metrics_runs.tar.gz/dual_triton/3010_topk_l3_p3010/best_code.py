import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _direct_select(X, O, M: tl.constexpr, K: tl.constexpr, N: tl.constexpr):
    row = tl.program_id(0)
    col = tl.arange(0, N)
    active = col < M
    v = tl.load(X + row * M + col, active, other=-float('inf'))
    for rank in range(K):
        best = tl.max(tl.where(active, v, -float('inf')), 0)
        idx = tl.min(tl.where(active & (v == best), col, 2147483647), 0)
        value = tl.load(X + row * M + idx)
        tl.store(O + row * (2 * K) + rank, value)
        tl.store(O + row * (2 * K) + K + rank, idx.to(tl.float32))
        active = active & (col != idx)


@triton.jit
def _chunk_select(X, V, I, M: tl.constexpr, K: tl.constexpr, C: tl.constexpr, N: tl.constexpr):
    row = tl.program_id(0)
    chunk = tl.program_id(1)
    col = chunk * N + tl.arange(0, N)
    active = col < M
    v = tl.load(X + row * M + col, active, other=-float('inf'))
    for rank in range(K):
        best = tl.max(tl.where(active, v, -float('inf')), 0)
        idx = tl.min(tl.where(active & (v == best), col, 2147483647), 0)
        valid = idx < M
        value = tl.load(X + row * M + idx, valid, other=-float('inf'))
        offset = (row * C + chunk) * K + rank
        tl.store(V + offset, value)
        tl.store(I + offset, tl.where(valid, idx, -1))
        active = active & (col != idx)


@triton.jit
def _merge_select(X, V, I, O, M: tl.constexpr, K: tl.constexpr, S: tl.constexpr, N: tl.constexpr):
    row = tl.program_id(0)
    lane = tl.arange(0, N)
    v = tl.load(V + row * S + lane, lane < S, other=-float('inf'))
    indices = tl.load(I + row * S + lane, lane < S, other=-1)
    active = (lane < S) & (indices >= 0)
    for rank in range(K):
        best = tl.max(tl.where(active, v, -float('inf')), 0)
        idx = tl.min(tl.where(active & (v == best), indices, 2147483647), 0)
        value = tl.load(X + row * M + idx)
        tl.store(O + row * (2 * K) + rank, value)
        tl.store(O + row * (2 * K) + K + rank, idx.to(tl.float32))
        active = active & (indices != idx)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """In-row Top-K selection: for every row of a 2-D score matrix take the k
    largest values (strictly descending) together with their original column
    indices. This operator is the selection stage of MoE gating, where top-k
    routing is applied to the expert logits.

    Operator semantics: the input x has shape (B, M) and, independently for every
    row b:
        (values[b, :], indices[b, :]) = TopK(x[b, :], k)
    values[b, :] are the k largest elements of x[b, :] in strictly descending
    order; indices[b, j] is the column index of values[b, j] inside that row
    (0 <= indices[b, j] < M, distinct within a row), that is out[b, k + j]
    satisfies x[b, out[b, k + j]] == out[b, j]. Mathematically this equals a full
    descending sort of each row followed by taking the first k values and their
    original column positions. Boundary behaviour: k = 1 degenerates to the row
    maximum and its argmax; k = M degenerates to a descending argsort of the whole
    row; with M = 1 the output is that row's only element and index 0. The
    evaluation inputs guarantee that the elements of each row are mutually
    unequal (built as a random permutation of a set of distinct values), so the
    Top-K result is uniquely determined -- the tie order of equal values is not
    part of this task's semantics.

    Implementation path hints (free choice):
      - short rows (M <= 1024): a single kernel selecting the maximum round by
        round -- each round takes the current maximum and the column index of its
        first occurrence, writes them out and then masks that position with the
        smallest float32 value, for exactly k rounds;
      - long rows (M > 1024): two stages -- cut the row into fixed-length chunks,
        run a local Top-K per chunk to obtain chunk_num*k candidates (values plus
        global column indices), then merge-sort the candidates and take the first
        k.

    Input/output specification:
        x   (B, M) float32 (the evaluator casts all inputs to fp32 before passing
            them in), contiguous, row elements mutually unequal; B >= 1,
            M >= 1 and < 2^24 (column indices are exactly representable in the
            fp32 packing), non powers of two allowed; the task scale domain is
            M in [16, 131072].
        k   constructor hyperparameter (passed via __init__), 1 <= k <= M.
        out (B, 2*k) a single float32 tensor (evaluation protocol: single-tensor
            output):
            out[:, :k]   = values (strictly descending, a bit-exact copy of the
                           input values)
            out[:, k:]   = indices (integer column indices, < 2^24, exactly
                           representable in fp32)
        The output is a pure selection result (no arithmetic), so any single bit
        of deviation is a semantic error.

    Implementation constraints (violations are scored as failures):
      - The core Top-K selection (scan / tiling / merge) must be done with a
        Triton kernel inside the submitted file, with both values and indices
        written by the kernel; numeric comparison happens in float32.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - The first k output columns must be strictly descending; the last k
        columns must be the original column indices (not chunk-local indices and
        not sort ranks).

    Disallowed list: aiter / torch.topk / torch.sort / torch.argsort /
    torch.kthvalue / torch.mode, plus the Tensor method forms of the shortcuts
    above .topk( / .sort( / .argsort( / .kthvalue( -- calling a selection
    operator directly and doing a full sort to take the first k are the same
    shortcut, so any appearance in any form fails (Triton primitives are
    unrestricted).
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, k: int = 8):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.k = int(k)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.to(torch.float32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        B, M = x.shape
        k = self.k
        out = torch.empty((B, 2 * k), dtype=torch.float32, device=x.device)
        if M <= 1024 or k > 32:
            n = triton.next_power_of_2(M)
            _direct_select[(B,)](x, out, M, k, n, num_warps=4 if n <= 4096 else 16)
        else:
            chunks = triton.cdiv(M, 1024)
            candidates = torch.empty((B, chunks, k), dtype=torch.float32, device=x.device)
            candidate_indices = torch.empty((B, chunks, k), dtype=torch.int32, device=x.device)
            _chunk_select[(B, chunks)](x, candidates, candidate_indices, M, k, chunks, 1024, num_warps=4)
            count = chunks * k
            _merge_select[(B,)](x, candidates, candidate_indices, out, M, k, count, triton.next_power_of_2(count), num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        return out
        # <<<END_IMPROVE>>>
