import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _copy_kernel(src, dst, n, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    off = pid * BLOCK + tl.arange(0, BLOCK)
    mask = off < n
    x = tl.load(src + off, mask=mask)
    tl.store(dst + off, x, mask=mask)

@triton.jit
def _write_kernel(indices, updates, out, k, s0, s1, s2, s3, s4, s5, RANK: tl.constexpr, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    row = pid * BLOCK + tl.arange(0, BLOCK)
    mask = row < k
    base = row * RANK
    pos = tl.zeros([BLOCK], dtype=tl.int32)
    if RANK >= 1:
        c0 = tl.load(indices + base, mask=mask).to(tl.int32)
        pos += c0 * s0
    if RANK >= 2:
        c1 = tl.load(indices + base + 1, mask=mask).to(tl.int32)
        pos += c1 * s1
    if RANK >= 3:
        c2 = tl.load(indices + base + 2, mask=mask).to(tl.int32)
        pos += c2 * s2
    if RANK >= 4:
        c3 = tl.load(indices + base + 3, mask=mask).to(tl.int32)
        pos += c3 * s3
    if RANK >= 5:
        c4 = tl.load(indices + base + 4, mask=mask).to(tl.int32)
        pos += c4 * s4
    if RANK >= 6:
        c5 = tl.load(indices + base + 5, mask=mask).to(tl.int32)
        pos += c5 * s5
    value = tl.load(updates + row, mask=mask)
    tl.store(out + pos, value, mask=mask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    ScatterND: the index-write family that overwrites positions of `data`
    with `updates` according to integer index tuples.

    Semantics: data has shape (S_0, ..., S_{r-1}) where r is its rank; indices is
    an int64 tensor of shape (K, r) -- each row is a full coordinate tuple that
    picks exactly one position in data; updates has shape (K,) and the same dtype
    as data. The output out has the same shape and dtype as data:
        out[indices[k,0], ..., indices[k,r-1]] = updates[k]
            (hit positions: overwritten, the original value is discarded and
             replaced by the corresponding element of updates)
        all other positions out[i_0, ..., i_{r-1}] = data[i_0, ..., i_{r-1}]
            (misses: the original value is preserved bit-for-bit)
    The write semantics is overwrite, not accumulate; the K coordinate tuples are
    pairwise distinct (the generator samples without replacement), so every data
    element is written at most once. Which write wins for duplicate coordinate
    tuples is undefined behaviour (mainstream frameworks leave the write order
    for duplicate indices undefined either way), and duplicate tuples are outside
    this task's input domain -- the implementation need not define behaviour for
    them, and must not let deduplication / sorting or any other preprocessing
    change the overwrite result for distinct tuples.

    Input/output specification:
        data    float32 / float16 / bfloat16, contiguous, ndim in [1, 6],
                every dimension >= 1, total element count <= 2^23; values are
                ordinary randn magnitude (no inf/NaN)
        indices int64 (K, r) with r = data rank, 1 <= K <= the total element
                count of data; every index value lies in [0, S_d) and the K
                coordinate tuples are pairwise distinct
        updates same dtype as data, shape (K,), contiguous
        out     a single tensor, same shape / dtype as data, contiguous -- this
                operator is naturally single-output, so no multi-output packing is
                needed. forward must return a single tensor (the evaluator
                compares .shape / allclose on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (indices are small non-negative integers < 2^24 and exactly
        representable in fp32, so they are recovered losslessly; fp16/bf16 ->
        fp32 is also lossless). The offline final audit passes inputs natively in
        their declared dtype -- the implementation must be correct for both.

    Boundary behaviour: K=1, K equal to the total element count of data (a full
    permutation, every element written), ndim=1 (indices shaped (K, 1)), and
    shapes with non-power-of-two / prime lengths or axes of length 1 must all be
    handled correctly; the output must be a fresh tensor and must not modify
    data / indices / updates in place.

    Implementation constraints (violations are scored as failures):
        - The core computation (r-dimensional coordinate -> linear offset address
          computation, reading updates, and moving the original values out for
          miss positions) must be completed with a Triton kernel inside the
          submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Pure-movement contract: miss positions match data bit-for-bit and hit
          positions match updates bit-for-bit (bit patterns preserved); no
          numeric transformation may be introduced.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.scatter / .scatter( / .scatter_( / scatter_add / scatter_reduce /
    index_put / torch.put( / .put_( / index_copy / torch_scatter / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, data, indices, updates):
        # <<<IMPROVE:forward_stmt_1>>>
        idx = indices.contiguous()
        out = torch.empty_like(data).reshape(-1)
        rank = data.ndim
        k = idx.shape[0]
        strides = tuple(int(x) for x in data.stride())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        n = out.numel()
        _copy_kernel[(triton.cdiv(n, 256),)](data.reshape(-1), out, n, BLOCK=256, num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        s = strides + (0,) * (6 - rank)
        _write_kernel[(triton.cdiv(k, 256),)](idx.reshape(-1), updates.reshape(-1), out, k, s[0], s[1], s[2], s[3], s[4], s[5], RANK=rank, BLOCK=256, num_warps=4)
        out = out.reshape(data.shape)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return out
        # <<<END_IMPROVE>>>
