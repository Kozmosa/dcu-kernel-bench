import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _rms_values(X, R, offsets, mask, FUSED: tl.constexpr):
    v = tl.load(X + offsets, mask, other=0).to(tl.float32)
    if FUSED:
        r = tl.load(R + offsets, mask, other=0).to(tl.float32)
        v = (v + r).to(X.dtype.element_ty).to(tl.float32)
    return tl.where(mask, v, 0.0)

@triton.jit
def _rms_row(X, W, R, O, N: tl.constexpr, EPS: tl.constexpr, FUSED: tl.constexpr, B: tl.constexpr):
    row = tl.program_id(0)
    c = tl.arange(0, B)
    v = _rms_values(X, R, row * N + c, c < N, FUSED)
    inv = tl.rsqrt(tl.sum(v * v, 0) / N + EPS)
    w = tl.load(W + c, c < N, other=0).to(tl.float32)
    stride: tl.constexpr = N * (2 if FUSED else 1)
    tl.store(O + row * stride + c, (v * inv) * w, c < N)
    if FUSED:
        tl.store(O + row * stride + N + c, v, c < N)

@triton.jit
def _rms_large(X, W, R, O, N: tl.constexpr, EPS: tl.constexpr, FUSED: tl.constexpr, B: tl.constexpr):
    row = tl.program_id(0)
    lanes = tl.arange(0, B)
    acc = tl.full((B,), 0, tl.float32)
    for start in range(0, N, B):
        c = start + lanes
        v = _rms_values(X, R, row * N + c, c < N, FUSED)
        acc = acc + v * v
    inv = tl.rsqrt(tl.sum(acc, 0) / N + EPS)
    stride: tl.constexpr = N * (2 if FUSED else 1)
    for start in range(0, N, B):
        c = start + lanes
        v = _rms_values(X, R, row * N + c, c < N, FUSED)
        w = tl.load(W + c, c < N, other=0).to(tl.float32)
        tl.store(O + row * stride + c, (v * inv) * w, c < N)
        if FUSED:
            tl.store(O + row * stride + N + c, v, c < N)

def _rmsnorm_dispatch(x, weight, residual, variant, eps):
    m, n = x.shape
    fused = variant == "fused_add"
    out = torch.empty((m, n * (2 if fused else 1)), device=x.device, dtype=x.dtype)
    if n <= 4096:
        _rms_row[(m,)](x, weight, residual, out, n, eps, fused, triton.next_power_of_2(n), num_warps=4, enable_fp_fusion=False)
    else:
        _rms_large[(m,)](x, weight, residual, out, n, eps, fused, 1024, num_warps=4, enable_fp_fusion=False)
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """RMSNorm forward family: standard RMSNorm and residual-fused
    (fused residual-add) RMSNorm.

    For each row of an (M, N) input, the normalization is computed in float32 as
    defined below:
        mean_sq = sum_i x_i^2 / N
        rsigma  = rsqrt(mean_sq + eps)
        y_i     = x_i * rsigma * w_i
    where w is the per-channel scale vector. The __init__ parameter `variant`
    selects one of two paths:
        "fused_add": first compute residual_out = x + residual in the input dtype
        (the residual stream passes straight through to the output), then apply the
        RMSNorm above to residual_out;
        "rmsnorm"  : apply the RMSNorm directly to x; residual takes no part in the
        computation (its content is arbitrary and may be garbage data).
    forward returns a single tensor out (same dtype as x): with fused_add it is
    (M, 2N) with the first N columns equal to y and the last N columns equal to
    residual_out (the two logical outputs concatenated along the last dimension);
    with rmsnorm it is (M, N), i.e. y.
    Boundary behaviour: for an all-zero row mean_sq = 0, so rsigma = rsqrt(eps)
    (eps guarantees no division by zero); N is arbitrary (including 1,
    non-powers-of-two, sizes not multiple of 16, and large N beyond a single
    block's reduction capacity) and must all be handled correctly with masking / a
    blocked reduction, and out-of-range elements at the row tail must not
    contribute to the sum of squares.

    Input/output specification:
        x        float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        weight   same dtype as x, (N,), contiguous
        residual same dtype as x, (M, N), contiguous (ignored when variant="rmsnorm")
        out      a single tensor, same dtype as x: (M, 2N) with fused_add (first N
                 columns y, last N columns residual_out), (M, N) with rmsnorm (i.e. y)
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (residual add, per-row sum-of-squares reduction,
          rsqrt, element-wise scaling) must be completed with a Triton kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The sum-of-squares accumulation and the normalization run in float32; y is
          cast back to the input dtype; residual_out is added in the input dtype and
          written out as-is.
        - forward returns the single tensor `out` (the evaluator compares a single
          output); with fused_add the residual_out column block must be bit-identical
          to x + residual in the input dtype.

    Forbidden list: aiter / torch.rms_norm / torch.nn.functional.rms_norm /
    torch.nn.RMSNorm / torch.layer_norm / torch.nn.functional.layer_norm /
    torch.nn.LayerNorm / torch.norm / torch.linalg.norm /
    torch.linalg.vector_norm.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "fused_add", eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("rmsnorm", "fused_add"), "variant must be one of rmsnorm / fused_add"
        self.variant = variant
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, residual):
        # <<<IMPROVE:forward_stmt_1>>>
        return _rmsnorm_dispatch(x, weight, residual, self.variant, self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        norm_input = x + residual if fused else x
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        residual_out = norm_input
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        xf = norm_input.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        wf = weight.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        mean_sq = (xf * xf).mean(dim=-1, keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        y = (xf * torch.rsqrt(mean_sq + self.eps) * wf).to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return torch.cat([y, residual_out], dim=-1) if fused else y
        # <<<END_IMPROVE>>>
