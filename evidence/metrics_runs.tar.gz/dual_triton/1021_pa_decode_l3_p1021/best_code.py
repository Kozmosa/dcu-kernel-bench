import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _paged_stream(Q, K, V, BT, L, O,
                  HQ: tl.constexpr, GROUP: tl.constexpr, D: tl.constexpr,
                  BS: tl.constexpr, SCALE: tl.constexpr,
                  Q0: tl.constexpr, Q1: tl.constexpr, Q2: tl.constexpr,
                  K0: tl.constexpr, K1: tl.constexpr, K2: tl.constexpr, K3: tl.constexpr,
                  V0: tl.constexpr, V1: tl.constexpr, V2: tl.constexpr, V3: tl.constexpr,
                  T0: tl.constexpr, T1: tl.constexpr, L0: tl.constexpr,
                  O0: tl.constexpr, O1: tl.constexpr, O2: tl.constexpr,
                  BD: tl.constexpr, BN: tl.constexpr):
    pid = tl.program_id(0)
    s = pid // HQ
    h = pid % HQ
    kh = h // GROUP
    n = tl.load(L + s * L0)
    d = tl.arange(0, BD)
    r = tl.arange(0, BN)
    q = tl.load(Q + s * Q0 + h * Q1 + d * Q2, d < D, 0).to(tl.float32) * SCALE
    m = tl.full((), -float('inf'), tl.float32)
    z = tl.full((), 0.0, tl.float32)
    acc = tl.full((BD,), 0.0, tl.float32)
    for start in range(0, n, BN):
        pos = start + r
        valid = pos < n
        page = tl.load(BT + s * T0 + (pos // BS) * T1, valid, 0)
        ko = page[:, None] * K0 + kh * K1 + (pos % BS)[:, None] * K2 + d[None, :] * K3
        k = tl.load(K + ko, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        x = tl.sum(k * q[None, :], 1)
        x = tl.where(valid, x, -float('inf'))
        nm = tl.maximum(m, tl.max(x, 0))
        alpha = tl.exp(m - nm)
        p = tl.exp(x - nm)
        vo = page[:, None] * V0 + kh * V1 + (pos % BS)[:, None] * V2 + d[None, :] * V3
        v = tl.load(V + vo, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        acc = acc * alpha + tl.sum(p[:, None] * v, 0)
        z = z * alpha + tl.sum(p, 0)
        m = nm
    tl.store(O + s * O0 + h * O1 + d * O2, acc / z, d < D)


@triton.jit
def _paged_partition(Q, K, V, BT, L, S,
                     HQ: tl.constexpr, GROUP: tl.constexpr, D: tl.constexpr,
                     BS: tl.constexpr, SCALE: tl.constexpr,
                     Q0: tl.constexpr, Q1: tl.constexpr, Q2: tl.constexpr,
                     K0: tl.constexpr, K1: tl.constexpr, K2: tl.constexpr, K3: tl.constexpr,
                     V0: tl.constexpr, V1: tl.constexpr, V2: tl.constexpr, V3: tl.constexpr,
                     T0: tl.constexpr, T1: tl.constexpr, L0: tl.constexpr,
                     P: tl.constexpr, BD: tl.constexpr, BN: tl.constexpr):
    pid = tl.program_id(0)
    part = tl.program_id(1)
    s = pid // HQ
    h = pid % HQ
    kh = h // GROUP
    n = tl.load(L + s * L0)
    end = tl.minimum(n, (part + 1) * 512)
    d = tl.arange(0, BD)
    r = tl.arange(0, BN)
    q = tl.load(Q + s * Q0 + h * Q1 + d * Q2, d < D, 0).to(tl.float32) * SCALE
    m = tl.full((), -float('inf'), tl.float32)
    z = tl.full((), 0.0, tl.float32)
    acc = tl.full((BD,), 0.0, tl.float32)
    for start in range(part * 512, end, BN):
        pos = start + r
        valid = pos < end
        page = tl.load(BT + s * T0 + (pos // BS) * T1, valid, 0)
        ko = page[:, None] * K0 + kh * K1 + (pos % BS)[:, None] * K2 + d[None, :] * K3
        k = tl.load(K + ko, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        x = tl.sum(k * q[None, :], 1)
        x = tl.where(valid, x, -float('inf'))
        nm = tl.maximum(m, tl.max(x, 0))
        alpha = tl.exp(m - nm)
        p = tl.exp(x - nm)
        vo = page[:, None] * V0 + kh * V1 + (pos % BS)[:, None] * V2 + d[None, :] * V3
        v = tl.load(V + vo, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        acc = acc * alpha + tl.sum(p[:, None] * v, 0)
        z = z * alpha + tl.sum(p, 0)
        m = nm
    base = S + (pid * P + part) * (BD + 2)
    tl.store(base + d, acc)
    tl.store(base + BD, tl.where(z > 0, m, 0.0))
    tl.store(base + BD + 1, z)


@triton.jit
def _paged_merge(S, O, HQ: tl.constexpr, D: tl.constexpr,
                 P: tl.constexpr, BD: tl.constexpr, BP: tl.constexpr,
                 O0: tl.constexpr, O1: tl.constexpr, O2: tl.constexpr):
    pid = tl.program_id(0)
    r = tl.arange(0, BP)
    d = tl.arange(0, BD)
    base = (pid * P + r) * (BD + 2)
    m = tl.load(S + base + BD, r < P, 0.0)
    z = tl.load(S + base + BD + 1, r < P, 0.0)
    gm = tl.max(tl.where(z > 0, m, -float('inf')), 0)
    w = tl.exp(tl.where(z > 0, m - gm, -float('inf')))
    acc = tl.load(S + base[:, None] + d[None, :], r[:, None] < P, 0.0)
    result = tl.sum(acc * w[:, None], 0) / tl.sum(z * w, 0)
    tl.store(O + (pid // HQ) * O0 + (pid % HQ) * O1 + d * O2, result, d < D)


def _launch_paged(query, key, value, tables, lengths, out, scale, B, HQ, HKV, D, bs):
    if B * HQ < 256 and tables.shape[1] * bs > 8192:
        P = triton.cdiv(tables.shape[1] * bs, 512)
        BD = triton.next_power_of_2(D)
        scratch = torch.empty((B * HQ, P, BD + 2), device=query.device, dtype=torch.float32)
        _paged_partition[(B * HQ, P)](
            query, key, value, tables, lengths, scratch,
            HQ, HQ // HKV, D, bs, scale,
            *query.stride(), *key.stride(), *value.stride(),
            *tables.stride(), lengths.stride(0), P, BD, 32,
            num_warps=4, num_stages=1)
        _paged_merge[(B * HQ,)](
            scratch, out, HQ, D, P, BD, triton.next_power_of_2(P),
            *out.stride(), num_warps=4, num_stages=1)
        return
    _paged_stream[(B * HQ,)](
        query, key, value, tables, lengths, out,
        HQ, HQ // HKV, D, bs, scale,
        *query.stride(), *key.stride(), *value.stride(),
        *tables.stride(), lengths.stride(0), *out.stride(),
        triton.next_power_of_2(D), 32,
        num_warps=4, num_stages=1)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Paged attention for the long-context decode phase (single-token query), for both MHA and GQA.

    Operator semantics: the KV cache is paged with a fixed block_size in the
    physical block pool key_cache / value_cache, and each sequence is addressed
    indirectly through the physical block ids in block_tables; the KV length that
    actually takes part in attention for each sequence is given by seq_lens[s]
    (>=1); slots of the physical block pool that nothing references, and slots of
    the tail block beyond seq_lens[s], are garbage data and must not take part in
    the computation. For query head h of sequence s (its KV head is
    h // query_group_size; let bs = block_size, bt = block_tables):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    softmax is a numerically stable reduction over the whole
    [0, seq_lens[s]) interval.

    This task is in the long-context regime: the block-table capacity max_seq_len
    (16384 in the fixed family) far exceeds 8192, so a single sequence's KV can be
    long. How the work is parallelized is **not** a scoring criterion -- any
    implementation that is numerically equivalent to the full softmax within the
    tolerance is acceptable, and the implementation path is free. Core boundary
    cases: partially filled tail blocks (seq_len not a multiple of the block
    size), seq_len exactly a multiple of the block size, wildly different
    sequence lengths within one batch (as short as 1), and tail-block slot
    masking -- positions beyond seq_len must not contribute any probability mass.

    Input/output specification:
      query       [num_seqs, num_q_heads, head_size], fp16/bf16
      key_cache   [num_blocks, num_kv_heads, block_size, head_size], fp16/bf16
      value_cache same as key_cache
      block_tables[num_seqs, max_blocks_per_seq] int32, logical block -> physical block id
      seq_lens    [num_seqs] int32, each sequence's valid KV length, 1 <= seq_lens[s] <= max_seq_len
      output out  [num_seqs, num_q_heads, head_size], dtype matches query

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling external attention operator libraries such as
        scaled_dot_product_attention / sdpa / flash_attn, and torch.matmul /
        torch.bmm / torch.einsum / torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - Unreferenced physical blocks and slots beyond seq_len must not affect the
        output.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding
    window; the long-context regime (max(seq_lens) > 8192).
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _launch_paged(query, key_cache, value_cache, block_tables, seq_lens,
                      out, self.scale, B, H_Q, H_KV, D, bs)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
