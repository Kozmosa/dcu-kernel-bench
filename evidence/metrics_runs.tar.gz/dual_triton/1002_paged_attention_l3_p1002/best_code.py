import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _paged_decode_kernel(
    query, key_cache, value_cache, block_tables, seq_lens, out,
    q_stride_s, q_stride_h, q_stride_d,
    k_stride_b, k_stride_h, k_stride_t, k_stride_d,
    v_stride_b, v_stride_h, v_stride_t, v_stride_d,
    bt_stride_s, bt_stride_b, sl_stride,
    o_stride_s, o_stride_h, o_stride_d,
    D: tl.constexpr, D_PAD: tl.constexpr, BS: tl.constexpr,
    GROUP: tl.constexpr, SCALE: tl.constexpr, TILE: tl.constexpr,
):
    s = tl.program_id(0)
    h = tl.program_id(1)
    offs_d = tl.arange(0, D_PAD)
    dmask = offs_d < D

    q_ptr = query + s * q_stride_s + h * q_stride_h + offs_d * q_stride_d
    q = tl.load(q_ptr, mask=dmask, other=0.0).to(tl.float32) * SCALE

    seq_len = tl.load(seq_lens + s * sl_stride).to(tl.int32)
    kv_head = h // GROUP
    m = tl.full((), -float("inf"), tl.float32)
    z = tl.zeros((), tl.float32)
    acc = tl.zeros((D_PAD,), tl.float32)

    start = 0
    while start < seq_len:
        tok = start + tl.arange(0, TILE)
        tmask = tok < seq_len
        block_idx = tok // BS
        block_off = tok - block_idx * BS
        bt_ptr = block_tables + s * bt_stride_s + block_idx * bt_stride_b
        physical = tl.load(bt_ptr, mask=tmask, other=0).to(tl.int64)

        k_ptr = (
            key_cache
            + physical[:, None] * k_stride_b
            + kv_head * k_stride_h
            + block_off[:, None] * k_stride_t
            + offs_d[None, :] * k_stride_d
        )
        v_ptr = (
            value_cache
            + physical[:, None] * v_stride_b
            + kv_head * v_stride_h
            + block_off[:, None] * v_stride_t
            + offs_d[None, :] * v_stride_d
        )
        kv_mask = tmask[:, None] & dmask[None, :]
        k = tl.load(k_ptr, mask=kv_mask, other=0.0).to(tl.float32)
        v = tl.load(v_ptr, mask=kv_mask, other=0.0).to(tl.float32)

        logits = tl.sum(k * q[None, :], axis=1)
        logits = tl.where(tmask, logits, -float("inf"))
        tile_m = tl.max(logits, axis=0)
        new_m = tl.maximum(m, tile_m)
        alpha = tl.exp(m - new_m)
        weights = tl.exp(logits - new_m)
        z = alpha * z + tl.sum(weights, axis=0)
        acc = alpha * acc + tl.sum(weights[:, None] * v, axis=0)
        m = new_m
        start += TILE

    result = tl.where(seq_len > 0, acc / z, 0.0)
    out_ptr = out + s * o_stride_s + h * o_stride_h + offs_d * o_stride_d
    tl.store(out_ptr, result, mask=dmask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Paged attention in the decode phase (single-token query), supporting both
    MHA and GQA.

    The KV cache is stored page-wise with a fixed block_size in the physical block
    pools key_cache / value_cache, and each sequence addresses them indirectly
    through the physical block ids in block_tables; the KV length that actually
    participates in attention for each sequence is given by seq_lens[s], while the
    remaining slots in the pool hold garbage data and must not participate in the
    computation. For query head h of sequence s (whose KV head is
    h // query_group_size):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    The softmax uses an online (numerically stable) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding window.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _paged_decode_kernel[(B, H_Q)](
            query,
            key_cache,
            value_cache,
            block_tables,
            seq_lens,
            out,
            query.stride(0), query.stride(1), query.stride(2),
            key_cache.stride(0), key_cache.stride(1), key_cache.stride(2), key_cache.stride(3),
            value_cache.stride(0), value_cache.stride(1), value_cache.stride(2), value_cache.stride(3),
            block_tables.stride(0), block_tables.stride(1), seq_lens.stride(0),
            out.stride(0), out.stride(1), out.stride(2),
            D=D,
            D_PAD=triton.next_power_of_2(D),
            BS=bs,
            GROUP=group,
            SCALE=self.scale,
            TILE=32,
            num_warps=4,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
