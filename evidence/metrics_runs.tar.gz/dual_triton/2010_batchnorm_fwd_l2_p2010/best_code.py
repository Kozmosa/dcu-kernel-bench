import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _bn_partial_kernel(x_ptr, scratch_ptr, m, C, S, BLOCK: tl.constexpr):
    tile = tl.program_id(0)
    c = tl.program_id(1)
    start = tile * BLOCK
    r = start + tl.arange(0, BLOCK)
    mask = r < m
    n = r // S
    q = r - n * S
    offs = n * C * S + c * S + q
    x = tl.load(x_ptr + offs, mask=mask, other=0.0).to(tl.float32)
    count = tl.sum(tl.where(mask, 1.0, 0.0), axis=0)
    total = tl.sum(tl.where(mask, x, 0.0), axis=0)
    mean = total / count
    diff = x - mean
    m2 = tl.sum(tl.where(mask, diff * diff, 0.0), axis=0)
    base = tile * C + c
    tl.store(scratch_ptr + base, count)
    tl.store(scratch_ptr + C * ((m + BLOCK - 1) // BLOCK) + base, mean)
    tl.store(scratch_ptr + 2 * C * ((m + BLOCK - 1) // BLOCK) + base, m2)

@triton.jit
def _bn_finalize_kernel(scratch_ptr, out_ptr, mf_ptr, vf_ptr, eps, momentum, m, C, tiles, TBLOCK: tl.constexpr):
    c = tl.program_id(0)
    t = tl.arange(0, TBLOCK)
    mask = t < tiles
    stride = C * tiles
    counts = tl.load(scratch_ptr + t * C + c, mask=mask, other=0.0)
    means = tl.load(scratch_ptr + stride + t * C + c, mask=mask, other=0.0)
    m2s = tl.load(scratch_ptr + 2 * stride + t * C + c, mask=mask, other=0.0)
    total = tl.sum(tl.where(mask, counts, 0.0), axis=0)
    batch_mean = tl.sum(tl.where(mask, counts * means, 0.0), axis=0) / total
    centered = means - batch_mean
    total_m2 = tl.sum(tl.where(mask, m2s + counts * centered * centered, 0.0), axis=0)
    batch_var = total_m2 / total
    inv = tl.rsqrt(batch_var + eps)
    old_mean = tl.load(mf_ptr + c)
    old_var = tl.load(vf_ptr + c)
    next_mean = (1.0 - momentum) * old_mean + momentum * batch_mean
    unbiased = batch_var * (m / (m - 1.0))
    next_var = (1.0 - momentum) * old_var + momentum * unbiased
    p = m * C
    tl.store(out_ptr + p + c, batch_mean)
    tl.store(out_ptr + p + C + c, inv)
    tl.store(out_ptr + p + 2 * C + c, next_mean)
    tl.store(out_ptr + p + 3 * C + c, next_var)

@triton.jit
def _bn_affine_kernel(x_ptr, scale_ptr, bias_ptr, out_ptr, m, C, S, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    total = m * C
    mask = i < total
    c = (i // S) % C
    p = m * C
    x = tl.load(x_ptr + i, mask=mask, other=0.0).to(tl.float32)
    scale = tl.load(scale_ptr + c)
    bias = tl.load(bias_ptr + c)
    mean = tl.load(out_ptr + p + c)
    inv = tl.load(out_ptr + p + C + c)
    y = (x - mean) * inv * scale + bias
    tl.store(out_ptr + i, y, mask=mask)

def _bn_training_triton(xf, sf, bf, mf, vf, eps, momentum):
    N, C, H, W = xf.shape
    m = N * H * W
    S = H * W
    BLOCK = 1024
    tiles = (m + BLOCK - 1) // BLOCK
    scratch = torch.empty((3 * tiles * C,), device=xf.device, dtype=torch.float32)
    out = torch.empty((m * C + 4 * C,), device=xf.device, dtype=torch.float32)
    _bn_partial_kernel[(tiles, C)](xf, scratch, m, C, S, BLOCK=BLOCK, num_warps=4)
    tblock = 1
    while tblock < tiles:
        tblock *= 2
    warps = 4 if tblock <= 1024 else 8
    _bn_finalize_kernel[(C,)](scratch, out, mf, vf, eps, momentum, m, C, tiles, TBLOCK=tblock, num_warps=warps)
    elements = m * C
    ablock = 1024
    grids = (elements + ablock - 1) // ablock
    _bn_affine_kernel[(grids,)](xf, sf, bf, out, m, C, S, BLOCK=ablock, num_warps=4)
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    BatchNorm forward family: inference affine (inference) and training batch
    statistics (training).

    The input is x (N, C, H, W), NCHW contiguous; scale / bias / mean / variance are
    all (1, C, 1, 1) and broadcast along the channel dimension. Reduction dimension:
    per-channel, computing the statistics of every channel c over the three
    dimensions (N, H, W), with m = N*H*W elements per channel. The __init__ argument
    variant selects one of two paths (eps defaults to 1e-5 and momentum to 0.1; both
    are scalar hyper-parameters only):

        "inference": the mean and the variance are given as inputs, element-wise
                     affine (float32 intermediate computation):
            y = scale * (x - mean) / sqrt(variance + eps) + bias
        "training": batch statistics + affine + running update (float32
                    throughout):
            batch_mean_c = sum_{n,h,w} x[n,c,h,w] / m                    (biased batch mean)
            batch_var_c  = sum_{n,h,w} (x[n,c,h,w] - batch_mean_c)^2 / m (biased batch variance)
            saved_mean         = batch_mean                              (shape (1,C,1,1))
            saved_inv_variance = 1 / sqrt(batch_var + eps)               (shape (1,C,1,1))
            y = scale * (x - saved_mean) * saved_inv_variance + bias
            next_running_mean = (1 - momentum) * mean + momentum * batch_mean
            next_running_var  = (1 - momentum) * variance
                                + momentum * batch_var * m / (m - 1)
            In the training variant the 4th/5th forward arguments are the running
            statistics of the previous step (prev_running_mean / prev_running_var);
            the running variance update uses the unbiased batch variance (the
            m/(m-1) correction, hence the requirement m >= 2) -- this is the
            standard PyTorch / cuDNN / MIOpen training-BN convention.

    The forward signature is (x, scale, bias, mean, variance) for both variants: in
    inference the 4th/5th arguments are the given mean / variance, in training they
    are prev_running_mean / prev_running_var.

    Single-tensor output protocol (forward must return a single tensor; the
    evaluator compares a single output):
        "inference": returns y itself, shape (N, C, H, W), same dtype as x;
        "training" : returns a one-dimensional float32 packed tensor of length
                     N*C*H*W + 4*C; the five logical outputs are each cast to
                     float32, reshaped with reshape(-1) and torch.cat'ed in the
                     sample-output order, with the segment protocol (half-open
                     intervals):
            [0,            N*C*H*W)      y
            [N*C*H*W,      N*C*H*W + C)  saved_mean
            [N*C*H*W + C,  N*C*H*W + 2C) saved_inv_variance
            [N*C*H*W + 2C, N*C*H*W + 3C) next_running_mean
            [N*C*H*W + 3C, N*C*H*W + 4C) next_running_var

    Input/output specification:
        x        float32 (always float32 for training) / float16 / bfloat16
                 (inference only), (N, C, H, W), contiguous, N/C/H/W >= 1
        scale    same dtype as x, (1, C, 1, 1), contiguous
        bias     same dtype as x, (1, C, 1, 1), contiguous
        mean     same dtype as x, (1, C, 1, 1), contiguous (inference: the given
                 mean, any real value; training: prev_running_mean)
        variance same dtype as x, (1, C, 1, 1), contiguous, always positive
                 (inference: the given variance; training: prev_running_var)
        out      inference: (N, C, H, W), same dtype as x; training: one-dimensional
                 float32 of length N*C*H*W + 4*C (the five-segment packing protocol
                 above)
        The inputs are the usual randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-channel reduction statistics, rsqrt, the
          affine, and the running update) must be completed inside the submitted
          file with a Triton kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, the normalization and the running update all use float32
          intermediates; the y of inference is cast back to the x dtype; all five
          training segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.BatchNorm1d / torch.nn.BatchNorm2d /
    torch.nn.BatchNorm3d / torch.nn.SyncBatchNorm /
    torch.nn.functional.batch_norm / torch.batch_norm /
    torch.native_batch_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "training", eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("inference", "training"), "variant must be one of inference / training"
        assert eps > 0, "eps must be positive"
        assert 0.0 <= momentum <= 1.0, "momentum must be in [0, 1]"
        self.variant = variant
        self.eps = float(eps)
        self.momentum = float(momentum)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias, mean, variance):
        # <<<IMPROVE:forward_stmt_1>>>
        eps = self.eps
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        sf = scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        bf = bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        mf = mean.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        vf = variance.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        if self.variant == "inference":
            # element-wise affine with the given mean/variance; (1,C,1,1)
            # broadcasts along the channel dimension
            inv_std = torch.rsqrt(vf + eps)
            y = (xf - mf) * inv_std * sf + bf
            return y.to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        m = xf.shape[0] * xf.shape[2] * xf.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert m >= 2, "the training variant requires N*H*W >= 2 (the m/(m-1) unbiased correction factor of the running variance)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return _bn_training_triton(xf, sf, bf, mf, vf, eps, self.momentum)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        batch_var = ((xf - batch_mean) ** 2).mean(dim=(0, 2, 3), keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        saved_inv_variance = torch.rsqrt(batch_var + eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        y = (xf - batch_mean) * saved_inv_variance * sf + bf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        batch_var_unbiased = batch_var * (m / (m - 1))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        next_running_mean = (1.0 - self.momentum) * mf + self.momentum * batch_mean
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        next_running_var = (1.0 - self.momentum) * vf + self.momentum * batch_var_unbiased
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        return torch.cat([
            y.to(torch.float32).reshape(-1),
            batch_mean.to(torch.float32).reshape(-1),
            saved_inv_variance.to(torch.float32).reshape(-1),
            next_running_mean.to(torch.float32).reshape(-1),
            next_running_var.to(torch.float32).reshape(-1),
        ])
        # <<<END_IMPROVE>>>
