import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _mxfp4_row_kernel(X, W, R, O, N: tl.constexpr, B: tl.constexpr,
                      XS: tl.constexpr, XC: tl.constexpr,
                      RS: tl.constexpr, RC: tl.constexpr, WS: tl.constexpr,
                      EPS: tl.constexpr):
    row = tl.program_id(0)
    j = tl.arange(0, B)
    x = tl.load(X + row * XS + j * XC, j < N, 0).to(tl.float32)
    r = tl.load(R + row * RS + j * RC, j < N, 0).to(tl.float32)
    w = tl.load(W + j * WS, j < N, 0).to(tl.float32)
    s = x + r
    factor = tl.rsqrt(tl.sum(s * s, 0) / N + EPS)
    v = tl.where(j < N, (s * factor) * w, 0.0)
    blocks = tl.reshape(v, (B // 32, 32))
    amax = tl.max(tl.abs(blocks), 1)
    rounded = (amax.to(tl.uint32, bitcast=True) + 0x200000) & 0xFF800000
    exponent = ((rounded >> 23) & 255).to(tl.int32) - 129
    exponent = tl.minimum(127, tl.maximum(-127, exponent))
    inv_bits = ((127 - exponent).to(tl.uint32) << 23)
    inv_bits = tl.where(exponent == 127, 0x00400000, inv_bits).to(tl.uint32)
    inv = inv_bits.to(tl.float32, bitcast=True)
    q = blocks * inv[:, None]
    bits = q.to(tl.uint32, bitcast=True)
    e = ((bits >> 23) & 255).to(tl.int32)
    m = bits & 0x7FFFFF
    shift = 126 - e
    shifted = (0x400000 | (m >> 1)) >> tl.minimum(31, tl.maximum(0, shift))
    shifted = tl.where(shift >= 32, 0, shifted)
    m = tl.where(e < 127, shifted, m)
    e = tl.maximum(e, 126) - 126
    mag = tl.minimum(( ((e << 2) | (m >> 21)) + 1) >> 1, 7)
    codes = ((bits >> 28) & 8) | mag
    pairs = tl.reshape(codes, (B // 2, 2))
    lo, hi = tl.split(pairs)
    packed = lo | (hi << 4)
    p = tl.arange(0, B // 2)
    nb: tl.constexpr = (N + 31) // 32
    stride: tl.constexpr = N // 2 + nb
    tl.store(O + row * stride + p, packed.to(tl.uint8), p < N // 2)
    b = tl.arange(0, B // 32)
    tl.store(O + row * stride + N // 2 + b, (exponent + 127).to(tl.uint8), b < nb)

def _fused_mxfp4_quant_triton(inp, weight, residual, eps):
    m, n = inp.shape
    out = torch.empty((m, n // 2 + (n + 31) // 32), device=inp.device, dtype=torch.uint8)
    b = max(32, triton.next_power_of_2(n))
    _mxfp4_row_kernel[(m,)](
        inp, weight, residual, out, n, b,
        inp.stride(0), inp.stride(1), residual.stride(0), residual.stride(1),
        weight.stride(0), eps,
        num_warps=2 if b <= 1024 else (4 if b <= 4096 else 8), enable_fp_fusion=False)
    return out
# <<<END_IMPROVE>>>

def _rmsnorm(x, weight, eps):
    # Official semantics: row-wise RMS normalization in float32, then multiply
    # by the weight
    row_norm = torch.sum(x * x, dim=-1)
    norm_factor = torch.rsqrt((row_norm / x.shape[1]) + eps).reshape(-1, 1)
    return x * norm_factor * weight.reshape(1, -1)

def _mxfp4_quant(x):
    # MXFP4 dynamic quantization (block size 32, even rounding). See the Model
    # docstring for the bit-exact semantics: the bit-level algorithm matches the
    # reference implementation; the input is a float32 (M, N) matrix.
    MXFP4_QUANT_BLOCK_SIZE = 32
    x_shape = x.shape
    if x.shape[-1] % MXFP4_QUANT_BLOCK_SIZE != 0:
        shape = list(x_shape)
        shape = shape[:-1] + [
            ((shape[-1] - 1 + MXFP4_QUANT_BLOCK_SIZE) // MXFP4_QUANT_BLOCK_SIZE)
            * MXFP4_QUANT_BLOCK_SIZE
        ]
        shape = tuple(shape)
        x_padded = torch.zeros(shape, dtype=x.dtype, device=x.device)
        x_padded[..., : x.shape[-1]] = x
    else:
        x_padded = x

    # Block scale: round amax up to a power of two, then take floor(log2) - 2
    x_padded = x_padded.reshape(
        -1, x_padded.shape[-1] // MXFP4_QUANT_BLOCK_SIZE, MXFP4_QUANT_BLOCK_SIZE
    ).to(torch.float32)
    amax, _ = torch.max(torch.abs(x_padded), dim=-1)
    amax = amax.view(torch.int32)
    amax = (amax + 0x200000) & 0xFF800000
    amax = amax.view(torch.float32)
    scale_e8m0_unbiased = torch.log2(amax).floor() - 2
    scale_e8m0_unbiased = torch.clamp(scale_e8m0_unbiased, min=-127, max=127)
    quant_scale = torch.exp2(-scale_e8m0_unbiased)

    # Quantized values
    qx = x_padded * quant_scale.unsqueeze(-1)

    # blockscale_e8m0
    bs_e8m0 = scale_e8m0_unbiased.to(torch.uint8) + 127

    # e2m1 rounding: round-half-up, saturating past the range (take min(x, 7) of
    # ((E<<2 | M>>21) + 1) >> 1)
    qx = qx.view(torch.int32)
    s = qx & 0x80000000
    e = (qx >> 23) & 0xFF
    m = qx & 0x7FFFFF

    E8_BIAS = 127
    E2_BIAS = 1
    adjusted_exponents = E8_BIAS - e - 1
    m = torch.where(e < E8_BIAS, (0x400000 | (m >> 1)) >> adjusted_exponents, m)
    e = torch.where(e > E8_BIAS - E2_BIAS, e, E8_BIAS - E2_BIAS) - (E8_BIAS - E2_BIAS)

    combined_val = (((e << 2) | (m >> 21)) + 1) >> 1
    e2m1_tmp = torch.where(combined_val < 0x7, combined_val, 0x7)
    e2m1_value = (((s >> 28) & 0xF) | e2m1_tmp).to(torch.uint8)

    # Pack 2 4-bit code words per byte: even indices occupy the low 4 bits
    x_mxfp4 = e2m1_value[..., ::2] | (e2m1_value[..., 1::2] << 4)
    x_mxfp4 = torch.flatten(x_mxfp4, -2, -1)

    # Drop the extra bytes produced by the zero padding
    if x.shape[-1] % MXFP4_QUANT_BLOCK_SIZE != 0:
        x_mxfp4 = x_mxfp4[..., : x.shape[-1] // 2]

    mxfp4_shape = list(x_shape)
    mxfp4_shape = tuple(mxfp4_shape[:-1] + [mxfp4_shape[-1] // 2])
    x_mxfp4 = x_mxfp4.reshape(mxfp4_shape)
    return x_mxfp4, bs_e8m0

class ModelNew(nn.Module):
    """Fused residual add + RMSNorm + MXFP4 dynamic quantization (mxfp4 GEMM
    preprocessing).

    Mathematical definition (all intermediates in float32; inputs are randn in
    the bfloat16/float16 value range):
      1. s = inp1 + res1                                     element-wise add
      2. norm[m, j] = s[m, j] * rsqrt( (1/N1) * sum_j s[m, j]^2 + eps ) * weight1[j]
         eps = 1e-6, normalized along the last dimension
      3. MXFP4 dynamic quantization of every row of norm in 32-element blocks
         (definition below), yielding packed e2m1 code words (2 per byte) and
         e8m0 block scale bytes.

    MXFP4 quantization (block size fixed at 32 along the last dimension; a
    trailing block shorter than 32 zero padded and taking part):
      a. amax = max |x| (inside the block, padding included)
      b. round amax up to a power of two: interpret the IEEE754 bit pattern of
         amax as int32, add 0x200000, bitwise-AND with 0xFF800000, then
         reinterpret as float32 (unchanged when amax is already a power of two,
         otherwise it goes up to the next power of two)
      c. e = clamp( floor(log2(rounded amax)) - 2, -127, 127 )
      d. scale byte = e + 127 (uint8 e8m0 encoding)
      e. q = x * 2^(-e), rounded to the e2m1 code table
         {0, +-0.5, +-1, +-1.5, +-2, +-3, +-4, +-6}: round-half-up (0.5 rounds
         up), saturating to +-6 beyond the range; the equivalent bit-level form
         is ((E<<2 | M>>21) + 1) >> 1 on the fp32 bit pattern, then min(x, 7),
         with bit31 as the sign bit
      f. packing: the 2i-th and the (2i+1)-th code words share one byte, the
         even index occupying the low 4 bits

    Input/output specification:
      inp1    (M, N1)  bfloat16/float16  main input
      weight1 (N1,)    same as inp1      RMSNorm weight
      res1    (M, N1)  same as inp1      residual
      out     (M, N1//2 + ceil(N1/32)) uint8, single-tensor output contract:
              out[:, :N1//2]        packed e2m1 code words (2 per byte, even
                                    indices in the low 4 bits)
              out[:, N1//2:]        e8m0 block scale bytes (ceil(N1/32) per row)
      Constraints: M >= 1; N1 is even and N1 >= 2.
      Boundary behaviour: an all-zero block has amax=0, handled as
      log2(0)=-inf, so after the clamp e=-127, the scale byte is 0 and the code
      words are 0.

    Implementation constraints (violations are scored as failures):
      - The core computation of RMSNorm and quantization (amax/scale
        computation, e2m1 rounding, packing) must be completed inside the
        submitted file; calling torch.nn.functional.rms_norm /
        torch.nn.RMSNorm is forbidden, as is using torch built-in float4/mxfp4
        quantization or conversion APIs (including torch.float4_e2m1fn_x2,
        torch.quantize_per_tensor and other ready-made quantization
        operators), and wrapping or modifying any third-party operator
        library's existing implementation.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate computation uses float32; the output is uint8, and both
        the code words and the scale bytes must be bit-exact against the
        reference implementation (exact match, no tolerance).
      - The evaluator casts every input to fp32 before calling forward
        (bfloat16/float16 values are exact in fp32); just compute with those
        values directly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-path residual + RMSNorm + MXFP4 dynamic quantization
    (block size 32, even rounding), without the downstream GEMM main
    computation.
    """
    def __init__(self, dtype: str = "bfloat16", eps: float = 1e-6):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.dtype = getattr(torch, dtype)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, inp1, weight1, res1):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _fused_mxfp4_quant_triton(inp1, weight1, res1, self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Full-row RMS normalization is performed inside the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Packed codes and block scales have already been written to out.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return out
        # <<<END_IMPROVE>>>
