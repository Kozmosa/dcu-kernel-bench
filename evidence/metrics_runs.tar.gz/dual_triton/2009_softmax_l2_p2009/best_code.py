import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _row_softmax(X, Y, N: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    cols = tl.arange(0, BLOCK)
    values = tl.load(X + row * N + cols, cols < N, other=-float('inf')).to(tl.float32)
    maximum = tl.max(values, axis=0)
    exp_values = tl.exp(values - maximum)
    denominator = tl.sum(exp_values, axis=0)
    tl.store(Y + row * N + cols, exp_values / denominator, cols < N)


@triton.jit
def _streaming_row_softmax(X, Y, N, BLOCK: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    base = row * N
    lanes = tl.arange(0, BLOCK).to(tl.int64)
    maxima = tl.full((BLOCK,), -float('inf'), tl.float32)
    for start in range(0, N, BLOCK):
        cols = start + lanes
        values = tl.load(X + base + cols, cols < N, other=-float('inf')).to(tl.float32)
        maxima = tl.maximum(maxima, values)
    maximum = tl.max(maxima, axis=0)
    sums = tl.full((BLOCK,), 0, tl.float32)
    for start in range(0, N, BLOCK):
        cols = start + lanes
        values = tl.load(X + base + cols, cols < N, other=-float('inf')).to(tl.float32)
        sums += tl.exp(values - maximum)
    denominator = tl.sum(sums, axis=0)
    for start in range(0, N, BLOCK):
        cols = start + lanes
        values = tl.load(X + base + cols, cols < N, other=-float('inf')).to(tl.float32)
        result = tl.exp(values - maximum) / denominator
        tl.store(Y + base + cols, result, cols < N)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """2D row-wise softmax.

    For each row (the last dimension) of an (M, N) input, independently:
        m[i]     = max_j x[i, j]
        z[i, j]  = exp(x[i, j] - m[i])
        y[i, j]  = z[i, j] / sum_j z[i, j]
    Rows are completely independent, and after per-row normalization the elements
    of every row sum to 1. The reference implementation does max / exp / sum
    entirely in float32 and casts the output back to the input dtype.

    Boundary behaviour: N is any positive integer -- when N=1 the row's output is
    always 1; non-power-of-two N and very long rows (longer than a single block's
    capacity) must still give exact results, and out-of-range elements at the row
    tail must not participate in the max and sum reductions; the inputs are
    ordinary randn magnitude (no inf/NaN).

    Input/output specification:
        x   float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        y   same dtype as x, (M, N), the row-wise softmax result
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless); this operator has no integer tensor
        input, so nothing needs restoring.

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-row max reduction, the exp sum reduction,
          and the element-wise normalization) must be completed with a Triton
          kernel inside the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Intermediates (max / sum / exp) are computed in float32; the output is
          cast back to the input dtype.

    Forbidden list: aiter / torch.softmax / torch.nn.functional.softmax /
    torch.nn.Softmax / torch.log_softmax / torch.nn.functional.log_softmax /
    torch.nn.LogSoftmax / torch.special.softmax / torch.special.log_softmax.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        dt = x.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, N = x.shape
        y = torch.empty_like(x)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        if N <= 8192:
            block = triton.next_power_of_2(N)
            _row_softmax[(M,)](x, y, N, BLOCK=block, num_warps=4 if block <= 2048 else 8)
        else:
            _streaming_row_softmax[(M,)](x, y, N, BLOCK=1024, num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # Exponentiation is performed inside the Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # y has already been normalized by Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        return y.to(dt)
        # <<<END_IMPROVE>>>
