import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _sample(X, O, M, V, C: tl.constexpr, H: tl.constexpr, W: tl.constexpr, P: tl.constexpr, S: tl.constexpr, T: tl.constexpr, OW: tl.constexpr, SH: tl.constexpr, SW: tl.constexpr, PH: tl.constexpr, PW: tl.constexpr, DH: tl.constexpr, DW: tl.constexpr, MOD: tl.constexpr):
    t = tl.program_id(0) * 128 + tl.arange(0, 128)
    c = tl.program_id(1) * 4 + tl.arange(0, 4)
    n = tl.program_id(2) // P
    p = tl.program_id(2) % P
    oy = tl.load(O + (n * 2 * P + 2 * p) * T + t, t < T, 0).to(tl.float32)
    ox = tl.load(O + (n * 2 * P + 2 * p + 1) * T + t, t < T, 0).to(tl.float32)
    y = (t // OW * SH - PH + p // S * DH).to(tl.float32) + oy
    x = (t % OW * SW - PW + p % S * DW).to(tl.float32) + ox
    iy = tl.floor(y).to(tl.int32)
    ix = tl.floor(x).to(tl.int32)
    wy = y - iy.to(tl.float32)
    wx = x - ix.to(tl.float32)
    base = X + (n * C + c[:, None]) * H * W
    valid = (c[:, None] < C) & (t[None, :] < T)
    a = tl.load(base + iy[None, :] * W + ix[None, :], valid & (iy[None, :] >= 0) & (iy[None, :] < H) & (ix[None, :] >= 0) & (ix[None, :] < W), 0).to(tl.float32)
    b = tl.load(base + iy[None, :] * W + ix[None, :] + 1, valid & (iy[None, :] >= 0) & (iy[None, :] < H) & (ix[None, :] + 1 >= 0) & (ix[None, :] + 1 < W), 0).to(tl.float32)
    d = tl.load(base + (iy[None, :] + 1) * W + ix[None, :], valid & (iy[None, :] + 1 >= 0) & (iy[None, :] + 1 < H) & (ix[None, :] >= 0) & (ix[None, :] < W), 0).to(tl.float32)
    e = tl.load(base + (iy[None, :] + 1) * W + ix[None, :] + 1, valid & (iy[None, :] + 1 >= 0) & (iy[None, :] + 1 < H) & (ix[None, :] + 1 >= 0) & (ix[None, :] + 1 < W), 0).to(tl.float32)
    v = a * ((1 - wy) * (1 - wx))[None, :] + b * ((1 - wy) * wx)[None, :]
    v = v + d * (wy * (1 - wx))[None, :]
    v = v + e * (wy * wx)[None, :]
    if MOD:
        m = tl.load(M + (n * P + p) * T + t, t < T, 0).to(tl.float32)
        v = v * m[None, :]
    tl.store(V + ((n * C + c[:, None]) * P + p) * T + t[None, :], v, valid)

@triton.jit
def _contract(W, V, B, Y, K: tl.constexpr, D: tl.constexpr, T: tl.constexpr):
    k = tl.program_id(0) * 16 + tl.arange(0, 16)
    t = tl.program_id(1) * 32 + tl.arange(0, 32)
    n = tl.program_id(2)
    q = tl.arange(0, 32)
    acc = tl.zeros((16, 32), tl.float32)
    for start in range(tl.cdiv(D, 32)):
        d = start * 32 + q
        a = tl.load(W + k[:, None] * D + d[None, :], (k[:, None] < K) & (d[None, :] < D), 0).to(tl.float32)
        b = tl.load(V + (n * D + d[:, None]) * T + t[None, :], (d[:, None] < D) & (t[None, :] < T), 0).to(tl.float32)
        acc = tl.dot(a, b, acc, input_precision='ieee')
    bias = tl.load(B + k, k < K, 0).to(tl.float32)
    tl.store(Y + (n * K + k[:, None]) * T + t[None, :], acc + bias[:, None], (k[:, None] < K) & (t[None, :] < T))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Deformable 2D convolution forward (Deformable Convolution): sampling grid
    plus a handwritten bilinear interpolation.

    Semantics (NCHW, all intermediate computation in float32):
      For each output position (oi, oj) and kernel position p = i*S + j
      (i in [0,R), j in [0,S), row-major), the base sampling coordinate given by
      the regular convolutional receptive field is
          y0 = oi * stride_h + i * dilation_h - padding_h
          x0 = oj * stride_w + j * dilation_w - padding_w
      After adding the per-(output position x kernel position) offsets, the
      input map is sampled at real-valued coordinates with bilinear
      interpolation:
          yc = y0 + offset[n, 2*p,     oi, oj]     # even channel = y offset
          xc = x0 + offset[n, 2*p + 1, oi, oj]     # odd channel = x offset
          v(n, c, p, oi, oj) = bilinear(input map, yc, xc)
      The __init__ parameter variant selects one of the two paths:
          "modulated" (default, modulated form): the sampled value is
              additionally multiplied by the per-position modulation mask
              v *= mask[n, p, oi, oj]
          "plain" (mask-free form): mask does not take part in the computation
              (its contents are arbitrary, possibly garbage data).
      The output is a single tensor:
          out[n, k, oi, oj] = bias[k]
                              + sum_{c, p} v(n, c, p, oi, oj) * weight[k, c, i, j]
      After the computation it is cast back to the input dtype.

    Bilinear interpolation definition (point-wise identical to mainstream
    deformable convolution operators):
      Let iy = floor(yc), ix = floor(xc), wy = yc - iy, wx = xc - ix, and take
      the four corners (iy, ix), (iy, ix+1), (iy+1, ix), (iy+1, ix+1) with
      weights (1-wy)(1-wx), (1-wy)wx, wy(1-wx), wy*wx respectively; when either
      the row or the column of a corner is out of range (< 0 or > dim-1) that
      corner contributes 0 while the remaining corners are weighted as usual --
      i.e. zero-fill semantics: a partially out-of-range coordinate is still
      weighted by the remaining valid corners, and when it is entirely out of
      range (yc <= -1, outside the yc >= H-1 boundary band, etc.) the sampled
      value is 0. No clamp / nearest-neighbour pull-back is done anywhere.

    Input/output specification (all tensors contiguous, NCHW layout):
      x        float32 / float16 / bfloat16 (N, C, H, W)
      offset   same dtype as x (N, 2*R*S, H_out, W_out): 2 channels per kernel
               position (even channel = y offset, odd channel = x offset,
               p = i*S + j row-major)
      weight   same dtype as x (K, C, R, S)
      bias     same dtype as x (K,)
      mask     same dtype as x (N, R*S, H_out, W_out) (ignored when
               variant="plain")
      out      a single tensor, same dtype as x (N, K, H_out, W_out)
      H_out = (H + 2*padding_h - dilation_h*(R-1) - 1) // stride_h + 1, likewise
      for W_out. The evaluator casts all inputs to fp32 before the call
      (low-precision inputs are lossless).

    Implementation constraints (violations are scored as failures):
      - The core computation (sampling-grid construction, bilinear-interpolation
        sampling, mask modulation, the weighted reduction against weight) must
        be handwritten with a Triton kernel inside the submitted file.
      - forward returns the single tensor out (the evaluator compares a single
        output).
      - Interpolation and the weighted reduction are computed in float32, with
        the output cast back to the input dtype.
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torchvision (including torchvision.ops.deform_conv2d) /
    torch.nn.functional.conv2d (F.conv2d) / torch.nn.Conv2d /
    torch.nn.functional.grid_sample (F.grid_sample) /
    torch.nn.functional.unfold (F.unfold) / torch.matmul / torch.bmm /
    torch.mm / torch.einsum / torch.tensordot / miopen / hipdnn / aiter.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "modulated", stride=(1, 1), padding=(1, 1), dilation=(1, 1)):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("modulated", "plain"), "variant must be either modulated or plain"
        self.variant = variant
        self.stride = (int(stride[0]), int(stride[1]))
        self.padding = (int(padding[0]), int(padding[1]))
        self.dilation = (int(dilation[0]), int(dilation[1]))
        # <<<END_IMPROVE>>>

    def forward(self, x, offset, weight, bias, mask):
        # <<<IMPROVE:forward_stmt_1>>>
        n, c, h, w = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        k_out = weight.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        r, s = weight.shape[2], weight.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        sh, sw = self.stride
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        ph, pw = self.padding
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dh, dw = self.dilation
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        h_out = (h + 2 * ph - (dh * (r - 1) + 1)) // sh + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        w_out = (w + 2 * pw - (dw * (s - 1) + 1)) // sw + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert offset.shape[1] == 2 * r * s and mask.shape[1] == r * s, \
            "the channel counts of offset/mask must be 2*R*S / R*S"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert offset.shape[2] == h_out and offset.shape[3] == w_out \
            and mask.shape[2] == h_out and mask.shape[3] == w_out, \
            "the spatial sizes of offset/mask must be (H_out, W_out)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        sampled = torch.empty((n, c*r*s, h_out*w_out), device=x.device, dtype=torch.float32)
        out = torch.empty((n, k_out, h_out, w_out), device=x.device, dtype=x.dtype)
        _sample[(triton.cdiv(h_out*w_out, 128), triton.cdiv(c, 4), n*r*s)](x, offset, mask, sampled, c, h, w, r*s, s, h_out*w_out, w_out, sh, sw, ph, pw, dh, dw, self.variant == 'modulated', num_warps=4, enable_fp_fusion=False)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_27>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_28>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_29>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_30>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_31>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_32>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_33>>>
        _contract[(triton.cdiv(k_out, 16), triton.cdiv(h_out*w_out, 32), n)](weight, sampled, bias, out, k_out, c*r*s, h_out*w_out, num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_34>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_35>>>
        return out
        # <<<END_IMPROVE>>>
