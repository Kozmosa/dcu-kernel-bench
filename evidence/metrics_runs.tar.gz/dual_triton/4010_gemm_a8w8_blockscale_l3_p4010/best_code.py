import torch
import torch.nn as nn
import torch.nn.functional as F

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _gemm_a8w8_blockscale_kernel(
    x_ptr, w_ptr, xs_ptr, ws_ptr, out_ptr,
    M, N, K, GK: tl.constexpr, GN: tl.constexpr,
    sx0, sx1, sw0, sw1,
    sxs0, sxs1, sws0, sws1,
    so0, so1,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    m_mask = offs_m < M
    n_mask = offs_n < N
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for k0 in range(0, K, BLOCK_K):
        offs_k = k0 + tl.arange(0, BLOCK_K)
        k_mask = offs_k < K
        xp = x_ptr + offs_m[:, None] * sx0 + offs_k[None, :] * sx1
        wp = w_ptr + offs_n[None, :] * sw0 + offs_k[:, None] * sw1
        a = tl.load(xp, mask=m_mask[:, None] & k_mask[None, :], other=0).to(tl.float32)
        b = tl.load(wp, mask=n_mask[None, :] & k_mask[:, None], other=0).to(tl.float32)
        if GK % BLOCK_K == 0 and GN % BLOCK_N == 0:
            xscale = tl.load(
                xs_ptr + offs_m * sxs0 + (k0 // GK) * sxs1,
                mask=m_mask & (k0 < K),
                other=0.0,
            ).to(tl.float32)
            xscale = xscale[:, None]
            wscale = tl.load(
                ws_ptr + ((pid_n * BLOCK_N) // GN) * sws0 + (k0 // GK) * sws1,
                mask=(pid_n * BLOCK_N < N) & (k0 < K),
                other=0.0,
            ).to(tl.float32)
        else:
            xscale = tl.load(
                xs_ptr + offs_m[:, None] * sxs0 + (offs_k[None, :] // GK) * sxs1,
                mask=m_mask[:, None] & k_mask[None, :],
                other=0.0,
            ).to(tl.float32)
            wscale = tl.load(
                ws_ptr + (offs_n[None, :] // GN) * sws0 + (offs_k[:, None] // GK) * sws1,
                mask=n_mask[None, :] & k_mask[:, None],
                other=0.0,
            ).to(tl.float32)
        a = a * xscale
        b = b * wscale
        acc = tl.dot(a, b, acc=acc, input_precision="ieee")
    outp = out_ptr + offs_m[:, None] * so0 + offs_n[None, :] * so1
    tl.store(outp, acc, mask=m_mask[:, None] & n_mask[None, :])
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """8bit GEMM with 2D block-scale dequantization (fp8 activations x fp8
    weights).

    Mathematical definition: given the fp8(e4m3) code-word matrices xq (M, K),
    wq (N, K) and the float32 block scales x_scale (M, ceil(K/gk)),
    w_scale (ceil(N/gn), ceil(K/gk)), the output is
      dq_x[m, k] = xq[m, k] * x_scale[m, k // gk]
      dq_w[n, k] = wq[n, k] * w_scale[n // gn, k // gk]
      acc[m, n]  = sum_k dq_x[m, k] * dq_w[n, k]     (float32 accumulation)
      out[m, n]  = cast(acc[m, n], out_dtype)
    That is, every element is first dequantized with the block scale it belongs
    to ((m, k//gk) / (n//gn, k//gk)), then a float32 GEMM is performed
    (equivalent to the transposed GEMM xq @ wq^T, with wq row-major (N, K)).
    Scale ownership is decided element by element and is independent of the
    K-direction tile partition; when K is not divisible by gk / N is not
    divisible by gn, elements of the tail block still use the scale of the
    block they belong to (the scale count is the ceil division result); M/N/K
    >= 1, non-powers of two allowed. The dequantization multiply and the GEMM
    accumulation run in float32 throughout, and the output is finally cast to
    out_dtype.

    Input/output specification:
      x       float8_e4m3fn (M, K)             activation code words (row-major, TN layout)
      w       float8_e4m3fn (N, K)             weight code words (row-major, transposed GEMM)
      x_scale float32 (M, ceil(K/gk))          activation scale: per-M-row, K in gk blocks
      w_scale float32 (ceil(N/gn), ceil(K/gk)) weight 2D block scale (rows = N blocks, cols = K blocks)
      out     out_dtype (M, N)                 bfloat16 / float16, set by __init__
    The online evaluator casts every input to fp32 before calling forward; the
    finite values of fp8(e4m3) are exact in fp32, so the
    .to(torch.float8_e4m3fn) at the entry point recovers the code words
    losslessly.

    Final-audit compatible form: the offline final-audit harness constructs the
    model with a single argument Model(case["head_size"])
    (case["head_size"] = [group_k, group_n, out_dtype]), so the first __init__
    argument also accepts a [group_k, group_n, out_dtype] sequence and unpacks
    it in order; ModelNew must keep the same dual-form compatibility
    (constructible with either three arguments or a single sequence).

    Implementation constraints (violations are scored as failures):
      - The core computation (8bit GEMM accumulation + block-scale
        dequantization) must be completed inside the submitted file, and
        calling any ATen matmul shortcut is forbidden: torch.matmul /
        torch.bmm / torch.mm / torch.addmm / torch.einsum / torch._int_mm /
        torch._scaled_mm / F.linear / functional.linear, together with their
        torch.ops.aten.* fully qualified names and tensor-method forms
        (torch.ops.aten.mm, .mm( / .bmm( / .matmul( / .addmm( / .einsum( /
        ._int_mm( / ._scaled_mm( etc.), the matmul operator @ and the tensor
        transpose method .t() (x @ w.t() is the typical disguised form; the
        transpose should be handled with strides inside the kernel). The
        final-audit static audit scans the submitted file for those literal
        strings (docstrings excluded).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast to
        out_dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: a single matrix (no batch dimension), no bias, no splitK; the
    code-word and scale value ranges follow the task generator (code words are
    fp8 values in [0, 0.1), scales are float32 in [0, 1)).
    """
    def __init__(self, group_k=128, group_n=128, out_dtype="bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        if isinstance(group_k, (list, tuple)):
            group_k, group_n, out_dtype = group_k
        self.group_k = int(group_k)
        self.group_n = int(group_n)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, x, w, x_scale, w_scale):
        # <<<IMPROVE:forward_stmt_1>>>
        if x.dtype != torch.float32:
                    x = x.to(torch.float8_e4m3fn)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        if w.dtype != torch.float32:
                    w = w.to(torch.float8_e4m3fn)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        gk, gn = self.group_k, self.group_n
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = w.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == w.shape[1], "the K dimension of x and w must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        scale_k = (K + gk - 1) // gk
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        scale_n = (N + gn - 1) // gn
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert x_scale.shape == (M, scale_k), \
            f"x_scale shape should be ({M}, {scale_k}), got {tuple(x_scale.shape)}"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert w_scale.shape == (scale_n, scale_k), \
            f"w_scale shape should be ({scale_n}, {scale_k}), got {tuple(w_scale.shape)}"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty((M, N), device=x.device, dtype=self.out_dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        x = x.to(torch.float32)
        w = w.to(torch.float32)
        _gemm_a8w8_blockscale_kernel[(triton.cdiv(M, 16), triton.cdiv(N, 32))](
            x, w, x_scale, w_scale, out,
            M, N, K, gk, gn,
            x.stride(0), x.stride(1),
            w.stride(0), w.stride(1),
            x_scale.stride(0), x_scale.stride(1),
            w_scale.stride(0), w_scale.stride(1),
            out.stride(0), out.stride(1),
            BLOCK_M=16, BLOCK_N=32, BLOCK_K=32,
            num_warps=4, num_stages=1,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return out.to(self.out_dtype)
        # <<<END_IMPROVE>>>
