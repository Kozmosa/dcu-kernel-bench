import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _decode_parts(Q, K, V, PT, L, M, Z, A,
                  HQ: tl.constexpr, G: tl.constexpr, DK: tl.constexpr, DV: tl.constexpr,
                  PS: tl.constexpr, S: tl.constexpr, SCALE: tl.constexpr,
                  QB: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
                  KT: tl.constexpr, KH: tl.constexpr, KD: tl.constexpr,
                  VT: tl.constexpr, VH: tl.constexpr, VD: tl.constexpr,
                  PB: tl.constexpr, PP: tl.constexpr, LS: tl.constexpr,
                  CK: tl.constexpr, CV: tl.constexpr):
    row = tl.program_id(0)
    split = tl.program_id(1)
    b = row // HQ
    h = row % HQ
    kh = h // G
    length = tl.load(L + b * LS)
    chunk = tl.cdiv(length, S)
    start = split * chunk
    end = tl.minimum(start + chunk, length)
    dk = tl.arange(0, CK)
    dv = tl.arange(0, CV)
    t = tl.arange(0, 32)
    q = tl.load(Q + b * QB + h * QH + dk * QD, dk < DK, 0).to(tl.float32) * SCALE
    m = tl.full((), -float('inf'), tl.float32)
    z = tl.full((), 0, tl.float32)
    acc = tl.full((CV,), 0, tl.float32)
    for base in range(start, end, 32):
        tok = base + t
        valid = tok < end
        page = tl.load(PT + b * PB + (tok // PS) * PP, valid, 0)
        slot = page.to(tl.int64) * PS + tok % PS
        k = tl.load(K + slot[:, None] * KT + kh * KH + dk[None, :] * KD,
                    valid[:, None] & (dk[None, :] < DK), 0).to(tl.float32)
        score = tl.sum(k * q[None, :], 1)
        score = tl.where(valid, score, -float('inf'))
        new_m = tl.maximum(m, tl.max(score, 0))
        alpha = tl.exp(m - new_m)
        p = tl.exp(score - new_m)
        v = tl.load(V + slot[:, None] * VT + kh * VH + dv[None, :] * VD,
                    valid[:, None] & (dv[None, :] < DV), 0).to(tl.float32)
        acc = acc * alpha + tl.sum(p[:, None] * v, 0)
        z = z * alpha + tl.sum(p, 0)
        m = new_m
    idx = row * S + split
    tl.store(M + idx, m)
    tl.store(Z + idx, z)
    tl.store(A + idx * DV + dv, acc, dv < DV)


@triton.jit
def _decode_merge(M, Z, A, O, S: tl.constexpr, DV: tl.constexpr,
                  CS: tl.constexpr, CV: tl.constexpr):
    row = tl.program_id(0)
    s = tl.arange(0, CS)
    d = tl.arange(0, CV)
    m = tl.load(M + row * S + s, s < S, -float('inf'))
    z = tl.load(Z + row * S + s, s < S, 0)
    maximum = tl.max(m, 0)
    weight = tl.where(z > 0, tl.exp(m - maximum), 0.0)
    denominator = tl.sum(weight * z, 0)
    a = tl.load(A + (row * S + s[:, None]) * DV + d[None, :],
                (s[:, None] < S) & (d[None, :] < DV), 0)
    result = tl.sum(a * weight[:, None], 0) / denominator
    tl.store(O + row * DV + d, result, d < DV)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Decode-stage attention (single-token query) with paged KV.

    The KV cache is paged at page_size granularity: slot s of physical page p in
    key_cache / value_cache corresponds to flat slot number p * page_size + s.
    Sequence b is addressed indirectly through page_tables, and its l-th KV token
    (0 <= l < seq_lens[b]) lives in slot l % page_size of physical page
    page_tables[b, l // page_size]; slots in the page pool that are not
    referenced are garbage data and must not affect the output. Query head h
    corresponds to KV head h // query_group_size
    (query_group_size = num_q_heads // num_kv_heads, equal to 1 means MHA, equal
    to num_q_heads means MQA). For every sequence b and every query head h:
      logits[l] = scale * <q[b,h,:head_dim_qk],
                            key_flat[slot(b,l), h//group, :head_dim_qk]>
      p[l]      = exp(logits[l] - max(logits)) / sum(exp(logits - max(logits)))
      out[b,h,:head_dim_v] = sum_l p[l] * value_flat[slot(b,l), h//group, :head_dim_v]
    where key_flat / value_flat is the [num_pages*page_size, H_KV, D] flat view of
    the page pool, scale defaults to 1/sqrt(head_dim_qk), and the softmax must be
    numerically stable.

    Any implementation that is numerically equivalent within the tolerance is
    acceptable; how the work is parallelized is **not** a scoring criterion.

    Boundary behaviour:
      - Only the first seq_lens[b] KV tokens participate in the computation;
        seq_lens[b] >= 1 (an empty sequence is undefined).
      - page_size >= 1 is an arbitrary value (with page_size == 1 the page_tables
        are simply a per-token slot table).
      - head_dim_qk and head_dim_v may differ, and non-power-of-2 is allowed (for
        example 192/128, 576/512); the channels short of a power of 2 are handled
        by masking, so no out-of-bounds access occurs.
      - The page pool may be larger than what is actually used; page_tables
        entries beyond ceil(seq_lens[b]/page_size) point at valid but garbage
        pages that do not belong to this sequence.

    Inputs:
      q           [num_seqs, num_q_heads, head_dim_qk]  fp16/bf16 -- the query of
                  one new token per batch
      key_cache   [num_pages, page_size, num_kv_heads, head_dim_qk]
      value_cache [num_pages, page_size, num_kv_heads, head_dim_v]
      page_tables [num_seqs, max_pages_per_seq] int32 -- logical page -> physical page id
      seq_lens    [num_seqs] int32 -- the actually valid KV length of each sequence
    Output:
      out [num_seqs, num_q_heads, head_dim_v], dtype same as q.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV / cross-slice reduction) must
        be completed inside the submitted file; calling external attention
        operator libraries such as scaled_dot_product_attention / sdpa /
        flash_attn, as well as torch.matmul / torch.bmm / torch.einsum /
        torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, non-quantized KV, no logit_cap clamping, no
    ALiBi, no sliding window.
    """
    def __init__(self, page_size: int, head_dim_qk: int, head_dim_v: int, num_kv_splits: int = 8, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.page_size = int(page_size)
        self.head_dim_qk = int(head_dim_qk)
        self.head_dim_v = int(head_dim_v)
        self.num_kv_splits = int(num_kv_splits)
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim_qk)
        # <<<END_IMPROVE>>>

    def forward(self, q, key_cache, value_cache, page_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        page_tables = page_tables
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D_QK = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_pages, page_size, H_KV, _ = key_cache.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        D_V = value_cache.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert page_size == self.page_size, "the key_cache page size does not match the initialized page_size"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        key_flat = key_cache.view(num_pages * page_size, H_KV, D_QK)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        value_flat = value_cache.view(num_pages * page_size, H_KV, D_V)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty(B, H_Q, D_V, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        S = max(1, self.num_kv_splits)
        partial_max = torch.empty((B, H_Q, S), device=q.device, dtype=torch.float32)
        partial_sum = torch.empty_like(partial_max)
        partial_acc = torch.empty((B, H_Q, S, D_V), device=q.device, dtype=torch.float32)
        _decode_parts[(B * H_Q, S)](
            q, key_flat, value_flat, page_tables, seq_lens,
            partial_max, partial_sum, partial_acc,
            H_Q, group, D_QK, D_V, page_size, S, self.scale,
            *q.stride(), *key_flat.stride(), *value_flat.stride(),
            *page_tables.stride(), seq_lens.stride(0),
            triton.next_power_of_2(D_QK), triton.next_power_of_2(D_V),
            num_warps=4)
        _decode_merge[(B * H_Q,)](
            partial_max, partial_sum, partial_acc, out, S, D_V,
            triton.next_power_of_2(S), triton.next_power_of_2(D_V), num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
