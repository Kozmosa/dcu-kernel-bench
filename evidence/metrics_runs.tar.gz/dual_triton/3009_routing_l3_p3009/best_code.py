import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _routing_fused(X, W, O, M: tl.constexpr, K: tl.constexpr, N: tl.constexpr, SHARED: tl.constexpr, BLOCK_K: tl.constexpr):
    rows = tl.program_id(0) * 16 + tl.arange(0, 16)
    cols = tl.arange(0, 32)
    ks = tl.arange(0, BLOCK_K)
    best = tl.full((16,), -float('inf'), tl.float32)
    best_id = tl.full((16,), 2147483647, tl.int32)
    for nb in range(tl.cdiv(N, 32)):
        ns = nb * 32 + cols
        acc = tl.zeros((16, 32), tl.float32)
        for kb in range(tl.cdiv(K, BLOCK_K)):
            kk = kb * BLOCK_K + ks
            a = tl.load(X + rows[:, None] * K + kk[None, :],
                        (rows[:, None] < M) & (kk[None, :] < K), other=0)
            b = tl.load(W + kk[:, None] * N + ns[None, :],
                        (kk[:, None] < K) & (ns[None, :] < N), other=0)
            acc = tl.dot(a, b, acc, input_precision='ieee')
        scores = 1.0 / (1.0 + tl.exp(-acc))
        scores = tl.where(ns[None, :] < N, scores, -float('inf'))
        tile_best = tl.max(scores, axis=1)
        tile_id = tl.min(tl.where((ns[None, :] < N) & (scores == tile_best[:, None]),
                                  ns[None, :], 2147483647), axis=1)
        take = (tile_best > best) | ((tile_best == best) & (tile_id < best_id))
        best_id = tl.where(take, tile_id, best_id)
        best = tl.maximum(best, tile_best)
    if SHARED:
        tl.store(O + rows * 4, best_id.to(tl.float32), rows < M)
        tl.store(O + rows * 4 + 1, N, rows < M)
        tl.store(O + rows * 4 + 2, best, rows < M)
        tl.store(O + rows * 4 + 3, 1.0, rows < M)
    else:
        tl.store(O + rows * 2, best_id.to(tl.float32), rows < M)
        tl.store(O + rows * 2 + 1, best, rows < M)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Sigmoid top-1 routing of MoE (Mixture of Experts) gating: pick the expert
    with the highest routing score for each token out of N experts (top_k is
    always 1).

    Operator semantics: given the gating input x ([M, K], M tokens and K gating
    features) and the routing weight w ([K, N], one column per expert), for each
    token m and expert n:
        score[m, n] = sigmoid( sum_k x[m, k] * w[k, n] )
        sigmoid(z)  = 1 / (1 + exp(-z))
    top-1 routing output:
        topk_ids[m]     = argmax_n score[m, n], ties resolved to the smallest
                          expert index
        topk_weights[m] = max_n score[m, n]
    The inner product (matrix multiply) is evaluated with float32 accumulation;
    with top_k = 1 the normalization coefficient is always 1, so the weight is
    the raw sigmoid score and there is no need to divide by a sum.

    Fused shared expert column: with fused_shared_experts=True one fixed shared
    expert column is appended after the top-1 result -- the id column gets N
    (= the number of experts, outside the real expert id range) and the weight
    column gets 1.0. With False nothing is appended and the output has a single
    column.

    Input/output specification:
        x   [M, K] float16/bfloat16, contiguous; M/K/N >= 1, non powers of two
            allowed
        w   [K, N] same dtype as x, contiguous
        output  a single float32 tensor [M, 2*C], C = 1 + fused_shared_experts:
            out[:, :C] = the integers of topk_ids represented in fp32 (< 2^24,
                         exact)
            out[:, C:] = topk_weights (fp32 sigmoid scores; the fused column is
                         always 1.0)
        The evaluator casts all inputs to fp32 before passing them in (all
        inputs of this operator are floating point, so this is lossless).

    Implementation constraints (violations are scored as failures):
      - Core computation (the block-wise x * w matrix multiply, sigmoid, the
        top-1 selection and tie-break, writing back the fused shared expert
        column) must be done in a Triton kernel inside the submitted file; the
        official implementation fully fuses everything into a single kernel (the
        score matrix is never materialized), splitting it into several Triton
        kernels is not scored as a failure, but calling ATen shortcuts is.
      - Accumulation inside the matrix multiply is always float32 (inputs may be
        fp16/bf16/fp32).
      - The output is strictly float32 per the single-tensor packing protocol
        above.
      - The __init__ and forward signatures of ModelNew must not be changed.

    Disallowed list: aiter / torch.matmul / torch.bmm / torch.einsum /
    torch.nn.functional.linear / torch.topk / torch.argmax / torch.sigmoid.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, fused_shared_experts: bool = True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.fused_shared_experts = bool(fused_shared_experts)
        # <<<END_IMPROVE>>>

    def forward(self, x, w):
        # <<<IMPROVE:forward_stmt_1>>>
        assert x.dim() == 2 and w.dim() == 2, "x / w must be 2-D tensors"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        Kb, N = w.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert K == Kb, "the last dimension of x must equal the number of rows of w"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        C = 1 + int(self.fused_shared_experts)
        out = torch.empty((M, 2 * C), device=x.device, dtype=torch.float32)
        block_k = 64 if K >= 64 else 32
        _routing_fused[(triton.cdiv(M, 16),)](
            x, w, out, M, K, N, self.fused_shared_experts,
            BLOCK_K=block_k, num_warps=4, num_stages=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
