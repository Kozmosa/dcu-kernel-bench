import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _gn_fused(X, S, A, O, D: tl.constexpr, HW: tl.constexpr, G: tl.constexpr, R: tl.constexpr, NG: tl.constexpr, EPS: tl.constexpr, SW: tl.constexpr, B: tl.constexpr):
    row = tl.program_id(0)
    i = tl.arange(0, B)
    valid = i < D
    x = tl.load(X + row * D + i, valid, 0).to(tl.float32)
    mean = tl.sum(x, 0) / D
    delta = x - mean
    var = tl.sum(tl.where(valid, delta * delta, 0.0), 0) / D
    inv = tl.rsqrt(var + EPS)
    ch = (row % G) * R + i // HW
    s = tl.load(S + ch, valid, 0).to(tl.float32)
    a = tl.load(A + ch, valid, 0).to(tl.float32)
    y = ((x - mean) * inv) * s + a
    if SW:
        y = y / (1.0 + tl.exp(-y))
    tl.store(O + row * D + i, y, valid)
    tl.store(O + NG * D + row, mean)
    tl.store(O + NG * D + NG + row, inv)


@triton.jit
def _gn_stats(X, O, D: tl.constexpr, NG: tl.constexpr, EPS: tl.constexpr, B: tl.constexpr):
    row = tl.program_id(0)
    lanes = tl.arange(0, B)
    accum = tl.full((B,), 0.0, tl.float32)
    for start in range(0, D, B):
        i = start + lanes
        x = tl.load(X + row * D + i, i < D, 0).to(tl.float32)
        accum += x
    mean = tl.sum(accum, 0) / D
    squares = tl.full((B,), 0.0, tl.float32)
    for start in range(0, D, B):
        i = start + lanes
        x = tl.load(X + row * D + i, i < D, 0).to(tl.float32)
        delta = x - mean
        squares += tl.where(i < D, delta * delta, 0.0)
    inv = tl.rsqrt(tl.sum(squares, 0) / D + EPS)
    tl.store(O + NG * D + row, mean)
    tl.store(O + NG * D + NG + row, inv)


@triton.jit
def _gn_output(X, S, A, O, D: tl.constexpr, HW: tl.constexpr, C: tl.constexpr, NG: tl.constexpr, SW: tl.constexpr, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    valid = i < NG * D
    row = i // D
    mean = tl.load(O + NG * D + row, valid, 0)
    inv = tl.load(O + NG * D + NG + row, valid, 0)
    x = tl.load(X + i, valid, 0).to(tl.float32)
    ch = (i // HW) % C
    s = tl.load(S + ch, valid, 0).to(tl.float32)
    a = tl.load(A + ch, valid, 0).to(tl.float32)
    y = ((x - mean) * inv) * s + a
    if SW:
        y = y / (1.0 + tl.exp(-y))
    tl.store(O + i, y, valid)


def _groupnorm_launch(x, scale, bias, n, c, h, w, g, eps, variant):
    d = (c // g) * h * w
    ng = n * g
    out = torch.empty((ng * d + 2 * ng,), device=x.device, dtype=torch.float32)
    sw = variant == 'groupnorm_swish'
    if d <= 4096:
        _gn_fused[(ng,)](x, scale, bias, out, d, h * w, g, c // g, ng, eps, sw, triton.next_power_of_2(d), num_warps=4, enable_fp_fusion=False)
    else:
        _gn_stats[(ng,)](x, out, d, ng, eps, 1024, num_warps=4, enable_fp_fusion=False)
        _gn_output[(triton.cdiv(ng * d, 1024),)](x, scale, bias, out, d, h * w, c, ng, sw, 1024, num_warps=4, enable_fp_fusion=False)
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    GroupNorm forward family: standard GroupNorm and the GroupNorm+Swish fusion.

    The input is x (N, C, H, W), NCHW contiguous; scale / bias are the (C,)
    per-channel affine parameters; the __init__ argument groups = G (dividing C,
    1 <= G <= C) splits the channels into G groups, with channel c belonging to
    group c // (C//G); eps defaults to 1e-5. The normalization statistics are
    computed per (n, g) group: x[n] is split along the channel dimension into G
    segments (group g occupies the channels [g*(C//G), (g+1)*(C//G)), and the number
    of elements in a group is D = (C//G)*H*W), in float32:
        mean_ng     = sum_D x / D                      (biased mean)
        var_ng      = sum_D (x - mean_ng)^2 / D        (biased variance)
        inv_var_ng  = 1 / sqrt(var_ng + eps)
        gn[n,c,h,w] = (x[n,c,h,w] - mean_ng) * inv_var_ng * scale[c] + bias[c]
                      (where the group index is g = c // (C//G))
    The __init__ argument variant selects one of two paths:
        "groupnorm"      : y = gn
        "groupnorm_swish": y = gn * sigmoid(gn) (Swish / SiLU)
    Both variants also emit the per-group statistics mean and inv_var (one entry per
    (n, g), (N, G) layout, float32).

    Boundary behaviour: when the in-group variance is 0 (e.g. D == 1, a single
    element in the group) inv_var = 1/sqrt(eps) (eps guarantees no division by zero)
    and gn = bias; G=1 is full-channel normalization and G=C is per-channel
    normalization, both of which are legal; N/C/H/W are arbitrary (including 1,
    non-powers of two and unaligned), a large in-group D needs a tiling (block-wise)
    reduction, and out-of-range elements at the row tail must not take part in the
    statistics.

    Single-tensor output protocol (forward must return a single tensor; the evaluator
    compares a single output):
    Returns a one-dimensional float32 packed tensor of length N*C*H*W + 2*N*G, with
    three segments packed back to back in order (half-open intervals; each segment is
    float32, reshaped with reshape(-1) and torch.cat'ed):
        [0,               N*C*H*W)           y
        [N*C*H*W,         N*C*H*W + N*G)     mean    ((N, G) flattened row-major)
        [N*C*H*W + N*G,   N*C*H*W + 2*N*G)   inv_var ((N, G) flattened row-major)
    The output is always float32: the y segment is not quantized to a lower
    precision; fp16/bf16 is only the input quantization level (the input is provided
    in that dtype and then cast to float32 to take part in the whole computation).

    Input/output specification:
        x      float32 / float16 / bfloat16 (N, C, H, W), contiguous, N/C/H/W >= 1
        scale  same dtype as x, (C,), contiguous
        bias   same dtype as x, (C,), contiguous
        out    one-dimensional float32 of length N*C*H*W + 2*N*G (the three-segment
               packing protocol above)
        The inputs are the usual randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-group mean / biased var reduction, rsqrt, the
          per-channel affine, and Swish) must be completed inside the submitted file
          with a Triton kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt, the affine and Swish all use float32 intermediates;
          all three output segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "groupnorm", groups: int = 2, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("groupnorm", "groupnorm_swish"), "variant must be one of groupnorm / groupnorm_swish"
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.variant = variant
        self.groups = int(groups)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        n, c, h, w = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        g = self.groups
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        rep = c // g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert 1 <= g <= c and c % g == 0, "groups must divide the number of channels and 1 <= groups <= C"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        return _groupnorm_launch(x, scale, bias, n, c, h, w, g, self.eps, self.variant)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        xg = xf.reshape(n, g, -1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        mean = xg.mean(dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        var = (xg - mean.unsqueeze(-1)).pow(2).mean(dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        inv_var = torch.rsqrt(var + self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        mean_c = mean.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        inv_c = inv_var.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        sf = scale.to(torch.float32).reshape(1, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        bf = bias.to(torch.float32).reshape(1, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        gn = (xf - mean_c) * inv_c * sf + bf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        y = gn * torch.sigmoid(gn) if self.variant == "groupnorm_swish" else gn
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return torch.cat([y.reshape(-1), mean.reshape(-1), inv_var.reshape(-1)])
        # <<<END_IMPROVE>>>
