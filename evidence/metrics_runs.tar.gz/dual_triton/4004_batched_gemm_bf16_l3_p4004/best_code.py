import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _batched_tn_gemm(X, W, Bias, Out,
                     M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
                     xb: tl.constexpr, xm: tl.constexpr, xk: tl.constexpr,
                     wb: tl.constexpr, wn: tl.constexpr, wk: tl.constexpr,
                     bb: tl.constexpr, bn: tl.constexpr,
                     ob: tl.constexpr, om: tl.constexpr, on: tl.constexpr,
                     USE_BIAS: tl.constexpr,
                     BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    tile = tl.program_id(0)
    batch = tl.program_id(1)
    nt = tl.cdiv(N, BN)
    rows = (tile // nt) * BM + tl.arange(0, BM)
    cols = (tile % nt) * BN + tl.arange(0, BN)
    ks = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), dtype=tl.float32)
    for block in range(tl.cdiv(K, BK)):
        kk = block * BK + ks
        a = tl.load(X + batch * xb + rows[:, None] * xm + kk[None, :] * xk,
                    mask=(rows[:, None] < M) & (kk[None, :] < K), other=0)
        b = tl.load(W + batch * wb + cols[None, :] * wn + kk[:, None] * wk,
                    mask=(cols[None, :] < N) & (kk[:, None] < K), other=0)
        acc = tl.dot(a, b, acc)
    if USE_BIAS:
        rounded = acc.to(tl.bfloat16).to(tl.float32)
        bias = tl.load(Bias + batch * bb + cols * bn, mask=cols < N, other=0)
        result = (rounded + bias.to(tl.float32)[None, :]).to(tl.bfloat16)
    else:
        result = acc
    tl.store(Out + batch * ob + rows[:, None] * om + cols[None, :] * on,
             result.to(Out.dtype.element_ty),
             mask=(rows[:, None] < M) & (cols[None, :] < N))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Batch-dimension bf16 GEMM: computes x[b] @ weight[b]^T independently for
    every matrix in the batch.

    Mathematical definition (independent per b in the batch, B/M/N/K >= 1):
      acc[b, m, n] = sum_k x[b, m, k] * weight[b, n, k]    (float32 accumulation)
      out[b, m, n] = acc[b, m, n] + bias[b, 0, n]          (optional bias)
    weight is stored row-major as (B, N, K), so the computation is equivalent to a
    transposed GEMM (each output channel corresponds to one row of weight). The
    bias fusion order follows GEMM kernel convention: the float32 accumulated
    result is first cast to the input dtype (bfloat16), bias is then added
    (bfloat16 arithmetic), and finally the result is cast to the output dtype. With
    no bias it is cast directly. Boundary behaviour: B/M/N/K may be any value >= 1
    (including the minimal 1x1x1 size) and the dimensions may be
    non-powers-of-two, with no alignment requirement on any of them.

    Input/output specification:
      x      bfloat16  (B, M, K)  the activation matrix
      weight bfloat16  (B, N, K)  the weight matrix (row-major, transposed-GEMM semantics)
      bias   bfloat16  (B, 1, N)  optional; when use_bias=False a placeholder tensor is
                                  passed and ignored
      out    output dtype (B, M, N), where the dtype is set by __init__'s out_dtype
                                  (bfloat16 / float16)

    Implementation constraints (violations are scored as failures):
      - The core computation (the bf16 GEMM multiply-accumulate and the bias fusion)
        must be completed inside the submitted file; calling torch.matmul /
        torch.bmm / torch.mm / torch.addmm / torch.baddbmm / torch.einsum /
        F.linear / functional.linear / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; the bias branch follows the fusion
        order above; cast the output to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward; the input
        values (small integer codes and values representable in bfloat16) are all
        exactly representable in fp32, so .to(torch.bfloat16) at the entry point
        recovers them losslessly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: TN layout (x row-major (B,M,K), weight row-major (B,N,K)), no
    split-K, no quantization component at all (pure bf16 inputs, no scale
    dequantization).
    """
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.to(torch.bfloat16)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        weight = weight.to(torch.bfloat16)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        bias = bias.to(torch.bfloat16) if self.use_bias else None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        B, M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = weight.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == weight.shape[2], "x and weight must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        acc = torch.empty((B, M, N), device=x.device, dtype=self.out_dtype)
        bias_ptr = bias if bias is not None else acc
        bias_batch_stride = bias.stride(0) if bias is not None else 0
        bias_col_stride = bias.stride(2) if bias is not None else 0
        _batched_tn_gemm[(triton.cdiv(M, 32) * triton.cdiv(N, 64), B)](
            x, weight, bias_ptr, acc, M, N, K,
            *x.stride(), *weight.stride(),
            bias_batch_stride, bias_col_stride, *acc.stride(),
            USE_BIAS=self.use_bias, BM=32, BN=64, BK=32,
            num_warps=4, num_stages=2,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # Bias and both required bf16 rounding steps are fused in the Triton epilogue.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        return acc
        # <<<END_IMPROVE>>>
