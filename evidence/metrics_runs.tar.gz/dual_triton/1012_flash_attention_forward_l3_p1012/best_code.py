import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _varlen_attention_kernel(
    q_ptr, k_ptr, v_ptr, o_ptr,
    cuq_ptr, cuk_ptr, causal_ptr,
    sm_scale, group, head_dim,
    sq0, sq1, sq2, sk0, sk1, sk2, sv0, sv1, sv2, so0, so1, so2,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_D: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_h = tl.program_id(1)
    pid_b = tl.program_id(2)

    q_begin = tl.load(cuq_ptr + pid_b)
    q_end = tl.load(cuq_ptr + pid_b + 1)
    k_begin = tl.load(cuk_ptr + pid_b)
    k_end = tl.load(cuk_ptr + pid_b + 1)
    seq_len_q = q_end - q_begin
    seq_len_k = k_end - k_begin
    q_tile_begin = pid_m * BLOCK_M
    if q_tile_begin >= seq_len_q:
        return

    offs_m = q_tile_begin + tl.arange(0, BLOCK_M)
    offs_d = tl.arange(0, BLOCK_D)
    q_pos = q_begin + offs_m
    q_mask = offs_m < seq_len_q
    q_offsets = q_pos[:, None] * sq0 + pid_h * sq1 + offs_d[None, :] * sq2
    qv = tl.load(
        q_ptr + q_offsets,
        mask=q_mask[:, None] & (offs_d[None, :] < head_dim),
        other=0.0,
    ).to(tl.float32)

    m_i = tl.full([BLOCK_M], -float("inf"), tl.float32)
    l_i = tl.zeros([BLOCK_M], tl.float32)
    acc = tl.zeros([BLOCK_M, BLOCK_D], tl.float32)
    kv_head = pid_h // group
    causal_value = tl.load(causal_ptr)
    q_tile_end = tl.minimum(q_tile_begin + BLOCK_M, seq_len_q)
    causal_key_limit = tl.minimum(seq_len_k, q_tile_end + seq_len_k - seq_len_q)
    key_limit = tl.where(causal_value != 0, causal_key_limit, seq_len_k)

    for start_n in tl.range(0, key_limit, BLOCK_N):
        offs_n = start_n + tl.arange(0, BLOCK_N)
        k_pos = k_begin + offs_n
        k_mask = offs_n < seq_len_k
        kv_offsets = k_pos[:, None] * sk0 + kv_head * sk1 + offs_d[None, :] * sk2
        kk = tl.load(
            k_ptr + kv_offsets,
            mask=k_mask[:, None] & (offs_d[None, :] < head_dim),
            other=0.0,
        ).to(tl.float32)
        vv = tl.load(
            v_ptr + (k_pos[:, None] * sv0 + kv_head * sv1 + offs_d[None, :] * sv2),
            mask=k_mask[:, None] & (offs_d[None, :] < head_dim),
            other=0.0,
        ).to(tl.float32)

        scores = tl.dot(qv, tl.trans(kk), input_precision="ieee") * sm_scale
        causal_mask = offs_n[None, :] <= (offs_m[:, None] + seq_len_k - seq_len_q)
        valid = q_mask[:, None] & k_mask[None, :] & ((causal_value == 0) | causal_mask)
        scores = tl.where(valid, scores, -float("inf"))

        m_ij = tl.max(scores, axis=1)
        m_new = tl.maximum(m_i, m_ij)
        m_old_safe = tl.where(m_i == -float("inf"), 0.0, m_i)
        m_new_safe = tl.where(m_new == -float("inf"), 0.0, m_new)
        alpha = tl.exp(m_old_safe - m_new_safe)
        p = tl.exp(scores - m_new_safe[:, None])
        p = tl.where(valid, p, 0.0)
        l_i = l_i * alpha + tl.sum(p, axis=1)
        acc = acc * alpha[:, None] + tl.dot(p, vv, input_precision="ieee")
        m_i = m_new

    out_offsets = q_pos[:, None] * so0 + pid_h * so1 + offs_d[None, :] * so2
    result = acc / l_i[:, None]
    tl.store(
        o_ptr + out_offsets,
        result,
        mask=q_mask[:, None] & (offs_d[None, :] < head_dim),
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Variable-length (varlen) FlashAttention v2 forward pass: dense Q/K/V is
    segmented by cu_seqlens and each segment computes scaled dot-product attention
    independently, supporting MHA/GQA and a causal
    mask.

    Mathematical definition: for segment b of the batch (let
    L_q = cu_seqlens_q[b+1]-cu_seqlens_q[b],
    L_k = cu_seqlens_k[b+1]-cu_seqlens_k[b]; the task constrains 0 < L_q <= L_k, and
    g = num_q_heads // num_kv_heads):
      scores[h,i,j] = sm_scale * <q[start_q+i,h,:], k[start_k+j,h//g,:]>
      with causal=1 a bottom-right-aligned causal mask is applied: positions with
      j > i + (L_k - L_q) are set to -inf (i.e. query position i only attends to key
      positions j <= i + L_k - L_q); with causal=0 no mask is applied.
      p[h,i,:] = softmax_j(scores[h,i,:])
      out[start_q+i,h,:] = sum_j p[h,i,j] * v[start_k+j,h//g,:]
    The softmax uses a numerically stable formulation; intermediates are accumulated
    in float32 and the output is cast back to the input dtype.
    Boundary behaviour: the task guarantees L_q >= 1 for every segment, so the
    softmax denominator is always positive and no row is fully masked; segments
    other than the last do not affect each other.

    Input/output specification:
      q            [total_q, num_q_heads, head_dim]  float16/bfloat16
      k, v         [total_k, num_kv_heads, head_dim] same dtype as q
      cu_seqlens_q [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_q
      cu_seqlens_k [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_k
      causal       0-dim int32 tensor, 1 = causal mask, 0 = no mask
      out          [total_q, num_q_heads, head_dim], same dtype as q
    Global constraints: num_q_heads is an integer multiple of num_kv_heads (GQA;
    equality means MHA); 1 <= head_dim <= 256; for every sequence
    0 < L_q <= L_k.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: varlen forward, non-quantized inputs, no bias/ALiBi, no dropout, no
    LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, cu_seqlens_q, cu_seqlens_k, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        cu_seqlens_q = cu_seqlens_q.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        cu_seqlens_k = cu_seqlens_k.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        is_causal = causal.to(device=q.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        nheads_q = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        nheads_k = k.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        group = nheads_q // nheads_k
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert nheads_q == nheads_k * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        num_seqs = int(cu_seqlens_q.numel()) - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        cu_seqlens_q = cu_seqlens_q.to(device=q.device, dtype=torch.int32)
        cu_seqlens_k = cu_seqlens_k.to(device=q.device, dtype=torch.int32)
        grid = (triton.cdiv(q.shape[0], 32), nheads_q, num_seqs)
        _varlen_attention_kernel[grid](
            q, k, v, out, cu_seqlens_q, cu_seqlens_k, is_causal,
            self.sm_scale, group, q.shape[2],
            q.stride(0), q.stride(1), q.stride(2),
            k.stride(0), k.stride(1), k.stride(2),
            v.stride(0), v.stride(1), v.stride(2),
            out.stride(0), out.stride(1), out.stride(2),
            BLOCK_M=32, BLOCK_N=64,
            BLOCK_D=max(16, triton.next_power_of_2(q.shape[2])),
            num_warps=4,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
