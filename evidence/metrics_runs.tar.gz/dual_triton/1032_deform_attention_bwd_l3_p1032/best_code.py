import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _analytic_bwd(V, SH, BASE, LOC, A, GO, GV, GL, GA,
                  K: tl.constexpr, Q: tl.constexpr, NH: tl.constexpr,
                  D: tl.constexpr, P: tl.constexpr, T: tl.constexpr,
                  BT: tl.constexpr, BD: tl.constexpr):
    row = tl.program_id(0)
    batch = row // (Q * NH)
    head = row % NH
    p = tl.arange(0, BT)
    c = tl.arange(0, BD)
    valid = p < T
    lev = p // P
    h = tl.load(SH + 2 * lev, valid, 1).to(tl.int32)
    w = tl.load(SH + 2 * lev + 1, valid, 1).to(tl.int32)
    base = tl.load(BASE + lev, valid, 0).to(tl.int32)
    a = tl.load(A + row * T + p, valid, -float('inf')).to(tl.float32)
    e = tl.exp(a - tl.max(a, 0))
    weight = e / tl.sum(e, 0)
    x = tl.load(LOC + (row * T + p) * 2, valid, 0).to(tl.float32) * w
    y = tl.load(LOC + (row * T + p) * 2 + 1, valid, 0).to(tl.float32) * h
    ix = tl.floor(x).to(tl.int32)
    iy = tl.floor(y).to(tl.int32)
    fx = x - ix
    fy = y - iy
    g = tl.load(GO + row * D + c, c < D, 0).to(tl.float32)
    off = ((batch * K + base + iy * w + ix) * NH + head)[:, None] * D + c[None, :]
    m00 = valid & (ix >= 0) & (ix < w) & (iy >= 0) & (iy < h)
    m01 = valid & (ix + 1 >= 0) & (ix + 1 < w) & (iy >= 0) & (iy < h)
    m10 = valid & (ix >= 0) & (ix < w) & (iy + 1 >= 0) & (iy + 1 < h)
    m11 = valid & (ix + 1 >= 0) & (ix + 1 < w) & (iy + 1 >= 0) & (iy + 1 < h)
    mask00 = m00[:, None] & (c[None, :] < D)
    mask01 = m01[:, None] & (c[None, :] < D)
    mask10 = m10[:, None] & (c[None, :] < D)
    mask11 = m11[:, None] & (c[None, :] < D)
    off01 = off + NH * D
    off10 = off + w[:, None] * NH * D
    off11 = off10 + NH * D
    v00 = tl.load(V + off, mask00, 0).to(tl.float32)
    v01 = tl.load(V + off01, mask01, 0).to(tl.float32)
    v10 = tl.load(V + off10, mask10, 0).to(tl.float32)
    v11 = tl.load(V + off11, mask11, 0).to(tl.float32)
    b00 = (1 - fy) * (1 - fx)
    b01 = (1 - fy) * fx
    b10 = fy * (1 - fx)
    b11 = fy * fx
    sample = v00 * b00[:, None] + v01 * b01[:, None] + v10 * b10[:, None] + v11 * b11[:, None]
    t = tl.sum(sample * g[None, :], 1)
    mean = tl.sum(weight * t, 0)
    da = weight * (t - mean)
    if T == 1:
        da = tl.full((BT,), 0, tl.float32)
    tl.store(GA + row * T + p, da, valid)
    dx = (1 - fy[:, None]) * (v01 - v00) + fy[:, None] * (v11 - v10)
    dy = (1 - fx[:, None]) * (v10 - v00) + fx[:, None] * (v11 - v01)
    gx = tl.sum(dx * g[None, :], 1) * weight * w
    gy = tl.sum(dy * g[None, :], 1) * weight * h
    tl.store(GL + (row * T + p) * 2, gx, valid)
    tl.store(GL + (row * T + p) * 2 + 1, gy, valid)
    wg = weight[:, None] * g[None, :]
    tl.atomic_add(GV + off, wg * b00[:, None], mask00, sem='relaxed')
    tl.atomic_add(GV + off01, wg * b01[:, None], mask01, sem='relaxed')
    tl.atomic_add(GV + off10, wg * b10[:, None], mask10, sem='relaxed')
    tl.atomic_add(GV + off11, wg * b11[:, None], mask11, sem='relaxed')


def _launch_analytic_bwd(value, spatial_shapes, level_start_index, locations, attention, grad_output):
    n, k, heads, d = value.shape
    q = locations.shape[1]
    p = locations.shape[4]
    t = locations.shape[3] * p
    gv = torch.zeros(value.shape, device=value.device, dtype=torch.float32)
    gl = torch.empty(locations.shape, device=value.device, dtype=torch.float32)
    ga = torch.empty(attention.shape, device=value.device, dtype=torch.float32)
    _analytic_bwd[(n * q * heads,)](
        value, spatial_shapes, level_start_index, locations, attention, grad_output,
        gv, gl, ga, k, q, heads, d, p, t,
        triton.next_power_of_2(t), triton.next_power_of_2(d),
        num_warps=4, enable_fp_fusion=False)
    return gv, gl, ga
# <<<END_IMPROVE>>>

def _deform_attn_forward(value_f, spatial_shapes, level_start_index,
                         sampling_locations_f, attention_weights_f):
    """Multi-scale deformable attention forward (float32, hand-written the same way as task 1031).

    Semantically identical to the reference of task 1031: coordinate expansion,
    four-corner zero-padded bilinear interpolation, softmax normalization of the
    sampling weights over the flattened (levels x points) dimension, and the
    cross-sampling-point weighted reduction. The only difference is that the floor
    path is detached first (the subgradient convention that the floor gradient is
    0 is made explicit, so the gradient only flows back through the interpolation
    fractions fx/fy); numerically it is exactly the same as the forward.
    All inputs are float32 tensors (the caller is responsible for the cast and for
    requires_grad); returns the uncast float32 output (N, Q, heads*D) for the
    gradient chain to use.
    """
    n, n_keys, num_heads, d = value_f.shape
    n_levels = spatial_shapes.shape[0]
    n_queries = sampling_locations_f.shape[1]
    n_points = sampling_locations_f.shape[4]

    # Normalize the sampling weights: flatten (levels x points) into one
    # dimension and run a numerically stable softmax
    wf = attention_weights_f.reshape(n, n_queries, num_heads,
                                     n_levels * n_points)
    wf = torch.softmax(wf, dim=-1).view(n, n_queries, num_heads,
                                        n_levels, n_points)

    n_idx = torch.arange(n, device=value_f.device).view(n, 1, 1)
    h_idx = torch.arange(num_heads, device=value_f.device).view(1, 1, num_heads)

    out = torch.zeros(n, n_queries, num_heads, d,
                      dtype=torch.float32, device=value_f.device)
    for l in range(n_levels):
        h_l = int(spatial_shapes[l, 0])
        w_l = int(spatial_shapes[l, 1])
        base = int(level_start_index[l])
        v_l = value_f[:, base: base + h_l * w_l]   # (n, H_l*W_l, heads, d)

        # normalized coordinates x level size -> real-valued sampling
        # coordinates (channel 0 along W, channel 1 along H)
        sx = sampling_locations_f[:, :, :, l, :, 0] * float(w_l)
        sy = sampling_locations_f[:, :, :, l, :, 1] * float(h_l)
        # The floor / integer-index path is treated as a constant (detached
        # explicitly); the gradient only flows back through fx/fy
        ix0 = torch.floor(sx.detach()).to(torch.long)
        iy0 = torch.floor(sy.detach()).to(torch.long)
        fx = sx - ix0.to(torch.float32)
        fy = sy - iy0.to(torch.float32)

        def corner(iy, ix, wgt):
            # Single-corner sampling: an out-of-range corner contributes 0
            # (zero padding semantics); the clamp only guards the index
            # against going out of range and is cancelled by the 0 weight
            valid = ((iy >= 0) & (iy <= h_l - 1)
                     & (ix >= 0) & (ix <= w_l - 1)).to(torch.float32)
            flat = iy.clamp(0, h_l - 1) * w_l + ix.clamp(0, w_l - 1)
            vals = v_l[n_idx, flat, h_idx]        # (n, q, heads, P, d)
            return vals * (valid * wgt).unsqueeze(-1)

        for p in range(n_points):
            iy0p, ix0p = iy0[..., p], ix0[..., p]      # (n, q, heads)
            fyp, fxp = fy[..., p], fx[..., p]
            sampled = (corner(iy0p, ix0p, (1.0 - fyp) * (1.0 - fxp))
                       + corner(iy0p, ix0p + 1, (1.0 - fyp) * fxp)
                       + corner(iy0p + 1, ix0p, fyp * (1.0 - fxp))
                       + corner(iy0p + 1, ix0p + 1, fyp * fxp))
            out = out + wf[:, :, :, l, p].unsqueeze(-1) * sampled

    return out.view(n, n_queries, num_heads * d)

class ModelNew(nn.Module):
    """
    Multi-Scale Deformable Attention Backward (deform_attn_dgrad): given the forward inputs and the upstream gradient grad_output, one call computes the gradients of value, sampling_locations and attention_weights at once.

    Forward semantics (all intermediate computation float32, the same convention
    as the companion forward task): value (N, n_keys, heads, D) is the
    concatenation of the multi-scale feature levels -- level l contributes
    spatial_shapes[l] = (H_l, W_l) keys, laid out inside the level in row-major
    order (H first, then W) over [level_start_index[l], level_start_index[l] +
    H_l*W_l), where level_start_index must be the prefix sum of the per-level
    H_l*W_l (first element 0) and n_keys = sum_l H_l*W_l. The last dimension of
    sampling_locations (N, Q, heads, L, P, 2) holds the normalized coordinates
    (x, y): channel 0 runs along W and channel 1 along H (generation domain
    [0,1)), so the actual sampling coordinates are loc_x = x * W_l and loc_y =
    y * H_l; the sampled value goes through four-corner bilinear interpolation
    (floor + the fractions fx/fy, with zero padding semantics where an
    out-of-range corner contributes 0, and no clamp / nearest-neighbour
    pull-back); attention_weights (N, Q, heads, L, P) are non-negative
    unnormalized scores, first flattened over (levels x points) into one
    dimension and normalized by a numerically stable softmax (max subtraction)
    into convex-combination weights, then used in the weighted sum against the
    interpolated value of each sampling point, producing the output o
    (N, Q, heads*D).

    Backward semantics (backpropagated through the float32 forward described
    above, at the point before the output is cast back to the value dtype;
    grad_output is first cast to float32): write dO for the float32 form of
    grad_output, w = softmax(attention_weights flattened over L*P), S_{l,p}[c] for
    the four-corner zero-padded bilinear sample of point (l,p), and
    t_{l,p} = <dO, S_{l,p}>; the three gradients are then the analytic gradients
    of o with respect to the three floating-point inputs:
      grad_value[n, key, h, c] = sum_{q, l, p} w_{l,p} * corner_weight *
                                 dO[n, q, h*D + c]
        (per-corner scatter accumulation; out-of-range corners do not scatter)
      grad_sampling_locations[n, q, h, l, p, 0] =
          sum_c dO[n, q, h*D + c] * w_{l,p} * W_l *
          ((1-fy) * (v01 - v00) + fy * (v11 - v10))
      grad_sampling_locations[n, q, h, l, p, 1] =
          sum_c dO[n, q, h*D + c] * w_{l,p} * H_l *
          ((1-fx) * (v10 - v00) + fx * (v11 - v01))
        (v00/v01/v10/v11 are the four corner pixel values of that point, with an
        out-of-range corner counted as 0; the gradient only flows back through
        the fractions fx/fy, and the floor / integer-index path has gradient 0 --
        the standard subgradient of bilinear sampling)
      grad_attention_weights[n, q, h, l, p] = w_{l,p} *
          (t_{l,p} - sum_{l', p'} w_{l',p'} * t_{l',p'})
        (softmax backprop; identically 0 when L*P = 1)
    The softmax, the interpolation, the weighted reduction and all gradient
    accumulation are done in float32, and the three gradients are each cast back
    to the value dtype and then packed into the output.

    Output contract (single tensor, one-dimensional concatenation packing, the
    segment order is fixed and must not be swapped):
      out = cat([grad_value.reshape(-1),
                 grad_sampling_locations.reshape(-1),
                 grad_attention_weights.reshape(-1)])
      a one-dimensional tensor with the same dtype as value, of length
          = n*n_keys*heads*D + n*n_queries*heads*L*P*2 + n*n_queries*heads*L*P
      segment 0 grad_value: n*n_keys*heads*D elements, (N, n_keys, heads, D)
          flattened row-major;
      segment 1 grad_sampling_locations: n*n_queries*heads*L*P*2 elements,
          (N, Q, heads, L, P, 2) flattened row-major (the (x, y) channel order of
          the last dimension is preserved);
      segment 2 grad_attention_weights: n*n_queries*heads*L*P elements,
          (N, Q, heads, L, P) flattened row-major.

    Input/output specification (all tensors contiguous):
      value              float32 / float16 (N, n_keys, heads, D)
      spatial_shapes     int64 (L, 2), each row (H_l, W_l), H_l / W_l >= 1
      level_start_index  int64 (L,), prefix sum of the per-level key counts
      sampling_locations same dtype as value (N, Q, heads, L, P, 2), generation domain [0,1)
      (with an fp16 input individual elements may round to exactly 1.0 through
       the cast; then loc_x = W_l is fully out of range, the sampled value is 0,
       and the zero padding semantics apply)
      attention_weights  same dtype as value (N, Q, heads, L, P), non-negative
      grad_output        same dtype as value (N, Q, heads*D), the upstream
                         gradient in the forward output layout, generation domain [0,1)
      out                single tensor, same dtype as value, 1-D three-segment
                         concatenation (see above)
      every dimension is an arbitrary positive integer (including 1, non-powers
      of 2, and non-16-aligned sizes; a single-level single-pixel (H_l, W_l) =
      (1, 1), 1xN / Nx1 thin-strip levels, Q=1, P=1 and L=1 are all legal
      boundaries, and when L*P=1 grad_attention_weights is identically 0). The
      evaluator casts every input to fp32 before passing it in (lossless for both
      the low precision and the int64 indices -- an index value <= 2^24 is exactly
      representable in fp32), so the implementation must restore
      spatial_shapes / level_start_index to integer indices before using them.

    Implementation constraints (violations are scored as failures):
      - The core computation (softmax backprop, the four-corner gradient scatter
        with the partial derivatives of the interpolation fractions, and the
        cross-query grad_value scatter accumulation) must be hand-written as a HIP
        kernel inside the submitted file.
      - Using torch.autograd / autograd.grad / .backward() to backpropagate for the
        gradients is forbidden; the gradients must be hand-written from the
        analytic formulas above.
      - All gradient accumulation is done in float32; the three gradient segments
        are cast back to the value dtype and concatenated in the segment order
        above; forward returns the single tensor out (the evaluator compares a
        single output).
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden list: torchvision (including ready-made deformable attention /
    deformable convolution primitives such as torchvision.ops.ms_deform_attn),
    mmcv, miopen, hipdnn, aiter,
    torch.nn.functional.grid_sample (F.grid_sample),
    torch.nn.functional.interpolate (F.interpolate), torch.matmul /
    torch.bmm / torch.mm / torch.einsum / torch.tensordot,
    torch.softmax / torch.nn.functional.softmax (F.softmax),
    torch.autograd (including autograd.grad), .backward().
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, value, spatial_shapes, level_start_index, sampling_locations, attention_weights, grad_output):
        # <<<IMPROVE:forward_stmt_1>>>
        # Pass spatial_shapes unchanged; Triton loads convert dimensions to int32.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Pass level_start_index unchanged; Triton loads convert starts to int32.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        n, n_keys, num_heads, d = value.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        n_levels = spatial_shapes.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_queries = sampling_locations.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_points = sampling_locations.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert sampling_locations.dim() == 6 \
            and sampling_locations.shape[2] == num_heads \
            and sampling_locations.shape[3] == n_levels \
            and sampling_locations.shape[5] == 2, \
            "sampling_locations must be (N, Q, heads, L, P, 2)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert attention_weights.shape == (n, n_queries, num_heads, n_levels, n_points), \
            "attention_weights must be (N, Q, heads, L, P)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # The input contract guarantees n_keys equals the sum of level areas.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert grad_output.shape == (n, n_queries, num_heads * d), \
            "grad_output must be (N, Q, heads*D)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        vg = value
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        lg = sampling_locations
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        ag = attention_weights
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        grad_value, grad_sampling_loc, grad_attn_weight = _launch_analytic_bwd(
            vg, spatial_shapes, level_start_index, lg, ag, grad_output)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # All three gradients were computed analytically by the Triton launch.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return torch.cat([grad_value.to(value.dtype).reshape(-1),
                          grad_sampling_loc.to(value.dtype).reshape(-1),
                          grad_attn_weight.to(value.dtype).reshape(-1)])
        # <<<END_IMPROVE>>>
