import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _qk_fused(QN, QP, KN, KP, Pos, Cos, Sin, Out,
              QH: tl.constexpr, KH: tl.constexpr, DN: tl.constexpr,
              DP: tl.constexpr, DF: tl.constexpr, NEOX: tl.constexpr,
              ROPE: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    b = row // (QH + KH)
    h = row % (QH + KH)
    if h < QH:
        nptr = QN + (b * QH + h) * DN
        pptr = QP + (b * QH + h) * DP
    else:
        nptr = KN + (b * KH + h - QH) * DN
        pptr = KP + (b * KH + h - QH) * DP
    f = tl.program_id(1) * BLOCK + tl.arange(0, BLOCK)
    n = tl.load(nptr + f, mask=f < DN, other=0)
    dst = Out + row * (DN + DP) + f
    tl.store(dst, n, mask=f < DN)
    i = f - DN
    pm = (i >= 0) & (i < DP)
    x = tl.load(pptr + i, mask=pm, other=0)
    if ROPE:
        position = tl.load(Pos + b).to(tl.int64)
        if NEOX:
            negative = i < DP // 2
            partner = tl.where(negative, i + DP // 2, i - DP // 2)
        else:
            negative = (i % 2) == 0
            partner = i ^ 1
        y = tl.load(pptr + partner, mask=pm, other=0).to(tl.float32)
        y = tl.where(negative, -y, y)
        if DF == DP:
            freq = i
        elif NEOX:
            freq = i % (DP // 2)
        else:
            freq = i // 2
        c = tl.load(Cos + position * DF + freq, mask=pm, other=0).to(tl.float32)
        s = tl.load(Sin + position * DF + freq, mask=pm, other=0).to(tl.float32)
        result = x.to(tl.float32) * c + y * s
        tl.store(dst, result, mask=pm)
    else:
        tl.store(dst, x, mask=pm)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """MLA-style QK preprocessing fused operator: rotary position embedding (RoPE)
    on the pe segment plus nope/pe concatenation.

    (1) Operator semantics (mathematical definition and boundary behaviour):
    The Q side takes q_nope [B, QH, D_nope] and q_pe [B, QH, D_pe]; the K side takes
    k_nope [B, KH, D_nope] and k_pe [B, KH, D_pe]. QH must be an integer multiple of
    KH (GQA; write QH_PER_KH = QH // KH) and D_pe must be even. The output is packed
    into a single tensor out [B, QH + KH, D_nope + D_pe]: along the head dimension
    the first QH rows are the Q result and the last KH rows are the K result (each
    KV head is computed and written back only once, i.e. the GQA deduplicated
    write-back semantics).

    The nope segment is copied verbatim: out[:, :QH, :D_nope] = q_nope,
    out[:, QH:, :D_nope] = k_nope. The pe segment (x means q_pe or k_pe, promoted to
    float32 before the computation):
    - apply_rope=False (pure concatenation mode): out[..., D_nope:] = x copied
      verbatim; pos / cos / sin are ignored;
    - apply_rope=True (rope mode): for each batch b take c = cos[pos[b]] and
      s = sin[pos[b]] (width d_freq; d_freq == D_pe is the full-width table,
      d_freq == D_pe//2 is the first-half reuse table), and expand to width D_pe
      according to the rotation style:
        full width: c~ = c;
        first-half reuse + NEOX: c~ = [c, c] (the whole segment repeated once; both
          halves share the same frequency);
        first-half reuse + GPTJ: c~ = [c0, c0, c1, c1, ...] (every element repeated
          twice back to back).
      rotate_half(x) is defined as:
        NEOX (is_neox=True): rotate_half(x)[i] = -x[i + D_pe//2]
          (i < D_pe//2), = x[i - D_pe//2] (i >= D_pe//2);
        GPTJ (is_neox=False): rotate_half(x)[2j] = -x[2j+1],
          rotate_half(x)[2j+1] = x[2j].
      pe segment output = x * c~ + rotate_half(x) * s~, cast back to the input dtype.
    Boundary behaviour: pos[b] is in [0, max_pos) (out of range is undefined
    behaviour); this operator is a memory-bound preprocessing step and computes no
    attention score; the nope segment and the pe segment in pure concatenation mode
    are verbatim copies and must match bit-for-bit; the whole forward is out-of-place
    and must not overwrite any input in place.

    (2) Input/output specification:
    - q_nope / q_pe / k_nope / k_pe: float16 / bfloat16, contiguous, shapes as above
      (QH == KH * QH_PER_KH, one shared batch for all four tensors);
    - pos: int64, [B], one position index per batch (it is cast to floating point
      under the evaluation precision and restored to integer losslessly at the
      entry);
    - cos / sin: same dtype as the data, [max_pos, d_freq], contiguous, used only
      through the row-style indexing cos[pos[b], d];
    - returns: out [B, QH + KH, D_nope + D_pe] with the same dtype as q_nope;
    - hyper-parameters (__init__): is_neox -- True selects the NEOX rotation style /
      False selects GPTJ; apply_rope -- True rotates the pe segment / False pure
      concatenation.

    (3) Implementation constraints (violations are scored as failures):
    - The core computation (row indexing of cos/sin by position, rotation of the pe
      segment, the nope/pe concatenated write-back, and the K-side deduplication
      under GQA) must be completed inside the submitted file with a self-written
      Triton kernel: a single kernel (one launch) with a single
      read-compute-write pass;
    - The __init__ and forward signatures of ModelNew must not be changed;
    - Use float32 for intermediate computation; cast the output back to the input
      dtype.

    (4) Forbidden list and target hardware:
    - Calling ATen shortcuts such as torch.cat / torch.concat (including the tensor
      method .cat) or index_select to complete this task's computation directly is
      forbidden; the authoritative forbidden list is the task.yaml forbidden list
      (it covers the source operator library and other closed-source acceleration
      libraries; the final static audit does substring matching on the code outside
      docstrings / comments);
    - Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, is_neox: bool = True, apply_rope: bool = True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.is_neox = bool(is_neox)
        self.apply_rope = bool(apply_rope)
        # <<<END_IMPROVE>>>

    def forward(self, q_nope, q_pe, k_nope, k_pe, pos, cos, sin):
        # <<<IMPROVE:forward_stmt_1>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        B, QH, D_nope = q_nope.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        KH = k_nope.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        D_pe = q_pe.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        assert q_pe.shape[0] == B and k_nope.shape[0] == k_pe.shape[0] == B, "the batch dimension must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert q_pe.shape[1] == QH and k_pe.shape[1] == KH, "the head counts of Q and K must each match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert k_nope.shape[2] == D_nope and k_pe.shape[2] == D_pe, "the D_nope and D_pe of q and k must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert QH % KH == 0, "QH must be an integer multiple of KH (GQA)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert D_pe % 2 == 0, "D_pe must be even (half-width rotation)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty((B, QH + KH, D_nope + D_pe), dtype=q_nope.dtype, device=q_nope.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        d_freq = cos.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        assert d_freq in (D_pe, D_pe // 2), "the cos/sin width must be D_pe or D_pe//2"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        _qk_fused[(B * (QH + KH), triton.cdiv(D_nope + D_pe, 256))](
            q_nope, q_pe, k_nope, k_pe, pos, cos, sin, out,
            QH, KH, D_nope, D_pe, d_freq, self.is_neox, self.apply_rope,
            BLOCK=256, num_warps=4, enable_fp_fusion=False,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        return out
        # <<<END_IMPROVE>>>
