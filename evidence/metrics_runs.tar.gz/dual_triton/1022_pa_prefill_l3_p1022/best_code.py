import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _paged_prefill(Q, K, V, KC, VC, BT, QS, SL, A, O,
                   SQ0: tl.constexpr, SQ1: tl.constexpr, SQ2: tl.constexpr,
                   SK0: tl.constexpr, SK1: tl.constexpr, SK2: tl.constexpr,
                   SV0: tl.constexpr, SV1: tl.constexpr, SV2: tl.constexpr,
                   SC0: tl.constexpr, SC1: tl.constexpr, SC2: tl.constexpr,
                   SC3: tl.constexpr, SC4: tl.constexpr,
                   SW0: tl.constexpr, SW1: tl.constexpr, SW2: tl.constexpr, SW3: tl.constexpr,
                   ST0: tl.constexpr, ST1: tl.constexpr,
                   SO0: tl.constexpr, SO1: tl.constexpr, SO2: tl.constexpr,
                   D: tl.constexpr, BD: tl.constexpr,
                   BS: tl.constexpr, X: tl.constexpr, G: tl.constexpr,
                   SCALE: tl.constexpr, HAS_A: tl.constexpr):
    tile = tl.program_id(0)
    h = tl.program_id(1)
    b = tl.program_id(2)
    start = tl.load(QS + b)
    length = tl.load(QS + b + 1) - start
    ctx = tl.load(SL + b) - length
    if tile * 16 >= length:
        return
    r = tile * 16 + tl.arange(0, 16)
    d = tl.arange(0, BD)
    n = tl.arange(0, 32)
    kh = h // G
    q = tl.load(Q + (start + r[:, None]) * SQ0 + h * SQ1 + d[None, :] * SQ2, (r[:, None] < length) & (d[None, :] < D), 0)
    slope = 0.0
    if HAS_A:
        slope = tl.load(A + h)
    m = tl.full((16,), float('-inf'), tl.float32)
    z = tl.zeros((16,), tl.float32)
    acc = tl.zeros((16, BD), tl.float32)
    for phase in tl.static_range(2):
        if phase == 0:
            limit = ctx
        else:
            limit = tl.minimum(length, tile * 16 + 16)
        for base in range(0, limit, 32):
            t = base + n
            if phase == 0:
                page = tl.load(BT + b * ST0 + (t // BS) * ST1, t < ctx, 0)
                kp = KC + page[None, :] * SC0 + kh * SC1 + (d[:, None] // X) * SC2 + (t[None, :] % BS) * SC3 + (d[:, None] % X) * SC4
                vp = VC + page[:, None] * SW0 + kh * SW1 + d[None, :] * SW2 + (t[:, None] % BS) * SW3
                k = tl.load(kp, (t[None, :] < ctx) & (d[:, None] < D), 0)
                v = tl.load(vp, (t[:, None] < ctx) & (d[None, :] < D), 0)
                pos = t
                valid = t[None, :] < ctx
            else:
                kp = K + (start + t[None, :]) * SK0 + kh * SK1 + d[:, None] * SK2
                vp = V + (start + t[:, None]) * SV0 + kh * SV1 + d[None, :] * SV2
                k = tl.load(kp, (t[None, :] < limit) & (d[:, None] < D), 0)
                v = tl.load(vp, (t[:, None] < limit) & (d[None, :] < D), 0)
                pos = ctx + t
                valid = (t[None, :] < length) & (t[None, :] <= r[:, None])
            scores = tl.dot(q, k).to(tl.float32) * SCALE
            if HAS_A:
                scores += slope * (pos[None, :] - ctx - r[:, None]).to(tl.float32)
            scores = tl.where(valid, scores, float('-inf'))
            nm = tl.maximum(m, tl.max(scores, 1))
            safe = tl.where(nm == float('-inf'), 0.0, nm)
            alpha = tl.exp(m - safe)
            p = tl.exp(scores - safe[:, None])
            z = z * alpha + tl.sum(p, 1)
            acc = acc * alpha[:, None] + tl.dot(p.to(v.dtype), v)
            m = nm
    result = acc / z[:, None]
    tl.store(O + (start + r[:, None]) * SO0 + h * SO1 + d[None, :] * SO2, result, (r[:, None] < length) & (d[None, :] < D))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Paged KV prefix (context) attention: attention for prefill multi-token queries.

    (MHA/GQA, causal + optional ALiBi.)

    Within a batch, num_seqs sequences run in parallel; sequence b has
    query_len[b] = query_start_loc[b+1] - query_start_loc[b] newly computed query
    tokens in this round, and the slices of all sequences are flattened and
    concatenated along the token dimension in query_start_loc order (no
    padding). The current total length of the sequence is seq_lens[b], of which
    the first ctx_len[b] = seq_lens[b] - query_len[b] tokens are the already
    admitted prefix K/V, stored only in the paged KV cache; the K/V of the new
    tokens of this round are given explicitly only as key / value (the cache
    does not contain the new tokens). query_len[b] > 1 means prefill, and == 1
    is also legal (a single-token query against the pure prefix).

    Paged layout: the physical block pool has num_blocks blocks, each holding
    block_size token slots; block_tables[b] is the "prefix logical block ->
    physical block id" table of that sequence, where only the first
    ceil(ctx_len[b]/block_size) columns are valid (the remaining columns are
    garbage). K uses the channel-packed layout: the K channel d of the l-th
    prefix token is stored at
    key_cache[bt[b, l//block_size], h_kv, d//x, l%block_size, d%x]
    (x = 8, head_size is a multiple of 8); V is stored at
    value_cache[bt[b, l//block_size], h_kv, d, l%block_size]. Blocks in the pool
    that are not referenced, as well as slots beyond the prefix length inside
    referenced blocks, are garbage data (magnitudes up to +/-10) and must not
    participate in the computation.

    For the j-th new token of the h-th query head of sequence b (the
    corresponding KV head is h // query_group_size, query_group_size =
    num_heads / num_kv_heads), at in-sequence absolute position pos =
    ctx_len[b] + j:

      logits[l] = scale * <query[pos, h, :], K[l]> + alibi_slopes[h] * (l - pos)
      causal mask: logits at positions l > pos are set to -inf
      p[l] = exp(logits[l] - max_l' logits[l']) / sum_l' exp(logits[l'] - max_l' logits[l'])
      out[pos, h, :] = sum_{l = 0..pos} p[l] * V[l]

    where K[l] / V[l]: for l < ctx_len[b] they come from the paged cache
    (indirect addressing through the block table), and for l >= ctx_len[b] they
    come from key / value. When alibi_slopes is None no bias term is added (it
    degenerates to the unbiased baseline); when a float32 [num_heads] tensor is
    given, the ALiBi bias is added as in the formula above (the bias is 0 at
    l == pos). The softmax uses an online (numerically stable) implementation,
    intermediate accumulation is in float32, and the output is cast back to the
    input dtype.

    Input/output specification (forward parameter order):
      query           [num_tokens, num_heads, head_size]                    fp16/bf16
      key             [num_tokens, num_kv_heads, head_size]                 same as query
      value           [num_tokens, num_kv_heads, head_size]                 same as query
      key_cache       [num_blocks, num_kv_heads, head_size//8, block_size, 8]   same as query
      value_cache     [num_blocks, num_kv_heads, head_size, block_size]         same as query
      block_tables    [num_seqs, max_blocks_per_seq]                         int32
      query_start_loc [num_seqs+1] int32 (prefix sum of query_len, first element 0)
      seq_lens        [num_seqs] int32
      alibi_slopes    [num_heads] float32, or None (no ALiBi bias)
      returns out     [num_tokens, num_heads, head_size], dtype same as query.
      scale defaults to 1/sqrt(head_size) (given by head_size in __init__).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        torch.matmul / torch.bmm / torch.einsum / torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: prefill multi-token queries, non-quantized KV; includes the ALiBi
    bias variant and the unbiased baseline (alibi_slopes passed as None); does
    not include sliding window, does not include a quantized KV cache, and the
    K/V of the new tokens of this round are not written into the cache.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens, alibi_slopes=None):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        query_start_loc = query_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        slopes = None if alibi_slopes is None else alibi_slopes.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        num_tokens, num_heads, head_size = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_kv_heads = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        block_size = value_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        x = key_cache.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        group = num_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert num_heads == num_kv_heads * group, "num_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        assert head_size == (head_size // x) * x, "head_size must be an integer multiple of x"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        _paged_prefill[(triton.cdiv(num_tokens, 16), num_heads, seq_lens.shape[0])](
            query, key, value, key_cache, value_cache, block_tables,
            query_start_loc, seq_lens, slopes if slopes is not None else query, out,
            *query.stride(), *key.stride(), *value.stride(), *key_cache.stride(),
            *value_cache.stride(), *block_tables.stride(), *out.stride(),
            head_size, triton.next_power_of_2(head_size), block_size, x, group,
            self.scale, slopes is not None, num_warps=4, num_stages=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return out
        # <<<END_IMPROVE>>>
