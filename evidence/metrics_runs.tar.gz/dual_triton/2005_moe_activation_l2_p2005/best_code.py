import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl
import triton.language.extra.libdevice as libdevice


@triton.jit
def _activation_kernel(X, Y, COUNT: tl.constexpr, N: tl.constexpr,
                       ACT: tl.constexpr, GATED: tl.constexpr,
                       ALPHA: tl.constexpr, LIMIT: tl.constexpr,
                       BLOCK: tl.constexpr):
    q = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    mask = q < COUNT
    if GATED:
        if ACT == "swiglu_interleaved":
            gi = 2 * q
            ui = gi + 1
        else:
            gi = (q // N) * (2 * N) + q % N
            ui = gi + N
        g = tl.load(X + gi, mask, other=0).to(tl.float32)
        u = tl.load(X + ui, mask, other=0).to(tl.float32)
    else:
        g = tl.load(X + q, mask, other=0).to(tl.float32)

    if ACT == "gelu" or ACT == "gelu_no_mul":
        a = (0.5 * g) * (1.0 + libdevice.erf(g * 0.7071067811865476))
    elif ACT == "gelu_tanh" or ACT == "gelu_tanh_no_mul":
        inner = 0.7978845608028654 * (g + ((0.044715 * g) * g) * g)
        a = (0.5 * g) * (1.0 + libdevice.tanh(inner))
    elif ACT == "relu2":
        r = tl.maximum(g, 0.0)
        a = r * r
    elif ACT == "swiglustep":
        a = g * (1.0 / (1.0 + tl.exp(-g)))
        a = tl.minimum(a, LIMIT)
        u = tl.minimum(tl.maximum(u, -LIMIT), LIMIT)
    else:
        if GATED and LIMIT is not None:
            g = tl.minimum(g, LIMIT)
            u = tl.minimum(tl.maximum(u, -LIMIT), LIMIT)
        if GATED and ALPHA is not None:
            z = ALPHA * g
            u = u + 1.0
        else:
            z = g
        a = g * (1.0 / (1.0 + tl.exp(-z)))
    if GATED:
        a = a * u
    tl.store(Y + q, a, mask)


def _launch_activation(x, activation, is_gated, alpha, limit):
    m, width = x.shape
    n = width // 2 if is_gated else width
    out = torch.empty((m, n), dtype=x.dtype, device=x.device)
    count = m * n
    block = 512 if count >= 4096 else 256
    warps = 8 if count >= 4096 else 4
    _activation_kernel[(triton.cdiv(count, block),)](
        x, out, count, n, activation, is_gated,
        alpha if is_gated else None, limit if is_gated else None,
        block, num_warps=warps, enable_fp_fusion=False)
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """MoE FFN activation variant family: gated activations (SwiGLU family
    variants) and non-gated element-wise activations, dispatched by the __init__
    parameters activation / alpha / limit.

    All computation runs in float32 and the output is cast back to the input dtype.
    Define
        SiLU(u)      = u * sigmoid(u)
        GELU(u)      = 0.5 * u * (1 + erf(u * 0.7071067811865476))
        GELU_tanh(u) = 0.5 * u * (1 + tanh(0.7978845608028654
                                           * (u + 0.044715 * u^3)))
        ReLU2(u)     = max(u, 0)^2
    sigmoid / erf / tanh are all evaluated as float32 math functions.

    [gated variants] The input x has shape (M, 2N) and the output (M, N). Two data
    layouts:
        chunked (default) : gate = x[:, :N], up = x[:, N:]
        interleaved       : gate = x[:, 0::2] (even columns), up = x[:, 1::2] (odd
                            columns)
    Write the clamped quantities as gate' = min(gate, limit) (upper bound only) and
    up' = clamp(up, -limit, limit) (symmetric clamping); the output of each variant
    is:
        activation="silu", alpha=None, limit=None:
            out = SiLU(gate) * up                        (standard SwiGLU)
        activation="silu", alpha=None, limit=L:
            out = SiLU(gate') * up'                       (clamped SwiGLU)
        activation="silu", alpha=A, limit=L (A and L must be given together):
            out = gate' * sigmoid(A * gate') * (up' + 1)  (scaled clamped gate)
        activation="gelu" (does not accept alpha / limit):
            out = GELU(gate) * up
        activation="gelu_tanh" (does not accept alpha / limit):
            out = GELU_tanh(gate) * up
        activation="swiglustep" (limit defaults to 7.0, does not accept alpha):
            out = clamp(SiLU(gate), max=limit) * up'      (SiLU first, then the
                                                           upper clamp)
        activation="swiglu_interleaved" (interleaved layout; alpha defaults to
        1.702, limit defaults to 7.0):
            out = gate' * sigmoid(alpha * gate') * (up' + 1)

    [non-gated variants] The input x has shape (M, N) and the output (M, N);
    element-wise activation, alpha / limit are ignored:
        activation="silu_no_mul"      : out = SiLU(x)
        activation="gelu_no_mul"      : out = GELU(x)
        activation="gelu_tanh_no_mul" : out = GELU_tanh(x)
        activation="relu2"            : out = ReLU2(x)

    Boundary behaviour: clamping of gate is upper-bound only (nothing is clamped on
    the negative side) while clamping of up is symmetric; the clamping is applied
    before the activation, except for swiglustep, which computes SiLU first and then
    clamps the result on the upper side. Illegal parameter combinations (an unknown
    variant name; gelu / gelu_tanh with alpha or limit; swiglustep with alpha; silu
    given alpha but not limit) are rejected at construction time.

    Input/output specification:
        x    float16 / bfloat16 (M, n), contiguous, M >= 1; the gated variants
             require n to be even (N = n/2 has no alignment constraint: non-powers
             of two and sizes below the common block size are allowed); the
             non-gated variants accept any n >= 1. The evaluator casts the input to
             fp32 before passing it in; fp16/bf16 -> fp32 is lossless.
        out  same dtype as x; shape (M, n/2) for the gated variants and (M, n) for
             the non-gated ones.
        The input value range is the usual randn magnitude (no inf/NaN).

    Implementation constraints (violations are scored as failures):
        - The core computation (chunked / interleaved data selection, clamping,
          activation, gated multiply) must be completed with a Triton kernel inside
          the submitted file; intermediates are always float32.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate accumulation; cast the output back to the
          input dtype.

    (4) Forbidden list and target hardware:
    - Calling ATen shortcuts such as torch.nn.functional.silu /
      torch.nn.functional.gelu / torch.nn.SiLU / torch.nn.GELU / torch.sigmoid /
      torch.erf / torch.tanh / torch.relu / torch.clamp to complete this task's
      computation directly is forbidden; the authoritative forbidden list is the
      task.yaml forbidden list (it covers the source operator library and other
      closed-source acceleration libraries; the final static audit does substring
      matching on the code outside docstrings / comments);
    - Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, activation: str = "silu", alpha=None, limit=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        import sys
        gated = ("silu", "gelu", "gelu_tanh", "swiglustep", "swiglu_interleaved")
        nomul = ("silu_no_mul", "gelu_no_mul", "gelu_tanh_no_mul", "relu2")
        name = sys.intern(str(activation).lower())
        assert name in gated or name in nomul, (
            "activation must be one of " + "/".join(gated + nomul) + " variants")
        if name in ("gelu", "gelu_tanh"):
            assert alpha is None and limit is None, "gelu / gelu_tanh do not accept alpha / limit"
        if name == "swiglustep":
            assert alpha is None, "swiglustep does not accept alpha"
        if name == "silu" and alpha is not None:
            assert limit is not None, "silu must set limit as well when alpha is set"
        if name == "swiglustep" and limit is None:
            limit = 7.0
        if name == "swiglu_interleaved":
            alpha = 1.702 if alpha is None else alpha
            limit = 7.0 if limit is None else limit
        self.activation = name
        self.is_gated = name in gated
        self.alpha = None if alpha is None else float(alpha)
        self.limit = None if limit is None else float(limit)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        xf = x
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert xf.dim() == 2, "the input must be a 2D (M, n) tensor"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        if not self.is_gated:
                    return _launch_activation(x, self.activation, False, self.alpha, self.limit)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert xf.shape[-1] % 2 == 0, "the gated variants require the last dimension n to be even"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        half = xf.shape[-1] // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        interleaved = self.activation == "swiglu_interleaved"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # Gate addressing is performed inside Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # Up addressing is performed inside Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # The fused kernel applies the post-SiLU clamp for swiglustep.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # Scaled SiLU is implemented in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Clamped SiLU is implemented in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Standard SiLU is implemented in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Exact GELU is implemented in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # Tanh GELU is implemented in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # Interleaved activation is implemented in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return _launch_activation(x, self.activation, True, self.alpha, self.limit)
        # <<<END_IMPROVE>>>
