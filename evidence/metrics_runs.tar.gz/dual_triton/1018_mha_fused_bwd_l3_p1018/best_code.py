import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _products(Q, K, V, O, P, T, M:tl.constexpr, N:tl.constexpr, H:tl.constexpr, J:tl.constexpr, D:tl.constexpr, S:tl.constexpr, Q0:tl.constexpr, Q1:tl.constexpr, Q2:tl.constexpr, Q3:tl.constexpr, K0:tl.constexpr, K1:tl.constexpr, K2:tl.constexpr, K3:tl.constexpr, V0:tl.constexpr, V1:tl.constexpr, V2:tl.constexpr, V3:tl.constexpr, O0:tl.constexpr, O1:tl.constexpr, O2:tl.constexpr, O3:tl.constexpr):
    i = tl.program_id(0)*32 + tl.arange(0,32)
    j = tl.program_id(1)*32 + tl.arange(0,32)
    bh = tl.program_id(2)
    b = bh//H
    h = bh%H
    kh = h//(H//J)
    r = tl.arange(0,32)
    a = tl.full((32,32),0,tl.float32)
    c = tl.full((32,32),0,tl.float32)
    for start in range(tl.cdiv(D,32)):
        d = start*32+r
        q = tl.load(Q+b*Q0+i[:,None]*Q1+h*Q2+d[None,:]*Q3,(i[:,None]<M)&(d[None,:]<D),0).to(tl.float32)
        o = tl.load(O+b*O0+i[:,None]*O1+h*O2+d[None,:]*O3,(i[:,None]<M)&(d[None,:]<D),0).to(tl.float32)
        k = tl.load(K+b*K0+j[None,:]*K1+kh*K2+d[:,None]*K3,(j[None,:]<N)&(d[:,None]<D),0).to(tl.float32)
        v = tl.load(V+b*V0+j[None,:]*V1+kh*V2+d[:,None]*V3,(j[None,:]<N)&(d[:,None]<D),0).to(tl.float32)
        a += tl.dot(q,k,input_precision='ieee')
        c += tl.dot(o,v,input_precision='ieee')
    off = (bh*M+i[:,None])*N+j[None,:]
    mask = (i[:,None]<M)&(j[None,:]<N)
    tl.store(P+off,a*S,mask)
    tl.store(T+off,c,mask)

@triton.jit
def _normalize(P,T,N:tl.constexpr):
    row = tl.program_id(0)
    r = tl.arange(0,256)
    mx = tl.full((256,),float('-inf'),tl.float32)
    for start in range(tl.cdiv(N,256)):
        j = start*256+r
        s = tl.load(P+row*N+j,j<N,float('-inf'))
        mx = tl.maximum(mx,s)
    maximum = tl.max(mx,0)
    den = tl.full((256,),0,tl.float32)
    weighted = tl.full((256,),0,tl.float32)
    for start in range(tl.cdiv(N,256)):
        j = start*256+r
        s = tl.load(P+row*N+j,j<N,float('-inf'))
        dp = tl.load(T+row*N+j,j<N,0)
        e = tl.exp(s-maximum)
        den += e
        weighted += e*dp
    denom = tl.sum(den,0)
    delta = tl.sum(weighted,0)/denom
    for start in range(tl.cdiv(N,256)):
        j = start*256+r
        s = tl.load(P+row*N+j,j<N,float('-inf'))
        dp = tl.load(T+row*N+j,j<N,0)
        p = tl.exp(s-maximum)/denom
        tl.store(P+row*N+j,p,j<N)
        tl.store(T+row*N+j,p*(dp-delta),j<N)

@triton.jit
def _query_grad(K,T,R,M:tl.constexpr,N:tl.constexpr,H:tl.constexpr,J:tl.constexpr,D:tl.constexpr,S:tl.constexpr,K0:tl.constexpr,K1:tl.constexpr,K2:tl.constexpr,K3:tl.constexpr):
    i = tl.program_id(0)*32+tl.arange(0,32)
    d = tl.program_id(1)*32+tl.arange(0,32)
    bh = tl.program_id(2)
    b = bh//H
    h = bh%H
    kh = h//(H//J)
    r = tl.arange(0,32)
    acc = tl.full((32,32),0,tl.float32)
    for start in range(tl.cdiv(N,32)):
        j = start*32+r
        ds = tl.load(T+(bh*M+i[:,None])*N+j[None,:],(i[:,None]<M)&(j[None,:]<N),0)
        k = tl.load(K+b*K0+j[:,None]*K1+kh*K2+d[None,:]*K3,(j[:,None]<N)&(d[None,:]<D),0).to(tl.float32)
        acc += tl.dot(ds,k,input_precision='ieee')
    tl.store(R+((b*M+i[:,None])*H+h)*D+d[None,:],acc*S,(i[:,None]<M)&(d[None,:]<D))

@triton.jit
def _kv_grad(Q,O,P,T,R,M:tl.constexpr,N:tl.constexpr,H:tl.constexpr,J:tl.constexpr,D:tl.constexpr,S:tl.constexpr,Q0:tl.constexpr,Q1:tl.constexpr,Q2:tl.constexpr,Q3:tl.constexpr,O0:tl.constexpr,O1:tl.constexpr,O2:tl.constexpr,O3:tl.constexpr,QSIZE:tl.constexpr,KSIZE:tl.constexpr):
    j = tl.program_id(0)*32+tl.arange(0,32)
    d = tl.program_id(1)*32+tl.arange(0,32)
    bk = tl.program_id(2)
    b = bk//J
    kh = bk%J
    r = tl.arange(0,32)
    ak = tl.full((32,32),0,tl.float32)
    av = tl.full((32,32),0,tl.float32)
    for g in range(H//J):
        h = kh*(H//J)+g
        for start in range(tl.cdiv(M,32)):
            i = start*32+r
            off = ((b*H+h)*M+i[None,:])*N+j[:,None]
            mask = (j[:,None]<N)&(i[None,:]<M)
            ds = tl.load(T+off,mask,0)
            p = tl.load(P+off,mask,0)
            q = tl.load(Q+b*Q0+i[:,None]*Q1+h*Q2+d[None,:]*Q3,(i[:,None]<M)&(d[None,:]<D),0).to(tl.float32)
            o = tl.load(O+b*O0+i[:,None]*O1+h*O2+d[None,:]*O3,(i[:,None]<M)&(d[None,:]<D),0).to(tl.float32)
            ak += tl.dot(ds,q,input_precision='ieee')
            av += tl.dot(p,o,input_precision='ieee')
    off = ((b*N+j[:,None])*J+kh)*D+d[None,:]
    mask = (j[:,None]<N)&(d[None,:]<D)
    tl.store(R+QSIZE+off,ak*S,mask)
    tl.store(R+QSIZE+KSIZE+off,av,mask)

def _gqa_backward(q,k,v,do,scale):
    b,m,h,d = q.shape
    n,j = k.shape[1:3]
    p = torch.empty((b,h,m,n),device=q.device,dtype=torch.float32)
    t = torch.empty_like(p)
    result = torch.empty((q.numel()+2*k.numel(),),device=q.device,dtype=q.dtype)
    opts = dict(num_warps=4,num_stages=1)
    _products[(triton.cdiv(m,32),triton.cdiv(n,32),b*h)](q,k,v,do,p,t,m,n,h,j,d,scale,*q.stride(),*k.stride(),*v.stride(),*do.stride(),**opts)
    _normalize[(b*h*m,)](p,t,n,**opts)
    _query_grad[(triton.cdiv(m,32),triton.cdiv(d,32),b*h)](k,t,result,m,n,h,j,d,scale,*k.stride(),**opts)
    _kv_grad[(triton.cdiv(n,32),triton.cdiv(d,32),b*j)](q,do,p,t,result,m,n,h,j,d,scale,*q.stride(),*do.stride(),q.numel(),k.numel(),**opts)
    return result
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """FlashAttention backward (fused form): given the forward inputs Q/K/V and the
    upstream gradient dO, a single call computes the gradients dQ/dK/dV of the
    scaled dot-product attention forward O = softmax(scale·QK^T)·V with respect to
    Q, K and V. Supports MHA/GQA, dense fixed-length
    [batch, seqlen, heads, head_dim] (bshd) layout, non-causal (seqlen_q and
    seqlen_k may differ).

    Mathematical definition (g = num_q_heads // num_kv_heads,
    scale = 1/sqrt(head_dim), S_q/S_k are the sequence lengths of q/k, the KV head
    index for query head h is h_kv = h // g):
      S[b,h,i,j]     = scale * <q[b,i,h,:], k[b,j,h_kv,:]>
      P[b,h,i,j]     = softmax_j(S[b,h,i,:])     (non-causal, no mask)
      O[b,h,i,:]     = sum_j P[b,h,i,j] * v[b,j,h_kv,:]
      delta[b,h,i]   = <dO[b,i,h,:], O[b,h,i,:]> (= rowsum(dP∘P))
      dP[b,h,i,j]    = <dO[b,i,h,:], v[b,j,h_kv,:]>
      dS[b,h,i,j]    = P[b,h,i,j] * (dP[b,h,i,j] - delta[b,h,i])
      dQ[b,i,h,:]    = scale * sum_j dS[b,h,i,j] * k[b,j,h_kv,:]
      dK[b,j,h_kv,:] = scale * sum_{i, h: h//g = h_kv} dS[b,h,i,j] * q[b,i,h,:]
      dV[b,j,h_kv,:] = sum_{i, h: h//g = h_kv} P[b,h,i,j] * dO[b,i,h,:]
    i.e. dQ = scale·(dS·K), dK = scale·(dS^T·Q) (summed over the query heads inside
    each group of g), dV = P^T·dO (summed over the query heads inside each group of
    g). Intermediates are computed in float32 (numerically stable softmax), and
    each of the three gradients is cast back to the input dtype.
    Boundary behaviour: softmax normalizes along the k dimension, so the
    denominator is always positive; under GQA, dK/dV are the sum of the gradients
    over all query heads belonging to the same KV head, with a shape matching K/V.

    Input/output specification:
      q, do [batch, seqlen_q, num_q_heads, head_dim]  float16/bfloat16
      k, v  [batch, seqlen_k, num_kv_heads, head_dim] same dtype as q
      output: a 1-D tensor with the same dtype as q: dQ, dK, dV flattened in that
              order in their own bshd row-major layouts and then concatenated,
              length = batch*seqlen_q*num_q_heads*head_dim
                       + 2*batch*seqlen_k*num_kv_heads*head_dim
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (equal means MHA, otherwise GQA); 1 <= head_dim <= 256; seqlen_q >= 1,
    seqlen_k >= 1.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / recomputation of P and delta / chained
        gradient products) must be completed inside the submitted file; calling
        scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden, as is obtaining the
        gradients through torch.autograd or .backward().
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: non-causal, dense fixed-length batch layout, no dropout, no
    bias/ALiBi, non-quantized inputs (fp16/bf16).
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, do):
        # <<<IMPROVE:forward_stmt_1>>>
        B, seqlen_q, num_q_heads, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        _, seqlen_k, num_kv_heads, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        group = num_q_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert num_q_heads == num_kv_heads * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        result = _gqa_backward(q, k, v, do, self.sm_scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        return result
        # <<<END_IMPROVE>>>
