import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _spconv_fprop_kernel(xf, wf, pairs, counts, out, n, c_in, c_out, kv, num_act_out, BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    k = tl.program_id(2)
    count = tl.load(counts + k)
    if pid_m * BLOCK_M >= count:
        return
    rows = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    cols = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    row_mask = rows < n
    col_mask = cols < c_out
    valid = row_mask & (rows < count)
    in_idx = tl.load(pairs + k * n + rows, mask=valid, other=0)
    out_idx = tl.load(pairs + kv * n + k * n + rows, mask=valid, other=0)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for kk in range(0, c_in, BLOCK_K):
        chans = kk + tl.arange(0, BLOCK_K)
        cmask = chans < c_in
        xptr = xf + in_idx[:, None] * c_in + chans[None, :]
        wptr = wf + cols[None, :] * (kv * c_in) + k * c_in + chans[:, None]
        xv = tl.load(xptr, mask=valid[:, None] & cmask[None, :], other=0.0).to(tl.float32)
        wv = tl.load(wptr, mask=col_mask[None, :] & cmask[:, None], other=0.0).to(tl.float32)
        acc = tl.dot(xv, wv, acc, input_precision="ieee")
    optr = out + out_idx[:, None] * c_out + cols[None, :]
    tl.atomic_add(optr, acc, mask=valid[:, None] & col_mask[None, :])
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """
    Sparse convolution forward (the gathered form spconv_fprop): a per
    kernel-offset gather-GEMM-scatter forward over the sparse active points,
    driven by an index-pair table (spconv style).

    Semantic definition (out is first initialized to all zeros, then
    accumulated by the formula below):
        for each kernel offset k in [0, kv):
            n_k = indice_num_per_loc[k]
            for each j in [0, n_k):
                in_idx  = indice_pairs[0, k, j]      # input row index in [0, n)
                out_idx = indice_pairs[1, k, j]      # output row index in [0, num_act_out)
                out[out_idx, :] += features[in_idx, :] @ W[:, :, k].T
    i.e. for each index pair, gather the input row and matrix-multiply it with
    the weight matrix of offset k ((n_k, c_in) @ (c_in, c_out)), then
    scatter-accumulate by the output row index into out. The same output row may
    be hit by any number of index pairs (duplicates are allowed within the same
    k), and all of them accumulate with +=.

    The filters layout mapping (must be respected; it comes from the sample's
    as_strided rearrangement): let F be the contiguous (c_out, c_in, kv) tensor
    of the input; the library interprets its storage with strides
    (c_in*kv, 1, c_in), and the mathematical weight W and F satisfy:
        W[o, i, k] = F.reshape(c_out, kv, c_in)[o, k, i]
    which is equivalent to W = F.reshape(c_out, kv, c_in).permute(0, 2, 1)
    (still shaped (c_out, c_in, kv), a pure reinterpretation view for
    contiguous input); the weight matrix of kernel offset k is W[:, :, k],
    shaped (c_out, c_in).

    Boundary behaviour: kernel offsets with n_k = 0 are skipped entirely; when
    all n_k = 0, out stays all-zero; kv = 1 degenerates to a single-offset
    gather-scatter; num_act_out and n are independent of each other (either may
    be the larger one). Index-pair table entries with j >= n_k are padding
    garbage (they may hold any value, including duplicated valid row indices)
    and must be masked out according to indice_num_per_loc -- they must never be
    read into the computation.

    Input/output specification:
        features           float32 / float16 / bfloat16 (n, c_in), contiguous
        filters            same dtype as features (c_out, c_in, kv), contiguous
        indice_pairs       int32 (2, kv, n), contiguous
        indice_num_per_loc int32 (kv,), contiguous
        num_act_out        0-dim integer tensor (the online evaluator casts all
                           input tensors to fp32: integer indices are exact up
                           to 2^24 and are recovered with int(); the shape
                           domain of this task guarantees indices <= 2^24)
        out                a single tensor, same dtype as features
                           (num_act_out, c_out). This operator is inherently
                           single-output, with no multi-output packing segments.
    Dimension domain: n, c_in, c_out, kv, num_act_out >= 1, non-powers-of-two
    allowed; indice_num_per_loc[k] in [0, n]. Input values are ordinary randn
    magnitude (no inf/NaN).

    Implementation constraints (violations are scored as failures):
        - The core computation (gathering by index pair, the matrix
          multiplication with W[:, :, k], the scatter accumulation by output row
          index) must be done with a Triton kernel inside the submitted file; ATen
          is only allowed for non-core operations such as dtype recovery / shape
          cleanup.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate in float32 throughout (fp16/bf16 inputs are first cast
          losslessly to fp32), then cast the result back to the dtype of
          features; padding table entries must not take part in the computation
          (including out-of-bounds reads).
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.sparse / torch.sparse_coo_tensor /
    torch.sparse_csr_tensor / torch.sparse_csc_tensor / torch.sparse_mm /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear / index_add_ /
    torch.index_add / index_put / torch.index_put / scatter_add_ /
    .scatter_( / torch.scatter / segment_reduce / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, features, filters, indice_pairs, indice_num_per_loc, num_act_out):
        # <<<IMPROVE:forward_stmt_1>>>
        num_act_out = int(num_act_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        c_out, c_in, kv = filters.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        dt = features.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        xf = features.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        wf = filters.to(torch.float32).reshape(c_out, kv, c_in).permute(0, 2, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pairs = indice_pairs.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        counts = indice_num_per_loc.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.zeros(num_act_out, c_out, dtype=torch.float32,
                          device=features.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _spconv_fprop_kernel[(triton.cdiv(features.shape[0], 16), triton.cdiv(c_out, 32), kv)](
                    xf, wf, pairs, counts, out, features.shape[0], c_in, c_out, kv,
                    num_act_out, BLOCK_M=16, BLOCK_N=32, BLOCK_K=32, num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out.to(dt)
        # <<<END_IMPROVE>>>
