import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _clear_out(O, L: tl.constexpr, B: tl.constexpr):
    i = tl.program_id(0) * B + tl.arange(0, B)
    tl.store(O + i, 0.0, i < L)

@triton.jit
def _geometry(Off, Mask, b, m, p, valid, P: tl.constexpr, M: tl.constexpr, S: tl.constexpr, OW: tl.constexpr, SH: tl.constexpr, SW: tl.constexpr, PH: tl.constexpr, PW: tl.constexpr, DH: tl.constexpr, DW: tl.constexpr):
    oi = (b * 2 * M + 2 * m) * P + p
    yy = (p // OW * SH - PH + m // S * DH).to(tl.float32) + tl.load(Off + oi, valid, 0)
    xx = (p % OW * SW - PW + m % S * DW).to(tl.float32) + tl.load(Off + oi + P, valid, 0)
    y = tl.floor(yy).to(tl.int32)
    x = tl.floor(xx).to(tl.int32)
    a = yy - y
    t = xx - x
    mod = tl.load(Mask + (b * M + m) * P + p, valid, 0)
    return y, x, a, t, mod

@triton.jit
def _neighbors(X, b, c, y, x, valid, C: tl.constexpr, H: tl.constexpr, W: tl.constexpr):
    base = (b * C + c) * H * W + y * W + x
    v00 = valid & (y >= 0) & (y < H) & (x >= 0) & (x < W)
    v01 = valid & (y >= 0) & (y < H) & (x + 1 >= 0) & (x + 1 < W)
    v10 = valid & (y + 1 >= 0) & (y + 1 < H) & (x >= 0) & (x < W)
    v11 = valid & (y + 1 >= 0) & (y + 1 < H) & (x + 1 >= 0) & (x + 1 < W)
    u00 = tl.load(X + base, v00, 0)
    u01 = tl.load(X + base + 1, v01, 0)
    u10 = tl.load(X + base + W, v10, 0)
    u11 = tl.load(X + base + W + 1, v11, 0)
    return base, v00, v01, v10, v11, u00, u01, u10, u11

@triton.jit
def _input_grads(DY, WT, X, Off, Mask, Out, N: tl.constexpr, C: tl.constexpr, H: tl.constexpr, W: tl.constexpr, K: tl.constexpr, M: tl.constexpr, S: tl.constexpr, P: tl.constexpr, OW: tl.constexpr, SH: tl.constexpr, SW: tl.constexpr, PH: tl.constexpr, PW: tl.constexpr, DH: tl.constexpr, DW: tl.constexpr, B: tl.constexpr):
    p = tl.program_id(0) * B + tl.arange(0, B)
    m = tl.program_id(1)
    b = tl.program_id(2)
    valid = p < P
    y, x, a, t, mod = _geometry(Off, Mask, b, m, p, valid, P, M, S, OW, SH, SW, PH, PW, DH, DW)
    ay = tl.zeros((B,), tl.float32)
    ax = tl.zeros((B,), tl.float32)
    am = tl.zeros((B,), tl.float32)
    for c in range(C):
        q = tl.zeros((B,), tl.float32)
        for k in range(K):
            w = tl.load(WT + (k * C + c) * M + m)
            d = tl.load(DY + (b * K + k) * P + p, valid, 0)
            q = q + w * d
        base, v00, v01, v10, v11, u00, u01, u10, u11 = _neighbors(X, b, c, y, x, valid, C, H, W)
        val = (1-a)*(1-t)*u00 + (1-a)*t*u01 + a*(1-t)*u10 + a*t*u11
        gy = (1-t)*(u10-u00) + t*(u11-u01)
        gx = (1-a)*(u01-u00) + a*(u11-u10)
        z = q * mod
        am = am + q * val
        ay = ay + z * gy
        ax = ax + z * gx
        tl.atomic_add(Out + base, z * (1-a) * (1-t), v00, sem='relaxed')
        tl.atomic_add(Out + base + 1, z * (1-a) * t, v01, sem='relaxed')
        tl.atomic_add(Out + base + W, z * a * (1-t), v10, sem='relaxed')
        tl.atomic_add(Out + base + W + 1, z * a * t, v11, sem='relaxed')
    oi = N*C*H*W + (b * 2*M + 2*m)*P + p
    tl.store(Out + oi, ay, valid)
    tl.store(Out + oi + P, ax, valid)
    tl.store(Out + N*C*H*W + N*2*M*P + (b*M+m)*P+p, am, valid)

@triton.jit
def _weight_grads(DY, X, Off, Mask, Out, N: tl.constexpr, C: tl.constexpr, H: tl.constexpr, W: tl.constexpr, K: tl.constexpr, M: tl.constexpr, S: tl.constexpr, P: tl.constexpr, OW: tl.constexpr, SH: tl.constexpr, SW: tl.constexpr, PH: tl.constexpr, PW: tl.constexpr, DH: tl.constexpr, DW: tl.constexpr, B: tl.constexpr):
    idx = tl.program_id(0)
    m = idx % M
    c = idx // M % C
    k = idx // (M*C)
    lane = tl.arange(0, B)
    acc = tl.zeros((B,), tl.float32)
    for start in range(triton.cdiv(N*P, B)):
        j = start*B + lane
        b = j // P
        p = j % P
        valid = j < N*P
        y, x, a, t, mod = _geometry(Off, Mask, b, m, p, valid, P, M, S, OW, SH, SW, PH, PW, DH, DW)
        base, v00, v01, v10, v11, u00, u01, u10, u11 = _neighbors(X, b, c, y, x, valid, C, H, W)
        val = (1-a)*(1-t)*u00 + (1-a)*t*u01 + a*(1-t)*u10 + a*t*u11
        d = tl.load(DY + (b*K+k)*P+p, valid, 0)
        acc = acc + (d*mod)*val
    tl.store(Out + idx, tl.sum(acc, 0))
# <<<END_IMPROVE>>>

def _bilinear_zero_pad(x, y_coord, x_coord):
    """Bilinear sampling (an integer coordinate is the pixel centre);
    contributions outside the boundary are 0.

    x: (n, c, h, w); y_coord / x_coord: (n, oh, ow) floating-point sampling
    coordinates (in the H/W coordinate system).
    Returns (n, c, oh, ow). Differentiable with respect to y_coord / x_coord:
    the coordinate gradient flows back only through the interpolation fractions
    (the frac terms) while the floor/index path is treated as a constant -- i.e.
    the subgradient of the standard zero-padding bilinear Theano/DCNv2
    convention.
    """
    n, c, h, w = x.shape
    oh, ow = y_coord.shape[1], y_coord.shape[2]
    y0 = torch.floor(y_coord)
    x0 = torch.floor(x_coord)
    y1 = y0 + 1
    x1 = x0 + 1
    ty = (y_coord - y0).unsqueeze(1)   # (n, 1, oh, ow)
    tx = (x_coord - x0).unsqueeze(1)

    def gather(yc, xc):
        valid = ((yc >= 0) & (yc <= h - 1) & (xc >= 0) & (xc <= w - 1)).unsqueeze(1)
        yi = yc.clamp(0, h - 1).long()
        xi = xc.clamp(0, w - 1).long()
        # The index tensors carry a batch dimension, so plain advanced indexing
        # would move the index dimensions to the front and produce 5-D;
        # flattening plus gather keeps (n, c, oh, ow) and stays differentiable
        # with respect to x
        idx = (yi * w + xi).reshape(n, 1, oh * ow).expand(n, c, oh * ow)
        got = x.reshape(n, c, h * w).gather(2, idx).reshape(n, c, oh, ow)
        return got * valid.to(x.dtype)

    return ((1 - ty) * (1 - tx) * gather(y0, x0)
            + (1 - ty) * tx * gather(y0, x1)
            + ty * (1 - tx) * gather(y1, x0)
            + ty * tx * gather(y1, x1))

class ModelNew(nn.Module):
    """
    Deformable 2D convolution backward (DCNv2, with mask modulation):
    gradient with respect to the input (dgrad) and gradient with respect to the
    weights (wrw).

    Semantics (NCHW, offset group = 1, no bias, strictly consistent with the
    standard DCNv2 forward):
        forward y = deform_conv2d(x, offset, weight, mask, stride=(sh,sw),
                               padding=(ph,pw), dilation=(dh,dw))
        output size out_h = floor((H + 2*ph - dh*(R-1) - 1) / sh) + 1 (likewise
        for out_w)
        the m-th kernel sampling point in row-major order m = pm*S + pn
        (pm = m // S, pn = m % S), at output position (i, j):
            sampling coordinate  Y = i*sh - ph + dh*pm + offset[b, 2*m,   i, j]
                                 X = j*sw - pw + dw_*pn + offset[b, 2*m+1, i, j]
            sampled value  V[b, :, i, j, m] = bilinear(x, Y, X): an integer
                coordinate is the pixel centre, interpolated bilinearly; the part
                of a sampling point that falls outside [0,H-1]x[0,W-1]
                contributes 0.
            y[b, ko, i, j] = sum_m mask[b, m, i, j] *
                                 sum_ci weight[ko, ci, pm, pn] * V[b, ci, i, j, m]
        offset channels correspond one-to-one with the kernel sampling points in
        row-major order: channel 2*m is the H-direction offset and 2*m+1 the
        W-direction offset (the only widespread DCNv2 convention; offset
        group = 1 for this task).
    Given the upstream gradient dy = dL/dy (shape (N, out_c, out_h, out_w)):
        dgrad: dx = dL/dx (N,C,H,W), doffset = dL/doffset (N,2*R*S,out_h,out_w),
               dmask = dL/dmask (N,R*S,out_h,out_w)
        wrw:   dw = dL/dw (out_c,C,R,S)
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns the three gradients packed into a single 1-D tensor by
                 the segmentation protocol;
        "wrw":   returns dw; the values of weight do not take part in the
                 output here (shape convention only).
    forward(dy, weight, x, offset, mask) has a fixed five-input signature; the
    tensors mean:
        dy     (N, out_c, out_h, out_w)     upstream gradient, consumed by both
                                            directions
        weight (out_c, C, R, S)             convolution kernel (out_c output
                                            channels / C input channels)
        x      (N, C, H, W)                 forward input
        offset (N, 2*R*S, out_h, out_w)     sampling offsets
        mask   (N, R*S, out_h, out_w)       modulation mask
    forward returns the single tensor out (float32) -- dgrad is a 1-D
    concatenated packing (segmentation protocol):
        out = cat([dx.reshape(-1), doffset.reshape(-1), dmask.reshape(-1)])
        length = N*C*H*W + N*2*R*S*out_h*out_w + N*R*S*out_h*out_w, with the
        segment order fixed as dx | doffset | dmask, each segment being the
        C-order flattening of the corresponding 4-D tensor; the segment order
        must not be swapped;
        wrw -> (out_c, C, R, S), inherently single-output with no packing.

    Input/output specification:
        dy / weight / x / offset / mask are all float32, contiguous, NCHW
        layout; every dimension >= 1; R/S may be 1 (1x1 kernel); H/W may be 1,
        odd, non-power-of-two, not 16-aligned; stride/dilation >= 1, padding
        >= 0, padding follows the forward four-sided symmetric (ph, pw)
        semantics; consistency constraint
            H + 2*ph >= dh*(R-1) + 1, W + 2*pw >= dw_*(S-1) + 1,
        and the spatial sizes of dy/offset/mask must equal out_h/out_w from the
        forward formula, offset channels = 2*R*S, mask channels = R*S.
        Input values are ordinary randn magnitude (no inf/NaN). The evaluator
        casts all inputs to fp32 before the call.

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a Triton kernel inside the
          submitted file: the backward bilinear-sampling scatter of dgrad (the
          analytic partial derivatives with respect to Y/X chained back through
          the kernel weights and the mask into dx/doffset/dmask, with
          out-of-boundary contributions set to 0) or the sampled-value
          correlation accumulation of wrw (summing the cross-correlation of the
          x sampling windows with dy); falling back to torch autograd /
          convolution primitives / grid_sample for the core computation is
          forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares a single
          output); the three dgrad segments must be packed by the segmentation
          protocol above and the segment order must not be swapped.
        - Numeric contract: float32 inputs are accumulated directly in float32,
          with no downcast to half precision; the three dgrad gradient segments
          and the wrw output are all float32.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torchvision / torch.nn.functional.conv2d / F.conv2d /
    torch.conv2d / torch.nn.Conv2d / torch.nn.functional.conv_transpose2d /
    F.conv_transpose2d / torch.nn.ConvTranspose2d /
    torch.nn.grad.conv2d_input / torch.nn.grad.conv2d_weight /
    aten.convolution_backward / deform_conv2d / deform_conv2d_backward /
    grid_sample / F.grid_sample / torch.nn.functional.grid_sample /
    torch.autograd / .backward( / unfold / F.fold /
    torch.nn.functional.fold / im2col / col2im / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1, pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wrw"), "variant must be either dgrad or wrw"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)
        # <<<END_IMPROVE>>>

    def forward(self, dy, weight, x, offset, mask):
        # <<<IMPROVE:forward_stmt_1>>>
        N, C, H, W = x.shape
        K, _, R, S = weight.shape
        OH, OW = dy.shape[2:]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        P = OH * OW
        M = R * S
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        dx_len = N * C * H * W
        offset_len = N * 2 * M * P
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        if self.variant == "dgrad":
                    out = torch.empty((dx_len + offset_len + N*M*P,), device=x.device, dtype=torch.float32)
                    _clear_out[(triton.cdiv(dx_len, 256),)](out, dx_len, 256)
                    _input_grads[(triton.cdiv(P, 64), M, N)](dy, weight, x, offset, mask, out, N, C, H, W, K, M, S, P, OW, self.stride_h, self.stride_w, self.pad_h, self.pad_w, self.dil_h, self.dil_w, 64, num_warps=4, enable_fp_fusion=False)
                    return out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        dw = torch.empty((K, C, R, S), device=x.device, dtype=torch.float32)
        _weight_grads[(K*C*M,)](dy, x, offset, mask, dw, N, C, H, W, K, M, S, P, OW, self.stride_h, self.stride_w, self.pad_h, self.pad_w, self.dil_h, self.dil_w, 128, num_warps=4, enable_fp_fusion=False)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return dw
        # <<<END_IMPROVE>>>

    def _deform_conv2d_forward(self, x, offset, weight, mask):
        """Handwritten DCNv2 forward (a composition of standard differentiable
        torch operators), used for the autograd backward pass."""
        n, c, h, w = x.shape
        k, _, r, s = weight.shape
        sh, sw = self.stride_h, self.stride_w
        ph, pw = self.pad_h, self.pad_w
        dh, dwl = self.dil_h, self.dil_w
        oh, ow = offset.shape[2], offset.shape[3]
        out = torch.zeros(n, k, oh, ow, dtype=x.dtype, device=x.device)
        for m in range(r * s):
            pm, pn = m // s, m % s
            base_y = torch.arange(oh, dtype=x.dtype, device=x.device) * sh - ph + dh * pm
            base_x = torch.arange(ow, dtype=x.dtype, device=x.device) * sw - pw + dwl * pn
            yo = base_y.view(1, oh, 1) + offset[:, 2 * m]      # (n, oh, ow)
            xo = base_x.view(1, 1, ow) + offset[:, 2 * m + 1]  # (n, oh, ow)
            val = _bilinear_zero_pad(x, yo, xo)                # (n, c, oh, ow)
            wc = weight[:, :, pm, pn]                          # (k, c)
            contrib = torch.einsum("oc,ncij->noij", wc, val)
            out = out + mask[:, m].unsqueeze(1) * contrib
        return out
