import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl
from triton.language.extra import libdevice


@triton.jit
def _fused_mxfp4(X, Y, N: tl.constexpr, D: tl.constexpr, NB: tl.constexpr, ACT: tl.constexpr, BP: tl.constexpr):
    pid = tl.program_id(0)
    tiles_per_row = tl.cdiv(NB, BP)
    row = pid // tiles_per_row
    block = (pid % tiles_per_row) * BP + tl.arange(0, BP)
    lane = tl.arange(0, 32)
    col = block[:, None] * 32 + lane[None, :]
    valid = (block[:, None] < NB) & (col < D)
    a = tl.load(X + row * N + col, valid, other=0).to(tl.float32)
    b = tl.load(X + row * N + D + col, valid, other=0).to(tl.float32)
    if ACT == 'silu':
        act = a / (1.0 + libdevice.exp(-a))
    elif ACT == 'gelu':
        act = (0.5 * a) * (1.0 + libdevice.erf(a * 0.7071067811865476))
    else:
        cube = (a * a) * a
        inner = 0.7978845608028654 * (a + 0.044715 * cube)
        act = (0.5 * a) * (1.0 + libdevice.tanh(inner))
    value = tl.where(valid, act * b, 0.0)
    peak = tl.max(tl.abs(value), 1)
    rounded = (peak.to(tl.uint32, bitcast=True) + 0x200000) & 0xFF800000
    exponent = ((rounded >> 23) & 255).to(tl.int32)
    scale = tl.minimum(tl.maximum(exponent - 129, -127), 127)
    multiplier = tl.exp2(-scale.to(tl.float32))
    q = (value * multiplier[:, None]).to(tl.uint32, bitcast=True)
    e = ((q >> 23) & 255).to(tl.int32)
    m = q & 0x7FFFFF
    shift = tl.maximum(126 - e, 0)
    adjusted = (0x400000 | (m >> 1)) >> tl.minimum(shift, 31)
    adjusted = tl.where(shift >= 32, 0, adjusted)
    m = tl.where(e < 127, adjusted, m)
    ep = tl.maximum(e, 126) - 126
    code = (((ep << 2) | (m >> 21)) + 1) >> 1
    code = tl.minimum(code, 7) | ((q >> 28) & 8)
    pairs = tl.reshape(code, (BP, 16, 2))
    lo, hi = tl.split(pairs)
    packed = lo | (hi << 4)
    pair_col = block[:, None] * 16 + tl.arange(0, 16)[None, :]
    stride: tl.constexpr = D // 2 + NB
    tl.store(Y + row * stride + pair_col, packed.to(tl.uint8), (block[:, None] < NB) & (pair_col < D // 2))
    tl.store(Y + row * stride + D // 2 + block, (scale + 127).to(tl.uint8), block < NB)


def _launch_mxfp4(x, M, N, d, activation):
    nb = (d + 31) // 32
    bp = 4 if nb >= 4 else 1
    result = torch.empty((M, d // 2 + nb), device=x.device, dtype=torch.uint8)
    _fused_mxfp4[(M * triton.cdiv(nb, bp),)](x, result, N, d, nb, activation, bp, num_warps=1, enable_fp_fusion=False)
    return result
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Gated activation x SwiGLU split-half multiply x dynamic MXFP4 quantization
    fused operator.

    Input x has shape (M, N) (N is a multiple of 4). Split the last dimension in
    half: a = x[:, :N/2], b = x[:, N/2:], then first compute the gated product in
    float32 as out = act(a) * b, where act is selected by the __init__ argument
    activation (mathematical definition, all evaluated in float32):
        silu      : u * sigmoid(u)
        gelu      : 0.5 * u * (1 + erf(u * 0.7071067811865476))
        gelu_tanh : 0.5 * u * (1 + tanh(0.7978845608028654 * (u + 0.044715 * u^3)))

    Then split out along the last dimension into contiguous 32-element blocks and
    dynamically quantize each block to MXFP4 (float32 bit manipulation throughout):
      1. When N/2 is not a multiple of 32, zero-pad the right end of the last block
         up to 32 elements; the padding participates in amax.
      2. amax = max|block|; apply (bits + 0x200000) & 0xFF800000 to the float32 bit
         pattern of amax (even_round: clear the mantissa and round up to the power
         of two grid).
      3. Unbiased scale = clamp(floor(log2(amax)) - 2, -127, 127); the e8m0 byte =
         unbiased scale + 127, landing in [0, 254] (meaning 2^(byte - 127)). A
         fully zero block (including a zero-pad segment that makes amax 0) goes
         through log2(0) = -inf, is clamped to -127, and gets byte 0.
      4. q = block * 2^(-unbiased scale), each element rounded to the e2m1 grid
         {0, +-0.5, +-1, +-1.5, +-2, +-3, +-4, +-6}. Bit-level formula: take the
         float32 fields of q -- s (sign bit) / e (biased exponent) / m (23-bit
         mantissa):
             e' = max(e, 126) - 126
             m' = (e < 127) ? (0x400000 | (m >> 1)) >> (126 - e) : m (subnormal
                  rescaling)
             code = (((e' << 2) | (m' >> 21)) + 1) >> 1, then saturated to 0x7
             e2m1 code word (4 bits) = (s ? 8 : 0) | code
      5. Two adjacent e2m1 code words are packed into one uint8: the even index
         occupies the low 4 bits, the odd index the high 4 bits.

    The output is a single uint8 tensor (two segments concatenated along the last
    dimension):
        out (M, N/4 + ceil(N/64)) uint8
        first N/4 columns       : MXFP4 packed code words (two e2m1 values per byte)
        last ceil(N/64) columns : the e8m0 scale byte of each 32-element block
    Both segments are integer code words and must match exactly.

    Input/output specification:
        x    float16 / bfloat16 (M, N), contiguous, N % 4 == 0, M >= 1
             (the evaluator casts the input to fp32 before calling forward;
             fp16/bf16 -> fp32 is lossless)
        out  uint8 (M, N/4 + ceil(N/64))

    Implementation constraints (violations are scored as failures):
        - The core computation (activation, split-half multiply, per-block scale
          and e2m1 quantization, code-word packing) must be completed with a
          Triton kernel inside the submitted file; the output is uint8 code words
          with no floating-point output.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The activation, the multiply and the quantization bit manipulation all
          run in float32 and must be bit-identical to this reference implementation
          (code words and scale bytes exactly equal, no tolerance).
        - When N/2 is not a multiple of 32, handle the block tail with the zero-pad
          semantics described above.

    Forbidden: torch.nn.functional.silu / torch.nn.functional.gelu /
    torch.nn.SiLU / torch.nn.GELU / torch.sigmoid / torch.erf / torch.tanh.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, activation: str = "silu"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        if activation not in ("silu", "gelu", "gelu_tanh"):
            raise AssertionError("activation must be one of silu / gelu / gelu_tanh")
        self.activation = activation
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, N = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        assert N % 4 == 0, "N must be a multiple of 4"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        d = N // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        return _launch_mxfp4(x, M, N, d, self.activation)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        BLOCK = 32
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        n_blocks = (d + BLOCK - 1) // BLOCK
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        blocks = out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        if d % BLOCK != 0:
            # zero-pad the block tail (the padding participates in amax)
            padded = torch.zeros(M, n_blocks * BLOCK, dtype=torch.float32, device=out.device)
            padded[:, :d] = out
            blocks = padded
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        blocks = blocks.reshape(M, n_blocks, BLOCK)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        amax, _ = torch.max(torch.abs(blocks), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        amax = amax.view(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        amax = (amax + 0x200000) & 0xFF800000
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        amax = amax.view(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        scale_unbiased = torch.clamp(torch.log2(amax).floor() - 2, min=-127, max=127)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        bs_e8m0 = (scale_unbiased + 127).to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        quant_scale = torch.exp2(-scale_unbiased)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        qx = blocks * quant_scale.unsqueeze(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        qx = qx.contiguous().view(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        s = qx & 0x80000000
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        e = (qx >> 23) & 0xFF
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        m = qx & 0x7FFFFF
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        adjusted = torch.clamp(127 - e - 1, min=0)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_27>>>
        m = torch.where(e < 127, (0x400000 | (m >> 1)) >> adjusted, m)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_28>>>
        e = torch.where(e > 126, e, 126) - 126
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_29>>>
        combined = (((e << 2) | (m >> 21)) + 1) >> 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_30>>>
        e2m1_tmp = torch.where(combined < 0x7, combined, 0x7)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_31>>>
        e2m1_value = (((s >> 28) & 0xF) | e2m1_tmp).to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_32>>>
        x_fp4 = e2m1_value[..., ::2] | (e2m1_value[..., 1::2] << 4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_33>>>
        x_fp4 = x_fp4.reshape(M, -1)[:, : d // 2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_34>>>
        return torch.cat([x_fp4, bs_e8m0], dim=-1)
        # <<<END_IMPROVE>>>
