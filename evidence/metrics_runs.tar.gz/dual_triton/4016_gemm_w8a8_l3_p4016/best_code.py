import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _group_scaled_gemm(A, B, AS, BS, O,
                       M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
                       am: tl.constexpr, ak: tl.constexpr,
                       bn: tl.constexpr, bk: tl.constexpr,
                       asm: tl.constexpr, asg: tl.constexpr,
                       bsn: tl.constexpr, bsg: tl.constexpr,
                       BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    pid = tl.program_id(0)
    nm = tl.cdiv(M, BM)
    nn = tl.cdiv(N, BN)
    group_width = 8 * nn
    group_id = pid // group_width
    first_m = group_id * 8
    actual_m = tl.minimum(nm - first_m, 8)
    local = pid % group_width
    tile_m = first_m + local % actual_m
    tile_n = local // actual_m
    rows = tile_m * BM + tl.arange(0, BM)
    cols = tile_n * BN + tl.arange(0, BN)
    rk = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), tl.float32)
    for g in range(tl.cdiv(K, BK)):
        ks = g * BK + rk
        av = tl.load(A + rows[:, None] * am + ks[None, :] * ak,
                     (rows[:, None] < M) & (ks[None, :] < K), other=0)
        bv = tl.load(B + cols[None, :] * bn + ks[:, None] * bk,
                     (cols[None, :] < N) & (ks[:, None] < K), other=0)
        sa = tl.load(AS + rows * asm + g * asg, rows < M, other=0)
        sb = tl.load(BS + (cols // 128) * bsn + g * bsg, cols < N, other=0)
        af = av.to(tl.float32) * sa[:, None]
        bf = bv.to(tl.float32) * sb[None, :]
        acc = tl.dot(af, bf, acc, input_precision="ieee")
    tl.store(O + rows[:, None] * N + cols[None, :], acc,
             (rows[:, None] < M) & (cols[None, :] < N))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """int8 block-quantized GEMM (quantized activations x quantized weights,
    dequantized with block scales).

    Mathematical definition: given the int8 activation code words A (M,K), the
    int8 weight code words B (N,K), the activation per-token-group scale
    As (M, ceil(K/128)) and the weight 128x128 block scale
    Bs (ceil(N/128), ceil(K/128)) (all float32), dequantize first and then do
    the matrix multiply:
      Af[m,k] = A[m,k] * As[m, floor(k/128)]
      Bf[n,k] = B[n,k] * Bs[floor(n/128), floor(k/128)]
      out[m,n] = sum_k Af[m,k] * Bf[n,k]    (float32 accumulation, i.e. Af @ Bf^T)
    The equivalent compute order for block quantization: take an int8 dot
    product per 128-element group along K first (exactly accumulable in int32),
    then multiply by that group's As[m,g] * Bs[n_blk,g] and sum in float32 --
    equal to the expression above within float32 precision. The output is cast
    to the out_dtype passed to __init__.
    Boundary behaviour: when K or N is not divisible by 128 the floor index
    simply extends naturally -- a tail group/block covers only the valid
    elements (out-of-range elements do not take part in the accumulation), and
    the group counts of As/Bs are given by ceil(.../128).

    Input/output specification:
      aq      int8    (M, K)                 activation code words, row-major
      bq      int8    (N, K)                 weight code words, row-major (output channels on rows)
      a_scale float32 (M, ceil(K/128))       per-token scale, one group per 128 elements
      b_scale float32 (ceil(N/128), ceil(K/128))   weight 128x128 block scale
      out     out_dtype (M, N)              bfloat16 / float16
      M/N/K >= 1, all allow non-powers of two and a tail not aligned to 128.

    Implementation constraints (violations are scored as failures):
      - The core computation (int8 GEMM accumulation and the scale multiply)
        must be completed inside the submitted file, and calling library-level
        matrix-multiply shortcuts such as torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / torch._int_mm / F.linear /
        functional.linear, or the other entries on the task set's static-audit
        forbidden list, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation (int8 products can be
        accumulated exactly in int32 first, then converted to float32); the
        output is cast to out_dtype.
      - The evaluator casts every input to fp32 before calling forward; the
        int8 code-word range [-128,127] and the fp32 scales are both exactly
        representable, so .to(torch.int8) / .to(torch.float32) at the entry
        point recover them losslessly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: block shape fixed at [128,128], A is 2D (M,K), no bias, no
    splitK; the output is bfloat16 / float16.
    """
    def __init__(self, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.out_dtype = getattr(torch, out_dtype)
        self.block_n = 128
        self.block_k = 128
        # <<<END_IMPROVE>>>

    def forward(self, aq, bq, a_scale, b_scale):
        # <<<IMPROVE:forward_stmt_1>>>
        aq = aq.to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        bq = bq.to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        a_scale = a_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        b_scale = b_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = aq.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        N = bq.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert K == bq.shape[1], "the K dimension of aq and bq must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty((M, N), device=aq.device, dtype=self.out_dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Scales are loaded directly by the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # The kernel consumes compact int8 weights.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _group_scaled_gemm[(triton.cdiv(M, 32) * triton.cdiv(N, 64),)](
                    aq, bq, a_scale, b_scale, out, M, N, K,
                    aq.stride(0), aq.stride(1), bq.stride(0), bq.stride(1),
                    a_scale.stride(0), a_scale.stride(1),
                    b_scale.stride(0), b_scale.stride(1),
                    BM=32, BN=64, BK=128, num_warps=4,
                )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
