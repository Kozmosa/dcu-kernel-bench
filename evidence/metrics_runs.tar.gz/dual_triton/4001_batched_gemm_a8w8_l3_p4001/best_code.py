import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _fused_tn_gemm(X, W, XS, WS, Bias, O,
                   M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
                   xb: tl.constexpr, xm: tl.constexpr, xk: tl.constexpr,
                   wb: tl.constexpr, wn: tl.constexpr, wk: tl.constexpr,
                   sb: tl.constexpr, sm: tl.constexpr,
                   tb: tl.constexpr, tn: tl.constexpr,
                   bb: tl.constexpr, bn: tl.constexpr,
                   USE_BIAS: tl.constexpr,
                   BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    m = tl.program_id(0) * BM + tl.arange(0, BM)
    n = tl.program_id(1) * BN + tl.arange(0, BN)
    b = tl.program_id(2)
    r = tl.arange(0, BK)
    acc = tl.zeros((BM, BN), tl.float32)
    for start in range(tl.cdiv(K, BK)):
        k = start * BK + r
        a = tl.load(X + b * xb + m[:, None] * xm + k[None, :] * xk,
                    (m[:, None] < M) & (k[None, :] < K), other=0).to(tl.float16)
        w = tl.load(W + b * wb + n[None, :] * wn + k[:, None] * wk,
                    (n[None, :] < N) & (k[:, None] < K), other=0).to(tl.float16)
        acc = tl.dot(a, w, acc)
    xs = tl.load(XS + b * sb + m * sm, m < M, other=0).to(tl.float32)
    ws = tl.load(WS + b * tb + n * tn, n < N, other=0).to(tl.float32)
    acc = acc * xs[:, None]
    acc = acc * ws[None, :]
    out = acc.to(O.dtype.element_ty)
    if USE_BIAS:
        bias = tl.load(Bias + b * bb + n * bn, n < N, other=0).to(O.dtype.element_ty).to(tl.float32)
        out = (out.to(tl.float32) + bias[None, :]).to(O.dtype.element_ty)
    tl.store(O + b * M * N + m[:, None] * N + n[None, :], out,
             (m[:, None] < M) & (n[None, :] < N))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Batch-dimension int8 quantized GEMM: int8 activations x int8 weights, with an
    outer-product scale applied for dequantization.

    Computed independently for every matrix in the batch (mathematical definition):
      acc[b, m, n] = sum_k xq[b, m, k] * wq[b, n, k]          (float32 accumulation)
      out[b, m, n] = acc[b, m, n] * xs[b, m, 0] * ws[b, 0, n] (+ bias[b, 0, n])

    i.e. out[b] = xq[b] @ wq[b]^T followed by dequantization. wq is stored
    row-major as (B, N, K), so the computation is equivalent to a transposed GEMM
    (row n of the weight is one output-channel column). xs is the per-token scale:
    one value per row of the M dimension, (B, M, 1) float32; ws is the per-channel
    scale: one value per column of the N dimension, (B, 1, N) float32; their outer
    product is the (B, M, N) dequantization matrix. bias (B, 1, N) is optional and
    has the same dtype as the output; with bias the quantized-GEMM kernel fusion
    order applies: the float32 scaled result is first cast to the output dtype, then
    the bias is added.

    Input/output specification:
      xq      int8       (B, M, K)   activation code words
      wq      int8       (B, N, K)   weight code words (row-major, transposed-GEMM
                                     equivalent)
      xs      float32    (B, M, 1)   per-token scale
      ws      float32    (B, 1, N)   per-channel scale
      bias    output dtype (B, 1, N) optional; when use_bias=False a placeholder
                                     tensor is passed and ignored
      out     output dtype (B, M, N) the dtype is set by __init__'s out_dtype
                                     (bfloat16 / float16), B/M/N/K >= 1

    Implementation constraints (violations are scored as failures):
      - The core computation (the int8 GEMM accumulation) must be completed inside
        the submitted file; calling torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / torch._int_mm / F.linear /
        functional.linear is forbidden, as is calling any ready-made operator
        library or closed-source kernel wrapper to complete this computation
        directly.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward; the code
        words are small integers in [-20, 20) and the bias values come from
        low-precision quantization, all exactly representable in fp32, so
        .to(torch.int8) / .to(out_dtype) at the entry point recovers them
        losslessly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: TN layout (x row-major (B,M,K), w row-major (B,N,K)), no split-K;
    B/M/N/K are any values >= 1 with no alignment requirement; the accumulation
    runs in float32 and must agree with the reference fp32 GEMM within tolerance.
    """
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.__dict__.update({"use_bias": bool(use_bias), "out_dtype": getattr(torch, out_dtype)})
        # <<<END_IMPROVE>>>

    def forward(self, xq, wq, x_scale, w_scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        bias = bias if self.use_bias else None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        B, M, K = xq.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = wq.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == wq.shape[2], "xq and wq must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        acc = torch.empty((B, M, N), device=xq.device, dtype=self.out_dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _fused_tn_gemm[(triton.cdiv(M, 32), triton.cdiv(N, 64), B)](
            xq, wq, x_scale, w_scale, bias if self.use_bias else acc, acc,
            M, N, K,
            xq.stride(0), xq.stride(1), xq.stride(2),
            wq.stride(0), wq.stride(1), wq.stride(2),
            x_scale.stride(0), x_scale.stride(1),
            w_scale.stride(0), w_scale.stride(2),
            bias.stride(0) if self.use_bias else 0,
            bias.stride(2) if self.use_bias else 0,
            USE_BIAS=self.use_bias, BM=32, BN=64, BK=32,
            num_warps=4, enable_fp_fusion=False,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return acc.to(self.out_dtype)
        # <<<END_IMPROVE>>>
