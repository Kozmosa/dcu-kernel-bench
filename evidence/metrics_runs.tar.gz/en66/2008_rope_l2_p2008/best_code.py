import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl
from triton.language.extra import libdevice


@triton.jit
def _rope_forward_kernel(X, Freqs, Out, N: tl.constexpr,
                         BH: tl.constexpr, D: tl.constexpr, F: tl.constexpr,
                         STYLE: tl.constexpr, NOPE_FIRST: tl.constexpr,
                         REUSE: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = i < N
    c = i % D
    row = i // D
    seq = row // BH
    R: tl.constexpr = F * (2 if REUSE else 1)
    START: tl.constexpr = D - R if NOPE_FIRST else 0
    rotating = (c >= START) & (c < START + R)
    j = c & (R - 1)
    original = tl.load(X + i, mask=valid, other=0)
    if STYLE == 0:
        partner = j ^ (R // 2)
        negative = (j & (R // 2)) == 0
    else:
        partner = j ^ 1
        negative = (j & 1) == 0
    other = tl.load(X + row * D + START + partner,
                    mask=valid & rotating, other=0).to(tl.float32)
    if REUSE:
        if STYLE == 0:
            freq_col = j & (F - 1)
        else:
            freq_col = j >> 1
    else:
        freq_col = j
    angle = tl.load(Freqs + seq * F + freq_col,
                    mask=valid & rotating, other=0).to(tl.float32)
    signed_other = tl.where(negative, -other, other)
    result = original.to(tl.float32) * libdevice.cos(angle) + signed_other * libdevice.sin(angle)
    tl.store(Out + i, result, mask=valid & rotating)
    tl.store(Out + i, original, mask=valid & ~rotating)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """RoPE (Rotary Position Embedding) forward: dense sbhd layout, with the
    rotation angles given directly as a freqs tensor (not a cached cos/sin table);
    the channels of every head vector are rotated as planes according to the
    sequence position.

    Semantics (the trigonometric functions and the multiply-add are all evaluated in
    float32; the output is cast back to the input dtype):
       The input is x (S, B, H, D) together with freqs (S, 1, 1, F); freqs
       broadcasts over the B and H dimensions.
       Rotation width R = F * 2 (reuse_freqs_front_part=True) or R = F (False).
       Split the last dimension (length D) into a "rotation segment" (length R) and
       a "pass-through segment" (length D - R): with nope_first=False the rotation
       segment occupies the first R channels, with True the last R channels.
       Angle row Theta (length R): with reuse=False, Theta = freqs, one angle per
       rotation channel; with reuse=True, F = R/2 angles are expanded to R columns --
       the NEOX style tiles the whole segment ([a, b] -> [a, b, a, b], each half used
       once), the GPTJ style repeats adjacently ([a, b] -> [a, a, b, b], each number
       pair shares one angle).
       For the rotation segment x_rot (length R) compute:
         out_rot = x_rot * cos(Theta) + rotate_half(x_rot) * sin(Theta)
       rotate_half is decided by the __init__ argument rotate_style:
         NEOX (rotate_style=0): rotate_half(x_rot) = concat(-x_rot[R/2:],
           x_rot[:R/2]), i.e. the first half u and the second half v are swapped with
           the u segment negated, which is equivalent to a plane rotation of every
           pair (u_j, v_j).
         GPTJ (rotate_style=1): even-odd channel pairing, rotate_half(x_rot)[2j] =
           -x_rot[2j+1], rotate_half(x_rot)[2j+1] = x_rot[2j].
       The pass-through segment is appended back without any transformation: with
       nope_first=False, out = concat(out_rot, pass-through segment); with True,
       out = concat(pass-through segment, out_rot).
       Boundary behaviour: when R = D the pass-through segment is empty (full-width
       rotation); when R < D the pass-through segment is kept verbatim, bit for bit;
       the last dimension F of freqs has only the three legal values {D, D/2, D/4}
       (their combination with reuse and R is listed below); all other
       configurations are undefined.

    Input/output specification:
        x      (S, B, H, D)  float16 / bfloat16, contiguous; D is a power of two
                              (4..256), S, B, H are arbitrary positive integers
        freqs  (S, 1, 1, F)  same dtype as x, contiguous; legal combinations:
                              full-width rotation reuse=False: F = D;
                              full-width rotation reuse=True: F = D/2;
                              partial rotation (R=D/2) reuse=False: F = D/2;
                              partial rotation (R=D/2) reuse=True: F = D/4
        output out (S, B, H, D), same dtype as x
        (the evaluator casts the input to fp32 before passing it in; fp16/bf16 ->
        fp32 is lossless)
        hyper-parameters (__init__): rotate_style (0=NEOX, 1=GPTJ), nope_first,
        reuse_freqs_front_part.

    Implementation constraints (violations are scored as failures):
        - The core computation (angle expansion, rotate_half, cos/sin and the
          multiply-add, concatenation of the pass-through segment) must be completed
          inside the submitted file with a Triton kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate computation; cast the output back to the input
          dtype.

    Forbidden: scaled_dot_product_attention / sdpa / flash_attn /
    torch.matmul / torch.bmm / torch.einsum / torch.softmax / torch.polar /
    torch.view_as_complex.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: dense sbhd non-cached forward; variable-length thd, cos/sin cache
    addressing, the dual-input GQA case, the backward pass, and 2D image rotation are
    outside this task.
    """
    def __init__(self, rotate_style: int, nope_first: bool, reuse_freqs_front_part: bool):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.rotate_style = int(rotate_style)
        self.nope_first = bool(nope_first)
        self.reuse_freqs_front_part = bool(reuse_freqs_front_part)
        # <<<END_IMPROVE>>>

    def forward(self, x, freqs):
        # <<<IMPROVE:forward_stmt_1>>>
        out = torch.empty_like(x)
        s, b, h, d = x.shape
        f = freqs.shape[-1]
        n = x.numel()
        _rope_forward_kernel[(triton.cdiv(n, 256),)](
            x, freqs, out, n, b * h, d, f,
            self.rotate_style, self.nope_first, self.reuse_freqs_front_part,
            BLOCK=256, num_warps=4, enable_fp_fusion=False,
        )
        return out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        x32 = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        f32 = freqs.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        d = x32.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        rotate_dim = f32.shape[-1] * (2 if self.reuse_freqs_front_part else 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        start = (d - rotate_dim) if self.nope_first else 0
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        x_rot = x32[..., start : start + rotate_dim]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        x_pass = torch.cat((x32[..., :start], x32[..., start + rotate_dim :]), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        theta = f32
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        if self.reuse_freqs_front_part and self.rotate_style == 0:
            theta = f32.repeat([1] * (f32.dim() - 1) + [2])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        if self.reuse_freqs_front_part and self.rotate_style == 1:
            theta = f32.repeat_interleave(2, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        half = rotate_dim // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        rot_half = x_rot
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        if self.rotate_style == 0:  # NEOX: swap the first half u / second half v, negate the u segment
            x1 = x_rot[..., :half]
            x2 = x_rot[..., half:]
            rot_half = torch.cat((-x2, x1), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        if self.rotate_style == 1:  # GPTJ: even-odd pairing; the even slot takes the negated odd element, the odd slot takes the even element
            x1 = x_rot[..., ::2]
            x2 = x_rot[..., 1::2]
            rot_half = torch.stack((-x2, x1), dim=-1).flatten(-2)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        x_embed = x_rot * torch.cos(theta) + rot_half * torch.sin(theta)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        pieces = (x_pass, x_embed) if self.nope_first else (x_embed, x_pass)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        out = torch.cat(pieces, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        return out.to(dt)
        # <<<END_IMPROVE>>>
