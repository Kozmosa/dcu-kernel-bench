import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _ragged_attention(Q, K, V, O, L,
                      Q0: tl.constexpr, Q1: tl.constexpr, Q2: tl.constexpr,
                      K0: tl.constexpr, K1: tl.constexpr, K2: tl.constexpr,
                      V0: tl.constexpr, V1: tl.constexpr, V2: tl.constexpr,
                      O0: tl.constexpr, O1: tl.constexpr, O2: tl.constexpr,
                      LS: tl.constexpr, B: tl.constexpr, H: tl.constexpr,
                      T: tl.constexpr, D: tl.constexpr, SCALE: tl.constexpr,
                      CAUSAL: tl.constexpr, BP: tl.constexpr,
                      BM: tl.constexpr, BN: tl.constexpr, BD: tl.constexpr):
    tile = tl.program_id(0)
    h = tl.program_id(1)
    b = tl.program_id(2)
    bs = tl.arange(0, BP)
    lengths = tl.load(L + bs * LS, mask=(bs < B) & (bs < b), other=0)
    start = tl.sum(lengths, 0)
    length = tl.load(L + b * LS)
    rows = tile * BM + tl.arange(0, BM)
    ds = tl.arange(0, BD)
    ns = tl.arange(0, BN)
    qv = tl.load(Q + (b * T + rows[:, None]) * Q0 + h * Q1 + ds[None, :] * Q2,
                 mask=(rows[:, None] < T) & (ds[None, :] < D), other=0).to(tl.float32)
    maximum = tl.full((BM,), -float('inf'), tl.float32)
    denominator = tl.zeros((BM,), tl.float32)
    acc = tl.zeros((BM, BD), tl.float32)
    end = length
    if CAUSAL:
        end = tl.minimum(length, (tile + 1) * BM)
    for base in range(0, end, BN):
        cols = base + ns
        kv = tl.load(K + (start + cols[None, :]) * K0 + h * K1 + ds[:, None] * K2,
                     mask=(cols[None, :] < length) & (ds[:, None] < D), other=0).to(tl.float32)
        scores = tl.dot(qv, kv, input_precision='ieee') * SCALE
        visible = cols[None, :] < length
        if CAUSAL:
            visible = visible & (cols[None, :] <= rows[:, None])
        scores = tl.where(visible, scores, -float('inf'))
        new_maximum = tl.maximum(maximum, tl.max(scores, 1))
        correction = tl.exp(maximum - new_maximum)
        probabilities = tl.exp(scores - new_maximum[:, None])
        denominator = denominator * correction + tl.sum(probabilities, 1)
        acc = acc * correction[:, None]
        vv = tl.load(V + (start + cols[:, None]) * V0 + h * V1 + ds[None, :] * V2,
                     mask=(cols[:, None] < length) & (ds[None, :] < D), other=0).to(tl.float32)
        acc = tl.dot(probabilities, vv, acc, input_precision='ieee')
        maximum = new_maximum
    result = acc / denominator[:, None]
    tl.store(O + (b * T + rows[:, None]) * O0 + h * O1 + ds[None, :] * O2,
             result, mask=(rows[:, None] < T) & (ds[None, :] < D))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Attention forward pass over ragged batches with variable-length KV (Lean
    Attention semantics: contiguous, non-paged KV, softmax inside a single
    kernel), covering both decode (independent KV lengths per batch entry) and
    prefill (square causal self-attention) forms, with MHA (Q/K/V head counts
    equal).

    Mathematical definition: the batch holds num_seqs sequences, sequence b has an
    actually participating KV length kv_lens[b] (>= 1), and every query segment has
    the same length q_len (total_q = num_seqs * q_len, with q stored in
    sequence-major order). Let start_k = kv_lens[0] + ... + kv_lens[b-1] (k/v are
    likewise stored contiguously in sequence-major order). For every sequence b,
    head h, query position i (0 <= i < q_len) and KV position j
    (0 <= j < kv_lens[b]):
      scores[i, j] = sm_scale * <q[b*q_len+i, h, :], k[start_k+j, h, :]>
      with causal=1 (the task constrains kv_lens[b] == q_len for all b in this form)
      a square causal mask is applied: positions with j > i are set to -inf; with
      causal=0 no mask is applied;
      p[i, :] = softmax_j(scores[i, :])
      out[b*q_len+i, h, :] = sum_j p[i, j] * v[start_k+j, h, :]
    The softmax uses a numerically stable (online) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.
    Boundary behaviour: kv_lens[b] >= 1 always holds, so the softmax denominator is
    always positive and no row is fully masked; sequences do not affect each other;
    slots in k/v beyond each sequence's cumulative length boundary do not
    participate in the computation.

    Input/output specification:
      q        [num_seqs*q_len, num_heads, head_dim]  float16/bfloat16, sequence-major
      k, v     [total_kv, num_heads, head_dim]        same dtype as q, total_kv = sum(kv_lens)
      kv_lens  [num_seqs] int32 -- the KV length actually participating per sequence
      causal   0-dim int32 tensor, 1 = square causal mask, 0 = no mask
      out      [num_seqs*q_len, num_heads, head_dim]  same dtype as q
    Global constraints: Q/K/V head counts are equal (MHA, no GQA); head_dim in
    {16, 32, 64, 128, 256} and identical across Q/K/V; q_len >= 1; with causal=1,
    kv_lens[b] == q_len for all b.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: contiguous non-paged KV, variable-length ragged batch, MHA, both
    causal states, fp16/bf16 non-quantized inputs; no GQA, no dropout, no
    bias/ALiBi, no LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, kv_lens, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        kv_lens = kv_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        is_causal = bool(int(causal.to(torch.int32)))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_heads = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        assert num_heads == k.shape[1] == v.shape[1], "MHA: Q/K/V must have the same number of heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_seqs = int(kv_lens.numel())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        q_len = q.shape[0] // num_seqs
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert q_len * num_seqs == q.shape[0], "total_q must be an integer multiple of num_seqs"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if is_causal:
            assert bool((kv_lens == q_len).all()), "with causal=1 every batch entry's kv_len must equal q_len"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        kv_lens_device = kv_lens.to(device=q.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        _ragged_attention[(triton.cdiv(q_len, 16), num_heads, num_seqs)](
            q, k, v, out, kv_lens_device,
            *q.stride(), *k.stride(), *v.stride(), *out.stride(),
            kv_lens_device.stride(0), num_seqs, num_heads,
            q_len, q.shape[2], self.sm_scale, is_causal,
            triton.next_power_of_2(num_seqs), 16, 32,
            triton.next_power_of_2(q.shape[2]), num_warps=4, num_stages=1,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
