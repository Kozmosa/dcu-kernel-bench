import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _rmsnorm_row_kernel(
    x_ptr, w_ptr, residual_ptr, out_ptr,
    n, eps,
    BLOCK: tl.constexpr,
    CHUNKS: tl.constexpr,
    FUSED: tl.constexpr,
):
    row = tl.program_id(0)
    cols = tl.arange(0, BLOCK)
    acc = 0.0
    for chunk in range(CHUNKS):
        col = chunk * BLOCK + cols
        mask = col < n
        xval = tl.load(x_ptr + row * n + col, mask=mask, other=0.0)
        if FUSED:
            rval = tl.load(residual_ptr + row * n + col, mask=mask, other=0.0)
            raw = xval + rval
            val = raw.to(tl.float32)
        else:
            raw = xval
            val = xval.to(tl.float32)
        val = tl.where(mask, val, 0.0)
        acc += tl.sum(val * val, axis=0)

    rsigma = tl.rsqrt(acc / n + eps)
    out_n = n * (2 if FUSED else 1)
    for chunk in range(CHUNKS):
        col = chunk * BLOCK + cols
        mask = col < n
        xval = tl.load(x_ptr + row * n + col, mask=mask, other=0.0)
        if FUSED:
            rval = tl.load(residual_ptr + row * n + col, mask=mask, other=0.0)
            raw = xval + rval
            val = raw.to(tl.float32)
        else:
            raw = xval
            val = xval.to(tl.float32)
        weight = tl.load(w_ptr + col, mask=mask, other=0.0).to(tl.float32)
        y = (val * rsigma) * weight
        y_ptr = out_ptr + row * out_n + col
        tl.store(y_ptr, y, mask=mask)
        if FUSED:
            r_ptr = out_ptr + row * out_n + n + col
            tl.store(r_ptr, raw, mask=mask)


def _rmsnorm_forward_triton(x, weight, residual, fused, eps):
    m, n = x.shape
    out_n = 2 * n if fused else n
    out = torch.empty((m, out_n), device=x.device, dtype=x.dtype)
    block = 4096
    chunks = (n + block - 1) // block
    _rmsnorm_row_kernel[(m,)](
        x, weight, residual, out, n, eps,
        BLOCK=block, CHUNKS=chunks, FUSED=fused,
        num_warps=4, enable_fp_fusion=False,
    )
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """RMSNorm forward family: standard RMSNorm and residual-fused
    (fused residual-add) RMSNorm.

    For each row of an (M, N) input, the normalization is computed in float32 as
    defined below:
        mean_sq = sum_i x_i^2 / N
        rsigma  = rsqrt(mean_sq + eps)
        y_i     = x_i * rsigma * w_i
    where w is the per-channel scale vector. The __init__ parameter `variant`
    selects one of two paths:
        "fused_add": first compute residual_out = x + residual in the input dtype
        (the residual stream passes straight through to the output), then apply the
        RMSNorm above to residual_out;
        "rmsnorm"  : apply the RMSNorm directly to x; residual takes no part in the
        computation (its content is arbitrary and may be garbage data).
    forward returns a single tensor out (same dtype as x): with fused_add it is
    (M, 2N) with the first N columns equal to y and the last N columns equal to
    residual_out (the two logical outputs concatenated along the last dimension);
    with rmsnorm it is (M, N), i.e. y.
    Boundary behaviour: for an all-zero row mean_sq = 0, so rsigma = rsqrt(eps)
    (eps guarantees no division by zero); N is arbitrary (including 1,
    non-powers-of-two, sizes not multiple of 16, and large N beyond a single
    block's reduction capacity) and must all be handled correctly with masking / a
    blocked reduction, and out-of-range elements at the row tail must not
    contribute to the sum of squares.

    Input/output specification:
        x        float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        weight   same dtype as x, (N,), contiguous
        residual same dtype as x, (M, N), contiguous (ignored when variant="rmsnorm")
        out      a single tensor, same dtype as x: (M, 2N) with fused_add (first N
                 columns y, last N columns residual_out), (M, N) with rmsnorm (i.e. y)
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (residual add, per-row sum-of-squares reduction,
          rsqrt, element-wise scaling) must be completed with a Triton kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The sum-of-squares accumulation and the normalization run in float32; y is
          cast back to the input dtype; residual_out is added in the input dtype and
          written out as-is.
        - forward returns the single tensor `out` (the evaluator compares a single
          output); with fused_add the residual_out column block must be bit-identical
          to x + residual in the input dtype.

    Forbidden list: aiter / torch.rms_norm / torch.nn.functional.rms_norm /
    torch.nn.RMSNorm / torch.layer_norm / torch.nn.functional.layer_norm /
    torch.nn.LayerNorm / torch.norm / torch.linalg.norm /
    torch.linalg.vector_norm.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, variant: str = "fused_add", eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("rmsnorm", "fused_add"), "variant must be one of rmsnorm / fused_add"
        self.variant = variant
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, residual):
        # <<<IMPROVE:forward_stmt_1>>>
        fused = self.variant == "fused_add"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        out = _rmsnorm_forward_triton(x, weight, residual, fused, self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # The Triton kernel writes the residual output directly.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # Input conversion to float32 is performed inside the Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # Weight conversion to float32 is performed inside the Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # The masked row-wise sum-of-squares reduction is performed inside Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # Triton computes and writes the normalized values directly into out.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return out
        # <<<END_IMPROVE>>>
