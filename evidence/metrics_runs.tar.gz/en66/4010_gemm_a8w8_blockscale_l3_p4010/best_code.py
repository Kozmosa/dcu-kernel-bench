import torch
import torch.nn as nn
import torch.nn.functional as F

# <<<IMPROVE:helpers>>>
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """8bit GEMM with 2D block-scale dequantization (fp8 activations x fp8
    weights).

    Mathematical definition: given the fp8(e4m3) code-word matrices xq (M, K),
    wq (N, K) and the float32 block scales x_scale (M, ceil(K/gk)),
    w_scale (ceil(N/gn), ceil(K/gk)), the output is
      dq_x[m, k] = xq[m, k] * x_scale[m, k // gk]
      dq_w[n, k] = wq[n, k] * w_scale[n // gn, k // gk]
      acc[m, n]  = sum_k dq_x[m, k] * dq_w[n, k]     (float32 accumulation)
      out[m, n]  = cast(acc[m, n], out_dtype)
    That is, every element is first dequantized with the block scale it belongs
    to ((m, k//gk) / (n//gn, k//gk)), then a float32 GEMM is performed
    (equivalent to the transposed GEMM xq @ wq^T, with wq row-major (N, K)).
    Scale ownership is decided element by element and is independent of the
    K-direction tile partition; when K is not divisible by gk / N is not
    divisible by gn, elements of the tail block still use the scale of the
    block they belong to (the scale count is the ceil division result); M/N/K
    >= 1, non-powers of two allowed. The dequantization multiply and the GEMM
    accumulation run in float32 throughout, and the output is finally cast to
    out_dtype.

    Input/output specification:
      x       float8_e4m3fn (M, K)             activation code words (row-major, TN layout)
      w       float8_e4m3fn (N, K)             weight code words (row-major, transposed GEMM)
      x_scale float32 (M, ceil(K/gk))          activation scale: per-M-row, K in gk blocks
      w_scale float32 (ceil(N/gn), ceil(K/gk)) weight 2D block scale (rows = N blocks, cols = K blocks)
      out     out_dtype (M, N)                 bfloat16 / float16, set by __init__
    The online evaluator casts every input to fp32 before calling forward; the
    finite values of fp8(e4m3) are exact in fp32, so the
    .to(torch.float8_e4m3fn) at the entry point recovers the code words
    losslessly.

    Final-audit compatible form: the offline final-audit harness constructs the
    model with a single argument Model(case["head_size"])
    (case["head_size"] = [group_k, group_n, out_dtype]), so the first __init__
    argument also accepts a [group_k, group_n, out_dtype] sequence and unpacks
    it in order; ModelNew must keep the same dual-form compatibility
    (constructible with either three arguments or a single sequence).

    Implementation constraints (violations are scored as failures):
      - The core computation (8bit GEMM accumulation + block-scale
        dequantization) must be completed inside the submitted file, and
        calling any ATen matmul shortcut is forbidden: torch.matmul /
        torch.bmm / torch.mm / torch.addmm / torch.einsum / torch._int_mm /
        torch._scaled_mm / F.linear / functional.linear, together with their
        torch.ops.aten.* fully qualified names and tensor-method forms
        (torch.ops.aten.mm, .mm( / .bmm( / .matmul( / .addmm( / .einsum( /
        ._int_mm( / ._scaled_mm( etc.), the matmul operator @ and the tensor
        transpose method .t() (x @ w.t() is the typical disguised form; the
        transpose should be handled with strides inside the kernel). The
        final-audit static audit scans the submitted file for those literal
        strings (docstrings excluded).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast to
        out_dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: a single matrix (no batch dimension), no bias, no splitK; the
    code-word and scale value ranges follow the task generator (code words are
    fp8 values in [0, 0.1), scales are float32 in [0, 1)).
    """
    def __init__(self, group_k=128, group_n=128, out_dtype="bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        if isinstance(group_k, (list, tuple)):
            group_k, group_n, out_dtype = group_k
        self.group_k = int(group_k)
        self.group_n = int(group_n)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, x, w, x_scale, w_scale):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.to(torch.float8_e4m3fn)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        w = w.to(torch.float8_e4m3fn)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        gk, gn = self.group_k, self.group_n
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = w.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == w.shape[1], "the K dimension of x and w must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        scale_k = (K + gk - 1) // gk
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        scale_n = (N + gn - 1) // gn
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert x_scale.shape == (M, scale_k), \
            f"x_scale shape should be ({M}, {scale_k}), got {tuple(x_scale.shape)}"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert w_scale.shape == (scale_n, scale_k), \
            f"w_scale shape should be ({scale_n}, {scale_k}), got {tuple(w_scale.shape)}"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        k_idx = torch.arange(K, device=x.device) // gk
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        n_idx = torch.arange(N, device=x.device) // gn
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        xs = x_scale[:, k_idx]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        ws = w_scale[n_idx[:, None], k_idx[None, :]]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        dq_x = x.to(torch.float32) * xs
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        dq_w = w.to(torch.float32) * ws
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        out = F.linear(dq_x, dq_w)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return out.to(self.out_dtype)
        # <<<END_IMPROVE>>>
