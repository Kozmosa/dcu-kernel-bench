import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p8003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor scatter_nd(torch::Tensor data, torch::Tensor indices, torch::Tensor updates);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("scatter_nd", &scatter_nd, "HIP ScatterND");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <cstdint>

struct ScatterShape {
    int64_t v[6];
};

__global__ void copy_bytes_kernel(const unsigned char* src, unsigned char* dst,
                                  int64_t n, int64_t width) {
    int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        int64_t base = i * width;
        for (int64_t b = 0; b < width; ++b) dst[base + b] = src[base + b];
    }
}

template <typename IndexT>
__global__ void overwrite_kernel(const IndexT* indices, const unsigned char* updates,
                                 unsigned char* out, int64_t k, int rank,
                                 ScatterShape shape, int64_t width) {
    int64_t row = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (row < k) {
        int64_t offset = 0;
        int64_t base = row * rank;
        for (int d = 0; d < rank; ++d) {
            int64_t coord = (int64_t)indices[base + d];
            offset = offset * shape.v[d] + coord;
        }
        int64_t dst_base = offset * width;
        int64_t src_base = row * width;
        for (int64_t b = 0; b < width; ++b) out[dst_base + b] = updates[src_base + b];
    }
}

template <typename IndexT>
__global__ void fused_single_kernel(const IndexT* indices, const unsigned char* data,
                                    const unsigned char* updates, unsigned char* out,
                                    int64_t n, int rank, ScatterShape shape,
                                    int64_t width) {
    int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        int64_t offset = 0;
        for (int d = 0; d < rank; ++d) {
            int64_t coord = (int64_t)indices[d];
            offset = offset * shape.v[d] + coord;
        }
        const unsigned char* src = (i == offset) ? updates : data + i * width;
        unsigned char* dst = out + i * width;
        for (int64_t b = 0; b < width; ++b) dst[b] = src[b];
    }
}

static inline void check_hip(hipError_t e) {
    TORCH_CHECK(e == hipSuccess, "HIP launch failed: ", hipGetErrorString(e));
}

torch::Tensor scatter_nd(torch::Tensor data, torch::Tensor indices, torch::Tensor updates) {
    TORCH_CHECK(data.is_cuda() && indices.is_cuda() && updates.is_cuda(), "inputs must be on HIP device");
    TORCH_CHECK(data.is_contiguous() && indices.is_contiguous() && updates.is_contiguous(), "inputs must be contiguous");
    TORCH_CHECK(data.dim() >= 1 && data.dim() <= 6, "rank must be between 1 and 6");
    TORCH_CHECK(indices.dim() == 2 && indices.size(1) == data.dim(), "invalid index shape");
    TORCH_CHECK(updates.dim() == 1 && updates.size(0) == indices.size(0), "invalid update shape");
    TORCH_CHECK(indices.scalar_type() == at::kLong || indices.scalar_type() == at::kFloat, "indices must be int64 or float32");

    at::DeviceGuard device_guard(data.device());
    auto out = torch::empty_like(data);
    const int rank = (int)data.dim();
    const int64_t n = data.numel();
    const int64_t k = indices.size(0);
    const int64_t width = data.element_size();
    ScatterShape shape{};
    for (int d = 0; d < rank; ++d) shape.v[d] = data.size(d);

    hipStream_t stream = at::cuda::getCurrentCUDAStream(data.device().index()).stream();
    constexpr int threads = 256;

    if (k == 1) {
        int blocks = (int)((n + threads - 1) / threads);
        if (indices.scalar_type() == at::kLong) {
            hipLaunchKernelGGL((fused_single_kernel<int64_t>), dim3(blocks), dim3(threads), 0, stream,
                               indices.data_ptr<int64_t>(),
                               (const unsigned char*)data.data_ptr(),
                               (const unsigned char*)updates.data_ptr(),
                               (unsigned char*)out.data_ptr(), n, rank, shape, width);
        } else {
            hipLaunchKernelGGL((fused_single_kernel<float>), dim3(blocks), dim3(threads), 0, stream,
                               indices.data_ptr<float>(),
                               (const unsigned char*)data.data_ptr(),
                               (const unsigned char*)updates.data_ptr(),
                               (unsigned char*)out.data_ptr(), n, rank, shape, width);
        }
        check_hip(hipGetLastError());
        return out;
    }

    if (k != n) {
        int blocks = (int)((n + threads - 1) / threads);
        hipLaunchKernelGGL(copy_bytes_kernel, dim3(blocks), dim3(threads), 0, stream,
                           (const unsigned char*)data.data_ptr(),
                           (unsigned char*)out.data_ptr(), n, width);
        check_hip(hipGetLastError());
    }

    int blocks = (int)((k + threads - 1) / threads);
    if (indices.scalar_type() == at::kLong) {
        hipLaunchKernelGGL((overwrite_kernel<int64_t>), dim3(blocks), dim3(threads), 0, stream,
                           indices.data_ptr<int64_t>(),
                           (const unsigned char*)updates.data_ptr(),
                           (unsigned char*)out.data_ptr(), k, rank, shape, width);
    } else {
        hipLaunchKernelGGL((overwrite_kernel<float>), dim3(blocks), dim3(threads), 0, stream,
                           indices.data_ptr<float>(),
                           (const unsigned char*)updates.data_ptr(),
                           (unsigned char*)out.data_ptr(), k, rank, shape, width);
    }
    check_hip(hipGetLastError());
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """ScatterND: the index-write family that overwrites positions of `data`
    with `updates` according to integer index tuples.

    Semantics: data has shape (S_0, ..., S_{r-1}) where r is its rank; indices is
    an int64 tensor of shape (K, r) -- each row is a full coordinate tuple that
    picks exactly one position in data; updates has shape (K,) and the same dtype
    as data. The output out has the same shape and dtype as data:
        out[indices[k,0], ..., indices[k,r-1]] = updates[k]
            (hit positions: overwritten, the original value is discarded and
             replaced by the corresponding element of updates)
        all other positions out[i_0, ..., i_{r-1}] = data[i_0, ..., i_{r-1}]
            (misses: the original value is preserved bit-for-bit)
    The write semantics is overwrite, not accumulate; the K coordinate tuples are
    pairwise distinct (the generator samples without replacement), so every data
    element is written at most once. Which write wins for duplicate coordinate
    tuples is undefined behaviour (mainstream frameworks leave the write order
    for duplicate indices undefined either way), and duplicate tuples are outside
    this task's input domain -- the implementation need not define behaviour for
    them, and must not let deduplication / sorting or any other preprocessing
    change the overwrite result for distinct tuples.

    Input/output specification:
        data    float32 / float16 / bfloat16, contiguous, ndim in [1, 6],
                every dimension >= 1, total element count <= 2^23; values are
                ordinary randn magnitude (no inf/NaN)
        indices int64 (K, r) with r = data rank, 1 <= K <= the total element
                count of data; every index value lies in [0, S_d) and the K
                coordinate tuples are pairwise distinct
        updates same dtype as data, shape (K,), contiguous
        out     a single tensor, same shape / dtype as data, contiguous -- this
                operator is naturally single-output, so no multi-output packing is
                needed. forward must return a single tensor (the evaluator
                compares .shape / allclose on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (indices are small non-negative integers < 2^24 and exactly
        representable in fp32, so they are recovered losslessly; fp16/bf16 ->
        fp32 is also lossless). The offline final audit passes inputs natively in
        their declared dtype -- the implementation must be correct for both.

    Boundary behaviour: K=1, K equal to the total element count of data (a full
    permutation, every element written), ndim=1 (indices shaped (K, 1)), and
    shapes with non-power-of-two / prime lengths or axes of length 1 must all be
    handled correctly; the output must be a fresh tensor and must not modify
    data / indices / updates in place.

    Implementation constraints (violations are scored as failures):
        - The core computation (r-dimensional coordinate -> linear offset address
          computation, reading updates, and moving the original values out for
          miss positions) must be completed with a HIP kernel inside the
          submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Pure-movement contract: miss positions match data bit-for-bit and hit
          positions match updates bit-for-bit (bit patterns preserved); no
          numeric transformation may be introduced.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.scatter / .scatter( / .scatter_( / scatter_add / scatter_reduce /
    index_put / torch.put( / .put_( / index_copy / torch_scatter / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
    regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h>
    is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, data, indices, updates):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().scatter_nd(data, indices, updates)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return out
        # <<<END_IMPROVE>>>
