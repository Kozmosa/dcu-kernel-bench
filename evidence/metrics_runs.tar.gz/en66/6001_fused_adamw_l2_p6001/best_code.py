import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p6001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor adamw_update(torch::Tensor params, torch::Tensor grads,
    torch::Tensor exp_avg, torch::Tensor exp_avg_sq, torch::Tensor step,
    double lr, double beta1, double beta2, double eps, double weight_decay,
    bool bias_correction);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("adamw_update", &adamw_update);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cstdint>
#include <cmath>

__device__ __forceinline__ float load_value(const void* ptr, int64_t i, bool half) {
    return half ? static_cast<float>(static_cast<const c10::Half*>(ptr)[i])
                : static_cast<const float*>(ptr)[i];
}

template<int ElementsPerThread, bool BiasCorrection, bool AllFloat32>
__global__ void adamw_kernel(
    const void* params, const void* grads, const void* avg, const void* sq,
    const float* step, void* out, int64_t n,
    bool ph, bool gh, bool mh, bool vh,
    float lr, float b1, float b2, float c1, float c2, float decay,
    float eps) {
#pragma clang fp contract(off)
    int64_t base = static_cast<int64_t>(blockIdx.x) * (ElementsPerThread * blockDim.x) + threadIdx.x;
    if (base >= n) return;
    float bc1 = 1.0f;
    float bc2 = 1.0f;
    if constexpr (BiasCorrection) {
        float s = *step;
        bc1 = 1.0f - powf(b1, s);
        bc2 = 1.0f - powf(b2, s);
    }
#pragma unroll
    for (int e = 0; e < ElementsPerThread; ++e) {
        int64_t i = base + e * blockDim.x;
        if (i < n) {
            float pv, g, mv, vv;
            if constexpr (AllFloat32) {
                pv = static_cast<const float*>(params)[i];
                g = static_cast<const float*>(grads)[i];
                mv = static_cast<const float*>(avg)[i];
                vv = static_cast<const float*>(sq)[i];
            } else {
                pv = load_value(params, i, ph);
                g = load_value(grads, i, gh);
                mv = load_value(avg, i, mh);
                vv = load_value(sq, i, vh);
            }
            float p = pv * decay;
            float m = b1 * mv + c1 * g;
            float v = b2 * vv + (c2 * g) * g;
            float update;
            if constexpr (BiasCorrection) {
                update = (m / bc1) / (sqrtf(v / bc2) + eps);
            } else {
                update = m / (sqrtf(v) + eps);
            }
            float result = p - lr * update;
            if constexpr (AllFloat32) {
                static_cast<float*>(out)[i] = result;
            } else {
                if (ph) static_cast<c10::Half*>(out)[i] = static_cast<c10::Half>(result);
                else static_cast<float*>(out)[i] = result;
            }
        }
    }
}

template<int ElementsPerThread, bool BiasCorrection, bool AllFloat32>
void launch_adamw(const torch::Tensor& params, const torch::Tensor& grads,
    const torch::Tensor& exp_avg, const torch::Tensor& exp_avg_sq,
    const torch::Tensor& device_step, torch::Tensor& out, int64_t n,
    hipStream_t stream, double lr, double beta1, double beta2,
    double eps, double weight_decay) {
    constexpr int coverage = ElementsPerThread * 256;
    hipLaunchKernelGGL((adamw_kernel<ElementsPerThread, BiasCorrection, AllFloat32>),
        dim3((n + coverage - 1) / coverage), dim3(256), 0,
        stream, params.data_ptr(), grads.data_ptr(), exp_avg.data_ptr(),
        exp_avg_sq.data_ptr(), device_step.data_ptr<float>(), out.data_ptr(), n,
        params.scalar_type() == at::kHalf, grads.scalar_type() == at::kHalf,
        exp_avg.scalar_type() == at::kHalf, exp_avg_sq.scalar_type() == at::kHalf,
        static_cast<float>(lr), static_cast<float>(beta1), static_cast<float>(beta2),
        static_cast<float>(1.0 - beta1), static_cast<float>(1.0 - beta2),
        static_cast<float>(1.0 - lr * weight_decay), static_cast<float>(eps));
}

torch::Tensor adamw_update(torch::Tensor params, torch::Tensor grads,
    torch::Tensor exp_avg, torch::Tensor exp_avg_sq, torch::Tensor step,
    double lr, double beta1, double beta2, double eps, double weight_decay,
    bool bias_correction) {
    TORCH_CHECK(params.is_cuda(), "params must be on a HIP device");
    c10::cuda::CUDAGuard guard(params.device());
    for (const auto& t : {params, grads, exp_avg, exp_avg_sq}) {
        TORCH_CHECK(t.device() == params.device() && t.is_contiguous(),
                    "state tensors must be contiguous and on the same device");
        TORCH_CHECK(t.sizes() == params.sizes(), "state shapes must match");
        TORCH_CHECK(t.scalar_type() == at::kFloat || t.scalar_type() == at::kHalf,
                    "state dtype must be float32 or float16");
    }
    TORCH_CHECK(step.numel() == 1 && step.scalar_type() == at::kFloat,
                "step must be a float32 scalar");
    auto device_step = step.to(params.device());
    auto out = torch::empty_like(params);
    int64_t n = params.numel();
    if (n == 0) return out;
    auto stream = c10::cuda::getCurrentCUDAStream(params.get_device());
    bool all_float32 = params.scalar_type() == at::kFloat &&
        grads.scalar_type() == at::kFloat && exp_avg.scalar_type() == at::kFloat &&
        exp_avg_sq.scalar_type() == at::kFloat;
#define LAUNCH_ADAMW(E, B, F) launch_adamw<E, B, F>(params, grads, exp_avg, exp_avg_sq, device_step, out, n, stream.stream(), lr, beta1, beta2, eps, weight_decay)
    if (n >= 4096) {
        if (bias_correction) {
            if (all_float32) { LAUNCH_ADAMW(8, true, true); }
            else { LAUNCH_ADAMW(8, true, false); }
        } else {
            if (all_float32) { LAUNCH_ADAMW(8, false, true); }
            else { LAUNCH_ADAMW(8, false, false); }
        }
    } else {
        if (bias_correction) {
            if (all_float32) { LAUNCH_ADAMW(1, true, true); }
            else { LAUNCH_ADAMW(1, true, false); }
        } else {
            if (all_float32) { LAUNCH_ADAMW(1, false, true); }
            else { LAUNCH_ADAMW(1, false, false); }
        }
    }
#undef LAUNCH_ADAMW
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "AdamW HIP launch failed: ", hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Fused AdamW optimizer family: a single functional (out-of-place) parameter
    update for standard AdamW and for Transformer-schedule AdamW.

    (1) Operator semantics: the __init__ hyper-parameters lr, beta1, beta2, eps,
    weight_decay are construction constants, and `variant` selects one of two
    update paths. Let `step` be a 0-dimensional float32 scalar tensor (the
    current iteration count). The four state tensors params / grads / exp_avg /
    exp_avg_sq have the same shape and are element-wise aligned; the whole update
    is computed in float32 (inputs are promoted to float32 first):
        1) decoupled weight decay (the AdamW form, applied in both variants --
           equivalent to p = params - lr * weight_decay * params, not L2
           regularization):
               p = params * (1 - lr * weight_decay)
        2) first moment: m = beta1 * exp_avg + (1 - beta1) * grads
        3) second moment: v = beta2 * exp_avg_sq + (1 - beta2) * grads^2
        4) variant="adamw" (standard AdamW, bias correction ON):
               bc1 = 1 - beta1^step; bc2 = 1 - beta2^step
               out = p - lr * (m / bc1) / (sqrt(v / bc2) + eps)
           variant="transformer_adamw" (Transformer schedule, bias correction
           OFF -- the only difference between the two variants):
               out = p - lr * m / (sqrt(v) + eps)
    The two variants are line-by-line identical apart from bias correction; eps is
    added outside the sqrt (denom = sqrt(...) + eps); the power beta^step is a
    float32 scalar power.
    Boundary behaviour: at step=1, bc1 = 1 - beta1 and bc2 = 1 - beta2 take their
    minimum values (the standard AdamW path amplifies the most); for very large
    step the two variants converge numerically; exp_avg_sq is always
    non-negative (second-moment constraint, generated in [0, 0.5)) and
    denom >= eps guarantees no division by zero; this operator has no reduction
    and no indexing -- it is a pure element-wise map.

    (2) Input/output specification:
      - params / grads / exp_avg / exp_avg_sq: float32 or float16 tensors, all
        with the same shape (ndim 1-4, numel >= 1, including non-power-of-two and
        boundary sizes), contiguous;
      - step: a 0-dimensional float32 scalar tensor (numel == 1) whose value is a
        positive-integer-semantics step count (>= 1);
      - returns: the updated parameters, a new tensor with the same shape and
        dtype as params (single-tensor output, out-of-place; no input may be
        modified in place, and no state such as exp_avg / exp_avg_sq may be
        returned).

    (3) Implementation constraints (violations are scored as failures):
      - The core computation (decoupled weight decay, first/second moment update,
        bias-correction power, sqrt, element-wise update) must be completed with a
        HIP kernel inside the submitted file;
      - out-of-place: params / grads / exp_avg / exp_avg_sq must not be modified
        in place;
      - the __init__ and forward signatures of ModelNew must not be changed;
      - intermediate computation uses float32 (fp16 inputs are promoted to
        float32 as well), and the final result is cast back to the dtype of
        params;
      - step arrives as a 0-dimensional tensor and participates in the power
        operation as a scalar inside the kernel; it must not be materialized into
        a temporary tensor of the same shape as params.

    (4) Forbidden list and target hardware:
      - the whole torch.optim family is forbidden (torch.optim.AdamW / Adam /
        SGD / ... plus their _functional / _multi_tensor internal paths);
      - any fused-optimizer library and closed-source entry point is forbidden:
        apex / deepspeed / bitsandbytes / the fused_adam entry-point family /
        hipdnn / miopen;
      - completing this task via an ATen shortcut is forbidden: torch.addcdiv /
        torch.addcmul (including the .addcdiv / .addcdiv_ / .addcmul / .addcmul_
        tensor methods and in-place forms, which finish the parameter update or
        the moment update in a single call); the multi-tensor primitives
        torch._foreach_addcdiv / torch._foreach_addcmul are equally forbidden
        (including their in-place _ forms, which complete the core update step in
        a single call) (the final static audit does substring matching on code
        outside docstrings/comments);
      - target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
        (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
        regions; device code must include <hip/hip_runtime.h> --
        <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "adamw", lr: float = 1e-3, beta1: float = 0.9, beta2: float = 0.999, eps: float = 1e-8, weight_decay: float = 0.01):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("adamw", "transformer_adamw"), \
            "variant must be one of adamw / transformer_adamw"
        self.variant = variant
        self.lr = float(lr)
        self.beta1 = float(beta1)
        self.beta2 = float(beta2)
        self.eps = float(eps)
        self.weight_decay = float(weight_decay)
        # <<<END_IMPROVE>>>

    def forward(self, params, grads, exp_avg, exp_avg_sq, step):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().adamw_update(
            params, grads, exp_avg, exp_avg_sq, step,
            self.lr, self.beta1, self.beta2, self.eps, self.weight_decay,
            self.variant == "adamw",
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        g = grads.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        m = exp_avg.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        v = exp_avg_sq.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        s = step.to(torch.float32) if torch.is_tensor(step) \
            else torch.tensor(float(step))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        p = p * (1.0 - self.lr * self.weight_decay)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        m = self.beta1 * m + (1.0 - self.beta1) * g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        v = self.beta2 * v + (1.0 - self.beta2) * g * g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if self.variant == "adamw":
            # standard AdamW: bias correction ON
            bc1 = 1.0 - torch.pow(self.beta1, s)
            bc2 = 1.0 - torch.pow(self.beta2, s)
            denom = torch.sqrt(v / bc2) + self.eps
            update = (m / bc1) / denom
        else:
            # transformer_adamw: bias correction OFF (the only difference)
            denom = torch.sqrt(v) + self.eps
            update = m / denom
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return (p - self.lr * update).to(params.dtype)
        # <<<END_IMPROVE>>>
