import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _paged_prefill(Q, K, V, KC, VC, BT, QS, SL, O,
                   qst, kst, vst, kcst, vcst, bst, ost,
                   qss: tl.constexpr, sls: tl.constexpr,
                   D: tl.constexpr, G: tl.constexpr, BS: tl.constexpr,
                   X: tl.constexpr, SCALE: tl.constexpr, BD: tl.constexpr,
                   BM: tl.constexpr, BN: tl.constexpr):
    tile = tl.program_id(0)
    h = tl.program_id(1)
    b = tl.program_id(2)
    start = tl.load(QS + b * qss)
    end = tl.load(QS + (b + 1) * qss)
    length = end - start
    if tile * BM >= length:
        return
    ctx = tl.load(SL + b * sls) - length
    kh = h // G
    r = tile * BM + tl.arange(0, BM)
    d = tl.arange(0, BD)
    n = tl.arange(0, BN)
    q = tl.load(Q + (start + r[:, None]).to(tl.int64) * qst[0]
                + h * qst[1] + d[None, :] * qst[2],
                (r[:, None] < length) & (d[None, :] < D), 0)
    m = tl.full((BM,), -float('inf'), tl.float32)
    z = tl.zeros((BM,), tl.float32)
    acc = tl.zeros((BM, BD), tl.float32)
    limit = ctx + tl.minimum((tile + 1) * BM, length)
    for base in range(0, limit, BN):
        l = base + n
        prefix = (l < ctx) & (l < limit)
        fresh = (l >= ctx) & (l < limit)
        pb = tl.load(BT + b * bst[0] + (l // BS) * bst[1], prefix, 0).to(tl.int64)
        slot = l % BS
        ck = tl.load(KC + pb[None, :] * kcst[0] + kh * kcst[1]
                     + (d[:, None] // X) * kcst[2]
                     + slot[None, :] * kcst[3] + (d[:, None] % X) * kcst[4],
                     prefix[None, :] & (d[:, None] < D), 0)
        nk = tl.load(K + (start + l[None, :] - ctx).to(tl.int64) * kst[0]
                     + kh * kst[1] + d[:, None] * kst[2],
                     fresh[None, :] & (d[:, None] < D), 0)
        keys = tl.where(prefix[None, :], ck, nk)
        logits = tl.dot(q, keys).to(tl.float32) * SCALE
        valid = (r[:, None] < length) & (l[None, :] < limit) & (l[None, :] <= ctx + r[:, None])
        logits = tl.where(valid, logits, -float('inf'))
        next_m = tl.maximum(m, tl.max(logits, 1))
        safe_m = tl.where(r < length, next_m, 0.0)
        alpha = tl.exp(m - safe_m)
        p = tl.exp(logits - safe_m[:, None])
        z = z * alpha + tl.sum(p, 1)
        cv = tl.load(VC + pb[:, None] * vcst[0] + kh * vcst[1]
                     + d[None, :] * vcst[2] + slot[:, None] * vcst[3],
                     prefix[:, None] & (d[None, :] < D), 0)
        nv = tl.load(V + (start + l[:, None] - ctx).to(tl.int64) * vst[0]
                     + kh * vst[1] + d[None, :] * vst[2],
                     fresh[:, None] & (d[None, :] < D), 0)
        vals = tl.where(prefix[:, None], cv, nv)
        acc = acc * alpha[:, None]
        acc = tl.dot(p.to(vals.dtype), vals, acc)
        m = next_m
    result = acc / tl.where(z > 0, z, 1.0)[:, None]
    tl.store(O + (start + r[:, None]).to(tl.int64) * ost[0]
             + h * ost[1] + d[None, :] * ost[2], result,
             (r[:, None] < length) & (d[None, :] < D))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Chunked prefill / decode mixed-batch attention over a paged KV cache (MHA and GQA, causal mask).

    The batch holds num_seqs sequences running in parallel; sequence b computes
    query_len[b] = query_start_loc[b+1] - query_start_loc[b] new query tokens
    this round, and the per-sequence slices are packed back to back along the
    token dimension according to query_start_loc (no padding). Sequence b
    currently has total length seq_lens[b], of which the first
    ctx_len[b] = seq_lens[b] - query_len[b] tokens are already-admitted prefix
    K/V that live only in the paged KV cache; the K/V of this round's new tokens
    are given separately and explicitly as key / value (consistent with the
    corresponding cache slots). A sequence with query_len[b] == 1 is decode,
    > 1 is chunked prefill, and the two kinds may be mixed in the same batch.

    Paged layout: the physical block pool has num_blocks blocks, each holding
    block_size token slots; block_tables[b] is that sequence's "logical block ->
    physical block number" table, covering the whole seq_lens[b] (including this
    round's new tokens). K uses a channel-packed layout: K[tok, h, d] lives at
    key_cache[pblk, h, d // x, tok % block_size, d % x] (x = 8, head_size is a
    multiple of 8); V is value_cache[pblk, h, d, tok % block_size]. Blocks of the
    pool that no block table references, and slots past a sequence's valid
    length, hold garbage data (magnitudes up to +/-10) and must not take part in
    the computation.

    For query head h of sequence b (its KV head is h // query_group_size, where
    query_group_size = num_heads / num_kv_heads) and its j-th new token (absolute
    position within the sequence pos = ctx_len[b] + j):

      logits[l] = scale * <query[pos, h, :], K[l]>,  l = 0 .. seq_lens[b]-1
      causal mask: logits at positions l > pos are set to -inf
      p[l] = exp(logits[l] - max_l logits) / sum_l' exp(logits[l'] - max_l logits)
      out[pos, h, :] = sum_l p[l] * V[l]

    The first ctx_len[b] K / V tokens come from the paged cache (indirectly
    addressed through the block table), the remaining query_len[b] come from
    key / value. softmax uses an online (numerically stable) implementation,
    intermediate accumulation is in float32, and the output is cast back to the
    input dtype.

    Input/output specification (forward parameter order):
      query           [num_tokens, num_heads, head_size]          fp16/bf16
      key             [num_tokens, num_kv_heads, head_size]       same as query
      value           [num_tokens, num_kv_heads, head_size]       same as query
      key_cache       [num_blocks, num_kv_heads, head_size//8, block_size, 8]  same as query
      value_cache     [num_blocks, num_kv_heads, head_size, block_size]        same as query
      block_tables    [num_seqs, max_blocks_per_seq]              int32
      query_start_loc [num_seqs+1] int32 (prefix sum of query_len, first element 0)
      seq_lens        [num_seqs] int32
      output out      [num_tokens, num_heads, head_size], dtype matches query.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / torch.matmul / torch.bmm / torch.einsum / torch.softmax is forbidden
        (the complete forbidden list is defined by the task configuration's
        forbidden field).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: chunked prefill/decode mixed batch, non-quantized KV, no ALiBi,
    no sliding window.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        # Consume the original block table directly on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        query_start_loc = query_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens, num_heads, head_size = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        num_kv_heads = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        block_size = value_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        x = key_cache.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        group = num_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert num_heads == num_kv_heads * group, "num_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        if num_tokens > 0:
                    _paged_prefill[(triton.cdiv(num_tokens, 16), num_heads, seq_lens.shape[0])](
                        query, key, value, key_cache, value_cache, block_tables,
                        query_start_loc, seq_lens, out,
                        query.stride(), key.stride(), value.stride(),
                        key_cache.stride(), value_cache.stride(), block_tables.stride(),
                        out.stride(), query_start_loc.stride(0), seq_lens.stride(0),
                        head_size, group, block_size, x, self.scale,
                        max(16, triton.next_power_of_2(head_size)), 16, 64,
                        num_warps=4, num_stages=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
