import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _online_attention(Q, K, V, A, O, L,
                      QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr, QS3: tl.constexpr,
                      KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr, KS3: tl.constexpr,
                      VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr, VS3: tl.constexpr,
                      AS0: tl.constexpr, AS1: tl.constexpr,
                      SQ: tl.constexpr, SK: tl.constexpr, HQ: tl.constexpr,
                      D: tl.constexpr, G: tl.constexpr, SCALE: tl.constexpr,
                      CAUSAL: tl.constexpr, BD: tl.constexpr,
                      BM: tl.constexpr, BN: tl.constexpr):
    tile = tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // HQ
    h = bh % HQ
    kh = h // G
    i = tile * BM + tl.arange(0, BM)
    d = tl.arange(0, BD)
    n = tl.arange(0, BN)
    q = tl.load(Q + b * QS0 + i[:, None] * QS1 + h * QS2 + d[None, :] * QS3,
                (i[:, None] < SQ) & (d[None, :] < D), other=0)
    slope = tl.load(A + b * AS0 + h * AS1)
    maximum = tl.full((BM,), float('-inf'), tl.float32)
    total = tl.zeros((BM,), tl.float32)
    acc = tl.zeros((BM, BD), tl.float32)
    end = SK
    if CAUSAL:
        end = tl.minimum(SK, tl.maximum(0, (tile + 1) * BM + SK - SQ))
    for start in range(0, end, BN):
        j = start + n
        k = tl.load(K + b * KS0 + j[None, :] * KS1 + kh * KS2 + d[:, None] * KS3,
                    (j[None, :] < SK) & (d[:, None] < D), other=0)
        score = tl.dot(q, k).to(tl.float32) * SCALE
        distance = i[:, None] + SK - SQ - j[None, :]
        score = score - slope * tl.abs(distance).to(tl.float32)
        valid = (i[:, None] < SQ) & (j[None, :] < SK)
        if CAUSAL:
            valid = valid & (distance >= 0)
        score = tl.where(valid, score, float('-inf'))
        new_max = tl.maximum(maximum, tl.max(score, 1))
        safe_max = tl.where(new_max == float('-inf'), 0.0, new_max)
        alpha = tl.exp(maximum - safe_max)
        p = tl.exp(score - safe_max[:, None])
        total = total * alpha + tl.sum(p, 1)
        acc = acc * alpha[:, None]
        v = tl.load(V + b * VS0 + j[:, None] * VS1 + kh * VS2 + d[None, :] * VS3,
                    (j[:, None] < SK) & (d[None, :] < D), other=0)
        acc = tl.dot(p, v.to(tl.float32), acc, input_precision='ieee')
        maximum = new_max
    denom = tl.where(total > 0, total, 1.0)
    result = acc / denom[:, None]
    tl.store(O + ((b * SQ + i[:, None]) * HQ + h) * D + d[None, :],
             result, (i[:, None] < SQ) & (d[None, :] < D))
    lse = tl.where(total > 0, maximum + tl.log(denom), 0.0)
    tl.store(L + bh * SQ + i, lse, i < SQ)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Dense (padded 4D batch) FlashAttention forward: scaled dot-product attention
    with softmax, bottom-right-aligned causal mask, ALiBi positional bias,
    MHA/GQA, returning both the output and the per-row log-sum-exp (LSE).

    Mathematical definition (for batch element b, query head h, query position i,
    key position j, g = num_q_heads // num_kv_heads, query head h maps to KV head
    h // g):
      score[b,h,i,j] = sm_scale * <q[b,i,h,:], k[b,j,h//g,:]>
                       - alibi_slopes[b,h] * |i + seqlen_k - seqlen_q - j|
      With causal=1 the bottom-right-aligned causal mask is applied: positions
      j > i + seqlen_k - seqlen_q are set to -inf (i.e. query i only attends to
      keys j <= i + seqlen_k - seqlen_q); with causal=0 no mask is applied at all.
      The ALiBi bias is applied in both causal and non-causal mode; all-zero
      slopes are equivalent to no ALiBi.
      p[b,h,i,:] = softmax_j(score[b,h,i,:])   (numerically stable online form)
      out[b,i,h,:] = sum_j p[b,h,i,j] * v[b,j,h//g,:]
      lse[b,h,i] = ln( sum_j exp(score[b,h,i,j]) )   (natural logarithm)
    softmax/accumulation are done in float32, out is cast back to the input dtype,
    lse is float32.
    Boundary behaviour: with causal=1 and seqlen_q > seqlen_k, rows
    i < seqlen_q - seqlen_k are masked out entirely -- those rows have out = 0 and
    lse = 0 (not -inf).

    Input/output specification:
      q            [batch, seqlen_q, num_q_heads, head_dim]   float16/bfloat16
      k, v         [batch, seqlen_k, num_kv_heads, head_dim]  same dtype as q
      causal       0-dim int32 tensor, 1=causal mask, 0=no mask
      alibi_slopes [batch, num_q_heads] float32, elements >= 0 (all zeros = no ALiBi)
      Returns a single 1-D tensor packed (multi-output packing protocol):
      packed = cat([out.reshape(-1).to(float32), lse.reshape(-1)])
      where out [batch, seqlen_q, num_q_heads, head_dim] (computed in the input
      dtype, then cast to float32 for the concatenation) and lse
      [batch, num_q_heads, seqlen_q] float32; total length of packed =
      batch * seqlen_q * num_q_heads * (head_dim + 1).
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (equal means MHA, otherwise GQA); 1 <= seqlen_q, 1 <= seqlen_k (any
    combination, including seqlen_q > seqlen_k); 1 <= head_dim <= 256.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / ALiBi bias / causal mask / softmax / PV / LSE)
        must be completed inside the submitted file; calling ready-made attention /
        matrix-multiplication / softmax routines is forbidden:
        scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax / torch.logsumexp, as is any
        synonymous wrapper from a third-party operator library.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast out back to the input
        dtype, keep lse in float32.
      - forward must return a single 1-D float32 tensor following the packing
        protocol above (compute out and lse internally first, then flatten and
        concatenate them).

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: dense 4D forward, non-quantized inputs, no bias, no dropout, no
    sliding window.
    """
    def __init__(self, head_dim: int, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, causal, alibi_slopes):
        # <<<IMPROVE:forward_stmt_1>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        is_causal = bool(int(causal.to(torch.int32)))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        alibi_slopes = alibi_slopes.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        batch, seqlen_q, nheads_q, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        _, seqlen_k, nheads_k, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = nheads_q // nheads_k
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert nheads_q == nheads_k * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty((batch, seqlen_q, nheads_q, head_dim), device=q.device, dtype=q.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        lse = torch.empty((batch, nheads_q, seqlen_q), device=q.device, dtype=torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # Original-layout Q/K/V are read directly by the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _online_attention[(triton.cdiv(seqlen_q, 32), batch * nheads_q)](
            q, k, v, alibi_slopes, out, lse,
            *q.stride(), *k.stride(), *v.stride(), *alibi_slopes.stride(),
            seqlen_q, seqlen_k, nheads_q, head_dim, group, self.sm_scale,
            is_causal, max(16, triton.next_power_of_2(head_dim)), 32, 64,
            num_warps=4, num_stages=1,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Scaling is fused.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Query indices are generated in Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # Key indices are generated in Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # Bottom-right relative positions are computed per tile.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # Absolute-distance ALiBi is fused.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # Bottom-right causal masking is fused.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        # Natural-log LSE is written by the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        # Empty rows are tracked by the online sum.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        # Empty-row LSE is already zero.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        # Online normalization avoids materializing probabilities.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        # Weighted values are accumulated in float32 in Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        # Empty-row outputs are already zero.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        # Output is contiguous [B, Sq, Hq, D] in the input dtype.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        return torch.cat([out.reshape(-1).to(torch.float32), lse.reshape(-1)])
        # <<<END_IMPROVE>>>
