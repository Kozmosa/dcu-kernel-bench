import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """The full fused Mixture-of-Experts (MoE) token feed-forward path: one call
    completes the whole chain "pick experts by routing -> first grouped GEMM ->
    SwiGLU activation -> second grouped GEMM -> routing weighting".

    Operator semantics (mathematical definition and boundary behaviour):
      Inputs: activation a [M, K]; expert weight w1 [E, N, K] for the first FFN
      layer (N = 2*hidden, the first N/2 channels are gate and the last N/2 are
      up), w2 [E, K, N//2] for the second FFN layer; the routing result
      topk_ids [M, top_k] holds the expert ids selected for each token and
      topk_weights [M, top_k] the matching routing weights. For each token m and
      its j-th expert e = topk_ids[m, j]:
        gate[m,j,:] = a[m,:] @ w1[e, :N//2, :].T          # [N//2]
        up[m,j,:]   = a[m,:] @ w1[e, N//2:, :].T          # [N//2]
        h[m,j,:]    = gate * sigmoid(gate) * up           # SwiGLU, SiLU(x)=x*sigmoid(x)
        out[m,j,k]  = topk_weights[m,j] * sum_{n<N//2} h[m,j,n] * w2[e,k,n]
      that is out[m,j,:] = topk_weights[m,j] * (h[m,j,:] @ w2[e].T). The (m, j)
      pairs are mutually independent; the outputs of all top_k slots are written
      to the result, with no merge, sum or normalization across experts.
      Boundary behaviour: N is even; top_k <= E and the topk_ids values lie in
      [0, E); the top_k experts of one token are generated distinct (even should
      a duplicate appear, the pair-independent computation still holds); M and K
      are arbitrary positive integers (1 included, i.e. the GEMV case); routing
      weighting is always enabled.

    Input/output specification:
      forward(a, w1, w2, topk_weights, topk_ids) -> out
        a            [M, K]        bfloat16/float32, row-major contiguous
        w1           [E, N, K]     same dtype as a, row-major contiguous
        w2           [E, K, N//2]  same dtype as a, row-major contiguous
        topk_weights [M, top_k]    same dtype as a, row-major contiguous
        topk_ids     [M, top_k]    int64 (losslessly recoverable after the
                                   evaluator's fp32 cast)
        out          [M, top_k, K] same dtype as a
      __init__(top_k, num_experts): instance metadata only; forward always goes
      by the actual runtime tensor shapes (top_k = topk_ids.shape[1],
      E = w1.shape[0]).

    Implementation constraints (violations are scored as failures):
      - Core computation (both grouped GEMMs, the SwiGLU activation, the routing
        weighting) must be done with a Triton kernel inside the submitted file;
        calling ATen shortcuts such as torch.matmul / torch.mm / torch.bmm /
        torch.baddbmm / torch.addmm / torch.einsum /
        torch.nn.functional.linear / F.linear / torch.nn.functional.silu /
        F.silu / torch.sigmoid / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: non-quantized bfloat16/float32 activations and weights; single
    card; no expert capacity limit, no shared experts, no routing weight
    normalization; the expert dispatch/scheduling strategy (sorted alignment,
    persistent grid, etc.) is up to the implementation and is judged by the
    output tolerance.
    """
    def __init__(self, top_k: int, num_experts: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.top_k = top_k
        self.num_experts = num_experts
        # <<<END_IMPROVE>>>

    def forward(self, a, w1, w2, topk_weights, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, K = a.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        E, N, _ = w1.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        H = N // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert 0 <= int(topk_ids.min()) and int(topk_ids.max()) < E, "topk_ids must fall inside [0, E)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        a32 = a.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        tw32 = topk_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        out = torch.empty((M, top_k, K), dtype=a.dtype, device=a.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        for e in range(E):
            sel = topk_ids == e
            if not sel.any():
                continue
            rows, slots = sel.nonzero(as_tuple=True)            # the (m, j) routed to expert e
            inter = a32[rows] @ w1[e].to(torch.float32).t()     # [T, N] first grouped GEMM
            gate, up = inter[:, :H], inter[:, H:]
            h = gate * torch.sigmoid(gate) * up                 # SwiGLU, float32 throughout
            o = h @ w2[e].to(torch.float32).t()                 # [T, K] second grouped GEMM
            o = o * tw32[rows, slots].unsqueeze(-1)             # routing weighting
            out[rows, slots] = o.to(a.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return out
        # <<<END_IMPROVE>>>
