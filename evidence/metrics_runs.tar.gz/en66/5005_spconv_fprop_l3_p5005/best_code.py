import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5005_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor spconv_fprop(torch::Tensor x, torch::Tensor w, torch::Tensor pairs, torch::Tensor counts, torch::Tensor out);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("spconv_fprop", &spconv_fprop);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

__global__ void pair_forward(const float* __restrict__ x,
                             const float* __restrict__ w,
                             const int* __restrict__ pairs,
                             const int* __restrict__ counts,
                             float* __restrict__ out,
                             int n, int ci, int co, int kv,
                             int64_t ws0, int64_t ws1, int64_t ws2) {
    int64_t id = blockIdx.x;
    int k = id / n;
    int j = id % n;
    if (k >= kv || j >= counts[k]) return;
    int src = pairs[(int64_t)k * n + j];
    int dst = pairs[((int64_t)kv + k) * n + j];

    extern __shared__ float sx[];
    for (int i = threadIdx.x; i < ci; i += blockDim.x) {
        sx[i] = x[(int64_t)src * ci + i];
    }
    __syncthreads();

    int lane = threadIdx.x % 16;
    int group = threadIdx.x / 16;
    for (int o = group; o < co; o += 16) {
        float sum = 0.0f;
        for (int i = lane; i < ci; i += 16) {
            sum = fmaf(sx[i],
                       w[(int64_t)o * ws0 + (int64_t)i * ws1 + (int64_t)k * ws2], sum);
        }
        #pragma unroll
        for (int delta = 8; delta > 0; delta >>= 1)
            sum += __shfl_down(sum, delta, 16);
        if (lane == 0) atomicAdd(out + (int64_t)dst * co + o, sum);
    }
}

torch::Tensor spconv_fprop(torch::Tensor x, torch::Tensor w,
                          torch::Tensor pairs, torch::Tensor counts,
                          torch::Tensor out) {
    TORCH_CHECK(x.is_cuda() && w.is_cuda() && pairs.is_cuda() && counts.is_cuda() && out.is_cuda(), "GPU tensors required");
    TORCH_CHECK(x.scalar_type() == at::kFloat && w.scalar_type() == at::kFloat && out.scalar_type() == at::kFloat, "float32 required");
    TORCH_CHECK(pairs.scalar_type() == at::kInt && counts.scalar_type() == at::kInt, "int32 metadata required");
    TORCH_CHECK(x.is_contiguous() && pairs.is_contiguous() && counts.is_contiguous() && out.is_contiguous(), "contiguous buffers required");
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = at::cuda::getCurrentCUDAStream();
    int n = x.size(0), ci = x.size(1), co = w.size(0), kv = w.size(2);
    TORCH_CHECK(w.size(1) == ci && out.size(1) == co, "shape mismatch");
    auto status = hipMemsetAsync(out.data_ptr<float>(), 0, out.numel() * sizeof(float), stream);
    TORCH_CHECK(status == hipSuccess, "output initialization failed");
    hipLaunchKernelGGL(pair_forward, dim3((uint32_t)((int64_t)n * kv)), dim3(256), ci * sizeof(float), stream,
                      x.data_ptr<float>(), w.data_ptr<float>(), pairs.data_ptr<int>(), counts.data_ptr<int>(),
                      out.data_ptr<float>(), n, ci, co, kv, w.stride(0), w.stride(1), w.stride(2));
    TORCH_CHECK(hipGetLastError() == hipSuccess, "pair kernel launch failed");
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Sparse convolution forward (the gathered form spconv_fprop): a per
    kernel-offset gather-GEMM-scatter forward over the sparse active points,
    driven by an index-pair table (spconv style).

    Semantic definition (out is first initialized to all zeros, then
    accumulated by the formula below):
        for each kernel offset k in [0, kv):
            n_k = indice_num_per_loc[k]
            for each j in [0, n_k):
                in_idx  = indice_pairs[0, k, j]      # input row index in [0, n)
                out_idx = indice_pairs[1, k, j]      # output row index in [0, num_act_out)
                out[out_idx, :] += features[in_idx, :] @ W[:, :, k].T
    i.e. for each index pair, gather the input row and matrix-multiply it with
    the weight matrix of offset k ((n_k, c_in) @ (c_in, c_out)), then
    scatter-accumulate by the output row index into out. The same output row may
    be hit by any number of index pairs (duplicates are allowed within the same
    k), and all of them accumulate with +=.

    The filters layout mapping (must be respected; it comes from the sample's
    as_strided rearrangement): let F be the contiguous (c_out, c_in, kv) tensor
    of the input; the library interprets its storage with strides
    (c_in*kv, 1, c_in), and the mathematical weight W and F satisfy:
        W[o, i, k] = F.reshape(c_out, kv, c_in)[o, k, i]
    which is equivalent to W = F.reshape(c_out, kv, c_in).permute(0, 2, 1)
    (still shaped (c_out, c_in, kv), a pure reinterpretation view for
    contiguous input); the weight matrix of kernel offset k is W[:, :, k],
    shaped (c_out, c_in).

    Boundary behaviour: kernel offsets with n_k = 0 are skipped entirely; when
    all n_k = 0, out stays all-zero; kv = 1 degenerates to a single-offset
    gather-scatter; num_act_out and n are independent of each other (either may
    be the larger one). Index-pair table entries with j >= n_k are padding
    garbage (they may hold any value, including duplicated valid row indices)
    and must be masked out according to indice_num_per_loc -- they must never be
    read into the computation.

    Input/output specification:
        features           float32 / float16 / bfloat16 (n, c_in), contiguous
        filters            same dtype as features (c_out, c_in, kv), contiguous
        indice_pairs       int32 (2, kv, n), contiguous
        indice_num_per_loc int32 (kv,), contiguous
        num_act_out        0-dim integer tensor (the online evaluator casts all
                           input tensors to fp32: integer indices are exact up
                           to 2^24 and are recovered with int(); the shape
                           domain of this task guarantees indices <= 2^24)
        out                a single tensor, same dtype as features
                           (num_act_out, c_out). This operator is inherently
                           single-output, with no multi-output packing segments.
    Dimension domain: n, c_in, c_out, kv, num_act_out >= 1, non-powers-of-two
    allowed; indice_num_per_loc[k] in [0, n]. Input values are ordinary randn
    magnitude (no inf/NaN).

    Implementation constraints (violations are scored as failures):
        - The core computation (gathering by index pair, the matrix
          multiplication with W[:, :, k], the scatter accumulation by output row
          index) must be done with a HIP kernel inside the submitted file; ATen
          is only allowed for non-core operations such as dtype recovery / shape
          cleanup.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate in float32 throughout (fp16/bf16 inputs are first cast
          losslessly to fp32), then cast the result back to the dtype of
          features; padding table entries must not take part in the computation
          (including out-of-bounds reads).
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.sparse / torch.sparse_coo_tensor /
    torch.sparse_csr_tensor / torch.sparse_csc_tensor / torch.sparse_mm /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear / index_add_ /
    torch.index_add / index_put / torch.index_put / scatter_add_ /
    .scatter_( / torch.scatter / segment_reduce / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
    regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h>
    is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, features, filters, indice_pairs, indice_num_per_loc, num_act_out):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        num_act_out = int(num_act_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        c_out, c_in, kv = filters.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        dt = features.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        xf = features.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        wf = filters.to(torch.float32).reshape(c_out, kv, c_in).permute(0, 2, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pairs = indice_pairs.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        counts = indice_num_per_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.zeros(num_act_out, c_out, dtype=torch.float32,
                          device=features.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        out = _pyramidkernel_get_extension().spconv_fprop(xf, wf, pairs, counts, out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out.to(dt)
        # <<<END_IMPROVE>>>
