import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _row_softmax_fused(X, Y, N: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    col = tl.arange(0, BLOCK)
    offset = row * N + col
    values = tl.load(X + offset, mask=col < N, other=-float('inf')).to(tl.float32)
    maximum = tl.max(values, axis=0)
    numerator = tl.exp(values - maximum)
    denominator = tl.sum(numerator, axis=0)
    tl.store(Y + offset, numerator / denominator, mask=col < N)


@triton.jit
def _row_softmax_stream(X, Y, N: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    base = row * N
    lane = tl.arange(0, BLOCK)
    values = tl.load(X + base + lane, mask=lane < N, other=-float('inf')).to(tl.float32)
    maximum = tl.max(values, axis=0)
    denominator = tl.sum(tl.exp(values - maximum), axis=0)
    for start in range(BLOCK, N, BLOCK):
        col = start + lane
        values = tl.load(X + base + col, mask=col < N, other=-float('inf')).to(tl.float32)
        tile_maximum = tl.max(values, axis=0)
        tile_sum = tl.sum(tl.exp(values - tile_maximum), axis=0)
        merged_maximum = tl.maximum(maximum, tile_maximum)
        denominator = denominator * tl.exp(maximum - merged_maximum) + tile_sum * tl.exp(tile_maximum - merged_maximum)
        maximum = merged_maximum
    for start in range(0, N, BLOCK):
        col = start + lane
        values = tl.load(X + base + col, mask=col < N, other=-float('inf')).to(tl.float32)
        result = tl.exp(values - maximum) / denominator
        tl.store(Y + base + col, result, mask=col < N)


def _launch_row_softmax(x, y, m, n):
    if n <= 4096:
        _row_softmax_fused[(m,)](x, y, n, triton.next_power_of_2(n), num_warps=4)
    else:
        _row_softmax_stream[(m,)](x, y, n, 1024, num_warps=4)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """2D row-wise softmax.

    For each row (the last dimension) of an (M, N) input, independently:
        m[i]     = max_j x[i, j]
        z[i, j]  = exp(x[i, j] - m[i])
        y[i, j]  = z[i, j] / sum_j z[i, j]
    Rows are completely independent, and after per-row normalization the elements
    of every row sum to 1. The reference implementation does max / exp / sum
    entirely in float32 and casts the output back to the input dtype.

    Boundary behaviour: N is any positive integer -- when N=1 the row's output is
    always 1; non-power-of-two N and very long rows (longer than a single block's
    capacity) must still give exact results, and out-of-range elements at the row
    tail must not participate in the max and sum reductions; the inputs are
    ordinary randn magnitude (no inf/NaN).

    Input/output specification:
        x   float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        y   same dtype as x, (M, N), the row-wise softmax result
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless); this operator has no integer tensor
        input, so nothing needs restoring.

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-row max reduction, the exp sum reduction,
          and the element-wise normalization) must be completed with a Triton
          kernel inside the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Intermediates (max / sum / exp) are computed in float32; the output is
          cast back to the input dtype.

    Forbidden list: aiter / torch.softmax / torch.nn.functional.softmax /
    torch.nn.Softmax / torch.log_softmax / torch.nn.functional.log_softmax /
    torch.nn.LogSoftmax / torch.special.softmax / torch.special.log_softmax.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # Narrow-row num_warps refinement deferred: helpers is frozen.
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        dt = x.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, N = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        y = torch.empty_like(x)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        _launch_row_softmax(x, y, M, N)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # Triton has already stored the normalized result in y.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        return y.to(dt)
        # <<<END_IMPROVE>>>
