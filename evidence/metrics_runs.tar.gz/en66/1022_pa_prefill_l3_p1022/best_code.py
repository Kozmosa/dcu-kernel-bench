import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _paged_prefill(
    Q, K, V, A, O,
    q_len, ctx_len, scale,
    sq0, sq1, sq2,
    sk0, sk1, sk2,
    sv0, sv1, sv2,
    so0, so1, so2,
    H: tl.constexpr,
    SEQ_LEN: tl.constexpr,
    HEAD_SIZE: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    HAS_ALIBI: tl.constexpr,
):
    pid_m = tl.program_id(0)
    h = tl.program_id(1)
    rows = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    d = tl.arange(0, HEAD_SIZE)
    row_mask = rows < q_len
    q_ptrs = Q + rows[:, None] * sq0 + h * sq1 + d[None, :] * sq2
    q = tl.load(q_ptrs, mask=row_mask[:, None], other=0.0).to(tl.float32) * scale

    m = tl.full((BLOCK_M,), -float("inf"), tl.float32)
    l = tl.zeros((BLOCK_M,), tl.float32)
    acc = tl.zeros((BLOCK_M, HEAD_SIZE), tl.float32)
    pos = ctx_len + rows

    for start in range(0, SEQ_LEN, BLOCK_N):
        cols = start + tl.arange(0, BLOCK_N)
        key_mask = cols < SEQ_LEN
        causal_mask = cols[None, :] <= pos[:, None]
        valid = row_mask[:, None] & key_mask[None, :] & causal_mask

        k_ptrs = K + h * sk0 + d[:, None] * sk2 + cols[None, :] * sk1
        k = tl.load(k_ptrs, mask=key_mask[None, :], other=0.0).to(tl.float32)
        scores = tl.dot(q, k, input_precision="ieee")
        if HAS_ALIBI:
            slope = tl.load(A + h).to(tl.float32)
            scores = scores + slope * (cols[None, :] - pos[:, None])
        scores = tl.where(valid, scores, -float("inf"))
        scores = tl.where(row_mask[:, None], scores, 0.0)

        m_next = tl.maximum(m, tl.max(scores, axis=1))
        alpha = tl.exp(m - m_next)
        beta = tl.exp(scores - m_next[:, None])
        beta = tl.where(valid, beta, 0.0)
        l = l * alpha + tl.sum(beta, axis=1)

        v_ptrs = V + h * sv0 + cols[:, None] * sv1 + d[None, :] * sv2
        v = tl.load(v_ptrs, mask=key_mask[:, None], other=0.0).to(tl.float32)
        acc = acc * alpha[:, None] + tl.dot(beta, v, input_precision="ieee")
        m = m_next

    out = acc / l[:, None]
    o_ptrs = O + rows[:, None] * so0 + h * so1 + d[None, :] * so2
    tl.store(o_ptrs, out, mask=row_mask[:, None])
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Paged KV prefix (context) attention: attention for prefill multi-token queries.

    (MHA/GQA, causal + optional ALiBi.)

    Within a batch, num_seqs sequences run in parallel; sequence b has
    query_len[b] = query_start_loc[b+1] - query_start_loc[b] newly computed query
    tokens in this round, and the slices of all sequences are flattened and
    concatenated along the token dimension in query_start_loc order (no
    padding). The current total length of the sequence is seq_lens[b], of which
    the first ctx_len[b] = seq_lens[b] - query_len[b] tokens are the already
    admitted prefix K/V, stored only in the paged KV cache; the K/V of the new
    tokens of this round are given explicitly only as key / value (the cache
    does not contain the new tokens). query_len[b] > 1 means prefill, and == 1
    is also legal (a single-token query against the pure prefix).

    Paged layout: the physical block pool has num_blocks blocks, each holding
    block_size token slots; block_tables[b] is the "prefix logical block ->
    physical block id" table of that sequence, where only the first
    ceil(ctx_len[b]/block_size) columns are valid (the remaining columns are
    garbage). K uses the channel-packed layout: the K channel d of the l-th
    prefix token is stored at
    key_cache[bt[b, l//block_size], h_kv, d//x, l%block_size, d%x]
    (x = 8, head_size is a multiple of 8); V is stored at
    value_cache[bt[b, l//block_size], h_kv, d, l%block_size]. Blocks in the pool
    that are not referenced, as well as slots beyond the prefix length inside
    referenced blocks, are garbage data (magnitudes up to +/-10) and must not
    participate in the computation.

    For the j-th new token of the h-th query head of sequence b (the
    corresponding KV head is h // query_group_size, query_group_size =
    num_heads / num_kv_heads), at in-sequence absolute position pos =
    ctx_len[b] + j:

      logits[l] = scale * <query[pos, h, :], K[l]> + alibi_slopes[h] * (l - pos)
      causal mask: logits at positions l > pos are set to -inf
      p[l] = exp(logits[l] - max_l' logits[l']) / sum_l' exp(logits[l'] - max_l' logits[l'])
      out[pos, h, :] = sum_{l = 0..pos} p[l] * V[l]

    where K[l] / V[l]: for l < ctx_len[b] they come from the paged cache
    (indirect addressing through the block table), and for l >= ctx_len[b] they
    come from key / value. When alibi_slopes is None no bias term is added (it
    degenerates to the unbiased baseline); when a float32 [num_heads] tensor is
    given, the ALiBi bias is added as in the formula above (the bias is 0 at
    l == pos). The softmax uses an online (numerically stable) implementation,
    intermediate accumulation is in float32, and the output is cast back to the
    input dtype.

    Input/output specification (forward parameter order):
      query           [num_tokens, num_heads, head_size]                    fp16/bf16
      key             [num_tokens, num_kv_heads, head_size]                 same as query
      value           [num_tokens, num_kv_heads, head_size]                 same as query
      key_cache       [num_blocks, num_kv_heads, head_size//8, block_size, 8]   same as query
      value_cache     [num_blocks, num_kv_heads, head_size, block_size]         same as query
      block_tables    [num_seqs, max_blocks_per_seq]                         int32
      query_start_loc [num_seqs+1] int32 (prefix sum of query_len, first element 0)
      seq_lens        [num_seqs] int32
      alibi_slopes    [num_heads] float32, or None (no ALiBi bias)
      returns out     [num_tokens, num_heads, head_size], dtype same as query.
      scale defaults to 1/sqrt(head_size) (given by head_size in __init__).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        torch.matmul / torch.bmm / torch.einsum / torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: prefill multi-token queries, non-quantized KV; includes the ALiBi
    bias variant and the unbiased baseline (alibi_slopes passed as None); does
    not include sliding window, does not include a quantized KV cache, and the
    K/V of the new tokens of this round are not written into the cache.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 0.08838834764831843
        # <<<END_IMPROVE>>>

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens, alibi_slopes=None):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        query_start_loc = query_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        slopes = None if alibi_slopes is None else alibi_slopes.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        num_tokens, num_heads, head_size = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_kv_heads = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        block_size = value_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        x = key_cache.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        group = num_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert num_heads == num_kv_heads * group, "num_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        assert head_size == (head_size // x) * x, "head_size must be an integer multiple of x"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        for b in range(int(seq_lens.shape[0])):
            q_start = int(query_start_loc[b])
            q_len = int(query_start_loc[b + 1]) - q_start
            seq_len = int(seq_lens[b])
            ctx_len = seq_len - q_len
            num_ctx_blocks = (ctx_len + block_size - 1) // block_size
            physical = block_tables[b, :num_ctx_blocks]

            k_ctx = key_cache[physical].permute(1, 0, 3, 2, 4).reshape(
                num_kv_heads, num_ctx_blocks * block_size, head_size)[:, :ctx_len].to(torch.float32)
            v_ctx = value_cache[physical].permute(1, 0, 3, 2).reshape(
                num_kv_heads, num_ctx_blocks * block_size, head_size)[:, :ctx_len].to(torch.float32)

            k_new = key[q_start:q_start + q_len].to(torch.float32).permute(1, 0, 2)
            v_new = value[q_start:q_start + q_len].to(torch.float32).permute(1, 0, 2)
            k_full = torch.cat([k_ctx, k_new], dim=1)
            v_full = torch.cat([v_ctx, v_new], dim=1)

            if group > 1:
                k_full = k_full.repeat_interleave(group, dim=0)
                v_full = v_full.repeat_interleave(group, dim=0)

            q_slice = query[q_start:q_start + q_len]
            o_slice = out[q_start:q_start + q_len]
            slope_ptr = slopes if slopes is not None else query
            _paged_prefill[(triton.cdiv(q_len, 16), num_heads)](
                q_slice,
                k_full,
                v_full,
                slope_ptr,
                o_slice,
                q_len,
                ctx_len,
                self.scale,
                q_slice.stride(0), q_slice.stride(1), q_slice.stride(2),
                k_full.stride(0), k_full.stride(1), k_full.stride(2),
                v_full.stride(0), v_full.stride(1), v_full.stride(2),
                o_slice.stride(0), o_slice.stride(1), o_slice.stride(2),
                H=num_heads,
                SEQ_LEN=seq_len,
                HEAD_SIZE=head_size,
                BLOCK_M=16,
                BLOCK_N=32,
                HAS_ALIBI=slopes is not None,
                num_warps=4,
                num_stages=2,
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return out
        # <<<END_IMPROVE>>>
