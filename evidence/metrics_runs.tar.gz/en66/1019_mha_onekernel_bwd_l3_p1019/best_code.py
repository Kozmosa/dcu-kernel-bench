import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _load_rows(X, b, h, rows, dims, S0, S1, S2, S3, L, D):
    off = b * S0 + rows[:, None] * S1 + h * S2 + dims[None, :] * S3
    mask = (rows[:, None] < L) & (dims[None, :] < D)
    return tl.load(X + off, mask=mask, other=0).to(tl.float32)


@triton.jit
def _attention_backward(Q, K, V, O, LSE, DO, DQ, DK, DV,
                        QS0, QS1, QS2, QS3,
                        KS0, KS1, KS2, KS3,
                        VS0, VS1, VS2, VS3,
                        OS0, OS1, OS2, OS3,
                        LS0, LS1, LS2,
                        GS0, GS1, GS2, GS3,
                        M: tl.constexpr, N: tl.constexpr, HQ: tl.constexpr,
                        HK: tl.constexpr, D: tl.constexpr, GROUP: tl.constexpr,
                        SCALE: tl.constexpr, CAUSAL: tl.constexpr,
                        T: tl.constexpr, BD: tl.constexpr):
    tile = tl.program_id(0)
    hk = tl.program_id(1)
    b = tl.program_id(2)
    r = tl.arange(0, T)
    d = tl.arange(0, BD)

    if tile * T < N:
        j = tile * T + r
        kv = _load_rows(K, b, hk, j, d, KS0, KS1, KS2, KS3, N, D)
        vv = _load_rows(V, b, hk, j, d, VS0, VS1, VS2, VS3, N, D)
        ak = tl.zeros((T, BD), tl.float32)
        av = tl.zeros((T, BD), tl.float32)
        first = 0
        if CAUSAL:
            first = tl.maximum(0, tile * T + M - N) // T * T
        for gh in range(GROUP):
            h = hk * GROUP + gh
            for start in range(first, M, T):
                i = start + r
                qv = _load_rows(Q, b, h, i, d, QS0, QS1, QS2, QS3, M, D)
                gov = _load_rows(DO, b, h, i, d, GS0, GS1, GS2, GS3, M, D)
                ov = _load_rows(O, b, h, i, d, OS0, OS1, OS2, OS3, M, D)
                delta = tl.sum(ov * gov, 1)
                ls = tl.load(LSE + b * LS0 + h * LS1 + i * LS2, mask=i < M, other=0.0)
                score = tl.dot(qv.to(Q.dtype.element_ty), tl.trans(kv.to(K.dtype.element_ty)), out_dtype=tl.float32) * SCALE
                keep = (i[:, None] < M) & (j[None, :] < N)
                if CAUSAL:
                    keep = keep & (j[None, :] <= i[:, None] + N - M)
                p = tl.exp(tl.where(keep, score - ls[:, None], -float('inf')))
                dp = tl.dot(gov.to(DO.dtype.element_ty), tl.trans(vv.to(V.dtype.element_ty)), out_dtype=tl.float32)
                ds = p * (dp - delta[:, None])
                ak += tl.dot(tl.trans(ds), qv, input_precision='ieee')
                av += tl.dot(tl.trans(p), gov, input_precision='ieee')
        offset = ((b * N + j[:, None]) * HK + hk) * D + d[None, :]
        mask = (j[:, None] < N) & (d[None, :] < D)
        tl.store(DK + offset, ak * SCALE, mask=mask)
        tl.store(DV + offset, av, mask=mask)

    if tile * T < M:
        i = tile * T + r
        last = N
        if CAUSAL:
            last = tl.minimum(N, tl.maximum(0, (tile + 1) * T + N - M))
        for gh in range(GROUP):
            h = hk * GROUP + gh
            qv = _load_rows(Q, b, h, i, d, QS0, QS1, QS2, QS3, M, D)
            gov = _load_rows(DO, b, h, i, d, GS0, GS1, GS2, GS3, M, D)
            ov = _load_rows(O, b, h, i, d, OS0, OS1, OS2, OS3, M, D)
            delta = tl.sum(ov * gov, 1)
            ls = tl.load(LSE + b * LS0 + h * LS1 + i * LS2, mask=i < M, other=0.0)
            aq = tl.zeros((T, BD), tl.float32)
            for start in range(0, last, T):
                j = start + r
                kv = _load_rows(K, b, hk, j, d, KS0, KS1, KS2, KS3, N, D)
                vv = _load_rows(V, b, hk, j, d, VS0, VS1, VS2, VS3, N, D)
                score = tl.dot(qv.to(Q.dtype.element_ty), tl.trans(kv.to(K.dtype.element_ty)), out_dtype=tl.float32) * SCALE
                keep = (i[:, None] < M) & (j[None, :] < N)
                if CAUSAL:
                    keep = keep & (j[None, :] <= i[:, None] + N - M)
                p = tl.exp(tl.where(keep, score - ls[:, None], -float('inf')))
                dp = tl.dot(gov.to(DO.dtype.element_ty), tl.trans(vv.to(V.dtype.element_ty)), out_dtype=tl.float32)
                ds = p * (dp - delta[:, None])
                aq += tl.dot(ds, kv, input_precision='ieee')
            offset = ((b * M + i[:, None]) * HQ + h) * D + d[None, :]
            tl.store(DQ + offset, aq * SCALE, mask=(i[:, None] < M) & (d[None, :] < D))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """FlashAttention backward (one-kernel form): given the forward output o and the
    per-row log-sum-exp statistics lse, compute the gradients (dq, dk, dv) from
    (q, k, v, o, lse, do); dK/dV and dQ are produced inside the same kernel
    (dK/dV first, dQ after).

    Mathematical definition (let g = num_q_heads // num_kv_heads and the scaled
    score be s[b,h,i,j] = sm_scale * <q[b,i,h,:], k[b,j,h//g,:]>,
    with sm_scale defaulting to 1/sqrt(head_dim)):
      keep[b,i,j] = (j <= i + seqlen_k - seqlen_q) when causal=1 (bottom-right
                    aligned), always true when causal=0
      p[b,h,i,j]   = exp(s[b,h,i,j] - lse[b,h,i]), and masked positions (keep=0) are always 0
      delta[b,h,i] = sum_d o[b,i,h,d] * do[b,i,h,d]   (computed from the given o)
      dp[b,h,i,j]  = <do[b,i,h,:], v[b,j,h//g,:]>
      ds[b,h,i,j]  = p[b,h,i,j] * (dp[b,h,i,j] - delta[b,h,i])
      dv[b,j,h_k,d] = sum_{h = h_k*g .. h_k*g+g-1} sum_i p[b,h,i,j] * do[b,i,h,d]
      dk[b,j,h_k,d] = sm_scale * sum_{h in the same group} sum_i ds[b,h,i,j] * q[b,i,h,d]
      dq[b,i,h,d]   = sm_scale * sum_j ds[b,h,i,j] * k[b,j,h//g,d]
    Note that dK/dQ are multiplied by sm_scale at the end while dV is not; delta
    uses the input o (not the ideal forward output).
    Boundary behaviour: when causal=1 and i < seqlen_q - seqlen_k the row is fully
    masked -- p/ds are always 0, the dq row is all 0, and it contributes nothing to
    dk/dv (the task input convention sets o=0 and lse=0 for those rows).

    Input/output specification:
      q, o, do  [batch, seqlen_q, num_q_heads, head_dim] float16/bfloat16
      k, v      [batch, seqlen_k, num_kv_heads, head_dim] same dtype as q
      lse       [batch, num_q_heads, seqlen_q] float32 -- natural-log log-sum-exp of
                the scaled scores (0 for fully masked rows)
      returns a single 1-D tensor packed (multi-output packing protocol):
      packed = cat([dq flattened, dk flattened, dv flattened]) (each segment is
      first cast back to the input dtype, then converted to float32)
      where dq has the same shape as q and dk/dv the same shape as k; the total
      length of packed is
      (batch*seqlen_q*num_q_heads + 2*batch*seqlen_k*num_kv_heads) * head_dim.
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
      (GQA; equal means MHA); 1 <= head_dim <= 256 (need not be a power of 2);
      1 <= seqlen_q, seqlen_k; o and lse are the self-consistent forward statistics
      of (q, k, v) (guaranteed by the task's input generator).

    Implementation constraints (violations are scored as failures):
      - The core computation (all matrix multiplies and elementwise operations of
        delta / p / ds / dV / dK / dQ) must be done inside the submitted file;
        calling scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden, and so are
        automatic-differentiation shortcuts such as torch.autograd /
        autograd.grad / .backward(.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - forward must return a single 1-D float32 tensor following the packing
        protocol above (compute dq/dk/dv internally first, then flatten and
        concatenate each).

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: dense fixed-length (non-varlen), non-quantized inputs, no dropout /
    ALiBi / bias / fp8; causal and non-causal are selected by __init__'s causal
    switch.
    """
    def __init__(self, head_dim: int, causal: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.head_dim = int(head_dim)
        self.causal = bool(int(causal))
        self.sm_scale = float(scale) if scale is not None else (0.125 if int(head_dim) == 64 else 1.0 / math.sqrt(head_dim))
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, o, lse, do):
        # <<<IMPROVE:forward_stmt_1>>>
        B, M, H_Q, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        _, N, H_K, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        group = H_Q // H_K
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert H_Q == H_K * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        causal = bool(self.causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dq = torch.empty((B, M, H_Q, D), dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        dk = torch.empty((B, N, H_K, D), dtype=k.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        dv = torch.empty((B, N, H_K, D), dtype=v.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        tile = 16
        _attention_backward[(triton.cdiv(max(M, N), tile), H_K, B)](
            q, k, v, o, lse, do, dq, dk, dv,
            *q.stride(), *k.stride(), *v.stride(), *o.stride(),
            *lse.stride(), *do.stride(),
            M, N, H_Q, H_K, D, group, self.sm_scale, causal,
            tile, max(16, triton.next_power_of_2(D)),
            num_warps=4, num_stages=1,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return torch.cat([
            dq.reshape(-1).to(k.dtype).to(torch.float32),
            dk.reshape(-1).to(k.dtype).to(torch.float32),
            dv.reshape(-1).to(v.dtype).to(torch.float32),
        ])
        # <<<END_IMPROVE>>>
