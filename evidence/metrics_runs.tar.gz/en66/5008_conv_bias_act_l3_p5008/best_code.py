import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5008_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor conv_bias_act(torch::Tensor x, torch::Tensor weight, torch::Tensor bias, torch::Tensor slope, int64_t variant);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("conv_bias_act", &conv_bias_act, "Fused convolution, bias, and activation");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/Dispatch.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cstdint>

namespace {
template <int Mode> struct Activation;
template <> struct Activation<0> { template <typename T> __device__ static inline float run(float z, const T*) { return z > 0.0f ? z : 0.0f; } };
template <> struct Activation<1> { template <typename T> __device__ static inline float run(float z, const T*) { return z / (1.0f + expf(-z)); } };
template <> struct Activation<2> { template <typename T> __device__ static inline float run(float z, const T* slope) { return z > 0.0f ? z : static_cast<float>(slope[0]) * z; } };

template <typename scalar_t, int Mode>
__global__ void conv_bias_act_kernel(const scalar_t* __restrict__ x, const scalar_t* __restrict__ weight, const scalar_t* __restrict__ bias, const scalar_t* __restrict__ slope, scalar_t* __restrict__ out, int64_t N, int64_t C, int64_t H, int64_t W, int64_t K, int64_t R, int64_t S, int64_t Hout, int64_t Wout) {
    int64_t linear = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const int64_t total = N * K * Hout * Wout;
    if (linear >= total) return;
    int64_t q = linear;
    const int64_t j = q % Wout; q /= Wout;
    const int64_t i = q % Hout; q /= Hout;
    const int64_t k = q % K;
    const int64_t n = q / K;
    float acc = 0.0f;
    const int64_t xb = n * C * H * W;
    const int64_t crs = C * R * S;
    for (int64_t c = 0; c < C; ++c) {
        const int64_t xc = xb + c * H * W;
        const int64_t wb = k * crs + c * R * S;
        for (int64_t r = 0; r < R; ++r) {
            const int64_t iy = i + r - 1;
            if (iy < 0 || iy >= H) continue;
            for (int64_t s = 0; s < S; ++s) {
                const int64_t ix = j + s - 1;
                if (ix >= 0 && ix < W) acc = fmaf(static_cast<float>(x[xc + iy * W + ix]), static_cast<float>(weight[wb + r * S + s]), acc);
            }
        }
    }
    float z = Activation<Mode>::run(acc + static_cast<float>(bias[k]), slope);
    out[linear] = static_cast<scalar_t>(z);
}

template <typename scalar_t, int Mode, int RR, int SS>
__global__ void conv_bias_act_halo(const scalar_t* __restrict__ x, const scalar_t* __restrict__ weight, const scalar_t* __restrict__ bias, const scalar_t* __restrict__ slope, scalar_t* __restrict__ out, int64_t N, int64_t C, int64_t H, int64_t W, int64_t K, int64_t Hout, int64_t Wout) {
    constexpr int CHUNK = (RR <= 3 && SS <= 3) ? 16 : 4;
    constexpr int HW = 16 + SS - 1;
    constexpr int HH = 4 + RR - 1;
    constexpr int HALO = HW * HH;
    constexpr int RS = RR * SS;
    __shared__ float inputs[CHUNK][HALO];
    __shared__ float weights[16][CHUNK * RS];

    const int tid = threadIdx.x;
    const int row = tid / 64;
    const int pos = tid & 63;
    const int py = pos >> 4;
    const int px = pos & 15;
    const int tiles_x = (static_cast<int>(Wout) + 15) / 16;
    const int64_t y0 = static_cast<int64_t>(blockIdx.x / tiles_x) * 4;
    const int64_t x0 = static_cast<int64_t>(blockIdx.x % tiles_x) * 16;
    const int64_t kb = static_cast<int64_t>(blockIdx.y) * 16;
    const int64_t n = blockIdx.z;
    float acc[4] = {0.0f, 0.0f, 0.0f, 0.0f};

    for (int64_t cb = 0; cb < C; cb += CHUNK) {
        for (int q = tid; q < CHUNK * HALO; q += 256) {
            const int c = q / HALO;
            const int p = q - c * HALO;
            const int64_t iy = y0 + p / HW - 1;
            const int64_t ix = x0 + p % HW - 1;
            float v = 0.0f;
            if (cb + c < C && iy >= 0 && iy < H && ix >= 0 && ix < W) v = static_cast<float>(x[((n * C + cb + c) * H + iy) * W + ix]);
            inputs[c][p] = v;
        }
        for (int q = tid; q < 16 * CHUNK * RS; q += 256) {
            const int k = q / (CHUNK * RS);
            const int d = q - k * (CHUNK * RS);
            const int c = d / RS;
            const int rs = d - c * RS;
            weights[k][d] = (kb + k < K && cb + c < C) ? static_cast<float>(weight[((kb + k) * C + cb + c) * RS + rs]) : 0.0f;
        }
        __syncthreads();
        const int count = (C - cb < CHUNK) ? static_cast<int>(C - cb) : CHUNK;
        for (int c = 0; c < count; ++c) {
            #pragma unroll
            for (int r = 0; r < RR; ++r) {
                #pragma unroll
                for (int s = 0; s < SS; ++s) {
                    const float v = inputs[c][(py + r) * HW + px + s];
                    const int d = c * RS + r * SS + s;
                    #pragma unroll
                    for (int a = 0; a < 4; ++a) acc[a] = fmaf(v, weights[row + 4 * a][d], acc[a]);
                }
            }
        }
        __syncthreads();
    }

    #pragma unroll
    for (int a = 0; a < 4; ++a) {
        const int64_t k = kb + row + 4 * a;
        if (k < K && y0 + py < Hout && x0 + px < Wout) {
            float z = Activation<Mode>::run(acc[a] + static_cast<float>(bias[k]), slope);
            out[((n * K + k) * Hout + y0 + py) * Wout + x0 + px] = static_cast<scalar_t>(z);
        }
    }
}

template <typename scalar_t, int Mode, int RR, int SS>
static inline void launch_halo(const dim3& grid, const dim3& block, hipStream_t stream, const scalar_t* x, const scalar_t* weight, const scalar_t* bias, const scalar_t* slope, scalar_t* out, int64_t N, int64_t C, int64_t H, int64_t W, int64_t K, int64_t Hout, int64_t Wout) {
    hipLaunchKernelGGL((conv_bias_act_halo<scalar_t, Mode, RR, SS>), grid, block, 0, stream, x, weight, bias, slope, out, N, C, H, W, K, Hout, Wout);
}
}

torch::Tensor conv_bias_act(torch::Tensor x, torch::Tensor weight, torch::Tensor bias, torch::Tensor slope, int64_t variant) {
    TORCH_CHECK(x.is_cuda(), "x must be a device tensor");
    TORCH_CHECK(weight.is_cuda() && bias.is_cuda() && slope.is_cuda(), "all inputs must be device tensors");
    TORCH_CHECK(x.dim() == 4 && weight.dim() == 4, "invalid input dimensions");
    TORCH_CHECK(x.is_contiguous() && weight.is_contiguous() && bias.is_contiguous() && slope.is_contiguous(), "inputs must be contiguous");
    TORCH_CHECK(variant >= 0 && variant <= 2, "invalid activation variant");
    const int64_t N = x.size(0), C = x.size(1), H = x.size(2), W = x.size(3);
    const int64_t K = weight.size(0), R = weight.size(2), S = weight.size(3);
    TORCH_CHECK(weight.size(1) == C, "channel dimensions must match");
    const int64_t Hout = H - R + 3, Wout = W - S + 3;
    TORCH_CHECK(Hout > 0 && Wout > 0, "invalid output dimensions");
    auto out = torch::empty({N, K, Hout, Wout}, x.options());
    const int threads = 256;
    const int64_t total = N * K * Hout * Wout;
    const unsigned int blocks = static_cast<unsigned int>((total + threads - 1) / threads);
    auto stream = at::cuda::getCurrentCUDAStream();
    const bool tiled = K >= 16 && C >= 4 && R <= 5 && S <= 5 && C * R * S >= 32 && Hout >= 8 && Wout >= 16;
    const dim3 tile_grid(((Hout + 3) / 4) * ((Wout + 15) / 16), (K + 15) / 16, N);

    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(), "conv_bias_act", [&] {
        const scalar_t* xp = x.data_ptr<scalar_t>();
        const scalar_t* wp = weight.data_ptr<scalar_t>();
        const scalar_t* bp = bias.data_ptr<scalar_t>();
        const scalar_t* sp = slope.data_ptr<scalar_t>();
        scalar_t* op = out.data_ptr<scalar_t>();
        if (tiled && ((R == 1 && S == 1) || (R == 3 && S == 3) || (R == 5 && S == 5))) {
            if (variant == 0) {
                if (R == 1 && S == 1) launch_halo<scalar_t, 0, 1, 1>(tile_grid, dim3(threads), stream, xp, wp, bp, sp, op, N, C, H, W, K, Hout, Wout);
                else if (R == 3 && S == 3) launch_halo<scalar_t, 0, 3, 3>(tile_grid, dim3(threads), stream, xp, wp, bp, sp, op, N, C, H, W, K, Hout, Wout);
                else launch_halo<scalar_t, 0, 5, 5>(tile_grid, dim3(threads), stream, xp, wp, bp, sp, op, N, C, H, W, K, Hout, Wout);
            } else if (variant == 1) {
                if (R == 1 && S == 1) launch_halo<scalar_t, 1, 1, 1>(tile_grid, dim3(threads), stream, xp, wp, bp, sp, op, N, C, H, W, K, Hout, Wout);
                else if (R == 3 && S == 3) launch_halo<scalar_t, 1, 3, 3>(tile_grid, dim3(threads), stream, xp, wp, bp, sp, op, N, C, H, W, K, Hout, Wout);
                else launch_halo<scalar_t, 1, 5, 5>(tile_grid, dim3(threads), stream, xp, wp, bp, sp, op, N, C, H, W, K, Hout, Wout);
            } else {
                if (R == 1 && S == 1) launch_halo<scalar_t, 2, 1, 1>(tile_grid, dim3(threads), stream, xp, wp, bp, sp, op, N, C, H, W, K, Hout, Wout);
                else if (R == 3 && S == 3) launch_halo<scalar_t, 2, 3, 3>(tile_grid, dim3(threads), stream, xp, wp, bp, sp, op, N, C, H, W, K, Hout, Wout);
                else launch_halo<scalar_t, 2, 5, 5>(tile_grid, dim3(threads), stream, xp, wp, bp, sp, op, N, C, H, W, K, Hout, Wout);
            }
        } else if (variant == 0) {
            hipLaunchKernelGGL((conv_bias_act_kernel<scalar_t, 0>), dim3(blocks), dim3(threads), 0, stream, xp, wp, bp, sp, op, N, C, H, W, K, R, S, Hout, Wout);
        } else if (variant == 1) {
            hipLaunchKernelGGL((conv_bias_act_kernel<scalar_t, 1>), dim3(blocks), dim3(threads), 0, stream, xp, wp, bp, sp, op, N, C, H, W, K, R, S, Hout, Wout);
        } else {
            hipLaunchKernelGGL((conv_bias_act_kernel<scalar_t, 2>), dim3(blocks), dim3(threads), 0, stream, xp, wp, bp, sp, op, N, C, H, W, K, R, S, Hout, Wout);
        }
    });
    auto err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "conv_bias_act launch failed: ", hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Conv + Bias + element-wise activation fused forward family: three
    variants, relu / swish / prelu.

    For the input x (N, C, H, W) and the kernel weight (K, C, R, S), run the 2D
    cross-correlation forward pass (the deep-learning-library conv_fprop
    convention, not the kernel-flipped mathematical convolution), add the
    per-channel bias bias (1, K, 1, 1) (broadcast along the batch and spatial
    dimensions), then apply the element-wise activation. The convolution
    hyper-parameters are shared by the three variants: stride=(1, 1),
    dilation=(1, 1), symmetric zero padding=(1, 1) (1 added on each of the
    top/bottom/left/right sides; the padding value is always zero). Element-wise
    definition:
        z[b, k, i, j] = ( sum_{c, u, v} x[b, c, i+u-1, j+v-1] *
                          weight[k, c, u, v] ) + bias[0, k, 0, 0]
        out[b, k, i, j] = act(z[b, k, i, j])
    where i in [0, H_out), j in [0, W_out), H_out = H - R + 3 and
    W_out = W - S + 3 (the standard convolution output formula once
    stride/padding/dilation are fixed). The activation is selected among three
    by the __init__ parameter variant (z is the convolution result after adding
    bias):
        "relu"  : out = max(z, 0)
        "swish" : out = z * sigmoid(z) = z / (1 + exp(-z))
        "prelu" : out = z (when z > 0), otherwise slope * z (a scalar slope,
                  equivalent to leaky-ReLU with negative_slope=slope; slope is a
                  forward input tensor rather than a module parameter)
    forward returns the single tensor out (N, K, H_out, W_out), with the same
    dtype as x (convolution is inherently single-output, so there are no
    multi-output packing segments).

    Input/output specification:
        x      float16 / bfloat16 / float32 (N, C, H, W), contiguous,
               N/C/H/W >= 1
        weight same dtype as x (K, C, R, S), contiguous, K/R/S >= 1, the
               input-channel dimension equals C
        bias   same dtype as x (1, K, 1, 1), contiguous (per-channel bias,
               broadcast over the whole batch and all spatial positions)
        slope  a 0-dim scalar tensor of the same dtype as x; it takes part in
               the computation only for variant="prelu" (default 0.01, may
               vary); for variant="relu"/"swish" its contents are arbitrary
               (garbage data) and must not affect the output
        out    a single tensor, same dtype as x (N, K, H_out, W_out)
        Inputs are ordinary randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before the call (fp16/bf16 -> fp32 is lossless; the
        output dtype of this task always matches the dtype of the passed x).

    Implementation constraints (violations are scored as failures):
        - The core computation (the padding-aware index/mask expansion and the
          dot-product accumulation, the bias addition, the element-wise
          activation) must all be done and fused with a HIP kernel inside the
          submitted file; replacing it with any form of library convolution or
          ATen GEMM (matmul/mm/bmm/addmm/baddbmm/einsum/tensordot/unfold/linear
          etc., including one-step equivalent routes such as a conv3d
          depth-axis unsqueeze or a conv_transpose2d kernel-flip rewrite) is
          forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The convolution dot-product accumulation, the bias addition and the
          activation are computed in float32 and the output is cast back to the
          input dtype exactly once (do not accumulate in fp16/bf16 low
          precision, and do not make repeated round-trip casts); padding must be
          handled inside the kernel with boundary masks/indices -- do not
          materialize a padded copy on the host side in place of in-kernel
          handling.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.nn.Conv2d / torch.nn.functional.conv2d / F.conv2d /
    torch.conv2d / aten.conv2d / aten.convolution /
    torch.nn.functional.conv3d / torch.conv3d / torch.nn.Conv3d /
    torch.nn.functional.conv_transpose2d / torch.conv_transpose2d /
    torch.nn.ConvTranspose2d /
    torch.nn.functional.unfold / torch.nn.Unfold / .unfold( /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear /
    miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
    regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h>
    is not available on this machine).
    """
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)
    def __init__(self, variant: str = "relu"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("relu", "swish", "prelu"), \
            "variant must be one of relu / swish / prelu"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, bias, slope):
        # <<<IMPROVE:forward_stmt_1>>>
        z = _pyramidkernel_get_extension().conv_bias_act(
            x, weight, bias, slope,
            {"relu": 0, "swish": 1, "prelu": 2}[self.variant],
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return z
        # <<<END_IMPROVE>>>
