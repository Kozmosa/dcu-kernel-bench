import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p2011_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

at::Tensor batchnorm_backward_hip(
    const at::Tensor& dy,
    const at::Tensor& x,
    const at::Tensor& scale,
    const at::Tensor& saved_mean,
    const at::Tensor& saved_inv_variance,
    int64_t variant);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("batchnorm_backward_hip", &batchnorm_backward_hip,
          "BatchNorm backward HIP");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cstdint>

namespace {

constexpr int kThreads = 256;
constexpr int kPartialElements = 4;

__device__ __forceinline__ void reduce_pair(float* a, float* b) {
    const int tid = static_cast<int>(threadIdx.x);
    const int lane = tid % warpSize;
    const int wave = tid / warpSize;
    const int waves = static_cast<int>(blockDim.x) / warpSize;

    float va = a[tid];
    float vb = b[tid];
    __syncthreads();

    for (int offset = warpSize / 2; offset > 0; offset >>= 1) {
        va += __shfl_down(va, offset, warpSize);
        vb += __shfl_down(vb, offset, warpSize);
    }

    if (lane == 0) {
        a[wave] = va;
        b[wave] = vb;
    }
    __syncthreads();

    va = (lane < waves) ? a[lane] : 0.0f;
    vb = (lane < waves) ? b[lane] : 0.0f;
    if (wave == 0) {
        for (int offset = warpSize / 2; offset > 0; offset >>= 1) {
            va += __shfl_down(va, offset, warpSize);
            vb += __shfl_down(vb, offset, warpSize);
        }
        if (lane == 0) {
            a[0] = va;
            b[0] = vb;
        }
    }
}

template <typename scalar_t>
__global__ void partial_kernel(
    const scalar_t* __restrict__ dy,
    const scalar_t* __restrict__ x,
    const float* __restrict__ mean,
    const float* __restrict__ inv,
    float* __restrict__ partial_db,
    float* __restrict__ partial_dg,
    int64_t n,
    int64_t c,
    int64_t spatial,
    int64_t tiles) {
    int64_t tile = static_cast<int64_t>(blockIdx.x);
    int ch = static_cast<int>(blockIdx.y);
    int64_t m = n * spatial;
    int64_t base = tile * (static_cast<int64_t>(kPartialElements) * blockDim.x) + threadIdx.x;
    float db = 0.0f;
    float dg = 0.0f;

    for (int j = 0; j < kPartialElements; ++j) {
        int64_t r = base + static_cast<int64_t>(j) * blockDim.x;
        if (r < m) {
            int64_t batch = r / spatial;
            int64_t pos = r - batch * spatial;
            int64_t off = (batch * c + ch) * spatial + pos;
            float xv = static_cast<float>(x[off]);
            float yv = static_cast<float>(dy[off]);
            float xhat = (xv - mean[ch]) * inv[ch];
            db += yv;
            dg += yv * xhat;
        }
    }

    extern __shared__ float smem[];
    float* sb = smem;
    float* sg = smem + blockDim.x;
    sb[threadIdx.x] = db;
    sg[threadIdx.x] = dg;
    reduce_pair(sb, sg);
    if (threadIdx.x == 0) {
        int64_t out = static_cast<int64_t>(ch) * tiles + tile;
        partial_db[out] = sb[0];
        partial_dg[out] = sg[0];
    }
}

__global__ void finalize_kernel(
    const float* __restrict__ partial_db,
    const float* __restrict__ partial_dg,
    float* __restrict__ sums,
    int64_t c,
    int64_t tiles) {
    int ch = static_cast<int>(blockIdx.x);
    if (ch >= c) return;
    float db = 0.0f;
    float dg = 0.0f;
    for (int64_t t = threadIdx.x; t < tiles; t += blockDim.x) {
        int64_t off = static_cast<int64_t>(ch) * tiles + t;
        db += partial_db[off];
        dg += partial_dg[off];
    }
    extern __shared__ float smem[];
    float* sb = smem;
    float* sg = smem + blockDim.x;
    sb[threadIdx.x] = db;
    sg[threadIdx.x] = dg;
    reduce_pair(sb, sg);
    if (threadIdx.x == 0) {
        sums[ch] = sg[0];
        sums[c + ch] = sb[0];
    }
}

template <typename scalar_t>
__global__ void dx_kernel(
    const scalar_t* __restrict__ dy,
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ scale,
    const float* __restrict__ mean,
    const float* __restrict__ inv,
    const float* __restrict__ sums,
    scalar_t* __restrict__ out,
    int64_t total,
    int64_t c,
    int64_t spatial,
    float m) {
    int64_t idx = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (idx >= total) return;
    int64_t channel = (idx / spatial) % c;
    int64_t batch = idx / (c * spatial);
    int64_t pos = idx - (batch * c + channel) * spatial;
    int64_t off = (batch * c + channel) * spatial + pos;
    float yv = static_cast<float>(dy[off]);
    float xv = static_cast<float>(x[off]);
    float xhat = (xv - mean[channel]) * inv[channel];
    float dg = sums[channel];
    float db = sums[c + channel];
    float sv = static_cast<float>(scale[channel]);
    float value = (sv * inv[channel] / m) * (m * yv - db - xhat * dg);
    out[off] = static_cast<scalar_t>(value);
}

}

at::Tensor batchnorm_backward_hip(
    const at::Tensor& dy,
    const at::Tensor& x,
    const at::Tensor& scale,
    const at::Tensor& saved_mean,
    const at::Tensor& saved_inv_variance,
    int64_t variant) {
    TORCH_CHECK(dy.is_cuda() && x.is_cuda() && scale.is_cuda(), "inputs must be on accelerator");
    TORCH_CHECK(dy.is_contiguous() && x.is_contiguous() && scale.is_contiguous(), "inputs must be contiguous");
    TORCH_CHECK(saved_mean.is_contiguous() && saved_inv_variance.is_contiguous(), "statistics must be contiguous");
    TORCH_CHECK(dy.dim() == 4 && x.sizes() == dy.sizes(), "invalid input shapes");
    TORCH_CHECK(scale.numel() == dy.size(1), "invalid scale shape");
    TORCH_CHECK(saved_mean.numel() == dy.size(1) && saved_inv_variance.numel() == dy.size(1), "invalid statistics shape");
    TORCH_CHECK(dy.scalar_type() == x.scalar_type() && dy.scalar_type() == scale.scalar_type(), "dtype mismatch");
    TORCH_CHECK(saved_mean.scalar_type() == at::kFloat && saved_inv_variance.scalar_type() == at::kFloat, "statistics must be float32");

    const int64_t n = dy.size(0);
    const int64_t c = dy.size(1);
    const int64_t spatial = dy.size(2) * dy.size(3);
    const int64_t m = n * spatial;
    const int64_t tile_width = static_cast<int64_t>(kPartialElements) * kThreads;
    const int64_t tiles = (m + tile_width - 1) / tile_width;
    auto fopts = dy.options().dtype(at::kFloat);
    auto partial_db = at::empty({c, tiles}, fopts);
    auto partial_dg = at::empty({c, tiles}, fopts);
    auto sums = at::empty({2 * c}, fopts);
    auto stream = at::cuda::getDefaultCUDAStream();
    dim3 grid(static_cast<unsigned>(tiles), static_cast<unsigned>(c), 1);
    dim3 block(kThreads, 1, 1);

    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                    dy.scalar_type(), "batchnorm_backward_hip", [&] {
        partial_kernel<scalar_t><<<grid, block, 2 * kThreads * sizeof(float), stream>>>(
            dy.data_ptr<scalar_t>(), x.data_ptr<scalar_t>(),
            saved_mean.data_ptr<float>(), saved_inv_variance.data_ptr<float>(),
            partial_db.data_ptr<float>(), partial_dg.data_ptr<float>(),
            n, c, spatial, tiles);
    });
    finalize_kernel<<<static_cast<unsigned>(c), block, 2 * kThreads * sizeof(float), stream>>>(
        partial_db.data_ptr<float>(), partial_dg.data_ptr<float>(), sums.data_ptr<float>(), c, tiles);

    if (variant != 0) {
        auto out = at::empty({2 * c}, dy.options());
        AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                        dy.scalar_type(), "batchnorm_backward_pack", [&] {
            dx_kernel<scalar_t><<<1, 1, 0, stream>>>(
                dy.data_ptr<scalar_t>(), x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(),
                saved_mean.data_ptr<float>(), saved_inv_variance.data_ptr<float>(),
                sums.data_ptr<float>(), out.data_ptr<scalar_t>(), 0, c, spatial, static_cast<float>(m));
        });
        auto packed_dg = at::empty({c}, dy.options());
        auto packed_db = at::empty({c}, dy.options());
        packed_dg.copy_(sums.narrow(0, 0, c).to(dy.scalar_type()));
        packed_db.copy_(sums.narrow(0, c, c).to(dy.scalar_type()));
        return at::cat({packed_dg, packed_db}, 0);
    }

    auto out = at::empty_like(dy);
    const int64_t total = n * c * spatial;
    const int blocks = static_cast<int>((total + kThreads - 1) / kThreads);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                    dy.scalar_type(), "batchnorm_backward_dx", [&] {
        dx_kernel<scalar_t><<<blocks, block, 0, stream>>>(
            dy.data_ptr<scalar_t>(), x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(),
            saved_mean.data_ptr<float>(), saved_inv_variance.data_ptr<float>(),
            sums.data_ptr<float>(), out.data_ptr<scalar_t>(), total, c, spatial, static_cast<float>(m));
    });
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """BatchNorm training backward: given the upstream gradient dy, the input x of
    the training forward, the saved statistics (saved_mean / saved_inv_variance) and
    the scale parameter, compute the gradients of the normalized forward
        y = scale * xhat + bias,  xhat = (x - saved_mean) * saved_inv_variance
    The __init__ argument variant selects which gradients are returned:
        "dx"           : returns only the data gradient dx, shape (N, C, H, W), same
                         dtype as x;
        "dgamma_dbeta" : returns only the parameter gradients; dgamma and dbeta are
                         each (1, C, 1, 1) and are emitted as a single 1-D tensor
                         (2*C,) following the "one-dimensional concatenation packing
                         protocol": the first C elements are dgamma (flattened in
                         row-major order) and the last C are dbeta.
    Both variants share the same forward signature; the return value is always a
    single tensor (the evaluator compares a single output). Mathematical definition
    (float32 intermediate computation throughout, m = N*H*W elements per channel):
        xhat         = (x - saved_mean) * saved_inv_variance
        dgamma[c]    = sum_{n,h,w} dy * xhat          (summed per channel)
        dbeta[c]     = sum_{n,h,w} dy                 (summed per channel)
        dx           = (scale * saved_inv_variance / m)
                       * (m*dy - dbeta - xhat * dgamma)
    saved_mean / saved_inv_variance are consumed verbatim as the given values: they
    are the statistics saved by the training forward (inv_variance = 1/sqrt(biased
    variance + eps); eps was already absorbed in the forward, and the backward math
    itself contains no eps) and may be any positive numbers unrelated to the true
    statistics of x -- the given values must be used directly, and recomputing the
    statistics from x is forbidden. saved_inv_variance is always positive.

    Input/output specification (NCHW, contiguous):
        dy                 float32 / float16 / bfloat16 (N, C, H, W)
        x                  same dtype as dy (N, C, H, W)
        scale              same dtype as dy (1, C, 1, 1)
        saved_mean         float32 (1, C, 1, 1) (the statistics are always float32,
                           independent of the input dtype)
        saved_inv_variance float32 (1, C, 1, 1), its elements are always positive
        out                single tensor: (N, C, H, W) with the same dtype as dy for
                           dx; (2*C,) with the same dtype as dy for dgamma_dbeta (the
                           first C are dgamma and the last C are dbeta, both computed
                           in float32 and then cast)
        The evaluator casts all inputs to fp32 before passing them in (fp16/bf16 ->
        fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (xhat reconstruction, the two channel reductions, and
          the element-wise chained multiply-add of dx) must be completed inside the
          submitted file with a HIP kernel; a channel reduction of any size (m =
          N*H*W may exceed the capacity of a single block) must be handled correctly
          with mask / tiling (block-wise) reductions, leaving out no element of the
          channel.
        - Computing the gradients through torch.autograd / autograd.grad /
          .backward() is forbidden, as is calling the batch_norm primitive family or
          any closed-source library primitive (MIOpen / hipDNN and the like).
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The reductions and the intermediate computation run in float32; the output
          is cast back to the input dtype; the packing order of dgamma_dbeta is fixed
          as the dgamma segment first and the dbeta segment last.

    Boundary behaviour: N, C, H and W may all be 1 (m may be 1, in which case
    dx = scale * inv_var * (dy - dy*xhat^2)); non-powers of two and unaligned
    dimensions are allowed; the statistics shape is always (1, C, 1, 1); the input
    value range is the usual randn magnitude (no inf/NaN).
    Forbidden: aiter / torch.batch_norm / torch.native_batch_norm /
    torch.nn.functional.batch_norm / F.batch_norm / torch.nn.BatchNorm1d /
    torch.nn.BatchNorm2d / torch.nn.BatchNorm3d /
    torch.ops.aten.batch_norm / torch.ops.aten.native_batch_norm /
    autograd / .backward(.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions;
    device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available
    on this machine).
    """
    def __init__(self, variant: str = "dx"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dx", "dgamma_dbeta"), "variant must be one of dx / dgamma_dbeta"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, dy, x, scale, saved_mean, saved_inv_variance):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().batchnorm_backward_hip(
            dy, x, scale, saved_mean, saved_inv_variance,
            0 if self.variant == "dx" else 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        mean = saved_mean.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        inv_var = saved_inv_variance.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        xhat = (xf - mean) * inv_var
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dgamma_c = (dyf * xhat).sum(dim=(0, 2, 3))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        dbeta_c = dyf.sum(dim=(0, 2, 3))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if self.variant == "dgamma_dbeta":
            # single-tensor packing: the dgamma segment first and the dbeta segment
            # last, each flattened in row-major order
            return torch.cat([dgamma_c.to(x.dtype).reshape(-1),
                              dbeta_c.to(x.dtype).reshape(-1)])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        m = x.shape[0] * x.shape[2] * x.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        scalef = scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        dx = (scalef * inv_var / m) * (m * dyf - dbeta_c.reshape_as(scalef)
                                       - xhat * dgamma_c.reshape_as(scalef))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return dx.to(x.dtype)
        # <<<END_IMPROVE>>>
