import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5006_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

at::Tensor spconv_dgrad(at::Tensor features, at::Tensor filters,
                        at::Tensor out_bp, at::Tensor indice_pairs,
                        at::Tensor indice_num_per_loc);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("spconv_dgrad", &spconv_dgrad);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/hip/HIPStream.h>

__global__ void spconv_dgrad_kernel(
    const float* __restrict__ filters,
    const float* __restrict__ out_bp,
    const float* __restrict__ pairs,
    const float* __restrict__ counts,
    float* __restrict__ dx,
    int64_t kv,
    int64_t pair_capacity,
    int64_t c_in,
    int64_t c_out) {
    int64_t linear = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    int64_t total = kv * pair_capacity * c_in;
    if (linear >= total) return;

    int64_t i = linear % c_in;
    int64_t q = linear / c_in;
    int64_t j = q % pair_capacity;
    int64_t k = q / pair_capacity;

    int count = static_cast<int>(counts[k]);
    if (j >= count) return;

    int in_idx = static_cast<int>(pairs[k * pair_capacity + j]);
    int out_idx = static_cast<int>(pairs[kv * pair_capacity + k * pair_capacity + j]);

    float acc = 0.0f;
    int64_t o = 0;
    for (; o + 7 < c_out; o += 8) {
        float gy0 = out_bp[static_cast<int64_t>(out_idx) * c_out + o];
        float w0 = filters[(o * kv + k) * c_in + i];
        acc += gy0 * w0;
        float gy1 = out_bp[static_cast<int64_t>(out_idx) * c_out + o + 1];
        float w1 = filters[((o + 1) * kv + k) * c_in + i];
        acc += gy1 * w1;
        float gy2 = out_bp[static_cast<int64_t>(out_idx) * c_out + o + 2];
        float w2 = filters[((o + 2) * kv + k) * c_in + i];
        acc += gy2 * w2;
        float gy3 = out_bp[static_cast<int64_t>(out_idx) * c_out + o + 3];
        float w3 = filters[((o + 3) * kv + k) * c_in + i];
        acc += gy3 * w3;
        float gy4 = out_bp[static_cast<int64_t>(out_idx) * c_out + o + 4];
        float w4 = filters[((o + 4) * kv + k) * c_in + i];
        acc += gy4 * w4;
        float gy5 = out_bp[static_cast<int64_t>(out_idx) * c_out + o + 5];
        float w5 = filters[((o + 5) * kv + k) * c_in + i];
        acc += gy5 * w5;
        float gy6 = out_bp[static_cast<int64_t>(out_idx) * c_out + o + 6];
        float w6 = filters[((o + 6) * kv + k) * c_in + i];
        acc += gy6 * w6;
        float gy7 = out_bp[static_cast<int64_t>(out_idx) * c_out + o + 7];
        float w7 = filters[((o + 7) * kv + k) * c_in + i];
        acc += gy7 * w7;
    }
    for (; o < c_out; ++o) {
        float gy = out_bp[static_cast<int64_t>(out_idx) * c_out + o];
        float w = filters[(o * kv + k) * c_in + i];
        acc += gy * w;
    }
    atomicAdd(&dx[static_cast<int64_t>(in_idx) * c_in + i], acc);
}

at::Tensor spconv_dgrad(at::Tensor features, at::Tensor filters,
                        at::Tensor out_bp, at::Tensor indice_pairs,
                        at::Tensor indice_num_per_loc) {
    auto x = features.contiguous().to(at::kFloat);
    auto f = filters.contiguous().to(at::kFloat);
    auto gy = out_bp.contiguous().to(at::kFloat);
    auto pairs = indice_pairs.contiguous().to(at::kFloat);
    auto counts = indice_num_per_loc.contiguous().to(at::kFloat);

    int64_t n = x.size(0);
    int64_t c_in = f.size(1);
    int64_t kv = f.size(2);
    int64_t c_out = f.size(0);
    int64_t pair_capacity = pairs.size(2);

    auto dx = at::zeros({n, c_in}, x.options());
    int64_t total = kv * pair_capacity * c_in;
    constexpr int threads = 128;
    int blocks = static_cast<int>((total + threads - 1) / threads);
    auto stream = c10::hip::getCurrentHIPStream(x.device().index()).stream();
    hipLaunchKernelGGL(spconv_dgrad_kernel, dim3(blocks), dim3(threads), 0,
                       stream, f.data_ptr<float>(), gy.data_ptr<float>(),
                       pairs.data_ptr<float>(), counts.data_ptr<float>(),
                       dx.data_ptr<float>(), kv, pair_capacity, c_in, c_out);
    return dx;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Sparse convolution backward (gathered form spconv): dgrad (gradient with
    respect to the input features) and wgrad (gradient with respect to the
    weight buffer); it is the exact adjoint of the sparse convolution forward
    (gather-GEMM-scatter).

    Forward semantics (the sole authority for this task's convention; out is
    first initialized to all zeros, then accumulated by the formula below):
        for each kernel offset k in [0, kv):
            n_k = indice_num_per_loc[k]
            for each j in [0, n_k):
                in_idx  = indice_pairs[0, k, j]      # input row index in [0, n)
                out_idx = indice_pairs[1, k, j]      # output row index in [0, num_act_out)
                out[out_idx, :] += features[in_idx, :] @ W[:, :, k].T
    i.e. for each index pair, gather the input row and matrix-multiply it with
    the weight matrix of offset k ((n_k, c_in) @ (c_in, c_out)), then
    scatter-accumulate by the output row index into out.
    The mathematical weight W and the contiguous filters tensor F satisfy the
    layout mapping:
        W[o, i, k] = F.reshape(c_out, kv, c_in)[o, k, i]
    (equivalent to W = F.reshape(c_out, kv, c_in).permute(0, 2, 1), still shaped
    (c_out, c_in, kv)).

    Given the upstream gradient out_bp = dL/dy (shape (num_act_out, c_out)), the
    two directions are defined as the adjoint of that forward with respect to
    features / filters:
        dgrad: dx[in_idx, :] += out_bp[out_idx, :] @ W[:, :, k], output
               (n, c_in), i.e. dL/dfeatures;
        wgrad: dW_math[:, :, k] += out_bp[out_idx, :, None] *
               features[in_idx, None, :] (accumulated per index pair), output as
               the weight gradient dF (c_out, c_in, kv) interpreted with the same
               layout mapping as filters:
               dF.reshape(c_out, kv, c_in)[o, k, i] = dW_math[o, i, k],
               stored contiguously.
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns dx; here the values of features do not take part in the
                 output (shape convention only);
        "wgrad": returns dF; here the values of filters do not take part in the
                 output (shape convention only).
    forward(features, filters, out_bp, indice_pairs, indice_num_per_loc) has a
    fixed five-input signature; both directions are inherently single-tensor
    outputs (no concatenation packing).

    Boundary behaviour: kernel offsets with n_k = 0 are skipped entirely; when
    all n_k = 0 the output is all-zero; kv = 1 degenerates to a single offset;
    num_act_out and n are independent of each other (either may be the larger
    one). Index-pair table entries with j >= indice_num_per_loc[k] are padding
    garbage (they may hold any value, including duplicated valid row indices)
    and must be masked out according to indice_num_per_loc -- they must never be
    read into the computation. The same input/output row may be hit by any number
    of index pairs (duplicates are allowed within the same k), and all of them
    accumulate with +=.

    Input/output specification:
        features           float32 / float16 / bfloat16 (n, c_in), contiguous
        filters            same dtype as features (c_out, c_in, kv), contiguous
        out_bp             same dtype as features (num_act_out, c_out),
                           contiguous
        indice_pairs       int32 (2, kv, n), contiguous
        indice_num_per_loc int32 (kv,), contiguous
        out                a single tensor, same dtype as features: (n, c_in) for
                           dgrad, (c_out, c_in, kv) for wgrad
        Dimension domain: n, c_in, c_out, kv, num_act_out >= 1, non-powers-of-two
        allowed; indice_num_per_loc[k] in [0, n]; row indices <= 2^24. Input
        values are ordinary randn magnitude (no inf/NaN). The evaluator casts all
        input tensors to fp32 before the call (integer indices are exact up to
        2^24 and are recovered with int()/long()).

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a HIP kernel inside the
          submitted file: the scatter accumulation of dgrad (the out_bp rows
          transformed by W[:, :, k] and then scatter-accumulated by in_idx) or
          the per-index-pair outer-product correlation accumulation of wgrad;
          falling back to combinations of torch gather / matmul / scatter or to
          autograd is forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).
        - Numeric contract: accumulate in float32 throughout (fp16/bf16 inputs
          are first cast losslessly to fp32), then cast the result back to the
          dtype of features; padding table entries must not take part in the
          computation (including out-of-bounds reads).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.sparse / torch.sparse_coo_tensor /
    torch.sparse_csr_tensor / torch.sparse_csc_tensor / torch.sparse_mm /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear /
    index_add (including every spelling .index_add( / index_add_ /
    torch.index_add) / index_put / torch.index_put / scatter_add (including
    scatter_add_) / .scatter_( / torch.scatter / scatter_reduce /
    segment_reduce / torch.gather / index_select / torch.take / torch.sum /
    torch.ops.aten / torch.autograd / .backward( / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
    regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h>
    is not available on this machine).
    """
    def __init__(self, variant: str = "dgrad"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, features, filters, out_bp, indice_pairs, indice_num_per_loc):
        # <<<IMPROVE:forward_stmt_1>>>
        dt = features.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        c_out, c_in, kv = filters.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        return _pyramidkernel_get_extension().spconv_dgrad(
            features.to(torch.float32), filters.to(torch.float32),
            out_bp.to(torch.float32), indice_pairs, indice_num_per_loc).to(dt)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        pass
        # <<<END_IMPROVE>>>
