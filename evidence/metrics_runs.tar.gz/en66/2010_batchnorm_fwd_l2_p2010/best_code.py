import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2010_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor batchnorm_forward(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, bool, double, double);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("batchnorm_forward", &batchnorm_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

struct Stat { float n, mean, m2; };

__device__ Stat merge_stat(Stat a, Stat b) {
    if (b.n == 0.0f) return a;
    if (a.n == 0.0f) return b;
    float n = a.n + b.n;
    float d = b.mean - a.mean;
    return {n, a.mean + d * (b.n / n), a.m2 + b.m2 + d * d * (a.n * (b.n / n))};
}

__device__ Stat block_stat(Stat a, Stat* sm) {
    int t = threadIdx.x;
    sm[t] = a;
    __syncthreads();
    for (int k = 128; k; k >>= 1) {
        if (t < k) sm[t] = merge_stat(sm[t], sm[t + k]);
        __syncthreads();
    }
    return sm[0];
}

__device__ Stat block_stat128(Stat a, Stat* sm) {
    int t = threadIdx.x;
    sm[t] = a;
    __syncthreads();
    for (int k = 64; k; k >>= 1) {
        if (t < k) sm[t] = merge_stat(sm[t], sm[t + k]);
        __syncthreads();
    }
    return sm[0];
}

__global__ void partial_stats(const float* x, Stat* tmp, int64_t S, int64_t C, int64_t M, int64_t P, int64_t tile) {
    __shared__ Stat sm[256];
    int64_t c = blockIdx.x / P;
    int64_t p = blockIdx.x % P;
    Stat a = {0.0f, 0.0f, 0.0f};
    int64_t end = (p + 1) * tile;
    if (end > M) end = M;
    for (int64_t r = p * tile + threadIdx.x; r < end; r += 256) {
        float v = x[(r / S * C + c) * S + r % S];
        a.n += 1.0f;
        float d = v - a.mean;
        a.mean += d / a.n;
        a.m2 += d * (v - a.mean);
    }
    a = block_stat(a, sm);
    if (threadIdx.x == 0) tmp[c * P + p] = a;
}

__global__ void partial_stats128(const float* x, Stat* tmp, int64_t S, int64_t C, int64_t M, int64_t P, int64_t tile) {
    __shared__ Stat sm[128];
    int64_t c = blockIdx.x / P;
    int64_t p = blockIdx.x % P;
    Stat a = {0.0f, 0.0f, 0.0f};
    int64_t end = (p + 1) * tile;
    if (end > M) end = M;
    for (int64_t r = p * tile + threadIdx.x; r < end; r += 128) {
        float v = x[(r / S * C + c) * S + r % S];
        a.n += 1.0f;
        float d = v - a.mean;
        a.mean += d / a.n;
        a.m2 += d * (v - a.mean);
    }
    a = block_stat128(a, sm);
    if (threadIdx.x == 0) tmp[c * P + p] = a;
}

__global__ void partial_stats_channel_tile(const float* x, Stat* tmp, int64_t S, int64_t C, int64_t M, int64_t P, int64_t tile) {
    __shared__ Stat sm[256];
    int lane = threadIdx.x & 63;
    int group = threadIdx.x >> 6;
    int64_t channel_base = (blockIdx.x / P) * 4;
    int64_t c = channel_base + group;
    int64_t p = blockIdx.x % P;
    Stat a = {0.0f, 0.0f, 0.0f};
    int64_t end = (p + 1) * tile;
    if (end > M) end = M;
    if (c < C) {
        for (int64_t r = p * tile + lane; r < end; r += 64) {
            float v = x[(r / S * C + c) * S + r % S];
            a.n += 1.0f;
            float d = v - a.mean;
            a.mean += d / a.n;
            a.m2 += d * (v - a.mean);
        }
    }
    sm[group * 64 + lane] = a;
    __syncthreads();
    for (int k = 32; k; k >>= 1) {
        if (lane < k) {
            sm[group * 64 + lane] = merge_stat(sm[group * 64 + lane], sm[group * 64 + lane + k]);
        }
        __syncthreads();
    }
    if (lane == 0 && c < C) tmp[c * P + p] = sm[group * 64];
}

__global__ void finalize_stats(const Stat* tmp, float* out, const float* rm, const float* rv, int64_t C, int64_t M, int64_t P, float eps, float mom) {
    __shared__ Stat sm[256];
    int64_t c = blockIdx.x;
    Stat a = {0.0f, 0.0f, 0.0f};
    for (int64_t p = threadIdx.x; p < P; p += 256) a = merge_stat(a, tmp[c * P + p]);
    a = block_stat(a, sm);
    if (threadIdx.x == 0) {
        float v = a.m2 / (float)M;
        float* tail = out + M * C;
        tail[c] = a.mean;
        tail[C + c] = rsqrtf(v + eps);
        tail[2 * C + c] = (1.0f - mom) * rm[c] + mom * a.mean;
        tail[3 * C + c] = (1.0f - mom) * rv[c] + mom * (v * ((float)M / (float)(M - 1)));
    }
}

__global__ void finalize_stats128(const Stat* tmp, float* out, const float* rm, const float* rv, int64_t C, int64_t M, int64_t P, float eps, float mom) {
    __shared__ Stat sm[128];
    int64_t c = blockIdx.x;
    Stat a = {0.0f, 0.0f, 0.0f};
    for (int64_t p = threadIdx.x; p < P; p += 128) a = merge_stat(a, tmp[c * P + p]);
    a = block_stat128(a, sm);
    if (threadIdx.x == 0) {
        float v = a.m2 / (float)M;
        float* tail = out + M * C;
        tail[c] = a.mean;
        tail[C + c] = rsqrtf(v + eps);
        tail[2 * C + c] = (1.0f - mom) * rm[c] + mom * a.mean;
        tail[3 * C + c] = (1.0f - mom) * rv[c] + mom * (v * ((float)M / (float)(M - 1)));
    }
}

__global__ void train_affine(const float* x, const float* scale, const float* bias, float* out, int64_t L, int64_t C, int64_t S) {
    for (int64_t i = (int64_t)blockIdx.x * 256 + threadIdx.x; i < L; i += (int64_t)gridDim.x * 256) {
        int64_t c = (i / S) % C;
        float v = (x[i] - out[L + c]) * out[L + C + c];
        out[i] = v * scale[c] + bias[c];
    }
}

template <class T> __global__ void infer_affine(const T* x, const T* scale, const T* bias, const T* mean, const T* var, T* out, int64_t L, int64_t C, int64_t S, float eps) {
    for (int64_t i = (int64_t)blockIdx.x * 256 + threadIdx.x; i < L; i += (int64_t)gridDim.x * 256) {
        int64_t c = (i / S) % C;
        float v = ((float)x[i] - (float)mean[c]) * rsqrtf((float)var[c] + eps);
        out[i] = (T)(v * (float)scale[c] + (float)bias[c]);
    }
}

void check_launch() {
    hipError_t e = hipGetLastError();
    TORCH_CHECK(e == hipSuccess, hipGetErrorString(e));
}

torch::Tensor batchnorm_forward(torch::Tensor x, torch::Tensor scale, torch::Tensor bias, torch::Tensor mean, torch::Tensor variance, bool training, double eps, double momentum) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous(), "expected contiguous GPU input");
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = at::cuda::getCurrentCUDAStream();
    int64_t C = x.size(1), S = x.size(2) * x.size(3), M = x.size(0) * S, L = x.numel();
    int blocks = (int)std::min<int64_t>((L + 255) / 256, 65535);
    if (!training) {
        auto out = torch::empty_like(x);
        AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(), "bn_inference", [&] {
            infer_affine<scalar_t><<<blocks, 256, 0, stream>>>(x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), mean.data_ptr<scalar_t>(), variance.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), L, C, S, (float)eps);
        });
        check_launch();
        return out;
    }
    TORCH_CHECK(x.scalar_type() == at::kFloat && M >= 2, "training requires float32 and N*H*W>=2");
    int64_t tile = (C >= 128 && M >= 8192) ? 8192 : 4096;
    int64_t P = (M + tile - 1) / tile;
    auto out = torch::empty({L + 4 * C}, x.options());
    auto scratch = torch::empty({C * P * 3}, x.options());
    Stat* tmp = reinterpret_cast<Stat*>(scratch.data_ptr<float>());
    bool small_reduce = (P <= 2 && C < 128);
    bool channel_tiled = (!small_reduce && C >= 64 && M >= 16384 && P >= 3);
    if (channel_tiled) {
        int64_t groups = (C + 3) / 4;
        partial_stats_channel_tile<<<(unsigned int)(groups * P), 256, 0, stream>>>(x.data_ptr<float>(), tmp, S, C, M, P, tile);
    } else if (small_reduce) {
        partial_stats128<<<(unsigned int)(C * P), 128, 0, stream>>>(x.data_ptr<float>(), tmp, S, C, M, P, tile);
    } else {
        partial_stats<<<(unsigned int)(C * P), 256, 0, stream>>>(x.data_ptr<float>(), tmp, S, C, M, P, tile);
    }
    check_launch();
    if (small_reduce) {
        finalize_stats128<<<(unsigned int)C, 128, 0, stream>>>(tmp, out.data_ptr<float>(), mean.data_ptr<float>(), variance.data_ptr<float>(), C, M, P, (float)eps, (float)momentum);
    } else {
        finalize_stats<<<(unsigned int)C, 256, 0, stream>>>(tmp, out.data_ptr<float>(), mean.data_ptr<float>(), variance.data_ptr<float>(), C, M, P, (float)eps, (float)momentum);
    }
    check_launch();
    train_affine<<<blocks, 256, 0, stream>>>(x.data_ptr<float>(), scale.data_ptr<float>(), bias.data_ptr<float>(), out.data_ptr<float>(), L, C, S);
    check_launch();
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """BatchNorm forward family: inference affine (inference) and training batch
    statistics (training).

    The input is x (N, C, H, W), NCHW contiguous; scale / bias / mean / variance are
    all (1, C, 1, 1) and broadcast along the channel dimension. Reduction dimension:
    per-channel, computing the statistics of every channel c over the three
    dimensions (N, H, W), with m = N*H*W elements per channel. The __init__ argument
    variant selects one of two paths (eps defaults to 1e-5 and momentum to 0.1; both
    are scalar hyper-parameters only):

        "inference": the mean and the variance are given as inputs, element-wise
                     affine (float32 intermediate computation):
            y = scale * (x - mean) / sqrt(variance + eps) + bias
        "training": batch statistics + affine + running update (float32
                    throughout):
            batch_mean_c = sum_{n,h,w} x[n,c,h,w] / m                    (biased batch mean)
            batch_var_c  = sum_{n,h,w} (x[n,c,h,w] - batch_mean_c)^2 / m (biased batch variance)
            saved_mean         = batch_mean                              (shape (1,C,1,1))
            saved_inv_variance = 1 / sqrt(batch_var + eps)               (shape (1,C,1,1))
            y = scale * (x - saved_mean) * saved_inv_variance + bias
            next_running_mean = (1 - momentum) * mean + momentum * batch_mean
            next_running_var  = (1 - momentum) * variance
                                + momentum * batch_var * m / (m - 1)
            In the training variant the 4th/5th forward arguments are the running
            statistics of the previous step (prev_running_mean / prev_running_var);
            the running variance update uses the unbiased batch variance (the
            m/(m-1) correction, hence the requirement m >= 2) -- this is the
            standard PyTorch / cuDNN / MIOpen training-BN convention.

    The forward signature is (x, scale, bias, mean, variance) for both variants: in
    inference the 4th/5th arguments are the given mean / variance, in training they
    are prev_running_mean / prev_running_var.

    Single-tensor output protocol (forward must return a single tensor; the
    evaluator compares a single output):
        "inference": returns y itself, shape (N, C, H, W), same dtype as x;
        "training" : returns a one-dimensional float32 packed tensor of length
                     N*C*H*W + 4*C; the five logical outputs are each cast to
                     float32, reshaped with reshape(-1) and torch.cat'ed in the
                     sample-output order, with the segment protocol (half-open
                     intervals):
            [0,            N*C*H*W)      y
            [N*C*H*W,      N*C*H*W + C)  saved_mean
            [N*C*H*W + C,  N*C*H*W + 2C) saved_inv_variance
            [N*C*H*W + 2C, N*C*H*W + 3C) next_running_mean
            [N*C*H*W + 3C, N*C*H*W + 4C) next_running_var

    Input/output specification:
        x        float32 (always float32 for training) / float16 / bfloat16
                 (inference only), (N, C, H, W), contiguous, N/C/H/W >= 1
        scale    same dtype as x, (1, C, 1, 1), contiguous
        bias     same dtype as x, (1, C, 1, 1), contiguous
        mean     same dtype as x, (1, C, 1, 1), contiguous (inference: the given
                 mean, any real value; training: prev_running_mean)
        variance same dtype as x, (1, C, 1, 1), contiguous, always positive
                 (inference: the given variance; training: prev_running_var)
        out      inference: (N, C, H, W), same dtype as x; training: one-dimensional
                 float32 of length N*C*H*W + 4*C (the five-segment packing protocol
                 above)
        The inputs are the usual randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-channel reduction statistics, rsqrt, the
          affine, and the running update) must be completed inside the submitted
          file with a HIP kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, the normalization and the running update all use float32
          intermediates; the y of inference is cast back to the x dtype; all five
          training segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.BatchNorm1d / torch.nn.BatchNorm2d /
    torch.nn.BatchNorm3d / torch.nn.SyncBatchNorm /
    torch.nn.functional.batch_norm / torch.batch_norm /
    torch.native_batch_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions;
    device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available
    on this machine).
    """
    def __init__(self, variant: str = "training", eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("inference", "training"), "variant must be one of inference / training"
        assert eps > 0, "eps must be positive"
        assert 0.0 <= momentum <= 1.0, "momentum must be in [0, 1]"
        self.variant = variant
        self.eps = float(eps)
        self.momentum = float(momentum)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias, mean, variance):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().batchnorm_forward(x, scale, bias, mean, variance, self.variant == 'training', self.eps, self.momentum)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        sf = scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        bf = bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        mf = mean.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        vf = variance.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        if self.variant == "inference":
            # element-wise affine with the given mean/variance; (1,C,1,1)
            # broadcasts along the channel dimension
            inv_std = torch.rsqrt(vf + eps)
            y = (xf - mf) * inv_std * sf + bf
            return y.to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        m = xf.shape[0] * xf.shape[2] * xf.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert m >= 2, "the training variant requires N*H*W >= 2 (the m/(m-1) unbiased correction factor of the running variance)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        batch_mean = xf.mean(dim=(0, 2, 3), keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        batch_var = ((xf - batch_mean) ** 2).mean(dim=(0, 2, 3), keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        saved_inv_variance = torch.rsqrt(batch_var + eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        y = (xf - batch_mean) * saved_inv_variance * sf + bf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        batch_var_unbiased = batch_var * (m / (m - 1))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        next_running_mean = (1.0 - self.momentum) * mf + self.momentum * batch_mean
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        next_running_var = (1.0 - self.momentum) * vf + self.momentum * batch_var_unbiased
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        return torch.cat([
            y.to(torch.float32).reshape(-1),
            batch_mean.to(torch.float32).reshape(-1),
            saved_inv_variance.to(torch.float32).reshape(-1),
            next_running_mean.to(torch.float32).reshape(-1),
            next_running_var.to(torch.float32).reshape(-1),
        ])
        # <<<END_IMPROVE>>>
