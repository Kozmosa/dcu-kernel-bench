import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _moe_count_kernel(ids, counts, n, e: tl.constexpr, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offs = tl.arange(0, BLOCK)
    total = tl.zeros((), dtype=tl.int32)
    for base in range(0, n, BLOCK):
        x = tl.load(ids + base + offs, mask=(base + offs) < n, other=-1).to(tl.int32)
        total += tl.sum((x == pid).to(tl.int32), axis=0)
    tl.store(counts + pid, total)

@triton.jit
def _moe_metadata_kernel(counts, seg, slot, nblocks, totals, e: tl.constexpr, b: tl.constexpr):
    pid = tl.program_id(0)
    if pid == 0:
        csum = 0
        ssum = 0
        bsum = 0
        for i in range(0, e):
            c = tl.load(counts + i).to(tl.int32)
            nb = (c + b - 1) // b
            tl.store(seg + i, csum)
            tl.store(slot + i, ssum)
            tl.store(nblocks + i, nb)
            csum += c
            ssum += nb * b
            bsum += nb
        tl.store(totals + 0, ssum)
        tl.store(totals + 1, bsum)

@triton.jit
def _moe_init_kernel(out, size, value, BLOCK: tl.constexpr):
    p = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    tl.store(out + p, value, mask=p < size)

@triton.jit
def _moe_scatter_kernel(ids, sorted_ids, slot, n, e: tl.constexpr, BLOCK: tl.constexpr):
    expert = tl.program_id(0)
    lanes = tl.arange(0, BLOCK)
    base_rank = 0
    for base in range(0, n, BLOCK):
        offs = base + lanes
        valid = offs < n
        x = tl.load(ids + offs, mask=valid, other=-1).to(tl.int32)
        hit = valid & (x == expert)
        hit_i = hit.to(tl.int32)
        prior = tl.cumsum(hit_i, axis=0) - hit_i
        dst = tl.load(slot + expert) + base_rank + prior
        tl.store(sorted_ids + dst, offs.to(tl.float32), mask=hit)
        base_rank += tl.sum(hit_i, axis=0)

@triton.jit
def _moe_expert_table_kernel(expert_ids, nblocks, capacity, e: tl.constexpr, BLOCK: tl.constexpr):
    blk = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = blk < capacity
    result = tl.full((BLOCK,), -1, tl.int32)
    cur = 0
    for i in range(0, e):
        nb = tl.load(nblocks + i).to(tl.int32)
        take = (blk >= cur) & (blk < cur + nb)
        result = tl.where(take, i, result)
        cur += nb
    tl.store(expert_ids + blk, result.to(tl.float32), mask=valid)

def _moe_launch_metadata(counts, seg, slot, nblocks, totals, e, b):
    _moe_metadata_kernel[(1,)](counts, seg, slot, nblocks, totals, e=e, b=int(b))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Scheduling prologue of MoE grouped GEMM: tokens bucketized per expert and
    laid out aligned to block_size.

    The input topk_ids ([num_tokens, top_k], elements are expert ids in
    [0, num_experts), duplicates allowed within a row) holds the experts the
    router selected for each token. Write the flattened index
    i = t * top_k + j (t is the token row, j the column), N = num_tokens * top_k,
    E = num_experts, B = block_size. For every expert e:
        T_e = { i : the i-th element of flattened topk_ids == e } (ascending i)
        n_blocks_e = ceil(|T_e| / B)        # aligned blocks occupied by e
        padded_e   = n_blocks_e * B         # aligned slot count of e
    Produce the three scheduling tensors of grouped GEMM:
        sorted_token_ids  length L1 = N + E*(B-1): for e = 0..E-1 in order, all
          indices of T_e (ascending), then padded_e - |T_e| fill sentinels N;
          the buffer tail [S, L1) is also sentinel N, where S = sum_e padded_e
        expert_ids        length L2 = ceil(L1/B): for e = 0..E-1 in order,
          n_blocks_e copies of e (together the first S/B positions), the tail
          [S/B, L2) filled with the -1 sentinel
        num_tokens_post_pad  scalar S (total padded slot count, always a
          multiple of B)
    grouped GEMM takes every B consecutive slots of sorted_token_ids as one
    M-tile, uses expert_ids as that tile's expert id to fetch weights, skips
    fill slots whose value is sentinel N, and num_tokens_post_pad gives the
    valid total length. This task is that scheduling prologue itself and does
    not include the GEMM.

    Boundary behaviour: an expert with |T_e| = 0 occupies 0 blocks and yields no
    sorted entry and no expert entry; when |T_e| is an exact multiple of B no
    padding is produced; the same row may select the same expert more than once
    (different flattened indices are different entries); entries within an
    expert follow ascending flattened index i.

    Input/output specification:
      topk_ids  int64/int32 (or fp32 as cast by the evaluator, integer values
                unchanged), contiguous 2D [num_tokens, top_k]; num_tokens /
                top_k >= 1 and top_k <= num_experts; E and B are __init__
                hyperparameters and >= 1, non powers of two allowed
      returns   a single 1-D float32 tensor of length L1 + L2 + 1, packed in
                three segments:
                out[:L1] = the L1 integers of sorted_token_ids (sentinel N
                           included)
                out[L1:L1+L2] = the L2 integers of expert_ids (tail -1)
                out[L1+L2] = num_tokens_post_pad (scalar S)
                -- all of them are non-negative / minus-one integers; the
                global-domain constraint L1 = N + E*(B-1) <= 2^24 guarantees
                that sentinel N, every index, every expert id and S <= L1 are
                exactly representable in fp32
      __init__ hyperparameters: num_experts (int), block_size (int).

    Implementation constraints (violations are scored as failures):
      - Core computation (bucket counting, block-count prefix sums, scatter
        writes of the layout, block expert table generation) must be done in a
        Triton kernel inside the submitted file; forward may only do input/
        output arrangement (dtype restoration, three-segment cat packing).
        Calling torch.sort / torch.argsort / torch.bincount / torch.cumsum /
        torch.histc / torch.unique / torch.repeat_interleave, or any
        third-party MoE/scheduling operator library, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Integer arithmetic throughout (no floating-point accumulation); the
        output is packed into float32 integers per the protocol above.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: the pure scheduling prologue (sorting / alignment / block table
    generation); no grouped GEMM body and no routing scores (softmax/topk are
    already done upstream).
    """
    def __init__(self, num_experts: int, block_size: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = int(num_experts)
        self.block_size = int(block_size)
        # <<<END_IMPROVE>>>

    def forward(self, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        E, B = self.num_experts, self.block_size
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Input expert IDs are guaranteed to lie in [0, E) by the input contract.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        N = topk_ids.numel()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        flat_ids = topk_ids.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        counts = torch.empty((E,), dtype=torch.int32, device=flat_ids.device)
        _moe_count_kernel[(E,)](flat_ids, counts, N, e=E, BLOCK=256)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        seg_start = torch.empty((E,), dtype=torch.int32, device=flat_ids.device)
        slot_start = torch.empty((E,), dtype=torch.int32, device=flat_ids.device)
        n_blocks = torch.empty((E,), dtype=torch.int32, device=flat_ids.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        padded = torch.empty((E,), dtype=torch.int32, device=flat_ids.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        totals = torch.empty((2,), dtype=torch.int32, device=flat_ids.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        _moe_launch_metadata(counts, seg_start, slot_start, n_blocks, totals, E, B)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # The padded total S remains device-resident in totals[0].
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Expert-table generation uses the fixed L2 capacity and device n_blocks.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Stable ordering is produced directly by the ordered Triton scatter pass.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # Source indices are generated from masked Triton tile offsets.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # Destination computation and expert-local ranks are performed in Triton.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        L1 = N + E * (B - 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        L2 = (L1 + B - 1) // B
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        sorted_ids = torch.empty((L1,), dtype=torch.float32, device=flat_ids.device)
        _moe_init_kernel[((L1 + 255) // 256,)](sorted_ids, L1, float(N), BLOCK=256)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        _moe_scatter_kernel[(E,)](flat_ids, sorted_ids, slot_start, N, e=E, BLOCK=256)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        expert_ids = torch.empty((L2,), dtype=torch.float32, device=flat_ids.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        _moe_expert_table_kernel[((L2 + 255) // 256,)](
                            expert_ids, n_blocks, L2, e=E, BLOCK=256
                        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        return torch.cat([
                    sorted_ids,
                    expert_ids,
                    totals[:1].to(torch.float32),
                ])
        # <<<END_IMPROVE>>>
