import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _paged_decode(Q, K, V, BT, L, O,
                  QS: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
                  KP: tl.constexpr, KH: tl.constexpr, KT: tl.constexpr, KD: tl.constexpr,
                  VP: tl.constexpr, VH: tl.constexpr, VT: tl.constexpr, VD: tl.constexpr,
                  BTS: tl.constexpr, BTT: tl.constexpr, LS: tl.constexpr,
                  OS: tl.constexpr, OH: tl.constexpr, OD: tl.constexpr,
                  D: tl.constexpr, BS: tl.constexpr, GROUP: tl.constexpr,
                  SCALE: tl.constexpr, DD: tl.constexpr, TILE: tl.constexpr):
    s = tl.program_id(0)
    h = tl.program_id(1)
    kvh = h // GROUP
    d = tl.arange(0, DD)
    r = tl.arange(0, TILE)
    length = tl.load(L + s * LS)
    q = tl.load(Q + s * QS + h * QH + d * QD, d < D, 0).to(tl.float32) * SCALE
    m = tl.full((), -float('inf'), tl.float32)
    denom = tl.full((), 0.0, tl.float32)
    acc = tl.full((DD,), 0.0, tl.float32)
    for start in range(0, length, TILE):
        t = start + r
        valid = t < length
        page = tl.load(BT + s * BTS + (t // BS) * BTT, valid, 0).to(tl.int64)
        ko = page[:, None] * KP + kvh * KH + (t % BS)[:, None] * KT + d[None, :] * KD
        mask = valid[:, None] & (d[None, :] < D)
        k = tl.load(K + ko, mask, 0).to(tl.float32)
        logits = tl.sum(k * q[None, :], axis=1)
        logits = tl.where(valid, logits, -float('inf'))
        new_m = tl.maximum(m, tl.max(logits, axis=0))
        alpha = tl.exp(m - new_m)
        p = tl.exp(logits - new_m)
        vo = page[:, None] * VP + kvh * VH + (t % BS)[:, None] * VT + d[None, :] * VD
        v = tl.load(V + vo, mask, 0).to(tl.float32)
        acc = acc * alpha + tl.sum(p[:, None] * v, axis=0)
        denom = denom * alpha + tl.sum(p, axis=0)
        m = new_m
    result = acc / tl.where(denom > 0.0, denom, 1.0)
    tl.store(O + s * OS + h * OH + d * OD, result, d < D)


@triton.jit
def _paged_partition(Q, K, V, BT, L, M, Z, A,
                  QS: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
                  KP: tl.constexpr, KH: tl.constexpr, KT: tl.constexpr, KD: tl.constexpr,
                  VP: tl.constexpr, VH: tl.constexpr, VT: tl.constexpr, VD: tl.constexpr,
                  BTS: tl.constexpr, BTT: tl.constexpr, LS: tl.constexpr,
                  D: tl.constexpr, BS: tl.constexpr, GROUP: tl.constexpr,
                  SCALE: tl.constexpr, DD: tl.constexpr, TILE: tl.constexpr,
                  HQ: tl.constexpr, NP: tl.constexpr, PART: tl.constexpr):
    s = tl.program_id(0)
    h = tl.program_id(1)
    part = tl.program_id(2)
    kvh = h // GROUP
    d = tl.arange(0, DD)
    r = tl.arange(0, TILE)
    length = tl.load(L + s * LS)
    end = tl.minimum(length, (part + 1) * PART)
    q = tl.load(Q + s * QS + h * QH + d * QD, d < D, 0).to(tl.float32) * SCALE
    m = tl.full((), -float('inf'), tl.float32)
    denom = tl.full((), 0.0, tl.float32)
    acc = tl.full((DD,), 0.0, tl.float32)
    for start in range(part * PART, end, TILE):
        t = start + r
        valid = t < end
        page = tl.load(BT + s * BTS + (t // BS) * BTT, valid, 0).to(tl.int64)
        ko = page[:, None] * KP + kvh * KH + (t % BS)[:, None] * KT + d[None, :] * KD
        mask = valid[:, None] & (d[None, :] < D)
        k = tl.load(K + ko, mask, 0).to(tl.float32)
        logits = tl.sum(k * q[None, :], axis=1)
        logits = tl.where(valid, logits, -float('inf'))
        new_m = tl.maximum(m, tl.max(logits, axis=0))
        alpha = tl.exp(m - new_m)
        p = tl.exp(logits - new_m)
        vo = page[:, None] * VP + kvh * VH + (t % BS)[:, None] * VT + d[None, :] * VD
        v = tl.load(V + vo, mask, 0).to(tl.float32)
        acc = acc * alpha + tl.sum(p[:, None] * v, axis=0)
        denom = denom * alpha + tl.sum(p, axis=0)
        m = new_m
    idx = (s * HQ + h) * NP + part
    tl.store(M + idx, m)
    tl.store(Z + idx, denom)
    tl.store(A + idx * DD + d, acc)


@triton.jit
def _paged_merge(M, Z, A, O, OS: tl.constexpr, OH: tl.constexpr, OD: tl.constexpr,
                 HQ: tl.constexpr, NP: tl.constexpr, PP: tl.constexpr,
                 D: tl.constexpr, DD: tl.constexpr):
    s = tl.program_id(0)
    h = tl.program_id(1)
    p = tl.arange(0, PP)
    d = tl.arange(0, DD)
    idx = (s * HQ + h) * NP + p
    z = tl.load(Z + idx, p < NP, 0)
    m = tl.load(M + idx, p < NP, -float('inf'))
    active = z > 0
    maximum = tl.max(tl.where(active, m, -float('inf')), 0)
    maximum = tl.where(tl.sum(z, 0) > 0, maximum, 0.0)
    w = tl.where(active, tl.exp(tl.where(active, m, maximum) - maximum), 0.0)
    a = tl.load(A + idx[:, None] * DD + d[None, :], p[:, None] < NP, 0)
    denominator = tl.sum(w * z, 0)
    result = tl.sum(w[:, None] * a, 0) / tl.where(denominator > 0, denominator, 1.0)
    tl.store(O + s * OS + h * OH + d * OD, result, d < D)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Paged attention in the decode phase (single-token query), supporting both
    MHA and GQA.

    The KV cache is stored page-wise with a fixed block_size in the physical block
    pools key_cache / value_cache, and each sequence addresses them indirectly
    through the physical block ids in block_tables; the KV length that actually
    participates in attention for each sequence is given by seq_lens[s], while the
    remaining slots in the pool hold garbage data and must not participate in the
    computation. For query head h of sequence s (whose KV head is
    h // query_group_size):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    The softmax uses an online (numerically stable) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding window.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        PART = triton.cdiv(256, bs) * bs
        capacity = block_tables.shape[1] * bs
        if capacity >= 2 * PART:
            partition_count = triton.cdiv(capacity, PART)
            dd = triton.next_power_of_2(D)
            maxima = torch.empty((B, H_Q, partition_count), dtype=torch.float32, device=query.device)
            denominators = torch.empty_like(maxima)
            accumulators = torch.empty((B, H_Q, partition_count, dd), dtype=torch.float32, device=query.device)
            _paged_partition[(B, H_Q, partition_count)](
                query, key_cache, value_cache, block_tables, seq_lens,
                maxima, denominators, accumulators,
                *query.stride(), *key_cache.stride(), *value_cache.stride(),
                *block_tables.stride(), seq_lens.stride(0),
                D, bs, group, self.scale, dd, 32, H_Q, partition_count, PART,
                num_warps=4,
            )
            _paged_merge[(B, H_Q)](
                maxima, denominators, accumulators, out, *out.stride(),
                H_Q, partition_count, triton.next_power_of_2(partition_count), D, dd,
                num_warps=4,
            )
        else:
            _paged_decode[(B, H_Q)](
                        query, key_cache, value_cache, block_tables, seq_lens, out,
                        *query.stride(),
                        *key_cache.stride(),
                        *value_cache.stride(),
                        *block_tables.stride(), seq_lens.stride(0),
                        *out.stride(),
                        D, bs, group, self.scale, triton.next_power_of_2(D), 32,
                        num_warps=4,
                    )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
