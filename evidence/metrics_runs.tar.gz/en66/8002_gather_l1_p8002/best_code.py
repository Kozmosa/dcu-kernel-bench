import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l1_p8002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor run_select(torch::Tensor data, torch::Tensor indices, int64_t axis, bool elementwise);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("run_select", &run_select);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cstdint>

template<class T, class J, bool E>
__global__ void select_copy(const T* __restrict__ data, const J* __restrict__ idx,
                            T* __restrict__ out, int64_t n, int64_t a,
                            int64_t k, int64_t inner) {
    for (int64_t p = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         p < n; p += int64_t(blockDim.x) * gridDim.x) {
        int64_t q = p / inner;
        int64_t j = q % k;
        int64_t outer = q / k;
        int64_t m = static_cast<int64_t>(idx[E ? p : j]);
        out[p] = data[(outer * a + m) * inner + p % inner];
    }
}

template<class T, class J>
void launch_select(torch::Tensor data, torch::Tensor idx, torch::Tensor out,
                   int64_t a, int64_t k, int64_t inner, bool e, hipStream_t stream) {
    int64_t n = out.numel();
    const T* d = reinterpret_cast<const T*>(data.data_ptr());
    const J* i = reinterpret_cast<const J*>(idx.data_ptr());
    T* o = reinterpret_cast<T*>(out.data_ptr());
    if (n <= 64) {
        if (e) {
            select_copy<T, J, true><<<1, 64, 0, stream>>>(d, i, o, n, a, k, inner);
        } else {
            select_copy<T, J, false><<<1, 64, 0, stream>>>(d, i, o, n, a, k, inner);
        }
        return;
    }
    if (n <= 1024) {
        int blocks = static_cast<int>(std::min<int64_t>((n + 127) / 128, 4096));
        if (e) {
            select_copy<T, J, true><<<blocks, 128, 0, stream>>>(d, i, o, n, a, k, inner);
        } else {
            select_copy<T, J, false><<<blocks, 128, 0, stream>>>(d, i, o, n, a, k, inner);
        }
        return;
    }
    int blocks = static_cast<int>(std::min<int64_t>((n + 255) / 256, 4096));
    if (!blocks) return;
    if (e) {
        select_copy<T, J, true><<<blocks, 256, 0, stream>>>(d, i, o, n, a, k, inner);
    } else {
        select_copy<T, J, false><<<blocks, 256, 0, stream>>>(d, i, o, n, a, k, inner);
    }
}

template<class T>
void dispatch_indices(torch::Tensor data, torch::Tensor idx, torch::Tensor out,
                      int64_t a, int64_t k, int64_t inner, bool e, hipStream_t stream) {
    switch (idx.scalar_type()) {
        case at::kLong: launch_select<T, int64_t>(data, idx, out, a, k, inner, e, stream); break;
        case at::kInt: launch_select<T, int32_t>(data, idx, out, a, k, inner, e, stream); break;
        case at::kFloat: launch_select<T, float>(data, idx, out, a, k, inner, e, stream); break;
        default: TORCH_CHECK(false, "Unsupported index dtype");
    }
}

torch::Tensor run_select(torch::Tensor data, torch::Tensor indices, int64_t axis, bool elementwise) {
    c10::cuda::CUDAGuard guard(data.device());
    TORCH_CHECK(data.is_contiguous() && indices.is_contiguous(), "Contiguous inputs required");
    auto shape = elementwise ? indices.sizes().vec() : data.sizes().vec();
    if (!elementwise) shape[axis] = indices.numel();
    auto out = torch::empty(shape, data.options());
    int64_t inner = 1;
    for (int64_t d = axis + 1; d < data.dim(); ++d) inner *= data.size(d);
    int64_t a = data.size(axis), k = shape[axis];
    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    if (data.scalar_type() == at::kFloat) {
        dispatch_indices<uint32_t>(data, indices, out, a, k, inner, elementwise, stream);
    } else {
        TORCH_CHECK(data.scalar_type() == at::kHalf || data.scalar_type() == at::kBFloat16, "Unsupported data dtype");
        dispatch_indices<uint16_t>(data, indices, out, a, k, inner, elementwise, stream);
    }
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "Selection launch failed: ", hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Gather / GatherElements: the index-movement family that selects elements
    along a given axis by integer index.

    The __init__ parameter `variant` selects one of two paths; their semantics
    are defined as follows:
        "gather" (select along an axis): `indices` is a 1-D integer vector of
            arbitrary length K;
            out[i_0, ..., i_{axis-1}, j, i_{axis+1}, ...] =
                data[i_0, ..., i_{axis-1}, indices[j], i_{axis+1}, ...]
            i.e. indices[j] picks one whole slice along dimension `axis` at a
            time; the output shape equals the data shape with dimension `axis`
            replaced by K.
        "gather_elements" (element-wise selection with a same-shaped index):
            `indices` has the same rank as data, with every dimension equal to
            data except dimension `axis` (whose length K may differ from data);
            out[i_0, ..., i_{n-1}] = data[i_0, ..., m, ..., i_{n-1}] where
            m = indices[i_0, ..., i_{n-1}] -- each output element takes its own
            subscript along `axis`; the output shape equals the indices shape.
    The difference: gather's index is a 1-D vector that decides how a whole
    slice along `axis` is selected at once; gather_elements' index has the same
    shape as the output and specifies the subscript along `axis` per element.
    The __init__ parameter `axis` sets the selection dimension (torch
    convention: non-negative counts from 0, negative counts from the end),
    defaulting to 1.

    Numeric contract: this operator is pure index movement with no arithmetic.
    A correct implementation produces an output bit-identical to the selected
    elements of the input (bit patterns preserved; no dtype conversion, no
    numeric operation).

    Input/output specification:
        data    float32 / float16 / bfloat16, contiguous, ndim in [1, 4],
                every dimension >= 1, total element count <= 2^23; values are
                ordinary randn magnitude (no inf/NaN)
        indices an integer tensor: for variant="gather" an int64 1-D tensor
                (length K >= 1); for variant="gather_elements" an int32 tensor
                with the same rank as data (shape constraints above); every
                index value lies in [0, data.shape[axis]) -- the input contains
                no out-of-range index
        out     a single tensor, same dtype as data, contiguous: for gather its
                shape is the data shape with dimension `axis` replaced by K;
                for gather_elements its shape is the indices shape. forward must
                return a single tensor (the evaluator compares .shape /
                allclose on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (indices are small non-negative integers < 2^24 and are exactly
        representable in fp32, so they are recovered losslessly; fp16/bf16 ->
        fp32 is also lossless). The offline final audit passes inputs natively
        in their declared dtype -- the implementation must be correct for both.

    Boundary behaviour: K=1, K different from data.shape[axis], an axis of
    length 1, non-power-of-two / prime lengths, and repeated indices hitting the
    same element must all be handled correctly; a negative `axis` follows the
    torch convention.

    Implementation constraints (violations are scored as failures):
        - The core computation (index expansion / address computation plus
          load/store at those addresses) must be completed with a HIP kernel
          inside the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Pure-movement contract: the output is bit-identical to the selected
          elements of data (including float16 / bfloat16 bit patterns); no
          numeric transformation may be introduced.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.gather / .gather( / torch.index_select /
    .index_select( / torch.take_along_dim / .take_along_dim( /
    torch.take( / .take( (including the Tensor.take method form) /
    torch.embedding / nn.Embedding / .embedding( / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
    regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h>
    is not available on this machine).
    """
    def __init__(self, variant: str = "gather", axis: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("gather", "gather_elements"), "variant must be one of gather / gather_elements"
        self.variant = variant
        self.axis = int(axis)
        # <<<END_IMPROVE>>>

    def forward(self, data, indices):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        ndim = data.dim()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        axis = self.axis % ndim
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        return _pyramidkernel_get_extension().run_select(data, indices, axis, self.variant == "gather_elements")
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
