import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _fused_tn_gemm(X, W, XS, WS, Bias, Out,
                   M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
                   xb: tl.constexpr, xm: tl.constexpr, xk: tl.constexpr,
                   wb: tl.constexpr, wn: tl.constexpr, wk: tl.constexpr,
                   sb: tl.constexpr, sm: tl.constexpr,
                   tb: tl.constexpr, tn: tl.constexpr,
                   bb: tl.constexpr, bn: tl.constexpr,
                   ob: tl.constexpr, om: tl.constexpr, on: tl.constexpr,
                   USE_BIAS: tl.constexpr,
                   BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr,
                   BLOCK_K: tl.constexpr):
    tile = tl.program_id(0)
    batch = tl.program_id(1)
    tiles_n = tl.cdiv(N, BLOCK_N)
    rows = (tile // tiles_n) * BLOCK_M + tl.arange(0, BLOCK_M)
    cols = (tile % tiles_n) * BLOCK_N + tl.arange(0, BLOCK_N)
    rk = tl.arange(0, BLOCK_K)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for chunk in range(tl.cdiv(K, BLOCK_K)):
        ks = chunk * BLOCK_K + rk
        a = tl.load(X + batch * xb + rows[:, None] * xm + ks[None, :] * xk,
                    mask=(rows[:, None] < M) & (ks[None, :] < K), other=0).to(tl.float16)
        b = tl.load(W + batch * wb + cols[None, :] * wn + ks[:, None] * wk,
                    mask=(cols[None, :] < N) & (ks[:, None] < K), other=0).to(tl.float16)
        acc = tl.dot(a, b, acc)
    row_scale = tl.load(XS + batch * sb + rows * sm, mask=rows < M, other=0).to(tl.float32)
    col_scale = tl.load(WS + batch * tb + cols * tn, mask=cols < N, other=0).to(tl.float32)
    acc = acc * row_scale[:, None]
    acc = acc * col_scale[None, :]
    rounded = acc.to(Out.dtype.element_ty)
    if USE_BIAS:
        bias = tl.load(Bias + batch * bb + cols * bn, mask=cols < N, other=0).to(Out.dtype.element_ty).to(tl.float32)
        rounded = (rounded.to(tl.float32) + bias[None, :]).to(Out.dtype.element_ty)
    tl.store(Out + batch * ob + rows[:, None] * om + cols[None, :] * on,
             rounded, mask=(rows[:, None] < M) & (cols[None, :] < N))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Batch-dimension int8 quantized GEMM: int8 activations x int8 weights, with an
    outer-product scale applied for dequantization.

    Computed independently for every matrix in the batch (mathematical definition):
      acc[b, m, n] = sum_k xq[b, m, k] * wq[b, n, k]          (float32 accumulation)
      out[b, m, n] = acc[b, m, n] * xs[b, m, 0] * ws[b, 0, n] (+ bias[b, 0, n])

    i.e. out[b] = xq[b] @ wq[b]^T followed by dequantization. wq is stored
    row-major as (B, N, K), so the computation is equivalent to a transposed GEMM
    (row n of the weight is one output-channel column). xs is the per-token scale:
    one value per row of the M dimension, (B, M, 1) float32; ws is the per-channel
    scale: one value per column of the N dimension, (B, 1, N) float32; their outer
    product is the (B, M, N) dequantization matrix. bias (B, 1, N) is optional and
    has the same dtype as the output; with bias the quantized-GEMM kernel fusion
    order applies: the float32 scaled result is first cast to the output dtype, then
    the bias is added.

    Input/output specification:
      xq      int8       (B, M, K)   activation code words
      wq      int8       (B, N, K)   weight code words (row-major, transposed-GEMM
                                     equivalent)
      xs      float32    (B, M, 1)   per-token scale
      ws      float32    (B, 1, N)   per-channel scale
      bias    output dtype (B, 1, N) optional; when use_bias=False a placeholder
                                     tensor is passed and ignored
      out     output dtype (B, M, N) the dtype is set by __init__'s out_dtype
                                     (bfloat16 / float16), B/M/N/K >= 1

    Implementation constraints (violations are scored as failures):
      - The core computation (the int8 GEMM accumulation) must be completed inside
        the submitted file; calling torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / torch._int_mm / F.linear /
        functional.linear is forbidden, as is calling any ready-made operator
        library or closed-source kernel wrapper to complete this computation
        directly.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward; the code
        words are small integers in [-20, 20) and the bias values come from
        low-precision quantization, all exactly representable in fp32, so
        .to(torch.int8) / .to(out_dtype) at the entry point recovers them
        losslessly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: TN layout (x row-major (B,M,K), w row-major (B,N,K)), no split-K;
    B/M/N/K are any values >= 1 with no alignment requirement; the accumulation
    runs in float32 and must agree with the reference fp32 GEMM within tolerance.
    """
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, xq, wq, x_scale, w_scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        # Convert activation code words in registers in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Convert weight code words in registers in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        bias = bias if self.use_bias else None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        B, M, K = xq.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = wq.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == wq.shape[2], "xq and wq must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        acc = torch.empty((B, M, N), device=xq.device, dtype=self.out_dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # The fused kernel consumes the int8 operands directly.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _fused_tn_gemm[(triton.cdiv(M, 32) * triton.cdiv(N, 64), B)](
            xq, wq, x_scale, w_scale, bias if self.use_bias else acc, acc,
            M, N, K,
            xq.stride(0), xq.stride(1), xq.stride(2),
            wq.stride(0), wq.stride(1), wq.stride(2),
            x_scale.stride(0), x_scale.stride(1),
            w_scale.stride(0), w_scale.stride(2),
            bias.stride(0) if self.use_bias else 0,
            bias.stride(2) if self.use_bias else 0,
            acc.stride(0), acc.stride(1), acc.stride(2),
            USE_BIAS=self.use_bias, BLOCK_M=32, BLOCK_N=64, BLOCK_K=32,
            num_warps=4, num_stages=1, enable_fp_fusion=False,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # Row scaling is performed in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Column scaling follows row scaling in the fused kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # The fused kernel explicitly rounds to output dtype before bias.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Optional bias has already been applied to the rounded result.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return acc.to(self.out_dtype)
        # <<<END_IMPROVE>>>
