import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2012_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """GroupNorm forward family: standard GroupNorm and the GroupNorm+Swish fusion.

    The input is x (N, C, H, W), NCHW contiguous; scale / bias are the (C,)
    per-channel affine parameters; the __init__ argument groups = G (dividing C,
    1 <= G <= C) splits the channels into G groups, with channel c belonging to
    group c // (C//G); eps defaults to 1e-5. The normalization statistics are
    computed per (n, g) group: x[n] is split along the channel dimension into G
    segments (group g occupies the channels [g*(C//G), (g+1)*(C//G)), and the number
    of elements in a group is D = (C//G)*H*W), in float32:
        mean_ng     = sum_D x / D                      (biased mean)
        var_ng      = sum_D (x - mean_ng)^2 / D        (biased variance)
        inv_var_ng  = 1 / sqrt(var_ng + eps)
        gn[n,c,h,w] = (x[n,c,h,w] - mean_ng) * inv_var_ng * scale[c] + bias[c]
                      (where the group index is g = c // (C//G))
    The __init__ argument variant selects one of two paths:
        "groupnorm"      : y = gn
        "groupnorm_swish": y = gn * sigmoid(gn) (Swish / SiLU)
    Both variants also emit the per-group statistics mean and inv_var (one entry per
    (n, g), (N, G) layout, float32).

    Boundary behaviour: when the in-group variance is 0 (e.g. D == 1, a single
    element in the group) inv_var = 1/sqrt(eps) (eps guarantees no division by zero)
    and gn = bias; G=1 is full-channel normalization and G=C is per-channel
    normalization, both of which are legal; N/C/H/W are arbitrary (including 1,
    non-powers of two and unaligned), a large in-group D needs a tiling (block-wise)
    reduction, and out-of-range elements at the row tail must not take part in the
    statistics.

    Single-tensor output protocol (forward must return a single tensor; the evaluator
    compares a single output):
    Returns a one-dimensional float32 packed tensor of length N*C*H*W + 2*N*G, with
    three segments packed back to back in order (half-open intervals; each segment is
    float32, reshaped with reshape(-1) and torch.cat'ed):
        [0,               N*C*H*W)           y
        [N*C*H*W,         N*C*H*W + N*G)     mean    ((N, G) flattened row-major)
        [N*C*H*W + N*G,   N*C*H*W + 2*N*G)   inv_var ((N, G) flattened row-major)
    The output is always float32: the y segment is not quantized to a lower
    precision; fp16/bf16 is only the input quantization level (the input is provided
    in that dtype and then cast to float32 to take part in the whole computation).

    Input/output specification:
        x      float32 / float16 / bfloat16 (N, C, H, W), contiguous, N/C/H/W >= 1
        scale  same dtype as x, (C,), contiguous
        bias   same dtype as x, (C,), contiguous
        out    one-dimensional float32 of length N*C*H*W + 2*N*G (the three-segment
               packing protocol above)
        The inputs are the usual randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-group mean / biased var reduction, rsqrt, the
          per-channel affine, and Swish) must be completed inside the submitted file
          with a HIP kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt, the affine and Swish all use float32 intermediates;
          all three output segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions;
    device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available
    on this machine).
    """
    def __init__(self, variant: str = "groupnorm", groups: int = 2, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("groupnorm", "groupnorm_swish"), "variant must be one of groupnorm / groupnorm_swish"
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.variant = variant
        self.groups = int(groups)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        n, c, h, w = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        g = self.groups
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        rep = c // g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert 1 <= g <= c and c % g == 0, "groups must divide the number of channels and 1 <= groups <= C"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        xg = xf.reshape(n, g, -1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        mean = xg.mean(dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        var = (xg - mean.unsqueeze(-1)).pow(2).mean(dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        inv_var = torch.rsqrt(var + self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        mean_c = mean.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        inv_c = inv_var.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        sf = scale.to(torch.float32).reshape(1, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        bf = bias.to(torch.float32).reshape(1, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        gn = (xf - mean_c) * inv_c * sf + bf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        y = gn * torch.sigmoid(gn) if self.variant == "groupnorm_swish" else gn
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return torch.cat([y.reshape(-1), mean.reshape(-1), inv_var.reshape(-1)])
        # <<<END_IMPROVE>>>
