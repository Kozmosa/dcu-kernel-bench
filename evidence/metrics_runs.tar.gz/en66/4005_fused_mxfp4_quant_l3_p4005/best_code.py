import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _mxfp4_quant_kernel(x_ptr, codes_ptr, scales_ptr, n_cols, n_blocks, stride_x, stride_codes, stride_scales, BLOCKS: tl.constexpr = 4):
    row = tl.program_id(0)
    tile = tl.program_id(1)
    block_ids = tile * BLOCKS + tl.arange(0, BLOCKS)
    elems = tl.arange(0, 32)
    cols = block_ids[:, None] * 32 + elems[None, :]
    valid = cols < n_cols
    x = tl.load(x_ptr + row * stride_x + cols, mask=valid, other=0.0)

    amax = tl.max(tl.abs(x), axis=1)
    amax_bits = tl.cast(amax, tl.int32, bitcast=True)
    rounded_bits = (amax_bits + 0x200000) & -8388608
    rounded_exp = (rounded_bits >> 23) & 255
    scale_e = tl.where(rounded_bits == 0, -127, rounded_exp - 129)
    scale_e = tl.maximum(tl.minimum(scale_e, 127), -127)
    scale_bits = tl.where(scale_e <= 126, (127 - scale_e) << 23, 0x00400000)
    quant_scale = tl.cast(scale_bits, tl.float32, bitcast=True)

    q = x * quant_scale[:, None]
    qi = tl.cast(q, tl.int32, bitcast=True)
    sign = qi & -2147483648
    exp = (qi >> 23) & 255
    mant = qi & 0x7fffff

    adjusted = 126 - exp
    safe_adjusted = tl.maximum(adjusted, 0)
    sub_mant = (0x400000 | (mant >> 1)) >> safe_adjusted
    mant = tl.where(exp < 127, sub_mant, mant)
    shifted_exp = tl.where(exp > 126, exp, 126) - 126
    combined = (((shifted_exp << 2) | (mant >> 21)) + 1) >> 1
    magnitude = tl.minimum(combined, 7)
    code = ((sign >> 28) & 0xF) | magnitude

    lanes = tl.arange(0, 32)
    pairs = tl.arange(0, 16)
    even_sel = lanes[None, :] == (pairs * 2)[:, None]
    odd_sel = lanes[None, :] == (pairs * 2 + 1)[:, None]
    even_code = tl.sum(tl.where(even_sel[None, :, :], code[:, None, :], 0), axis=2)
    odd_code = tl.sum(tl.where(odd_sel[None, :, :], code[:, None, :], 0), axis=2)
    packed = tl.cast(even_code | (odd_code << 4), tl.uint8)
    packed_cols = block_ids[:, None] * 16 + pairs[None, :]
    packed_mask = packed_cols < (n_cols // 2)
    tl.store(codes_ptr + row * stride_codes + packed_cols, packed, mask=packed_mask)

    scale_mask = block_ids < n_blocks
    tl.store(scales_ptr + row * stride_scales + block_ids, tl.cast(scale_e + 127, tl.uint8), mask=scale_mask)


def _triton_mxfp4_quant(x):
    x = x.contiguous()
    m, n = x.shape
    n_blocks = (n + 31) // 32
    codes = torch.empty((m, n // 2), device=x.device, dtype=torch.uint8)
    scales = torch.empty((m, n_blocks), device=x.device, dtype=torch.uint8)
    grid = (m, (n_blocks + 3) // 4)
    _mxfp4_quant_kernel[grid](
        x, codes, scales, n,
        n_blocks, x.stride(0), codes.stride(0), scales.stride(0),
        num_warps=4,
    )
    return codes, scales
# <<<END_IMPROVE>>>

def _rmsnorm(x, weight, eps):
    # Official semantics: row-wise RMS normalization in float32, then multiply
    # by the weight
    row_norm = torch.sum(x * x, dim=-1)
    norm_factor = torch.rsqrt((row_norm / x.shape[1]) + eps).reshape(-1, 1)
    return x * norm_factor * weight.reshape(1, -1)

def _mxfp4_quant(x):
    # MXFP4 dynamic quantization (block size 32, even rounding). See the Model
    # docstring for the bit-exact semantics: the bit-level algorithm matches the
    # reference implementation; the input is a float32 (M, N) matrix.
    MXFP4_QUANT_BLOCK_SIZE = 32
    x_shape = x.shape
    if x.shape[-1] % MXFP4_QUANT_BLOCK_SIZE != 0:
        shape = list(x_shape)
        shape = shape[:-1] + [
            ((shape[-1] - 1 + MXFP4_QUANT_BLOCK_SIZE) // MXFP4_QUANT_BLOCK_SIZE)
            * MXFP4_QUANT_BLOCK_SIZE
        ]
        shape = tuple(shape)
        x_padded = torch.zeros(shape, dtype=x.dtype, device=x.device)
        x_padded[..., : x.shape[-1]] = x
    else:
        x_padded = x

    # Block scale: round amax up to a power of two, then take floor(log2) - 2
    x_padded = x_padded.reshape(
        -1, x_padded.shape[-1] // MXFP4_QUANT_BLOCK_SIZE, MXFP4_QUANT_BLOCK_SIZE
    ).to(torch.float32)
    amax, _ = torch.max(torch.abs(x_padded), dim=-1)
    amax = amax.view(torch.int32)
    amax = (amax + 0x200000) & 0xFF800000
    amax = amax.view(torch.float32)
    scale_e8m0_unbiased = torch.log2(amax).floor() - 2
    scale_e8m0_unbiased = torch.clamp(scale_e8m0_unbiased, min=-127, max=127)
    quant_scale = torch.exp2(-scale_e8m0_unbiased)

    # Quantized values
    qx = x_padded * quant_scale.unsqueeze(-1)

    # blockscale_e8m0
    bs_e8m0 = scale_e8m0_unbiased.to(torch.uint8) + 127

    # e2m1 rounding: round-half-up, saturating past the range (take min(x, 7) of
    # ((E<<2 | M>>21) + 1) >> 1)
    qx = qx.view(torch.int32)
    s = qx & 0x80000000
    e = (qx >> 23) & 0xFF
    m = qx & 0x7FFFFF

    E8_BIAS = 127
    E2_BIAS = 1
    adjusted_exponents = E8_BIAS - e - 1
    m = torch.where(e < E8_BIAS, (0x400000 | (m >> 1)) >> adjusted_exponents, m)
    e = torch.where(e > E8_BIAS - E2_BIAS, e, E8_BIAS - E2_BIAS) - (E8_BIAS - E2_BIAS)

    combined_val = (((e << 2) | (m >> 21)) + 1) >> 1
    e2m1_tmp = torch.where(combined_val < 0x7, combined_val, 0x7)
    e2m1_value = (((s >> 28) & 0xF) | e2m1_tmp).to(torch.uint8)

    # Pack 2 4-bit code words per byte: even indices occupy the low 4 bits
    x_mxfp4 = e2m1_value[..., ::2] | (e2m1_value[..., 1::2] << 4)
    x_mxfp4 = torch.flatten(x_mxfp4, -2, -1)

    # Drop the extra bytes produced by the zero padding
    if x.shape[-1] % MXFP4_QUANT_BLOCK_SIZE != 0:
        x_mxfp4 = x_mxfp4[..., : x.shape[-1] // 2]

    mxfp4_shape = list(x_shape)
    mxfp4_shape = tuple(mxfp4_shape[:-1] + [mxfp4_shape[-1] // 2])
    x_mxfp4 = x_mxfp4.reshape(mxfp4_shape)
    return x_mxfp4, bs_e8m0

class ModelNew(nn.Module):
    """Fused residual add + RMSNorm + MXFP4 dynamic quantization (mxfp4 GEMM
    preprocessing).

    Mathematical definition (all intermediates in float32; inputs are randn in
    the bfloat16/float16 value range):
      1. s = inp1 + res1                                     element-wise add
      2. norm[m, j] = s[m, j] * rsqrt( (1/N1) * sum_j s[m, j]^2 + eps ) * weight1[j]
         eps = 1e-6, normalized along the last dimension
      3. MXFP4 dynamic quantization of every row of norm in 32-element blocks
         (definition below), yielding packed e2m1 code words (2 per byte) and
         e8m0 block scale bytes.

    MXFP4 quantization (block size fixed at 32 along the last dimension; a
    trailing block shorter than 32 zero padded and taking part):
      a. amax = max |x| (inside the block, padding included)
      b. round amax up to a power of two: interpret the IEEE754 bit pattern of
         amax as int32, add 0x200000, bitwise-AND with 0xFF800000, then
         reinterpret as float32 (unchanged when amax is already a power of two,
         otherwise it goes up to the next power of two)
      c. e = clamp( floor(log2(rounded amax)) - 2, -127, 127 )
      d. scale byte = e + 127 (uint8 e8m0 encoding)
      e. q = x * 2^(-e), rounded to the e2m1 code table
         {0, +-0.5, +-1, +-1.5, +-2, +-3, +-4, +-6}: round-half-up (0.5 rounds
         up), saturating to +-6 beyond the range; the equivalent bit-level form
         is ((E<<2 | M>>21) + 1) >> 1 on the fp32 bit pattern, then min(x, 7),
         with bit31 as the sign bit
      f. packing: the 2i-th and the (2i+1)-th code words share one byte, the
         even index occupying the low 4 bits

    Input/output specification:
      inp1    (M, N1)  bfloat16/float16  main input
      weight1 (N1,)    same as inp1      RMSNorm weight
      res1    (M, N1)  same as inp1      residual
      out     (M, N1//2 + ceil(N1/32)) uint8, single-tensor output contract:
              out[:, :N1//2]        packed e2m1 code words (2 per byte, even
                                    indices in the low 4 bits)
              out[:, N1//2:]        e8m0 block scale bytes (ceil(N1/32) per row)
      Constraints: M >= 1; N1 is even and N1 >= 2.
      Boundary behaviour: an all-zero block has amax=0, handled as
      log2(0)=-inf, so after the clamp e=-127, the scale byte is 0 and the code
      words are 0.

    Implementation constraints (violations are scored as failures):
      - The core computation of RMSNorm and quantization (amax/scale
        computation, e2m1 rounding, packing) must be completed inside the
        submitted file; calling torch.nn.functional.rms_norm /
        torch.nn.RMSNorm is forbidden, as is using torch built-in float4/mxfp4
        quantization or conversion APIs (including torch.float4_e2m1fn_x2,
        torch.quantize_per_tensor and other ready-made quantization
        operators), and wrapping or modifying any third-party operator
        library's existing implementation.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate computation uses float32; the output is uint8, and both
        the code words and the scale bytes must be bit-exact against the
        reference implementation (exact match, no tolerance).
      - The evaluator casts every input to fp32 before calling forward
        (bfloat16/float16 values are exact in fp32); just compute with those
        values directly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-path residual + RMSNorm + MXFP4 dynamic quantization
    (block size 32, even rounding), without the downstream GEMM main
    computation.
    """
    def __init__(self, dtype: str = "bfloat16", eps: float = 1e-6):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.dtype = getattr(torch, dtype)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, inp1, weight1, res1):
        # <<<IMPROVE:forward_stmt_1>>>
        s = inp1.to(torch.float32) + res1.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        norm = _rmsnorm(s, weight1.to(torch.float32), self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        codes, scales = _triton_mxfp4_quant(norm)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return torch.cat([codes, scales], dim=1)
        # <<<END_IMPROVE>>>
