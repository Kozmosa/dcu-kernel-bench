import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _paged_window_attention(Q, K, V, BT, L, CU, S, O,
                            NS: tl.constexpr, HQ: tl.constexpr,
                            HK: tl.constexpr, D: tl.constexpr,
                            BS: tl.constexpr, BTS: tl.constexpr,
                            GROUP: tl.constexpr, SCALE: tl.constexpr,
                            WINDOW: tl.constexpr, CAP: tl.constexpr,
                            SINK: tl.constexpr, BD: tl.constexpr):
    r = tl.program_id(0)
    h = tl.program_id(1)
    lo = 0
    hi = NS
    while lo < hi:
        mid = (lo + hi) // 2
        boundary = tl.load(CU + mid + 1).to(tl.int32)
        before = r < boundary
        hi = tl.where(before, mid, hi)
        lo = tl.where(before, lo, mid + 1)
    seq = lo
    end = tl.load(CU + seq + 1).to(tl.int32)
    kv = tl.load(L + seq).to(tl.int32)
    pos = kv - end + r
    first = 0
    if WINDOW > 0:
        first = tl.maximum(0, pos - WINDOW + 1)
    d = tl.arange(0, BD)
    t = tl.arange(0, 64)
    q = tl.load(Q + (r * HQ + h) * D + d, d < D, 0).to(tl.float32) * SCALE
    acc = tl.full((BD,), 0, tl.float32)
    m = tl.full((), float('-inf'), tl.float32)
    z = tl.full((), 0, tl.float32)
    if SINK:
        m = tl.load(S + h).to(tl.float32)
        if CAP > 0:
            m = CAP * (2.0 / (1.0 + tl.exp(2.0 * (-m / CAP))) - 1.0)
        z = tl.full((), 1, tl.float32)
    for base in range(first, pos + 1, 64):
        j = base + t
        valid = j <= pos
        page = tl.load(BT + seq * BTS + j // BS, valid, 0).to(tl.int64)
        offsets = ((page * BS + j % BS) * HK + h // GROUP)[:, None] * D + d[None, :]
        k = tl.load(K + offsets, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        logits = tl.sum(k * q[None, :], 1)
        if CAP > 0:
            logits = CAP * (2.0 / (1.0 + tl.exp(2.0 * (-logits / CAP))) - 1.0)
        logits = tl.where(valid, logits, float('-inf'))
        new_m = tl.maximum(m, tl.max(logits, 0))
        correction = tl.exp(m - new_m)
        weights = tl.exp(logits - new_m)
        z = z * correction + tl.sum(weights, 0)
        v = tl.load(V + offsets, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        acc = acc * correction + tl.sum(weights[:, None] * v, 0)
        m = new_m
    tl.store(O + (r * HQ + h) * D + d, acc / z, d < D)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Unified variable-length attention: paged attention with prefill and decode sequences mixed.

    The num_seqs sequences in the batch share one packed query tensor: the
    queries of sequence s are stored contiguously in the row range
    [cu_seqlens_q[s], cu_seqlens_q[s+1]), q_s = cu_seqlens_q[s+1] -
    cu_seqlens_q[s] rows in total (q_s == 1 is a decode sequence, q_s > 1 is a
    prefill sequence, and the two may be mixed arbitrarily within the batch); the
    KV length of that sequence is kv_s = seq_lens[s], and kv_s >= q_s is
    guaranteed. The KV is not stored contiguously but addressed page-wise: the
    physical address of logical token position j (0 <= j < kv_s) is
      key_cache[block_tables[s, j // block_size], j % block_size, g, :]
      value_cache[block_tables[s, j // block_size], j % block_size, g, :]
    where g is the KV head index. Slots in the physical block pool that are not
    referenced are garbage data and must not participate in the computation; only
    the first ceil(kv_s / block_size) entries of each row of block_tables are
    valid.

    For the i-th query of sequence s (0 <= i < q_s, with in-KV-sequence absolute
    position T = kv_s - q_s + i and row index r = cu_seqlens_q[s] + i) and query
    head h (the corresponding KV head is g = h // query_group_size,
    query_group_size = num_q_heads // num_kv_heads):
      logits[j] = scale * <query[r, h, :], K_phys(j, g, :)>
                  scale defaults to 1 / sqrt(head_size)
      visibility (causal, query right-aligned against the KV): j <= T; if
      sliding_window > 0, additionally T - j < sliding_window (the left window edge)
      if use_sinks=True: one extra virtual sink column is introduced whose logit
      is always sinks[h] and whose value is always the zero vector, and which is
      never masked
      if softcap > 0: all logits (including the sink column) first go through
      c * tanh(logit / c) (c = softcap), and only then the mask and the softmax
      p = softmax(visible logits)
      out[r, h, :] = sum_j p[j] * V_phys(j, g, :)   (the sink column contributes the zero vector)
    The causal right alignment guarantees that every query sees at least its own
    position, so the softmax denominator is always > 0.

    Input/output specification (evaluation dtype is float16 / bfloat16, all
    tensors contiguous):
      query         eval dtype (total_q, num_q_heads, head_size)
                    total_q = cu_seqlens_q[-1]
      key_cache     eval dtype (num_blocks, block_size, num_kv_heads, head_size)
      value_cache   eval dtype, same shape as key_cache
      block_tables  int32 (num_seqs, max_blocks_per_seq) logical block -> physical block id
      seq_lens      int32 (num_seqs) valid KV length kv_s of each sequence (>= q_s)
      cu_seqlens_q  int32 (num_seqs + 1) prefix sum of the query lengths, first element 0
      sinks         eval dtype (num_q_heads) per-head sink logit
                    (ignored when use_sinks=False)
      returns out   eval dtype (total_q, num_q_heads, head_size), aligned with the query rows

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        flex_attention / aiter / torch.matmul / torch.bmm / torch.einsum /
        torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to the
        input dtype.
      - The evaluator casts every input tensor to fp32 before calling forward;
        block table ids, sequence lengths and the position prefix sums are small
        integers that fp32 represents exactly, so .to(torch.int32) /
        .to(torch.long) at the entry recovers them losslessly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: paged KV + prefill/decode mixed ragged batch + GQA + causal right
    alignment + sliding window + logit softcap + attention sinks; no ALiBi, no
    query-query bias, no multimodal bidirectional prefix, no fp8 quantized KV with
    dequantization scales -- those variants are left as separate follow-up tasks.
    """
    def __init__(self, head_size: int, sliding_window: int = 0, softcap: float = 0.0, use_sinks: bool = True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = 1.0 / math.sqrt(head_size)
        self.sliding_window = int(sliding_window)
        self.softcap = float(softcap)
        self.use_sinks = bool(use_sinks)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens, cu_seqlens_q, sinks):
        # <<<IMPROVE:forward_stmt_1>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_seqs = seq_lens.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        block_size = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_kv_heads = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        head_size = key_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        num_q_heads = query.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        group = num_q_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert num_q_heads == num_kv_heads * group, \
            "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        if query.shape[0] > 0:
            _paged_window_attention[(query.shape[0], num_q_heads)](
                query, key_cache, value_cache, block_tables, seq_lens,
                cu_seqlens_q, sinks, out,
                num_seqs, num_q_heads, num_kv_heads, head_size,
                block_size, block_tables.stride(0), group, self.scale,
                self.sliding_window, self.softcap, self.use_sinks,
                triton.next_power_of_2(head_size), num_warps=4, num_stages=2
            )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
