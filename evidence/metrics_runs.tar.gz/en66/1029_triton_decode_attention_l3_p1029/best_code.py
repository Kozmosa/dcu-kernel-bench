import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _paged_partial(Q, K, V, PT, L, M, Z, A,
                   HQ: tl.constexpr, G: tl.constexpr, PS: tl.constexpr,
                   DK: tl.constexpr, DV: tl.constexpr, S: tl.constexpr,
                   QS0: tl.constexpr, QS1: tl.constexpr, QS2: tl.constexpr,
                   KS0: tl.constexpr, KS1: tl.constexpr, KS2: tl.constexpr,
                   VS0: tl.constexpr, VS1: tl.constexpr, VS2: tl.constexpr,
                   PT0: tl.constexpr, PT1: tl.constexpr, LS: tl.constexpr,
                   SCALE: tl.constexpr, BK: tl.constexpr, BV: tl.constexpr):
    b = tl.program_id(0)
    h = tl.program_id(1)
    s = tl.program_id(2)
    length = tl.load(L + b * LS)
    start = length * s // S
    end = length * (s + 1) // S
    kd = tl.arange(0, BK)
    vd = tl.arange(0, BV)
    t = tl.arange(0, 32)
    if DK == 192:
        kd0 = tl.arange(0, 128)
        kd1 = 128 + tl.arange(0, 64)
        q0 = tl.load(Q + b * QS0 + h * QS1 + kd0 * QS2).to(tl.float32) * SCALE
        q1 = tl.load(Q + b * QS0 + h * QS1 + kd1 * QS2).to(tl.float32) * SCALE
    else:
        q = tl.load(Q + b * QS0 + h * QS1 + kd * QS2, kd < DK, 0).to(tl.float32) * SCALE
    maximum = tl.full((), -float('inf'), tl.float32)
    total = tl.full((), 0, tl.float32)
    acc = tl.full((BV,), 0, tl.float32)
    for base in range(start, end, 32):
        pos = base + t
        valid = pos < end
        page = tl.load(PT + b * PT0 + (pos // PS) * PT1, valid, 0).to(tl.int64)
        slot = page * PS + pos % PS
        if DK == 192:
            k0 = tl.load(K + slot[:, None] * KS0 + (h // G) * KS1 + kd0[None, :] * KS2,
                         valid[:, None], 0).to(tl.float32)
            logits = tl.sum(k0 * q0[None, :], 1)
            k1 = tl.load(K + slot[:, None] * KS0 + (h // G) * KS1 + kd1[None, :] * KS2,
                         valid[:, None], 0).to(tl.float32)
            logits = logits + tl.sum(k1 * q1[None, :], 1)
        else:
            k = tl.load(K + slot[:, None] * KS0 + (h // G) * KS1 + kd[None, :] * KS2,
                        valid[:, None] & (kd[None, :] < DK), 0).to(tl.float32)
            logits = tl.sum(k * q[None, :], 1)
        logits = tl.where(valid, logits, -float('inf'))
        new_max = tl.maximum(maximum, tl.max(logits, 0))
        alpha = tl.exp(maximum - new_max)
        p = tl.exp(logits - new_max)
        v = tl.load(V + slot[:, None] * VS0 + (h // G) * VS1 + vd[None, :] * VS2,
                    valid[:, None] & (vd[None, :] < DV), 0).to(tl.float32)
        acc = acc * alpha + tl.sum(p[:, None] * v, 0)
        total = total * alpha + tl.sum(p, 0)
        maximum = new_max
    idx = (b * HQ + h) * S + s
    tl.store(M + idx, maximum)
    tl.store(Z + idx, total)
    tl.store(A + idx * DV + vd, acc, vd < DV)


@triton.jit
def _paged_merge(M, Z, A, O, HQ: tl.constexpr, S: tl.constexpr,
                 DV: tl.constexpr, BS: tl.constexpr, BV: tl.constexpr):
    b = tl.program_id(0)
    h = tl.program_id(1)
    s = tl.arange(0, BS)
    d = tl.arange(0, BV)
    idx = (b * HQ + h) * S + s
    m = tl.load(M + idx, s < S, -float('inf'))
    z = tl.load(Z + idx, s < S, 0)
    largest = tl.max(m, 0)
    safe_m = tl.where(z > 0, m, largest)
    weight = tl.where(z > 0, tl.exp(safe_m - largest), 0)
    a = tl.load(A + idx[:, None] * DV + d[None, :],
                (s[:, None] < S) & (d[None, :] < DV), 0)
    numerator = tl.sum(a * weight[:, None], 0)
    denominator = tl.sum(z * weight, 0)
    tl.store(O + (b * HQ + h) * DV + d, numerator / denominator, d < DV)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Decode-stage attention (single-token query) with paged KV.

    The KV cache is paged at page_size granularity: slot s of physical page p in
    key_cache / value_cache corresponds to flat slot number p * page_size + s.
    Sequence b is addressed indirectly through page_tables, and its l-th KV token
    (0 <= l < seq_lens[b]) lives in slot l % page_size of physical page
    page_tables[b, l // page_size]; slots in the page pool that are not
    referenced are garbage data and must not affect the output. Query head h
    corresponds to KV head h // query_group_size
    (query_group_size = num_q_heads // num_kv_heads, equal to 1 means MHA, equal
    to num_q_heads means MQA). For every sequence b and every query head h:
      logits[l] = scale * <q[b,h,:head_dim_qk],
                            key_flat[slot(b,l), h//group, :head_dim_qk]>
      p[l]      = exp(logits[l] - max(logits)) / sum(exp(logits - max(logits)))
      out[b,h,:head_dim_v] = sum_l p[l] * value_flat[slot(b,l), h//group, :head_dim_v]
    where key_flat / value_flat is the [num_pages*page_size, H_KV, D] flat view of
    the page pool, scale defaults to 1/sqrt(head_dim_qk), and the softmax must be
    numerically stable.

    Any implementation that is numerically equivalent within the tolerance is
    acceptable; how the work is parallelized is **not** a scoring criterion.

    Boundary behaviour:
      - Only the first seq_lens[b] KV tokens participate in the computation;
        seq_lens[b] >= 1 (an empty sequence is undefined).
      - page_size >= 1 is an arbitrary value (with page_size == 1 the page_tables
        are simply a per-token slot table).
      - head_dim_qk and head_dim_v may differ, and non-power-of-2 is allowed (for
        example 192/128, 576/512); the channels short of a power of 2 are handled
        by masking, so no out-of-bounds access occurs.
      - The page pool may be larger than what is actually used; page_tables
        entries beyond ceil(seq_lens[b]/page_size) point at valid but garbage
        pages that do not belong to this sequence.

    Inputs:
      q           [num_seqs, num_q_heads, head_dim_qk]  fp16/bf16 -- the query of
                  one new token per batch
      key_cache   [num_pages, page_size, num_kv_heads, head_dim_qk]
      value_cache [num_pages, page_size, num_kv_heads, head_dim_v]
      page_tables [num_seqs, max_pages_per_seq] int32 -- logical page -> physical page id
      seq_lens    [num_seqs] int32 -- the actually valid KV length of each sequence
    Output:
      out [num_seqs, num_q_heads, head_dim_v], dtype same as q.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV / cross-slice reduction) must
        be completed inside the submitted file; calling external attention
        operator libraries such as scaled_dot_product_attention / sdpa /
        flash_attn, as well as torch.matmul / torch.bmm / torch.einsum /
        torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, non-quantized KV, no logit_cap clamping, no
    ALiBi, no sliding window.
    """
    def __init__(self, page_size: int, head_dim_qk: int, head_dim_v: int, num_kv_splits: int = 8, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.page_size = int(page_size)
        self.head_dim_qk = int(head_dim_qk)
        self.head_dim_v = int(head_dim_v)
        self.num_kv_splits = int(num_kv_splits)
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim_qk)
        # <<<END_IMPROVE>>>

    def forward(self, q, key_cache, value_cache, page_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        # Read integer page tables directly; physical addresses are widened in the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D_QK = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_pages, page_size, H_KV, _ = key_cache.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        D_V = value_cache.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert page_size == self.page_size, "the key_cache page size does not match the initialized page_size"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        key_flat = key_cache.view(num_pages * page_size, H_KV, D_QK)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        value_flat = value_cache.view(num_pages * page_size, H_KV, D_V)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty(B, H_Q, D_V, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        S = max(1, self.num_kv_splits)
        partial_max = torch.empty((B, H_Q, S), device=q.device, dtype=torch.float32)
        partial_sum = torch.empty_like(partial_max)
        partial_value = torch.empty((B, H_Q, S, D_V), device=q.device, dtype=torch.float32)
        _paged_partial[(B, H_Q, S)](
            q, key_flat, value_flat, page_tables, seq_lens,
            partial_max, partial_sum, partial_value,
            H_Q, group, page_size, D_QK, D_V, S,
            *q.stride(), *key_flat.stride(), *value_flat.stride(),
            *page_tables.stride(), seq_lens.stride(0), self.scale,
            triton.next_power_of_2(D_QK), triton.next_power_of_2(D_V),
            num_warps=4)
        _paged_merge[(B, H_Q)](
            partial_max, partial_sum, partial_value, out,
            H_Q, S, D_V, triton.next_power_of_2(S), triton.next_power_of_2(D_V),
            num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
