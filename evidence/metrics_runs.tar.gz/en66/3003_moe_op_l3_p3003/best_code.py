import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _moe_grouped_gemm_kernel(
    a_ptr, b_ptr, w_ptr, sorted_ptr, expert_ptr, ntp_ptr, out_ptr,
    K, N, top_k, num_slots,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    rows = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    cols = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    num_padded = tl.load(ntp_ptr)
    row_mask = rows < num_padded
    block_id = (pid_m * BLOCK_M) // 64
    expert = tl.load(expert_ptr + block_id, mask=pid_m * BLOCK_M < num_padded, other=0)
    sorted_ids = tl.load(sorted_ptr + rows, mask=row_mask, other=num_slots)
    valid = row_mask & (sorted_ids < num_slots)
    safe_slots = tl.where(valid, sorted_ids, 0)
    src_rows = safe_slots // top_k
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for k0 in range(0, K, BLOCK_K):
        ks = k0 + tl.arange(0, BLOCK_K)
        k_mask = ks < K
        a = tl.load(
            a_ptr + src_rows[:, None] * K + ks[None, :],
            mask=valid[:, None] & k_mask[None, :],
            other=0.0,
        )
        b = tl.load(
            b_ptr + expert * N * K + cols[None, :] * K + ks[:, None],
            mask=k_mask[:, None] & (cols[None, :] < N),
            other=0.0,
        )
        acc = tl.dot(a, b, acc)
    weights = tl.load(w_ptr + safe_slots, mask=valid, other=0.0).to(tl.float32)
    result = acc * weights[:, None]
    tl.store(
        out_ptr + safe_slots[:, None] * N + cols[None, :],
        result,
        mask=valid[:, None] & (cols[None, :] < N),
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """MoE (Mixture-of-Experts) routed grouped GEMM: non-quantized weights, with
    routing weighting.

    Each token's feature vector A[m] (K dimensions) is dispatched by the routing
    table topk_ids to top_k of the num_experts experts; expert e owns the weight
    matrix B[e] (N x K). For each token m and its j-th routing slot (write
    e = topk_ids[m, j]), the output is defined as

        C[m, j, n] = topk_weights[m, j] * sum_k A[m, k] * B[e, n, k]

    i.e. grouped GEMM followed by a per-slot multiply by the routing weight;
    intermediate accumulation is float32 and the output is cast back to the
    input dtype. Every (m, j) slot hits a legal expert inside [0, num_experts),
    so no output is undefined.

    The inputs also carry the block-aligned layout of grouped GEMM (produced by
    the upstream router; fetching data through it is exactly equivalent to
    computing the formula above directly):
      - sorted_token_ids: int32, length EM = M*top_k + num_experts*(block_m-1),
        with block_m always 64 in this task. Number the slots flat as
        p = m*top_k + j, regroup them by ascending expert id, and pad each group
        up to a multiple of block_m; the intra-group padding positions and the
        array tail hold the sentinel value M*top_k (that is num_valid_tokens;
        offs_token >= it means padding and produces no output).
      - expert_ids: int32, length M*top_k + num_experts; the expert id owning
        block t (covering sorted_token_ids[t*block_m : (t+1)*block_m]), values
        in [0, num_experts), no -1; positions past the number of blocks implied
        by num_tokens_post_padded are sentinel fill and must not be read.
      - num_tokens_post_padded: int32 scalar (length 1), the valid length of
        sorted_token_ids (intra-block padding included), always a multiple of
        block_m.
    The kernel's BLOCK_SIZE_M must divide block_m (that is, be a factor of 64)
    so that every program block sees a single expert.

    Input/output specification:
        A                       (M, K)             float16/bfloat16
        B                       (E, N, K)          same as A (E = num_experts)
        topk_weights            (M, top_k)         float32
        topk_ids                (M, top_k)         int32
        sorted_token_ids        (EM,)              int32
        expert_ids              (M*top_k + E,)     int32
        num_tokens_post_padded  (1,)               int32
        returns C               (M, top_k, N)      dtype same as A

    Implementation constraints (violations are scored as failures):
        - Core computation (layout-driven data fetch + grouped GEMM + weighted
          routing write-out) must be done in a Triton kernel inside the
          submitted file; calling torch.matmul / torch.mm / torch.bmm /
          torch.baddbmm / torch.addmm / torch.einsum /
          torch.nn.functional.linear or any precompiled operator library for
          any matrix multiply is forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate accumulation; the output is cast back to
          the input dtype.
        - Sentinel padding slots must not contaminate any valid output.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: non-quantized fp16/bf16 weights and activations (no w8a8 / int4 /
    mxfp4 quantization), no fused activation (SiLU/GELU etc.), no bias,
    top_k <= 8, num_experts <= 256.
    """
    def __init__(self, num_experts: int, top_k: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = num_experts
        self.top_k = top_k
        # <<<END_IMPROVE>>>

    def forward(self, A, B, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        # <<<IMPROVE:forward_stmt_1>>>
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        sorted_token_ids = sorted_token_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        expert_ids = expert_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens_post_padded = num_tokens_post_padded.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = A.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        E, N, _ = B.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        a = A
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        b = B
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        w = topk_weights.reshape(-1)
        num_valid = int(num_tokens_post_padded[0].item())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty((M, top_k, N), dtype=A.dtype, device=A.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        flat_out = out.view(M * top_k, N)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        a_rp = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        flat_ids = None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        _moe_grouped_gemm_kernel[
                            (triton.cdiv(num_valid, 64), triton.cdiv(N, 64))
                        ](
                            a, b, w, sorted_token_ids, expert_ids, num_tokens_post_padded,
                            flat_out, K, N, top_k, M * top_k,
                            BLOCK_M=64, BLOCK_N=64, BLOCK_K=32, num_warps=4,
                        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return out.to(A.dtype)
        # <<<END_IMPROVE>>>
