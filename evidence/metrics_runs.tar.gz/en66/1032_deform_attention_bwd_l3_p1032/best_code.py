import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

def _deform_attn_forward(value_f, spatial_shapes, level_start_index,
                         sampling_locations_f, attention_weights_f):
    """Multi-scale deformable attention forward (float32, hand-written the same way as task 1031).

    Semantically identical to the reference of task 1031: coordinate expansion,
    four-corner zero-padded bilinear interpolation, softmax normalization of the
    sampling weights over the flattened (levels x points) dimension, and the
    cross-sampling-point weighted reduction. The only difference is that the floor
    path is detached first (the subgradient convention that the floor gradient is
    0 is made explicit, so the gradient only flows back through the interpolation
    fractions fx/fy); numerically it is exactly the same as the forward.
    All inputs are float32 tensors (the caller is responsible for the cast and for
    requires_grad); returns the uncast float32 output (N, Q, heads*D) for the
    gradient chain to use.
    """
    n, n_keys, num_heads, d = value_f.shape
    n_levels = spatial_shapes.shape[0]
    n_queries = sampling_locations_f.shape[1]
    n_points = sampling_locations_f.shape[4]

    # Normalize the sampling weights: flatten (levels x points) into one
    # dimension and run a numerically stable softmax
    wf = attention_weights_f.reshape(n, n_queries, num_heads,
                                     n_levels * n_points)
    wf = torch.softmax(wf, dim=-1).view(n, n_queries, num_heads,
                                        n_levels, n_points)

    n_idx = torch.arange(n, device=value_f.device).view(n, 1, 1)
    h_idx = torch.arange(num_heads, device=value_f.device).view(1, 1, num_heads)

    out = torch.zeros(n, n_queries, num_heads, d,
                      dtype=torch.float32, device=value_f.device)
    for l in range(n_levels):
        h_l = int(spatial_shapes[l, 0])
        w_l = int(spatial_shapes[l, 1])
        base = int(level_start_index[l])
        v_l = value_f[:, base: base + h_l * w_l]   # (n, H_l*W_l, heads, d)

        # normalized coordinates x level size -> real-valued sampling
        # coordinates (channel 0 along W, channel 1 along H)
        sx = sampling_locations_f[:, :, :, l, :, 0] * float(w_l)
        sy = sampling_locations_f[:, :, :, l, :, 1] * float(h_l)
        # The floor / integer-index path is treated as a constant (detached
        # explicitly); the gradient only flows back through fx/fy
        ix0 = torch.floor(sx.detach()).to(torch.long)
        iy0 = torch.floor(sy.detach()).to(torch.long)
        fx = sx - ix0.to(torch.float32)
        fy = sy - iy0.to(torch.float32)

        def corner(iy, ix, wgt):
            # Single-corner sampling: an out-of-range corner contributes 0
            # (zero padding semantics); the clamp only guards the index
            # against going out of range and is cancelled by the 0 weight
            valid = ((iy >= 0) & (iy <= h_l - 1)
                     & (ix >= 0) & (ix <= w_l - 1)).to(torch.float32)
            flat = iy.clamp(0, h_l - 1) * w_l + ix.clamp(0, w_l - 1)
            vals = v_l[n_idx, flat, h_idx]        # (n, q, heads, P, d)
            return vals * (valid * wgt).unsqueeze(-1)

        for p in range(n_points):
            iy0p, ix0p = iy0[..., p], ix0[..., p]      # (n, q, heads)
            fyp, fxp = fy[..., p], fx[..., p]
            sampled = (corner(iy0p, ix0p, (1.0 - fyp) * (1.0 - fxp))
                       + corner(iy0p, ix0p + 1, (1.0 - fyp) * fxp)
                       + corner(iy0p + 1, ix0p, fyp * (1.0 - fxp))
                       + corner(iy0p + 1, ix0p + 1, fyp * fxp))
            out = out + wf[:, :, :, l, p].unsqueeze(-1) * sampled

    return out.view(n, n_queries, num_heads * d)

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1032_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor deform_attention_backward(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_attention_backward", &deform_attention_backward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cmath>

__global__ void zero_values(float* out, int64_t count) {
    for (int64_t i = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
         i < count; i += (int64_t)gridDim.x * blockDim.x) out[i] = 0.0f;
}

template<class T, class ShapeT, class StartT, bool SingleWave>
__global__ void deform_backward_kernel(
    const T* value, const ShapeT* shapes, const StartT* starts,
    const T* loc, const T* logits, const T* go, float* out, float* ts,
    int64_t K, int64_t heads, int64_t D, int64_t Q, int64_t P,
    int64_t S, int64_t V, int64_t A) {
    const int tid = threadIdx.x;
    const int64_t row = blockIdx.x;
    const int64_t n = row / (Q * heads), h = row % heads;
    const int64_t first = row * S;
    __shared__ float maximum, invsum;
    __shared__ float red[3][4];
    __shared__ float weight_cache[256];
    if (tid == 0) {
        float m = -INFINITY;
        for (int64_t p = 0; p < S; ++p) m = fmaxf(m, (float)logits[first+p]);
        float sum = 0.0f;
        for (int64_t p = 0; p < S; ++p) {
            float e = expf((float)logits[first+p] - m);
            sum += e;
            if (S <= 256) weight_cache[p] = e;
        }
        maximum = m;
        invsum = 1.0f / sum;
        if (S <= 256) {
            for (int64_t p = 0; p < S; ++p) weight_cache[p] *= invsum;
        }
    }
    __syncthreads();
    for (int64_t p = 0; p < S; ++p) {
        const int64_t idx = first + p, level = p / P;
        const int64_t H = (int64_t)shapes[2*level];
        const int64_t W = (int64_t)shapes[2*level+1];
        float x = (float)loc[2*idx] * (float)W;
        float y = (float)loc[2*idx+1] * (float)H;
        int64_t ix = (int64_t)floorf(x), iy = (int64_t)floorf(y);
        float fx = x - (float)ix, fy = y - (float)iy;
        float cw[4] = {(1-fy)*(1-fx), (1-fy)*fx, fy*(1-fx), fy*fx};
        bool valid[4];
        int64_t offsets[4];
        for (int k = 0; k < 4; ++k) {
            int64_t xx = ix + (k & 1), yy = iy + (k >> 1);
            valid[k] = xx >= 0 && xx < W && yy >= 0 && yy < H;
            offsets[k] = ((n*K + (int64_t)starts[level] + yy*W + xx)*heads + h)*D;
        }
        float w = S <= 256 ? weight_cache[p] : expf((float)logits[idx] - maximum) * invsum;
        float t = 0, dx = 0, dy = 0;
        for (int64_t c = tid; c < D; c += SingleWave ? warpSize : 128) {
            float v[4];
            float g = (float)go[row*D+c];
            float wg = w*g;
            for (int k = 0; k < 4; ++k) {
                v[k] = valid[k] ? (float)value[offsets[k]+c] : 0.0f;
                if (valid[k]) atomicAdd(out+offsets[k]+c, wg*cw[k]);
            }
            float sample = ((v[0]*cw[0] + v[1]*cw[1]) + v[2]*cw[2]) + v[3]*cw[3];
            t += g*sample;
            dx += wg*((1-fy)*(v[1]-v[0]) + fy*(v[3]-v[2]));
            dy += wg*((1-fx)*(v[2]-v[0]) + fx*(v[3]-v[1]));
        }
        const int lane = tid % warpSize;
        for (int offset = warpSize / 2; offset > 0; offset >>= 1) {
            t += __shfl_down(t, offset, warpSize);
            dx += __shfl_down(dx, offset, warpSize);
            dy += __shfl_down(dy, offset, warpSize);
        }
        if (SingleWave) {
            if (lane == 0) {
                ts[idx] = t;
                out[V+2*idx] = dx*(float)W;
                out[V+2*idx+1] = dy*(float)H;
            }
        } else {
            const int wave = tid / warpSize;
            if (lane == 0) {
                red[0][wave] = t;
                red[1][wave] = dx;
                red[2][wave] = dy;
            }
            __syncthreads();
            if (wave == 0) {
                t = lane < 128 / warpSize ? red[0][lane] : 0.0f;
                dx = lane < 128 / warpSize ? red[1][lane] : 0.0f;
                dy = lane < 128 / warpSize ? red[2][lane] : 0.0f;
                for (int offset = warpSize / 2; offset > 0; offset >>= 1) {
                    t += __shfl_down(t, offset, warpSize);
                    dx += __shfl_down(dx, offset, warpSize);
                    dy += __shfl_down(dy, offset, warpSize);
                }
                if (tid == 0) {
                    ts[idx] = t;
                    out[V+2*idx] = dx*(float)W;
                    out[V+2*idx+1] = dy*(float)H;
                }
            }
            __syncthreads();
        }
    }
    if (tid == 0) {
        float mean = 0;
        for (int64_t p = 0; p < S; ++p)
            mean += (S <= 256 ? weight_cache[p] : expf((float)logits[first+p]-maximum)*invsum)*ts[first+p];
        for (int64_t p = 0; p < S; ++p) {
            float w = S <= 256 ? weight_cache[p] : expf((float)logits[first+p]-maximum)*invsum;
            out[V+2*A+first+p] = S == 1 ? 0.0f : w*(ts[first+p]-mean);
        }
    }
}

template<class T>
__global__ void cast_packed(const float* src, T* dst, int64_t count) {
    for (int64_t i = (int64_t)blockIdx.x*blockDim.x+threadIdx.x;
         i < count; i += (int64_t)gridDim.x*blockDim.x) dst[i] = (T)src[i];
}

static void check_launch() {
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "HIP launch failed: ", hipGetErrorString(err));
}

template<class T, class ShapeT, class StartT>
static void launch_backward(
    const T* value, const ShapeT* shapes, const StartT* starts,
    const T* loc, const T* logits, const T* go, float* out, float* ts,
    int64_t K, int64_t heads, int64_t D, int64_t Q, int64_t P,
    int64_t S, int64_t V, int64_t A, hipStream_t stream, int wave) {
    if (D <= wave) {
        deform_backward_kernel<T, ShapeT, StartT, true><<<(unsigned int)(A/S), wave, 0, stream>>>(
            value, shapes, starts, loc, logits, go, out, ts,
            K, heads, D, Q, P, S, V, A);
    } else {
        deform_backward_kernel<T, ShapeT, StartT, false><<<(unsigned int)(A/S),128,0,stream>>>(
            value, shapes, starts, loc, logits, go, out, ts,
            K, heads, D, Q, P, S, V, A);
    }
}

torch::Tensor deform_attention_backward(torch::Tensor value, torch::Tensor shapes,
    torch::Tensor starts, torch::Tensor loc, torch::Tensor logits, torch::Tensor go) {
    c10::cuda::CUDAGuard guard(value.device());
    auto stream = c10::cuda::getCurrentCUDAStream(value.get_device()).stream();
    const int64_t V = value.numel(), A = logits.numel(), total = V+3*A;
    const int64_t K = value.size(1), heads = value.size(2), D = value.size(3);
    const int64_t Q = loc.size(1), P = loc.size(4), S = loc.size(3)*P;
    TORCH_CHECK((shapes.scalar_type() == torch::kFloat32 || shapes.scalar_type() == torch::kInt64) &&
                (starts.scalar_type() == torch::kFloat32 || starts.scalar_type() == torch::kInt64),
                "metadata must be float32 or int64");
    hipDeviceProp_t prop;
    TORCH_CHECK(hipGetDeviceProperties(&prop, value.get_device()) == hipSuccess,
                "unable to query HIP device properties");
    const int wave = prop.warpSize;
    auto workspace = torch::empty({total}, value.options().dtype(torch::kFloat32));
    auto scratch = torch::empty({A}, value.options().dtype(torch::kFloat32));
    int blocks = (int)std::min<int64_t>((V+255)/256, 65535);
    zero_values<<<blocks,256,0,stream>>>(workspace.data_ptr<float>(), V);
    check_launch();
    AT_DISPATCH_FLOATING_TYPES_AND_HALF(value.scalar_type(), "deform_backward", [&] {
        if (shapes.scalar_type() == torch::kFloat32 && starts.scalar_type() == torch::kFloat32)
            launch_backward<scalar_t,float,float>(value.data_ptr<scalar_t>(), shapes.data_ptr<float>(), starts.data_ptr<float>(), loc.data_ptr<scalar_t>(), logits.data_ptr<scalar_t>(), go.data_ptr<scalar_t>(), workspace.data_ptr<float>(), scratch.data_ptr<float>(), K, heads, D, Q, P, S, V, A, stream, wave);
        else if (shapes.scalar_type() == torch::kFloat32 && starts.scalar_type() == torch::kInt64)
            launch_backward<scalar_t,float,int64_t>(value.data_ptr<scalar_t>(), shapes.data_ptr<float>(), starts.data_ptr<int64_t>(), loc.data_ptr<scalar_t>(), logits.data_ptr<scalar_t>(), go.data_ptr<scalar_t>(), workspace.data_ptr<float>(), scratch.data_ptr<float>(), K, heads, D, Q, P, S, V, A, stream, wave);
        else if (shapes.scalar_type() == torch::kInt64 && starts.scalar_type() == torch::kFloat32)
            launch_backward<scalar_t,int64_t,float>(value.data_ptr<scalar_t>(), shapes.data_ptr<int64_t>(), starts.data_ptr<float>(), loc.data_ptr<scalar_t>(), logits.data_ptr<scalar_t>(), go.data_ptr<scalar_t>(), workspace.data_ptr<float>(), scratch.data_ptr<float>(), K, heads, D, Q, P, S, V, A, stream, wave);
        else
            launch_backward<scalar_t,int64_t,int64_t>(value.data_ptr<scalar_t>(), shapes.data_ptr<int64_t>(), starts.data_ptr<int64_t>(), loc.data_ptr<scalar_t>(), logits.data_ptr<scalar_t>(), go.data_ptr<scalar_t>(), workspace.data_ptr<float>(), scratch.data_ptr<float>(), K, heads, D, Q, P, S, V, A, stream, wave);
    });
    check_launch();
    if (value.scalar_type() == torch::kFloat32) return workspace;
    auto result = torch::empty({total}, value.options());
    blocks = (int)std::min<int64_t>((total+255)/256, 65535);
    AT_DISPATCH_FLOATING_TYPES_AND_HALF(value.scalar_type(), "cast_deform_backward", [&] {
        cast_packed<scalar_t><<<blocks,256,0,stream>>>(workspace.data_ptr<float>(), result.data_ptr<scalar_t>(), total);
    });
    check_launch();
    return result;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Multi-Scale Deformable Attention Backward (deform_attn_dgrad): given the forward inputs and the upstream gradient grad_output, one call computes the gradients of value, sampling_locations and attention_weights at once.

    Forward semantics (all intermediate computation float32, the same convention
    as the companion forward task): value (N, n_keys, heads, D) is the
    concatenation of the multi-scale feature levels -- level l contributes
    spatial_shapes[l] = (H_l, W_l) keys, laid out inside the level in row-major
    order (H first, then W) over [level_start_index[l], level_start_index[l] +
    H_l*W_l), where level_start_index must be the prefix sum of the per-level
    H_l*W_l (first element 0) and n_keys = sum_l H_l*W_l. The last dimension of
    sampling_locations (N, Q, heads, L, P, 2) holds the normalized coordinates
    (x, y): channel 0 runs along W and channel 1 along H (generation domain
    [0,1)), so the actual sampling coordinates are loc_x = x * W_l and loc_y =
    y * H_l; the sampled value goes through four-corner bilinear interpolation
    (floor + the fractions fx/fy, with zero padding semantics where an
    out-of-range corner contributes 0, and no clamp / nearest-neighbour
    pull-back); attention_weights (N, Q, heads, L, P) are non-negative
    unnormalized scores, first flattened over (levels x points) into one
    dimension and normalized by a numerically stable softmax (max subtraction)
    into convex-combination weights, then used in the weighted sum against the
    interpolated value of each sampling point, producing the output o
    (N, Q, heads*D).

    Backward semantics (backpropagated through the float32 forward described
    above, at the point before the output is cast back to the value dtype;
    grad_output is first cast to float32): write dO for the float32 form of
    grad_output, w = softmax(attention_weights flattened over L*P), S_{l,p}[c] for
    the four-corner zero-padded bilinear sample of point (l,p), and
    t_{l,p} = <dO, S_{l,p}>; the three gradients are then the analytic gradients
    of o with respect to the three floating-point inputs:
      grad_value[n, key, h, c] = sum_{q, l, p} w_{l,p} * corner_weight *
                                 dO[n, q, h*D + c]
        (per-corner scatter accumulation; out-of-range corners do not scatter)
      grad_sampling_locations[n, q, h, l, p, 0] =
          sum_c dO[n, q, h*D + c] * w_{l,p} * W_l *
          ((1-fy) * (v01 - v00) + fy * (v11 - v10))
      grad_sampling_locations[n, q, h, l, p, 1] =
          sum_c dO[n, q, h*D + c] * w_{l,p} * H_l *
          ((1-fx) * (v10 - v00) + fx * (v11 - v01))
        (v00/v01/v10/v11 are the four corner pixel values of that point, with an
        out-of-range corner counted as 0; the gradient only flows back through
        the fractions fx/fy, and the floor / integer-index path has gradient 0 --
        the standard subgradient of bilinear sampling)
      grad_attention_weights[n, q, h, l, p] = w_{l,p} *
          (t_{l,p} - sum_{l', p'} w_{l',p'} * t_{l',p'})
        (softmax backprop; identically 0 when L*P = 1)
    The softmax, the interpolation, the weighted reduction and all gradient
    accumulation are done in float32, and the three gradients are each cast back
    to the value dtype and then packed into the output.

    Output contract (single tensor, one-dimensional concatenation packing, the
    segment order is fixed and must not be swapped):
      out = cat([grad_value.reshape(-1),
                 grad_sampling_locations.reshape(-1),
                 grad_attention_weights.reshape(-1)])
      a one-dimensional tensor with the same dtype as value, of length
          = n*n_keys*heads*D + n*n_queries*heads*L*P*2 + n*n_queries*heads*L*P
      segment 0 grad_value: n*n_keys*heads*D elements, (N, n_keys, heads, D)
          flattened row-major;
      segment 1 grad_sampling_locations: n*n_queries*heads*L*P*2 elements,
          (N, Q, heads, L, P, 2) flattened row-major (the (x, y) channel order of
          the last dimension is preserved);
      segment 2 grad_attention_weights: n*n_queries*heads*L*P elements,
          (N, Q, heads, L, P) flattened row-major.

    Input/output specification (all tensors contiguous):
      value              float32 / float16 (N, n_keys, heads, D)
      spatial_shapes     int64 (L, 2), each row (H_l, W_l), H_l / W_l >= 1
      level_start_index  int64 (L,), prefix sum of the per-level key counts
      sampling_locations same dtype as value (N, Q, heads, L, P, 2), generation domain [0,1)
      (with an fp16 input individual elements may round to exactly 1.0 through
       the cast; then loc_x = W_l is fully out of range, the sampled value is 0,
       and the zero padding semantics apply)
      attention_weights  same dtype as value (N, Q, heads, L, P), non-negative
      grad_output        same dtype as value (N, Q, heads*D), the upstream
                         gradient in the forward output layout, generation domain [0,1)
      out                single tensor, same dtype as value, 1-D three-segment
                         concatenation (see above)
      every dimension is an arbitrary positive integer (including 1, non-powers
      of 2, and non-16-aligned sizes; a single-level single-pixel (H_l, W_l) =
      (1, 1), 1xN / Nx1 thin-strip levels, Q=1, P=1 and L=1 are all legal
      boundaries, and when L*P=1 grad_attention_weights is identically 0). The
      evaluator casts every input to fp32 before passing it in (lossless for both
      the low precision and the int64 indices -- an index value <= 2^24 is exactly
      representable in fp32), so the implementation must restore
      spatial_shapes / level_start_index to integer indices before using them.

    Implementation constraints (violations are scored as failures):
      - The core computation (softmax backprop, the four-corner gradient scatter
        with the partial derivatives of the interpolation fractions, and the
        cross-query grad_value scatter accumulation) must be hand-written as a HIP
        kernel inside the submitted file.
      - Using torch.autograd / autograd.grad / .backward() to backpropagate for the
        gradients is forbidden; the gradients must be hand-written from the
        analytic formulas above.
      - All gradient accumulation is done in float32; the three gradient segments
        are cast back to the value dtype and concatenated in the segment order
        above; forward returns the single tensor out (the evaluator compares a
        single output).
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden list: torchvision (including ready-made deformable attention /
    deformable convolution primitives such as torchvision.ops.ms_deform_attn),
    mmcv, miopen, hipdnn, aiter,
    torch.nn.functional.grid_sample (F.grid_sample),
    torch.nn.functional.interpolate (F.interpolate), torch.matmul /
    torch.bmm / torch.mm / torch.einsum / torch.tensordot,
    torch.softmax / torch.nn.functional.softmax (F.softmax),
    torch.autograd (including autograd.grad), .backward().
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, value, spatial_shapes, level_start_index, sampling_locations, attention_weights, grad_output):
        # <<<IMPROVE:forward_stmt_1>>>
        # Pass spatial_shapes unchanged; the HIP kernel restores integer indices from its actual dtype.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Pass level_start_index unchanged for dtype-aware device loading in the HIP kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        n, n_keys, num_heads, d = value.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        n_levels = spatial_shapes.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_queries = sampling_locations.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_points = sampling_locations.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert sampling_locations.dim() == 6 \
            and sampling_locations.shape[2] == num_heads \
            and sampling_locations.shape[3] == n_levels \
            and sampling_locations.shape[5] == 2, \
            "sampling_locations must be (N, Q, heads, L, P, 2)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert attention_weights.shape == (n, n_queries, num_heads, n_levels, n_points), \
            "attention_weights must be (N, Q, heads, L, P)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Valid prefix-sum spatial metadata is guaranteed by the input contract.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert grad_output.shape == (n, n_queries, num_heads * d), \
            "grad_output must be (N, Q, heads*D)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Compute the analytic gradients in the HIP extension.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Sampling derivatives use float32 accumulation.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Softmax derivatives are computed directly in the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        out = _pyramidkernel_get_extension().deform_attention_backward(
            value, spatial_shapes, level_start_index, sampling_locations,
            attention_weights, grad_output)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # The extension returns all three packed gradient segments.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return out
        # <<<END_IMPROVE>>>
