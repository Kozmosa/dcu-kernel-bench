import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _moe_e2m1(x):
    v = x & 7
    y = tl.where(v < 4, v.to(tl.float32) * 0.5,
                 tl.where(v == 4, 2.0, tl.where(v == 5, 3.0, tl.where(v == 6, 4.0, 6.0))))
    return tl.where((x & 8) != 0, -y, y)


@triton.jit
def _moe_packed_dot(A, AS, B, BS, W, IDS, C,
                    KH: tl.constexpr, N: tl.constexpr, TOP: tl.constexpr,
                    a0: tl.constexpr, a1: tl.constexpr,
                    as0: tl.constexpr, as1: tl.constexpr,
                    b0: tl.constexpr, b1: tl.constexpr, b2: tl.constexpr,
                    bs0: tl.constexpr, bs1: tl.constexpr, bs2: tl.constexpr,
                    w0: tl.constexpr, w1: tl.constexpr,
                    i0: tl.constexpr, i1: tl.constexpr):
    slot = tl.program_id(0)
    m = slot // TOP
    j = slot % TOP
    expert = tl.load(IDS + m * i0 + j * i1)
    weight = tl.load(W + m * w0 + j * w1).to(tl.float32)
    n = tl.program_id(1) * 8 + tl.arange(0, 8)
    r = tl.arange(0, 128)
    even = tl.full((8, 128), 0, tl.float32)
    odd = tl.full((8, 128), 0, tl.float32)
    for start in range(tl.cdiv(KH, 128)):
        k = start * 128 + r
        valid = (n[:, None] < N) & (k[None, :] < KH)
        ac = tl.load(A + m * a0 + k * a1, k < KH, other=0).to(tl.int32)
        bc = tl.load(B + expert * b0 + n[:, None] * b1 + k[None, :] * b2,
                     valid, other=0).to(tl.int32)
        asc = tl.load(AS + m * as0 + (k // 16) * as1, k < KH, other=127).to(tl.float32)
        bsc = tl.load(BS + expert * bs0 + n[:, None] * bs1 + (k[None, :] // 16) * bs2,
                      valid, other=127).to(tl.float32)
        sa = tl.exp2(asc - 127.0)
        sb = tl.exp2(bsc - 127.0)
        al = _moe_e2m1(ac & 15) * sa
        ah = _moe_e2m1(ac >> 4) * sa
        bl = _moe_e2m1(bc & 15) * sb
        bh = _moe_e2m1(bc >> 4) * sb
        even += tl.where(valid, al[None, :] * bl, 0.0)
        odd += tl.where(valid, ah[None, :] * bh, 0.0)
    result = (tl.sum(even, axis=1) + tl.sum(odd, axis=1)) * weight
    tl.store(C + slot * N + n, result, n < N)
# <<<END_IMPROVE>>>

_E2M1_TABLE = torch.tensor(
    [0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0,
     -0.0, -0.5, -1.0, -1.5, -2.0, -3.0, -4.0, -6.0],
    dtype=torch.float32,
)

def _dequant_mxfp4(codes, scales):
    """mxfp4 dequantization: (..., K//2) uint8 code words plus (..., K//32) uint8
    e8m0 block scales -> (..., K) float32. In every byte the low 4 bits are the
    even-index element and the high 4 bits the odd-index element;
    x[..., k] = e2m1(nibble) * 2^(scales[..., k // 32] - 127)."""
    lo = codes & 0xF
    hi = codes >> 4
    nib = torch.stack((lo, hi), dim=-1).flatten(-2)      # (..., K)
    x = _E2M1_TABLE.to(codes.device)[nib.long()]
    scale = torch.exp2(scales.to(torch.float32) - 127.0)
    return x * scale.repeat_interleave(32, dim=-1)

class ModelNew(nn.Module):
    """MoE (Mixture of Experts) grouped GEMM: mxfp4 quantized activations x
    mxfp4 quantized expert weights.

    Routing is already done (topk_ids gives the experts selected for each
    token); this operator runs one GEMM per (token, selected expert) slot and
    multiplies by the routing weight (mul_routed_weight is always True):
      c[m, j, n] = topk_weights[m, j] * sum_k adeq[m, k] * bdeq[topk_ids[m, j], n, k]
    The sum runs along the K dimension, intermediate accumulation is float32 and
    the result is cast to bfloat16 for output.

    mxfp4 dequantization definition (the same for activation a and weight b):
      - every byte of the last dimension of the code word tensor holds 2 e2m1
        codes: the low 4 bits are the even-index element and the high 4 bits the
        odd-index element, i.e. the low/high nibble of code[..., i] correspond
        to elements 2i / 2i+1.
      - e2m1 nibble (4 bit) decoding: bit3 is the sign, the low 3 bits index the
        table {0: 0.0, 1: 0.5, 2: 1.0, 3: 1.5, 4: 2.0, 5: 3.0, 6: 4.0, 7: 6.0};
        a set sign bit negates the value (-0.0 takes part in the multiply-add as
        0).
      - e8m0 block scale: every 32 elements of the last dimension share 1 uint8
        scale byte s = scales[..., k // 32], decoded as 2^(s - 127).
      - dequantization:
        x[..., k] = e2m1(nibble(..., k)) * 2^(scales[..., k // 32] - 127).

    Input/output specification:
      a_q          (M, K//2)     uint8   activation code words (K is the logical
                                         feature dimension)
      a_scales     (M, K//32)    uint8   activation e8m0 block scales
      b_q          (E, N, K//2)  uint8   expert weight code words (E experts)
      b_scales     (E, N, K//32) uint8   expert weight e8m0 block scales
      topk_weights (M, top_k)    float16/bfloat16/float32  routing weights (>0)
      topk_ids     (M, top_k)    int64   selected expert ids, values in [0, E)
      out          (M, top_k, N) bfloat16
      Constraints: M >= 1, E >= 1, N >= 1, K % 32 == 0, 1 <= top_k <= E.
      Boundary behaviour: one expert may be selected by several tokens, and one
      token may select the same expert in several of its slots; every (m, j)
      slot is computed independently, with no reduction or weighted merge across
      experts and no dispatch-merge semantics (that belongs to a downstream
      operator).

    Implementation constraints (violations are scored as failures):
      - Core computation (nibble unpacking, e2m1/e8m0 decoding, the GEMM grouped
        by topk_ids, the routing weight multiply) must be done inside the
        submitted file; calling torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / F.linear / functional.linear /
        torch._scaled_mm is forbidden, as is using the built-in torch
        float4/mxfp4 representations and ready-made quantization conversion APIs
        (torch.float4_e2m1fn_x2, torch.quantize_per_tensor, etc.).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast to
        bfloat16.
      - The evaluator casts all inputs to fp32 before calling forward (uint8
        code words and scale bytes (0..255), int64 expert ids (small integers)
        are all exactly representable in fp32), so they must be restored
        losslessly at the entry point (.to(torch.uint8) / .to(torch.long)).

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: MoE grouped GEMM of mxfp4 activations x mxfp4 weights plus the
    routing weight multiply; the token-expert alignment scheduling metadata
    (sorted_token_ids / expert_ids / num_tokens_post_padded) is an
    implementation detail and not part of the input contract.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        global _moe_packed_dot
        if not getattr(_moe_packed_dot, '_two_warp_proxy', False):
            class _TwoWarpLaunchProxy:
                _two_warp_proxy = True

                def __init__(self, kernel):
                    self.kernel = kernel

                def __getitem__(self, grid):
                    launch = self.kernel[grid]

                    def run(*args, **kwargs):
                        kwargs['num_warps'] = 2
                        return launch(*args, **kwargs)

                    return run

            _moe_packed_dot = _TwoWarpLaunchProxy(_moe_packed_dot)
        # <<<END_IMPROVE>>>

    def forward(self, a_q, a_scales, b_q, b_scales, topk_weights, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        a_q = a_q.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        a_scales = a_scales.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        b_q = b_q.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        b_scales = b_scales.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        topk_weights = topk_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        M, Kh = a_q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        K = Kh * 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        E, N, _ = b_q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        c = torch.empty((M, top_k, N), dtype=torch.bfloat16, device=a_q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        _moe_packed_dot[(M * top_k, triton.cdiv(N, 8))](
                    a_q, a_scales, b_q, b_scales, topk_weights, topk_ids, c,
                    Kh, N, top_k,
                    *a_q.stride(), *a_scales.stride(),
                    *b_q.stride(), *b_scales.stride(),
                    *topk_weights.stride(), *topk_ids.stride(),
                    num_warps=4, enable_fp_fusion=False,
                )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return c
        # <<<END_IMPROVE>>>
