import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

def _bilinear_zero_pad(x, y_coord, x_coord):
    """Bilinear sampling (an integer coordinate is the pixel centre);
    contributions outside the boundary are 0.

    x: (n, c, h, w); y_coord / x_coord: (n, oh, ow) floating-point sampling
    coordinates (in the H/W coordinate system).
    Returns (n, c, oh, ow). Differentiable with respect to y_coord / x_coord:
    the coordinate gradient flows back only through the interpolation fractions
    (the frac terms) while the floor/index path is treated as a constant -- i.e.
    the subgradient of the standard zero-padding bilinear Theano/DCNv2
    convention.
    """
    n, c, h, w = x.shape
    oh, ow = y_coord.shape[1], y_coord.shape[2]
    y0 = torch.floor(y_coord)
    x0 = torch.floor(x_coord)
    y1 = y0 + 1
    x1 = x0 + 1
    ty = (y_coord - y0).unsqueeze(1)   # (n, 1, oh, ow)
    tx = (x_coord - x0).unsqueeze(1)

    def gather(yc, xc):
        valid = ((yc >= 0) & (yc <= h - 1) & (xc >= 0) & (xc <= w - 1)).unsqueeze(1)
        yi = yc.clamp(0, h - 1).long()
        xi = xc.clamp(0, w - 1).long()
        # The index tensors carry a batch dimension, so plain advanced indexing
        # would move the index dimensions to the front and produce 5-D;
        # flattening plus gather keeps (n, c, oh, ow) and stays differentiable
        # with respect to x
        idx = (yi * w + xi).reshape(n, 1, oh * ow).expand(n, c, oh * ow)
        got = x.reshape(n, c, h * w).gather(2, idx).reshape(n, c, oh, ow)
        return got * valid.to(x.dtype)

    return ((1 - ty) * (1 - tx) * gather(y0, x0)
            + (1 - ty) * tx * gather(y0, x1)
            + ty * (1 - tx) * gather(y1, x0)
            + ty * tx * gather(y1, x1))

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5004_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor deform_backward_cuda(
    torch::Tensor dy, torch::Tensor weight, torch::Tensor x,
    torch::Tensor offset, torch::Tensor mask, std::string variant,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_backward", &deform_backward_cuda);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <cmath>

__device__ __forceinline__ void interp4(
    const float* x, int64_t n, int64_t C, int64_t c, int64_t H, int64_t W,
    float yf, float xf, float* val, float* gy, float* gx) {
    int iy = (int)floorf(yf);
    int ix = (int)floorf(xf);
    float ty = yf - (float)iy;
    float tx = xf - (float)ix;
    float a = 0.0f, b = 0.0f, c0 = 0.0f, d = 0.0f;
    if (iy >= 0 && iy < H && ix >= 0 && ix < W)
        a = x[((n * C + c) * H + iy) * W + ix];
    if (iy >= 0 && iy < H && ix + 1 >= 0 && ix + 1 < W)
        b = x[((n * C + c) * H + iy) * W + ix + 1];
    if (iy + 1 >= 0 && iy + 1 < H && ix >= 0 && ix < W)
        c0 = x[((n * C + c) * H + iy + 1) * W + ix];
    if (iy + 1 >= 0 && iy + 1 < H && ix + 1 >= 0 && ix + 1 < W)
        d = x[((n * C + c) * H + iy + 1) * W + ix + 1];
    *val = (1.0f - ty) * ((1.0f - tx) * a + tx * b) +
           ty * ((1.0f - tx) * c0 + tx * d);
    *gy = (1.0f - tx) * (c0 - a) + tx * (d - b);
    *gx = (1.0f - ty) * (b - a) + ty * (d - c0);
}

__global__ void dgrad_kernel(
    const float* dy, const float* weight, const float* x,
    const float* offset, const float* mask, float* dx,
    float* doff, float* dmask, int N, int OC, int C, int H, int W,
    int OH, int OW, int R, int S, int sh, int sw, int ph, int pw,
    int dh, int dw) {
    int64_t q = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    int64_t total = (int64_t)N * OH * OW * R * S;
    if (q >= total) return;

    int64_t spatial = q % ((int64_t)OH * OW);
    q /= (int64_t)OH * OW;
    int m = q % (R * S);
    int n = q / (R * S);
    int i = (int)(spatial / OW);
    int j = (int)(spatial % OW);
    int pm = m / S;
    int pn = m % S;

    int64_t off_base = (int64_t)n * (2 * R * S) * OH * OW;
    int64_t mask_base = (int64_t)n * (R * S) * OH * OW;
    float yf = (float)(i * sh - ph + pm * dh) +
        offset[off_base + (int64_t)(2 * m) * OH * OW + spatial];
    float xf = (float)(j * sw - pw + pn * dw) +
        offset[off_base + (int64_t)(2 * m + 1) * OH * OW + spatial];
    float mm = mask[mask_base + (int64_t)m * OH * OW + spatial];

    int iy = (int)floorf(yf);
    int ix = (int)floorf(xf);
    float ty = yf - (float)iy;
    float tx = xf - (float)ix;
    float w00 = (1.0f - ty) * (1.0f - tx);
    float w01 = (1.0f - ty) * tx;
    float w10 = ty * (1.0f - tx);
    float w11 = ty * tx;
    bool v00 = (iy >= 0 && iy < H && ix >= 0 && ix < W);
    bool v01 = (iy >= 0 && iy < H && ix + 1 >= 0 && ix + 1 < W);
    bool v10 = (iy + 1 >= 0 && iy + 1 < H && ix >= 0 && ix < W);
    bool v11 = (iy + 1 >= 0 && iy + 1 < H && ix + 1 >= 0 && ix + 1 < W);

    float dm = 0.0f;
    float gy_out = 0.0f;
    float gx_out = 0.0f;
    int64_t kernel_index = (int64_t)pm * S + pn;
    int64_t dy_base = ((int64_t)n * OC) * OH * OW + spatial;

    for (int ci = 0; ci < C; ++ci) {
        float g = 0.0f;
        for (int ko = 0; ko < OC; ++ko) {
            float go = dy[dy_base + (int64_t)ko * OH * OW];
            float ww = weight[((int64_t)ko * C + ci) * R * S + kernel_index];
            g += go * ww;
        }

        int64_t xbase = ((int64_t)n * C + ci) * H * W;
        float a = v00 ? x[xbase + (int64_t)iy * W + ix] : 0.0f;
        float b = v01 ? x[xbase + (int64_t)iy * W + ix + 1] : 0.0f;
        float c0 = v10 ? x[xbase + (int64_t)(iy + 1) * W + ix] : 0.0f;
        float d = v11 ? x[xbase + (int64_t)(iy + 1) * W + ix + 1] : 0.0f;
        float v = w00 * a + w01 * b + w10 * c0 + w11 * d;
        float gy = (1.0f - tx) * (c0 - a) + tx * (d - b);
        float gx = (1.0f - ty) * (b - a) + ty * (d - c0);

        dm += g * v;
        gy_out += g * mm * gy;
        gx_out += g * mm * gx;
        float scale = g * mm;
        if (v00)
            atomicAdd(&dx[xbase + (int64_t)iy * W + ix], scale * w00);
        if (v01)
            atomicAdd(&dx[xbase + (int64_t)iy * W + ix + 1], scale * w01);
        if (v10)
            atomicAdd(&dx[xbase + (int64_t)(iy + 1) * W + ix], scale * w10);
        if (v11)
            atomicAdd(&dx[xbase + (int64_t)(iy + 1) * W + ix + 1], scale * w11);
    }

    dmask[mask_base + (int64_t)m * OH * OW + spatial] = dm;
    doff[off_base + (int64_t)(2 * m) * OH * OW + spatial] = gy_out;
    doff[off_base + (int64_t)(2 * m + 1) * OH * OW + spatial] = gx_out;
}

__global__ void wrw_kernel(
    const float* dy, const float* weight, const float* x,
    const float* offset, const float* mask, float* out,
    int N, int OC, int C, int H, int W, int OH, int OW,
    int R, int S, int sh, int sw, int ph, int pw, int dh, int dw) {
    int64_t z = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    int64_t total = (int64_t)OC * C * R * S;
    if (z >= total) return;
    int pn = z % S;
    z /= S;
    int pm = z % R;
    z /= R;
    int ci = z % C;
    int ko = z / C;
    float acc = 0.0f;
    for (int n = 0; n < N; ++n) {
        for (int i = 0; i < OH; ++i) {
            for (int j = 0; j < OW; ++j) {
                int m = pm * S + pn;
                int64_t spatial = (int64_t)i * OW + j;
                float yf = (float)(i * sh - ph + pm * dh) +
                    offset[((int64_t)n * 2 * R * S + 2 * m) * OH * OW + spatial];
                float xf = (float)(j * sw - pw + pn * dw) +
                    offset[((int64_t)n * 2 * R * S + 2 * m + 1) * OH * OW + spatial];
                float v, gy, gx;
                interp4(x, n, C, ci, H, W, yf, xf, &v, &gy, &gx);
                float g = dy[((int64_t)n * OC + ko) * OH * OW + spatial];
                float mm = mask[((int64_t)n * R * S + m) * OH * OW + spatial];
                acc += g * mm * v;
            }
        }
    }
    out[((int64_t)ko * C + ci) * R * S + pm * S + pn] = acc;
}

torch::Tensor deform_backward_cuda(
    torch::Tensor dy, torch::Tensor weight, torch::Tensor x,
    torch::Tensor offset, torch::Tensor mask, std::string variant,
    int64_t sh, int64_t sw, int64_t ph, int64_t pw,
    int64_t dh, int64_t dw) {
    TORCH_CHECK(dy.is_cuda() && weight.is_cuda() && x.is_cuda() && offset.is_cuda() && mask.is_cuda());
    TORCH_CHECK(dy.scalar_type() == torch::kFloat32 && weight.scalar_type() == torch::kFloat32 && x.scalar_type() == torch::kFloat32 && offset.scalar_type() == torch::kFloat32 && mask.scalar_type() == torch::kFloat32);
    TORCH_CHECK(dy.is_contiguous() && weight.is_contiguous() && x.is_contiguous() && offset.is_contiguous() && mask.is_contiguous());
    int N = x.size(0), C = x.size(1), H = x.size(2), W = x.size(3);
    int OC = weight.size(0), R = weight.size(2), S = weight.size(3);
    int OH = offset.size(2), OW = offset.size(3);
    auto stream = at::cuda::getCurrentCUDAStream();
    int threads = (variant == "wrw") ? 256 : 128;
    if (variant == "wrw") {
        auto out = torch::zeros_like(weight);
        int blocks = ((int64_t)OC * C * R * S + threads - 1) / threads;
        hipLaunchKernelGGL(wrw_kernel, dim3(blocks), dim3(threads), 0, stream.stream(),
            dy.data_ptr<float>(), weight.data_ptr<float>(), x.data_ptr<float>(),
            offset.data_ptr<float>(), mask.data_ptr<float>(), out.data_ptr<float>(),
            N, OC, C, H, W, OH, OW, R, S, sh, sw, ph, pw, dh, dw);
        return out;
    }

    int64_t nx = x.numel();
    int64_t no = offset.numel();
    int64_t nm = mask.numel();
    auto out = torch::empty({nx + no + nm}, x.options());
    float* base = out.data_ptr<float>();
    TORCH_CHECK(hipMemsetAsync(base, 0, (size_t)nx * sizeof(float), stream.stream()) == hipSuccess, "HIP memset failed");
    float* dx = base;
    float* doff = base + nx;
    float* dmask = base + nx + no;
    int64_t total = (int64_t)N * OH * OW * R * S;
    int blocks = (total + threads - 1) / threads;
    hipLaunchKernelGGL(dgrad_kernel, dim3(blocks), dim3(threads), 0, stream.stream(),
        dy.data_ptr<float>(), weight.data_ptr<float>(), x.data_ptr<float>(),
        offset.data_ptr<float>(), mask.data_ptr<float>(), dx, doff, dmask,
        N, OC, C, H, W, OH, OW, R, S, sh, sw, ph, pw, dh, dw);
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Deformable 2D convolution backward (DCNv2, with mask modulation):
    gradient with respect to the input (dgrad) and gradient with respect to the
    weights (wrw).

    Semantics (NCHW, offset group = 1, no bias, strictly consistent with the
    standard DCNv2 forward):
        forward y = deform_conv2d(x, offset, weight, mask, stride=(sh,sw),
                               padding=(ph,pw), dilation=(dh,dw))
        output size out_h = floor((H + 2*ph - dh*(R-1) - 1) / sh) + 1 (likewise
        for out_w)
        the m-th kernel sampling point in row-major order m = pm*S + pn
        (pm = m // S, pn = m % S), at output position (i, j):
            sampling coordinate  Y = i*sh - ph + dh*pm + offset[b, 2*m,   i, j]
                                 X = j*sw - pw + dw_*pn + offset[b, 2*m+1, i, j]
            sampled value  V[b, :, i, j, m] = bilinear(x, Y, X): an integer
                coordinate is the pixel centre, interpolated bilinearly; the part
                of a sampling point that falls outside [0,H-1]x[0,W-1]
                contributes 0.
            y[b, ko, i, j] = sum_m mask[b, m, i, j] *
                                 sum_ci weight[ko, ci, pm, pn] * V[b, ci, i, j, m]
        offset channels correspond one-to-one with the kernel sampling points in
        row-major order: channel 2*m is the H-direction offset and 2*m+1 the
        W-direction offset (the only widespread DCNv2 convention; offset
        group = 1 for this task).
    Given the upstream gradient dy = dL/dy (shape (N, out_c, out_h, out_w)):
        dgrad: dx = dL/dx (N,C,H,W), doffset = dL/doffset (N,2*R*S,out_h,out_w),
               dmask = dL/dmask (N,R*S,out_h,out_w)
        wrw:   dw = dL/dw (out_c,C,R,S)
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns the three gradients packed into a single 1-D tensor by
                 the segmentation protocol;
        "wrw":   returns dw; the values of weight do not take part in the
                 output here (shape convention only).
    forward(dy, weight, x, offset, mask) has a fixed five-input signature; the
    tensors mean:
        dy     (N, out_c, out_h, out_w)     upstream gradient, consumed by both
                                            directions
        weight (out_c, C, R, S)             convolution kernel (out_c output
                                            channels / C input channels)
        x      (N, C, H, W)                 forward input
        offset (N, 2*R*S, out_h, out_w)     sampling offsets
        mask   (N, R*S, out_h, out_w)       modulation mask
    forward returns the single tensor out (float32) -- dgrad is a 1-D
    concatenated packing (segmentation protocol):
        out = cat([dx.reshape(-1), doffset.reshape(-1), dmask.reshape(-1)])
        length = N*C*H*W + N*2*R*S*out_h*out_w + N*R*S*out_h*out_w, with the
        segment order fixed as dx | doffset | dmask, each segment being the
        C-order flattening of the corresponding 4-D tensor; the segment order
        must not be swapped;
        wrw -> (out_c, C, R, S), inherently single-output with no packing.

    Input/output specification:
        dy / weight / x / offset / mask are all float32, contiguous, NCHW
        layout; every dimension >= 1; R/S may be 1 (1x1 kernel); H/W may be 1,
        odd, non-power-of-two, not 16-aligned; stride/dilation >= 1, padding
        >= 0, padding follows the forward four-sided symmetric (ph, pw)
        semantics; consistency constraint
            H + 2*ph >= dh*(R-1) + 1, W + 2*pw >= dw_*(S-1) + 1,
        and the spatial sizes of dy/offset/mask must equal out_h/out_w from the
        forward formula, offset channels = 2*R*S, mask channels = R*S.
        Input values are ordinary randn magnitude (no inf/NaN). The evaluator
        casts all inputs to fp32 before the call.

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a HIP kernel inside the
          submitted file: the backward bilinear-sampling scatter of dgrad (the
          analytic partial derivatives with respect to Y/X chained back through
          the kernel weights and the mask into dx/doffset/dmask, with
          out-of-boundary contributions set to 0) or the sampled-value
          correlation accumulation of wrw (summing the cross-correlation of the
          x sampling windows with dy); falling back to torch autograd /
          convolution primitives / grid_sample for the core computation is
          forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares a single
          output); the three dgrad segments must be packed by the segmentation
          protocol above and the segment order must not be swapped.
        - Numeric contract: float32 inputs are accumulated directly in float32,
          with no downcast to half precision; the three dgrad gradient segments
          and the wrw output are all float32.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torchvision / torch.nn.functional.conv2d / F.conv2d /
    torch.conv2d / torch.nn.Conv2d / torch.nn.functional.conv_transpose2d /
    F.conv_transpose2d / torch.nn.ConvTranspose2d /
    torch.nn.grad.conv2d_input / torch.nn.grad.conv2d_weight /
    aten.convolution_backward / deform_conv2d / deform_conv2d_backward /
    grid_sample / F.grid_sample / torch.nn.functional.grid_sample /
    torch.autograd / .backward( / unfold / F.fold /
    torch.nn.functional.fold / im2col / col2im / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
    regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h>
    is not available on this machine).
    """
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1, pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wrw"), "variant must be either dgrad or wrw"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)
        # <<<END_IMPROVE>>>

    def forward(self, dy, weight, x, offset, mask):
        # <<<IMPROVE:forward_stmt_1>>>
        ext = _pyramidkernel_get_extension()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        og = offset.detach().requires_grad_(True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        mg = mask.detach().requires_grad_(True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        wg = weight.detach().requires_grad_(True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        result = ext.deform_backward(dy, weight, x, offset, mask, self.variant, self.stride_h, self.stride_w, self.pad_h, self.pad_w, self.dil_h, self.dil_w)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        if self.variant == "dgrad":
                    return result
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        result = ext.deform_backward(dy, weight, x, offset, mask, "wrw", self.stride_h, self.stride_w, self.pad_h, self.pad_w, self.dil_h, self.dil_w)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return result
        # <<<END_IMPROVE>>>

    def _deform_conv2d_forward(self, x, offset, weight, mask):
        """Handwritten DCNv2 forward (a composition of standard differentiable
        torch operators), used for the autograd backward pass."""
        n, c, h, w = x.shape
        k, _, r, s = weight.shape
        sh, sw = self.stride_h, self.stride_w
        ph, pw = self.pad_h, self.pad_w
        dh, dwl = self.dil_h, self.dil_w
        oh, ow = offset.shape[2], offset.shape[3]
        out = torch.zeros(n, k, oh, ow, dtype=x.dtype, device=x.device)
        for m in range(r * s):
            pm, pn = m // s, m % s
            base_y = torch.arange(oh, dtype=x.dtype, device=x.device) * sh - ph + dh * pm
            base_x = torch.arange(ow, dtype=x.dtype, device=x.device) * sw - pw + dwl * pn
            yo = base_y.view(1, oh, 1) + offset[:, 2 * m]      # (n, oh, ow)
            xo = base_x.view(1, 1, ow) + offset[:, 2 * m + 1]  # (n, oh, ow)
            val = _bilinear_zero_pad(x, yo, xo)                # (n, c, oh, ow)
            wc = weight[:, :, pm, pn]                          # (k, c)
            contrib = torch.einsum("oc,ncij->noij", wc, val)
            out = out + mask[:, m].unsqueeze(1) * contrib
        return out
