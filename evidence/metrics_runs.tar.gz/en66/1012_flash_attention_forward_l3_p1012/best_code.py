import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _varlen_forward(Q, K, V, O, CQ, CK, C,
                    S: tl.constexpr, G: tl.constexpr, D: tl.constexpr,
                    Q0: tl.constexpr, Q1: tl.constexpr, Q2: tl.constexpr,
                    K0: tl.constexpr, K1: tl.constexpr, K2: tl.constexpr,
                    V0: tl.constexpr, V1: tl.constexpr, V2: tl.constexpr,
                    O0: tl.constexpr, O1: tl.constexpr, O2: tl.constexpr,
                    BD: tl.constexpr, BM: tl.constexpr, BN: tl.constexpr):
    tile = tl.program_id(0)
    h = tl.program_id(1)
    b = tl.program_id(2)
    sq = tl.load(CQ + b)
    eq = tl.load(CQ + b + 1)
    sk = tl.load(CK + b)
    ek = tl.load(CK + b + 1)
    lq = eq - sq
    lk = ek - sk
    if tile * BM < lq:
        causal = tl.load(C) != 0
        rows = tile * BM + tl.arange(0, BM)
        dims = tl.arange(0, BD)
        cols = tl.arange(0, BN)
        kh = h // G
        q = tl.load(Q + (sq + rows[:, None]) * Q0 + h * Q1 + dims[None, :] * Q2,
                    (rows[:, None] < lq) & (dims[None, :] < D), 0)
        m = tl.full((BM,), float('-inf'), tl.float32)
        z = tl.zeros((BM,), tl.float32)
        acc = tl.zeros((BM, BD), tl.float32)
        for start in range(0, lk, BN):
            js = start + cols
            k = tl.load(K + (sk + js[None, :]) * K0 + kh * K1 + dims[:, None] * K2,
                        (js[None, :] < lk) & (dims[:, None] < D), 0)
            scores = tl.dot(q, k, out_dtype=tl.float32) * S
            visible = (js[None, :] < lk) & ((~causal) | (js[None, :] <= rows[:, None] + lk - lq))
            scores = tl.where(visible, scores, float('-inf'))
            new_m = tl.maximum(m, tl.max(scores, 1))
            safe_m = tl.where(new_m == float('-inf'), 0.0, new_m)
            alpha = tl.exp(m - safe_m)
            p = tl.exp(scores - safe_m[:, None])
            v = tl.load(V + (sk + js[:, None]) * V0 + kh * V1 + dims[None, :] * V2,
                        (js[:, None] < lk) & (dims[None, :] < D), 0).to(tl.float32)
            acc = acc * alpha[:, None] + tl.dot(p, v, input_precision='ieee')
            z = z * alpha + tl.sum(p, 1)
            m = new_m
        result = acc / tl.where(z > 0, z, 1.0)[:, None]
        tl.store(O + (sq + rows[:, None]) * O0 + h * O1 + dims[None, :] * O2,
                 result, (rows[:, None] < lq) & (dims[None, :] < D))
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Variable-length (varlen) FlashAttention v2 forward pass: dense Q/K/V is
    segmented by cu_seqlens and each segment computes scaled dot-product attention
    independently, supporting MHA/GQA and a causal
    mask.

    Mathematical definition: for segment b of the batch (let
    L_q = cu_seqlens_q[b+1]-cu_seqlens_q[b],
    L_k = cu_seqlens_k[b+1]-cu_seqlens_k[b]; the task constrains 0 < L_q <= L_k, and
    g = num_q_heads // num_kv_heads):
      scores[h,i,j] = sm_scale * <q[start_q+i,h,:], k[start_k+j,h//g,:]>
      with causal=1 a bottom-right-aligned causal mask is applied: positions with
      j > i + (L_k - L_q) are set to -inf (i.e. query position i only attends to key
      positions j <= i + L_k - L_q); with causal=0 no mask is applied.
      p[h,i,:] = softmax_j(scores[h,i,:])
      out[start_q+i,h,:] = sum_j p[h,i,j] * v[start_k+j,h//g,:]
    The softmax uses a numerically stable formulation; intermediates are accumulated
    in float32 and the output is cast back to the input dtype.
    Boundary behaviour: the task guarantees L_q >= 1 for every segment, so the
    softmax denominator is always positive and no row is fully masked; segments
    other than the last do not affect each other.

    Input/output specification:
      q            [total_q, num_q_heads, head_dim]  float16/bfloat16
      k, v         [total_k, num_kv_heads, head_dim] same dtype as q
      cu_seqlens_q [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_q
      cu_seqlens_k [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_k
      causal       0-dim int32 tensor, 1 = causal mask, 0 = no mask
      out          [total_q, num_q_heads, head_dim], same dtype as q
    Global constraints: num_q_heads is an integer multiple of num_kv_heads (GQA;
    equality means MHA); 1 <= head_dim <= 256; for every sequence
    0 < L_q <= L_k.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: varlen forward, non-quantized inputs, no bias/ALiBi, no dropout, no
    LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, cu_seqlens_q, cu_seqlens_k, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        cu_seqlens_q = cu_seqlens_q.to(device=q.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        cu_seqlens_k = cu_seqlens_k.to(device=q.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        causal = causal.to(device=q.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        nheads_q = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        nheads_k = k.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        group = nheads_q // nheads_k
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert nheads_q == nheads_k * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        num_seqs = int(cu_seqlens_q.numel()) - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _varlen_forward[(triton.cdiv(q.shape[0], 16), nheads_q, num_seqs)](
            q, k, v, out, cu_seqlens_q, cu_seqlens_k, causal,
            self.sm_scale, group, q.shape[2],
            *q.stride(), *k.stride(), *v.stride(), *out.stride(),
            BD=max(16, triton.next_power_of_2(q.shape[2])), BM=16, BN=32,
            num_warps=4, num_stages=1,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
