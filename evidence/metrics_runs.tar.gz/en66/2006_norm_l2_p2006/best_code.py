import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _residual_layer_norm(X, R, W, Bias, Out, N: tl.constexpr,
                         EPS: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    col = tl.arange(0, BLOCK)
    if N <= BLOCK:
        mask = col < N
        a = tl.load(X + row * N + col, mask, other=0).to(tl.float32)
        r = tl.load(R + row * N + col, mask, other=0).to(tl.float32)
        s = (a + r).to(Out.dtype.element_ty).to(tl.float32)
        tl.store(Out + row * (2 * N) + N + col, s, mask)
        mean = tl.sum(tl.where(mask, s, 0.0), 0) / N
        d = tl.where(mask, s - mean, 0.0)
        var = tl.sum(d * d, 0) / N
        inv = tl.rsqrt(var + EPS)
        w = tl.load(W + col, mask, other=0).to(tl.float32)
        b = tl.load(Bias + col, mask, other=0).to(tl.float32)
        y = ((s - mean) * inv) * w + b
        tl.store(Out + row * (2 * N) + col, y, mask)
    else:
        sums = tl.full((BLOCK,), 0, tl.float32)
        for start in range(0, N, BLOCK):
            j = start + col
            mask = j < N
            a = tl.load(X + row * N + j, mask, other=0).to(tl.float32)
            r = tl.load(R + row * N + j, mask, other=0).to(tl.float32)
            s = (a + r).to(Out.dtype.element_ty).to(tl.float32)
            tl.store(Out + row * (2 * N) + N + j, s, mask)
            sums += tl.where(mask, s, 0.0)
        mean = tl.sum(sums, 0) / N
        squares = tl.full((BLOCK,), 0, tl.float32)
        for start in range(0, N, BLOCK):
            j = start + col
            mask = j < N
            a = tl.load(X + row * N + j, mask, other=0).to(tl.float32)
            r = tl.load(R + row * N + j, mask, other=0).to(tl.float32)
            s = (a + r).to(Out.dtype.element_ty).to(tl.float32)
            d = tl.where(mask, s - mean, 0.0)
            squares += d * d
        inv = tl.rsqrt(tl.sum(squares, 0) / N + EPS)
        for start in range(0, N, BLOCK):
            j = start + col
            mask = j < N
            a = tl.load(X + row * N + j, mask, other=0).to(tl.float32)
            r = tl.load(R + row * N + j, mask, other=0).to(tl.float32)
            s = (a + r).to(Out.dtype.element_ty).to(tl.float32)
            w = tl.load(W + j, mask, other=0).to(tl.float32)
            b = tl.load(Bias + j, mask, other=0).to(tl.float32)
            y = ((s - mean) * inv) * w + b
            tl.store(Out + row * (2 * N) + j, y, mask)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Forward pass of residual-fused LayerNorm (fused add LayerNorm).

    The inputs x and residual are added element-wise to form the residual sum s
    (the addition happens in float32, then s is rounded back to the input dtype
    for storage); LayerNorm is then applied to the last dimension of s together
    with an affine transform (everything evaluated in float32):
        mean_i  = (1/N) * sum_j s[i, j]
        var_i   = (1/N) * sum_j (s[i, j] - mean_i)^2      (biased variance)
        rstd_i  = 1 / sqrt(var_i + eps)                   (eps comes from __init__)
        y[i, j] = (s[i, j] - mean_i) * rstd_i * weight[j] + bias[j]
    The statistics are taken over s as rounded back to the input dtype; y is
    finally rounded back to the input dtype as well.
    Boundary behaviour: N is any positive integer (including 1, non-power-of-two,
    and very long rows), columns outside the mask do not participate in the
    statistics; when var = 0, eps keeps rstd finite; the inputs contain no
    inf/NaN.

    The output is a single tensor out (M, 2N) with the same dtype as the inputs:
        out[:, :N] = y           the LayerNorm output
        out[:, N:] = s           residual_out (the residual sum rounded to the input dtype)

    Input/output specification:
        x        (M, N)  float16 / bfloat16 / float32, contiguous, M >= 1, N >= 1
        residual (M, N)  same as x
        weight   (N,)    same as x (per-channel scale)
        bias     (N,)    same as x (per-channel shift)
        (the evaluator casts the inputs to fp32 before calling forward;
         fp16/bf16 -> fp32 is lossless)

    Implementation constraints (violations are scored as failures):
        - The core computation (residual add, mean/var statistics, normalization,
          affine transform) must be completed with a Triton kernel inside the
          submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate intermediates in float32; both y and residual_out are
          rounded back to the input dtype.

    Forbidden list: torch.nn.functional.layer_norm / torch.layer_norm /
    torch.nn.LayerNorm.
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, residual, weight, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        dt = x.dtype
        M, N = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        out = torch.empty((M, 2 * N), device=x.device, dtype=dt)
        block = triton.next_power_of_2(N) if N <= 16384 else 4096
        warps = 4 if block <= 4096 else 8
        _residual_layer_norm[(M,)](
            x, residual, weight, bias, out, N, self.eps, block,
            num_warps=warps, enable_fp_fusion=False,
        )
        return out
        # <<<END_IMPROVE>>>
