import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2014_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor instance_norm_forward(torch::Tensor x, torch::Tensor scale, torch::Tensor bias, double eps);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("instance_norm_forward", &instance_norm_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

__device__ __forceinline__ float plane_sum(float v, float* scratch) {
    const int lane = threadIdx.x % warpSize;
    const int wave = threadIdx.x / warpSize;
    for (int d = warpSize / 2; d; d >>= 1)
        v += __shfl_down(v, d);
    if (lane == 0) scratch[wave] = v;
    __syncthreads();
    if (wave == 0) {
        v = lane < blockDim.x / warpSize ? scratch[lane] : 0.0f;
        for (int d = warpSize / 2; d; d >>= 1)
            v += __shfl_down(v, d);
        if (lane == 0) scratch[0] = v;
    }
    __syncthreads();
    float result = scratch[0];
    __syncthreads();
    return result;
}

template<class T, bool CACHE>
__global__ void instance_plane(const T* __restrict__ x, const T* __restrict__ scale,
                               const T* __restrict__ bias, T* __restrict__ out,
                               int64_t hw, int64_t channels, float eps) {
    __shared__ float scratch[32];
    __shared__ float affine[2];
    int64_t plane = blockIdx.x;
    int64_t base = plane * hw;
    if (threadIdx.x == 0) {
        affine[0] = float(scale[plane % channels]);
        affine[1] = float(bias[plane % channels]);
    }
    if constexpr (CACHE) {
        float values[16];
        float sum = 0.0f;
        #pragma unroll
        for (int k = 0; k < 16; ++k) {
            int64_t i = threadIdx.x + k * 256;
            if (i < hw) {
                values[k] = float(x[base + i]);
                sum += values[k];
            }
        }
        float mean = plane_sum(sum, scratch) / float(hw);
        float sq = 0.0f;
        #pragma unroll
        for (int k = 0; k < 16; ++k) {
            int64_t i = threadIdx.x + k * 256;
            if (i < hw) {
                float d = values[k] - mean;
                sq += d * d;
            }
        }
        float inv = rsqrtf(plane_sum(sq, scratch) / float(hw) + eps);
        float s = affine[0], b = affine[1];
        #pragma unroll
        for (int k = 0; k < 16; ++k) {
            int64_t i = threadIdx.x + k * 256;
            if (i < hw) {
                float normalized = (values[k] - mean) * inv;
                out[base + i] = T(__fadd_rn(normalized * s, b));
            }
        }
    } else {
        float sum = 0.0f;
        for (int64_t i = threadIdx.x; i < hw; i += blockDim.x)
            sum += float(x[base + i]);
        float mean = plane_sum(sum, scratch) / float(hw);
        float sq = 0.0f;
        for (int64_t i = threadIdx.x; i < hw; i += blockDim.x) {
            float d = float(x[base + i]) - mean;
            sq += d * d;
        }
        float inv = rsqrtf(plane_sum(sq, scratch) / float(hw) + eps);
        float s = affine[0], b = affine[1];
        for (int64_t i = threadIdx.x; i < hw; i += blockDim.x) {
            float normalized = (float(x[base + i]) - mean) * inv;
            out[base + i] = T(__fadd_rn(normalized * s, b));
        }
    }
}

torch::Tensor instance_norm_forward(torch::Tensor x, torch::Tensor scale, torch::Tensor bias, double eps) {
    TORCH_CHECK(x.is_cuda() && scale.is_cuda() && bias.is_cuda(), "GPU tensors required");
    TORCH_CHECK(x.dim() == 4 && scale.dim() == 4 && bias.dim() == 4, "NCHW tensors required");
    TORCH_CHECK(x.is_contiguous() && scale.is_contiguous() && bias.is_contiguous(), "contiguous tensors required");
    TORCH_CHECK(scale.scalar_type() == x.scalar_type() && bias.scalar_type() == x.scalar_type(), "dtype mismatch");
    TORCH_CHECK(scale.device() == x.device() && bias.device() == x.device(), "device mismatch");
    TORCH_CHECK(scale.numel() == x.size(1) && bias.numel() == x.size(1), "affine size mismatch");
    c10::cuda::CUDAGuard guard(x.device());
    auto out = torch::empty_like(x);
    int64_t hw = x.size(2) * x.size(3);
    int64_t planes = x.size(0) * x.size(1);
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(), "instance_plane", [&] {
        if (hw <= 4096)
            instance_plane<scalar_t, true><<<planes, 256, 0, stream>>>(x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), hw, x.size(1), float(eps));
        else
            instance_plane<scalar_t, false><<<planes, 256, 0, stream>>>(x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), hw, x.size(1), float(eps));
    });
    TORCH_CHECK(hipGetLastError() == hipSuccess, "InstanceNorm kernel launch failed");
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """InstanceNorm forward pass: per-(N,C) spatial-statistics normalization plus
    per-channel affine (single variant).

    The input x (N, C, H, W) is NCHW contiguous; scale / bias are the (1, C, 1, 1)
    per-channel affine parameters, broadcast along the channel dimension; eps
    defaults to 1e-5. Statistics are taken over the spatial dimensions (H, W) for
    every (n, c) plane (HW = H*W elements per plane), in float32:
        mean_nc    = sum_{h,w} x[n,c,h,w] / HW                  (biased mean)
        var_nc     = sum_{h,w} (x[n,c,h,w] - mean_nc)^2 / HW    (biased variance)
        inv_std_nc = 1 / sqrt(var_nc + eps)
        y[n,c,h,w] = scale[c] * (x[n,c,h,w] - mean_nc) * inv_std_nc + bias[c]
    Instance norm has no train / inference semantic difference: the normalization
    statistics always come from the input itself. The convention is biased (divide
    by HW rather than HW-1), and eps sits inside the rsqrt (its only purpose is the
    division-by-zero guard; it takes part in no unbiased correction).

    Boundary behaviour: when HW == 1 (a single spatial element) var = 0 and
    x - mean = 0, so inv_std = 1/sqrt(eps) and y = bias (eps guarantees no division
    by zero); N/C/H/W are arbitrary (including 1, non-powers-of-two, and unaligned
    sizes); a large HW requires a blocked reduction, and out-of-range elements at
    the row tail must not participate in the statistics.

    Input/output specification:
        x     float32 / float16 / bfloat16 (N, C, H, W), contiguous,
              N/C/H/W >= 1
        scale same dtype as x, (1, C, 1, 1), contiguous
        bias  same dtype as x, (1, C, 1, 1), contiguous
        out   a single tensor, y itself: (N, C, H, W) with the same dtype as x
              (statistics and affine run in float32 intermediates, then cast back
              to the x dtype); no packing
        The inputs are ordinary randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before calling forward (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-(N,C) spatial reduction statistics, rsqrt,
          and the per-channel affine) must be completed with a HIP kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt and affine all run in float32 intermediates; y is
          cast back to the x dtype.
        - forward returns the single tensor `out` (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden list: torch.nn.InstanceNorm1d / torch.nn.InstanceNorm2d /
    torch.nn.InstanceNorm3d / torch.nn.functional.instance_norm /
    F.instance_norm / torch.instance_norm / native_instance_norm /
    torch.nn.GroupNorm / nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm /
    torch.nn.BatchNorm1d / torch.nn.BatchNorm2d / torch.nn.BatchNorm3d /
    torch.nn.SyncBatchNorm / torch.nn.functional.batch_norm /
    F.batch_norm / torch.batch_norm / torch.native_batch_norm /
    miopen / hipdnn.
    (GroupNorm with num_groups=C and BatchNorm via a (1, N*C, H, W) reshape both
    complete this task's core computation in a single step, so they are forbidden
    alongside the instance_norm family.)
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
    regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h>
    is not available on this machine).
    """
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert eps > 0, "eps must be positive"
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().instance_norm_forward(x, scale, bias, self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Mean is computed inside the HIP kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Biased variance is computed inside the HIP kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # Reciprocal standard deviation is computed inside the HIP kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # Scale is converted to float32 in the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # Bias is converted to float32 in the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # Affine normalization is fused with output writeback.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return out
        # <<<END_IMPROVE>>>
