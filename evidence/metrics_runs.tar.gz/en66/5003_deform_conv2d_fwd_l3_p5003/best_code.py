import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

at::Tensor deform_conv2d_forward(
    at::Tensor x, at::Tensor offset, at::Tensor weight, at::Tensor bias,
    at::Tensor mask, int64_t stride_h, int64_t stride_w,
    int64_t pad_h, int64_t pad_w, int64_t dilation_h, int64_t dilation_w,
    bool modulated);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_conv2d_forward", &deform_conv2d_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <cmath>

__device__ __forceinline__ float bilinear_value(
    const float* x, int64_t base, int h, int w,
    float y, float xx) {
    const int iy = (int)floorf(y);
    const int ix = (int)floorf(xx);
    const float wy = y - (float)iy;
    const float wx = xx - (float)ix;
    float v = 0.0f;
    int yy, xxx;
    if (iy >= 0 && iy < h && ix >= 0 && ix < w)
        v += x[base + (int64_t)iy * w + ix] * (1.0f - wy) * (1.0f - wx);
    xxx = ix + 1;
    if (iy >= 0 && iy < h && xxx >= 0 && xxx < w)
        v += x[base + (int64_t)iy * w + xxx] * (1.0f - wy) * wx;
    yy = iy + 1;
    if (yy >= 0 && yy < h && ix >= 0 && ix < w)
        v += x[base + (int64_t)yy * w + ix] * wy * (1.0f - wx);
    if (yy >= 0 && yy < h && xxx >= 0 && xxx < w)
        v += x[base + (int64_t)yy * w + xxx] * wy * wx;
    return v;
}

__global__ void deform_conv_kernel(
    const float* __restrict__ x, const float* __restrict__ offset,
    const float* __restrict__ weight, const float* __restrict__ bias,
    const float* __restrict__ mask, float* __restrict__ out,
    int n, int c, int h, int w, int k, int r, int s,
    int ho, int wo, int sh, int sw, int ph, int pw, int dh, int dw,
    bool modulated) {
    const int64_t linear = (int64_t)blockIdx.x * blockDim.x + threadIdx.x;
    const int pairs = (k + 1) / 2;
    const int64_t total = (int64_t)n * pairs * ho * wo;
    if (linear >= total) return;
    int64_t q = linear;
    const int oj = q % wo; q /= wo;
    const int oi = q % ho; q /= ho;
    const int pair = q % pairs;
    const int nn = (int)(q / pairs);
    const int base_y0 = oi * sh - ph;
    const int base_x0 = oj * sw - pw;
    const int kk0 = 2 * pair;
    const int kk1 = kk0 + 1;
    float acc0 = bias[kk0];
    float acc1 = kk1 < k ? bias[kk1] : 0.0f;
    const int rs = r * s;
    for (int cc = 0; cc < c; ++cc) {
        const int64_t xbase = ((int64_t)nn * c + cc) * h * w;
        for (int i = 0; i < r; ++i) {
            for (int j = 0; j < s; ++j) {
                const int p = i * s + j;
                const int64_t opos = (((int64_t)nn * (2 * rs) + 2 * p) * ho + oi) * wo + oj;
                const float yy = (float)(base_y0 + i * dh) + offset[opos];
                const float xx = (float)(base_x0 + j * dw) + offset[opos + (int64_t)ho * wo];
                float v = bilinear_value(x, xbase, h, w, yy, xx);
                if (modulated) {
                    const int64_t mpos = (((int64_t)nn * rs + p) * ho + oi) * wo + oj;
                    v *= mask[mpos];
                }
                const int64_t wpos = (((int64_t)kk0 * c + cc) * r + i) * s + j;
                acc0 += v * weight[wpos];
                if (kk1 < k) {
                    const int64_t wpos1 = (((int64_t)kk1 * c + cc) * r + i) * s + j;
                    acc1 += v * weight[wpos1];
                }
            }
        }
    }
    out[((int64_t)nn * k + kk0) * ho * wo + (int64_t)oi * wo + oj] = acc0;
    if (kk1 < k)
        out[((int64_t)nn * k + kk1) * ho * wo + (int64_t)oi * wo + oj] = acc1;
}

at::Tensor deform_conv2d_forward(
    at::Tensor x, at::Tensor offset, at::Tensor weight, at::Tensor bias,
    at::Tensor mask, int64_t stride_h, int64_t stride_w,
    int64_t pad_h, int64_t pad_w, int64_t dilation_h, int64_t dilation_w,
    bool modulated) {
    const int n = (int)x.size(0);
    const int c = (int)x.size(1);
    const int h = (int)x.size(2);
    const int w = (int)x.size(3);
    const int k = (int)weight.size(0);
    const int r = (int)weight.size(2);
    const int s = (int)weight.size(3);
    const int ho = (h + 2 * (int)pad_h - (int)dilation_h * (r - 1) - 1) / (int)stride_h + 1;
    const int wo = (w + 2 * (int)pad_w - (int)dilation_w * (s - 1) - 1) / (int)stride_w + 1;
    auto out = torch::empty({n, k, ho, wo}, x.options().dtype(torch::kFloat32));
    const int64_t total = (int64_t)n * ((k + 1) / 2) * ho * wo;
    const int threads = 256;
    const int blocks = (int)((total + threads - 1) / threads);
    hipLaunchKernelGGL(deform_conv_kernel, dim3(blocks), dim3(threads), 0, 0,
        x.data_ptr<float>(), offset.data_ptr<float>(), weight.data_ptr<float>(),
        bias.data_ptr<float>(), mask.data_ptr<float>(), out.data_ptr<float>(),
        n, c, h, w, k, r, s, ho, wo, (int)stride_h, (int)stride_w,
        (int)pad_h, (int)pad_w, (int)dilation_h, (int)dilation_w, modulated);
    TORCH_CHECK(hipGetLastError() == hipSuccess, "deformable convolution HIP launch failed");
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Deformable 2D convolution forward (Deformable Convolution): sampling grid
    plus a handwritten bilinear interpolation.

    Semantics (NCHW, all intermediate computation in float32):
      For each output position (oi, oj) and kernel position p = i*S + j
      (i in [0,R), j in [0,S), row-major), the base sampling coordinate given by
      the regular convolutional receptive field is
          y0 = oi * stride_h + i * dilation_h - padding_h
          x0 = oj * stride_w + j * dilation_w - padding_w
      After adding the per-(output position x kernel position) offsets, the
      input map is sampled at real-valued coordinates with bilinear
      interpolation:
          yc = y0 + offset[n, 2*p,     oi, oj]     # even channel = y offset
          xc = x0 + offset[n, 2*p + 1, oi, oj]     # odd channel = x offset
          v(n, c, p, oi, oj) = bilinear(input map, yc, xc)
      The __init__ parameter variant selects one of the two paths:
          "modulated" (default, modulated form): the sampled value is
              additionally multiplied by the per-position modulation mask
              v *= mask[n, p, oi, oj]
          "plain" (mask-free form): mask does not take part in the computation
              (its contents are arbitrary, possibly garbage data).
      The output is a single tensor:
          out[n, k, oi, oj] = bias[k]
                              + sum_{c, p} v(n, c, p, oi, oj) * weight[k, c, i, j]
      After the computation it is cast back to the input dtype.

    Bilinear interpolation definition (point-wise identical to mainstream
    deformable convolution operators):
      Let iy = floor(yc), ix = floor(xc), wy = yc - iy, wx = xc - ix, and take
      the four corners (iy, ix), (iy, ix+1), (iy+1, ix), (iy+1, ix+1) with
      weights (1-wy)(1-wx), (1-wy)wx, wy(1-wx), wy*wx respectively; when either
      the row or the column of a corner is out of range (< 0 or > dim-1) that
      corner contributes 0 while the remaining corners are weighted as usual --
      i.e. zero-fill semantics: a partially out-of-range coordinate is still
      weighted by the remaining valid corners, and when it is entirely out of
      range (yc <= -1, outside the yc >= H-1 boundary band, etc.) the sampled
      value is 0. No clamp / nearest-neighbour pull-back is done anywhere.

    Input/output specification (all tensors contiguous, NCHW layout):
      x        float32 / float16 / bfloat16 (N, C, H, W)
      offset   same dtype as x (N, 2*R*S, H_out, W_out): 2 channels per kernel
               position (even channel = y offset, odd channel = x offset,
               p = i*S + j row-major)
      weight   same dtype as x (K, C, R, S)
      bias     same dtype as x (K,)
      mask     same dtype as x (N, R*S, H_out, W_out) (ignored when
               variant="plain")
      out      a single tensor, same dtype as x (N, K, H_out, W_out)
      H_out = (H + 2*padding_h - dilation_h*(R-1) - 1) // stride_h + 1, likewise
      for W_out. The evaluator casts all inputs to fp32 before the call
      (low-precision inputs are lossless).

    Implementation constraints (violations are scored as failures):
      - The core computation (sampling-grid construction, bilinear-interpolation
        sampling, mask modulation, the weighted reduction against weight) must
        be handwritten with a HIP kernel inside the submitted file.
      - forward returns the single tensor out (the evaluator compares a single
        output).
      - Interpolation and the weighted reduction are computed in float32, with
        the output cast back to the input dtype.
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torchvision (including torchvision.ops.deform_conv2d) /
    torch.nn.functional.conv2d (F.conv2d) / torch.nn.Conv2d /
    torch.nn.functional.grid_sample (F.grid_sample) /
    torch.nn.functional.unfold (F.unfold) / torch.matmul / torch.bmm /
    torch.mm / torch.einsum / torch.tensordot / miopen / hipdnn / aiter.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
    regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h>
    is not available on this machine).
    """
    def __init__(self, variant: str = "modulated", stride=(1, 1), padding=(1, 1), dilation=(1, 1)):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("modulated", "plain"), "variant must be either modulated or plain"
        self.variant = variant
        self.stride = (int(stride[0]), int(stride[1]))
        self.padding = (int(padding[0]), int(padding[1]))
        self.dilation = (int(dilation[0]), int(dilation[1]))
        # <<<END_IMPROVE>>>

    def forward(self, x, offset, weight, bias, mask):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        n, c, h, w = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        k_out = weight.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        r, s = weight.shape[2], weight.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        sh, sw = self.stride
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        ph, pw = self.padding
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dh, dw = self.dilation
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        h_out = (h + 2 * ph - (dh * (r - 1) + 1)) // sh + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        w_out = (w + 2 * pw - (dw * (s - 1) + 1)) // sw + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert offset.shape[1] == 2 * r * s and mask.shape[1] == r * s, \
            "the channel counts of offset/mask must be 2*R*S / R*S"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert offset.shape[2] == h_out and offset.shape[3] == w_out \
            and mask.shape[2] == h_out and mask.shape[3] == w_out, \
            "the spatial sizes of offset/mask must be (H_out, W_out)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        xf = x.to(torch.float32)
        off = offset.to(torch.float32)
        wf = weight.to(torch.float32)
        bf = bias.to(torch.float32)
        mf = mask.to(torch.float32)
        return _pyramidkernel_get_extension().deform_conv2d_forward(
            xf, off, wf, bf, mf,
            sh, sw, ph, pw, dh, dw, self.variant == "modulated"
        ).to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        off = offset.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        wf = weight.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        bf = bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        dev = xf.device
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        base_y = (torch.arange(h_out, dtype=torch.float32, device=dev) * sh - ph).view(1, 1, h_out, 1) \
            + torch.arange(r, dtype=torch.float32, device=dev).view(r, 1, 1, 1) * dh
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        base_x = (torch.arange(w_out, dtype=torch.float32, device=dev) * sw - pw).view(1, 1, 1, w_out) \
            + torch.arange(s, dtype=torch.float32, device=dev).view(1, s, 1, 1) * dw
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        y_coord = (base_y + off[:, 0::2].reshape(n, r, s, h_out, w_out))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        x_coord = (base_x + off[:, 1::2].reshape(n, r, s, h_out, w_out))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        y_coord = y_coord.reshape(n, r * s, h_out, w_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        x_coord = x_coord.reshape(n, r * s, h_out, w_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        iy0 = torch.floor(y_coord).to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        ix0 = torch.floor(x_coord).to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        wy = y_coord - iy0.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        wx = x_coord - ix0.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        iy1 = iy0 + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_27>>>
        ix1 = ix0 + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_28>>>
        n_idx = torch.arange(n, device=xf.device).view(n, 1, 1, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_29>>>
        c_idx = torch.arange(c, device=xf.device).view(1, c, 1, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_30>>>
        def corner(iy, ix, wgt):
            # Single-corner sampling: the weight of an out-of-range corner is
            # set to 0; clamp only guards the index (cancelled by the times-0)
            valid = ((iy >= 0) & (iy <= h - 1) & (ix >= 0) & (ix <= w - 1)).to(torch.float32)
            vals = xf[n_idx, c_idx, iy.clamp(0, h - 1).unsqueeze(1),
                      ix.clamp(0, w - 1).unsqueeze(1)]
            return vals * valid.unsqueeze(1) * wgt.unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_31>>>
        sampled = (corner(iy0, ix0, (1.0 - wy) * (1.0 - wx))
                   + corner(iy0, ix1, (1.0 - wy) * wx)
                   + corner(iy1, ix0, wy * (1.0 - wx))
                   + corner(iy1, ix1, wy * wx))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_32>>>
        if self.variant == "modulated":
            sampled = sampled * mask.to(torch.float32).unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_33>>>
        y = torch.empty((n, k_out, h_out * w_out), dtype=torch.float32, device=xf.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_34>>>
        y = y + bf.view(1, k_out, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_35>>>
        return y.view(n, k_out, h_out, w_out).to(x.dtype)
        # <<<END_IMPROVE>>>
