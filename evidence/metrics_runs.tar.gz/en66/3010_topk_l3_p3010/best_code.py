import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl

@triton.jit
def _topk_short_kernel(x_ptr, out_ptr, m, k, stride_x, stride_o, BLOCK: tl.constexpr, K: tl.constexpr):
    row = tl.program_id(0)
    cols = tl.arange(0, BLOCK)
    valid = cols < m
    vals = tl.load(x_ptr + row * stride_x + cols, mask=valid, other=-float("inf"))
    neg_inf = -float("inf")
    for j in range(K):
        best = tl.max(vals, axis=0)
        pick = tl.argmax(vals, axis=0)
        tl.store(out_ptr + row * stride_o + j, best)
        tl.store(out_ptr + row * stride_o + k + j, pick.to(tl.float32))
        vals = tl.where(cols == pick, neg_inf, vals)

@triton.jit
def _topk_local_kernel(x_ptr, cand_ptr, m, k, stride_x, stride_c, nchunks, BLOCK: tl.constexpr, K: tl.constexpr):
    pid = tl.program_id(0)
    row = pid // nchunks
    chunk = pid - row * nchunks
    base = chunk * BLOCK
    cols = tl.arange(0, BLOCK)
    global_cols = base + cols
    valid = global_cols < m
    vals = tl.load(x_ptr + row * stride_x + global_cols, mask=valid, other=-float("inf"))
    neg_inf = -float("inf")
    for j in range(K):
        best = tl.max(vals, axis=0)
        pick = tl.argmax(vals, axis=0)
        out_base = row * stride_c + chunk * (2 * k)
        tl.store(cand_ptr + out_base + j, best)
        tl.store(cand_ptr + out_base + k + j, (base + pick).to(tl.float32))
        vals = tl.where(cols == pick, neg_inf, vals)

@triton.jit
def _topk_merge_kernel(cand_ptr, out_ptr, k, total, stride_c, stride_o, BLOCK: tl.constexpr, K: tl.constexpr, L: tl.constexpr):
    row = tl.program_id(0)
    pos = tl.arange(0, BLOCK)
    valid = pos < total
    chunk = pos // L
    within = pos - chunk * L
    cand_base = row * stride_c + chunk * (2 * L)
    vals = tl.load(cand_ptr + cand_base + within, mask=valid, other=-float("inf"))
    inds = tl.load(cand_ptr + cand_base + L + within, mask=valid, other=-1.0)
    neg_inf = -float("inf")
    for j in range(K):
        best = tl.max(vals, axis=0)
        pick = tl.argmax(vals, axis=0)
        tl.store(out_ptr + row * stride_o + j, best)
        tl.store(out_ptr + row * stride_o + k + j, tl.sum(tl.where(pos == pick, inds, 0.0), axis=0))
        vals = tl.where(pos == pick, neg_inf, vals)

def _launch_topk(x, k):
    b, m = x.shape
    out = torch.empty((b, 2 * k), device=x.device, dtype=torch.float32)
    if m <= 1024:
        block = 1
        while block < m:
            block *= 2
        warps = 1 if block <= 128 else (2 if block <= 512 else 4)
        _topk_short_kernel[(b,)](x, out, m, k, x.stride(0), out.stride(0), BLOCK=block, K=k, num_warps=warps)
        return out
    chunk = 1024
    nchunks = (m + chunk - 1) // chunk
    l = min(k, chunk)
    candidates = torch.empty((b, nchunks, 2 * l), device=x.device, dtype=torch.float32)
    _topk_local_kernel[(b * nchunks,)](x, candidates, m, l, x.stride(0), candidates.stride(0), nchunks, BLOCK=chunk, K=l, num_warps=4)
    total = nchunks * l
    merge_block = 1
    while merge_block < total:
        merge_block *= 2
    merge_warps = 1 if merge_block <= 1024 else 4
    _topk_merge_kernel[(b,)](candidates, out, k, total, candidates.stride(0), out.stride(0), BLOCK=merge_block, K=k, L=l, num_warps=merge_warps)
    return out
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """In-row Top-K selection: for every row of a 2-D score matrix take the k
    largest values (strictly descending) together with their original column
    indices. This operator is the selection stage of MoE gating, where top-k
    routing is applied to the expert logits.

    Operator semantics: the input x has shape (B, M) and, independently for every
    row b:
        (values[b, :], indices[b, :]) = TopK(x[b, :], k)
    values[b, :] are the k largest elements of x[b, :] in strictly descending
    order; indices[b, j] is the column index of values[b, j] inside that row
    (0 <= indices[b, j] < M, distinct within a row), that is out[b, k + j]
    satisfies x[b, out[b, k + j]] == out[b, j]. Mathematically this equals a full
    descending sort of each row followed by taking the first k values and their
    original column positions. Boundary behaviour: k = 1 degenerates to the row
    maximum and its argmax; k = M degenerates to a descending argsort of the whole
    row; with M = 1 the output is that row's only element and index 0. The
    evaluation inputs guarantee that the elements of each row are mutually
    unequal (built as a random permutation of a set of distinct values), so the
    Top-K result is uniquely determined -- the tie order of equal values is not
    part of this task's semantics.

    Implementation path hints (free choice):
      - short rows (M <= 1024): a single kernel selecting the maximum round by
        round -- each round takes the current maximum and the column index of its
        first occurrence, writes them out and then masks that position with the
        smallest float32 value, for exactly k rounds;
      - long rows (M > 1024): two stages -- cut the row into fixed-length chunks,
        run a local Top-K per chunk to obtain chunk_num*k candidates (values plus
        global column indices), then merge-sort the candidates and take the first
        k.

    Input/output specification:
        x   (B, M) float32 (the evaluator casts all inputs to fp32 before passing
            them in), contiguous, row elements mutually unequal; B >= 1,
            M >= 1 and < 2^24 (column indices are exactly representable in the
            fp32 packing), non powers of two allowed; the task scale domain is
            M in [16, 131072].
        k   constructor hyperparameter (passed via __init__), 1 <= k <= M.
        out (B, 2*k) a single float32 tensor (evaluation protocol: single-tensor
            output):
            out[:, :k]   = values (strictly descending, a bit-exact copy of the
                           input values)
            out[:, k:]   = indices (integer column indices, < 2^24, exactly
                           representable in fp32)
        The output is a pure selection result (no arithmetic), so any single bit
        of deviation is a semantic error.

    Implementation constraints (violations are scored as failures):
      - The core Top-K selection (scan / tiling / merge) must be done with a
        Triton kernel inside the submitted file, with both values and indices
        written by the kernel; numeric comparison happens in float32.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - The first k output columns must be strictly descending; the last k
        columns must be the original column indices (not chunk-local indices and
        not sort ranks).

    Disallowed list: aiter / torch.topk / torch.sort / torch.argsort /
    torch.kthvalue / torch.mode, plus the Tensor method forms of the shortcuts
    above .topk( / .sort( / .argsort( / .kthvalue( -- calling a selection
    operator directly and doing a full sort to take the first k are the same
    shortcut, so any appearance in any form fails (Triton primitives are
    unrestricted).
    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self, k: int = 8):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert k >= 1, "k must be >= 1"
        self.k = int(k)
        self._k_is_one = (self.k == 1)
        self._k_is_small = (self.k <= 8)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.to(torch.float32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        out = _launch_topk(x, self.k)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        return out
        # <<<END_IMPROVE>>>
