import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Standard 2D convolution backward: gradient with respect to the input
    (dgrad) and gradient with respect to the weights (wgrad).

    Semantics (NCHW, groups=1, no bias, strictly consistent with the PyTorch
    forward conv2d):
        forward y = conv2d(x, weight, stride=(stride_h,stride_w),
                        padding=(pad_h,pad_w), dilation=(dil_h,dil_w)),
        output size
            out_h = floor((H + 2*pad_h - dil_h*(R-1) - 1) / stride_h) + 1
        (likewise for out_w); given the upstream gradient dy = dL/dy (shape
        (N, out_c, out_h, out_w)):
            dgrad: dx = dL/dx, shape (N, C, H, W)
            wgrad: dw = dL/dw, shape (out_c, C, R, S)
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns dx; the values of x do not take part in the output
                 here (shape convention only);
        "wgrad": returns dw; the values of weight do not take part in the
                 output here (shape convention only).
    forward(dy, weight, x) has a fixed three-input signature; the tensors mean:
        dy     (N, out_c, out_h, out_w)   upstream gradient, consumed by both
                                          directions
        weight (out_c, C, R, S)           convolution kernel (out_c output
                                          channels / C input channels)
        x      (N, C, H, W)               forward input
    forward returns the single tensor out -- both directions are inherently
    single-output, with no concatenation packing:
        dgrad -> (N, C, H, W); wgrad -> (out_c, C, R, S); dtype as the inputs
        (float32 for this task).

    Input/output specification:
        dy / weight / x are all float32, contiguous, NCHW layout; every
        dimension >= 1;
        R/S may be 1 (1x1 convolution); H/W may be 1, odd, non-power-of-two,
        not 16-aligned;
        stride/dilation >= 1, padding >= 0, padding follows the four-sided
        symmetric (pad_h, pad_w) semantics of the forward conv (asymmetric
        pre/post padding is outside the domain of this task); consistency
        constraint
            H + 2*pad_h >= dil_h*(R-1) + 1, W + 2*pad_w >= dil_w*(S-1) + 1,
        and the spatial size of dy must equal out_h/out_w from the forward
        formula.
        Input values are ordinary randn magnitude (no inf/NaN). The evaluator
        casts all inputs to fp32 before the call.

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a HIP kernel inside the
          submitted file: the scatter accumulation of dgrad (dy convolved back
          over the kernel window following stride/dilation) or the correlation
          accumulation of wgrad (summing the cross-correlation of x windows
          with dy); falling back to torch convolution or autograd is
          forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares a
          single output).
        - Numeric contract: float32 inputs are accumulated directly in float32,
          with no downcast to half precision.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.nn.functional.conv2d / F.conv2d / torch.conv2d /
    torch.nn.Conv2d / torch.nn.functional.conv_transpose2d /
    F.conv_transpose2d / torch.nn.ConvTranspose2d /
    torch.nn.grad.conv2d_input / torch.nn.grad.conv2d_weight /
    aten.conv2d / aten.convolution / aten._convolution /
    aten.conv_transpose2d / aten.convolution_backward (including every
    spelling such as torch.ops.aten.*, at::.*) / torch.autograd / .backward( /
    unfold / F.fold / torch.nn.functional.fold / im2col / col2im / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP
    (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor
    regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h>
    is not available on this machine).
    """
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1, pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)
        # <<<END_IMPROVE>>>

    def forward(self, dy, weight, x):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        xg = x.detach().requires_grad_(True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        wg = weight.detach().requires_grad_(True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        y = torch.nn.functional.conv2d(
            xg, wg, None,
            (self.stride_h, self.stride_w),
            (self.pad_h, self.pad_w),
            (self.dil_h, self.dil_w),
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        if self.variant == "dgrad":
            (dx,) = torch.autograd.grad(y, (xg,), dy)
            return dx
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        (dw,) = torch.autograd.grad(y, (wg,), dy)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        return dw
        # <<<END_IMPROVE>>>
