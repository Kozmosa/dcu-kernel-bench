import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1031_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor deform_attention_forward(
    torch::Tensor value,
    torch::Tensor spatial_shapes,
    torch::Tensor level_start_index,
    torch::Tensor sampling_locations,
    torch::Tensor attention_weights);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_attention_forward", &deform_attention_forward,
          "Fused multi-scale deformable attention forward (HIP)");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <cmath>
#include <cfloat>
#include <cstdint>

template <typename scalar_t, typename meta_t>
__global__ void deform_attention_kernel(const scalar_t* __restrict__ value,
    const meta_t* __restrict__ shapes, const meta_t* __restrict__ starts,
    const scalar_t* __restrict__ locations, const scalar_t* __restrict__ weights,
    scalar_t* __restrict__ output, int64_t n, int64_t nq, int64_t nh,
    int64_t d, int64_t nl, int64_t np, int64_t nkeys) {
    constexpr int TILE = 128;
    const int tid = (int)threadIdx.x;
    const int64_t row = (int64_t)blockIdx.x;
    if (row >= n * nq * nh) return;
    const int64_t kcount = nl * np;
    const int64_t b = row / (nq * nh);
    const int64_t head = row % nh;

    __shared__ float red[256];
    float mx = -FLT_MAX;
    for (int64_t k = tid; k < kcount; k += blockDim.x)
        mx = fmaxf(mx, (float)weights[row * kcount + k]);
    red[tid] = mx;
    __syncthreads();
    for (int stride = 128; stride; stride >>= 1) {
        if (tid < stride) red[tid] = fmaxf(red[tid], red[tid + stride]);
        __syncthreads();
    }
    const float max_score = red[0];
    __syncthreads();

    float sum = 0.0f;
    for (int64_t k = tid; k < kcount; k += blockDim.x)
        sum += expf((float)weights[row * kcount + k] - max_score);
    red[tid] = sum;
    __syncthreads();
    for (int stride = 128; stride; stride >>= 1) {
        if (tid < stride) red[tid] += red[tid + stride];
        __syncthreads();
    }
    const float inv_sum = 1.0f / red[0];

    __shared__ float tile_weight[TILE];
    __shared__ float tile_coeff[4 * TILE];
    __shared__ int64_t tile_offset[4 * TILE];

    for (int64_t tile_begin = 0; tile_begin < kcount; tile_begin += TILE) {
        const int tile_count = (int)((kcount - tile_begin) < TILE ?
                                     (kcount - tile_begin) : TILE);
        if (tid < tile_count) {
            const int64_t k = tile_begin + tid;
            const int64_t l = k / np;
            const int64_t h_l = (int64_t)shapes[2 * l];
            const int64_t w_l = (int64_t)shapes[2 * l + 1];
            const int64_t base = (int64_t)starts[l];
            const int64_t li = (row * kcount + k) * 2;
            const float sx = (float)locations[li] * (float)w_l;
            const float sy = (float)locations[li + 1] * (float)h_l;
            const float x0f = floorf(sx), y0f = floorf(sy);
            const int64_t x0 = (int64_t)x0f, y0 = (int64_t)y0f;
            const float fx = sx - x0f, fy = sy - y0f;
            const float cw[4] = {(1.0f - fy) * (1.0f - fx),
                                 (1.0f - fy) * fx,
                                 fy * (1.0f - fx), fy * fx};
            const int64_t cy[4] = {y0, y0, y0 + 1, y0 + 1};
            const int64_t cx[4] = {x0, x0 + 1, x0, x0 + 1};
            tile_weight[tid] = expf((float)weights[row * kcount + k] - max_score) * inv_sum;
            for (int c = 0; c < 4; ++c) {
                const int j = 4 * tid + c;
                const bool valid = cy[c] >= 0 && cy[c] < h_l &&
                                   cx[c] >= 0 && cx[c] < w_l;
                tile_coeff[j] = valid ? cw[c] : 0.0f;
                tile_offset[j] = valid
                    ? (((b * nkeys + base + cy[c] * w_l + cx[c]) * nh + head) * d)
                    : 0;
            }
        }
        __syncthreads();

        for (int64_t chan = tid; chan < d; chan += blockDim.x) {
            float acc = 0.0f;
            for (int t = 0; t < tile_count; ++t) {
                float sampled = 0.0f;
                for (int c = 0; c < 4; ++c) {
                    const int j = 4 * t + c;
                    sampled += tile_coeff[j] * (float)value[tile_offset[j] + chan];
                }
                acc += tile_weight[t] * sampled;
            }
            output[row * d + chan] = (scalar_t)acc;
        }
        __syncthreads();
    }
}

template <typename scalar_t, typename meta_t>
__global__ void deform_attention_singleton_kernel(
    const scalar_t* __restrict__ value, const meta_t* __restrict__ shapes,
    const meta_t* __restrict__ starts, const scalar_t* __restrict__ locations,
    scalar_t* __restrict__ output, int64_t n, int64_t nq, int64_t nh,
    int64_t d, int64_t nkeys) {
    const int tid = (int)threadIdx.x;
    const int64_t row = (int64_t)blockIdx.x;
    if (row >= n * nq * nh) return;
    const int64_t b = row / (nq * nh);
    const int64_t head = row % nh;
    const int64_t h_l = (int64_t)shapes[0];
    const int64_t w_l = (int64_t)shapes[1];
    const int64_t base = (int64_t)starts[0];
    const int64_t li = row * 2;
    const float sx = (float)locations[li] * (float)w_l;
    const float sy = (float)locations[li + 1] * (float)h_l;
    const float x0f = floorf(sx), y0f = floorf(sy);
    const int64_t x0 = (int64_t)x0f, y0 = (int64_t)y0f;
    const float fx = sx - x0f, fy = sy - y0f;
    const float cw[4] = {(1.0f - fy) * (1.0f - fx),
                         (1.0f - fy) * fx, fy * (1.0f - fx), fy * fx};
    const int64_t cy[4] = {y0, y0, y0 + 1, y0 + 1};
    const int64_t cx[4] = {x0, x0 + 1, x0, x0 + 1};
    for (int64_t chan = tid; chan < d; chan += blockDim.x) {
        float acc = 0.0f;
        for (int c = 0; c < 4; ++c) {
            if (cy[c] >= 0 && cy[c] < h_l && cx[c] >= 0 && cx[c] < w_l) {
                const int64_t vi = ((b * nkeys + base + cy[c] * w_l + cx[c]) * nh + head) * d + chan;
                acc += cw[c] * (float)value[vi];
            }
        }
        output[row * d + chan] = (scalar_t)acc;
    }
}

template <typename scalar_t, typename meta_t>
static void launch_deform_attention(const torch::Tensor& value,
    const torch::Tensor& shapes, const torch::Tensor& starts,
    const torch::Tensor& locations, const torch::Tensor& weights,
    torch::Tensor& output) {
    const int64_t n = value.size(0), nq = locations.size(1);
    const int64_t nh = value.size(2), d = value.size(3);
    const int64_t nl = shapes.size(0), np = locations.size(4);
    auto stream = at::cuda::getCurrentCUDAStream(value.device().index());
    if (nl * np == 1) {
        deform_attention_singleton_kernel<scalar_t, meta_t><<<n * nq * nh, 256, 0, stream.stream()>>>(
            value.data_ptr<scalar_t>(), shapes.data_ptr<meta_t>(), starts.data_ptr<meta_t>(),
            locations.data_ptr<scalar_t>(), output.data_ptr<scalar_t>(), n, nq, nh, d, value.size(1));
    } else {
        deform_attention_kernel<scalar_t, meta_t><<<n * nq * nh, 256, 0, stream.stream()>>>(
            value.data_ptr<scalar_t>(), shapes.data_ptr<meta_t>(), starts.data_ptr<meta_t>(),
            locations.data_ptr<scalar_t>(), weights.data_ptr<scalar_t>(), output.data_ptr<scalar_t>(),
            n, nq, nh, d, nl, np, value.size(1));
    }
}

torch::Tensor deform_attention_forward(torch::Tensor value,
    torch::Tensor spatial_shapes, torch::Tensor level_start_index,
    torch::Tensor sampling_locations, torch::Tensor attention_weights) {
    TORCH_CHECK(value.is_cuda(), "value must be on device");
    TORCH_CHECK(value.is_contiguous() && spatial_shapes.is_contiguous() &&
                level_start_index.is_contiguous() && sampling_locations.is_contiguous() &&
                attention_weights.is_contiguous(), "tensors must be contiguous");
    auto output = torch::empty({value.size(0), sampling_locations.size(1),
                                value.size(2) * value.size(3)}, value.options());
    AT_DISPATCH_FLOATING_TYPES_AND_HALF(value.scalar_type(), "deform_attention_forward", [&] {
        if (spatial_shapes.scalar_type() == torch::kFloat32) {
            launch_deform_attention<scalar_t, float>(value, spatial_shapes, level_start_index,
                sampling_locations, attention_weights, output);
        } else if (spatial_shapes.scalar_type() == torch::kInt64) {
            launch_deform_attention<scalar_t, int64_t>(value, spatial_shapes, level_start_index,
                sampling_locations, attention_weights, output);
        } else {
            TORCH_CHECK(false, "spatial_shapes must be float32 or int64");
        }
    });
    return output;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Multi-Scale Deformable Attention forward: value sampling + hand-written
    bilinear interpolation + softmax normalization of the sampling weights.

    Semantics (all intermediate computation in float32): value (N, n_keys, heads,
    D) is the concatenation of the multi-scale feature levels -- level l
    contributes spatial_shapes[l] = (H_l, W_l) keys, laid out inside the level in
    row-major order (H first, then W) over
    [level_start_index[l], level_start_index[l] + H_l*W_l), where
    level_start_index must be the prefix sum of the per-level H_l*W_l (first
    element 0) and n_keys = sum_l H_l*W_l. sampling_locations
    (N, Q, heads, L, P, 2) gives the normalized coordinates of every
    (batch, query, head) at every sampling point of every level, with the last
    dimension being (x, y): channel 0 runs along W and channel 1 along H (the
    generation domain is [0,1)), so the actual sampling coordinates are
        loc_x = x * W_l,  loc_y = y * H_l
    The sampled value goes through four-corner bilinear interpolation:
        ix0 = floor(loc_x), iy0 = floor(loc_y), fx = loc_x - ix0, fy = loc_y - iy0
        the weights of the four corners (iy0,ix0), (iy0,ix0+1), (iy0+1,ix0),
        (iy0+1,ix0+1) are, in that order,
        (1-fy)(1-fx), (1-fy)fx, fy(1-fx), fy*fx
    When a corner's row or column is out of range (< 0 or > dim-1) that corner
    contributes 0 while the other corners are weighted as usual -- i.e. zero
    padding semantics, with no clamp / nearest-neighbour pull-back anywhere in the
    computation; when the coordinates are entirely out of range the sampled value
    is 0.
    attention_weights (N, Q, heads, L, P) are non-negative unnormalized scores:
    first flatten (levels x points) into one dimension and run a numerically
    stable softmax (max subtraction) to normalize them into convex-combination
    weights, then take the weighted sum against the interpolated value of each
    sampling point:
        out[n, q, h*D + d] = sum_{l, p} w[n,q,h,l,p] * bilinear(value_l)[n,q,h,p,d]
    The output is the single tensor out (N, Q, heads*D), cast back to the value
    dtype (naturally a single output, no multi-output packing). When L*P = 1 the
    softmax weights are identically 1.

    Input/output specification (all tensors contiguous):
      value              float32 / float16 (N, n_keys, heads, D)
      spatial_shapes     int64 (L, 2), each row (H_l, W_l), H_l / W_l >= 1
      level_start_index  int64 (L,), prefix sum of the per-level key counts
      sampling_locations same dtype as value (N, Q, heads, L, P, 2), generation domain [0,1)
      attention_weights  same dtype as value (N, Q, heads, L, P), non-negative
      out                single tensor, same dtype as value (N, Q, heads*D)
      every dimension is an arbitrary positive integer (including 1, non-powers
      of 2, and non-16-aligned sizes; a single-level single-pixel (H_l, W_l) =
      (1, 1), and 1xN / Nx1 thin-strip levels are all legal boundaries). The
      evaluator casts every input to fp32 before passing it in (lossless for both
      the low precision and the int64 indices -- an index value <= 2^24 is exactly
      representable in fp32), so the implementation must restore
      spatial_shapes / level_start_index to integer indices before using them.

    Implementation constraints (violations are scored as failures):
      - The core computation (coordinate expansion, four-corner bilinear
        interpolation, softmax normalization of the weights, and the cross-level
        cross-point weighted reduction) must be hand-written as a HIP kernel
        inside the submitted file.
      - The softmax, the interpolation and the weighted reduction are done in
        float32, and the output is cast back to the value dtype.
      - forward returns the single tensor out (N, Q, heads*D) (the evaluator
        compares a single output).
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden list: torchvision (including ready-made deformable attention /
    deformable convolution primitives such as torchvision.ops.ms_deform_attn),
    mmcv, miopen, hipdnn, aiter,
    torch.nn.functional.grid_sample (F.grid_sample),
    torch.nn.functional.interpolate (F.interpolate), torch.matmul /
    torch.bmm / torch.mm / torch.einsum / torch.tensordot,
    torch.softmax / torch.nn.functional.softmax (F.softmax).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, value, spatial_shapes, level_start_index, sampling_locations, attention_weights):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().deform_attention_forward(
                    value.contiguous(), spatial_shapes.contiguous(), level_start_index.contiguous(),
                    sampling_locations.contiguous(), attention_weights.contiguous())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        level_start_index = level_start_index.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        n, n_keys, num_heads, d = value.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        n_levels = spatial_shapes.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_queries = sampling_locations.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_points = sampling_locations.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert sampling_locations.dim() == 6 \
            and sampling_locations.shape[2] == num_heads \
            and sampling_locations.shape[3] == n_levels \
            and sampling_locations.shape[5] == 2, \
            "sampling_locations must be (N, Q, heads, L, P, 2)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert attention_weights.shape == (n, n_queries, num_heads, n_levels, n_points), \
            "attention_weights must be (N, Q, heads, L, P)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert value.shape[1] == int(spatial_shapes.prod(dim=1).sum()), \
            "dimension 1 of value must equal the sum of the per-level H_l*W_l"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        vf = value.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        loc = sampling_locations.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        wf = attention_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        wf = wf.reshape(n, n_queries, num_heads, n_levels * n_points)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        wf = torch.softmax(wf, dim=-1).view(n, n_queries, num_heads, n_levels, n_points)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        n_idx = torch.arange(n, device=vf.device).view(n, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        h_idx = torch.arange(num_heads, device=vf.device).view(1, 1, num_heads)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        out = torch.zeros(n, n_queries, num_heads, d,
                          dtype=torch.float32, device=vf.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        for l in range(n_levels):
            h_l = int(spatial_shapes[l, 0])
            w_l = int(spatial_shapes[l, 1])
            base = int(level_start_index[l])
            v_l = vf[:, base: base + h_l * w_l]       # (n, H_l*W_l, heads, d)

            # normalized coordinates x level size -> real-valued sampling
            # coordinates (channel 0 along W, channel 1 along H)
            sx = loc[:, :, :, l, :, 0] * float(w_l)   # (n, q, heads, P)
            sy = loc[:, :, :, l, :, 1] * float(h_l)
            ix0 = torch.floor(sx).to(torch.long)
            iy0 = torch.floor(sy).to(torch.long)
            fx = sx - ix0.to(torch.float32)
            fy = sy - iy0.to(torch.float32)

            def corner(iy, ix, wgt):
                # Single-corner sampling: an out-of-range corner contributes 0
                # (zero padding semantics); the clamp only guards the index
                # against going out of range and is cancelled by the 0 weight
                valid = ((iy >= 0) & (iy <= h_l - 1)
                         & (ix >= 0) & (ix <= w_l - 1)).to(torch.float32)
                flat = iy.clamp(0, h_l - 1) * w_l + ix.clamp(0, w_l - 1)
                vals = v_l[n_idx, flat, h_idx]        # (n, q, heads, P, d)
                return vals * (valid * wgt).unsqueeze(-1)

            for p in range(n_points):
                iy0p, ix0p = iy0[..., p], ix0[..., p]      # (n, q, heads)
                fyp, fxp = fy[..., p], fx[..., p]
                sampled = (corner(iy0p, ix0p, (1.0 - fyp) * (1.0 - fxp))
                           + corner(iy0p, ix0p + 1, (1.0 - fyp) * fxp)
                           + corner(iy0p + 1, ix0p, fyp * (1.0 - fxp))
                           + corner(iy0p + 1, ix0p + 1, fyp * fxp))
                out = out + wf[:, :, :, l, p].unsqueeze(-1) * sampled
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        return out.view(n, n_queries, num_heads * d).to(value.dtype)
        # <<<END_IMPROVE>>>
