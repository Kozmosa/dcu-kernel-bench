import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _batched_bf16_kernel(
    X, W, Bias, Out,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    XSB: tl.constexpr, XSM: tl.constexpr, XSK: tl.constexpr,
    WSB: tl.constexpr, WSN: tl.constexpr, WSK: tl.constexpr,
    BSB: tl.constexpr, BSN: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
):
    tile = tl.program_id(0)
    batch = tl.program_id(1)
    nt = tl.cdiv(N, BLOCK_N)
    rows = (tile // nt) * BLOCK_M + tl.arange(0, BLOCK_M)
    cols = (tile % nt) * BLOCK_N + tl.arange(0, BLOCK_N)
    ks = tl.arange(0, BLOCK_K)
    total = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for start in range(tl.cdiv(K, BLOCK_K)):
        kk = start * BLOCK_K + ks
        a = tl.load(
            X + batch * XSB + rows[:, None] * XSM + kk[None, :] * XSK,
            mask=(rows[:, None] < M) & (kk[None, :] < K), other=0,
        )
        w = tl.load(
            W + batch * WSB + cols[None, :] * WSN + kk[:, None] * WSK,
            mask=(cols[None, :] < N) & (kk[:, None] < K), other=0,
        )
        total = tl.dot(a, w, total)
    if HAS_BIAS:
        bv = tl.load(Bias + batch * BSB + cols * BSN, mask=cols < N, other=0)
        total = (total.to(tl.bfloat16).to(tl.float32) + bv[None, :].to(tl.float32)).to(tl.bfloat16).to(tl.float32)
    result = total.to(Out.dtype.element_ty)
    tl.store(
        Out + batch * M * N + rows[:, None] * N + cols[None, :],
        result, mask=(rows[:, None] < M) & (cols[None, :] < N),
    )
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Batch-dimension bf16 GEMM: computes x[b] @ weight[b]^T independently for
    every matrix in the batch.

    Mathematical definition (independent per b in the batch, B/M/N/K >= 1):
      acc[b, m, n] = sum_k x[b, m, k] * weight[b, n, k]    (float32 accumulation)
      out[b, m, n] = acc[b, m, n] + bias[b, 0, n]          (optional bias)
    weight is stored row-major as (B, N, K), so the computation is equivalent to a
    transposed GEMM (each output channel corresponds to one row of weight). The
    bias fusion order follows GEMM kernel convention: the float32 accumulated
    result is first cast to the input dtype (bfloat16), bias is then added
    (bfloat16 arithmetic), and finally the result is cast to the output dtype. With
    no bias it is cast directly. Boundary behaviour: B/M/N/K may be any value >= 1
    (including the minimal 1x1x1 size) and the dimensions may be
    non-powers-of-two, with no alignment requirement on any of them.

    Input/output specification:
      x      bfloat16  (B, M, K)  the activation matrix
      weight bfloat16  (B, N, K)  the weight matrix (row-major, transposed-GEMM semantics)
      bias   bfloat16  (B, 1, N)  optional; when use_bias=False a placeholder tensor is
                                  passed and ignored
      out    output dtype (B, M, N), where the dtype is set by __init__'s out_dtype
                                  (bfloat16 / float16)

    Implementation constraints (violations are scored as failures):
      - The core computation (the bf16 GEMM multiply-accumulate and the bias fusion)
        must be completed inside the submitted file; calling torch.matmul /
        torch.bmm / torch.mm / torch.addmm / torch.baddbmm / torch.einsum /
        F.linear / functional.linear / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; the bias branch follows the fusion
        order above; cast the output to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward; the input
        values (small integer codes and values representable in bfloat16) are all
        exactly representable in fp32, so .to(torch.bfloat16) at the entry point
        recovers them losslessly.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: TN layout (x row-major (B,M,K), weight row-major (B,N,K)), no
    split-K, no quantization component at all (pure bf16 inputs, no scale
    dequantization).
    """
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        x = x.to(torch.bfloat16)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        weight = weight.to(torch.bfloat16)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        bias = bias.to(torch.bfloat16) if self.use_bias else None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        B, M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = weight.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == weight.shape[2], "x and weight must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        acc = torch.empty((B, M, N), device=x.device, dtype=self.out_dtype)
        _batched_bf16_kernel[(triton.cdiv(M, 32) * triton.cdiv(N, 64), B)](
            x, weight, bias if bias is not None else x, acc,
            M, N, K,
            x.stride(0), x.stride(1), x.stride(2),
            weight.stride(0), weight.stride(1), weight.stride(2),
            bias.stride(0) if bias is not None else 0,
            bias.stride(2) if bias is not None else 0,
            bias is not None,
            BLOCK_M=32, BLOCK_N=64, BLOCK_K=32,
            num_warps=4, num_stages=2,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # Bias and both required bf16 rounding steps are fused in the Triton kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        return acc.to(self.out_dtype)
        # <<<END_IMPROVE>>>
