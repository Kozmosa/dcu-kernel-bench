import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _broadcast_mul_add_kernel(X, A, B, Y, N,
                              A_TENSOR: tl.constexpr, B_TENSOR: tl.constexpr,
                              A_FULL: tl.constexpr, B_FULL: tl.constexpr,
                              BLOCK: tl.constexpr):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    mask = offsets < N
    xv = tl.load(X + offsets, mask=mask, other=0).to(tl.float32)
    if A_TENSOR:
        if A_FULL:
            av = tl.load(A + offsets, mask=mask, other=0).to(tl.float32)
        else:
            av = tl.load(A).to(tl.float32)
    else:
        av = tl.cast(A, tl.float32)
    if B_TENSOR:
        if B_FULL:
            bv = tl.load(B + offsets, mask=mask, other=0).to(tl.float32)
        else:
            bv = tl.load(B).to(tl.float32)
    else:
        bv = tl.cast(B, tl.float32)
    result = av * xv + bv
    tl.store(Y + offsets, result.to(Y.dtype.element_ty), mask=mask)


def _broadcast_mul_add(x, a, b):
    a_tensor = isinstance(a, torch.Tensor)
    b_tensor = isinstance(b, torch.Tensor)
    a_full = a_tensor and a.numel() != 1
    b_full = b_tensor and b.numel() != 1
    a_arg = a if a_tensor else float(a)
    b_arg = b if b_tensor else float(b)
    output = torch.empty_like(x)
    count = x.numel()
    if count:
        block = 1024
        _broadcast_mul_add_kernel[(triton.cdiv(count, block),)](
            x, a_arg, b_arg, output, count,
            a_tensor, b_tensor, a_full, b_full, block,
            num_warps=4, enable_fp_fusion=False,
        )
    return output
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Element-wise fused multiply-add: out = a * x + b.

    (1) Operator semantics: for every element i of x,
    out[i] = a_i * x[i] + b_i. a and b each independently take one of the
    following three forms (any combination is allowed, e.g. a a scalar while b is a
    same-shape tensor):
      1. a Python float / int scalar: a_i = a (the value is broadcast to every
         element of x);
      2. a single-element tensor (numel == 1, any shape, e.g. (1,)): a_i = its only
         element (broadcast);
      3. a tensor with the same shape as x (numel == x.numel()): a_i = the
         corresponding element of a.
    x is a floating-point tensor of arbitrary rank and shape (including
    non-powers-of-two and prime sizes). Intermediate computation runs in float32
    (x / a / b are first promoted to float32, then multiplied and added), and the
    final result is cast back to the dtype of x. Boundary behaviour: this operator
    has no integer tensor inputs and no indexing/length-like semantics; when a and
    b are both scalars the output still has the same shape as x.

    (2) Input/output specification:
      - x: float16 / bfloat16 / float32 tensor, arbitrary shape, contiguous;
      - a, b: one of the three forms above; when a tensor, contiguous with the
        same dtype as x;
      - returns: a new tensor with the same shape and dtype as x (out-of-place; no
        input may be overwritten in place).

    (3) Implementation constraints (violations are scored as failures):
      - The core computation (the multiply-add) must be completed inside the
        submitted file with a self-written Triton kernel: a single kernel and a
        single read-compute-write pass; splitting it into a multiply kernel followed
        by an add kernel is forbidden;
      - When a / b is a scalar or a single-element tensor it must take part in the
        kernel as a broadcast argument and must not be materialized into a
        temporary big tensor with the same shape as x;
      - The __init__ and forward signatures of ModelNew must not be changed;
      - Use float32 for intermediate computation; cast the output back to the dtype
        of x.

    (4) Forbidden list and target hardware:
      - Directly completing this task's computation with ATen shortcuts is
        forbidden: torch.addcmul (including the .addcmul / .addcmul_ methods),
        torch.add, torch.mul, and tensor methods with their in-place forms such as
        .add( / .mul( / .add_( / .mul_; calling a same-functionality entry point
        provided by any precompiled operator library is also forbidden (the final
        static audit does substring matching on the code outside
        docstrings/comments);
      - Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, x, a, b):
        # <<<IMPROVE:forward_stmt_1>>>
        return _broadcast_mul_add(x, a, b)
        # <<<END_IMPROVE>>>
