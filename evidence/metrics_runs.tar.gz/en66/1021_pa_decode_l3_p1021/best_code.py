import math
import torch
import torch.nn as nn

# <<<IMPROVE:helpers>>>
import triton
import triton.language as tl


@triton.jit
def _paged_partial(Q, K, V, BT, L, M, Z, A,
                   HQ: tl.constexpr, D: tl.constexpr, G: tl.constexpr,
                   BS: tl.constexpr, CAP: tl.constexpr, P: tl.constexpr,
                   SCALE: tl.constexpr, QS: tl.constexpr, QH: tl.constexpr, QD: tl.constexpr,
                   K0: tl.constexpr, K1: tl.constexpr, K2: tl.constexpr, K3: tl.constexpr,
                   V0: tl.constexpr, V1: tl.constexpr, V2: tl.constexpr, V3: tl.constexpr,
                   B0: tl.constexpr, B1: tl.constexpr, LS: tl.constexpr,
                   DD: tl.constexpr):
    sh = tl.program_id(0)
    part = tl.program_id(1)
    s = sh // HQ
    h = sh % HQ
    kh = h // G
    length = tl.load(L + s * LS)
    d = tl.arange(0, DD)
    t = tl.arange(0, 64)
    q = tl.load(Q + s * QS + h * QH + d * QD, d < D, 0).to(tl.float32) * SCALE
    mx = tl.full((), -float('inf'), tl.float32)
    den = tl.full((), 0, tl.float32)
    acc = tl.full((DD,), 0, tl.float32)
    end = tl.minimum(length, (part + 1) * 512)
    for start in range(part * 512, end, 64):
        pos = start + t
        valid = (pos < length) & (pos // BS < CAP)
        page = tl.load(BT + s * B0 + (pos // BS) * B1, valid, 0).to(tl.int64)
        kp = page[:, None] * K0 + kh * K1 + (pos % BS)[:, None] * K2 + d[None, :] * K3
        kval = tl.load(K + kp, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        score = tl.sum(kval * q[None, :], 1)
        score = tl.where(valid, score, -float('inf'))
        newmx = tl.maximum(mx, tl.max(score, 0))
        alpha = tl.exp(mx - newmx)
        prob = tl.exp(score - newmx)
        vp = page[:, None] * V0 + kh * V1 + (pos % BS)[:, None] * V2 + d[None, :] * V3
        vval = tl.load(V + vp, valid[:, None] & (d[None, :] < D), 0).to(tl.float32)
        acc = acc * alpha + tl.sum(prob[:, None] * vval, 0)
        den = den * alpha + tl.sum(prob, 0)
        mx = newmx
    index = sh * P + part
    tl.store(M + index, mx)
    tl.store(Z + index, den)
    tl.store(A + index * D + d, acc, d < D)


@triton.jit
def _paged_merge(M, Z, A, O, HQ: tl.constexpr, D: tl.constexpr,
                 P: tl.constexpr, PP: tl.constexpr, DD: tl.constexpr,
                 O0: tl.constexpr, O1: tl.constexpr, O2: tl.constexpr):
    sh = tl.program_id(0)
    p = tl.arange(0, PP)
    d = tl.arange(0, DD)
    idx = sh * P + p
    m = tl.load(M + idx, p < P, -float('inf'))
    z = tl.load(Z + idx, p < P, 0)
    maximum = tl.max(m, 0)
    nonempty = (p < P) & (z > 0)
    safe_m = tl.where(nonempty, m, maximum)
    weight = tl.where(nonempty, tl.exp(safe_m - maximum), 0.0)
    a = tl.load(A + idx[:, None] * D + d[None, :], (p[:, None] < P) & (d[None, :] < D), 0)
    numerator = tl.sum(a * weight[:, None], 0)
    denominator = tl.sum(z * weight, 0)
    tl.store(O + (sh // HQ) * O0 + (sh % HQ) * O1 + d * O2,
             numerator / denominator, d < D)
# <<<END_IMPROVE>>>

class ModelNew(nn.Module):
    """Paged attention for the long-context decode phase (single-token query), for both MHA and GQA.

    Operator semantics: the KV cache is paged with a fixed block_size in the
    physical block pool key_cache / value_cache, and each sequence is addressed
    indirectly through the physical block ids in block_tables; the KV length that
    actually takes part in attention for each sequence is given by seq_lens[s]
    (>=1); slots of the physical block pool that nothing references, and slots of
    the tail block beyond seq_lens[s], are garbage data and must not take part in
    the computation. For query head h of sequence s (its KV head is
    h // query_group_size; let bs = block_size, bt = block_tables):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    softmax is a numerically stable reduction over the whole
    [0, seq_lens[s]) interval.

    This task is in the long-context regime: the block-table capacity max_seq_len
    (16384 in the fixed family) far exceeds 8192, so a single sequence's KV can be
    long. How the work is parallelized is **not** a scoring criterion -- any
    implementation that is numerically equivalent to the full softmax within the
    tolerance is acceptable, and the implementation path is free. Core boundary
    cases: partially filled tail blocks (seq_len not a multiple of the block
    size), seq_len exactly a multiple of the block size, wildly different
    sequence lengths within one batch (as short as 1), and tail-block slot
    masking -- positions beyond seq_len must not contribute any probability mass.

    Input/output specification:
      query       [num_seqs, num_q_heads, head_size], fp16/bf16
      key_cache   [num_blocks, num_kv_heads, block_size, head_size], fp16/bf16
      value_cache same as key_cache
      block_tables[num_seqs, max_blocks_per_seq] int32, logical block -> physical block id
      seq_lens    [num_seqs] int32, each sequence's valid KV length, 1 <= seq_lens[s] <= max_seq_len
      output out  [num_seqs, num_q_heads, head_size], dtype matches query

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling external attention operator libraries such as
        scaled_dot_product_attention / sdpa / flash_attn, and torch.matmul /
        torch.bmm / torch.einsum / torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - Unreferenced physical blocks and slots beyond seq_len must not affect the
        output.

    Target hardware: Hygon DCU (gfx936). Implementation language: Triton.
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding
    window; the long-context regime (max(seq_lens) > 8192).
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        # Consume native integer block-table entries directly.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        capacity = block_tables.shape[1] * bs
        partitions = triton.cdiv(capacity, 512)
        maxima = torch.empty((B, H_Q, partitions), device=query.device, dtype=torch.float32)
        denominators = torch.empty_like(maxima)
        partials = torch.empty((B, H_Q, partitions, D), device=query.device, dtype=torch.float32)
        _paged_partial[(B * H_Q, partitions)](
            query, key_cache, value_cache, block_tables, seq_lens,
            maxima, denominators, partials,
            H_Q, D, group, bs, block_tables.shape[1], partitions, self.scale,
            *query.stride(), *key_cache.stride(), *value_cache.stride(),
            *block_tables.stride(), seq_lens.stride(0), triton.next_power_of_2(D),
            num_warps=4)
        _paged_merge[(B * H_Q,)](
            maxima, denominators, partials, out, H_Q, D, partitions,
            triton.next_power_of_2(partitions), triton.next_power_of_2(D),
            *out.stride(), num_warps=4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
