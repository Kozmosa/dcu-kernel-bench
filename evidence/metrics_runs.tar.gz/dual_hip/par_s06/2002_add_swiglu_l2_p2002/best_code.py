import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor add_swiglu(torch::Tensor base, torch::Tensor delta, torch::Tensor grad_out);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("add_swiglu", &add_swiglu);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cstdint>

template <typename T>
__global__ void add_swiglu_kernel(const T* __restrict__ base,
                                  const T* __restrict__ delta,
                                  const T* __restrict__ grad_out,
                                  T* __restrict__ result,
                                  int64_t D, int64_t count) {
    const int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= count) return;
    const int64_t r = i / D;
    const int64_t c = i - r * D;
    const int64_t p = r * (2 * D) + c;
    const float gate = static_cast<float>(base[p]) + static_cast<float>(delta[p]);
    const float up = static_cast<float>(base[p + D]) + static_cast<float>(delta[p + D]);
    const float g = static_cast<float>(grad_out[i]);
    const float s = 1.0f / (1.0f + exp2f(-gate * 1.4426950408889634f));
    const float a = gate * s;
    const float out = a * up;
    const float dg = (g * up) * (s + a * (1.0f - s));
    const float du = g * a;
    const int64_t q = r * (3 * D) + c;
    result[q] = static_cast<T>(out);
    result[q + D] = static_cast<T>(dg);
    result[q + 2 * D] = static_cast<T>(du);
}

torch::Tensor add_swiglu(torch::Tensor base, torch::Tensor delta, torch::Tensor grad_out) {
    const c10::cuda::CUDAGuard guard(base.device());
    const int64_t rows = base.size(0);
    const int64_t D = base.size(1) / 2;
    auto result = torch::empty({rows, 3 * D}, base.options());
    const int64_t count = rows * D;
    if (count == 0) return result;
    const dim3 block(256);
    const dim3 grid((count + 255) / 256);
    const auto stream = c10::cuda::getCurrentCUDAStream(base.get_device());
    if (base.scalar_type() == at::kHalf) {
        add_swiglu_kernel<at::Half><<<grid, block, 0, stream.stream()>>>(
            base.data_ptr<at::Half>(), delta.data_ptr<at::Half>(),
            grad_out.data_ptr<at::Half>(), result.data_ptr<at::Half>(), D, count);
    } else if (base.scalar_type() == at::kBFloat16) {
        add_swiglu_kernel<at::BFloat16><<<grid, block, 0, stream.stream()>>>(
            base.data_ptr<at::BFloat16>(), delta.data_ptr<at::BFloat16>(),
            grad_out.data_ptr<at::BFloat16>(), result.data_ptr<at::BFloat16>(), D, count);
    } else if (base.scalar_type() == at::kFloat) {
        add_swiglu_kernel<float><<<grid, block, 0, stream.stream()>>>(
            base.data_ptr<float>(), delta.data_ptr<float>(),
            grad_out.data_ptr<float>(), result.data_ptr<float>(), D, count);
    } else {
        TORCH_CHECK(false, "add_swiglu requires float16, bfloat16 or float32");
    }
    const hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess, "add_swiglu launch failed: ", hipGetErrorString(error));
    return result;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Training-oriented Add + SwiGLU fused operator: forward activation plus
    first-order analytic backward in a single call.

    Operator semantics:
      base and delta are added element-wise, then split in half along the last
      dimension (let D = width // 2):
        gate = (base + delta)[..., :D], up = (base + delta)[..., D:]
      The forward is a plain (non-clipped, non-interleaved) SwiGLU:
        out = SiLU(gate) * up, where SiLU(g) = g * sigmoid(g)
      The backward receives the upstream gradient grad_out (same shape as out);
      the derivative of SiLU is
        SiLU'(g) = sigmoid(g) * (1 + g * (1 - sigmoid(g)))
      base and delta enter the sum with the same coefficient, so their input
      gradients are element-wise identical:
        grad[..., :D] = (grad_out * up) * SiLU'(gate)
        grad[..., D:] = grad_out * SiLU(gate)
      This task merges forward and backward into a single forward call returning
      one fused tensor (3D columns):
        fused[..., 0:D)   = out (the activation output)
        fused[..., D:2D)  = the gate half of grad (the same for base and delta)
        fused[..., 2D:3D) = the up half of grad
      Boundary behaviour: width is a non-zero even number; num_rows may be 0 (an
      empty batch, output (0, 3D)); the input tensors are not modified; there is
      no broadcasting and no implicit dtype promotion; the evaluation ground truth
      is the float32 intermediate computation, and the tolerances cover the
      differences between half-precision rounding paths, so no specific eager
      rounding chain needs to be reproduced bit-for-bit.

    Input/output specification:
      base     (num_rows, width)      contiguous float16/bfloat16, width a non-zero even number
      delta    (num_rows, width)      same shape, dtype and device as base
      grad_out (num_rows, width // 2) same dtype as base, the upstream gradient of out
      returns  (num_rows, 3 * (width // 2)) same dtype as base, layout as above

    Implementation constraints (violations are scored as failures):
      - The core computation (the addition, SiLU/sigmoid, and the two gradient
        formulas) must be completed with a HIP kernel inside the submitted file;
        torch tensor operations are limited to output allocation and layout
        handling.
      - Calling ready-made implementations such as aiter /
        torch.nn.functional.silu / torch.sigmoid / torch.matmul / torch.bmm /
        torch.einsum is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, base, delta, grad_out):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().add_swiglu(base, delta, grad_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        y = delta.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        g = grad_out.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        gate, up = (x + y).chunk(2, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        sig = torch.sigmoid(gate)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        silu = gate * sig
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        out = silu * up
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        dgate = (g * up) * (sig + gate * sig * (1.0 - sig))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        dup = g * silu
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        fused = torch.cat([out, dgate, dup], dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return fused.to(base.dtype)
        # <<<END_IMPROVE>>>
