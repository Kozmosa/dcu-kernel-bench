import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p6001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

at::Tensor fused_adamw(
    const at::Tensor& params,
    const at::Tensor& grads,
    const at::Tensor& exp_avg,
    const at::Tensor& exp_avg_sq,
    const at::Tensor& step,
    double lr,
    double beta1,
    double beta2,
    double eps,
    double weight_decay,
    bool adamw_variant);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_adamw", &fused_adamw, "Fused AdamW HIP update");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <c10/hip/HIPStream.h>

namespace {

template <typename scalar_t>
__global__ void fused_adamw_kernel(
    const scalar_t* __restrict__ params,
    const scalar_t* __restrict__ grads,
    const scalar_t* __restrict__ exp_avg,
    const scalar_t* __restrict__ exp_avg_sq,
    const float* __restrict__ step,
    scalar_t* __restrict__ out,
    int64_t n,
    float lr,
    float beta1,
    float beta2,
    float eps,
    float weight_decay,
    bool adamw_variant) {
    __shared__ float shared_lr_over_bc1;
    __shared__ float shared_inv_bc2;
    float lr_over_bc1 = lr;
    float inv_bc2 = 1.0f;
    if (adamw_variant) {
        if (threadIdx.x == 0) {
            const float s = step[0];
            const float bc1 = 1.0f - powf(beta1, s);
            const float bc2 = 1.0f - powf(beta2, s);
            shared_lr_over_bc1 = lr * (1.0f / bc1);
            shared_inv_bc2 = 1.0f / bc2;
        }
        __syncthreads();
        lr_over_bc1 = shared_lr_over_bc1;
        inv_bc2 = shared_inv_bc2;
    }
    const float decay = 1.0f - lr * weight_decay;
    for (int64_t i = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
         i < n;
         i += static_cast<int64_t>(blockDim.x) * gridDim.x) {
        const float p = static_cast<float>(params[i]) * decay;
        const float g = static_cast<float>(grads[i]);
        const float m = beta1 * static_cast<float>(exp_avg[i]) + (1.0f - beta1) * g;
        const float v = beta2 * static_cast<float>(exp_avg_sq[i]) + (1.0f - beta2) * g * g;
        if (adamw_variant) {
            const float denom = sqrtf(v * inv_bc2) + eps;
            out[i] = static_cast<scalar_t>(p - (m * lr_over_bc1) / denom);
        } else {
            const float update = m / (sqrtf(v) + eps);
            out[i] = static_cast<scalar_t>(p - lr * update);
        }
    }
}

} // namespace

at::Tensor fused_adamw(
    const at::Tensor& params,
    const at::Tensor& grads,
    const at::Tensor& exp_avg,
    const at::Tensor& exp_avg_sq,
    const at::Tensor& step,
    double lr,
    double beta1,
    double beta2,
    double eps,
    double weight_decay,
    bool adamw_variant) {
    TORCH_CHECK(params.is_cuda(), "params must be on the accelerator");
    TORCH_CHECK(params.is_contiguous() && grads.is_contiguous() && exp_avg.is_contiguous() && exp_avg_sq.is_contiguous(), "inputs must be contiguous");
    TORCH_CHECK(params.scalar_type() == torch::kFloat16 || params.scalar_type() == torch::kFloat32, "params must be float16 or float32");
    TORCH_CHECK(grads.scalar_type() == params.scalar_type() && exp_avg.scalar_type() == params.scalar_type() && exp_avg_sq.scalar_type() == params.scalar_type(), "state dtypes must match params");
    TORCH_CHECK(grads.sizes() == params.sizes() && exp_avg.sizes() == params.sizes() && exp_avg_sq.sizes() == params.sizes(), "input shapes must match");
    TORCH_CHECK(step.is_cuda() && step.is_contiguous() && step.scalar_type() == torch::kFloat32 && step.numel() == 1, "step must be a CUDA float32 scalar");

    auto out = torch::empty_like(params);
    const int threads = 256;
    const int blocks = static_cast<int>(std::min<int64_t>((params.numel() + threads - 1) / threads, 512));
    auto stream = c10::hip::getCurrentHIPStream(params.device().index()).stream();

    AT_DISPATCH_FLOATING_TYPES_AND_HALF(params.scalar_type(), "fused_adamw_hip", [&] {
        hipLaunchKernelGGL(
            (fused_adamw_kernel<scalar_t>),
            dim3(blocks), dim3(threads), 0, stream,
            params.data_ptr<scalar_t>(),
            grads.data_ptr<scalar_t>(),
            exp_avg.data_ptr<scalar_t>(),
            exp_avg_sq.data_ptr<scalar_t>(),
            step.data_ptr<float>(),
            out.data_ptr<scalar_t>(),
            params.numel(),
            static_cast<float>(lr), static_cast<float>(beta1), static_cast<float>(beta2),
            static_cast<float>(eps), static_cast<float>(weight_decay), adamw_variant);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Fused AdamW optimizer family: a single functional (out-of-place) parameter
    update for standard AdamW and for Transformer-schedule AdamW.

    (1) Operator semantics: the __init__ hyper-parameters lr, beta1, beta2, eps,
    weight_decay are construction constants, and `variant` selects one of two
    update paths. Let `step` be a 0-dimensional float32 scalar tensor (the
    current iteration count). The four state tensors params / grads / exp_avg /
    exp_avg_sq have the same shape and are element-wise aligned; the whole update
    is computed in float32 (inputs are promoted to float32 first):
        1) decoupled weight decay (the AdamW form, applied in both variants --
           equivalent to p = params - lr * weight_decay * params, not L2
           regularization):
               p = params * (1 - lr * weight_decay)
        2) first moment: m = beta1 * exp_avg + (1 - beta1) * grads
        3) second moment: v = beta2 * exp_avg_sq + (1 - beta2) * grads^2
        4) variant="adamw" (standard AdamW, bias correction ON):
               bc1 = 1 - beta1^step; bc2 = 1 - beta2^step
               out = p - lr * (m / bc1) / (sqrt(v / bc2) + eps)
           variant="transformer_adamw" (Transformer schedule, bias correction
           OFF -- the only difference between the two variants):
               out = p - lr * m / (sqrt(v) + eps)
    The two variants are line-by-line identical apart from bias correction; eps is
    added outside the sqrt (denom = sqrt(...) + eps); the power beta^step is a
    float32 scalar power.
    Boundary behaviour: at step=1, bc1 = 1 - beta1 and bc2 = 1 - beta2 take their
    minimum values (the standard AdamW path amplifies the most); for very large
    step the two variants converge numerically; exp_avg_sq is always
    non-negative (second-moment constraint, generated in [0, 0.5)) and
    denom >= eps guarantees no division by zero; this operator has no reduction
    and no indexing -- it is a pure element-wise map.

    (2) Input/output specification:
      - params / grads / exp_avg / exp_avg_sq: float32 or float16 tensors, all
        with the same shape (ndim 1-4, numel >= 1, including non-power-of-two and
        boundary sizes), contiguous;
      - step: a 0-dimensional float32 scalar tensor (numel == 1) whose value is a
        positive-integer-semantics step count (>= 1);
      - returns: the updated parameters, a new tensor with the same shape and
        dtype as params (single-tensor output, out-of-place; no input may be
        modified in place, and no state such as exp_avg / exp_avg_sq may be
        returned).

    (3) Implementation constraints (violations are scored as failures):
      - The core computation (decoupled weight decay, first/second moment update,
        bias-correction power, sqrt, element-wise update) must be completed with a
        HIP kernel inside the submitted file;
      - out-of-place: params / grads / exp_avg / exp_avg_sq must not be modified
        in place;
      - the __init__ and forward signatures of ModelNew must not be changed;
      - intermediate computation uses float32 (fp16 inputs are promoted to
        float32 as well), and the final result is cast back to the dtype of
        params;
      - step arrives as a 0-dimensional tensor and participates in the power
        operation as a scalar inside the kernel; it must not be materialized into
        a temporary tensor of the same shape as params.

    (4) Forbidden list and target hardware:
      - the whole torch.optim family is forbidden (torch.optim.AdamW / Adam /
        SGD / ... plus their _functional / _multi_tensor internal paths);
      - any fused-optimizer library and closed-source entry point is forbidden:
        apex / deepspeed / bitsandbytes / the fused_adam entry-point family /
        hipdnn / miopen;
      - completing this task via an ATen shortcut is forbidden: torch.addcdiv /
        torch.addcmul (including the .addcdiv / .addcdiv_ / .addcmul / .addcmul_
        tensor methods and in-place forms, which finish the parameter update or
        the moment update in a single call); the multi-tensor primitives
        torch._foreach_addcdiv / torch._foreach_addcmul are equally forbidden
        (including their in-place _ forms, which complete the core update step in
        a single call) (the final static audit does substring matching on code
        outside docstrings/comments);
      Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "adamw", lr: float = 1e-3, beta1: float = 0.9, beta2: float = 0.999, eps: float = 1e-8, weight_decay: float = 0.01):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("adamw", "transformer_adamw"), \
            "variant must be one of adamw / transformer_adamw"
        self.variant = variant
        self.lr = float(lr)
        self.beta1 = float(beta1)
        self.beta2 = float(beta2)
        self.eps = float(eps)
        self.weight_decay = float(weight_decay)
        # <<<END_IMPROVE>>>

    def forward(self, params, grads, exp_avg, exp_avg_sq, step):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().fused_adamw(
            params, grads, exp_avg, exp_avg_sq, step,
            self.lr, self.beta1, self.beta2, self.eps, self.weight_decay,
            self.variant == "adamw")
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
