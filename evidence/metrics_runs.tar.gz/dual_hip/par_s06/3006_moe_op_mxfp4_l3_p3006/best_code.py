import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_E2M1_TABLE = torch.tensor(
    [0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0,
     -0.0, -0.5, -1.0, -1.5, -2.0, -3.0, -4.0, -6.0],
    dtype=torch.float32,
)

def _dequant_mxfp4(codes, scales):
    """mxfp4 dequantization: (..., K//2) uint8 code words plus (..., K//32) uint8
    e8m0 block scales -> (..., K) float32. In every byte the low 4 bits are the
    even-index element and the high 4 bits the odd-index element;
    x[..., k] = e2m1(nibble) * 2^(scales[..., k // 32] - 127)."""
    lo = codes & 0xF
    hi = codes >> 4
    nib = torch.stack((lo, hi), dim=-1).flatten(-2)      # (..., K)
    x = _E2M1_TABLE.to(codes.device)[nib.long()]
    scale = torch.exp2(scales.to(torch.float32) - 127.0)
    return x * scale.repeat_interleave(32, dim=-1)

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3006_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor moe_mxfp4(torch::Tensor a, torch::Tensor sa, torch::Tensor b, torch::Tensor sb, torch::Tensor w, torch::Tensor ids);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_mxfp4", &moe_mxfp4);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

__device__ __forceinline__ float decode_scale(uint8_t s) {
    unsigned bits = s == 0 ? 0x00400000u : (unsigned(s) << 23);
    return __uint_as_float(bits);
}

__device__ __forceinline__ float decode4(unsigned x) {
    unsigned v = x & 7;
    float f = v < 4 ? 0.5f * v : (v == 4 ? 2.f : (v == 5 ? 3.f : (v == 6 ? 4.f : 6.f)));
    return (x & 8) ? -f : f;
}

// Sixteen lanes cooperate on each output, one byte per scale block per lane.
__global__ void moe_kernel(const uint8_t* __restrict__ a,
                           const uint8_t* __restrict__ sa,
                           const uint8_t* __restrict__ b,
                           const uint8_t* __restrict__ sb,
                           const float* __restrict__ w,
                           const int64_t* __restrict__ ids,
                           at::BFloat16* __restrict__ out,
                           int N, int H, int T, int64_t slots) {
    int lane = threadIdx.x & 15;
    int64_t index = (int64_t)blockIdx.x * 16 + threadIdx.x / 16;
    int64_t slot = index / N;
    int n = index % N;
    float sum = 0.f;
    if (slot < slots) {
        int64_t token = slot / T;
        int64_t row = ids[slot] * N + n;
        int blocks = H / 16;
        for (int g = 0; g < blocks; ++g) {
            float as = 0.f;
            float bs = 0.f;
            if (lane == 0) {
                as = decode_scale(sa[token * blocks + g]);
                bs = decode_scale(sb[row * blocks + g]);
            }
            as = __shfl(as, 0, 16);
            bs = __shfl(bs, 0, 16);
            unsigned av = a[token * H + g * 16 + lane];
            unsigned bv = b[row * H + g * 16 + lane];
            float al = decode4(av & 15) * as;
            float ah = decode4(av >> 4) * as;
            float bl = decode4(bv & 15) * bs;
            float bh = decode4(bv >> 4) * bs;
            sum = fmaf(al, bl, sum);
            sum = fmaf(ah, bh, sum);
        }
    }
    for (int d = 8; d; d >>= 1) sum += __shfl_down(sum, d, 16);
    if (slot < slots && lane == 0) out[index] = at::BFloat16(sum * w[slot]);
}

__global__ void moe_pair_kernel(const uint8_t* __restrict__ a,
                               const uint8_t* __restrict__ sa,
                               const uint8_t* __restrict__ b,
                               const uint8_t* __restrict__ sb,
                               const float* __restrict__ w,
                               const int64_t* __restrict__ ids,
                               at::BFloat16* __restrict__ out,
                               int N, int H, int T, int64_t slots) {
    int lane = threadIdx.x & 15;
    int pairs = (N + 1) / 2;
    int64_t work = (int64_t)blockIdx.x * (blockDim.x / 16) + threadIdx.x / 16;
    int64_t slot = work / pairs;
    int n0 = 2 * (work % pairs);
    int n1 = n0 + 1;
    float sum0 = 0.f, sum1 = 0.f;
    if (slot < slots) {
        int64_t token = slot / T;
        int64_t row0 = ids[slot] * N + n0;
        int64_t row1 = row0 + 1;
        int blocks = H / 16;
        int g = 0;
        for (; g + 1 < blocks; g += 2) {
            #pragma unroll 2
            for (int u = 0; u < 2; ++u) {
                int block = g + u;
                float as = decode_scale(sa[token * blocks + block]);
                unsigned av = a[token * H + block * 16 + lane];
                float al = decode4(av & 15) * as;
                float ah = decode4(av >> 4) * as;
                float bs0 = decode_scale(sb[row0 * blocks + block]);
                unsigned bv0 = b[row0 * H + block * 16 + lane];
                sum0 = fmaf(al, decode4(bv0 & 15) * bs0, sum0);
                sum0 = fmaf(ah, decode4(bv0 >> 4) * bs0, sum0);
                if (n1 < N) {
                    float bs1 = decode_scale(sb[row1 * blocks + block]);
                    unsigned bv1 = b[row1 * H + block * 16 + lane];
                    sum1 = fmaf(al, decode4(bv1 & 15) * bs1, sum1);
                    sum1 = fmaf(ah, decode4(bv1 >> 4) * bs1, sum1);
                }
            }
        }
        if (g < blocks) {
            float as = decode_scale(sa[token * blocks + g]);
            unsigned av = a[token * H + g * 16 + lane];
            float al = decode4(av & 15) * as;
            float ah = decode4(av >> 4) * as;
            float bs0 = decode_scale(sb[row0 * blocks + g]);
            unsigned bv0 = b[row0 * H + g * 16 + lane];
            sum0 = fmaf(al, decode4(bv0 & 15) * bs0, sum0);
            sum0 = fmaf(ah, decode4(bv0 >> 4) * bs0, sum0);
            if (n1 < N) {
                float bs1 = decode_scale(sb[row1 * blocks + g]);
                unsigned bv1 = b[row1 * H + g * 16 + lane];
                sum1 = fmaf(al, decode4(bv1 & 15) * bs1, sum1);
                sum1 = fmaf(ah, decode4(bv1 >> 4) * bs1, sum1);
            }
        }
    }
    for (int d = 8; d; d >>= 1) {
        sum0 += __shfl_down(sum0, d, 16);
        sum1 += __shfl_down(sum1, d, 16);
    }
    if (slot < slots && lane == 0) {
        float weight = w[slot];
        out[slot * N + n0] = at::BFloat16(sum0 * weight);
        if (n1 < N) out[slot * N + n1] = at::BFloat16(sum1 * weight);
    }
}

torch::Tensor moe_mxfp4(torch::Tensor a, torch::Tensor sa, torch::Tensor b, torch::Tensor sb, torch::Tensor w, torch::Tensor ids) {
    TORCH_CHECK(a.is_cuda() && sa.is_cuda() && b.is_cuda() && sb.is_cuda() && w.is_cuda() && ids.is_cuda(), "HIP tensors required");
    c10::cuda::CUDAGuard guard(a.device());
    TORCH_CHECK(sa.device() == a.device() && b.device() == a.device() && sb.device() == a.device() && w.device() == a.device() && ids.device() == a.device(), "device mismatch");
    TORCH_CHECK(a.scalar_type() == at::kByte && sa.scalar_type() == at::kByte && b.scalar_type() == at::kByte && sb.scalar_type() == at::kByte && w.scalar_type() == at::kFloat && ids.scalar_type() == at::kLong, "invalid input types");
    a = a.contiguous(); sa = sa.contiguous(); b = b.contiguous(); sb = sb.contiguous(); w = w.contiguous(); ids = ids.contiguous();
    int64_t M = a.size(0), H = a.size(1), N = b.size(1), T = ids.size(1);
    TORCH_CHECK(H % 16 == 0 && b.size(2) == H, "invalid K");
    auto out = torch::empty({M, T, N}, a.options().dtype(at::kBFloat16));
    int64_t count = M * T * N;
    if (count) {
        if (N >= 32) {
            int64_t pair_count = M * T * ((N + 1) / 2);
            hipLaunchKernelGGL(moe_pair_kernel, dim3((pair_count + 7) / 8), dim3(128), 0, at::cuda::getCurrentCUDAStream(), a.data_ptr<uint8_t>(), sa.data_ptr<uint8_t>(), b.data_ptr<uint8_t>(), sb.data_ptr<uint8_t>(), w.data_ptr<float>(), ids.data_ptr<int64_t>(), out.data_ptr<at::BFloat16>(), (int)N, (int)H, (int)T, M * T);
        } else {
            hipLaunchKernelGGL(moe_kernel, dim3((count + 15) / 16), dim3(256), 0, at::cuda::getCurrentCUDAStream(), a.data_ptr<uint8_t>(), sa.data_ptr<uint8_t>(), b.data_ptr<uint8_t>(), sb.data_ptr<uint8_t>(), w.data_ptr<float>(), ids.data_ptr<int64_t>(), out.data_ptr<at::BFloat16>(), (int)N, (int)H, (int)T, M * T);
        }
        auto err = hipGetLastError();
        TORCH_CHECK(err == hipSuccess, hipGetErrorString(err));
    }
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    MoE (Mixture of Experts) grouped GEMM: mxfp4 quantized activations x
    mxfp4 quantized expert weights.

    Routing is already done (topk_ids gives the experts selected for each
    token); this operator runs one GEMM per (token, selected expert) slot and
    multiplies by the routing weight (mul_routed_weight is always True):
      c[m, j, n] = topk_weights[m, j] * sum_k adeq[m, k] * bdeq[topk_ids[m, j], n, k]
    The sum runs along the K dimension, intermediate accumulation is float32 and
    the result is cast to bfloat16 for output.

    mxfp4 dequantization definition (the same for activation a and weight b):
      - every byte of the last dimension of the code word tensor holds 2 e2m1
        codes: the low 4 bits are the even-index element and the high 4 bits the
        odd-index element, i.e. the low/high nibble of code[..., i] correspond
        to elements 2i / 2i+1.
      - e2m1 nibble (4 bit) decoding: bit3 is the sign, the low 3 bits index the
        table {0: 0.0, 1: 0.5, 2: 1.0, 3: 1.5, 4: 2.0, 5: 3.0, 6: 4.0, 7: 6.0};
        a set sign bit negates the value (-0.0 takes part in the multiply-add as
        0).
      - e8m0 block scale: every 32 elements of the last dimension share 1 uint8
        scale byte s = scales[..., k // 32], decoded as 2^(s - 127).
      - dequantization:
        x[..., k] = e2m1(nibble(..., k)) * 2^(scales[..., k // 32] - 127).

    Input/output specification:
      a_q          (M, K//2)     uint8   activation code words (K is the logical
                                         feature dimension)
      a_scales     (M, K//32)    uint8   activation e8m0 block scales
      b_q          (E, N, K//2)  uint8   expert weight code words (E experts)
      b_scales     (E, N, K//32) uint8   expert weight e8m0 block scales
      topk_weights (M, top_k)    float16/bfloat16/float32  routing weights (>0)
      topk_ids     (M, top_k)    int64   selected expert ids, values in [0, E)
      out          (M, top_k, N) bfloat16
      Constraints: M >= 1, E >= 1, N >= 1, K % 32 == 0, 1 <= top_k <= E.
      Boundary behaviour: one expert may be selected by several tokens, and one
      token may select the same expert in several of its slots; every (m, j)
      slot is computed independently, with no reduction or weighted merge across
      experts and no dispatch-merge semantics (that belongs to a downstream
      operator).

    Implementation constraints (violations are scored as failures):
      - Core computation (nibble unpacking, e2m1/e8m0 decoding, the GEMM grouped
        by topk_ids, the routing weight multiply) must be done inside the
        submitted file; calling torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / F.linear / functional.linear /
        torch._scaled_mm is forbidden, as is using the built-in torch
        float4/mxfp4 representations and ready-made quantization conversion APIs
        (torch.float4_e2m1fn_x2, torch.quantize_per_tensor, etc.).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast to
        bfloat16.
      - The evaluator casts all inputs to fp32 before calling forward (uint8
        code words and scale bytes (0..255), int64 expert ids (small integers)
        are all exactly representable in fp32), so they must be restored
        losslessly at the entry point (.to(torch.uint8) / .to(torch.long)).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: MoE grouped GEMM of mxfp4 activations x mxfp4 weights plus the
    routing weight multiply; the token-expert alignment scheduling metadata
    (sorted_token_ids / expert_ids / num_tokens_post_padded) is an
    implementation detail and not part of the input contract.
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, a_q, a_scales, b_q, b_scales, topk_weights, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        a_q = a_q.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        a_scales = a_scales.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        b_q = b_q.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        b_scales = b_scales.to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        topk_weights = topk_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        M, Kh = a_q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        K = Kh * 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        E, N, _ = b_q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return _pyramidkernel_get_extension().moe_mxfp4(a_q, a_scales, b_q, b_scales, topk_weights, topk_ids)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        b = _dequant_mxfp4(b_q, b_scales)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        flat_ids = topk_ids.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        a_rep = a.unsqueeze(1).expand(M, top_k, K).reshape(-1, K)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        c = torch.empty((M * top_k, N), dtype=torch.float32, device=a_q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        for e in range(E):
            mask = flat_ids == e
            if mask.any():
                c[mask] = a_rep[mask] @ b[e].t()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        c *= topk_weights.reshape(-1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return c.reshape(M, top_k, N).to(torch.bfloat16)
        # <<<END_IMPROVE>>>
