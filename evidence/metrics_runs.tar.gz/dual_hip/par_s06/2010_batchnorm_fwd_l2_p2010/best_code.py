import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2010_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor batchnorm_forward(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, std::string, double, double);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("batchnorm_forward", &batchnorm_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

__device__ float block_sum(float v, float* sm) {
    if (blockDim.x < warpSize) {
        for (int d = blockDim.x / 2; d; d /= 2) v += __shfl_down(v, d, int(blockDim.x));
        return __shfl(v, 0, int(blockDim.x));
    }
    if (blockDim.x == warpSize) {
        for (int d = warpSize / 2; d; d /= 2) v += __shfl_down(v, d, warpSize);
        return __shfl(v, 0, warpSize);
    }
    int lane = threadIdx.x % warpSize;
    int wave = threadIdx.x / warpSize;
    for (int d = warpSize / 2; d; d /= 2) v += __shfl_down(v, d);
    if (lane == 0) sm[wave] = v;
    __syncthreads();
    if (wave == 0) {
        v = lane < (blockDim.x + warpSize - 1) / warpSize ? sm[lane] : 0.f;
        for (int d = warpSize / 2; d; d /= 2) v += __shfl_down(v, d);
        if (lane == 0) sm[0] = v;
    }
    __syncthreads();
    float result = sm[0];
    __syncthreads();
    return result;
}

struct WelfordState {
    float mean;
    float m2;
    float count;
};

__device__ __forceinline__ WelfordState welford_merge(WelfordState a, WelfordState b) {
    if (a.count == 0.f) return b;
    if (b.count == 0.f) return a;
    float n = a.count + b.count;
    float d = b.mean - a.mean;
    WelfordState r;
    r.count = n;
    r.mean = a.mean + d * (b.count / n);
    r.m2 = a.m2 + b.m2 + d * d * (a.count * b.count / n);
    return r;
}

__device__ __forceinline__ WelfordState wave_welford_reduce(WelfordState v) {
    for (int d = warpSize / 2; d; d >>= 1) {
        WelfordState q;
        q.mean = __shfl_down(v.mean, d, warpSize);
        q.m2 = __shfl_down(v.m2, d, warpSize);
        q.count = __shfl_down(v.count, d, warpSize);
        if ((threadIdx.x % warpSize) < d) v = welford_merge(v, q);
    }
    return v;
}

__device__ __forceinline__ WelfordState block_welford_reduce(WelfordState v, WelfordState* sh) {
    int lane = threadIdx.x % warpSize;
    int wave = threadIdx.x / warpSize;
    int nwaves = (blockDim.x + warpSize - 1) / warpSize;
    v = wave_welford_reduce(v);
    if (lane == 0) sh[wave] = v;
    __syncthreads();
    WelfordState result{0.f, 0.f, 0.f};
    if (wave == 0) {
        result = lane < nwaves ? sh[lane] : result;
        result = wave_welford_reduce(result);
        if (lane == 0) sh[0] = result;
    }
    __syncthreads();
    return sh[0];
}

__global__ void train_bn(const float* __restrict__ x, const float* __restrict__ s,
                         const float* __restrict__ b, const float* __restrict__ rm,
                         const float* __restrict__ rv, float* __restrict__ out,
                         int64_t C, int64_t S, int64_t M, float eps, float p) {
    int64_t c = blockIdx.x;
    __shared__ float sm[32];
    float sum = 0.f;
    for (int64_t r = threadIdx.x; r < M; r += blockDim.x) {
        int64_t i = (r / S * C + c) * S + r % S;
        sum += x[i];
    }
    float mean = block_sum(sum, sm) / float(M);
    float sq = 0.f;
    for (int64_t r = threadIdx.x; r < M; r += blockDim.x) {
        int64_t i = (r / S * C + c) * S + r % S;
        float d = x[i] - mean;
        sq += d * d;
    }
    float var = block_sum(sq, sm) / float(M);
    float inv = rsqrtf(var + eps);
    float scale = s[c], bias = b[c];
    for (int64_t r = threadIdx.x; r < M; r += blockDim.x) {
        int64_t i = (r / S * C + c) * S + r % S;
        float z = ((x[i] - mean) * inv) * scale;
        out[i] = __fadd_rn(z, bias);
    }
    if (threadIdx.x == 0) {
        int64_t base = C * M;
        out[base + c] = mean;
        out[base + C + c] = inv;
        out[base + 2 * C + c] = __fadd_rn((1.f - p) * rm[c], p * mean);
        out[base + 3 * C + c] = __fadd_rn((1.f - p) * rv[c], p * (var * (float(M) / float(M - 1))));
    }
}

__global__ void welford_partials(const float* __restrict__ x, float* __restrict__ scratch,
                                 int64_t C, int64_t S, int64_t M, int K) {
    int64_t c = blockIdx.x / K;
    int split = blockIdx.x % K;
    int64_t chunk = (M + K - 1) / K;
    int64_t begin = int64_t(split) * chunk;
    int64_t end = min(M, begin + chunk);
    WelfordState local{0.f, 0.f, 0.f};
    for (int64_t r = begin + threadIdx.x; r < end; r += blockDim.x) {
        int64_t i = (r / S * C + c) * S + r % S;
        WelfordState one{x[i], 0.f, 1.f};
        local = welford_merge(local, one);
    }
    __shared__ WelfordState sh[32];
    WelfordState total = block_welford_reduce(local, sh);
    if (threadIdx.x == 0) {
        int64_t q = (c * int64_t(K) + split) * 3;
        scratch[q] = total.mean;
        scratch[q + 1] = total.m2;
        scratch[q + 2] = total.count;
    }
}

__global__ void merge_bn_one_wave(const float* __restrict__ scratch, const float* __restrict__ s,
                                  const float* __restrict__ b, const float* __restrict__ rm,
                                  const float* __restrict__ rv, float* __restrict__ out,
                                  int64_t C, int64_t M, int K, float eps, float p) {
    int c = blockIdx.x;
    WelfordState local{0.f, 0.f, 0.f};
    for (int k = threadIdx.x; k < K; k += warpSize) {
        int64_t q = (int64_t(c) * K + k) * 3;
        WelfordState v{scratch[q], scratch[q + 1], scratch[q + 2]};
        local = welford_merge(local, v);
    }
    WelfordState total = wave_welford_reduce(local);
    if (threadIdx.x == 0) {
        float mean = total.mean;
        float var = total.m2 / float(M);
        float inv = rsqrtf(var + eps);
        int64_t base = C * M;
        out[base + c] = mean;
        out[base + C + c] = inv;
        out[base + 2 * C + c] = __fadd_rn((1.f - p) * rm[c], p * mean);
        out[base + 3 * C + c] = __fadd_rn((1.f - p) * rv[c], p * (var * (float(M) / float(M - 1))));
    }
}

__global__ void merge_bn(const float* __restrict__ scratch, const float* __restrict__ s,
                         const float* __restrict__ b, const float* __restrict__ rm,
                         const float* __restrict__ rv, float* __restrict__ out,
                         int64_t C, int64_t M, int K, float eps, float p) {
    int c = blockIdx.x;
    WelfordState local{0.f, 0.f, 0.f};
    for (int k = threadIdx.x; k < K; k += blockDim.x) {
        int64_t q = (int64_t(c) * K + k) * 3;
        WelfordState v{scratch[q], scratch[q + 1], scratch[q + 2]};
        local = welford_merge(local, v);
    }
    __shared__ WelfordState sh[32];
    WelfordState total = block_welford_reduce(local, sh);
    if (threadIdx.x == 0) {
        float mean = total.mean;
        float var = total.m2 / float(M);
        float inv = rsqrtf(var + eps);
        int64_t base = C * M;
        out[base + c] = mean;
        out[base + C + c] = inv;
        out[base + 2 * C + c] = __fadd_rn((1.f - p) * rm[c], p * mean);
        out[base + 3 * C + c] = __fadd_rn((1.f - p) * rv[c], p * (var * (float(M) / float(M - 1))));
    }
}

__global__ void affine_bn(const float* __restrict__ x, const float* __restrict__ s,
                          const float* __restrict__ b, const float* __restrict__ out_stats,
                          float* __restrict__ out, int64_t L, int64_t C, int64_t S,
                          int64_t M) {
    int64_t base = C * M;
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x; i < L;
         i += int64_t(blockDim.x) * gridDim.x) {
        int64_t c = (i / S) % C;
        float z = ((x[i] - out_stats[base + c]) * out_stats[base + C + c]) * s[c];
        out[i] = __fadd_rn(z, b[c]);
    }
}

template <class T>
__global__ void infer_bn(const T* __restrict__ x, const T* __restrict__ s,
                         const T* __restrict__ b, const T* __restrict__ mean,
                         const T* __restrict__ var, T* __restrict__ y, int64_t L,
                         int64_t C, int64_t S, float eps) {
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x; i < L;
         i += int64_t(blockDim.x) * gridDim.x) {
        int64_t c = (i / S) % C;
        float z = ((float(x[i]) - float(mean[c])) * rsqrtf(float(var[c]) + eps)) * float(s[c]);
        y[i] = T(__fadd_rn(z, float(b[c])));
    }
}

torch::Tensor batchnorm_forward(torch::Tensor x, torch::Tensor scale, torch::Tensor bias,
                                torch::Tensor mean, torch::Tensor variance,
                                std::string variant, double eps, double momentum) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous() && x.dim() == 4, "expected contiguous device NCHW input");
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = at::cuda::getCurrentCUDAStream();
    int64_t C = x.size(1), S = x.size(2) * x.size(3), M = x.size(0) * S;
    torch::Tensor out;
    if (variant == "training") {
        TORCH_CHECK(M >= 2, "training requires N*H*W >= 2");
        TORCH_CHECK(x.scalar_type() == at::kFloat, "training requires float32");
        out = torch::empty({x.numel() + 4 * C}, x.options().dtype(at::kFloat));
        if (M >= 16384 && C < 256) {
            int K = int((M + 4095) / 4096);
            if (K > 64) K = 64;
            auto scratch = torch::empty({C, K, 3}, x.options().dtype(at::kFloat));
            welford_partials<<<C * K, 256, 0, stream>>>(x.data_ptr<float>(), scratch.data_ptr<float>(), C, S, M, K);
            if (K <= warpSize) {
                merge_bn_one_wave<<<C, warpSize, 0, stream>>>(scratch.data_ptr<float>(), scale.data_ptr<float>(), bias.data_ptr<float>(), mean.data_ptr<float>(), variance.data_ptr<float>(), out.data_ptr<float>(), C, M, K, float(eps), float(momentum));
            } else {
                merge_bn<<<C, 256, 0, stream>>>(scratch.data_ptr<float>(), scale.data_ptr<float>(), bias.data_ptr<float>(), mean.data_ptr<float>(), variance.data_ptr<float>(), out.data_ptr<float>(), C, M, K, float(eps), float(momentum));
            }
            int blocks = int(std::min<int64_t>((x.numel() + 255) / 256, 65535));
            affine_bn<<<blocks, 256, 0, stream>>>(x.data_ptr<float>(), scale.data_ptr<float>(), bias.data_ptr<float>(), out.data_ptr<float>(), out.data_ptr<float>(), x.numel(), C, S, M);
        } else {
            int threads = 32;
            while (threads < M && threads < 256) threads *= 2;
            train_bn<<<C, threads, 0, stream>>>(x.data_ptr<float>(), scale.data_ptr<float>(), bias.data_ptr<float>(), mean.data_ptr<float>(), variance.data_ptr<float>(), out.data_ptr<float>(), C, S, M, float(eps), float(momentum));
        }
    } else {
        out = torch::empty_like(x);
        int blocks = int(std::min<int64_t>((x.numel() + 255) / 256, 65535));
        AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(), "infer_bn", [&] {
            infer_bn<scalar_t><<<blocks, 256, 0, stream>>>(x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), mean.data_ptr<scalar_t>(), variance.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), x.numel(), C, S, float(eps));
        });
    }
    TORCH_CHECK(hipGetLastError() == hipSuccess, "BatchNorm HIP launch failed");
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    BatchNorm forward family: inference affine (inference) and training batch
    statistics (training).

    The input is x (N, C, H, W), NCHW contiguous; scale / bias / mean / variance are
    all (1, C, 1, 1) and broadcast along the channel dimension. Reduction dimension:
    per-channel, computing the statistics of every channel c over the three
    dimensions (N, H, W), with m = N*H*W elements per channel. The __init__ argument
    variant selects one of two paths (eps defaults to 1e-5 and momentum to 0.1; both
    are scalar hyper-parameters only):

        "inference": the mean and the variance are given as inputs, element-wise
                     affine (float32 intermediate computation):
            y = scale * (x - mean) / sqrt(variance + eps) + bias
        "training": batch statistics + affine + running update (float32
                    throughout):
            batch_mean_c = sum_{n,h,w} x[n,c,h,w] / m                    (biased batch mean)
            batch_var_c  = sum_{n,h,w} (x[n,c,h,w] - batch_mean_c)^2 / m (biased batch variance)
            saved_mean         = batch_mean                              (shape (1,C,1,1))
            saved_inv_variance = 1 / sqrt(batch_var + eps)               (shape (1,C,1,1))
            y = scale * (x - saved_mean) * saved_inv_variance + bias
            next_running_mean = (1 - momentum) * mean + momentum * batch_mean
            next_running_var  = (1 - momentum) * variance
                                + momentum * batch_var * m / (m - 1)
            In the training variant the 4th/5th forward arguments are the running
            statistics of the previous step (prev_running_mean / prev_running_var);
            the running variance update uses the unbiased batch variance (the
            m/(m-1) correction, hence the requirement m >= 2) -- this is the
            standard PyTorch / cuDNN / MIOpen training-BN convention.

    The forward signature is (x, scale, bias, mean, variance) for both variants: in
    inference the 4th/5th arguments are the given mean / variance, in training they
    are prev_running_mean / prev_running_var.

    Single-tensor output protocol (forward must return a single tensor; the
    evaluator compares a single output):
        "inference": returns y itself, shape (N, C, H, W), same dtype as x;
        "training" : returns a one-dimensional float32 packed tensor of length
                     N*C*H*W + 4*C; the five logical outputs are each cast to
                     float32, reshaped with reshape(-1) and torch.cat'ed in the
                     sample-output order, with the segment protocol (half-open
                     intervals):
            [0,            N*C*H*W)      y
            [N*C*H*W,      N*C*H*W + C)  saved_mean
            [N*C*H*W + C,  N*C*H*W + 2C) saved_inv_variance
            [N*C*H*W + 2C, N*C*H*W + 3C) next_running_mean
            [N*C*H*W + 3C, N*C*H*W + 4C) next_running_var

    Input/output specification:
        x        float32 (always float32 for training) / float16 / bfloat16
                 (inference only), (N, C, H, W), contiguous, N/C/H/W >= 1
        scale    same dtype as x, (1, C, 1, 1), contiguous
        bias     same dtype as x, (1, C, 1, 1), contiguous
        mean     same dtype as x, (1, C, 1, 1), contiguous (inference: the given
                 mean, any real value; training: prev_running_mean)
        variance same dtype as x, (1, C, 1, 1), contiguous, always positive
                 (inference: the given variance; training: prev_running_var)
        out      inference: (N, C, H, W), same dtype as x; training: one-dimensional
                 float32 of length N*C*H*W + 4*C (the five-segment packing protocol
                 above)
        The inputs are the usual randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-channel reduction statistics, rsqrt, the
          affine, and the running update) must be completed inside the submitted
          file with a HIP kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, the normalization and the running update all use float32
          intermediates; the y of inference is cast back to the x dtype; all five
          training segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.BatchNorm1d / torch.nn.BatchNorm2d /
    torch.nn.BatchNorm3d / torch.nn.SyncBatchNorm /
    torch.nn.functional.batch_norm / torch.batch_norm /
    torch.native_batch_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "training", eps: float = 1e-5, momentum: float = 0.1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("inference", "training"), "variant must be one of inference / training"
        assert eps > 0, "eps must be positive"
        assert 0.0 <= momentum <= 1.0, "momentum must be in [0, 1]"
        self.variant = variant
        self.eps = float(eps)
        self.momentum = float(momentum)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias, mean, variance):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().batchnorm_forward(
            x, scale, bias, mean, variance, self.variant, self.eps, self.momentum
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        sf = scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        bf = bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        mf = mean.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        vf = variance.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        if self.variant == "inference":
            # element-wise affine with the given mean/variance; (1,C,1,1)
            # broadcasts along the channel dimension
            inv_std = torch.rsqrt(vf + eps)
            y = (xf - mf) * inv_std * sf + bf
            return y.to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        m = xf.shape[0] * xf.shape[2] * xf.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert m >= 2, "the training variant requires N*H*W >= 2 (the m/(m-1) unbiased correction factor of the running variance)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        batch_mean = xf.mean(dim=(0, 2, 3), keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        batch_var = ((xf - batch_mean) ** 2).mean(dim=(0, 2, 3), keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        saved_inv_variance = torch.rsqrt(batch_var + eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        y = (xf - batch_mean) * saved_inv_variance * sf + bf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        batch_var_unbiased = batch_var * (m / (m - 1))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        next_running_mean = (1.0 - self.momentum) * mf + self.momentum * batch_mean
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        next_running_var = (1.0 - self.momentum) * vf + self.momentum * batch_var_unbiased
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        return torch.cat([
            y.to(torch.float32).reshape(-1),
            batch_mean.to(torch.float32).reshape(-1),
            saved_inv_variance.to(torch.float32).reshape(-1),
            next_running_mean.to(torch.float32).reshape(-1),
            next_running_var.to(torch.float32).reshape(-1),
        ])
        # <<<END_IMPROVE>>>
