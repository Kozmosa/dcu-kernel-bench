import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1024_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void prefill_attention(torch::Tensor q, torch::Tensor k, torch::Tensor v, torch::Tensor starts, torch::Tensor lengths, torch::Tensor out, double scale, bool causal, int64_t max_len);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("prefill_attention", &prefill_attention);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

// General-dimension fallback.
template<class T, bool CAUSAL, int HEADS_PER_BLOCK>
__global__ void attention_kernel(const T* q, const T* k, const T* v,
    const int* starts, const int* lengths, T* out,
    int H, int HK, int D, int chunks, float scale, int total_tokens, int num_seqs) {
    extern __shared__ float shared[];
    int lane = threadIdx.x % warpSize;
    int wave = threadIdx.x / warpSize;
    int s = blockIdx.x;
    if (s >= total_tokens) return;
    int lo = 0, hi = num_seqs;
    while (lo + 1 < hi) {
        int mid = lo + (hi - lo) / 2;
        if (starts[mid] <= s) lo = mid;
        else hi = mid;
    }
    int h = HEADS_PER_BLOCK == 2 ? 2 * blockIdx.y + wave : blockIdx.y / chunks;
    int chunk = HEADS_PER_BLOCK == 2 ? 0 : blockIdx.y % chunks;
    int start = starts[lo], L = lengths[lo];
    int t = s - start;
    int g = h / (H / HK);
    bool valid = t < L;
    bool staged = D <= 256;
    float* sk = shared;
    float* sv = shared + 16 * D;
    float acc[8];
    #pragma unroll
    for (int a=0;a<8;++a) acc[a]=0.0f;
    float m = -INFINITY, den = 0.0f;
    int end = CAUSAL ? t+1 : L;
    for (int base=0;base<end;base+=16) {
        int count = min(16,end-base);
        if (staged) {
            for (int x=threadIdx.x;x<count*D;x+=blockDim.x) {
                int j=x/D, d=x%D;
                int64_t offset=(int64_t(start+base+j)*HK+g)*D+d;
                sk[x]=float(k[offset]);
                sv[x]=float(v[offset]);
            }
        }
        __syncthreads();
        if (valid) {
            for (int j=0;j<count;++j) {
                if (CAUSAL && base+j>t) break;
                float dot=0.0f;
                for (int d=lane;d<D;d+=warpSize) {
                    float kval=staged ? sk[j*D+d] : float(k[(int64_t(start+base+j)*HK+g)*D+d]);
                    dot += float(q[(int64_t(start+t)*H+h)*D+d])*kval;
                }
                for (int delta=warpSize/2;delta>0;delta/=2)
                    dot += __shfl_down(dot,delta,warpSize);
                dot=__shfl(dot,0,warpSize)*scale;
                float nm=fmaxf(m,dot);
                float alpha=expf(m-nm), p=expf(dot-nm);
                den=den*alpha+p;
                #pragma unroll
                for (int a=0;a<8;++a) {
                    int local=lane+a*warpSize;
                    int d=chunk*256+local;
                    if (local<256 && d<D) {
                        float vv=staged ? sv[j*D+d] : float(v[(int64_t(start+base+j)*HK+g)*D+d]);
                        acc[a]=acc[a]*alpha+p*vv;
                    }
                }
                m=nm;
            }
        }
        __syncthreads();
    }
    if (valid) {
        #pragma unroll
        for (int a=0;a<8;++a) {
            int local=lane+a*warpSize, d=chunk*256+local;
            if (local<256 && d<D)
                out[(int64_t(start+t)*H+h)*D+d]=T(acc[a]/den);
        }
    }
}

// Four independent online states, merged only after the KV traversal.
template<class T, bool CAUSAL, int W>
__global__ void split_attention(const T* q, const T* k, const T* v,
    const int* starts, const int* lengths, T* out,
    int H, int HK, int D, int B, float scale) {
    constexpr int N = (256 + W - 1) / W;
    extern __shared__ float shared[];
    float* maxima = shared + 4 * D;
    float* sums = maxima + 4;
    int lane = threadIdx.x % W;
    int wave = threadIdx.x / W;
    int s = blockIdx.x, h = blockIdx.y;
    int lo = 0, hi = B;
    while (lo + 1 < hi) {
        int mid = lo + (hi - lo) / 2;
        if (starts[mid] <= s) lo = mid;
        else hi = mid;
    }
    int start = starts[lo];
    int end = CAUSAL ? s - start + 1 : lengths[lo];
    int g = h / (H / HK);
    int64_t qb = (int64_t(s) * H + h) * D;
    float qr[N], acc[N];
    #pragma unroll
    for (int a = 0; a < N; ++a) {
        int d = lane + a * W;
        qr[a] = d < D ? float(q[qb + d]) : 0.0f;
        acc[a] = 0.0f;
    }
    float m = -INFINITY, den = 0.0f;
    for (int j = wave; j < end; j += 16) {
        bool valid1 = j + 4 < end;
        bool valid2 = j + 8 < end;
        bool valid3 = j + 12 < end;
        int64_t kb = (int64_t(start + j) * HK + g) * D;
        int64_t kb1 = (int64_t(start + j + 4) * HK + g) * D;
        int64_t kb2 = (int64_t(start + j + 8) * HK + g) * D;
        int64_t kb3 = (int64_t(start + j + 12) * HK + g) * D;
        float dot0 = 0.0f, dot1 = 0.0f, dot2 = 0.0f, dot3 = 0.0f;
        #pragma unroll
        for (int a = 0; a < N; ++a) {
            int d = lane + a * W;
            if (d < D) {
                dot0 += qr[a] * float(k[kb + d]);
                if (valid1) dot1 += qr[a] * float(k[kb1 + d]);
                if (valid2) dot2 += qr[a] * float(k[kb2 + d]);
                if (valid3) dot3 += qr[a] * float(k[kb3 + d]);
            }
        }
        #pragma unroll
        for (int delta = W / 2; delta > 0; delta /= 2) {
            dot0 += __shfl_xor(dot0, delta, W);
            dot1 += __shfl_xor(dot1, delta, W);
            dot2 += __shfl_xor(dot2, delta, W);
            dot3 += __shfl_xor(dot3, delta, W);
        }
        float score0 = dot0 * scale;
        float score1 = valid1 ? dot1 * scale : -INFINITY;
        float score2 = valid2 ? dot2 * scale : -INFINITY;
        float score3 = valid3 ? dot3 * scale : -INFINITY;
        float nm = fmaxf(m, fmaxf(fmaxf(score0, score1), fmaxf(score2, score3)));
        float alpha = expf(m - nm);
        float p0 = expf(score0 - nm);
        float p1 = valid1 ? expf(score1 - nm) : 0.0f;
        float p2 = valid2 ? expf(score2 - nm) : 0.0f;
        float p3 = valid3 ? expf(score3 - nm) : 0.0f;
        den = den * alpha + p0 + p1 + p2 + p3;
        #pragma unroll
        for (int a = 0; a < N; ++a) {
            int d = lane + a * W;
            if (d < D) {
                acc[a] = acc[a] * alpha + p0 * float(v[kb + d]);
                if (valid1) acc[a] += p1 * float(v[kb1 + d]);
                if (valid2) acc[a] += p2 * float(v[kb2 + d]);
                if (valid3) acc[a] += p3 * float(v[kb3 + d]);
            }
        }
        m = nm;
    }
    if (lane == 0) {
        maxima[wave] = m;
        sums[wave] = den;
    }
    #pragma unroll
    for (int a = 0; a < N; ++a) {
        int d = lane + a * W;
        if (d < D) shared[wave * D + d] = acc[a];
    }
    __syncthreads();
    if (wave == 0) {
        float M = fmaxf(fmaxf(maxima[0], maxima[1]), fmaxf(maxima[2], maxima[3]));
        float weights[4];
        float denom = 0.0f;
        #pragma unroll
        for (int w = 0; w < 4; ++w) {
            weights[w] = sums[w] > 0.0f ? expf(maxima[w] - M) : 0.0f;
            denom += weights[w] * sums[w];
        }
        #pragma unroll
        for (int a = 0; a < N; ++a) {
            int d = lane + a * W;
            if (d < D) {
                float value = 0.0f;
                #pragma unroll
                for (int w = 0; w < 4; ++w)
                    value += weights[w] * shared[w * D + d];
                out[qb + d] = T(value / denom);
            }
        }
    }
}

template<class T, bool C>
void launch_attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor starts, torch::Tensor lengths, torch::Tensor out,
    float scale, int wave, hipStream_t stream) {
    int D=q.size(2), H=q.size(1), HK=k.size(1);
    int chunks=(D+255)/256;
    if (D <= 256) {
        dim3 grid(q.size(0), H);
        size_t smem = (4 * D + 8) * sizeof(float);
        if (wave == 64) {
            split_attention<T,C,64><<<grid,4*wave,smem,stream>>>(q.data_ptr<T>(),k.data_ptr<T>(),v.data_ptr<T>(),starts.data_ptr<int>(),lengths.data_ptr<int>(),out.data_ptr<T>(),H,HK,D,lengths.numel(),scale);
        } else {
            split_attention<T,C,32><<<grid,4*wave,smem,stream>>>(q.data_ptr<T>(),k.data_ptr<T>(),v.data_ptr<T>(),starts.data_ptr<int>(),lengths.data_ptr<int>(),out.data_ptr<T>(),H,HK,D,lengths.numel(),scale);
        }
    } else {
        dim3 grid(q.size(0), H*chunks);
        attention_kernel<T,C,1><<<grid,wave,0,stream>>>(q.data_ptr<T>(),k.data_ptr<T>(),v.data_ptr<T>(),starts.data_ptr<int>(),lengths.data_ptr<int>(),out.data_ptr<T>(),H,HK,D,chunks,scale,q.size(0),lengths.numel());
    }
}

void prefill_attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor starts, torch::Tensor lengths, torch::Tensor out,
    double scale, bool causal, int64_t max_len) {
    c10::cuda::CUDAGuard guard(q.device());
    if (q.numel()==0) return;
    int device=q.get_device();
    hipDeviceProp_t prop;
    TORCH_CHECK(hipGetDeviceProperties(&prop,device)==hipSuccess,"device properties failed");
    auto stream=at::cuda::getCurrentCUDAStream(device);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, q.scalar_type(), "prefill_attention", [&] {
        if (causal)
            launch_attention<scalar_t,true>(q,k,v,starts,lengths,out,float(scale),prop.warpSize,stream);
        else
            launch_attention<scalar_t,false>(q,k,v,starts,lengths,out,float(scale),prop.warpSize,stream);
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Non-paged prefill self-attention over a ragged variable-length batch (contiguous KV, GQA, causal optional).

    Operator semantics: the tokens of num_seqs sequences in the batch are stored
    flattened in dimension 0 of q/k/v; sequence i occupies the row range
    [b_start_loc[i], b_start_loc[i] + b_seq_len[i]), and b_start_loc is the
    exclusive prefix sum of the sequence lengths (b_start_loc[0] = 0,
    b_start_loc[i+1] = b_start_loc[i] + b_seq_len[i]), with no padding; the
    q/k/v of each sequence are the query/key/value of the same token batch (self
    attention). For the h-th query head (its KV head is
    g = h // query_group_size, query_group_size = num_q_heads // num_kv_heads)
    and in-sequence relative position t of sequence i
    (0 <= t < L_i, L_i = b_seq_len[i], row index s = b_start_loc[i] + t):
      logits[j] = sm_scale * <q[s, h, :], k[b_start_loc[i]+j, g, :]>
                  (sm_scale defaults to 1 / sqrt(head_dim))
      with causal=True, positions j > t are set to -inf; with causal=False all j are visible
      p[j] = softmax_j(logits[j])
      out[s, h, :] = sum_{j=0}^{L_i-1} p[j] * v[b_start_loc[i]+j, g, :]
    The softmax uses a numerically stable online implementation, intermediate
    accumulation is in float32, and the output is cast back to the input dtype.
    Boundary behaviour: b_seq_len[i] >= 1 always holds, the softmax denominator
    is always positive and there is no fully masked row (under causal masking row
    t sees at least itself); sequences do not affect each other.

    Input/output specification (evaluation dtype is float16 / bfloat16, all
    tensors contiguous):
      q            eval dtype (total_tokens, num_q_heads, head_dim)
      k            eval dtype (total_tokens, num_kv_heads, head_dim)
      v            eval dtype (total_tokens, num_kv_heads, head_dim)
      b_start_loc  int32 (num_seqs) -- exclusive prefix sum of the sequence lengths
      b_seq_len    int32 (num_seqs) -- length of each sequence (>= 1, may all differ)
      returns out  eval dtype (total_tokens, num_q_heads, head_dim)
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (GQA; equality means MHA); Q/K/V share the same head dim and it is >= 16,
    non-power-of-2 is allowed (out-of-range channels must be masked to zero by
    head_dim); total_tokens = sum(b_seq_len).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.
      - The evaluator casts every input tensor to fp32 before calling forward;
        the prefix sum and the sequence lengths are small integers that fp32
        represents exactly, so .to(torch.int32) at the entry recovers them
        losslessly.
      - The maximum sequence length is not an input: an upper bound for the grid
        along the in-sequence position dimension can be derived inside forward
        from int(b_seq_len.max()), and the kernel masks out-of-range rows/columns
        per sequence using L_i.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: contiguous non-paged KV, ragged variable-length batch, GQA,
    causal/non-causal, fp16/bf16 non-quantized inputs; no paged KV cache, no
    prefix-pool indirect addressing, no custom mask, no sliding window, no
    attention sink, no dropout, no LSE output, no MLA absorb form -- those
    variants are left as separate follow-up tasks.
    """
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, b_start_loc, b_seq_len):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        b_start_loc = b_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        b_seq_len = b_seq_len.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        total, H_Q, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = k.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert k.shape[-1] == D and v.shape[-1] == D, "the Q/K/V head dims must be identical"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        scale = self.sm_scale if self.sm_scale is not None else 1.0 / math.sqrt(D)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        B = b_seq_len.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _pyramidkernel_get_extension().prefill_attention(
                    q, k, v, b_start_loc, b_seq_len, out, scale, self.causal, total
                )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
