import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor backward_direct(torch::Tensor dy, torch::Tensor weight, torch::Tensor x, bool dgrad, int64_t sh, int64_t sw, int64_t ph, int64_t pw, int64_t dh, int64_t dw);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("backward_direct", &backward_direct);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>

struct Params {
    int64_t N,C,H,W,K,R,S,OH,OW,sh,sw,ph,pw,dh,dw;
};

template<bool Unit>
__global__ void input_grad(const float* __restrict__ dy, const float* __restrict__ weight, float* __restrict__ out, Params p, int64_t count) {
    int64_t i=(int64_t)blockIdx.x*blockDim.x+threadIdx.x;
    if(i>=count) return;
    int64_t w=i%p.W, h=(i/p.W)%p.H, c=(i/(p.W*p.H))%p.C, n=i/(p.W*p.H*p.C);
    float acc=0.0f;
    for(int64_t k=0;k<p.K;++k) {
        for(int64_t r=0;r<p.R;++r) {
            int64_t ah=h+p.ph-r*(Unit?1:p.dh);
            if(ah<0) continue;
            if(!Unit && ah%p.sh) continue;
            int64_t oh=Unit?ah:ah/p.sh;
            if(oh<0 || oh>=p.OH) continue;
            for(int64_t s=0;s<p.S;++s) {
                int64_t aw=w+p.pw-s*(Unit?1:p.dw);
                if(aw<0) continue;
                if(!Unit && aw%p.sw) continue;
                int64_t ow=Unit?aw:aw/p.sw;
                if(ow<0 || ow>=p.OW) continue;
                acc=fmaf(dy[((n*p.K+k)*p.OH+oh)*p.OW+ow],weight[((k*p.C+c)*p.R+r)*p.S+s],acc);
            }
        }
    }
    out[i]=acc;
}

__global__ void input_grad_pointwise(const float* __restrict__ dy, const float* __restrict__ weight, float* __restrict__ out, Params p, int64_t count) {
    int64_t i=(int64_t)blockIdx.x*blockDim.x+threadIdx.x;
    if(i>=count) return;
    int64_t w=i%p.W, h=(i/p.W)%p.H, c=(i/(p.W*p.H))%p.C, n=i/(p.W*p.H*p.C);
    int64_t oh=h+p.ph, ow=w+p.pw;
    float acc=0.0f;
    if(oh>=0 && oh<p.OH && ow>=0 && ow<p.OW) {
        const float* dyp=dy+((n*p.K)*p.OH+oh)*p.OW+ow;
        for(int64_t k=0;k<p.K;++k)
            acc=fmaf(dyp[k*p.OH*p.OW],weight[k*p.C*p.R*p.S+c],acc);
    }
    out[i]=acc;
}

__global__ void input_grad_interior(const float* __restrict__ dy, const float* __restrict__ weight, float* __restrict__ out, Params p, int64_t count) {
    int64_t i=(int64_t)blockIdx.x*blockDim.x+threadIdx.x;
    if(i>=count) return;
    int64_t w=i%p.W, h=(i/p.W)%p.H, c=(i/(p.W*p.H))%p.C, n=i/(p.W*p.H*p.C);
    int64_t r0=h+p.ph-p.OH+1, r1=h+p.ph+1;
    int64_t s0=w+p.pw-p.OW+1, s1=w+p.pw+1;
    if(r0<0) r0=0;
    if(r1>p.R) r1=p.R;
    if(s0<0) s0=0;
    if(s1>p.S) s1=p.S;
    float acc=0.0f;
    if(r0>=r1 || s0>=s1) {
        out[i]=acc;
        return;
    }
    for(int64_t k=0;k<p.K;++k) {
        for(int64_t r=r0;r<r1;++r) {
            int64_t oh=h+p.ph-r;
            for(int64_t s=s0;s<s1;++s) {
                int64_t ow=w+p.pw-s;
                acc=fmaf(dy[((n*p.K+k)*p.OH+oh)*p.OW+ow],weight[((k*p.C+c)*p.R+r)*p.S+s],acc);
            }
        }
    }
    out[i]=acc;
}

__global__ void weight_grad(const float* __restrict__ dy, const float* __restrict__ x, float* __restrict__ out, Params p, int64_t count) {
    int64_t i=(int64_t)blockIdx.x*blockDim.x+threadIdx.x;
    if(i>=count) return;
    int64_t s=i%p.S, r=(i/p.S)%p.R, c=(i/(p.S*p.R))%p.C, k=i/(p.S*p.R*p.C);
    float acc=0.0f;
    for(int64_t n=0;n<p.N;++n) {
        for(int64_t oh=0;oh<p.OH;++oh) {
            int64_t ih=oh*p.sh-p.ph+r*p.dh;
            if(ih<0 || ih>=p.H) continue;
            for(int64_t ow=0;ow<p.OW;++ow) {
                int64_t iw=ow*p.sw-p.pw+s*p.dw;
                if(iw<0 || iw>=p.W) continue;
                acc=fmaf(x[((n*p.C+c)*p.H+ih)*p.W+iw],dy[((n*p.K+k)*p.OH+oh)*p.OW+ow],acc);
            }
        }
    }
    out[i]=acc;
}

torch::Tensor backward_direct(torch::Tensor dy, torch::Tensor weight, torch::Tensor x, bool dgrad, int64_t sh, int64_t sw, int64_t ph, int64_t pw, int64_t dh, int64_t dw) {
    c10::cuda::CUDAGuard guard(dy.device());
    Params p{x.size(0),x.size(1),x.size(2),x.size(3),weight.size(0),weight.size(2),weight.size(3),dy.size(2),dy.size(3),sh,sw,ph,pw,dh,dw};
    auto out=torch::empty(dgrad?x.sizes():weight.sizes(),dy.options());
    int64_t count=out.numel();
    dim3 block(256), grid((count+255)/256);
    auto stream=c10::cuda::getCurrentCUDAStream(dy.get_device()).stream();
    if(dgrad) {
        if(p.R==1 && p.S==1 && sh==1 && sw==1 && dh==1 && dw==1) {
            input_grad_pointwise<<<grid,block,0,stream>>>(dy.data_ptr<float>(),weight.data_ptr<float>(),out.data_ptr<float>(),p,count);
        } else if(sh==1 && sw==1 && dh==1 && dw==1 && p.R*p.S>1 && p.H*p.W>=64) {
            input_grad_interior<<<grid,block,0,stream>>>(dy.data_ptr<float>(),weight.data_ptr<float>(),out.data_ptr<float>(),p,count);
        } else if(sh==1 && sw==1 && dh==1 && dw==1) {
            input_grad<true><<<grid,block,0,stream>>>(dy.data_ptr<float>(),weight.data_ptr<float>(),out.data_ptr<float>(),p,count);
        } else {
            input_grad<false><<<grid,block,0,stream>>>(dy.data_ptr<float>(),weight.data_ptr<float>(),out.data_ptr<float>(),p,count);
        }
    } else {
        weight_grad<<<grid,block,0,stream>>>(dy.data_ptr<float>(),x.data_ptr<float>(),out.data_ptr<float>(),p,count);
    }
    auto err=hipGetLastError();
    TORCH_CHECK(err==hipSuccess,"HIP launch failed: ",hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Standard 2D convolution backward: gradient with respect to the input
    (dgrad) and gradient with respect to the weights (wgrad).

    Semantics (NCHW, groups=1, no bias, strictly consistent with the PyTorch
    forward conv2d):
        forward y = conv2d(x, weight, stride=(stride_h,stride_w),
                        padding=(pad_h,pad_w), dilation=(dil_h,dil_w)),
        output size
            out_h = floor((H + 2*pad_h - dil_h*(R-1) - 1) / stride_h) + 1
        (likewise for out_w); given the upstream gradient dy = dL/dy (shape
        (N, out_c, out_h, out_w)):
            dgrad: dx = dL/dx, shape (N, C, H, W)
            wgrad: dw = dL/dw, shape (out_c, C, R, S)
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns dx; the values of x do not take part in the output
                 here (shape convention only);
        "wgrad": returns dw; the values of weight do not take part in the
                 output here (shape convention only).
    forward(dy, weight, x) has a fixed three-input signature; the tensors mean:
        dy     (N, out_c, out_h, out_w)   upstream gradient, consumed by both
                                          directions
        weight (out_c, C, R, S)           convolution kernel (out_c output
                                          channels / C input channels)
        x      (N, C, H, W)               forward input
    forward returns the single tensor out -- both directions are inherently
    single-output, with no concatenation packing:
        dgrad -> (N, C, H, W); wgrad -> (out_c, C, R, S); dtype as the inputs
        (float32 for this task).

    Input/output specification:
        dy / weight / x are all float32, contiguous, NCHW layout; every
        dimension >= 1;
        R/S may be 1 (1x1 convolution); H/W may be 1, odd, non-power-of-two,
        not 16-aligned;
        stride/dilation >= 1, padding >= 0, padding follows the four-sided
        symmetric (pad_h, pad_w) semantics of the forward conv (asymmetric
        pre/post padding is outside the domain of this task); consistency
        constraint
            H + 2*pad_h >= dil_h*(R-1) + 1, W + 2*pad_w >= dil_w*(S-1) + 1,
        and the spatial size of dy must equal out_h/out_w from the forward
        formula.
        Input values are ordinary randn magnitude (no inf/NaN). The evaluator
        casts all inputs to fp32 before the call.

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a HIP kernel inside the
          submitted file: the scatter accumulation of dgrad (dy convolved back
          over the kernel window following stride/dilation) or the correlation
          accumulation of wgrad (summing the cross-correlation of x windows
          with dy); falling back to torch convolution or autograd is
          forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares a
          single output).
        - Numeric contract: float32 inputs are accumulated directly in float32,
          with no downcast to half precision.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.nn.functional.conv2d / F.conv2d / torch.conv2d /
    torch.nn.Conv2d / torch.nn.functional.conv_transpose2d /
    F.conv_transpose2d / torch.nn.ConvTranspose2d /
    torch.nn.grad.conv2d_input / torch.nn.grad.conv2d_weight /
    aten.conv2d / aten.convolution / aten._convolution /
    aten.conv_transpose2d / aten.convolution_backward (including every
    spelling such as torch.ops.aten.*, at::.*) / torch.autograd / .backward( /
    unfold / F.fold / torch.nn.functional.fold / im2col / col2im / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "dgrad", stride_h: int = 1, stride_w: int = 1, pad_h: int = 1, pad_w: int = 1, dil_h: int = 1, dil_w: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant
        self.stride_h, self.stride_w = int(stride_h), int(stride_w)
        self.pad_h, self.pad_w = int(pad_h), int(pad_w)
        self.dil_h, self.dil_w = int(dil_h), int(dil_w)
        # <<<END_IMPROVE>>>

    def forward(self, dy, weight, x):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().backward_direct(dy, weight, x, self.variant == "dgrad", self.stride_h, self.stride_w, self.pad_h, self.pad_w, self.dil_h, self.dil_w)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        return out
        # <<<END_IMPROVE>>>
