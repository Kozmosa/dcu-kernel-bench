import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1015_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void lean_attention_out(torch::Tensor q, torch::Tensor k, torch::Tensor v, torch::Tensor lens, torch::Tensor out, torch::Tensor causal, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("lean_attention_out", &lean_attention_out);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <assert.h>
#include <cmath>

struct Strides { int64_t x, y, z; };
static Strides strides(torch::Tensor t) { return {t.stride(0), t.stride(1), t.stride(2)}; }

template<class T, int D, int W, bool Packed=false>
__global__ void lean_kernel(const T* q,const T* k,const T* v,const int* lens,T* out,
                            int H,int Q,const int* causal_ptr,int causal_value,float scale,
                            Strides qs,Strides ks,Strides vs,Strides os,int64_t total_rows=0) {
    constexpr int S=Packed?D:W;
    int lane=threadIdx.x%S;
    int64_t flat_row=int64_t(blockIdx.x)*(int64_t(blockDim.x)/S)+threadIdx.x/S;
    if(flat_row>=total_rows) return;
    int row=flat_row/H,h=flat_row%H,b=row/Q,i=row%Q;
    bool causal=causal_ptr?(*causal_ptr!=0):(causal_value!=0);
    if(causal) assert(lens[b]==Q);
    int64_t start=0; for(int s=0;s<b;++s) start+=lens[s];
    int n=lens[b]; if(causal)n=min(n,i+1);
    constexpr int R=(D+S-1)/S;
    float qr[R],acc[R];
    #pragma unroll
    for(int r=0;r<R;++r){int d=lane+r*S;qr[r]=d<D?float(q[row*qs.x+h*qs.y+d*qs.z]):0.0f;acc[r]=0.0f;}
    float m=-INFINITY,denom=0.0f;
    for(int j=0;j<n;++j){
        float score=0.0f;
        #pragma unroll
        for(int r=0;r<R;++r){int d=lane+r*S;if(d<D)score+=qr[r]*float(k[(start+j)*ks.x+h*ks.y+d*ks.z]);}
        #pragma unroll
        for(int delta=S/2;delta>0;delta>>=1) score+=__shfl_xor(score,delta,S);
        score*=scale; float next=fmaxf(m,score),alpha=expf(m-next),beta=expf(score-next);
        denom=alpha*denom+beta;
        #pragma unroll
        for(int r=0;r<R;++r){int d=lane+r*S;if(d<D)acc[r]=alpha*acc[r]+beta*float(v[(start+j)*vs.x+h*vs.y+d*vs.z]);}
        m=next;
    }
    #pragma unroll
    for(int r=0;r<R;++r){int d=lane+r*S;if(d<D)out[row*os.x+h*os.y+d*os.z]=T(acc[r]/denom);}
}

template<class T,int D,int W>
__global__ void lean_decode_multi(const T* q,const T* k,const T* v,const int* lens,T* out,int H,
                                  const int* causal_ptr,int causal_value,float scale,
                                  Strides qs,Strides ks,Strides vs,Strides os){
    constexpr int NW=4,R=(D+W-1)/W;
    __shared__ float maxima[NW],sums[NW],numerators[NW][D];
    int lane=threadIdx.x%W,wave=threadIdx.x/W,b=blockIdx.x/H,h=blockIdx.x%H;
    bool causal=causal_ptr?(*causal_ptr!=0):(causal_value!=0);
    if(causal)assert(lens[b]==1);
    int64_t start=0;for(int s=0;s<b;++s)start+=lens[s];
    int n=lens[b];if(causal)n=min(n,1);int parts=n>=512?NW:1;
    float qr[R],acc[R];
    #pragma unroll
    for(int r=0;r<R;++r){int d=lane+r*W;qr[r]=d<D?float(q[b*qs.x+h*qs.y+d*qs.z]):0.0f;acc[r]=0.0f;}
    float m=-INFINITY,denom=0.0f;
    if(wave<parts)for(int j=wave;j<n;j+=parts){
        float score=0.0f;
        #pragma unroll
        for(int r=0;r<R;++r){int d=lane+r*W;if(d<D)score+=qr[r]*float(k[(start+j)*ks.x+h*ks.y+d*ks.z]);}
        #pragma unroll
        for(int delta=W/2;delta>0;delta>>=1)score+=__shfl_xor(score,delta,W);
        score*=scale;float next=fmaxf(m,score),alpha=expf(m-next),beta=expf(score-next);
        denom=alpha*denom+beta;
        #pragma unroll
        for(int r=0;r<R;++r){int d=lane+r*W;if(d<D)acc[r]=alpha*acc[r]+beta*float(v[(start+j)*vs.x+h*vs.y+d*vs.z]);}
        m=next;
    }
    if(lane==0){maxima[wave]=m;sums[wave]=denom;}
    #pragma unroll
    for(int r=0;r<R;++r){int d=lane+r*W;if(d<D)numerators[wave][d]=acc[r];}
    __syncthreads();
    if(wave==0){
        float common=maxima[0];for(int p=1;p<parts;++p)common=fmaxf(common,maxima[p]);
        float weights[NW],total=0.0f;
        for(int p=0;p<parts;++p){weights[p]=expf(maxima[p]-common);total+=weights[p]*sums[p];}
        #pragma unroll
        for(int r=0;r<R;++r){int d=lane+r*W;if(d<D){float value=0.0f;for(int p=0;p<parts;++p)value+=weights[p]*numerators[p][d];out[b*os.x+h*os.y+d*os.z]=T(value/total);}}
    }
}

template<class T,int W>
void launch_attention(torch::Tensor q,torch::Tensor k,torch::Tensor v,torch::Tensor lens,torch::Tensor out,
                      const int* causal_ptr,int causal_value,float scale,hipStream_t stream){
    int H=q.size(1),Q=q.size(0)/lens.numel();dim3 grid(q.size(0)*H);
    if(Q==1&&k.size(0)>=512*lens.numel()){
        #define DECODE(D) lean_decode_multi<T,D,W><<<grid,4*W,0,stream>>>(q.data_ptr<T>(),k.data_ptr<T>(),v.data_ptr<T>(),lens.data_ptr<int>(),out.data_ptr<T>(),H,causal_ptr,causal_value,scale,strides(q),strides(k),strides(v),strides(out))
        switch(q.size(2)){case 16:DECODE(16);break;case 32:DECODE(32);break;case 64:DECODE(64);break;case 128:DECODE(128);break;case 256:DECODE(256);break;default:TORCH_CHECK(false,"Unsupported head dimension");}
        #undef DECODE
        return;
    }
    int64_t total_rows=int64_t(q.size(0))*H;
    #define PACK(D) lean_kernel<T,D,W,true><<<dim3((total_rows+int64_t(4*W/D)-1)/int64_t(4*W/D)),4*W,0,stream>>>(q.data_ptr<T>(),k.data_ptr<T>(),v.data_ptr<T>(),lens.data_ptr<int>(),out.data_ptr<T>(),H,Q,causal_ptr,causal_value,scale,strides(q),strides(k),strides(v),strides(out),total_rows)
    if(q.size(2)==16){PACK(16);return;}if(q.size(2)==32){PACK(32);return;}
    #undef PACK
    #define RUN(D) lean_kernel<T,D,W><<<dim3((total_rows+3)/4),4*W,0,stream>>>(q.data_ptr<T>(),k.data_ptr<T>(),v.data_ptr<T>(),lens.data_ptr<int>(),out.data_ptr<T>(),H,Q,causal_ptr,causal_value,scale,strides(q),strides(k),strides(v),strides(out),total_rows)
    switch(q.size(2)){case 16:RUN(16);break;case 32:RUN(32);break;case 64:RUN(64);break;case 128:RUN(128);break;case 256:RUN(256);break;default:TORCH_CHECK(false,"Unsupported head dimension");}
    #undef RUN
}

void lean_attention_out(torch::Tensor q,torch::Tensor k,torch::Tensor v,torch::Tensor lens,torch::Tensor out,torch::Tensor causal,double scale){
    TORCH_CHECK(q.is_cuda()&&k.device()==q.device()&&v.device()==q.device()&&out.device()==q.device(),"Device mismatch");
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim()==3&&k.dim()==3&&v.dim()==3,"Expected rank three tensors");
    TORCH_CHECK(k.sizes()==v.sizes()&&out.sizes()==q.sizes(),"Shape mismatch");
    TORCH_CHECK(k.size(1)==q.size(1)&&k.size(2)==q.size(2),"Head shape mismatch");
    TORCH_CHECK(q.scalar_type()==k.scalar_type()&&q.scalar_type()==v.scalar_type()&&q.scalar_type()==out.scalar_type(),"Dtype mismatch");
    TORCH_CHECK(lens.numel()>0&&q.size(0)%lens.numel()==0&&q.size(0)>0,"Invalid batch");
    TORCH_CHECK(causal.numel()==1,"causal must be a scalar tensor");
    lens=lens.to(q.device(),torch::kInt32).contiguous();causal=causal.to(torch::kInt32).contiguous();
    const int* causal_ptr=nullptr;int causal_value=0;
    if(causal.device().is_cuda()){TORCH_CHECK(causal.device()==q.device(),"causal device mismatch");causal_ptr=causal.data_ptr<int>();}else causal_value=causal.item<int>();
    hipStream_t stream=at::cuda::getCurrentCUDAStream();int width=at::cuda::getCurrentDeviceProperties()->warpSize;
    TORCH_CHECK(width==32||width==64,"Unsupported wave width");
    if(q.scalar_type()==torch::kFloat16){if(width==64)launch_attention<at::Half,64>(q,k,v,lens,out,causal_ptr,causal_value,scale,stream);else launch_attention<at::Half,32>(q,k,v,lens,out,causal_ptr,causal_value,scale,stream);}
    else if(q.scalar_type()==torch::kBFloat16){if(width==64)launch_attention<at::BFloat16,64>(q,k,v,lens,out,causal_ptr,causal_value,scale,stream);else launch_attention<at::BFloat16,32>(q,k,v,lens,out,causal_ptr,causal_value,scale,stream);}
    else if(q.scalar_type()==torch::kFloat32){if(width==64)launch_attention<float,64>(q,k,v,lens,out,causal_ptr,causal_value,scale,stream);else launch_attention<float,32>(q,k,v,lens,out,causal_ptr,causal_value,scale,stream);}
    else TORCH_CHECK(false,"Expected fp16, bf16 or fp32");
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Attention forward pass over ragged batches with variable-length KV (Lean
    Attention semantics: contiguous, non-paged KV, softmax inside a single
    kernel), covering both decode (independent KV lengths per batch entry) and
    prefill (square causal self-attention) forms, with MHA (Q/K/V head counts
    equal).

    Mathematical definition: the batch holds num_seqs sequences, sequence b has an
    actually participating KV length kv_lens[b] (>= 1), and every query segment has
    the same length q_len (total_q = num_seqs * q_len, with q stored in
    sequence-major order). Let start_k = kv_lens[0] + ... + kv_lens[b-1] (k/v are
    likewise stored contiguously in sequence-major order). For every sequence b,
    head h, query position i (0 <= i < q_len) and KV position j
    (0 <= j < kv_lens[b]):
      scores[i, j] = sm_scale * <q[b*q_len+i, h, :], k[start_k+j, h, :]>
      with causal=1 (the task constrains kv_lens[b] == q_len for all b in this form)
      a square causal mask is applied: positions with j > i are set to -inf; with
      causal=0 no mask is applied;
      p[i, :] = softmax_j(scores[i, :])
      out[b*q_len+i, h, :] = sum_j p[i, j] * v[start_k+j, h, :]
    The softmax uses a numerically stable (online) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.
    Boundary behaviour: kv_lens[b] >= 1 always holds, so the softmax denominator is
    always positive and no row is fully masked; sequences do not affect each other;
    slots in k/v beyond each sequence's cumulative length boundary do not
    participate in the computation.

    Input/output specification:
      q        [num_seqs*q_len, num_heads, head_dim]  float16/bfloat16, sequence-major
      k, v     [total_kv, num_heads, head_dim]        same dtype as q, total_kv = sum(kv_lens)
      kv_lens  [num_seqs] int32 -- the KV length actually participating per sequence
      causal   0-dim int32 tensor, 1 = square causal mask, 0 = no mask
      out      [num_seqs*q_len, num_heads, head_dim]  same dtype as q
    Global constraints: Q/K/V head counts are equal (MHA, no GQA); head_dim in
    {16, 32, 64, 128, 256} and identical across Q/K/V; q_len >= 1; with causal=1,
    kv_lens[b] == q_len for all b.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: contiguous non-paged KV, variable-length ragged batch, MHA, both
    causal states, fp16/bf16 non-quantized inputs; no GQA, no dropout, no
    bias/ALiBi, no LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, kv_lens, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        kv_lens = kv_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        causal = causal.to(dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_heads = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        assert num_heads == k.shape[1] == v.shape[1], "MHA: Q/K/V must have the same number of heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_seqs = int(kv_lens.numel())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        q_len = q.shape[0] // num_seqs
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert q_len * num_seqs == q.shape[0], "total_q must be an integer multiple of num_seqs"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # The HIP kernel validates the square-causal length constraint on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        start_k = 0
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        _pyramidkernel_get_extension().lean_attention_out(q, k, v, kv_lens, out, causal, self.sm_scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
