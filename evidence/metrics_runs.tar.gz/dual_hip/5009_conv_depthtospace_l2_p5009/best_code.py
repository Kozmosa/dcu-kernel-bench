import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p5009_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor conv_dts(torch::Tensor x, torch::Tensor weight, torch::Tensor bias, int64_t bs, bool dcr);
torch::Tensor rearrange_dts(torch::Tensor x, int64_t bs, bool dcr);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("conv_dts", &conv_dts);
    m.def("rearrange_dts", &rearrange_dts);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <algorithm>
#include <type_traits>

// Each tile is shared by two four-channel output groups.
template<typename T>
__global__ void lds_dts_kernel(const T* __restrict__ x,
                               const T* __restrict__ weight,
                               const T* __restrict__ bias,
                               T* __restrict__ out,
                               int64_t tiles, int64_t I, int64_t K,
                               int64_t H, int64_t W) {
    __shared__ float tile[6 * 34];
    const int tid = threadIdx.x;
    const int ly = (tid % 128) / 32;
    const int lx = tid % 32;
    const int64_t C = K / 4;
    const int64_t nx = (W + 31) / 32;
    const int64_t ny = (H + 3) / 4;
    const int64_t pairs = (C + 1) / 2;
    for (int64_t block = blockIdx.x; block < tiles; block += gridDim.x) {
        int64_t tx = block % nx;
        int64_t ty = (block / nx) % ny;
        int64_t pair = (block / (nx * ny)) % pairs;
        int64_t n = block / (nx * ny * pairs);
        int64_t c = pair * 2 + tid / 128;
        int64_t k = c * 4;
        int64_t h = ty * 4 + ly;
        int64_t w = tx * 32 + lx;
        bool valid = c < C && h < H && w < W;
        float acc0 = 0.0f, acc1 = 0.0f, acc2 = 0.0f, acc3 = 0.0f;
        for (int64_t ci = 0; ci < I; ++ci) {
            for (int j = tid; j < 6 * 34; j += 256) {
                int64_t ih = ty * 4 + j / 34 - 1;
                int64_t iw = tx * 32 + j % 34 - 1;
                tile[j] = ih >= 0 && ih < H && iw >= 0 && iw < W
                    ? static_cast<float>(x[((n * I + ci) * H + ih) * W + iw]) : 0.0f;
            }
            __syncthreads();
            if (valid) {
                #pragma unroll
                for (int kh = 0; kh < 3; ++kh) {
                    #pragma unroll
                    for (int kw = 0; kw < 3; ++kw) {
                        float a = tile[(ly + kh) * 34 + lx + kw];
                        int64_t wi = (k * I + ci) * 9 + kh * 3 + kw;
                        acc0 = fmaf(a, static_cast<float>(weight[wi]), acc0);
                        acc1 = fmaf(a, static_cast<float>(weight[wi + I * 9]), acc1);
                        acc2 = fmaf(a, static_cast<float>(weight[wi + I * 18]), acc2);
                        acc3 = fmaf(a, static_cast<float>(weight[wi + I * 27]), acc3);
                    }
                }
            }
            __syncthreads();
        }
        if (valid) {
            acc0 += static_cast<float>(bias[k]);
            acc1 += static_cast<float>(bias[k + 1]);
            acc2 += static_cast<float>(bias[k + 2]);
            acc3 += static_cast<float>(bias[k + 3]);
            int64_t oi = ((n * C + c) * (H * 2) + h * 2) * (W * 2) + w * 2;
            if constexpr (std::is_same<T, float>::value) {
                *reinterpret_cast<float2*>(out + oi) = make_float2(acc0, acc1);
                *reinterpret_cast<float2*>(out + oi + W * 2) = make_float2(acc2, acc3);
            } else {
                out[oi] = static_cast<T>(acc0);
                out[oi + 1] = static_cast<T>(acc1);
                out[oi + W * 2] = static_cast<T>(acc2);
                out[oi + W * 2 + 1] = static_cast<T>(acc3);
            }
        }
    }
}

// Convolution threads traverse source spatial positions; rearrangement
// threads traverse final output positions. Both write the final tensor.
template<typename T, int BS, bool DCR, bool CONV>
__global__ void fused_dts_kernel(const T* __restrict__ x,
                                 const T* __restrict__ weight,
                                 const T* __restrict__ bias,
                                 T* __restrict__ out,
                                 int64_t total, int64_t I, int64_t K,
                                 int64_t H, int64_t W) {
    const int64_t C = K / (BS * BS);
    if (CONV && !DCR && BS == 2) {
        for (int64_t index = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
             index < total / 4; index += int64_t(blockDim.x) * gridDim.x) {
            int64_t w = index % W;
            int64_t h = (index / W) % H;
            int64_t c = (index / (H * W)) % C;
            int64_t n = index / (C * H * W);
            int64_t k = 4 * c;
            float acc0 = 0.0f, acc1 = 0.0f, acc2 = 0.0f, acc3 = 0.0f;
            for (int64_t ci = 0; ci < I; ++ci) {
                #pragma unroll
                for (int kh = 0; kh < 3; ++kh) {
                    int64_t ih = h + kh - 1;
                    #pragma unroll
                    for (int kw = 0; kw < 3; ++kw) {
                        int64_t iw = w + kw - 1;
                        if (ih >= 0 && ih < H && iw >= 0 && iw < W) {
                            float a = static_cast<float>(x[((n * I + ci) * H + ih) * W + iw]);
                            int64_t wi = (k * I + ci) * 9 + kh * 3 + kw;
                            acc0 = fmaf(a, static_cast<float>(weight[wi]), acc0);
                            acc1 = fmaf(a, static_cast<float>(weight[wi + I * 9]), acc1);
                            acc2 = fmaf(a, static_cast<float>(weight[wi + I * 18]), acc2);
                            acc3 = fmaf(a, static_cast<float>(weight[wi + I * 27]), acc3);
                        }
                    }
                }
            }
            acc0 += static_cast<float>(bias[k]);
            acc1 += static_cast<float>(bias[k + 1]);
            acc2 += static_cast<float>(bias[k + 2]);
            acc3 += static_cast<float>(bias[k + 3]);
            int64_t oi = ((n * C + c) * (H * 2) + h * 2) * (W * 2) + w * 2;
            if constexpr (std::is_same<T, float>::value) {
                *reinterpret_cast<float2*>(out + oi) = make_float2(acc0, acc1);
                *reinterpret_cast<float2*>(out + oi + W * 2) = make_float2(acc2, acc3);
            } else {
                out[oi] = static_cast<T>(acc0);
                out[oi + 1] = static_cast<T>(acc1);
                out[oi + W * 2] = static_cast<T>(acc2);
                out[oi + W * 2 + 1] = static_cast<T>(acc3);
            }
        }
        return;
    }
    for (int64_t index = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         index < total; index += int64_t(blockDim.x) * gridDim.x) {
        if (CONV) {
            int64_t w = index % W;
            int64_t h = (index / W) % H;
            int64_t k = (index / (H * W)) % K;
            int64_t n = index / (K * H * W);
            float acc = 0.0f;
            for (int64_t ci = 0; ci < I; ++ci) {
                #pragma unroll
                for (int kh = 0; kh < 3; ++kh) {
                    int64_t ih = h + kh - 1;
                    #pragma unroll
                    for (int kw = 0; kw < 3; ++kw) {
                        int64_t iw = w + kw - 1;
                        if (ih >= 0 && ih < H && iw >= 0 && iw < W) {
                            float a = static_cast<float>(x[((n * I + ci) * H + ih) * W + iw]);
                            float b = static_cast<float>(weight[(k * I + ci) * 9 + kh * 3 + kw]);
                            acc = fmaf(a, b, acc);
                        }
                    }
                }
            }
            acc += static_cast<float>(bias[k]);
            int64_t c = DCR ? k % C : k / (BS * BS);
            int64_t sub = DCR ? k / C : k % (BS * BS);
            int64_t oi = ((n * C + c) * (H * BS) + h * BS + sub / BS) * (W * BS) + w * BS + sub % BS;
            out[oi] = static_cast<T>(acc);
        } else {
            int64_t ow = index % (W * BS);
            int64_t oh = (index / (W * BS)) % (H * BS);
            int64_t c = (index / (W * H * BS * BS)) % C;
            int64_t n = index / (K * H * W);
            int64_t sub = (oh % BS) * BS + ow % BS;
            int64_t k = DCR ? sub * C + c : c * BS * BS + sub;
            float value = static_cast<float>(x[((n * K + k) * H + oh / BS) * W + ow / BS]);
            out[index] = static_cast<T>(value);
        }
    }
}

template<typename T, bool CONV, int BS>
void launch_mapping(const T* x, const T* w, const T* b, T* out,
                    int64_t total, int64_t I, int64_t K, int64_t H, int64_t W,
                    bool dcr, hipStream_t stream) {
    if (CONV && BS == 2 && !dcr && K >= 8 && W >= 32 && H >= 4 && total / 4 >= 8192) {
        int64_t N = total / (K * H * W);
        int64_t tiles = N * ((K / 4 + 1) / 2) * ((H + 3) / 4) * ((W + 31) / 32);
        unsigned blocks = static_cast<unsigned>(std::min<int64_t>(tiles, 65535));
        lds_dts_kernel<T><<<blocks, 256, 0, stream>>>(x, w, b, out, tiles, I, K, H, W);
        return;
    }
    unsigned blocks = static_cast<unsigned>(std::min<int64_t>((total + 255) / 256, 65535));
    if (dcr) {
        fused_dts_kernel<T, BS, true, CONV><<<blocks, 256, 0, stream>>>(x, w, b, out, total, I, K, H, W);
    } else {
        fused_dts_kernel<T, BS, false, CONV><<<blocks, 256, 0, stream>>>(x, w, b, out, total, I, K, H, W);
    }
}

template<bool CONV>
torch::Tensor run_dts(torch::Tensor x, torch::Tensor weight, torch::Tensor bias,
                      int64_t bs, bool dcr) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous() && x.dim() == 4, "Expected contiguous device NCHW input");
    TORCH_CHECK(bs >= 2 && bs <= 4, "Invalid block size");
    c10::cuda::CUDAGuard guard(x.device());
    int64_t N = x.size(0), I = x.size(1), H = x.size(2), W = x.size(3);
    int64_t K = I;
    if (CONV) {
        TORCH_CHECK(weight.is_cuda() && bias.is_cuda() && weight.device() == x.device() && bias.device() == x.device(), "Device mismatch");
        TORCH_CHECK(weight.is_contiguous() && bias.is_contiguous() && weight.scalar_type() == x.scalar_type() && bias.scalar_type() == x.scalar_type(), "Invalid parameters");
        TORCH_CHECK(weight.dim() == 4 && weight.size(1) == I && weight.size(2) == 3 && weight.size(3) == 3, "Expected 3x3 weights");
        K = weight.size(0);
        TORCH_CHECK(bias.numel() == K, "Invalid bias size");
    }
    TORCH_CHECK(K % (bs * bs) == 0, "Invalid channel count");
    auto out = torch::empty({N, K / (bs * bs), H * bs, W * bs}, x.options());
    int64_t total = out.numel();
    if (!total) return out;
    hipStream_t stream = c10::cuda::getCurrentCUDAStream(x.get_device()).stream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(), "fused_dts", [&] {
        const scalar_t* wp = CONV ? weight.data_ptr<scalar_t>() : nullptr;
        const scalar_t* bp = CONV ? bias.data_ptr<scalar_t>() : nullptr;
        const scalar_t* xp = x.data_ptr<scalar_t>();
        scalar_t* op = out.data_ptr<scalar_t>();
        switch (bs) {
            case 2: launch_mapping<scalar_t, CONV, 2>(xp, wp, bp, op, total, I, K, H, W, dcr, stream); break;
            case 3: launch_mapping<scalar_t, CONV, 3>(xp, wp, bp, op, total, I, K, H, W, dcr, stream); break;
            case 4: launch_mapping<scalar_t, CONV, 4>(xp, wp, bp, op, total, I, K, H, W, dcr, stream); break;
        }
    });
    hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess, "HIP launch failed: ", hipGetErrorString(error));
    return out;
}

torch::Tensor conv_dts(torch::Tensor x, torch::Tensor weight, torch::Tensor bias, int64_t bs, bool dcr) {
    return run_dts<true>(x, weight, bias, bs, dcr);
}

torch::Tensor rearrange_dts(torch::Tensor x, int64_t bs, bool dcr) {
    return run_dts<false>(x, torch::Tensor(), torch::Tensor(), bs, dcr);
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Conv+Bias+DepthToSpace fusion (conv_bias_dts) and pure DepthToSpace
    pixel rearrangement (dts) forward family.

    DepthToSpace (D2S) rearranges the channel dimension of an (N, K, H, W)
    feature map into the spatial dimensions: K must be divisible by
    block_size^2; writing C = K // block_size^2, the output is
    (N, C, H*bs, W*bs) (bs = block_size). The rearrangement mode is selected
    between two by the __init__ parameter mode, defined in terms of a
    six-dimensional view + transpose + reshape of v = (N, K, H, W):
        "CRD": v.reshape(N, C, bs, bs, H, W).permute(0, 1, 4, 2, 5, 3)
                .reshape(N, C, H*bs, W*bs)
                (bit-for-bit equivalent to
                torch.nn.functional.pixel_shuffle(v, bs) -- that ATen primitive
                is on the forbidden list; the equivalence is only noted here and
                it must not be called directly)
        "DCR": v.reshape(N, bs, bs, C, H, W).permute(0, 3, 4, 1, 5, 2)
                .reshape(N, C, H*bs, W*bs)
    Both modes produce the same output shape; only the channel-to-spatial-block
    mapping differs. Element-wise formula:
        out[b, c, h*bs + r, w*bs + d] = v[b, idx(c, r, d), h, w]
        CRD: idx = c*bs^2 + r*bs + d; DCR: idx = (r*bs + d)*C + c
        (c in [0, C), r/d in [0, bs), h in [0, H), w in [0, W))

    The fused path is selected between two by the __init__ parameter variant:
        "conv_bias_dts": for x (N, C_in, H, W) and the kernel weight
            (K, C_in, 3, 3), run the 2D cross-correlation forward pass (the
            deep-learning-library conv_fprop convention, not the kernel-flipped
            mathematical convolution), add the per-channel bias bias
            (1, K, 1, 1) (broadcast along the batch and spatial dimensions),
            then apply the D2S above to the convolution result. The convolution
            hyper-parameters are fixed: stride=(1, 1), symmetric zero
            padding=(1, 1) (1 added on each of the top/bottom/left/right sides;
            the padding value is always zero), dilation=(1, 1), so the
            convolution output keeps the spatial size (H, W) and the final
            output is (N, K//bs^2, H*bs, W*bs). forward(x, weight, bias) uses all
            three parameters.
        "dts": pure data rearrangement without convolution (super-resolution /
            pixel-rearrangement scenario): x itself is the (N, K, H, W) feature
            map to rearrange, forward(x) is called with a single parameter, and
            weight/bias are not passed (the optional parameters default to None;
            even if they are passed they must not affect the output); the
            rearrangement is pure index movement and bit-for-bit lossless.
    The convolution dot-product accumulation and the bias addition are computed
    in float32 intermediate precision throughout (the dts branch likewise
    promotes to float32 losslessly before the rearrangement), and the output is
    cast back to the dtype of x exactly once.

    Input/output specification:
        x      float16 / bfloat16 / float32 4D contiguous;
               (N, C_in, H, W) with C_in >= 1 for
               variant="conv_bias_dts", (N, K, H, W) with K % bs^2 == 0 for
               variant="dts"
        weight same dtype as x (K, C_in, 3, 3), contiguous (conv_bias_dts only)
        bias   same dtype as x (1, K, 1, 1), contiguous (conv_bias_dts only)
        out    a single tensor, same dtype as x (N, K//bs^2, H*bs, W*bs) (both
               the convolution and D2S are inherently single-output, so there
               are no multi-output packing segments)
        N/K/H/W >= 1 (non-powers-of-two, primes and boundary values are
        allowed, including N=1 and H=W=1); K % block_size^2 == 0; block_size in
        {2, 3, 4}; mode in {"CRD", "DCR"};
        inputs are ordinary randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before the call (fp16/bf16 -> fp32 is lossless; the
        output dtype of this task always matches the dtype of the passed x).

    Implementation constraints (violations are scored as failures):
        - The core computation (the padding-aware index/mask expansion and the
          dot-product accumulation, the bias addition, the six-dimensional
          rearrangement index mapping) must all be done and fused with a HIP
          kernel inside the submitted file; it is forbidden to replace it with
          any form of library convolution, ATen GEMM
          (matmul/mm/bmm/addmm/baddbmm/einsum/tensordot/unfold/fold/linear
          etc.), pixel_shuffle-family primitives (including a pixel_unshuffle
          round trip), or one-step equivalent routes such as a conv3d depth-axis
          unsqueeze or a conv_transpose2d kernel-flip rewrite.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The convolution dot-product accumulation and the bias addition are
          computed in float32 and the output is cast back to the input dtype
          exactly once (do not accumulate in fp16/bf16 low precision, and do not
          make repeated round-trip casts); padding must be handled inside the
          kernel with boundary masks/indices -- do not materialize a padded copy
          on the host side in place of in-kernel handling.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.nn.Conv2d / torch.nn.functional.conv2d / F.conv2d /
    torch.conv2d / aten.conv2d / aten.convolution /
    torch.nn.functional.conv3d / torch.conv3d / torch.nn.Conv3d /
    torch.nn.functional.conv_transpose2d / torch.conv_transpose2d /
    torch.nn.ConvTranspose2d /
    torch.nn.functional.unfold / torch.nn.Unfold / .unfold( /
    torch.nn.functional.fold / torch.nn.Fold / .fold( /
    torch.nn.functional.pixel_shuffle / torch.pixel_shuffle / pixel_shuffle /
    torch.nn.PixelShuffle / PixelShuffle /
    torch.nn.functional.pixel_unshuffle / torch.pixel_unshuffle /
    pixel_unshuffle / torch.nn.PixelUnshuffle / PixelUnshuffle /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear /
    miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    _STRIDE = (1, 1)
    _PADDING = (1, 1)
    _DILATION = (1, 1)
    def __init__(self, variant: str = "conv_bias_dts", mode: str = "CRD", block_size: int = 2):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("conv_bias_dts", "dts"), \
            "variant must be either conv_bias_dts or dts"
        assert mode in ("CRD", "DCR"), "mode must be either CRD or DCR"
        assert block_size in (2, 3, 4), "block_size must be 2 / 3 / 4"
        self.variant = variant
        self.mode = mode
        self.block_size = block_size
        # <<<END_IMPROVE>>>

    def forward(self, x, weight=None, bias=None):
        # <<<IMPROVE:forward_stmt_1>>>
        ext = _pyramidkernel_get_extension()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        if self.variant == "conv_bias_dts":
            return ext.conv_dts(x, weight, bias, self.block_size, self.mode == "DCR")
        return ext.rearrange_dts(x, self.block_size, self.mode == "DCR")
        # <<<END_IMPROVE>>>

    def _depth_to_space(self, v):
        """Six-dimensional view + transpose + reshape: a pure index
        rearrangement (no numeric operations) matching mode/block_size one to
        one; the per-dimension permutation corresponds exactly to the fused
        graph's first reshape -> transpose -> second reshape."""
        bs = self.block_size
        n, k, h, w = v.shape
        c = k // (bs * bs)
        if self.mode == "CRD":
            t = v.reshape(n, c, bs, bs, h, w).permute(0, 1, 4, 2, 5, 3)
        else:   # DCR
            t = v.reshape(n, bs, bs, c, h, w).permute(0, 3, 4, 1, 5, 2)
        return t.reshape(n, c, h * bs, w * bs)
