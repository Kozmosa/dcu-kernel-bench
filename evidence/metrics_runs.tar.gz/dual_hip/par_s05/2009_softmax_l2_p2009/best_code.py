import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2009_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor row_softmax(torch::Tensor x);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("row_softmax", &row_softmax);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cmath>

template <typename scalar_t, int BLOCK_SIZE>
__global__ void row_softmax_kernel(const scalar_t* x, scalar_t* y, int64_t n) {
    extern __shared__ float scratch[];
    const int t = threadIdx.x;
    const int64_t base = int64_t(blockIdx.x) * n;
    float vmax = -INFINITY;
    for (int64_t j = t; j < n; j += BLOCK_SIZE) {
        vmax = fmaxf(vmax, float(x[base + j]));
    }
    const int lane = t % warpSize;
    const int wave = t / warpSize;
    for (int step = warpSize / 2; step > 0; step >>= 1) {
        vmax = fmaxf(vmax, __shfl_down(vmax, step, warpSize));
    }
    if (lane == 0) {
        scratch[wave] = vmax;
    }
    __syncthreads();
    if (wave == 0) {
        float block_max = lane < BLOCK_SIZE / warpSize ? scratch[lane] : -INFINITY;
        for (int step = warpSize / 2; step > 0; step >>= 1) {
            block_max = fmaxf(block_max, __shfl_down(block_max, step, warpSize));
        }
        if (lane == 0) {
            scratch[0] = block_max;
        }
    }
    __syncthreads();
    const float row_max = scratch[0];
    __syncthreads();
    float sum = 0.0f;
    for (int64_t j = t; j < n; j += BLOCK_SIZE) {
        sum += expf(float(x[base + j]) - row_max);
    }
    for (int step = warpSize / 2; step > 0; step >>= 1) {
        sum += __shfl_down(sum, step, warpSize);
    }
    if (lane == 0) {
        scratch[wave] = sum;
    }
    __syncthreads();
    if (wave == 0) {
        float block_sum = lane < BLOCK_SIZE / warpSize ? scratch[lane] : 0.0f;
        for (int step = warpSize / 2; step > 0; step >>= 1) {
            block_sum += __shfl_down(block_sum, step, warpSize);
        }
        if (lane == 0) {
            scratch[0] = block_sum;
        }
    }
    __syncthreads();
    const float inv = 1.0f / scratch[0];
    for (int64_t j = t; j < n; j += BLOCK_SIZE) {
        y[base + j] = scalar_t(expf(float(x[base + j]) - row_max) * inv);
    }
}

torch::Tensor row_softmax(torch::Tensor x) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous() && x.dim() == 2,
                "Expected a contiguous GPU matrix");
    TORCH_CHECK(x.size(0) > 0 && x.size(1) > 0, "Expected positive dimensions");
    c10::cuda::CUDAGuard guard(x.device());
    auto y = torch::empty_like(x);
    const int64_t n = x.size(1);
    auto stream = at::cuda::getCurrentCUDAStream();
    const int wave_size = at::cuda::getCurrentDeviceProperties()->warpSize;
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  x.scalar_type(), "row_softmax", [&] {
        if (n <= 512) {
            hipLaunchKernelGGL((row_softmax_kernel<scalar_t, 128>), dim3(x.size(0)),
                               dim3(128), (128 / wave_size) * sizeof(float), stream.stream(),
                               x.data_ptr<scalar_t>(), y.data_ptr<scalar_t>(), n);
        } else if (n <= 4096) {
            hipLaunchKernelGGL((row_softmax_kernel<scalar_t, 256>), dim3(x.size(0)),
                               dim3(256), (256 / wave_size) * sizeof(float), stream.stream(),
                               x.data_ptr<scalar_t>(), y.data_ptr<scalar_t>(), n);
        } else {
            hipLaunchKernelGGL((row_softmax_kernel<scalar_t, 512>), dim3(x.size(0)),
                               dim3(512), (512 / wave_size) * sizeof(float), stream.stream(),
                               x.data_ptr<scalar_t>(), y.data_ptr<scalar_t>(), n);
        }
    });
    const hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "row_softmax launch failed: ", hipGetErrorString(err));
    return y;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    2D row-wise softmax.

    For each row (the last dimension) of an (M, N) input, independently:
        m[i]     = max_j x[i, j]
        z[i, j]  = exp(x[i, j] - m[i])
        y[i, j]  = z[i, j] / sum_j z[i, j]
    Rows are completely independent, and after per-row normalization the elements
    of every row sum to 1. The reference implementation does max / exp / sum
    entirely in float32 and casts the output back to the input dtype.

    Boundary behaviour: N is any positive integer -- when N=1 the row's output is
    always 1; non-power-of-two N and very long rows (longer than a single block's
    capacity) must still give exact results, and out-of-range elements at the row
    tail must not participate in the max and sum reductions; the inputs are
    ordinary randn magnitude (no inf/NaN).

    Input/output specification:
        x   float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        y   same dtype as x, (M, N), the row-wise softmax result
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless); this operator has no integer tensor
        input, so nothing needs restoring.

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-row max reduction, the exp sum reduction,
          and the element-wise normalization) must be completed with a Triton
          kernel inside the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Intermediates (max / sum / exp) are computed in float32; the output is
          cast back to the input dtype.

    Forbidden list: aiter / torch.softmax / torch.nn.functional.softmax /
    torch.nn.Softmax / torch.log_softmax / torch.nn.functional.log_softmax /
    torch.nn.LogSoftmax / torch.special.softmax / torch.special.log_softmax.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        ext = _pyramidkernel_get_extension()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        y = ext.row_softmax(x)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Row maximum is computed in the extension.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # Exponentials are computed in float32 in the extension.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # Row normalization is fused into the kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        return y
        # <<<END_IMPROVE>>>
