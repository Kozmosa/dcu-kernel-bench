import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1014_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void hstu_forward(torch::Tensor q, torch::Tensor k, torch::Tensor v, torch::Tensor offsets, torch::Tensor targets, torch::Tensor out, int64_t N, double alpha, bool causal, int64_t A, int64_t c);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("hstu_forward", &hstu_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>

struct Strides { int64_t x, h, d; };

template<class T, int QD = 0>
__global__ void hstu_kernel(const T* q, const T* k, const T* v,
                            const int64_t* offsets, const int32_t* targets, T* out,
                            int N, int H, int D, int V, float alpha, bool causal, int A, int c,
                            Strides qs, Strides ks, Strides vs, Strides os) {
    int i = blockIdx.x % N;
    int h = (blockIdx.x / N) % H;
    int b = blockIdx.x / (N * H);
    int64_t s = offsets[b];
    int L = offsets[b + 1] - s;
    if (i >= L) return;
    int t = threadIdx.x, lane = t % 64, group = t / 64;
    extern __shared__ float shared[];
    float* w = shared;
    int cap = (c > 0 ? L - c + 1 : L) - targets[b];
    int mi = min(c > 0 ? max(i - c + 1, 0) : i, cap);
    int key_end = (causal && c == 0) ? min(L, i + 1) : L;
    for (int base = 0; base < key_end; base += 4) {
        int j = base + group;
        int mj = min(c > 0 ? max(j - c + 1, 0) : j, cap);
        int dist = mi - mj;
        if (!causal) dist = abs(dist);
        bool valid = (i == j || dist > 0);
        if (A > 0) valid = valid && dist <= A;
        if (c > 0) valid = valid || (mi == 0 && mj < cap);
        valid = valid && j < key_end;
        float dot = 0.0f;
        if (valid) {
            if constexpr (QD > 0) {
                #pragma unroll
                for (int d = lane; d < QD; d += 64) {
                    dot += float(q[(s+i)*qs.x+h*qs.h+d*qs.d]) * float(k[(s+j)*ks.x+h*ks.h+d*ks.d]);
                }
            } else {
                for (int d = lane; d < D; d += 64) {
                    dot += float(q[(s+i)*qs.x+h*qs.h+d*qs.d]) * float(k[(s+j)*ks.x+h*ks.h+d*ks.d]);
                }
            }
        }
        for (int step = 32; step; step >>= 1) {
            dot += __shfl_down(dot, step, 64);
        }
        if (lane == 0 && j < key_end) {
            float x = dot * alpha;
            w[j] = valid ? (x / (1.0f + expf(-x))) / float(N) : 0.0f;
        }
    }
    __syncthreads();
    for (int d = t; d < V; d += 256) {
        float acc = 0.0f;
        for (int j = 0; j < key_end; ++j)
            acc += w[j] * float(v[(s+j)*vs.x+h*vs.h+d*vs.d]);
        out[(s+i)*os.x+h*os.h+d*os.d] = T(acc);
    }
}

void hstu_forward(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                  torch::Tensor offsets, torch::Tensor targets, torch::Tensor out,
                  int64_t N, double alpha, bool causal, int64_t A, int64_t c) {
    c10::cuda::CUDAGuard guard(q.device());
    if (out.numel() == 0) return;
    offsets = offsets.to(q.device()).contiguous();
    targets = targets.to(q.device()).contiguous();
    Strides qs{q.stride(0),q.stride(1),q.stride(2)};
    Strides ks{k.stride(0),k.stride(1),k.stride(2)};
    Strides vs{v.stride(0),v.stride(1),v.stride(2)};
    Strides os{out.stride(0),out.stride(1),out.stride(2)};
    int H = q.size(1), D = q.size(2), V = v.size(2);
    int64_t blocks = (offsets.numel()-1)*H*N;
    auto stream = c10::cuda::getCurrentCUDAStream(q.get_device());
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, q.scalar_type(), "hstu_forward", [&] {
        if (D == 64) {
            hstu_kernel<scalar_t,64><<<blocks, 256, N*sizeof(float), stream.stream()>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                offsets.data_ptr<int64_t>(), targets.data_ptr<int32_t>(), out.data_ptr<scalar_t>(),
                N, H, D, V, float(alpha), causal, A, c, qs, ks, vs, os);
        } else if (D == 128) {
            hstu_kernel<scalar_t,128><<<blocks, 256, N*sizeof(float), stream.stream()>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                offsets.data_ptr<int64_t>(), targets.data_ptr<int32_t>(), out.data_ptr<scalar_t>(),
                N, H, D, V, float(alpha), causal, A, c, qs, ks, vs, os);
        } else if (D == 256) {
            hstu_kernel<scalar_t,256><<<blocks, 256, N*sizeof(float), stream.stream()>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                offsets.data_ptr<int64_t>(), targets.data_ptr<int32_t>(), out.data_ptr<scalar_t>(),
                N, H, D, V, float(alpha), causal, A, c, qs, ks, vs, os);
        } else {
            hstu_kernel<scalar_t,0><<<blocks, 256, N*sizeof(float), stream.stream()>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                offsets.data_ptr<int64_t>(), targets.data_ptr<int32_t>(), out.data_ptr<scalar_t>(),
                N, H, D, V, float(alpha), causal, A, c, qs, ks, vs, os);
        }
    });
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "HSTU launch failed: ", hipGetErrorString(err));
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    HSTU attention forward (the attention of the generative-recommendation HSTU unit, no softmax / no normalization):
    dense Q/K/V are split by seq_offsets into batch variable-length sequences,
    and each sequence computes independently
    out = (valid * SiLU(alpha*Q*K^T) / N) * V, where N = max_seq_len.

    Mathematical definition (sequence b: s = seq_offsets[b],
    L = seq_offsets[b+1] - seq_offsets[b], g = num_targets[b],
    c = contextual_seq_len, A = max_attn_len; when c = 0, M = L and r[i] = i;
    when c > 0, M = L - c + 1 and r[i] = max(i - c + 1, 0)):
      position renumbering m[i] = min(r[i], M - g)
      d[i,j] = m[i] - m[j]; when causal = False, d[i,j] = abs(d[i,j])
      valid[i,j] = (i == j) or d[i,j] > 0
      when A > 0, valid[i,j] additionally requires d[i,j] <= A
      when c > 0, valid[i,j] is additionally relaxed to true when m[i] == 0 and
      m[j] < M - g
      out[s+i, h, :] = sum_j valid[i,j] * SiLU(alpha*<q[s+i,h,:], k[s+j,h,:]>) / N
                       * v[s+j,h,:]
    where SiLU(x) = x*sigmoid(x). When causal = True, valid is lower triangular
    (including the diagonal); the weights get no softmax and no sum
    normalization, and masked positions contribute exactly 0.
    Boundary behaviour: the last g tokens of a sequence are targets and are
    excluded from the key side by the renumbering truncation; g = 0 is equivalent
    to no target exclusion; when c > 0 the first c tokens (renumbered m = 0)
    additionally see all non-target keys (including each other); an empty
    sequence (L = 0) is legal and produces no output rows; a sequence may be
    shorter than N, and the scaling denominator is always N (not that sequence's
    own length).

    Input/output specification:
      q            [total, num_heads, qk_dim]   float16 / bfloat16
      k            [total, num_heads, qk_dim]   same dtype as q
      v            [total, num_heads, v_dim]    same dtype as q; v_dim may differ from qk_dim
      seq_offsets  [batch + 1] int64, monotonically non-decreasing, first element 0, last element total
      num_targets  [batch] int32, 0 <= num_targets[b] and c + num_targets[b] <= L_b
      out          [total, num_heads, v_dim], same dtype as v
    Global-domain constraints: 0 <= L_b <= max_seq_len; qk_dim / v_dim are powers
    of 2 (of order 64..256).

    Hyper-parameters (__init__): max_seq_len (scaling denominator and upper bound
    on length, N); alpha (logits scale, defaults to 1/sqrt(qk_dim)); causal
    (defaults to True); max_attn_len (defaults to 0 = distance not limited);
    contextual_seq_len (defaults to 0 = disabled).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / SiLU / mask / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / torch.matmul / torch.bmm / torch.einsum / torch.softmax /
        torch.nn.functional.silu and their alias forms (F.silu / F.softmax /
        torch.mm / the @ matrix-multiply operator) is forbidden (implement SiLU
        yourself as x*sigmoid(x)).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to v's
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: forward only, non-quantized inputs, no dropout, no
    backpropagation.
    """
    def __init__(self, max_seq_len: int, alpha=None, causal=True, max_attn_len=0, contextual_seq_len=0):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.max_seq_len = int(max_seq_len)
        self.alpha = float(alpha) if alpha is not None else None
        self.causal = bool(causal)
        self.max_attn_len = int(max_attn_len)
        self.contextual_seq_len = int(contextual_seq_len)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, seq_offsets, num_targets):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        seq_offsets = seq_offsets.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        num_targets = num_targets.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B = int(seq_offsets.numel()) - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        alpha = self.alpha if self.alpha is not None else 1.0 / math.sqrt(q.shape[2])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = self.max_seq_len
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        c = self.contextual_seq_len
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        out = torch.empty_like(v)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        _pyramidkernel_get_extension().hstu_forward(q, k, v, seq_offsets, num_targets, out, N, alpha, self.causal, self.max_attn_len, c)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        return out
        # <<<END_IMPROVE>>>
