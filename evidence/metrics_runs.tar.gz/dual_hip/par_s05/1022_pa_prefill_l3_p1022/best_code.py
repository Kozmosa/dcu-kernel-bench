import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1022_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void pa_prefill(torch::Tensor q, torch::Tensor k, torch::Tensor v, torch::Tensor kc, torch::Tensor vc, torch::Tensor bt, torch::Tensor starts, torch::Tensor lens, c10::optional<torch::Tensor> slopes, torch::Tensor out, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pa_prefill", &pa_prefill);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

template<class T, bool Registers>
__global__ void paged_online(const T* q, const T* k, const T* v,
                            const T* kc, const T* vc, const int* bt,
                            const int* starts, const int* lens,
                            const float* slopes, T* out,
                            int H, int HK, int D, int BS, int X, int NB, int B,
                            float scale, int64_t os0, int64_t os1, int64_t os2) {
    int t = blockIdx.x / H, h = blockIdx.x % H;
    int lane = threadIdx.x;
    int lo = 0, hi = B;
    while (lo + 1 < hi) {
        int mid = (lo + hi) / 2;
        if (starts[mid] <= t) lo = mid; else hi = mid;
    }
    int b = lo, start = starts[b];
    int ctx = lens[b] - (starts[b+1] - start);
    int pos = ctx + t - start;
    int kh = h / (H / HK);
    extern __shared__ float sm[];
    float* qs = sm;
    float* acc = sm + D;
    float q0 = 0.f, q1 = 0.f, a0 = 0.f, a1 = 0.f;
    int key_off0 = 0, key_off1 = 0;
    if constexpr (Registers) {
        q0 = float(q[((int64_t)t * H + h) * D + lane]);
        q1 = float(q[((int64_t)t * H + h) * D + lane + 64]);
        key_off0 = (lane >> 3) * BS * 8 + (lane & 7);
        int lane1 = lane + 64;
        key_off1 = (lane1 >> 3) * BS * 8 + (lane1 & 7);
    } else {
        for (int d = lane; d < D; d += 64) {
            qs[d] = float(q[((int64_t)t * H + h) * D + d]);
            acc[d] = 0.f;
        }
    }
    float m = -INFINITY, z = 0.f;
    float slope = slopes ? slopes[h] : 0.f;
    int scalar_begin = 0;
    if constexpr (Registers) {
        int cached_page_begin = -1, cached_page_end = -1;
        int64_t cached_cachebase = 0;
        for (; scalar_begin + 3 <= pos; scalar_begin += 4) {
            float scores[4], vals0[4], vals1[4];
            if (scalar_begin >= ctx) {
                int64_t newbase = ((int64_t)(start + scalar_begin - ctx) * HK + kh) * D;
                int64_t token_stride = (int64_t)HK * D;
                #pragma unroll
                for (int i = 0; i < 4; ++i) {
                    float k0 = float(k[newbase + i * token_stride + lane]);
                    float k1 = float(k[newbase + i * token_stride + lane + 64]);
                    scores[i] = q0 * k0 + q1 * k1;
                    vals0[i] = float(v[newbase + i * token_stride + lane]);
                    vals1[i] = float(v[newbase + i * token_stride + lane + 64]);
                }
            } else {
                if (scalar_begin < cached_page_begin || scalar_begin >= cached_page_end) {
                    int logical_page = scalar_begin / BS;
                    cached_page_begin = logical_page * BS;
                    cached_page_end = cached_page_begin + BS;
                    int physical = bt[(int64_t)b * NB + logical_page];
                    cached_cachebase = ((int64_t)physical * HK + kh) * D * BS;
                }
                int first_slot = scalar_begin - cached_page_begin;
                bool same_page_prefix = (scalar_begin + 4 <= ctx) && (scalar_begin + 4 <= cached_page_end);
                if (same_page_prefix) {
                    int64_t cachebase = cached_cachebase;
                    #pragma unroll
                    for (int i = 0; i < 4; ++i) {
                        int slot = first_slot + i;
                        float k0 = float(kc[cachebase + key_off0 + slot * 8]);
                        float k1 = float(kc[cachebase + key_off1 + slot * 8]);
                        scores[i] = q0 * k0 + q1 * k1;
                        vals0[i] = float(vc[cachebase + lane * BS + slot]);
                        vals1[i] = float(vc[cachebase + (lane + 64) * BS + slot]);
                    }
                } else {
                    #pragma unroll
                    for (int i = 0; i < 4; ++i) {
                        int l = scalar_begin + i;
                        bool prefix = l < ctx;
                        int physical = prefix ? bt[(int64_t)b * NB + l / BS] : 0;
                        int slot = l % BS;
                        int64_t cachebase = ((int64_t)physical * HK + kh) * D * BS;
                        int64_t newbase = ((int64_t)(start + l - ctx) * HK + kh) * D;
                        float k0 = prefix ? float(kc[cachebase + key_off0 + slot * 8]) : float(k[newbase + lane]);
                        float k1 = prefix ? float(kc[cachebase + key_off1 + slot * 8]) : float(k[newbase + lane + 64]);
                        scores[i] = q0 * k0 + q1 * k1;
                        vals0[i] = prefix ? float(vc[cachebase + lane * BS + slot]) : float(v[newbase + lane]);
                        vals1[i] = prefix ? float(vc[cachebase + (lane + 64) * BS + slot]) : float(v[newbase + lane + 64]);
                    }
                }
            }
            #pragma unroll
            for (int delta = 32; delta; delta >>= 1) {
                #pragma unroll
                for (int i = 0; i < 4; ++i)
                    scores[i] += __shfl_xor(scores[i], delta, 64);
            }
            float next = m;
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                scores[i] = scores[i] * scale + slope * (scalar_begin + i - pos);
                next = fmaxf(next, scores[i]);
            }
            float alpha = expf(m - next);
            z *= alpha;
            a0 *= alpha;
            a1 *= alpha;
            #pragma unroll
            for (int i = 0; i < 4; ++i) {
                float beta = expf(scores[i] - next);
                z += beta;
                a0 += beta * vals0[i];
                a1 += beta * vals1[i];
            }
            m = next;
        }
    }
    for (int l = scalar_begin; l <= pos; ++l) {
        bool prefix = l < ctx;
        int physical = prefix ? bt[(int64_t)b * NB + l / BS] : 0;
        int slot = l % BS;
        int64_t cachebase = ((int64_t)physical * HK + kh) * D * BS;
        int64_t newbase = ((int64_t)(start + l - ctx) * HK + kh) * D;
        float score = 0.f;
        if constexpr (Registers) {
            int d = lane;
            float kval = prefix ? float(kc[cachebase + key_off0 + slot * 8]) : float(k[newbase + d]);
            score += q0 * kval;
            d = lane + 64;
            kval = prefix ? float(kc[cachebase + key_off1 + slot * 8]) : float(k[newbase + d]);
            score += q1 * kval;
        } else {
            for (int d = lane; d < D; d += 64) {
                float kval = prefix ? float(kc[cachebase + (d / X) * BS * X + slot * X + d % X]) : float(k[newbase + d]);
                score += qs[d] * kval;
            }
        }
        for (int delta = 32; delta; delta >>= 1)
            score += __shfl_xor(score, delta, 64);
        score = score * scale + slope * (l - pos);
        float next = fmaxf(m, score);
        float alpha = expf(m - next), beta = expf(score - next);
        z = alpha * z + beta;
        if constexpr (Registers) {
            int d = lane;
            float val = prefix ? float(vc[cachebase + d * BS + slot]) : float(v[newbase + d]);
            a0 = alpha * a0 + beta * val;
            d = lane + 64;
            val = prefix ? float(vc[cachebase + d * BS + slot]) : float(v[newbase + d]);
            a1 = alpha * a1 + beta * val;
        } else {
            for (int d = lane; d < D; d += 64) {
                float val = prefix ? float(vc[cachebase + d * BS + slot]) : float(v[newbase + d]);
                acc[d] = alpha * acc[d] + beta * val;
            }
        }
        m = next;
    }
    if constexpr (Registers) {
        out[t * os0 + h * os1 + lane * os2] = T(a0 / z);
        out[t * os0 + h * os1 + (lane + 64) * os2] = T(a1 / z);
    } else {
        for (int d = lane; d < D; d += 64)
            out[t * os0 + h * os1 + d * os2] = T(acc[d] / z);
    }
}

void pa_prefill(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                torch::Tensor kc, torch::Tensor vc, torch::Tensor bt,
                torch::Tensor starts, torch::Tensor lens,
                c10::optional<torch::Tensor> slopes, torch::Tensor out, double scale) {
    c10::cuda::CUDAGuard guard(q.device());
    q = q.contiguous(); k = k.contiguous(); v = v.contiguous();
    kc = kc.contiguous(); vc = vc.contiguous(); bt = bt.contiguous();
    starts = starts.contiguous(); lens = lens.contiguous();
    if (slopes.has_value()) slopes = slopes->contiguous();
    int H = q.size(1), D = q.size(2), HK = k.size(1);
    int BS = vc.size(3), X = kc.size(4);
    if (!q.numel()) return;
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, q.scalar_type(), "paged_online", [&] {
        if (D == 128 && X == 8) {
            paged_online<scalar_t, true><<<q.size(0) * H, 64, 0, stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                kc.data_ptr<scalar_t>(), vc.data_ptr<scalar_t>(), bt.data_ptr<int>(),
                starts.data_ptr<int>(), lens.data_ptr<int>(),
                slopes.has_value() ? slopes->data_ptr<float>() : nullptr,
                out.data_ptr<scalar_t>(), H, HK, D, BS, X, bt.size(1), lens.numel(),
                float(scale), out.stride(0), out.stride(1), out.stride(2));
        } else {
            paged_online<scalar_t, false><<<q.size(0) * H, 64, 2 * D * sizeof(float), stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                kc.data_ptr<scalar_t>(), vc.data_ptr<scalar_t>(), bt.data_ptr<int>(),
                starts.data_ptr<int>(), lens.data_ptr<int>(),
                slopes.has_value() ? slopes->data_ptr<float>() : nullptr,
                out.data_ptr<scalar_t>(), H, HK, D, BS, X, bt.size(1), lens.numel(),
                float(scale), out.stride(0), out.stride(1), out.stride(2));
        }
    });
    auto err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "paged attention launch failed: ", hipGetErrorString(err));
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Paged KV prefix (context) attention: attention for prefill multi-token queries.

    (MHA/GQA, causal + optional ALiBi.)

    Within a batch, num_seqs sequences run in parallel; sequence b has
    query_len[b] = query_start_loc[b+1] - query_start_loc[b] newly computed query
    tokens in this round, and the slices of all sequences are flattened and
    concatenated along the token dimension in query_start_loc order (no
    padding). The current total length of the sequence is seq_lens[b], of which
    the first ctx_len[b] = seq_lens[b] - query_len[b] tokens are the already
    admitted prefix K/V, stored only in the paged KV cache; the K/V of the new
    tokens of this round are given explicitly only as key / value (the cache
    does not contain the new tokens). query_len[b] > 1 means prefill, and == 1
    is also legal (a single-token query against the pure prefix).

    Paged layout: the physical block pool has num_blocks blocks, each holding
    block_size token slots; block_tables[b] is the "prefix logical block ->
    physical block id" table of that sequence, where only the first
    ceil(ctx_len[b]/block_size) columns are valid (the remaining columns are
    garbage). K uses the channel-packed layout: the K channel d of the l-th
    prefix token is stored at
    key_cache[bt[b, l//block_size], h_kv, d//x, l%block_size, d%x]
    (x = 8, head_size is a multiple of 8); V is stored at
    value_cache[bt[b, l//block_size], h_kv, d, l%block_size]. Blocks in the pool
    that are not referenced, as well as slots beyond the prefix length inside
    referenced blocks, are garbage data (magnitudes up to +/-10) and must not
    participate in the computation.

    For the j-th new token of the h-th query head of sequence b (the
    corresponding KV head is h // query_group_size, query_group_size =
    num_heads / num_kv_heads), at in-sequence absolute position pos =
    ctx_len[b] + j:

      logits[l] = scale * <query[pos, h, :], K[l]> + alibi_slopes[h] * (l - pos)
      causal mask: logits at positions l > pos are set to -inf
      p[l] = exp(logits[l] - max_l' logits[l']) / sum_l' exp(logits[l'] - max_l' logits[l'])
      out[pos, h, :] = sum_{l = 0..pos} p[l] * V[l]

    where K[l] / V[l]: for l < ctx_len[b] they come from the paged cache
    (indirect addressing through the block table), and for l >= ctx_len[b] they
    come from key / value. When alibi_slopes is None no bias term is added (it
    degenerates to the unbiased baseline); when a float32 [num_heads] tensor is
    given, the ALiBi bias is added as in the formula above (the bias is 0 at
    l == pos). The softmax uses an online (numerically stable) implementation,
    intermediate accumulation is in float32, and the output is cast back to the
    input dtype.

    Input/output specification (forward parameter order):
      query           [num_tokens, num_heads, head_size]                    fp16/bf16
      key             [num_tokens, num_kv_heads, head_size]                 same as query
      value           [num_tokens, num_kv_heads, head_size]                 same as query
      key_cache       [num_blocks, num_kv_heads, head_size//8, block_size, 8]   same as query
      value_cache     [num_blocks, num_kv_heads, head_size, block_size]         same as query
      block_tables    [num_seqs, max_blocks_per_seq]                         int32
      query_start_loc [num_seqs+1] int32 (prefix sum of query_len, first element 0)
      seq_lens        [num_seqs] int32
      alibi_slopes    [num_heads] float32, or None (no ALiBi bias)
      returns out     [num_tokens, num_heads, head_size], dtype same as query.
      scale defaults to 1/sqrt(head_size) (given by head_size in __init__).

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        torch.matmul / torch.bmm / torch.einsum / torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: prefill multi-token queries, non-quantized KV; includes the ALiBi
    bias variant and the unbiased baseline (alibi_slopes passed as None); does
    not include sliding window, does not include a quantized KV cache, and the
    K/V of the new tokens of this round are not written into the cache.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens, alibi_slopes=None):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        query_start_loc = query_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        slopes = None if alibi_slopes is None else alibi_slopes.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        num_tokens, num_heads, head_size = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_kv_heads = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        block_size = value_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        x = key_cache.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        group = num_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert num_heads == num_kv_heads * group, "num_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        assert head_size == (head_size // x) * x, "head_size must be an integer multiple of x"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        _pyramidkernel_get_extension().pa_prefill(query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens, slopes, out, self.scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return out
        # <<<END_IMPROVE>>>
