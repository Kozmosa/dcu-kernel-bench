import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3004_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void moe_forward(torch::Tensor a, torch::Tensor w1, torch::Tensor w2, torch::Tensor tw, torch::Tensor ids, torch::Tensor out);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_forward", &moe_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

// Each block owns a routed pair and 256 output channels. Hidden tiles
// remain in LDS throughout both projections; all arithmetic is float32.
template<class T>
__global__ void fused_moe(const float* __restrict__ a,
                          const T* __restrict__ w1,
                          const T* __restrict__ w2,
                          const float* __restrict__ tw,
                          const int64_t* __restrict__ ids,
                          T* __restrict__ out,
                          int K, int H, int topk) {
    const int64_t p = blockIdx.x;
    const int64_t e = ids[p];
    const int tid = threadIdx.x;
    const int lane = tid & 31;
    const int group = tid >> 5;
    const int k = blockIdx.y * 256 + tid;
    const float* x = a + (p / topk) * K;
    const T* first = w1 + e * (int64_t)(2 * H) * K;
    const T* second = w2 + e * (int64_t)K * H;
    __shared__ float hidden[128];
    float result = 0.0f;
    for (int base = 0; base < H; base += 128) {
        #pragma unroll 1
        for (int r = 0; r < 16; ++r) {
            const int local = group + r * 8;
            const int n = base + local;
            float gate = 0.0f, up = 0.0f;
            if (n < H) {
                float gate0 = 0.0f, gate1 = 0.0f;
                float gate2 = 0.0f, gate3 = 0.0f;
                float up0 = 0.0f, up1 = 0.0f;
                float up2 = 0.0f, up3 = 0.0f;
                int q = lane;
                for (; q + 96 < K; q += 128) {
                    float av0 = x[q];
                    float av1 = x[q + 32];
                    float av2 = x[q + 64];
                    float av3 = x[q + 96];
                    gate0 = fmaf(av0, static_cast<float>(first[(int64_t)n * K + q]), gate0);
                    gate1 = fmaf(av1, static_cast<float>(first[(int64_t)n * K + q + 32]), gate1);
                    gate2 = fmaf(av2, static_cast<float>(first[(int64_t)n * K + q + 64]), gate2);
                    gate3 = fmaf(av3, static_cast<float>(first[(int64_t)n * K + q + 96]), gate3);
                    up0 = fmaf(av0, static_cast<float>(first[(int64_t)(n + H) * K + q]), up0);
                    up1 = fmaf(av1, static_cast<float>(first[(int64_t)(n + H) * K + q + 32]), up1);
                    up2 = fmaf(av2, static_cast<float>(first[(int64_t)(n + H) * K + q + 64]), up2);
                    up3 = fmaf(av3, static_cast<float>(first[(int64_t)(n + H) * K + q + 96]), up3);
                }
                gate = gate0 + gate1 + gate2 + gate3;
                up = up0 + up1 + up2 + up3;
                for (; q < K; q += 32) {
                    float av = x[q];
                    gate = fmaf(av, static_cast<float>(first[(int64_t)n * K + q]), gate);
                    up = fmaf(av, static_cast<float>(first[(int64_t)(n + H) * K + q]), up);
                }
            }
            #pragma unroll
            for (int delta = 16; delta > 0; delta >>= 1) {
                gate += __shfl_down(gate, delta, 32);
                up += __shfl_down(up, delta, 32);
            }
            if (lane == 0) hidden[local] = (gate / (1.0f + expf(-gate))) * up;
        }
        __syncthreads();
        if (k < K) {
            const int count = H - base < 128 ? H - base : 128;
            for (int n = 0; n < count; ++n)
                result = fmaf(hidden[n], static_cast<float>(second[(int64_t)k * H + base + n]), result);
        }
        __syncthreads();
    }
    if (k < K) out[p * K + k] = static_cast<T>(result * tw[p]);
}

void moe_forward(torch::Tensor a, torch::Tensor w1, torch::Tensor w2,
                 torch::Tensor tw, torch::Tensor ids, torch::Tensor out) {
    TORCH_CHECK(a.is_cuda() && w1.is_cuda() && w2.is_cuda() && tw.is_cuda() && ids.is_cuda() && out.is_cuda(), "GPU tensors required");
    TORCH_CHECK(a.is_contiguous() && w1.is_contiguous() && w2.is_contiguous() && tw.is_contiguous() && ids.is_contiguous() && out.is_contiguous(), "contiguous tensors required");
    TORCH_CHECK(a.scalar_type() == at::kFloat && tw.scalar_type() == at::kFloat && ids.scalar_type() == at::kLong, "invalid auxiliary dtype");
    TORCH_CHECK(w1.scalar_type() == w2.scalar_type() && out.scalar_type() == w1.scalar_type(), "weight/output dtype mismatch");
    c10::cuda::CUDAGuard guard(a.device());
    const int K = a.size(1), H = w1.size(1) / 2, topk = ids.size(1);
    dim3 grid(ids.numel(), (K + 255) / 256);
    auto stream = at::cuda::getCurrentCUDAStream();
    if (w1.scalar_type() == at::kFloat) {
        fused_moe<float><<<grid, 256, 0, stream>>>(a.data_ptr<float>(), w1.data_ptr<float>(), w2.data_ptr<float>(), tw.data_ptr<float>(), ids.data_ptr<int64_t>(), out.data_ptr<float>(), K, H, topk);
    } else {
        TORCH_CHECK(w1.scalar_type() == at::kBFloat16, "float32 or bfloat16 required");
        fused_moe<at::BFloat16><<<grid, 256, 0, stream>>>(a.data_ptr<float>(), w1.data_ptr<at::BFloat16>(), w2.data_ptr<at::BFloat16>(), tw.data_ptr<float>(), ids.data_ptr<int64_t>(), out.data_ptr<at::BFloat16>(), K, H, topk);
    }
    auto error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess, hipGetErrorString(error));
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    The full fused Mixture-of-Experts (MoE) token feed-forward path: one call
    completes the whole chain "pick experts by routing -> first grouped GEMM ->
    SwiGLU activation -> second grouped GEMM -> routing weighting".

    Operator semantics (mathematical definition and boundary behaviour):
      Inputs: activation a [M, K]; expert weight w1 [E, N, K] for the first FFN
      layer (N = 2*hidden, the first N/2 channels are gate and the last N/2 are
      up), w2 [E, K, N//2] for the second FFN layer; the routing result
      topk_ids [M, top_k] holds the expert ids selected for each token and
      topk_weights [M, top_k] the matching routing weights. For each token m and
      its j-th expert e = topk_ids[m, j]:
        gate[m,j,:] = a[m,:] @ w1[e, :N//2, :].T          # [N//2]
        up[m,j,:]   = a[m,:] @ w1[e, N//2:, :].T          # [N//2]
        h[m,j,:]    = gate * sigmoid(gate) * up           # SwiGLU, SiLU(x)=x*sigmoid(x)
        out[m,j,k]  = topk_weights[m,j] * sum_{n<N//2} h[m,j,n] * w2[e,k,n]
      that is out[m,j,:] = topk_weights[m,j] * (h[m,j,:] @ w2[e].T). The (m, j)
      pairs are mutually independent; the outputs of all top_k slots are written
      to the result, with no merge, sum or normalization across experts.
      Boundary behaviour: N is even; top_k <= E and the topk_ids values lie in
      [0, E); the top_k experts of one token are generated distinct (even should
      a duplicate appear, the pair-independent computation still holds); M and K
      are arbitrary positive integers (1 included, i.e. the GEMV case); routing
      weighting is always enabled.

    Input/output specification:
      forward(a, w1, w2, topk_weights, topk_ids) -> out
        a            [M, K]        bfloat16/float32, row-major contiguous
        w1           [E, N, K]     same dtype as a, row-major contiguous
        w2           [E, K, N//2]  same dtype as a, row-major contiguous
        topk_weights [M, top_k]    same dtype as a, row-major contiguous
        topk_ids     [M, top_k]    int64 (losslessly recoverable after the
                                   evaluator's fp32 cast)
        out          [M, top_k, K] same dtype as a
      __init__(top_k, num_experts): instance metadata only; forward always goes
      by the actual runtime tensor shapes (top_k = topk_ids.shape[1],
      E = w1.shape[0]).

    Implementation constraints (violations are scored as failures):
      - Core computation (both grouped GEMMs, the SwiGLU activation, the routing
        weighting) must be done with a HIP kernel inside the submitted file;
        calling ATen shortcuts such as torch.matmul / torch.mm / torch.bmm /
        torch.baddbmm / torch.addmm / torch.einsum /
        torch.nn.functional.linear / F.linear / torch.nn.functional.silu /
        F.silu / torch.sigmoid / aiter is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: non-quantized bfloat16/float32 activations and weights; single
    card; no expert capacity limit, no shared experts, no routing weight
    normalization; the expert dispatch/scheduling strategy (sorted alignment,
    persistent grid, etc.) is up to the implementation and is judged by the
    output tolerance.
    """
    def __init__(self, top_k: int, num_experts: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.top_k = top_k
        self.num_experts = num_experts
        # <<<END_IMPROVE>>>

    def forward(self, a, w1, w2, topk_weights, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, K = a.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        E, N, _ = w1.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        H = N // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert 0 <= int(topk_ids.min()) and int(topk_ids.max()) < E, "topk_ids must fall inside [0, E)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        a32 = a.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        tw32 = topk_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        out = torch.empty((M, top_k, K), dtype=a.dtype, device=a.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        _pyramidkernel_get_extension().moe_forward(a32, w1, w2, tw32, topk_ids, out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        return out
        # <<<END_IMPROVE>>>
