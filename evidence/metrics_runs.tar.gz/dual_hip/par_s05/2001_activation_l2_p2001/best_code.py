import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor gated_mxfp4(torch::Tensor x, int64_t activation);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("gated_mxfp4", &gated_mxfp4);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>

template<typename index_t, bool FULL_BLOCK>
__global__ void gated_quant_kernel(const float* __restrict__ x,
                                   unsigned char* __restrict__ out,
                                   index_t M, index_t d, index_t B,
                                   int activation) {
#pragma clang fp contract(off)
    const int lane = threadIdx.x & 31;
    const index_t group = (index_t)blockIdx.x * 8 + (index_t)(threadIdx.x / 32);
    const bool active = group < M * B;
    const index_t row = group / B;
    const index_t block = group % B;
    const index_t col = block * 32 + lane;
    float v = 0.0f;
    if (active && (FULL_BLOCK || col < d)) {
        const float a = x[row * (2*d) + col];
        const float b = x[row * (2*d) + d + col];
        float act;
        if (activation == 0) {
            act = a / (1.0f + expf(-a));
        } else if (activation == 1) {
            act = (0.5f * a) * (1.0f + erff(a * 0.7071067811865476f));
        } else {
            const float cube = (a * a) * a;
            const float inner = 0.7978845608028654f * (a + 0.044715f * cube);
            act = (0.5f * a) * (1.0f + tanhf(inner));
        }
        v = act * b;
    }
    float am = fabsf(v);
    for (int offset = 16; offset; offset >>= 1)
        am = fmaxf(am, __shfl_xor(am, offset, 32));
    const unsigned rounded = (__float_as_uint(am) + 0x200000u) & 0xff800000u;
    int scale;
    if (rounded == 0u) {
        scale = -127;
    } else if (rounded < 0x7f800000u) {
        scale = int((rounded >> 23) & 255u) - 129;
        scale = scale < -127 ? -127 : (scale > 127 ? 127 : scale);
    } else {
        scale = (int)fminf(127.0f, fmaxf(-127.0f,
            floorf(log2f(__uint_as_float(rounded))) - 2.0f));
    }
    const unsigned multiplier_bits = (scale == 127) ? 0x00400000u : (static_cast<unsigned>(127 - scale) << 23);
    const float q = v * __uint_as_float(multiplier_bits);
    const unsigned bits = __float_as_uint(q);
    int e = (bits >> 23) & 255;
    unsigned m = bits & 0x7fffffu;
    if (e < 127) {
        const int shift = 126 - e;
        m = shift >= 32 ? 0u : ((0x400000u | (m >> 1)) >> shift);
    }
    e = (e > 126 ? e : 126) - 126;
    unsigned code = ((((unsigned)e << 2) | (m >> 21)) + 1) >> 1;
    code = (code < 7 ? code : 7) | ((bits >> 28) & 8u);
    const unsigned neighbor = __shfl_xor(code, 1, 32);
    if (active) {
        const index_t base = row * (d/2 + B);
        if constexpr (FULL_BLOCK) {
            if (!(lane & 1))
                out[base + col/2] = (unsigned char)(code | (neighbor << 4));
        } else {
            if (!(lane & 1) && col < d)
                out[base + col/2] = (unsigned char)(code | (neighbor << 4));
        }
        if (lane == 0)
            out[base + d/2 + block] = (unsigned char)(scale + 127);
    }
}

torch::Tensor gated_mxfp4(torch::Tensor x, int64_t activation) {
    TORCH_CHECK(x.is_cuda() && x.scalar_type() == torch::kFloat32,
                "expected GPU float32 input");
    TORCH_CHECK(x.dim() == 2 && x.is_contiguous(), "expected contiguous matrix");
    TORCH_CHECK(x.size(1) % 4 == 0, "N must be a multiple of 4");
    TORCH_CHECK(activation >= 0 && activation <= 2, "invalid activation");
    c10::cuda::CUDAGuard guard(x.device());
    const int64_t M = x.size(0), d = x.size(1)/2, B = (d+31)/32;
    auto out = torch::empty({M, d/2+B}, x.options().dtype(torch::kUInt8));
    if (M*B) {
        auto stream = c10::cuda::getCurrentCUDAStream(x.get_device());
        const int64_t limit = 2147483647;
        const bool narrow = M <= limit && d <= limit/2 &&
            d <= limit-31 && B <= limit/32 &&
            d/2 <= limit-B && M <= (limit-7)/B &&
            M <= limit/(2*d) && M <= limit/(d/2+B);
        const bool full = (d % 32) == 0;
        if (narrow) {
            if (full) {
                hipLaunchKernelGGL((gated_quant_kernel<int32_t, true>), dim3((M*B+7)/8), dim3(256), 0,
                                  stream.stream(), x.data_ptr<float>(), out.data_ptr<unsigned char>(),
                                  (int32_t)M, (int32_t)d, (int32_t)B, (int)activation);
            } else {
                hipLaunchKernelGGL((gated_quant_kernel<int32_t, false>), dim3((M*B+7)/8), dim3(256), 0,
                                  stream.stream(), x.data_ptr<float>(), out.data_ptr<unsigned char>(),
                                  (int32_t)M, (int32_t)d, (int32_t)B, (int)activation);
            }
        } else {
            if (full) {
                hipLaunchKernelGGL((gated_quant_kernel<int64_t, true>), dim3((M*B+7)/8), dim3(256), 0,
                                  stream.stream(), x.data_ptr<float>(), out.data_ptr<unsigned char>(),
                                  M, d, B, (int)activation);
            } else {
                hipLaunchKernelGGL((gated_quant_kernel<int64_t, false>), dim3((M*B+7)/8), dim3(256), 0,
                                  stream.stream(), x.data_ptr<float>(), out.data_ptr<unsigned char>(),
                                  M, d, B, (int)activation);
            }
        }
        const hipError_t err = hipGetLastError();
        TORCH_CHECK(err == hipSuccess, "HIP launch failed: ", hipGetErrorString(err));
    }
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Gated activation x SwiGLU split-half multiply x dynamic MXFP4 quantization
    fused operator.

    Input x has shape (M, N) (N is a multiple of 4). Split the last dimension in
    half: a = x[:, :N/2], b = x[:, N/2:], then first compute the gated product in
    float32 as out = act(a) * b, where act is selected by the __init__ argument
    activation (mathematical definition, all evaluated in float32):
        silu      : u * sigmoid(u)
        gelu      : 0.5 * u * (1 + erf(u * 0.7071067811865476))
        gelu_tanh : 0.5 * u * (1 + tanh(0.7978845608028654 * (u + 0.044715 * u^3)))

    Then split out along the last dimension into contiguous 32-element blocks and
    dynamically quantize each block to MXFP4 (float32 bit manipulation throughout):
      1. When N/2 is not a multiple of 32, zero-pad the right end of the last block
         up to 32 elements; the padding participates in amax.
      2. amax = max|block|; apply (bits + 0x200000) & 0xFF800000 to the float32 bit
         pattern of amax (even_round: clear the mantissa and round up to the power
         of two grid).
      3. Unbiased scale = clamp(floor(log2(amax)) - 2, -127, 127); the e8m0 byte =
         unbiased scale + 127, landing in [0, 254] (meaning 2^(byte - 127)). A
         fully zero block (including a zero-pad segment that makes amax 0) goes
         through log2(0) = -inf, is clamped to -127, and gets byte 0.
      4. q = block * 2^(-unbiased scale), each element rounded to the e2m1 grid
         {0, +-0.5, +-1, +-1.5, +-2, +-3, +-4, +-6}. Bit-level formula: take the
         float32 fields of q -- s (sign bit) / e (biased exponent) / m (23-bit
         mantissa):
             e' = max(e, 126) - 126
             m' = (e < 127) ? (0x400000 | (m >> 1)) >> (126 - e) : m (subnormal
                  rescaling)
             code = (((e' << 2) | (m' >> 21)) + 1) >> 1, then saturated to 0x7
             e2m1 code word (4 bits) = (s ? 8 : 0) | code
      5. Two adjacent e2m1 code words are packed into one uint8: the even index
         occupies the low 4 bits, the odd index the high 4 bits.

    The output is a single uint8 tensor (two segments concatenated along the last
    dimension):
        out (M, N/4 + ceil(N/64)) uint8
        first N/4 columns       : MXFP4 packed code words (two e2m1 values per byte)
        last ceil(N/64) columns : the e8m0 scale byte of each 32-element block
    Both segments are integer code words and must match exactly.

    Input/output specification:
        x    float16 / bfloat16 (M, N), contiguous, N % 4 == 0, M >= 1
             (the evaluator casts the input to fp32 before calling forward;
             fp16/bf16 -> fp32 is lossless)
        out  uint8 (M, N/4 + ceil(N/64))

    Implementation constraints (violations are scored as failures):
        - The core computation (activation, split-half multiply, per-block scale
          and e2m1 quantization, code-word packing) must be completed with a
          HIP kernel inside the submitted file; the output is uint8 code words
          with no floating-point output.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The activation, the multiply and the quantization bit manipulation all
          run in float32 and must be bit-identical to this reference implementation
          (code words and scale bytes exactly equal, no tolerance).
        - When N/2 is not a multiple of 32, handle the block tail with the zero-pad
          semantics described above.

    Forbidden: torch.nn.functional.silu / torch.nn.functional.gelu /
    torch.nn.SiLU / torch.nn.GELU / torch.sigmoid / torch.erf / torch.tanh.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, activation: str = "silu"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert activation in ("silu", "gelu", "gelu_tanh"), "activation must be one of silu / gelu / gelu_tanh"
        self.activation = activation
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().gated_mxfp4(x.to(torch.float32), {'silu': 0, 'gelu': 1, 'gelu_tanh': 2}[self.activation])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, N = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        assert N % 4 == 0, "N must be a multiple of 4"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        d = N // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        a, b = x.split([d, d], dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        out = nn.functional.silu(a) * b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        if self.activation == "gelu":
            out = nn.functional.gelu(a) * b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if self.activation == "gelu_tanh":
            out = nn.functional.gelu(a, approximate="tanh") * b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        BLOCK = 32
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        n_blocks = (d + BLOCK - 1) // BLOCK
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        blocks = out
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        if d % BLOCK != 0:
            # zero-pad the block tail (the padding participates in amax)
            padded = torch.zeros(M, n_blocks * BLOCK, dtype=torch.float32, device=out.device)
            padded[:, :d] = out
            blocks = padded
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        blocks = blocks.reshape(M, n_blocks, BLOCK)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        amax, _ = torch.max(torch.abs(blocks), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        amax = amax.view(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        amax = (amax + 0x200000) & 0xFF800000
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        amax = amax.view(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        scale_unbiased = torch.clamp(torch.log2(amax).floor() - 2, min=-127, max=127)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        bs_e8m0 = (scale_unbiased + 127).to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        quant_scale = torch.exp2(-scale_unbiased)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        qx = blocks * quant_scale.unsqueeze(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        qx = qx.contiguous().view(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        s = qx & 0x80000000
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        e = (qx >> 23) & 0xFF
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        m = qx & 0x7FFFFF
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        adjusted = torch.clamp(127 - e - 1, min=0)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_27>>>
        m = torch.where(e < 127, (0x400000 | (m >> 1)) >> adjusted, m)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_28>>>
        e = torch.where(e > 126, e, 126) - 126
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_29>>>
        combined = (((e << 2) | (m >> 21)) + 1) >> 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_30>>>
        e2m1_tmp = torch.where(combined < 0x7, combined, 0x7)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_31>>>
        e2m1_value = (((s >> 28) & 0xF) | e2m1_tmp).to(torch.uint8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_32>>>
        x_fp4 = e2m1_value[..., ::2] | (e2m1_value[..., 1::2] << 4)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_33>>>
        x_fp4 = x_fp4.reshape(M, -1)[:, : d // 2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_34>>>
        return torch.cat([x_fp4, bs_e8m0], dim=-1)
        # <<<END_IMPROVE>>>
