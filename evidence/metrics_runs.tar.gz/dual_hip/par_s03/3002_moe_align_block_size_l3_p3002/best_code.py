import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor moe_align_cuda(torch::Tensor topk_ids, int64_t num_experts, int64_t block_size);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_align_cuda", &moe_align_cuda, "MoE alignment scheduling (HIP)");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/hip/HIPStream.h>
#include <c10/hip/HIPGuard.h>
#include <stdint.h>

#define HIP_CHECK(x) do { hipError_t err = (x); TORCH_CHECK(err == hipSuccess, hipGetErrorString(err)); } while (0)

template <typename T>
__global__ void metadata_kernel(const T* ids, int64_t n, int64_t experts, int64_t block,
                                int64_t* counts, int64_t* seg, int64_t* slots,
                                int64_t* total_blocks, int64_t* total_slots) {
    __shared__ unsigned int histogram[256];
    if (experts <= 256) {
        if ((int64_t)threadIdx.x < experts) histogram[threadIdx.x] = 0u;
        __syncthreads();
        for (int64_t i = (int64_t)threadIdx.x; i < n; i += (int64_t)blockDim.x)
            atomicAdd(&histogram[(int64_t)ids[i]], 1u);
        __syncthreads();
        if (threadIdx.x == 0) {
            for (int64_t e = 0; e < experts; ++e) counts[e] = (int64_t)histogram[e];
            int64_t cs = 0, ss = 0, cb = 0;
            for (int64_t e = 0; e < experts; ++e) {
                seg[e] = cs;
                slots[e] = ss;
                int64_t nb = (counts[e] + block - 1) / block;
                cs += counts[e];
                ss += nb * block;
                cb += nb;
            }
            *total_blocks = cb;
            *total_slots = ss;
        }
    } else if (threadIdx.x == 0) {
        for (int64_t e = 0; e < experts; ++e) counts[e] = 0;
        for (int64_t i = 0; i < n; ++i) ++counts[(int64_t)ids[i]];
        int64_t cs = 0, ss = 0, cb = 0;
        for (int64_t e = 0; e < experts; ++e) {
            seg[e] = cs;
            slots[e] = ss;
            int64_t nb = (counts[e] + block - 1) / block;
            cs += counts[e];
            ss += nb * block;
            cb += nb;
        }
        *total_blocks = cb;
        *total_slots = ss;
    }
}

template <typename T>
__global__ void layout_kernel(const T* ids, int64_t n, int64_t experts, int64_t block,
                              int64_t l1, int64_t l2, const int64_t* seg,
                              const int64_t* slots, const int64_t* counts,
                              const int64_t* total_blocks, const int64_t* total_slots,
                              float* out) {
    const int64_t e = (int64_t)blockIdx.x;
    const int tid = (int)threadIdx.x;
    const int wave = tid / warpSize;
    const int lane = tid % warpSize;
    __shared__ int64_t wave_counts[64];
    __shared__ int64_t wave_prefix[64];
    __shared__ int64_t running;
    __shared__ int64_t tile_base;

    const int64_t count = counts[e];
    const int64_t padded = ((count + block - 1) / block) * block;
    for (int64_t p = count + (int64_t)tid; p < padded; p += (int64_t)blockDim.x)
        out[slots[e] + p] = (float)n;
    const int64_t first_block = slots[e] / block;
    const int64_t num_blocks = padded / block;
    for (int64_t q = tid; q < num_blocks; q += blockDim.x)
        out[l1 + first_block + q] = (float)e;

    if (e == 0) {
        for (int64_t p = tid; p < l1 - *total_slots; p += blockDim.x)
            out[*total_slots + p] = (float)n;
        for (int64_t q = *total_blocks + tid; q < l2; q += blockDim.x)
            out[l1 + q] = -1.0f;
        if (tid == 0) out[l1 + l2] = (float)(*total_slots);
    }
    __syncthreads();

    if (tid == 0) running = 0;
    __syncthreads();
    for (int64_t tile = 0; tile < n; tile += blockDim.x) {
        const int64_t i = tile + tid;
        bool match = (i < n) && ((int64_t)ids[i] == e);
        const unsigned long long mask = __ballot(match);
        const unsigned long long lower = lane ? ((1ULL << lane) - 1ULL) : 0ULL;
        const int64_t exclusive_rank = (int64_t)__popcll(mask & lower);
        if (lane == 0) wave_counts[wave] = (int64_t)__popcll(mask);
        __syncthreads();
        if (tid == 0) {
            int64_t prefix = 0;
            const int nwaves = (blockDim.x + warpSize - 1) / warpSize;
            for (int w = 0; w < nwaves; ++w) {
                wave_prefix[w] = prefix;
                prefix += wave_counts[w];
            }
            tile_base = running;
        }
        __syncthreads();
        if (match)
            out[slots[e] + tile_base + wave_prefix[wave] + exclusive_rank] = (float)i;
        __syncthreads();
        if (tid == 0) {
            const int nwaves = (blockDim.x + warpSize - 1) / warpSize;
            running += wave_prefix[nwaves - 1] + wave_counts[nwaves - 1];
        }
        __syncthreads();
    }
}

template <typename T>
torch::Tensor moe_align_impl(torch::Tensor ids, int64_t experts, int64_t block) {
    const c10::hip::HIPGuard guard(ids.get_device());
    hipStream_t stream = c10::hip::getCurrentHIPStream(ids.get_device()).stream();
    const int64_t n = ids.numel();
    const int64_t l1 = n + experts * (block - 1);
    const int64_t l2 = (l1 + block - 1) / block;
    auto out = torch::empty({l1 + l2 + 1}, ids.options().dtype(torch::kFloat32));
    auto iopts = ids.options().dtype(torch::kInt64);
    auto counts = torch::empty({experts}, iopts);
    auto seg = torch::empty({experts}, iopts);
    auto slots = torch::empty({experts}, iopts);
    auto dblocks = torch::empty({}, iopts);
    auto dslots = torch::empty({}, iopts);
    const int threads = 256;
    metadata_kernel<T><<<1, threads, 0, stream>>>(
        ids.data_ptr<T>(), n, experts, block, counts.data_ptr<int64_t>(),
        seg.data_ptr<int64_t>(), slots.data_ptr<int64_t>(), dblocks.data_ptr<int64_t>(),
        dslots.data_ptr<int64_t>());
    layout_kernel<T><<<experts, threads, 0, stream>>>(
        ids.data_ptr<T>(), n, experts, block, l1, l2, seg.data_ptr<int64_t>(),
        slots.data_ptr<int64_t>(), counts.data_ptr<int64_t>(), dblocks.data_ptr<int64_t>(),
        dslots.data_ptr<int64_t>(), out.data_ptr<float>());
    HIP_CHECK(hipGetLastError());
    return out;
}

torch::Tensor moe_align_cuda(torch::Tensor topk_ids, int64_t num_experts, int64_t block_size) {
    TORCH_CHECK(topk_ids.is_cuda(), "topk_ids must be on device");
    TORCH_CHECK(topk_ids.is_contiguous(), "topk_ids must be contiguous");
    TORCH_CHECK(num_experts > 0 && block_size > 0, "invalid hyperparameters");
    auto x = topk_ids.reshape({-1});
    switch (x.scalar_type()) {
        case torch::kInt: return moe_align_impl<int32_t>(x, num_experts, block_size);
        case torch::kLong: return moe_align_impl<int64_t>(x, num_experts, block_size);
        case torch::kFloat: return moe_align_impl<float>(x, num_experts, block_size);
        default: TORCH_CHECK(false, "topk_ids must be int32, int64, or float32");
    }
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Scheduling prologue of MoE grouped GEMM: tokens bucketized per expert and
    laid out aligned to block_size.

    The input topk_ids ([num_tokens, top_k], elements are expert ids in
    [0, num_experts), duplicates allowed within a row) holds the experts the
    router selected for each token. Write the flattened index
    i = t * top_k + j (t is the token row, j the column), N = num_tokens * top_k,
    E = num_experts, B = block_size. For every expert e:
        T_e = { i : the i-th element of flattened topk_ids == e } (ascending i)
        n_blocks_e = ceil(|T_e| / B)        # aligned blocks occupied by e
        padded_e   = n_blocks_e * B         # aligned slot count of e
    Produce the three scheduling tensors of grouped GEMM:
        sorted_token_ids  length L1 = N + E*(B-1): for e = 0..E-1 in order, all
          indices of T_e (ascending), then padded_e - |T_e| fill sentinels N;
          the buffer tail [S, L1) is also sentinel N, where S = sum_e padded_e
        expert_ids        length L2 = ceil(L1/B): for e = 0..E-1 in order,
          n_blocks_e copies of e (together the first S/B positions), the tail
          [S/B, L2) filled with the -1 sentinel
        num_tokens_post_pad  scalar S (total padded slot count, always a
          multiple of B)
    grouped GEMM takes every B consecutive slots of sorted_token_ids as one
    M-tile, uses expert_ids as that tile's expert id to fetch weights, skips
    fill slots whose value is sentinel N, and num_tokens_post_pad gives the
    valid total length. This task is that scheduling prologue itself and does
    not include the GEMM.

    Boundary behaviour: an expert with |T_e| = 0 occupies 0 blocks and yields no
    sorted entry and no expert entry; when |T_e| is an exact multiple of B no
    padding is produced; the same row may select the same expert more than once
    (different flattened indices are different entries); entries within an
    expert follow ascending flattened index i.

    Input/output specification:
      topk_ids  int64/int32 (or fp32 as cast by the evaluator, integer values
                unchanged), contiguous 2D [num_tokens, top_k]; num_tokens /
                top_k >= 1 and top_k <= num_experts; E and B are __init__
                hyperparameters and >= 1, non powers of two allowed
      returns   a single 1-D float32 tensor of length L1 + L2 + 1, packed in
                three segments:
                out[:L1] = the L1 integers of sorted_token_ids (sentinel N
                           included)
                out[L1:L1+L2] = the L2 integers of expert_ids (tail -1)
                out[L1+L2] = num_tokens_post_pad (scalar S)
                -- all of them are non-negative / minus-one integers; the
                global-domain constraint L1 = N + E*(B-1) <= 2^24 guarantees
                that sentinel N, every index, every expert id and S <= L1 are
                exactly representable in fp32
      __init__ hyperparameters: num_experts (int), block_size (int).

    Implementation constraints (violations are scored as failures):
      - Core computation (bucket counting, block-count prefix sums, scatter
        writes of the layout, block expert table generation) must be done in a
        HIP kernel inside the submitted file; forward may only do input/
        output arrangement (dtype restoration, three-segment cat packing).
        Calling torch.sort / torch.argsort / torch.bincount / torch.cumsum /
        torch.histc / torch.unique / torch.repeat_interleave, or any
        third-party MoE/scheduling operator library, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Integer arithmetic throughout (no floating-point accumulation); the
        output is packed into float32 integers per the protocol above.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: the pure scheduling prologue (sorting / alignment / block table
    generation); no grouped GEMM body and no routing scores (softmax/topk are
    already done upstream).
    """
    def __init__(self, num_experts: int, block_size: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = int(num_experts)
        self.block_size = int(block_size)
        # <<<END_IMPROVE>>>

    def forward(self, topk_ids):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().moe_align_cuda(topk_ids.contiguous(), self.num_experts, self.block_size)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        E, B = self.num_experts, self.block_size
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        assert int(topk_ids.min()) >= 0 and int(topk_ids.max()) < E, \
            "topk_ids must fall inside [0, num_experts)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        N = topk_ids.numel()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        flat_ids = topk_ids.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        L1 = N + E * (B - 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        L2 = (L1 + B - 1) // B
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        pass
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        return _pyramidkernel_get_extension().moe_align_cuda(topk_ids.contiguous(), self.num_experts, self.block_size)
        # <<<END_IMPROVE>>>
