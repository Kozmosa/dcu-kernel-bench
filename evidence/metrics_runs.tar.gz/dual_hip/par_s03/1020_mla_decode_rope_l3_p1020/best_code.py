import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1020_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor mla_decode(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, int64_t, int64_t, int64_t, double, bool);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mla_decode", &mla_decode);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template<class T>
__device__ float rotated(const T* x, const T* cs, int d, int c, int rd, bool neox) {
    float v = float(x[d]);
    int z = d-c;
    if (z < 0 || z >= rd) return v;
    int half = rd/2;
    bool second = neox ? z >= half : (z & 1);
    int i = neox ? z % half : z/2;
    int partner = neox ? (second ? z-half : z+half) : (z^1);
    float co = float(cs[i]), si = float(cs[half+i]);
    float p = float(x[c+partner]);
    return v*co + (second ? p*si : -p*si);
}

template<class T, int F>
__global__ void decode_kernel(const T* q, const T* kv, const T* cs,
    const int* pos, const int* ptr, const int* idx, T* out,
    int B, int H, int c, int r, int rd, float scale, bool neox) {
    int b = blockIdx.x / H, h = blockIdx.x % H;
    int t = threadIdx.x, D = c+r;
    const T* query = q + (int64_t(b)*H+h)*D;
    const T* trig = cs + int64_t(pos[b])*rd;
    {
        int start=ptr[b], end=ptr[b+1];
        if (end-start==1) {
            const T* key=kv+int64_t(idx[start])*D;
            for (int d=t; d<c; d+=blockDim.x)
                out[(int64_t(b)*H+h)*c+d]=key[d];
            if (h==0) {
                for (int z=t; z<r; z+=blockDim.x)
                    out[int64_t(B)*H*c+int64_t(b)*r+z]=T(rotated(key,trig,c+z,c,rd,neox));
            }
            return;
        }
    }
    float qq[F], acc[F], val[F];
    #pragma unroll
    for (int f=0; f<F; ++f) {
        int d=t+128*f;
        qq[f] = d<D ? rotated(query,trig,d,c,rd,neox) : 0.f;
        acc[f] = 0.f;
    }
    __shared__ float red[128];
    float m=-INFINITY, l=0.f;
    int end=ptr[b+1];
    for (int j=ptr[b]; j<end; ++j) {
        const T* key=kv+int64_t(idx[j])*D;
        bool last=j==end-1;
        float dot=0.f;
        #pragma unroll
        for (int f=0; f<F; ++f) {
            int d=t+128*f;
            float v=0.f;
            if (d<D) v=last ? rotated(key,trig,d,c,rd,neox) : float(key[d]);
            val[f]=v;
            dot += qq[f]*v;
            if (last && h==0 && d>=c && d<D)
                out[int64_t(B)*H*c+int64_t(b)*r+d-c]=T(v);
        }
        red[t]=dot;
        __syncthreads();
        for (int stride=64; stride>0; stride>>=1) {
            if (t<stride) red[t]+=red[t+stride];
            __syncthreads();
        }
        float s=red[0]*scale;
        float nm=fmaxf(m,s);
        float a=expf(m-nm), w=expf(s-nm);
        l=a*l+w;
        m=nm;
        #pragma unroll
        for (int f=0; f<F; ++f) acc[f]=a*acc[f]+w*val[f];
        __syncthreads();
    }
    #pragma unroll
    for (int f=0; f<F; ++f) {
        int d=t+128*f;
        if (d<c) out[(int64_t(b)*H+h)*c+d]=T(acc[f]/l);
    }
}

// Four native waves gather four independent tokens per tile.
template<class T>
__global__ void decode_tile4(const T* q, const T* kv, const T* cs,
    const int* pos, const int* ptr, const int* idx, T* out,
    int B, int H, float scale, bool neox) {
    int b=blockIdx.x/H, h=blockIdx.x%H, t=threadIdx.x;
    int lane=t%warpSize, wave=t/warpSize;
    int start=ptr[b], end=ptr[b+1];
    const T* trig=cs+int64_t(pos[b])*64;
    if (end-start==1) {
        const T* key=kv+int64_t(idx[start])*576;
        for (int d=t; d<512; d+=blockDim.x)
            out[(int64_t(b)*H+h)*512+d]=key[d];
        if (h==0)
            for (int z=t; z<64; z+=blockDim.x)
                out[int64_t(B)*H*512+int64_t(b)*64+z]=T(rotated(key,trig,512+z,512,64,neox));
        return;
    }
    const T* query=q+(int64_t(b)*H+h)*576;
    float qq[18];
    for (int f=0, d=lane; d<576; ++f,d+=warpSize)
        qq[f]=rotated(query,trig,d,512,64,neox);
    float acc[4]={0.f,0.f,0.f,0.f};
    __shared__ float values[4][512];
    __shared__ float scores[4], weights[4], factor, denom;
    float m=-INFINITY, l=0.f;
    for (int base=start; base<end; base+=4) {
        int j=base+wave;
        bool valid=j<end, last=j==end-1;
        const T* key=valid ? kv+int64_t(idx[j])*576 : nullptr;
        float dot=0.f;
        for (int f=0,d=lane; d<576; ++f,d+=warpSize) {
            float v=0.f;
            if (valid) v=last ? rotated(key,trig,d,512,64,neox) : float(key[d]);
            dot+=qq[f]*v;
            if (d<512) values[wave][d]=v;
            if (last && h==0 && d>=512)
                out[int64_t(B)*H*512+int64_t(b)*64+d-512]=T(v);
        }
        for (int offset=warpSize/2; offset>0; offset/=2)
            dot+=__shfl_down(dot,offset,warpSize);
        if (lane==0) scores[wave]=valid ? dot*scale : -INFINITY;
        __syncthreads();
        if (t==0) {
            float nm=m;
            for (int k=0;k<4;++k) nm=fmaxf(nm,scores[k]);
            factor=expf(m-nm);
            l*=factor;
            for (int k=0;k<4;++k) {
                weights[k]=expf(scores[k]-nm);
                l+=weights[k];
            }
            m=nm;
            denom=l;
        }
        __syncthreads();
        for (int f=0,d=t; d<512; ++f,d+=blockDim.x) {
            float v=factor*acc[f];
            #pragma unroll
            for (int k=0;k<4;++k) v+=weights[k]*values[k][d];
            acc[f]=v;
        }
        __syncthreads();
    }
    for (int f=0,d=t; d<512; ++f,d+=blockDim.x)
        out[(int64_t(b)*H+h)*512+d]=T(acc[f]/denom);
}

torch::Tensor mla_decode(torch::Tensor q, torch::Tensor kv, torch::Tensor cs,
    torch::Tensor pos, torch::Tensor ptr, torch::Tensor idx,
    int64_t c, int64_t r, int64_t rd, double scale, bool neox) {
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim()==3 && q.size(2)==c+r && rd>=2 && rd<=r, "Invalid dimensions");
    TORCH_CHECK(c+r<=4096, "Feature width exceeds kernel capacity");
    TORCH_CHECK(pos.scalar_type()==at::kInt && ptr.scalar_type()==at::kInt && idx.scalar_type()==at::kInt, "Metadata must be int32");
    q=q.contiguous(); kv=kv.contiguous(); cs=cs.contiguous();
    pos=pos.contiguous(); ptr=ptr.contiguous(); idx=idx.contiguous();
    int B=q.size(0), H=q.size(1);
    auto out=torch::empty({B*H*c+B*r},q.options());
    auto stream=at::cuda::getCurrentCUDAStream();
    int wave_width=at::cuda::getCurrentDeviceProperties()->warpSize;
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, q.scalar_type(), "mla_decode", [&] {
        if (c==512 && r==64 && rd==64 && (wave_width==32 || wave_width==64)) {
            decode_tile4<scalar_t><<<B*H,4*wave_width,0,stream>>>(q.data_ptr<scalar_t>(),kv.data_ptr<scalar_t>(),cs.data_ptr<scalar_t>(),pos.data_ptr<int>(),ptr.data_ptr<int>(),idx.data_ptr<int>(),out.data_ptr<scalar_t>(),B,H,float(scale),neox);
        } else if (c+r<=640) {
            decode_kernel<scalar_t,5><<<B*H,128,0,stream>>>(q.data_ptr<scalar_t>(),kv.data_ptr<scalar_t>(),cs.data_ptr<scalar_t>(),pos.data_ptr<int>(),ptr.data_ptr<int>(),idx.data_ptr<int>(),out.data_ptr<scalar_t>(),B,H,c,r,rd,float(scale),neox);
        } else {
            decode_kernel<scalar_t,32><<<B*H,128,0,stream>>>(q.data_ptr<scalar_t>(),kv.data_ptr<scalar_t>(),cs.data_ptr<scalar_t>(),pos.data_ptr<int>(),ptr.data_ptr<int>(),idx.data_ptr<int>(),out.data_ptr<scalar_t>(),B,H,c,r,rd,float(scale),neox);
        }
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    DeepSeek MLA decode-phase attention with a single-token query, fusing the RoPE
    rotation, page size = 1.

    Semantics: q is the current decode step's query [B, H, c + r] (c =
    kv_lora_rank compressed nope part first, r = qk_rope_head_dim rope part q_pe
    after it). The KV cache is stored per token (page size 1): kv_cache has
    total_tokens rows, each row = [compressed latent vector (first c dims) | k_pe
    (last r dims)]; the j-th logical token of batch b lives at physical row
    kv_indices[kv_indptr[b] + j] (kv_indptr is the cumulative sum of the sequence
    lengths, starting at 0); unreferenced rows of the row pool are garbage data and
    must not take part in the computation. Value is exactly the first c columns of
    that row: the compressed part of K shares the same latent vector with V (the
    MLA structure -- every query head shares one per-token compressed KV, there is
    no separate KV head).

    For every batch b (let pos = positions[b], rd = rotary_dim, half = rd // 2):
      1. RoPE rotation: take the row [cos(half) | sin(half)] of cos_sin_cache by
         position pos. The first rd dims of q_pe are rotated and the dims after rd
         pass through unchanged; the k_pe of the last logical token
         (j = seq_len_b - 1) is likewise rotated only in its first rd dims (dims
         after rd pass through), while the k_pe of the other tokens is treated as
         already rotated and used as the raw cache value. The rotation style is
         chosen by is_neox_style:
           NEOX (rotate-half): (x1, x2) = (first half dims, last half dims)
           GPT-J (interleaved): (x1, x2) = (even dims, odd dims)
           rotation output = concat(x1*cos - x2*sin, x2*cos + x1*sin) (scattered
           back in their own order).
      2. Attention (softmax over all j = 0..seq_len_b-1):
           s[h, j] = sm_scale * ( <q_nope[b,h,:], k_lat[b,j,:]>
                                + <q_pe'[b,h,:], k_pe'[b,j,:]> )
         where ' denotes after rotation; k_pe' is the rotated value only for the
         last token and the raw cache value for the others.
           p[h, :] = softmax_j(s[h, :])
           attn_out[b, h, :] = sum_j p[h, j] * k_lat[b, j, :]
      3. k_pe_tokens[b, :] = the full rotated k_pe of the last token (r dims, for
         writing back to the cache).
    softmax is numerically stable, intermediate accumulation is float32, and the
    output is cast back to the input dtype.
    Boundary behaviour: seq_len_b >= 1 (when it equals 1 that token is "the last
    token" and its k_pe takes part in the rotation); how the KV reduction is
    organized is only an implementation detail -- any implementation numerically
    equivalent to the full softmax is acceptable; there is no logit cap, no causal
    mask (decode naturally attends the whole cache), and no quantization.

    Input/output specification:
      q              [B, H, c + r] float16/bfloat16
      kv_cache       [total_tokens, c + r] same dtype as q (token-level KV row pool)
      cos_sin_cache  [max_positions, rd] same dtype as q (first half columns cos,
                     last half columns sin; row t corresponds to position
                     t = 0,1,...)
      positions      [B] int32 (sequence position of the current query; values
                     < max_positions, independent of seq_len)
      kv_indptr      [B+1] int32 (cumulative sum of the sequence lengths: first
                     element 0, monotonically non-decreasing)
      kv_indices     [total_kv] int32 (logical token -> physical row id; values
                     < total_tokens; total_kv == kv_indptr[-1])
      out            1-D flat concatenation, length B*H*c + B*r, same dtype as q:
                     the first B*H*c entries = attn_out ([B, H, c] flattened in
                     row-major order), the last B*r entries = k_pe_tokens
                     ([B, r] flattened in row-major order)
    Global-domain constraints: rd is a power of 2 and rd <= r;
    total_tokens >= kv_indptr[-1]; each sequence seq_len_b >= 1; B, H, c, r,
    max_positions are given by the shape family.

    Implementation constraints (violations are scored as failures):
      - The core computation (RoPE rotation / KV gathering / QK^T / softmax / PV)
        must be done inside the submitted file; calling
        scaled_dot_product_attention / sdpa / flash_attn / aiter / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - The 1-D concatenation layout of the output must match the specification
        above (the evaluator compares element by element).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-token decode, use_rope always true, non-quantized
    fp16/bf16, no logit cap, no causal mask / ALiBi / sliding window.
    """
    def __init__(self, kv_lora_rank: int, qk_rope_head_dim: int, rotary_dim: int, sm_scale=None, is_neox_style=True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.kv_lora_rank = int(kv_lora_rank)
        self.qk_rope_head_dim = int(qk_rope_head_dim)
        self.rotary_dim = int(rotary_dim)
        self.sm_scale = float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(self.kv_lora_rank + self.qk_rope_head_dim)
        self.is_neox_style = bool(is_neox_style)
        # <<<END_IMPROVE>>>

    def forward(self, q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices):
        # <<<IMPROVE:forward_stmt_1>>>
        positions = positions.to(device=q.device, dtype=torch.int32).contiguous()
        kv_indptr = kv_indptr.to(device=q.device, dtype=torch.int32).contiguous()
        kv_indices = kv_indices.to(device=q.device, dtype=torch.int32).contiguous()
        return _pyramidkernel_get_extension().mla_decode(q, kv_cache, cos_sin_cache, positions, kv_indptr, kv_indices, self.kv_lora_rank, self.qk_rope_head_dim, self.rotary_dim, self.sm_scale, self.is_neox_style)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        kv_indptr = kv_indptr.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        kv_indices = kv_indices.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        c, rd = self.kv_lora_rank, self.rotary_dim
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        half = rd // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        B, H, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        r = D - c
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert r == self.qk_rope_head_dim, "q's last dim must equal kv_lora_rank + qk_rope_head_dim"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        def apply_rope(x, cos, sin):
            # rotate the last dim (width r) of the float32 tensor x in place: the first rd dims are rotated, the rest pass through
            rot = x[..., :rd]
            if self.is_neox_style:
                x1, x2 = rot[..., :half], rot[..., half:]
            else:
                x1, x2 = rot[..., ::2], rot[..., 1::2]
            o1 = x1 * cos - x2 * sin
            o2 = x2 * cos + x1 * sin
            if self.is_neox_style:
                rot_out = torch.cat((o1, o2), dim=-1)
            else:
                rot_out = torch.stack((o1, o2), dim=-1).flatten(-2)
            return torch.cat((rot_out, x[..., rd:]), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        attn_out = torch.empty(B, H, c, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        k_pe_tokens = torch.empty(B, r, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        for b in range(B):
            s0, s1 = int(kv_indptr[b]), int(kv_indptr[b + 1])
            toks = kv_indices[s0:s1]                                 # physical rows of this batch's tokens
            kv_b = kv_cache.index_select(0, toks).to(torch.float32)  # [S, c+r] (a copy)
            k_lat = kv_b[:, :c]                                      # compressed latent vector (shared by K/V)
            k_pe = kv_b[:, c:]

            pos = int(positions[b])
            cos = cos_sin_cache[pos, :half].to(torch.float32)
            sin = cos_sin_cache[pos, half:].to(torch.float32)

            q_b = q[b].to(torch.float32)                             # [H, c+r]
            q_pe = apply_rope(q_b[:, c:], cos, sin)                  # q_pe rotation
            k_pe[-1] = apply_rope(k_pe[-1], cos, sin)                # only the last token's k_pe is rotated
            k_pe_tokens[b] = k_pe[-1].to(q.dtype)

            qk = torch.matmul(q_b[:, :c], k_lat.transpose(0, 1))     # inner product of the nope part
            qk += torch.matmul(q_pe, k_pe.transpose(0, 1))           # inner product of the rope part
            qk *= self.sm_scale
            probs = torch.softmax(qk, dim=-1)                        # [H, S]
            attn_out[b] = torch.matmul(probs, k_lat).to(q.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return torch.cat((attn_out.reshape(-1), k_pe_tokens.reshape(-1)))
        # <<<END_IMPROVE>>>
