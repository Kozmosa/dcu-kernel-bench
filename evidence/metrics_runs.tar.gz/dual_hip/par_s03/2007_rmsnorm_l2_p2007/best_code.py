import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2007_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor rmsnorm_forward(torch::Tensor x, torch::Tensor weight, torch::Tensor residual, bool fused, double eps);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("rmsnorm_forward", &rmsnorm_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>

template <typename T, bool Fused>
__global__ void rms_row(const T* __restrict__ x, const T* __restrict__ w,
                        const T* __restrict__ r, T* __restrict__ out,
                        int64_t n, float eps) {
    const int t = threadIdx.x;
    const int64_t base = int64_t(blockIdx.x) * n;
    const int64_t obase = int64_t(blockIdx.x) * n * (Fused ? 2 : 1);
    __shared__ float sums[256];
    float sum = 0.0f;
    for (int64_t c = t; c < n; c += 256) {
        T v = x[base + c];
        if (Fused) v = T(float(v) + float(r[base + c]));
        float f = float(v);
        sum += f * f;
    }
    sums[t] = sum;
    __syncthreads();
    for (int stride = 128; stride > 0; stride >>= 1) {
        if (t < stride) sums[t] += sums[t + stride];
        __syncthreads();
    }
    float scale = rsqrtf(sums[0] / float(n) + eps);
    for (int64_t c = t; c < n; c += 256) {
        T v = x[base + c];
        if (Fused) v = T(float(v) + float(r[base + c]));
        out[obase + c] = T((float(v) * scale) * float(w[c]));
        if (Fused) out[obase + n + c] = v;
    }
}

template <typename T> struct alignas(4 * sizeof(T)) Pack4 { T v[4]; };

template <typename T, bool Fused>
__global__ void rms_row_pack4(const T* __restrict__ x, const T* __restrict__ w,
                             const T* __restrict__ r, T* __restrict__ out,
                             int64_t n, float eps) {
    const int t = threadIdx.x;
    const int64_t base = int64_t(blockIdx.x) * n;
    const int64_t obase = base * (Fused ? 2 : 1);
    using P = Pack4<T>;
    const P* xp = reinterpret_cast<const P*>(x + base);
    const P* wp = reinterpret_cast<const P*>(w);
    const P* rp = Fused ? reinterpret_cast<const P*>(r + base) : nullptr;
    P* op = reinterpret_cast<P*>(out + obase);
    __shared__ float sums[256];
    float acc[4] = {0.f, 0.f, 0.f, 0.f};
    for (int64_t p = t; p < n / 4; p += 256) {
        P v = xp[p];
        if (Fused) {
            P rv = rp[p];
            #pragma unroll
            for (int j = 0; j < 4; ++j) v.v[j] = T(float(v.v[j]) + float(rv.v[j]));
        }
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            float f = float(v.v[j]);
            acc[j] += f * f;
        }
    }
    sums[t] = (acc[0] + acc[1]) + (acc[2] + acc[3]);
    __syncthreads();
    for (int stride = 128; stride > 0; stride >>= 1) {
        if (t < stride) sums[t] += sums[t + stride];
        __syncthreads();
    }
    float scale = rsqrtf(sums[0] / float(n) + eps);
    for (int64_t p = t; p < n / 4; p += 256) {
        P v = xp[p];
        if (Fused) {
            P rv = rp[p];
            #pragma unroll
            for (int j = 0; j < 4; ++j) v.v[j] = T(float(v.v[j]) + float(rv.v[j]));
        }
        P weights = wp[p], y;
        #pragma unroll
        for (int j = 0; j < 4; ++j)
            y.v[j] = T((float(v.v[j]) * scale) * float(weights.v[j]));
        op[p] = y;
        if (Fused) op[n / 4 + p] = v;
    }
}

// A subgroup owns one row; width is bounded by the native HIP wave size.
template <typename T, bool Fused>
__global__ void rms_short(const T* __restrict__ x, const T* __restrict__ w,
                          const T* __restrict__ r, T* __restrict__ out,
                          int64_t m, int64_t n, float eps) {
    const int width = n <= 16 ? 16 : warpSize;
    const int lane = threadIdx.x % width;
    const int64_t row = int64_t(blockIdx.x) * (256 / width) + threadIdx.x / width;
    const int64_t base = row * n;
    const int64_t obase = base * (Fused ? 2 : 1);
    float values[8];
    float sum = 0.0f;
    #pragma unroll
    for (int i = 0; i < 8; ++i) {
        const int c = lane + i * width;
        float f = 0.0f;
        if (row < m && c < n) {
            T v = x[base + c];
            if (Fused) v = T(float(v) + float(r[base + c]));
            f = float(v);
        }
        values[i] = f;
        sum += f * f;
    }
    for (int delta = width / 2; delta > 0; delta >>= 1)
        sum += __shfl_xor(sum, delta, width);
    const float scale = rsqrtf(sum / float(n) + eps);
    #pragma unroll
    for (int i = 0; i < 8; ++i) {
        const int c = lane + i * width;
        if (row < m && c < n) {
            out[obase + c] = T((values[i] * scale) * float(w[c]));
            if (Fused) out[obase + n + c] = T(values[i]);
        }
    }
}

torch::Tensor rmsnorm_forward(torch::Tensor x, torch::Tensor weight, torch::Tensor residual, bool fused, double eps) {
    c10::cuda::CUDAGuard guard(x.device());
    const int64_t m = x.size(0), n = x.size(1);
    auto out = torch::empty({m, n * (fused ? 2 : 1)}, x.options());
    auto stream = at::cuda::getCurrentCUDAStream();
    const bool short_rows = n <= 256;
    const int width = n <= 16 ? 16 : at::cuda::getCurrentDeviceProperties()->warpSize;
    const int rows_per_block = 256 / width;
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(), "rmsnorm_forward", [&] {
        const scalar_t* rp = fused ? residual.data_ptr<scalar_t>() : nullptr;
        const uintptr_t alignment = 4 * sizeof(scalar_t);
        const bool packed = n >= 1024 && n % 4 == 0 &&
            reinterpret_cast<uintptr_t>(x.data_ptr<scalar_t>()) % alignment == 0 &&
            reinterpret_cast<uintptr_t>(weight.data_ptr<scalar_t>()) % alignment == 0 &&
            reinterpret_cast<uintptr_t>(out.data_ptr<scalar_t>()) % alignment == 0 &&
            (!fused || reinterpret_cast<uintptr_t>(rp) % alignment == 0);
        if (packed) {
            if (fused) {
                rms_row_pack4<scalar_t, true><<<dim3(m), dim3(256), 0, stream>>>(x.data_ptr<scalar_t>(), weight.data_ptr<scalar_t>(), rp, out.data_ptr<scalar_t>(), n, float(eps));
            } else {
                rms_row_pack4<scalar_t, false><<<dim3(m), dim3(256), 0, stream>>>(x.data_ptr<scalar_t>(), weight.data_ptr<scalar_t>(), rp, out.data_ptr<scalar_t>(), n, float(eps));
            }
        } else if (short_rows) {
            const dim3 grid((m + rows_per_block - 1) / rows_per_block);
            if (fused) {
                rms_short<scalar_t, true><<<grid, dim3(256), 0, stream>>>(x.data_ptr<scalar_t>(), weight.data_ptr<scalar_t>(), rp, out.data_ptr<scalar_t>(), m, n, float(eps));
            } else {
                rms_short<scalar_t, false><<<grid, dim3(256), 0, stream>>>(x.data_ptr<scalar_t>(), weight.data_ptr<scalar_t>(), rp, out.data_ptr<scalar_t>(), m, n, float(eps));
            }
        } else if (fused) {
            rms_row<scalar_t, true><<<dim3(m), dim3(256), 0, stream>>>(x.data_ptr<scalar_t>(), weight.data_ptr<scalar_t>(), rp, out.data_ptr<scalar_t>(), n, float(eps));
        } else {
            rms_row<scalar_t, false><<<dim3(m), dim3(256), 0, stream>>>(x.data_ptr<scalar_t>(), weight.data_ptr<scalar_t>(), rp, out.data_ptr<scalar_t>(), n, float(eps));
        }
    });
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "rmsnorm launch failed: ", hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    RMSNorm forward family: standard RMSNorm and residual-fused
    (fused residual-add) RMSNorm.

    For each row of an (M, N) input, the normalization is computed in float32 as
    defined below:
        mean_sq = sum_i x_i^2 / N
        rsigma  = rsqrt(mean_sq + eps)
        y_i     = x_i * rsigma * w_i
    where w is the per-channel scale vector. The __init__ parameter `variant`
    selects one of two paths:
        "fused_add": first compute residual_out = x + residual in the input dtype
        (the residual stream passes straight through to the output), then apply the
        RMSNorm above to residual_out;
        "rmsnorm"  : apply the RMSNorm directly to x; residual takes no part in the
        computation (its content is arbitrary and may be garbage data).
    forward returns a single tensor out (same dtype as x): with fused_add it is
    (M, 2N) with the first N columns equal to y and the last N columns equal to
    residual_out (the two logical outputs concatenated along the last dimension);
    with rmsnorm it is (M, N), i.e. y.
    Boundary behaviour: for an all-zero row mean_sq = 0, so rsigma = rsqrt(eps)
    (eps guarantees no division by zero); N is arbitrary (including 1,
    non-powers-of-two, sizes not multiple of 16, and large N beyond a single
    block's reduction capacity) and must all be handled correctly with masking / a
    blocked reduction, and out-of-range elements at the row tail must not
    contribute to the sum of squares.

    Input/output specification:
        x        float16 / bfloat16 (M, N), contiguous, M >= 1, N >= 1
        weight   same dtype as x, (N,), contiguous
        residual same dtype as x, (M, N), contiguous (ignored when variant="rmsnorm")
        out      a single tensor, same dtype as x: (M, 2N) with fused_add (first N
                 columns y, last N columns residual_out), (M, N) with rmsnorm (i.e. y)
        The evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (residual add, per-row sum-of-squares reduction,
          rsqrt, element-wise scaling) must be completed with a HIP kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The sum-of-squares accumulation and the normalization run in float32; y is
          cast back to the input dtype; residual_out is added in the input dtype and
          written out as-is.
        - forward returns the single tensor `out` (the evaluator compares a single
          output); with fused_add the residual_out column block must be bit-identical
          to x + residual in the input dtype.

    Forbidden list: aiter / torch.rms_norm / torch.nn.functional.rms_norm /
    torch.nn.RMSNorm / torch.layer_norm / torch.nn.functional.layer_norm /
    torch.nn.LayerNorm / torch.norm / torch.linalg.norm /
    torch.linalg.vector_norm.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "fused_add", eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("rmsnorm", "fused_add"), "variant must be one of rmsnorm / fused_add"
        self.variant = variant
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, weight, residual):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().rmsnorm_forward(x, weight, residual, self.variant == "fused_add", self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        norm_input = x + residual if fused else x
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        residual_out = norm_input
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        xf = norm_input.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        wf = weight.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        mean_sq = (xf * xf).mean(dim=-1, keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        y = (xf * torch.rsqrt(mean_sq + self.eps) * wf).to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return torch.cat([y, residual_out], dim=-1) if fused else y
        # <<<END_IMPROVE>>>
