import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1011_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

void extend_attention_out(torch::Tensor, torch::Tensor, torch::Tensor,
                          torch::Tensor, torch::Tensor, torch::Tensor,
                          torch::Tensor, torch::Tensor, torch::Tensor,
                          bool, double);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("extend_attention_out", &extend_attention_out);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

namespace {

template <typename scalar_t, int ACC_SLOTS, int DQ_STATIC, bool FULL_DV>
__global__ void extend_attention_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ k_ext,
    const scalar_t* __restrict__ v_ext,
    const scalar_t* __restrict__ k_pool,
    const scalar_t* __restrict__ v_pool,
    const int32_t* __restrict__ qo_ptr,
    const int32_t* __restrict__ kv_ptr,
    const int64_t* __restrict__ kv_indices,
    scalar_t* __restrict__ out,
    int total_extend,
    int num_q_heads,
    int num_kv_heads,
    int dq,
    int dv,
    int nseq,
    bool causal,
    float scale) {
    const int row = static_cast<int>(blockIdx.x);
    const int h = static_cast<int>(blockIdx.y);
    const int lane = static_cast<int>(threadIdx.x);
    if (row >= total_extend || h >= num_q_heads) return;

    int lo = 0;
    int hi = nseq;
    while (lo + 1 < hi) {
        const int mid = (lo + hi) >> 1;
        if (qo_ptr[mid] <= row) lo = mid;
        else hi = mid;
    }
    const int seq = (qo_ptr[lo] <= row && row < qo_ptr[lo + 1]) ? lo : 0;
    const int qs = qo_ptr[seq];
    const int qe = qo_ptr[seq + 1];
    const int ks = kv_ptr[seq];
    const int ke = kv_ptr[seq + 1];
    const int prefix_len = ke - ks;
    const int extend_len = qe - qs;
    const int t = row - qs;
    const int kvh = h / (num_q_heads / num_kv_heads);

    extern __shared__ float accum[];
    float acc[ACC_SLOTS > 0 ? ACC_SLOTS : 1];
    if constexpr (ACC_SLOTS > 0) {
        #pragma unroll
        for (int slot = 0; slot < ACC_SLOTS; ++slot) acc[slot] = 0.0f;
    } else {
        for (int d = lane; d < dv; d += 64) accum[d] = 0.0f;
        __syncthreads();
    }

    const int64_t qbase = (static_cast<int64_t>(row) * num_q_heads + h) * dq;
    float qfrag[DQ_STATIC > 0 ? DQ_STATIC / 64 : 4];
    if constexpr (DQ_STATIC > 0) {
        #pragma unroll
        for (int slot = 0; slot < DQ_STATIC / 64; ++slot) {
            qfrag[slot] = static_cast<float>(q[qbase + lane + 64 * slot]);
        }
    } else {
        #pragma unroll
        for (int slot = 0; slot < 4; ++slot) {
            const int d = lane + 64 * slot;
            qfrag[slot] = (dq <= 256 && d < dq) ? static_cast<float>(q[qbase + d]) : 0.0f;
        }
    }
    float m = -INFINITY;
    float denom = 0.0f;

    for (int j = 0; j < prefix_len; ++j) {
        const int64_t pool_row = kv_indices[static_cast<int64_t>(ks) + j];
        const scalar_t* kp = k_pool + (pool_row * num_kv_heads + kvh) * dq;
        const scalar_t* vp = v_pool + (pool_row * num_kv_heads + kvh) * dv;
        float part = 0.0f;
        if constexpr (DQ_STATIC > 0) {
            #pragma unroll
            for (int slot = 0; slot < DQ_STATIC / 64; ++slot) {
                const int d = lane + 64 * slot;
                part += qfrag[slot] * static_cast<float>(kp[d]);
            }
        } else if (dq <= 256) {
            #pragma unroll
            for (int slot = 0; slot < 4; ++slot) {
                const int d = lane + 64 * slot;
                if (d < dq) part += qfrag[slot] * static_cast<float>(kp[d]);
            }
        } else {
            for (int d = lane; d < dq; d += 64) {
                part += static_cast<float>(q[qbase + d]) * static_cast<float>(kp[d]);
            }
        }
        for (int off = 32; off > 0; off >>= 1)
            part += __shfl_down(part, off, 64);
        const float score = __shfl(part, 0, 64) * scale;
        const float new_m = fmaxf(m, score);
        const float alpha = isfinite(m) ? expf(m - new_m) : 0.0f;
        const float beta = expf(score - new_m);
        denom = alpha * denom + beta;
        if constexpr (ACC_SLOTS > 0) {
            #pragma unroll
            for (int slot = 0; slot < ACC_SLOTS; ++slot) {
                const int d = lane + 64 * slot;
                if constexpr (FULL_DV) {
                    const float old = acc[slot];
                    acc[slot] = alpha * old + beta * static_cast<float>(vp[d]);
                } else if (d < dv) {
                    const float old = acc[slot];
                    acc[slot] = alpha * old + beta * static_cast<float>(vp[d]);
                }
            }
        } else {
            for (int d = lane; d < dv; d += 64) {
                const float old = accum[d];
                accum[d] = alpha * old + beta * static_cast<float>(vp[d]);
            }
        }
        m = new_m;
    }

    const int visible_extend = causal ? t + 1 : extend_len;
    const int64_t kstride = static_cast<int64_t>(num_kv_heads) * dq;
    const int64_t vstride = static_cast<int64_t>(num_kv_heads) * dv;
    const scalar_t* kp = k_ext + (static_cast<int64_t>(qs) * num_kv_heads + kvh) * dq;
    const scalar_t* vp = v_ext + (static_cast<int64_t>(qs) * num_kv_heads + kvh) * dv;
    for (int e = 0; e < visible_extend; ++e, kp += kstride, vp += vstride) {
        float part = 0.0f;
        if constexpr (DQ_STATIC > 0) {
            #pragma unroll
            for (int slot = 0; slot < DQ_STATIC / 64; ++slot) {
                const int d = lane + 64 * slot;
                part += qfrag[slot] * static_cast<float>(kp[d]);
            }
        } else if (dq <= 256) {
            #pragma unroll
            for (int slot = 0; slot < 4; ++slot) {
                const int d = lane + 64 * slot;
                if (d < dq) part += qfrag[slot] * static_cast<float>(kp[d]);
            }
        } else {
            for (int d = lane; d < dq; d += 64) {
                part += static_cast<float>(q[qbase + d]) * static_cast<float>(kp[d]);
            }
        }
        for (int off = 32; off > 0; off >>= 1)
            part += __shfl_down(part, off, 64);
        const float score = __shfl(part, 0, 64) * scale;
        const float new_m = fmaxf(m, score);
        const float alpha = isfinite(m) ? expf(m - new_m) : 0.0f;
        const float beta = expf(score - new_m);
        denom = alpha * denom + beta;
        if constexpr (ACC_SLOTS > 0) {
            #pragma unroll
            for (int slot = 0; slot < ACC_SLOTS; ++slot) {
                const int d = lane + 64 * slot;
                if constexpr (FULL_DV) {
                    const float old = acc[slot];
                    acc[slot] = alpha * old + beta * static_cast<float>(vp[d]);
                } else if (d < dv) {
                    const float old = acc[slot];
                    acc[slot] = alpha * old + beta * static_cast<float>(vp[d]);
                }
            }
        } else {
            for (int d = lane; d < dv; d += 64) {
                const float old = accum[d];
                accum[d] = alpha * old + beta * static_cast<float>(vp[d]);
            }
        }
        m = new_m;
    }

    scalar_t* op = out + (static_cast<int64_t>(row) * num_q_heads + h) * dv;
    if constexpr (ACC_SLOTS > 0) {
        #pragma unroll
        for (int slot = 0; slot < ACC_SLOTS; ++slot) {
            const int d = lane + 64 * slot;
            if constexpr (FULL_DV) {
                op[d] = static_cast<scalar_t>(acc[slot] / denom);
            } else if (d < dv) op[d] = static_cast<scalar_t>(acc[slot] / denom);
        }
    } else {
        for (int d = lane; d < dv; d += 64)
            op[d] = static_cast<scalar_t>(accum[d] / denom);
    }
}

} // namespace

void extend_attention_out(
    torch::Tensor q_extend,
    torch::Tensor k_extend,
    torch::Tensor v_extend,
    torch::Tensor k_buffer,
    torch::Tensor v_buffer,
    torch::Tensor qo_indptr,
    torch::Tensor kv_indptr,
    torch::Tensor kv_indices,
    torch::Tensor out,
    bool causal,
    double scale) {
    TORCH_CHECK(q_extend.is_cuda(), "attention tensors must be on the accelerator");
    TORCH_CHECK(q_extend.is_contiguous() && k_extend.is_contiguous() && v_extend.is_contiguous() &&
                k_buffer.is_contiguous() && v_buffer.is_contiguous() && out.is_contiguous(),
                "attention tensors must be contiguous");
    TORCH_CHECK(qo_indptr.scalar_type() == torch::kInt32 && kv_indptr.scalar_type() == torch::kInt32,
                "indptr tensors must be int32");
    TORCH_CHECK(kv_indices.scalar_type() == torch::kInt64, "kv_indices must be int64");
    TORCH_CHECK(q_extend.dim() == 3 && k_extend.dim() == 3 && v_extend.dim() == 3,
                "invalid attention tensor ranks");
    const int total = static_cast<int>(q_extend.size(0));
    const int hq = static_cast<int>(q_extend.size(1));
    const int hkv = static_cast<int>(k_extend.size(1));
    const int dq = static_cast<int>(q_extend.size(2));
    const int dv = static_cast<int>(v_extend.size(2));
    TORCH_CHECK(hkv > 0 && hq % hkv == 0, "query heads must divide evenly into KV heads");
    TORCH_CHECK(k_extend.size(2) == dq && k_buffer.size(1) == hkv && v_buffer.size(1) == hkv,
                "incompatible Q/K/V dimensions");
    const int nseq = static_cast<int>(qo_indptr.size(0)) - 1;
    auto stream = at::cuda::getCurrentCUDAStream(q_extend.device().index());
    dim3 grid(total, hq, 1);
    dim3 block(64);
    const size_t shared_bytes = static_cast<size_t>(dv) * sizeof(float);

#define LAUNCH_DQ(SLOTS, BYTES, DQ, FULL) \
        extend_attention_kernel<scalar_t, SLOTS, DQ, FULL><<<grid, block, BYTES, stream.stream()>>>( \
            q_extend.data_ptr<scalar_t>(), k_extend.data_ptr<scalar_t>(), \
            v_extend.data_ptr<scalar_t>(), k_buffer.data_ptr<scalar_t>(), \
            v_buffer.data_ptr<scalar_t>(), qo_indptr.data_ptr<int32_t>(), \
            kv_indptr.data_ptr<int32_t>(), kv_indices.data_ptr<int64_t>(), \
            out.data_ptr<scalar_t>(), total, hq, hkv, dq, dv, nseq, causal, \
            static_cast<float>(scale))
#define LAUNCH_ACC(SLOTS, BYTES, FULL) do { \
        if (dq == 64) { LAUNCH_DQ(SLOTS, BYTES, 64, FULL); } \
        else if (dq == 128) { LAUNCH_DQ(SLOTS, BYTES, 128, FULL); } \
        else if (dq == 256) { LAUNCH_DQ(SLOTS, BYTES, 256, FULL); } \
        else { LAUNCH_DQ(SLOTS, BYTES, 0, FULL); } \
    } while (0)

    AT_DISPATCH_FLOATING_TYPES_AND2(torch::kHalf, torch::kBFloat16,
                                    q_extend.scalar_type(), "extend_attention_hip", [&] {
        if (dv <= 64) {
            if (dv == 64) { LAUNCH_ACC(1, 0, true); }
            else { LAUNCH_ACC(1, 0, false); }
        } else if (dv <= 128) {
            if (dv == 128) { LAUNCH_ACC(2, 0, true); }
            else { LAUNCH_ACC(2, 0, false); }
        } else if (dv <= 256) {
            if (dv == 256) { LAUNCH_ACC(4, 0, true); }
            else { LAUNCH_ACC(4, 0, false); }
        } else {
            LAUNCH_ACC(0, shared_bytes, false);
        }
    });
#undef LAUNCH_ACC
#undef LAUNCH_DQ
    AT_CUDA_CHECK(hipGetLastError());
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Variable-length attention mixing the extend (incremental prefill) phase with a prefix segment (GQA, causal optional).

    Inside the batch each sequence's KV has two segments: the prefix segment is
    already written into the KV pool (k_buffer / v_buffer) and is addressed
    token by token indirectly through the row ids in kv_indices; the extend
    segment holds the tokens newly computed in this step, whose K/V are stored
    contiguously per token in k_extend / v_extend, with the query in q_extend in
    the same order. For sequence i let E_i = qo_indptr[i+1] - qo_indptr[i]
    (number of extend tokens) and P_i = kv_indptr[i+1] - kv_indptr[i] (number of
    prefix tokens). For the t-th query of the extend segment (global position
    T = P_i + t, row s = qo_indptr[i] + t) and query head h (its KV head is
    g = h // query_group_size, query_group_size = num_q_heads // num_kv_heads):
      K_full = concat(k_buffer[kv_indices[kv_indptr[i]:kv_indptr[i+1]]][:, g, :],
                      k_extend[qo_indptr[i]:qo_indptr[i+1]][:, g, :])   P_i + E_i rows
      V_full likewise (taking the head_dim_v head dimension)
      logits[j] = sm_scale * <q_extend[s, h, :], K_full[j]>
                 (sm_scale defaults to 1/sqrt(head_dim_q))
      visibility: the whole prefix is visible; the extend segment with causal=True
      sees only tokens with global position <= T (that is, the first t+1 extend
      tokens), and with causal=False everything is visible
      p = softmax(logits) (numerically stable online implementation)
      out[s, h, :] = sum_j p[j] * V_full[j]
    Under causal the query's own position is always visible, so the softmax
    denominator is always > 0. K's head dimension equals Q's head dimension
    head_dim_q; V's head dimension head_dim_v may differ from it.

    Input/output specification (evaluation dtype is float16 / bfloat16, all tensors contiguous):
      q_extend   evaluation dtype (total_extend, num_q_heads, head_dim_q)
      k_extend   evaluation dtype (total_extend, num_kv_heads, head_dim_q)
      v_extend   evaluation dtype (total_extend, num_kv_heads, head_dim_v)
      k_buffer   evaluation dtype (num_pool, num_kv_heads, head_dim_q)   prefix K pool
      v_buffer   evaluation dtype (num_pool, num_kv_heads, head_dim_v)   prefix V pool
      qo_indptr  int32 (num_seqs + 1) -- prefix sum of extend lengths (each segment >= 1)
      kv_indptr  int32 (num_seqs + 1) -- prefix sum of prefix lengths (each segment >= 0, may be all 0)
      kv_indices int32 (total_prefix) -- pool row ids of the prefix tokens, any
                 permutation is allowed; num_pool may exceed total_prefix, and the
                 unreferenced pool rows are garbage data that must not take part
                 in the computation
      returns out evaluation dtype (total_extend, num_q_heads, head_dim_v)

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - The evaluator casts every input tensor to fp32 before passing it to
        forward; the indptrs and pool row ids are small integers that fp32
        represents exactly, so .to(torch.int32) / .to(torch.long) at the entry
        recovers them losslessly.
      - The maximum extend length is not an input: the upper bound of the grid's
        third dimension can be derived inside forward from qo_indptr, or
        total_extend can be used directly as a conservative bound (inside the
        kernel, mask the out-of-range query rows with each sequence's
        cur_seq_len_extend).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: prefix+extend mixed, variable-length (ragged) batch, GQA,
    causal/non-causal, Q/K/V head-dimension relation as above; no custom mask,
    no sliding window, no attention sink, no KV dequantization scale, the logit
    cap is not enabled (always 0), and the prefix segment gets no separate
    prefill-kernel fusion path -- those variants are left for later standalone
    tasks.
    """
    def __init__(self, causal: bool = True, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.causal = bool(causal)
        self.sm_scale = None if sm_scale is None else float(sm_scale)
        # <<<END_IMPROVE>>>

    def forward(self, q_extend, k_extend, v_extend, k_buffer, v_buffer, qo_indptr, kv_indptr, kv_indices):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        qo_indptr = qo_indptr.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        kv_indptr = kv_indptr.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        kv_indices = kv_indices.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        total_extend, H_Q, Dq = q_extend.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        H_KV = k_extend.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        Dv = v_extend.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        scale = self.sm_scale if self.sm_scale is not None else 1.0 / math.sqrt(Dq)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        B = qo_indptr.shape[0] - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty((total_extend, H_Q, Dv), dtype=q_extend.dtype,
                          device=q_extend.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        _pyramidkernel_get_extension().extend_attention_out(
                    q_extend, k_extend, v_extend, k_buffer, v_buffer,
                    qo_indptr, kv_indptr, kv_indices, out, self.causal, scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
