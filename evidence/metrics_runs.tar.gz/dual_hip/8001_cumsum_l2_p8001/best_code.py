import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p8001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor prefix_scan_hip(torch::Tensor x, int64_t dim);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("prefix_scan", &prefix_scan_hip);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

__device__ __forceinline__ float scan_tile(float value, float* shared) {
    const int t = threadIdx.x;
    shared[t] = value;
    __syncthreads();
    #pragma unroll
    for (int offset = 1; offset < 256; offset <<= 1) {
        float previous = t >= offset ? shared[t - offset] : 0.0f;
        __syncthreads();
        value += previous;
        shared[t] = value;
        __syncthreads();
    }
    return value;
}

template <typename T>
__global__ void strided_chain_prefix(const T* __restrict__ x, T* __restrict__ out, int length,
                                     int inner, int chains) {
    const int c = blockIdx.x * blockDim.x + threadIdx.x;
    if (c >= chains) return;
    const int base = (c / inner) * length * inner + c % inner;
    float accumulator = 0.0f;
    int j = 0;
    for (; j + 15 < length; j += 16) {
        float v0 = static_cast<float>(x[base + j * inner]);
        float v1 = static_cast<float>(x[base + (j + 1) * inner]);
        float v2 = static_cast<float>(x[base + (j + 2) * inner]);
        float v3 = static_cast<float>(x[base + (j + 3) * inner]);
        float v4 = static_cast<float>(x[base + (j + 4) * inner]);
        float v5 = static_cast<float>(x[base + (j + 5) * inner]);
        float v6 = static_cast<float>(x[base + (j + 6) * inner]);
        float v7 = static_cast<float>(x[base + (j + 7) * inner]);
        float v8 = static_cast<float>(x[base + (j + 8) * inner]);
        float v9 = static_cast<float>(x[base + (j + 9) * inner]);
        float v10 = static_cast<float>(x[base + (j + 10) * inner]);
        float v11 = static_cast<float>(x[base + (j + 11) * inner]);
        float v12 = static_cast<float>(x[base + (j + 12) * inner]);
        float v13 = static_cast<float>(x[base + (j + 13) * inner]);
        float v14 = static_cast<float>(x[base + (j + 14) * inner]);
        float v15 = static_cast<float>(x[base + (j + 15) * inner]);
        accumulator += v0;
        out[base + j * inner] = static_cast<T>(accumulator);
        accumulator += v1;
        out[base + (j + 1) * inner] = static_cast<T>(accumulator);
        accumulator += v2;
        out[base + (j + 2) * inner] = static_cast<T>(accumulator);
        accumulator += v3;
        out[base + (j + 3) * inner] = static_cast<T>(accumulator);
        accumulator += v4;
        out[base + (j + 4) * inner] = static_cast<T>(accumulator);
        accumulator += v5;
        out[base + (j + 5) * inner] = static_cast<T>(accumulator);
        accumulator += v6;
        out[base + (j + 6) * inner] = static_cast<T>(accumulator);
        accumulator += v7;
        out[base + (j + 7) * inner] = static_cast<T>(accumulator);
        accumulator += v8;
        out[base + (j + 8) * inner] = static_cast<T>(accumulator);
        accumulator += v9;
        out[base + (j + 9) * inner] = static_cast<T>(accumulator);
        accumulator += v10;
        out[base + (j + 10) * inner] = static_cast<T>(accumulator);
        accumulator += v11;
        out[base + (j + 11) * inner] = static_cast<T>(accumulator);
        accumulator += v12;
        out[base + (j + 12) * inner] = static_cast<T>(accumulator);
        accumulator += v13;
        out[base + (j + 13) * inner] = static_cast<T>(accumulator);
        accumulator += v14;
        out[base + (j + 14) * inner] = static_cast<T>(accumulator);
        accumulator += v15;
        out[base + (j + 15) * inner] = static_cast<T>(accumulator);
    }
    for (; j < length; ++j) {
        accumulator += static_cast<float>(x[base + j * inner]);
        out[base + j * inner] = static_cast<T>(accumulator);
    }
}

template <typename T>
__global__ void short_contiguous_prefix(const T* x, T* out, int length) {
    __shared__ float wave_totals[256];
    __shared__ float carry;
    const int t = threadIdx.x;
    const int lane = t % warpSize;
    const int wave = t / warpSize;
    const int waves = 256 / warpSize;
    const int base = blockIdx.x * length;
    if (t == 0) carry = 0.0f;
    __syncthreads();
    for (int segment = 0; segment < length; segment += 256) {
        const int j = segment + t;
        const float preceding = carry;
        float value = j < length ? static_cast<float>(x[base + j]) : 0.0f;
        for (int offset = 1; offset < warpSize; offset <<= 1) {
            float previous = __shfl_up(value, offset, warpSize);
            if (lane >= offset) value += previous;
        }
        if (lane == warpSize - 1) wave_totals[wave] = value;
        __syncthreads();
        if (wave == 0) {
            float total = lane < waves ? wave_totals[lane] : 0.0f;
            for (int offset = 1; offset < warpSize; offset <<= 1) {
                float previous = __shfl_up(total, offset, warpSize);
                if (lane >= offset) total += previous;
            }
            if (lane < waves) wave_totals[lane] = total;
        }
        __syncthreads();
        if (wave > 0) value += wave_totals[wave - 1];
        value += preceding;
        if (j < length) out[base + j] = static_cast<T>(value);
        if (t == 255) carry = value;
        __syncthreads();
    }
}

template <typename T, bool Direct>
__global__ void local_prefix(const T* x, T* out, float* partial,
                             float* totals, int length, int inner, int tiles) {
    __shared__ float shared[256];
    const int chain = blockIdx.x / tiles;
    const int tile = blockIdx.x % tiles;
    const int j = tile * 256 + threadIdx.x;
    const int base = (chain / inner) * length * inner + chain % inner;
    float value = j < length ? static_cast<float>(x[base + j * inner]) : 0.0f;
    value = scan_tile(value, shared);
    if (j < length) {
        const int index = base + j * inner;
        if (Direct) out[index] = static_cast<T>(value);
        else partial[index] = value;
    }
    if (!Direct && threadIdx.x == 255)
        totals[chain * tiles + tile] = value;
}

__global__ void prefix_totals(float* totals, int tiles) {
    __shared__ float shared[256];
    const int t = threadIdx.x;
    const int base = blockIdx.x * tiles;
    float value = t < tiles ? totals[base + t] : 0.0f;
    value = scan_tile(value, shared);
    if (t < tiles) totals[base + t] = value;
}

template <typename T>
__global__ void apply_offsets(const float* partial, const float* totals,
                              T* out, int count, int length, int inner, int tiles) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= count) return;
    const int j = (i / inner) % length;
    const int chain = (i / (length * inner)) * inner + i % inner;
    const int tile = j / 256;
    float value = partial[i];
    if (tile > 0) value += totals[chain * tiles + tile - 1];
    out[i] = static_cast<T>(value);
}

torch::Tensor prefix_scan_hip(torch::Tensor x, int64_t dim) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous(), "expected contiguous device input");
    TORCH_CHECK(dim >= -x.dim() && dim < x.dim(), "invalid scan dimension");
    c10::cuda::CUDAGuard guard(x.device());
    if (dim < 0) dim += x.dim();
    const int length = x.size(dim);
    TORCH_CHECK(length >= 1 && length <= 65536, "invalid scan length");
    int inner = 1;
    for (int d = dim + 1; d < x.dim(); ++d) inner *= x.size(d);
    const int count = x.numel();
    const int chains = count / length;
    const int tiles = (length + 255) / 256;
    const bool use_short = inner == 1 && length <= 1024;
    const bool use_strided = inner >= 64 && chains >= 256 && length <= 1024;
    auto out = torch::empty(x.sizes(), x.options());
    torch::Tensor partial, totals;
    if (!use_strided && !use_short && tiles > 1) {
        partial = torch::empty(x.sizes(), x.options().dtype(torch::kFloat32));
        totals = torch::empty({chains, tiles}, x.options().dtype(torch::kFloat32));
    }
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                  x.scalar_type(), "prefix_scan_hip", [&] {
        if (use_strided) {
            strided_chain_prefix<scalar_t><<<(chains + 255) / 256, 256, 0, stream>>>(
                x.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), length, inner, chains);
            C10_CUDA_KERNEL_LAUNCH_CHECK();
        } else if (use_short) {
            short_contiguous_prefix<scalar_t><<<chains, 256, 0, stream>>>(
                x.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), length);
            C10_CUDA_KERNEL_LAUNCH_CHECK();
        } else if (tiles == 1) {
            local_prefix<scalar_t, true><<<chains, 256, 0, stream>>>(
                x.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), nullptr, nullptr,
                length, inner, tiles);
            C10_CUDA_KERNEL_LAUNCH_CHECK();
        } else {
            local_prefix<scalar_t, false><<<chains * tiles, 256, 0, stream>>>(
                x.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), partial.data_ptr<float>(),
                totals.data_ptr<float>(), length, inner, tiles);
            C10_CUDA_KERNEL_LAUNCH_CHECK();
            prefix_totals<<<chains, 256, 0, stream>>>(totals.data_ptr<float>(), tiles);
            C10_CUDA_KERNEL_LAUNCH_CHECK();
            apply_offsets<scalar_t><<<(count + 255) / 256, 256, 0, stream>>>(
                partial.data_ptr<float>(), totals.data_ptr<float>(), out.data_ptr<scalar_t>(),
                count, length, inner, tiles);
            C10_CUDA_KERNEL_LAUNCH_CHECK();
        }
    });
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Cumsum (inclusive prefix sum): a sequential accumulation along a given
    dimension.

    Operator definition: for an n-dimensional input x and the scan dimension
    `dim`, the output out has the same shape as x:
        out[i_0, ..., i_k, ...] = sum_{j <= i_dim} x[i_0, ..., j, ...]
    i.e. an inclusive prefix sum along dimension `dim` (including the current
    element), with every other dimension accumulating independently per chain.
    The __init__ parameter `dim` selects the scan dimension (torch convention:
    non-negative counts from 0, negative counts from the end, e.g. -1 means the
    last dimension), defaulting to 2.

    Numeric contract: accumulation always happens in float32 -- float16/bfloat16
    inputs are first cast to float32, accumulated, then cast back to the input
    dtype (matching the compute-in-fp32 convention of production scan
    libraries).

    Input/output specification:
        x     float32 / float16 / bfloat16, contiguous, ndim in [1, 4],
              every dimension >= 1, scan dimension length L in [1, 65536],
              total element count <= 2^25; values are ordinary randn magnitude
              (no inf/NaN)
        out   a single tensor, same shape / dtype as x, contiguous; forward must
              return a single tensor (the evaluator compares .shape / allclose
              on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (fp16/bf16 -> fp32 is lossless); the offline final audit passes inputs
        natively in their declared dtype -- the implementation must be correct
        for both.

    Boundary behaviour: when L=1, out equals x (cast back to the input dtype);
    non-power-of-two L, prime lengths, and axes longer than a single block's
    capacity must all be handled correctly with masking plus a blocked scan, and
    out-of-range lanes must not contribute to the prefix sum; a negative `dim`
    follows the torch convention.

    Implementation constraints (violations are scored as failures):
        - The core scan (prefix sum) must be handwritten with a HIP kernel
          inside the submitted file; calling any library-level scan primitive is
          forbidden, as is bypassing via mathematically equivalent paths such as
          FFT / matrix multiplication / convolution.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate in float32 and cast the output back to the input dtype.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.cumsum / .cumsum( / torch.cumulative_sum / .cumulative_sum( /
    aten.cumsum / aten.cumulative_sum /
    torch.fft / torch.matmul / torch.mm / torch.bmm / torch.einsum /
    conv1d( / numpy / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, dim: int = 2):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.dim = int(dim)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        ndim = x.dim()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert -ndim <= self.dim < ndim, "dim must point at an existing dimension of the input"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        out = _pyramidkernel_get_extension().prefix_scan(x, self.dim)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return out
        # <<<END_IMPROVE>>>
