import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1012_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void attention_out(torch::Tensor q, torch::Tensor k, torch::Tensor v, torch::Tensor cq, torch::Tensor ck, torch::Tensor causal, torch::Tensor out, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("attention_out", &attention_out);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

struct Strides { int64_t a,b,c; };

template<class T, int FIXED_D=0, int NATIVE_WAVE=64>
__global__ void attention_kernel(const T* q, const T* k, const T* v,
 const int* cq, const int* ck, const int* causal, T* out,
 int B, int H, int HK, int D, float scale,
 Strides qs, Strides ks, Strides vs, Strides os, int64_t work) {
    int lane=threadIdx.x%warpSize;
    int64_t index=int64_t(blockIdx.x)*4+threadIdx.x/warpSize;
    if(index>=work) return;
    int row=index/H, h=index%H;
    int lo=0, hi=B;
    while(lo+1<hi) { int mid=(lo+hi)/2; if(cq[mid]<=row) lo=mid; else hi=mid; }
    int start=ck[lo], n=ck[lo+1]-start;
    if(*causal) n=row-cq[lo]+n-(cq[lo+1]-cq[lo])+1;
    int kh=h/(H/HK);
    constexpr int FRAGMENTS=FIXED_D ? (FIXED_D+NATIVE_WAVE-1)/NATIVE_WAVE : 8;
    const int dim=FIXED_D ? FIXED_D : D;
    float query[FRAGMENTS], acc[FRAGMENTS];
    #pragma unroll
    for(int r=0;r<FRAGMENTS;++r) {
        int d=lane+r*warpSize;
        query[r]=d<dim ? float(q[row*qs.a+h*qs.b+d*qs.c]) : 0.0f;
        acc[r]=0.0f;
    }
    float maximum=-INFINITY, denom=0.0f;
    for(int j=0;j<n;++j) {
        float s=0.0f;
        #pragma unroll
        for(int r=0;r<FRAGMENTS;++r) {
            int d=lane+r*warpSize;
            if(d<dim) s=fmaf(query[r],float(k[(start+j)*ks.a+kh*ks.b+d*ks.c]),s);
        }
        for(int step=warpSize/2;step;step/=2) s+=__shfl_down(s,step,warpSize);
        s=__shfl(s,0,warpSize)*scale;
        float nm=fmaxf(maximum,s);
        float a=expf(maximum-nm), p=expf(s-nm);
        denom=a*denom+p;
        maximum=nm;
        #pragma unroll
        for(int r=0;r<FRAGMENTS;++r) {
            int d=lane+r*warpSize;
            if(d<dim) acc[r]=fmaf(p,float(v[(start+j)*vs.a+kh*vs.b+d*vs.c]),a*acc[r]);
        }
    }
    #pragma unroll
    for(int r=0;r<FRAGMENTS;++r) {
        int d=lane+r*warpSize;
        if(d<dim) out[row*os.a+h*os.b+d*os.c]=T(acc[r]/denom);
    }
}

void attention_out(torch::Tensor q, torch::Tensor k, torch::Tensor v,
 torch::Tensor cq, torch::Tensor ck, torch::Tensor causal, torch::Tensor out, double scale) {
    TORCH_CHECK(q.is_cuda(), "q must be on GPU");
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim()==3 && k.dim()==3 && v.dim()==3, "expected rank 3");
    TORCH_CHECK(q.size(2)>=1 && q.size(2)<=256 && k.size(2)==q.size(2), "invalid dimension");
    TORCH_CHECK(k.sizes()==v.sizes() && out.sizes()==q.sizes(), "shape mismatch");
    TORCH_CHECK(k.size(1)>0 && q.size(1)%k.size(1)==0, "invalid GQA");
    for(auto x : {k,v,out}) {
        TORCH_CHECK(x.device()==q.device() && x.scalar_type()==q.scalar_type(), "dtype/device mismatch");
    }
    for(auto x : {cq,ck,causal}) {
        TORCH_CHECK(x.device()==q.device() && x.scalar_type()==at::kInt && x.is_contiguous(), "invalid metadata");
    }
    TORCH_CHECK(cq.numel()>=2 && cq.numel()==ck.numel() && causal.numel()==1, "invalid metadata shapes");
    TORCH_CHECK(q.scalar_type()==at::kHalf || q.scalar_type()==at::kBFloat16 || q.scalar_type()==at::kFloat, "expected half, bfloat16 or float32");
    auto strides=[](torch::Tensor x) { return Strides{x.stride(0),x.stride(1),x.stride(2)}; };
    auto stream=at::cuda::getCurrentCUDAStream();
    int64_t work=q.size(0)*q.size(1);
    if(!work) return;
    int wave=at::cuda::getDeviceProperties(q.get_device())->warpSize;
    int64_t blocks=(work+3)/4;
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, q.scalar_type(), "attention_out", [&] {
        if(q.size(2)==64 && wave==64) {
            attention_kernel<scalar_t,64,64><<<blocks,4*wave,0,stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                cq.data_ptr<int>(), ck.data_ptr<int>(), causal.data_ptr<int>(), out.data_ptr<scalar_t>(),
                cq.numel()-1, q.size(1), k.size(1), q.size(2), float(scale),
                strides(q),strides(k),strides(v),strides(out),work);
        } else if(q.size(2)==64 && wave==32) {
            attention_kernel<scalar_t,64,32><<<blocks,4*wave,0,stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                cq.data_ptr<int>(), ck.data_ptr<int>(), causal.data_ptr<int>(), out.data_ptr<scalar_t>(),
                cq.numel()-1, q.size(1), k.size(1), q.size(2), float(scale),
                strides(q),strides(k),strides(v),strides(out),work);
        } else {
            attention_kernel<scalar_t><<<blocks,4*wave,0,stream>>>(
                q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
                cq.data_ptr<int>(), ck.data_ptr<int>(), causal.data_ptr<int>(), out.data_ptr<scalar_t>(),
                cq.numel()-1, q.size(1), k.size(1), q.size(2), float(scale),
                strides(q),strides(k),strides(v),strides(out),work);
        }
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Variable-length (varlen) FlashAttention v2 forward pass: dense Q/K/V is
    segmented by cu_seqlens and each segment computes scaled dot-product attention
    independently, supporting MHA/GQA and a causal
    mask.

    Mathematical definition: for segment b of the batch (let
    L_q = cu_seqlens_q[b+1]-cu_seqlens_q[b],
    L_k = cu_seqlens_k[b+1]-cu_seqlens_k[b]; the task constrains 0 < L_q <= L_k, and
    g = num_q_heads // num_kv_heads):
      scores[h,i,j] = sm_scale * <q[start_q+i,h,:], k[start_k+j,h//g,:]>
      with causal=1 a bottom-right-aligned causal mask is applied: positions with
      j > i + (L_k - L_q) are set to -inf (i.e. query position i only attends to key
      positions j <= i + L_k - L_q); with causal=0 no mask is applied.
      p[h,i,:] = softmax_j(scores[h,i,:])
      out[start_q+i,h,:] = sum_j p[h,i,j] * v[start_k+j,h//g,:]
    The softmax uses a numerically stable formulation; intermediates are accumulated
    in float32 and the output is cast back to the input dtype.
    Boundary behaviour: the task guarantees L_q >= 1 for every segment, so the
    softmax denominator is always positive and no row is fully masked; segments
    other than the last do not affect each other.

    Input/output specification:
      q            [total_q, num_q_heads, head_dim]  float16/bfloat16
      k, v         [total_k, num_kv_heads, head_dim] same dtype as q
      cu_seqlens_q [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_q
      cu_seqlens_k [num_seqs+1] int32, monotonically non-decreasing, first element 0,
                   last element total_k
      causal       0-dim int32 tensor, 1 = causal mask, 0 = no mask
      out          [total_q, num_q_heads, head_dim], same dtype as q
    Global constraints: num_q_heads is an integer multiple of num_kv_heads (GQA;
    equality means MHA); 1 <= head_dim <= 256; for every sequence
    0 < L_q <= L_k.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: varlen forward, non-quantized inputs, no bias/ALiBi, no dropout, no
    LSE output.
    """
    def __init__(self, head_dim: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, cu_seqlens_q, cu_seqlens_k, causal):
        # <<<IMPROVE:forward_stmt_1>>>
        cu_seqlens_q = cu_seqlens_q.to(device=q.device, dtype=torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        cu_seqlens_k = cu_seqlens_k.to(device=q.device, dtype=torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        causal = causal.to(device=q.device, dtype=torch.int32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        nheads_q = q.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        nheads_k = k.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        group = nheads_q // nheads_k
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert nheads_q == nheads_k * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        num_seqs = int(cu_seqlens_q.numel()) - 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _pyramidkernel_get_extension().attention_out(q, k, v, cu_seqlens_q, cu_seqlens_k, causal, out, self.sm_scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
