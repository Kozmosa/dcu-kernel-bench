import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4018_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor quant_forward(torch::Tensor x, c10::optional<torch::Tensor> scale, int64_t mode, bool fp8);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("quant_forward", &quant_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

__device__ float block_max(float v) {
    __shared__ float waves[32];
    int lane = threadIdx.x % warpSize;
    int wave = threadIdx.x / warpSize;
    for (int d = warpSize / 2; d; d /= 2)
        v = fmaxf(v, __shfl_down(v, d));
    if (lane == 0) waves[wave] = v;
    __syncthreads();
    v = threadIdx.x < blockDim.x / warpSize ? waves[threadIdx.x] : 0.0f;
    if (wave == 0) {
        for (int d = warpSize / 2; d; d /= 2)
            v = fmaxf(v, __shfl_down(v, d));
        if (lane == 0) waves[0] = v;
    }
    __syncthreads();
    return waves[0];
}

__device__ float row_max(float v) {
    __shared__ float waves[32];
    int lane = threadIdx.x % warpSize;
    int wave = threadIdx.x / warpSize;
    for (int d = warpSize / 2; d; d /= 2)
        v = fmaxf(v, __shfl_down(v, d));
    if (lane == 0) waves[wave] = v;
    __syncthreads();
    v = lane < blockDim.x / warpSize ? waves[lane] : 0.0f;
    for (int d = warpSize / 2; d; d /= 2)
        v = fmaxf(v, __shfl_down(v, d));
    return __shfl(v, 0);
}

template<bool FP8> __device__ float code(float v) {
    if (!FP8) return nearbyintf(v);
    float a = fabsf(v);
    int exponent = int((__float_as_uint(a) >> 23) & 255) - 127;
    int spacing_exp = max(exponent - 3, -9);
    float spacing = __uint_as_float(unsigned(spacing_exp + 127) << 23);
    float rounded = nearbyintf(a / spacing) * spacing;
    return copysignf(rounded, v);
}

template<bool FP8> __global__ void narrow_rows_kernel(const float* x, float* out, int64_t rows, int64_t cols) {
    int lane = threadIdx.x % warpSize;
    int wave = threadIdx.x / warpSize;
    int64_t r = int64_t(blockIdx.x) * (blockDim.x / warpSize) + wave;
    if (r >= rows) return;
    int64_t base = r * cols;
    float a = 0.0f;
    for (int64_t j = lane; j < cols; j += warpSize)
        a = fmaxf(a, fabsf(x[base + j]));
    for (int d = warpSize / 2; d; d /= 2)
        a = fmaxf(a, __shfl_down(a, d));
    a = __shfl(a, 0);
    float s = fmaxf(a, 1.0e-10f) * (FP8 ? (1.0f / 448.0f) : (1.0f / 127.0f));
    float inv = __fdiv_rn(1.0f, s);
    if (lane == 0) out[rows * cols + r] = s;
    for (int64_t j = lane; j < cols; j += warpSize)
        out[base + j] = code<FP8>(x[base + j] * inv);
}

template<bool FP8> __global__ void rows_kernel(const float* x, float* out, int64_t rows, int64_t cols) {
    int64_t r = blockIdx.x;
    int64_t base = r * cols;
    float a = 0.0f;
    for (int64_t j = threadIdx.x; j < cols; j += blockDim.x)
        a = fmaxf(a, fabsf(x[base + j]));
    a = row_max(a);
    // Match the float32 scalar-divisor operation used for the scale.
    float s = fmaxf(a, 1.0e-10f) * (FP8 ? (1.0f / 448.0f) : (1.0f / 127.0f));
    float inv = __fdiv_rn(1.0f, s);
    if (threadIdx.x == 0) out[rows * cols + r] = s;
    for (int64_t j = threadIdx.x; j < cols; j += blockDim.x)
        out[base + j] = code<FP8>(x[base + j] * inv);
}

__global__ void partial_max(const float* x, float* partial, int64_t n) {
    float a = 0.0f;
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x; i < n; i += int64_t(gridDim.x) * blockDim.x)
        a = fmaxf(a, fabsf(x[i]));
    a = block_max(a);
    if (threadIdx.x == 0) partial[blockIdx.x] = a;
}

template<bool FP8> __global__ void final_scale(const float* partial, float* s, int n) {
    float a = 0.0f;
    for (int i = threadIdx.x; i < n; i += blockDim.x) a = fmaxf(a, partial[i]);
    a = block_max(a);
    if (threadIdx.x == 0) *s = a * (FP8 ? (1.0f / 448.0f) : (1.0f / 127.0f));
}

template<bool FP8> __global__ void tensor_codes(const float* x, const float* scale, float* out, int64_t n) {
    float s = *scale;
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x; i < n; i += int64_t(gridDim.x) * blockDim.x)
        out[i] = code<FP8>(__fdiv_rn(x[i], s));
    if (blockIdx.x == 0 && threadIdx.x == 0) out[n] = s;
}

template<bool FP8> void launch_quant(torch::Tensor x, c10::optional<torch::Tensor> scale, int64_t mode, torch::Tensor out, hipStream_t stream) {
    int64_t n = x.numel();
    const float* xp = x.data_ptr<float>();
    float* op = out.data_ptr<float>();
    if (mode == 2) {
        if (x.size(1) >= 1 && x.size(1) <= 512) {
            hipDeviceProp_t props;
            TORCH_CHECK(hipGetDeviceProperties(&props, x.get_device()) == hipSuccess, "Unable to query HIP device properties");
            int rows_per_block = 256 / props.warpSize;
            int64_t blocks = (x.size(0) + rows_per_block - 1) / rows_per_block;
            if (blocks > 0)
                narrow_rows_kernel<FP8><<<blocks, 256, 0, stream>>>(xp, op, x.size(0), x.size(1));
        } else {
            rows_kernel<FP8><<<x.size(0), 256, 0, stream>>>(xp, op, x.size(0), x.size(1));
        }
        return;
    }
    int blocks = int(std::min<int64_t>((n + 255) / 256, 1024));
    if (mode == 0) {
        tensor_codes<FP8><<<blocks, 256, 0, stream>>>(xp, scale->data_ptr<float>(), op, n);
    } else {
        auto partial = torch::empty({blocks}, x.options());
        partial_max<<<blocks, 256, 0, stream>>>(xp, partial.data_ptr<float>(), n);
        final_scale<FP8><<<1, 256, 0, stream>>>(partial.data_ptr<float>(), op + n, blocks);
        tensor_codes<FP8><<<blocks, 256, 0, stream>>>(xp, op + n, op, n);
    }
}

torch::Tensor quant_forward(torch::Tensor x, c10::optional<torch::Tensor> scale, int64_t mode, bool fp8) {
    c10::cuda::CUDAGuard guard(x.device());
    TORCH_CHECK(x.is_cuda() && x.scalar_type() == torch::kFloat32 && x.is_contiguous());
    auto out = torch::empty({x.numel() + (mode == 2 ? x.size(0) : 1)}, x.options());
    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    if (fp8) launch_quant<true>(x, scale, mode, out, stream);
    else launch_quant<false>(x, scale, mode, out, stream);
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    fp8(e4m3)/int8 quantization kernel family: static per-tensor / dynamic
    per-tensor / dynamic per-token.

    The input x is a contiguous 2D float tensor (rows, cols); the __init__
    hyperparameter mode selects the quantization mode and quant_dtype selects
    the target dtype (int8 or fp8 e4m3). Intermediate arithmetic is float32
    throughout. Definitions per mode (dtype_max: 127 for int8, 448 for fp8
    e4m3):

      static_per_tensor (the scale is given by the input):
          q_i  = x_i / scale                    # fp32 division, scale is (1,) fp32
          y_i  = int8: round_half_even(q_i); fp8: rne_e4m3(q_i)
          scale_out = scale (passed through as is, segment length 1)
      dynamic_per_tensor (single scale for the whole tensor, no division-by-zero guard):
          amax = max_i |x_i|                    # fp32
          s    = amax / dtype_max
          y_i  = int8: round_half_even(x_i / s); fp8: rne_e4m3(x_i / s)
          scale_out = s (segment length 1)
      dynamic_per_token (one scale per row, with a division-by-zero guard):
          amax_r = max_j |x_rj|                 # fp32
          s_r    = max(amax_r, 1e-10) / dtype_max
          y_rj   = int8: round_half_even(x_rj * (1/s_r)); fp8: rne_e4m3(x_rj * (1/s_r))
          scale_out = s (segment length rows, row-major)

    round_half_even is banker's rounding (0.5 -> 0, -0.5 -> 0, 1.5 -> 2,
    126.5 -> 126), consistent with torch.round; rne_e4m3 is rounding to the
    nearest representable e4m3 value (equivalent to .to(float8_e4m3fn)).
    Boundary behaviour: an all-zero row under per-token has amax_r = 0, the
    1e-10 guard gives s_r = 1e-10/dtype_max and every code word of that row is
    0 -- the output must be finite, producing NaN/Inf is a wrong
    implementation; per-tensor modes have no division-by-zero guard (the input
    contract guarantees amax > 0).

    Input/output specification:
      x     float16/bfloat16, contiguous (rows, cols); the evaluator casts the
            input to fp32 before passing it in -- fp16/bf16 values are exact in
            fp32, so the quantization semantics are unchanged
      scale used only in static_per_tensor mode: (1,) float32 positive number
      out   a 1-D float32 tensor of length rows*cols + S (single-tensor output
            protocol, two segments packed):
            out[:rows*cols] = quantized code words promoted to float32 (int8
                              are integers in [-127,127]; fp8 are exact e4m3
                              values)
            out[rows*cols:] = the scale segment: per-token gives rows row
                              scales (row-major), per-tensor/static gives 1
                              tensor scale
      __init__ hyperparameters: mode (str, default "dynamic_per_token"),
            quant_dtype (str, "int8" or "float8_e4m3", default "int8").
      Input contract: x is not all zero (per-tensor modes); for every mode the
      quotient/product before quantization falls inside the target dtype range
      (the cast has no overflow semantics divergence).

    Implementation constraints (violations are scored as failures):
      - The core computation (amax reduction, scale, quantized code words) must
        be completed in HIP kernels inside the submitted file; forward may
        only do input/output shaping (dtype conversion, the two-segment packing,
        etc.). Calling any ready-made quantization library / quantization
        shortcut is forbidden (including torch.quantize_per_tensor /
        torch.quantize_per_channel).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate arithmetic uses float32; the computation order of the
        scale and the quotient must match the definitions above -- per-token
        computes the reciprocal 1/s_r first and then multiplies by x, whereas
        static/per-tensor use the fp32 direct division x_i / s (reciprocal
        multiplication and direct division differ by 1 ulp, which shifts code
        words on tie boundaries); int8 rounding uses round_half_even.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: 2D contiguous input, int8 and fp8 e4m3 target dtypes, three
    modes in one operator; without the GEMM back-end computation and without
    block-scaling floating-point (mxfp4) quantization.
    """
    def __init__(self, mode: str = "dynamic_per_token", quant_dtype: str = "int8"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert mode in ("static_per_tensor", "dynamic_per_tensor", "dynamic_per_token"), "invalid mode"
        assert quant_dtype in ("int8", "float8_e4m3"), "quant_dtype must be int8 or float8_e4m3"
        self.mode = mode
        self.quant_dtype = torch.int8 if quant_dtype == "int8" else torch.float8_e4m3fn
        # <<<END_IMPROVE>>>

    def forward(self, x, scale=None):
        # <<<IMPROVE:forward_stmt_1>>>
        assert x.dim() == 2, "x must be a 2D tensor"
        assert x.is_contiguous(), "x must be contiguous"
        mode_id = {"static_per_tensor": 0, "dynamic_per_tensor": 1, "dynamic_per_token": 2}[self.mode]
        s_native = scale.to(device=x.device, dtype=torch.float32).reshape(1) if mode_id == 0 else None
        return _pyramidkernel_get_extension().quant_forward(x.to(torch.float32), s_native, mode_id, self.quant_dtype != torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert x.is_contiguous(), "x must be contiguous"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        qdt = self.quant_dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        dtype_max = torch.iinfo(qdt).max if qdt == torch.int8 else torch.finfo(qdt).max
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        x_f32 = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        absf = torch.abs(x_f32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        if self.mode == "static_per_tensor": s = scale.to(torch.float32).reshape(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if self.mode == "dynamic_per_tensor": s = (torch.max(absf) / dtype_max).reshape(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if self.mode == "dynamic_per_token": s = torch.max(absf, dim=-1).values.clamp(min=1.0e-10) / dtype_max
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        if self.mode == "dynamic_per_token": q = x_f32 * (1.0 / s)[:, None]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        if self.mode != "dynamic_per_token": q = x_f32 / s
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        if qdt == torch.int8: q = q.round()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        qx = q.to(qdt)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        codes = qx.reshape(-1).to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        return torch.cat([codes, s.reshape(-1).to(torch.float32)])
        # <<<END_IMPROVE>>>
