import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2008_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor rope_forward(torch::Tensor x, torch::Tensor freqs, int64_t rotate_style, bool nope_first, bool reuse_freqs_front_part);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("rope_forward", &rope_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cstdint>
#include <climits>

template<typename T, typename index_t>
__global__ void rope_kernel(const T* __restrict__ x, const T* __restrict__ freqs,
                            T* __restrict__ out, index_t n, index_t seq_stride,
                            int d, int f, int r, int start, int style, bool reuse) {
    index_t i = static_cast<index_t>(blockIdx.x) * static_cast<index_t>(blockDim.x) + static_cast<index_t>(threadIdx.x);
    if (i >= n) return;
    int channel = static_cast<int>(i & static_cast<index_t>(d - 1));
    int j = channel - start;
    if (j < 0 || j >= r) {
        out[i] = x[i];
        return;
    }
    int half = r / 2;
    int partner = style == 0 ? (j < half ? j + half : j - half) : (j ^ 1);
    bool negative = style == 0 ? j < half : (j & 1) == 0;
    int col = reuse ? (style == 0 ? (j & (half - 1)) : j / 2) : j;
    index_t seq = i / seq_stride;
    float angle = static_cast<float>(freqs[seq * f + col]);
    float a = static_cast<float>(x[i]);
    float b = static_cast<float>(x[i - channel + start + partner]);
    if (negative) b = -b;
    float sn, cs;
    __sincosf(angle, &sn, &cs);
    volatile float p = a * cs;
    volatile float q = b * sn;
    out[i] = static_cast<T>(p + q);
}

torch::Tensor rope_forward(torch::Tensor x, torch::Tensor freqs, int64_t rotate_style,
                           bool nope_first, bool reuse_freqs_front_part) {
    TORCH_CHECK(x.is_cuda() && freqs.is_cuda(), "GPU tensors required");
    TORCH_CHECK(x.device() == freqs.device() && x.scalar_type() == freqs.scalar_type(), "Input device and dtype must match");
    TORCH_CHECK(x.is_contiguous() && freqs.is_contiguous(), "Contiguous inputs required");
    c10::cuda::CUDAGuard guard(x.device());
    auto out = torch::empty_like(x);
    int d = x.size(3), f = freqs.size(3);
    int r = f * (reuse_freqs_front_part ? 2 : 1);
    int start = nope_first ? d - r : 0;
    int64_t n = x.numel();
    int64_t stride = x.size(1) * x.size(2) * d;
    int64_t blocks = (n + 255) / 256;
    bool narrow = n <= INT32_MAX && freqs.numel() <= INT32_MAX && stride <= INT32_MAX;
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(), "rope_forward", [&] {
        if (narrow) {
            hipLaunchKernelGGL((rope_kernel<scalar_t, int32_t>), dim3(blocks), dim3(256), 0, stream.stream(),
                              x.data_ptr<scalar_t>(), freqs.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(),
                              static_cast<int32_t>(n), static_cast<int32_t>(stride), d, f, r, start, static_cast<int>(rotate_style), reuse_freqs_front_part);
        } else {
            hipLaunchKernelGGL((rope_kernel<scalar_t, int64_t>), dim3(blocks), dim3(256), 0, stream.stream(),
                              x.data_ptr<scalar_t>(), freqs.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(),
                              n, stride, d, f, r, start, static_cast<int>(rotate_style), reuse_freqs_front_part);
        }
    });
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "RoPE launch failed: ", hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    RoPE (Rotary Position Embedding) forward: dense sbhd layout, with the
    rotation angles given directly as a freqs tensor (not a cached cos/sin table);
    the channels of every head vector are rotated as planes according to the
    sequence position.

    Semantics (the trigonometric functions and the multiply-add are all evaluated in
    float32; the output is cast back to the input dtype):
       The input is x (S, B, H, D) together with freqs (S, 1, 1, F); freqs
       broadcasts over the B and H dimensions.
       Rotation width R = F * 2 (reuse_freqs_front_part=True) or R = F (False).
       Split the last dimension (length D) into a "rotation segment" (length R) and
       a "pass-through segment" (length D - R): with nope_first=False the rotation
       segment occupies the first R channels, with True the last R channels.
       Angle row Theta (length R): with reuse=False, Theta = freqs, one angle per
       rotation channel; with reuse=True, F = R/2 angles are expanded to R columns --
       the NEOX style tiles the whole segment ([a, b] -> [a, b, a, b], each half used
       once), the GPTJ style repeats adjacently ([a, b] -> [a, a, b, b], each number
       pair shares one angle).
       For the rotation segment x_rot (length R) compute:
         out_rot = x_rot * cos(Theta) + rotate_half(x_rot) * sin(Theta)
       rotate_half is decided by the __init__ argument rotate_style:
         NEOX (rotate_style=0): rotate_half(x_rot) = concat(-x_rot[R/2:],
           x_rot[:R/2]), i.e. the first half u and the second half v are swapped with
           the u segment negated, which is equivalent to a plane rotation of every
           pair (u_j, v_j).
         GPTJ (rotate_style=1): even-odd channel pairing, rotate_half(x_rot)[2j] =
           -x_rot[2j+1], rotate_half(x_rot)[2j+1] = x_rot[2j].
       The pass-through segment is appended back without any transformation: with
       nope_first=False, out = concat(out_rot, pass-through segment); with True,
       out = concat(pass-through segment, out_rot).
       Boundary behaviour: when R = D the pass-through segment is empty (full-width
       rotation); when R < D the pass-through segment is kept verbatim, bit for bit;
       the last dimension F of freqs has only the three legal values {D, D/2, D/4}
       (their combination with reuse and R is listed below); all other
       configurations are undefined.

    Input/output specification:
        x      (S, B, H, D)  float16 / bfloat16, contiguous; D is a power of two
                              (4..256), S, B, H are arbitrary positive integers
        freqs  (S, 1, 1, F)  same dtype as x, contiguous; legal combinations:
                              full-width rotation reuse=False: F = D;
                              full-width rotation reuse=True: F = D/2;
                              partial rotation (R=D/2) reuse=False: F = D/2;
                              partial rotation (R=D/2) reuse=True: F = D/4
        output out (S, B, H, D), same dtype as x
        (the evaluator casts the input to fp32 before passing it in; fp16/bf16 ->
        fp32 is lossless)
        hyper-parameters (__init__): rotate_style (0=NEOX, 1=GPTJ), nope_first,
        reuse_freqs_front_part.

    Implementation constraints (violations are scored as failures):
        - The core computation (angle expansion, rotate_half, cos/sin and the
          multiply-add, concatenation of the pass-through segment) must be completed
          inside the submitted file with a HIP kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate computation; cast the output back to the input
          dtype.

    Forbidden: scaled_dot_product_attention / sdpa / flash_attn /
    torch.matmul / torch.bmm / torch.einsum / torch.softmax / torch.polar /
    torch.view_as_complex.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: dense sbhd non-cached forward; variable-length thd, cos/sin cache
    addressing, the dual-input GQA case, the backward pass, and 2D image rotation are
    outside this task.
    """
    def __init__(self, rotate_style: int, nope_first: bool, reuse_freqs_front_part: bool):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.rotate_style = int(rotate_style)
        self.nope_first = bool(nope_first)
        self.reuse_freqs_front_part = bool(reuse_freqs_front_part)
        # <<<END_IMPROVE>>>

    def forward(self, x, freqs):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().rope_forward(x, freqs, self.rotate_style, self.nope_first, self.reuse_freqs_front_part)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        x32 = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        f32 = freqs.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        d = x32.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        rotate_dim = f32.shape[-1] * (2 if self.reuse_freqs_front_part else 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        start = (d - rotate_dim) if self.nope_first else 0
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        x_rot = x32[..., start : start + rotate_dim]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        x_pass = torch.cat((x32[..., :start], x32[..., start + rotate_dim :]), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        theta = f32
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        if self.reuse_freqs_front_part and self.rotate_style == 0:
            theta = f32.repeat([1] * (f32.dim() - 1) + [2])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        if self.reuse_freqs_front_part and self.rotate_style == 1:
            theta = f32.repeat_interleave(2, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        half = rotate_dim // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        rot_half = x_rot
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        if self.rotate_style == 0:  # NEOX: swap the first half u / second half v, negate the u segment
            x1 = x_rot[..., :half]
            x2 = x_rot[..., half:]
            rot_half = torch.cat((-x2, x1), dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        if self.rotate_style == 1:  # GPTJ: even-odd pairing; the even slot takes the negated odd element, the odd slot takes the even element
            x1 = x_rot[..., ::2]
            x2 = x_rot[..., 1::2]
            rot_half = torch.stack((-x2, x1), dim=-1).flatten(-2)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        x_embed = x_rot * torch.cos(theta) + rot_half * torch.sin(theta)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        pieces = (x_pass, x_embed) if self.nope_first else (x_embed, x_pass)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        out = torch.cat(pieces, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        return out.to(dt)
        # <<<END_IMPROVE>>>
