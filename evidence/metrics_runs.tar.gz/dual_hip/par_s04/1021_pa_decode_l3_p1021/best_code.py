import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1021_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void pa_decode_out(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, double);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("pa_decode_out", &pa_decode_out);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

// Each logical 16-lane subgroup computes a token dot product.
template<class T>
__global__ void pa_split(const T* q, const T* k, const T* v,
                         const int* bt, const int* lens, float* tmp,
                         int H, int K, int D, int bs, int tables,
                         int splits, int chunk, float scale) {
    bool paired = ((H / K) % 2 == 0 && D <= 256 && chunk <= 1024);
    int h = paired ? 2 * int(blockIdx.y) : int(blockIdx.y);
    int s = blockIdx.z, part = blockIdx.x;
    int start = part * chunk;
    int end = min(start + chunk, lens[s]);
    if (start >= end) return;
    int n = end - start, tid = threadIdx.x;
    int lane = tid % 16, team = tid / 16;
    int kh = h / (H / K);
    extern __shared__ float logits[];
    __shared__ float maximum, denominator;
    // Compact paired grid maps each block to two heads within one KV group.
    // Ineligible shapes retain the original single-head path.
    if (paired) {
        float* tile = logits + 2 * chunk;
        // Stage at most sixteen tokens, never crossing a logical page.
        for (int j0 = 0; j0 < n;) {
            int token0 = start + j0;
            int nt = min(min(16, n - j0), bs - token0 % bs);
            int page = bt[(int64_t)s * tables + token0 / bs];
            int64_t base = (((int64_t)page * K + kh) * bs + token0 % bs) * D;
            for (int x = tid; x < nt * D; x += blockDim.x)
                tile[x] = float(k[base + x]);
            __syncthreads();
            for (int r = 0; r < 2; ++r) {
                float dot = 0.0f;
                if (team < nt) {
                    if (D == 128) {
                        #pragma unroll
                        for (int i = 0; i < 8; ++i) {
                            int d = lane + 16 * i;
                            dot += float(q[((int64_t)s * H + h + r) * 128 + d]) * tile[team * 128 + d];
                        }
                    } else {
                        for (int d = lane; d < D; d += 16)
                            dot += float(q[((int64_t)s * H + h + r) * D + d]) * tile[team * D + d];
                    }
                }
                for (int delta = 8; delta; delta /= 2)
                    dot += __shfl_down(dot, delta, 16);
                if (team < nt && lane == 0) logits[r * chunk + j0 + team] = dot * scale;
            }
            __syncthreads();
            j0 += nt;
        }
        if (tid < 2) {
            float m = -INFINITY, sum = 0.0f;
            float* p = logits + tid * chunk;
            for (int j = 0; j < n; ++j) m = fmaxf(m, p[j]);
            for (int j = 0; j < n; ++j) {
                p[j] = expf(p[j] - m);
                sum += p[j];
            }
            int64_t dst = (((int64_t)s * H + h + tid) * splits + part) * (D + 2);
            tmp[dst + D] = m;
            tmp[dst + D + 1] = sum;
        }
        __syncthreads();
        float acc0 = 0.0f, acc1 = 0.0f;
        for (int j0 = 0; j0 < n;) {
            int token0 = start + j0;
            int nt = min(min(16, n - j0), bs - token0 % bs);
            int page = bt[(int64_t)s * tables + token0 / bs];
            int64_t base = (((int64_t)page * K + kh) * bs + token0 % bs) * D;
            for (int x = tid; x < nt * D; x += blockDim.x)
                tile[x] = float(v[base + x]);
            __syncthreads();
            if (tid < D) {
                for (int j = 0; j < nt; ++j) {
                    float val = tile[j * D + tid];
                    acc0 += logits[j0 + j] * val;
                    acc1 += logits[chunk + j0 + j] * val;
                }
            }
            __syncthreads();
            j0 += nt;
        }
        if (tid < D) {
            int64_t dst = (((int64_t)s * H + h) * splits + part) * (D + 2);
            tmp[dst + tid] = acc0;
            tmp[dst + (int64_t)splits * (D + 2) + tid] = acc1;
        }
        return;
    }
    for (int j = team; j < n; j += 16) {
        int token = start + j;
        int page = bt[(int64_t)s * tables + token / bs];
        int64_t base = (((int64_t)page * K + kh) * bs + token % bs) * D;
        float dot = 0.0f;
        if (D == 128) {
            #pragma unroll
            for (int i = 0; i < 8; ++i) {
                int d = lane + 16 * i;
                dot += float(q[((int64_t)s * H + h) * 128 + d]) * float(k[base + d]);
            }
        } else {
            for (int d = lane; d < D; d += 16)
                dot += float(q[((int64_t)s * H + h) * D + d]) * float(k[base + d]);
        }
        for (int delta = 8; delta; delta /= 2)
            dot += __shfl_down(dot, delta, 16);
        if (lane == 0) logits[j] = dot * scale;
    }
    __syncthreads();
    if (tid == 0) {
        float m = -INFINITY;
        for (int j = 0; j < n; ++j) m = fmaxf(m, logits[j]);
        float sum = 0.0f;
        for (int j = 0; j < n; ++j) {
            float p = expf(logits[j] - m);
            logits[j] = p;
            sum += p;
        }
        maximum = m;
        denominator = sum;
    }
    __syncthreads();
    int64_t dst = (((int64_t)s * H + h) * splits + part) * (D + 2);
    for (int d = tid; d < D; d += blockDim.x) {
        float acc = 0.0f;
        for (int j = 0; j < n; ++j) {
            int token = start + j;
            int page = bt[(int64_t)s * tables + token / bs];
            int64_t base = (((int64_t)page * K + kh) * bs + token % bs) * D;
            acc += logits[j] * float(v[base + d]);
        }
        tmp[dst + d] = acc;
    }
    if (tid == 0) {
        tmp[dst + D] = maximum;
        tmp[dst + D + 1] = denominator;
    }
}

template<class T>
__global__ void pa_merge(const float* tmp, const int* lens, T* out,
                         int H, int D, int splits, int chunk,
                         int64_t os0, int64_t os1, int64_t os2) {
    int h = blockIdx.x, s = blockIdx.y;
    int count = (lens[s] + chunk - 1) / chunk;
    int64_t base = ((int64_t)s * H + h) * splits * (D + 2);
    float m = -INFINITY;
    for (int p = 0; p < count; ++p)
        m = fmaxf(m, tmp[base + (int64_t)p * (D + 2) + D]);
    float den = 0.0f;
    for (int p = 0; p < count; ++p) {
        int64_t off = base + (int64_t)p * (D + 2);
        den += expf(tmp[off + D] - m) * tmp[off + D + 1];
    }
    for (int d = threadIdx.x; d < D; d += blockDim.x) {
        float val = 0.0f;
        for (int p = 0; p < count; ++p) {
            int64_t off = base + (int64_t)p * (D + 2);
            val += expf(tmp[off + D] - m) * tmp[off + d];
        }
        out[s * os0 + h * os1 + d * os2] = T(val / den);
    }
}

void pa_decode_out(torch::Tensor query, torch::Tensor key, torch::Tensor value,
                   torch::Tensor tables, torch::Tensor lengths, torch::Tensor out,
                   double scale) {
    c10::cuda::CUDAGuard guard(query.device());
    auto q = query.contiguous();
    auto k = key.contiguous();
    auto v = value.contiguous();
    auto bt = tables.contiguous();
    auto lens = lengths.contiguous();
    int B = q.size(0), H = q.size(1), D = q.size(2);
    int K = k.size(1), bs = k.size(2), N = bt.size(1);
    int chunk = ((256 + bs - 1) / bs) * bs;
    int splits = (N * bs + chunk - 1) / chunk;
    TORCH_CHECK(H % K == 0 && key.scalar_type() == query.scalar_type() && value.scalar_type() == query.scalar_type());
    bool paired = ((H / K) % 2 == 0 && D <= 256 && chunk <= 1024);
    auto tmp = torch::empty({B, H, splits, D + 2}, q.options().dtype(torch::kFloat32));
    auto stream = at::cuda::getCurrentCUDAStream();
    int shared_floats = paired ? 2 * chunk + 16 * D : chunk;
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, q.scalar_type(), "pa_decode", [&] {
        pa_split<scalar_t><<<dim3(splits, paired ? H / 2 : H, B), 256, shared_floats * sizeof(float), stream>>>(
            q.data_ptr<scalar_t>(), k.data_ptr<scalar_t>(), v.data_ptr<scalar_t>(),
            bt.data_ptr<int>(), lens.data_ptr<int>(), tmp.data_ptr<float>(),
            H, K, D, bs, N, splits, chunk, float(scale));
        C10_CUDA_KERNEL_LAUNCH_CHECK();
        pa_merge<scalar_t><<<dim3(H, B), 256, 0, stream>>>(
            tmp.data_ptr<float>(), lens.data_ptr<int>(), out.data_ptr<scalar_t>(),
            H, D, splits, chunk, out.stride(0), out.stride(1), out.stride(2));
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    });
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Paged attention for the long-context decode phase (single-token query), for both MHA and GQA.

    Operator semantics: the KV cache is paged with a fixed block_size in the
    physical block pool key_cache / value_cache, and each sequence is addressed
    indirectly through the physical block ids in block_tables; the KV length that
    actually takes part in attention for each sequence is given by seq_lens[s]
    (>=1); slots of the physical block pool that nothing references, and slots of
    the tail block beyond seq_lens[s], are garbage data and must not take part in
    the computation. For query head h of sequence s (its KV head is
    h // query_group_size; let bs = block_size, bt = block_tables):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    softmax is a numerically stable reduction over the whole
    [0, seq_lens[s]) interval.

    This task is in the long-context regime: the block-table capacity max_seq_len
    (16384 in the fixed family) far exceeds 8192, so a single sequence's KV can be
    long. How the work is parallelized is **not** a scoring criterion -- any
    implementation that is numerically equivalent to the full softmax within the
    tolerance is acceptable, and the implementation path is free. Core boundary
    cases: partially filled tail blocks (seq_len not a multiple of the block
    size), seq_len exactly a multiple of the block size, wildly different
    sequence lengths within one batch (as short as 1), and tail-block slot
    masking -- positions beyond seq_len must not contribute any probability mass.

    Input/output specification:
      query       [num_seqs, num_q_heads, head_size], fp16/bf16
      key_cache   [num_blocks, num_kv_heads, block_size, head_size], fp16/bf16
      value_cache same as key_cache
      block_tables[num_seqs, max_blocks_per_seq] int32, logical block -> physical block id
      seq_lens    [num_seqs] int32, each sequence's valid KV length, 1 <= seq_lens[s] <= max_seq_len
      output out  [num_seqs, num_q_heads, head_size], dtype matches query

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling external attention operator libraries such as
        scaled_dot_product_attention / sdpa / flash_attn, and torch.matmul /
        torch.bmm / torch.einsum / torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - Unreferenced physical blocks and slots beyond seq_len must not affect the
        output.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding
    window; the long-context regime (max(seq_lens) > 8192).
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _pyramidkernel_get_extension().pa_decode_out(query, key_cache, value_cache, block_tables, seq_lens, out, self.scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
