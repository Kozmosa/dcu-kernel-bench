import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

def _deform_attn_forward(value_f, spatial_shapes, level_start_index,
                         sampling_locations_f, attention_weights_f):
    """Multi-scale deformable attention forward (float32, hand-written the same way as task 1031).

    Semantically identical to the reference of task 1031: coordinate expansion,
    four-corner zero-padded bilinear interpolation, softmax normalization of the
    sampling weights over the flattened (levels x points) dimension, and the
    cross-sampling-point weighted reduction. The only difference is that the floor
    path is detached first (the subgradient convention that the floor gradient is
    0 is made explicit, so the gradient only flows back through the interpolation
    fractions fx/fy); numerically it is exactly the same as the forward.
    All inputs are float32 tensors (the caller is responsible for the cast and for
    requires_grad); returns the uncast float32 output (N, Q, heads*D) for the
    gradient chain to use.
    """
    n, n_keys, num_heads, d = value_f.shape
    n_levels = spatial_shapes.shape[0]
    n_queries = sampling_locations_f.shape[1]
    n_points = sampling_locations_f.shape[4]

    # Normalize the sampling weights: flatten (levels x points) into one
    # dimension and run a numerically stable softmax
    wf = attention_weights_f.reshape(n, n_queries, num_heads,
                                     n_levels * n_points)
    wf = torch.softmax(wf, dim=-1).view(n, n_queries, num_heads,
                                        n_levels, n_points)

    n_idx = torch.arange(n, device=value_f.device).view(n, 1, 1)
    h_idx = torch.arange(num_heads, device=value_f.device).view(1, 1, num_heads)

    out = torch.zeros(n, n_queries, num_heads, d,
                      dtype=torch.float32, device=value_f.device)
    for l in range(n_levels):
        h_l = int(spatial_shapes[l, 0])
        w_l = int(spatial_shapes[l, 1])
        base = int(level_start_index[l])
        v_l = value_f[:, base: base + h_l * w_l]   # (n, H_l*W_l, heads, d)

        # normalized coordinates x level size -> real-valued sampling
        # coordinates (channel 0 along W, channel 1 along H)
        sx = sampling_locations_f[:, :, :, l, :, 0] * float(w_l)
        sy = sampling_locations_f[:, :, :, l, :, 1] * float(h_l)
        # The floor / integer-index path is treated as a constant (detached
        # explicitly); the gradient only flows back through fx/fy
        ix0 = torch.floor(sx.detach()).to(torch.long)
        iy0 = torch.floor(sy.detach()).to(torch.long)
        fx = sx - ix0.to(torch.float32)
        fy = sy - iy0.to(torch.float32)

        def corner(iy, ix, wgt):
            # Single-corner sampling: an out-of-range corner contributes 0
            # (zero padding semantics); the clamp only guards the index
            # against going out of range and is cancelled by the 0 weight
            valid = ((iy >= 0) & (iy <= h_l - 1)
                     & (ix >= 0) & (ix <= w_l - 1)).to(torch.float32)
            flat = iy.clamp(0, h_l - 1) * w_l + ix.clamp(0, w_l - 1)
            vals = v_l[n_idx, flat, h_idx]        # (n, q, heads, P, d)
            return vals * (valid * wgt).unsqueeze(-1)

        for p in range(n_points):
            iy0p, ix0p = iy0[..., p], ix0[..., p]      # (n, q, heads)
            fyp, fxp = fy[..., p], fx[..., p]
            sampled = (corner(iy0p, ix0p, (1.0 - fyp) * (1.0 - fxp))
                       + corner(iy0p, ix0p + 1, (1.0 - fyp) * fxp)
                       + corner(iy0p + 1, ix0p, fyp * (1.0 - fxp))
                       + corner(iy0p + 1, ix0p + 1, fyp * fxp))
            out = out + wf[:, :, :, l, p].unsqueeze(-1) * sampled

    return out.view(n, n_queries, num_heads * d)

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1032_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

 torch::Tensor deform_attention_bwd(torch::Tensor value, torch::Tensor spatial_shapes,
                                   torch::Tensor level_start_index,
                                   torch::Tensor sampling_locations,
                                   torch::Tensor attention_weights,
                                   torch::Tensor grad_output);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_attention_bwd", &deform_attention_bwd,
          "Multi-scale deformable attention backward (HIP)");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/hip/HIPContext.h>
#include <hip/hip_runtime.h>
#include <cmath>

#define HIP_CHECK(x) TORCH_CHECK((x) == hipSuccess, hipGetErrorString(x))

template<int BLOCK>
__global__ void deform_main(const float* value, const float* shapes,
                            const float* starts, const float* loc,
                            const float* aw, const float* go, float* out,
                            int N, int Q, int Hh, int D, int NK,
                            int L, int P, int gvsz, int lsz) {
    int bh = (int)blockIdx.x;
    if (bh >= N * Q * Hh) return;
    int tid = (int)threadIdx.x;
    int h = bh % Hh;
    int q = (bh / Hh) % Q;
    int n = bh / (Q * Hh);
    int K = L * P;
    __shared__ float red[BLOCK], redx[BLOCK], redy[BLOCK];

    float mx = -INFINITY;
    for (int j = tid; j < K; j += BLOCK)
        mx = fmaxf(mx, aw[bh * K + j]);
    red[tid] = mx;
    __syncthreads();
    for (int s = BLOCK / 2; s; s >>= 1) {
        if (tid < s) red[tid] = fmaxf(red[tid], red[tid + s]);
        __syncthreads();
    }
    float amax = red[0];
    __syncthreads();

    float den_part = 0.0f;
    for (int j = tid; j < K; j += BLOCK)
        den_part += expf(aw[bh * K + j] - amax);
    red[tid] = den_part;
    __syncthreads();
    for (int s = BLOCK / 2; s; s >>= 1) {
        if (tid < s) red[tid] += red[tid + s];
        __syncthreads();
    }
    float den = red[0];
    __syncthreads();

    float mean = 0.0f;
    for (int j = 0; j < K; ++j) {
        int l = j / P;
        int H = (int)shapes[2 * l];
        int W = (int)shapes[2 * l + 1];
        int base = (int)starts[l];
        int li = bh * K + j;
        float sx = loc[li * 2] * (float)W;
        float sy = loc[li * 2 + 1] * (float)H;
        int ix = (int)floorf(sx);
        int iy = (int)floorf(sy);
        float fx = sx - (float)ix;
        float fy = sy - (float)iy;
        float w = expf(aw[li] - amax) / den;
        float pt = 0.0f, px = 0.0f, py = 0.0f;

        for (int c = tid; c < D; c += BLOCK) {
            float g = go[bh * D + c];
            float v00 = 0.0f, v01 = 0.0f, v10 = 0.0f, v11 = 0.0f;
            if (iy >= 0 && iy < H && ix >= 0 && ix < W)
                v00 = value[((n * NK + base + iy * W + ix) * Hh + h) * D + c];
            if (iy >= 0 && iy < H && ix + 1 >= 0 && ix + 1 < W)
                v01 = value[((n * NK + base + iy * W + ix + 1) * Hh + h) * D + c];
            if (iy + 1 >= 0 && iy + 1 < H && ix >= 0 && ix < W)
                v10 = value[((n * NK + base + (iy + 1) * W + ix) * Hh + h) * D + c];
            if (iy + 1 >= 0 && iy + 1 < H && ix + 1 >= 0 && ix + 1 < W)
                v11 = value[((n * NK + base + (iy + 1) * W + ix + 1) * Hh + h) * D + c];

            float a00 = (1.0f - fy) * (1.0f - fx);
            float a01 = (1.0f - fy) * fx;
            float a10 = fy * (1.0f - fx);
            float a11 = fy * fx;
            pt += g * (a00 * v00 + a01 * v01 + a10 * v10 + a11 * v11);
            px += g * ((1.0f - fy) * (v01 - v00) + fy * (v11 - v10));
            py += g * ((1.0f - fx) * (v10 - v00) + fx * (v11 - v01));

            if (iy >= 0 && iy < H && ix >= 0 && ix < W)
                atomicAdd(out + ((n * NK + base + iy * W + ix) * Hh + h) * D + c, w * a00 * g);
            if (iy >= 0 && iy < H && ix + 1 >= 0 && ix + 1 < W)
                atomicAdd(out + ((n * NK + base + iy * W + ix + 1) * Hh + h) * D + c, w * a01 * g);
            if (iy + 1 >= 0 && iy + 1 < H && ix >= 0 && ix < W)
                atomicAdd(out + ((n * NK + base + (iy + 1) * W + ix) * Hh + h) * D + c, w * a10 * g);
            if (iy + 1 >= 0 && iy + 1 < H && ix + 1 >= 0 && ix + 1 < W)
                atomicAdd(out + ((n * NK + base + (iy + 1) * W + ix + 1) * Hh + h) * D + c, w * a11 * g);
        }

        red[tid] = pt;
        redx[tid] = px;
        redy[tid] = py;
        __syncthreads();
        for (int s = BLOCK / 2; s; s >>= 1) {
            if (tid < s) {
                red[tid] += red[tid + s];
                redx[tid] += redx[tid + s];
                redy[tid] += redy[tid + s];
            }
            __syncthreads();
        }
        if (tid == 0) {
            out[gvsz + lsz + li] = red[0];
            mean += w * red[0];
            out[gvsz + li * 2] = w * redx[0] * (float)W;
            out[gvsz + li * 2 + 1] = w * redy[0] * (float)H;
        }
        __syncthreads();
    }

    if (tid == 0) {
        for (int j = 0; j < K; ++j) {
            float w = expf(aw[bh * K + j] - amax) / den;
            float t = out[gvsz + lsz + bh * K + j];
            out[gvsz + lsz + bh * K + j] =
                K == 1 ? 0.0f : w * (t - mean);
        }
    }
}

torch::Tensor deform_attention_bwd(torch::Tensor value, torch::Tensor spatial_shapes,
                                   torch::Tensor level_start_index,
                                   torch::Tensor sampling_locations,
                                   torch::Tensor attention_weights,
                                   torch::Tensor grad_output) {
    TORCH_CHECK(value.is_cuda() && value.is_contiguous());
    TORCH_CHECK(value.scalar_type() == torch::kFloat);
    TORCH_CHECK(spatial_shapes.scalar_type() == torch::kFloat &&
                level_start_index.scalar_type() == torch::kFloat);
    int N = value.size(0), NK = value.size(1), Hh = value.size(2), D = value.size(3);
    int Q = sampling_locations.size(1), L = sampling_locations.size(3), P = sampling_locations.size(4);
    int64_t gv = (int64_t)N * NK * Hh * D;
    int64_t ls = (int64_t)N * Q * Hh * L * P * 2;
    int64_t at = (int64_t)N * Q * Hh * L * P;
    auto out = torch::empty({gv + ls + at}, value.options());
    hipStream_t stream = at::hip::getCurrentHIPStream();
    HIP_CHECK(hipMemsetAsync(out.data_ptr<float>(), 0, static_cast<size_t>(gv) * sizeof(float), stream));
    if (D <= 64) {
        hipLaunchKernelGGL((deform_main<64>), dim3(N * Q * Hh), dim3(64), 0, stream,
            value.data_ptr<float>(), spatial_shapes.data_ptr<float>(), level_start_index.data_ptr<float>(),
            sampling_locations.data_ptr<float>(), attention_weights.data_ptr<float>(), grad_output.data_ptr<float>(),
            out.data_ptr<float>(), N, Q, Hh, D, NK, L, P, (int)gv, (int)ls);
    } else {
        hipLaunchKernelGGL((deform_main<256>), dim3(N * Q * Hh), dim3(256), 0, stream,
            value.data_ptr<float>(), spatial_shapes.data_ptr<float>(), level_start_index.data_ptr<float>(),
            sampling_locations.data_ptr<float>(), attention_weights.data_ptr<float>(), grad_output.data_ptr<float>(),
            out.data_ptr<float>(), N, Q, Hh, D, NK, L, P, (int)gv, (int)ls);
    }
    HIP_CHECK(hipGetLastError());
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Multi-Scale Deformable Attention Backward (deform_attn_dgrad): given the forward inputs and the upstream gradient grad_output, one call computes the gradients of value, sampling_locations and attention_weights at once.

    Forward semantics (all intermediate computation float32, the same convention
    as the companion forward task): value (N, n_keys, heads, D) is the
    concatenation of the multi-scale feature levels -- level l contributes
    spatial_shapes[l] = (H_l, W_l) keys, laid out inside the level in row-major
    order (H first, then W) over [level_start_index[l], level_start_index[l] +
    H_l*W_l), where level_start_index must be the prefix sum of the per-level
    H_l*W_l (first element 0) and n_keys = sum_l H_l*W_l. The last dimension of
    sampling_locations (N, Q, heads, L, P, 2) holds the normalized coordinates
    (x, y): channel 0 runs along W and channel 1 along H (generation domain
    [0,1)), so the actual sampling coordinates are loc_x = x * W_l and loc_y =
    y * H_l; the sampled value goes through four-corner bilinear interpolation
    (floor + the fractions fx/fy, with zero padding semantics where an
    out-of-range corner contributes 0, and no clamp / nearest-neighbour
    pull-back); attention_weights (N, Q, heads, L, P) are non-negative
    unnormalized scores, first flattened over (levels x points) into one
    dimension and normalized by a numerically stable softmax (max subtraction)
    into convex-combination weights, then used in the weighted sum against the
    interpolated value of each sampling point, producing the output o
    (N, Q, heads*D).

    Backward semantics (backpropagated through the float32 forward described
    above, at the point before the output is cast back to the value dtype;
    grad_output is first cast to float32): write dO for the float32 form of
    grad_output, w = softmax(attention_weights flattened over L*P), S_{l,p}[c] for
    the four-corner zero-padded bilinear sample of point (l,p), and
    t_{l,p} = <dO, S_{l,p}>; the three gradients are then the analytic gradients
    of o with respect to the three floating-point inputs:
      grad_value[n, key, h, c] = sum_{q, l, p} w_{l,p} * corner_weight *
                                 dO[n, q, h*D + c]
        (per-corner scatter accumulation; out-of-range corners do not scatter)
      grad_sampling_locations[n, q, h, l, p, 0] =
          sum_c dO[n, q, h*D + c] * w_{l,p} * W_l *
          ((1-fy) * (v01 - v00) + fy * (v11 - v10))
      grad_sampling_locations[n, q, h, l, p, 1] =
          sum_c dO[n, q, h*D + c] * w_{l,p} * H_l *
          ((1-fx) * (v10 - v00) + fx * (v11 - v01))
        (v00/v01/v10/v11 are the four corner pixel values of that point, with an
        out-of-range corner counted as 0; the gradient only flows back through
        the fractions fx/fy, and the floor / integer-index path has gradient 0 --
        the standard subgradient of bilinear sampling)
      grad_attention_weights[n, q, h, l, p] = w_{l,p} *
          (t_{l,p} - sum_{l', p'} w_{l',p'} * t_{l',p'})
        (softmax backprop; identically 0 when L*P = 1)
    The softmax, the interpolation, the weighted reduction and all gradient
    accumulation are done in float32, and the three gradients are each cast back
    to the value dtype and then packed into the output.

    Output contract (single tensor, one-dimensional concatenation packing, the
    segment order is fixed and must not be swapped):
      out = cat([grad_value.reshape(-1),
                 grad_sampling_locations.reshape(-1),
                 grad_attention_weights.reshape(-1)])
      a one-dimensional tensor with the same dtype as value, of length
          = n*n_keys*heads*D + n*n_queries*heads*L*P*2 + n*n_queries*heads*L*P
      segment 0 grad_value: n*n_keys*heads*D elements, (N, n_keys, heads, D)
          flattened row-major;
      segment 1 grad_sampling_locations: n*n_queries*heads*L*P*2 elements,
          (N, Q, heads, L, P, 2) flattened row-major (the (x, y) channel order of
          the last dimension is preserved);
      segment 2 grad_attention_weights: n*n_queries*heads*L*P elements,
          (N, Q, heads, L, P) flattened row-major.

    Input/output specification (all tensors contiguous):
      value              float32 / float16 (N, n_keys, heads, D)
      spatial_shapes     int64 (L, 2), each row (H_l, W_l), H_l / W_l >= 1
      level_start_index  int64 (L,), prefix sum of the per-level key counts
      sampling_locations same dtype as value (N, Q, heads, L, P, 2), generation domain [0,1)
      (with an fp16 input individual elements may round to exactly 1.0 through
       the cast; then loc_x = W_l is fully out of range, the sampled value is 0,
       and the zero padding semantics apply)
      attention_weights  same dtype as value (N, Q, heads, L, P), non-negative
      grad_output        same dtype as value (N, Q, heads*D), the upstream
                         gradient in the forward output layout, generation domain [0,1)
      out                single tensor, same dtype as value, 1-D three-segment
                         concatenation (see above)
      every dimension is an arbitrary positive integer (including 1, non-powers
      of 2, and non-16-aligned sizes; a single-level single-pixel (H_l, W_l) =
      (1, 1), 1xN / Nx1 thin-strip levels, Q=1, P=1 and L=1 are all legal
      boundaries, and when L*P=1 grad_attention_weights is identically 0). The
      evaluator casts every input to fp32 before passing it in (lossless for both
      the low precision and the int64 indices -- an index value <= 2^24 is exactly
      representable in fp32), so the implementation must restore
      spatial_shapes / level_start_index to integer indices before using them.

    Implementation constraints (violations are scored as failures):
      - The core computation (softmax backprop, the four-corner gradient scatter
        with the partial derivatives of the interpolation fractions, and the
        cross-query grad_value scatter accumulation) must be hand-written as a HIP
        kernel inside the submitted file.
      - Using torch.autograd / autograd.grad / .backward() to backpropagate for the
        gradients is forbidden; the gradients must be hand-written from the
        analytic formulas above.
      - All gradient accumulation is done in float32; the three gradient segments
        are cast back to the value dtype and concatenated in the segment order
        above; forward returns the single tensor out (the evaluator compares a
        single output).
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden list: torchvision (including ready-made deformable attention /
    deformable convolution primitives such as torchvision.ops.ms_deform_attn),
    mmcv, miopen, hipdnn, aiter,
    torch.nn.functional.grid_sample (F.grid_sample),
    torch.nn.functional.interpolate (F.interpolate), torch.matmul /
    torch.bmm / torch.mm / torch.einsum / torch.tensordot,
    torch.softmax / torch.nn.functional.softmax (F.softmax),
    torch.autograd (including autograd.grad), .backward().
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, value, spatial_shapes, level_start_index, sampling_locations, attention_weights, grad_output):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().deform_attention_bwd(
                    value, spatial_shapes, level_start_index, sampling_locations,
                    attention_weights, grad_output);
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        level_start_index = level_start_index.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        n, n_keys, num_heads, d = value.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        n_levels = spatial_shapes.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_queries = sampling_locations.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_points = sampling_locations.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert sampling_locations.dim() == 6 \
            and sampling_locations.shape[2] == num_heads \
            and sampling_locations.shape[3] == n_levels \
            and sampling_locations.shape[5] == 2, \
            "sampling_locations must be (N, Q, heads, L, P, 2)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert attention_weights.shape == (n, n_queries, num_heads, n_levels, n_points), \
            "attention_weights must be (N, Q, heads, L, P)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert value.shape[1] == int(spatial_shapes.prod(dim=1).sum()), \
            "dimension 1 of value must equal the sum of the per-level H_l*W_l"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert grad_output.shape == (n, n_queries, num_heads * d), \
            "grad_output must be (N, Q, heads*D)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        vg = value.detach().to(torch.float32).requires_grad_(True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        lg = sampling_locations.detach().to(torch.float32).requires_grad_(True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        ag = attention_weights.detach().to(torch.float32).requires_grad_(True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        out = _deform_attn_forward(vg, spatial_shapes, level_start_index, lg, ag)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        grad_value, grad_sampling_loc, grad_attn_weight = torch.autograd.grad(
            out, (vg, lg, ag), grad_output.to(torch.float32))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return torch.cat([grad_value.to(value.dtype).reshape(-1),
                          grad_sampling_loc.to(value.dtype).reshape(-1),
                          grad_attn_weight.to(value.dtype).reshape(-1)])
        # <<<END_IMPROVE>>>
