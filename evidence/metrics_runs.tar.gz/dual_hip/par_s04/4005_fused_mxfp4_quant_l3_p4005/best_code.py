import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

def _rmsnorm(x, weight, eps):
    # Official semantics: row-wise RMS normalization in float32, then multiply
    # by the weight
    row_norm = torch.sum(x * x, dim=-1)
    norm_factor = torch.rsqrt((row_norm / x.shape[1]) + eps).reshape(-1, 1)
    return x * norm_factor * weight.reshape(1, -1)

def _mxfp4_quant(x):
    # MXFP4 dynamic quantization (block size 32, even rounding). See the Model
    # docstring for the bit-exact semantics: the bit-level algorithm matches the
    # reference implementation; the input is a float32 (M, N) matrix.
    MXFP4_QUANT_BLOCK_SIZE = 32
    x_shape = x.shape
    if x.shape[-1] % MXFP4_QUANT_BLOCK_SIZE != 0:
        shape = list(x_shape)
        shape = shape[:-1] + [
            ((shape[-1] - 1 + MXFP4_QUANT_BLOCK_SIZE) // MXFP4_QUANT_BLOCK_SIZE)
            * MXFP4_QUANT_BLOCK_SIZE
        ]
        shape = tuple(shape)
        x_padded = torch.zeros(shape, dtype=x.dtype, device=x.device)
        x_padded[..., : x.shape[-1]] = x
    else:
        x_padded = x

    # Block scale: round amax up to a power of two, then take floor(log2) - 2
    x_padded = x_padded.reshape(
        -1, x_padded.shape[-1] // MXFP4_QUANT_BLOCK_SIZE, MXFP4_QUANT_BLOCK_SIZE
    ).to(torch.float32)
    amax, _ = torch.max(torch.abs(x_padded), dim=-1)
    amax = amax.view(torch.int32)
    amax = (amax + 0x200000) & 0xFF800000
    amax = amax.view(torch.float32)
    scale_e8m0_unbiased = torch.log2(amax).floor() - 2
    scale_e8m0_unbiased = torch.clamp(scale_e8m0_unbiased, min=-127, max=127)
    quant_scale = torch.exp2(-scale_e8m0_unbiased)

    # Quantized values
    qx = x_padded * quant_scale.unsqueeze(-1)

    # blockscale_e8m0
    bs_e8m0 = scale_e8m0_unbiased.to(torch.uint8) + 127

    # e2m1 rounding: round-half-up, saturating past the range (take min(x, 7) of
    # ((E<<2 | M>>21) + 1) >> 1)
    qx = qx.view(torch.int32)
    s = qx & 0x80000000
    e = (qx >> 23) & 0xFF
    m = qx & 0x7FFFFF

    E8_BIAS = 127
    E2_BIAS = 1
    adjusted_exponents = E8_BIAS - e - 1
    m = torch.where(e < E8_BIAS, (0x400000 | (m >> 1)) >> adjusted_exponents, m)
    e = torch.where(e > E8_BIAS - E2_BIAS, e, E8_BIAS - E2_BIAS) - (E8_BIAS - E2_BIAS)

    combined_val = (((e << 2) | (m >> 21)) + 1) >> 1
    e2m1_tmp = torch.where(combined_val < 0x7, combined_val, 0x7)
    e2m1_value = (((s >> 28) & 0xF) | e2m1_tmp).to(torch.uint8)

    # Pack 2 4-bit code words per byte: even indices occupy the low 4 bits
    x_mxfp4 = e2m1_value[..., ::2] | (e2m1_value[..., 1::2] << 4)
    x_mxfp4 = torch.flatten(x_mxfp4, -2, -1)

    # Drop the extra bytes produced by the zero padding
    if x.shape[-1] % MXFP4_QUANT_BLOCK_SIZE != 0:
        x_mxfp4 = x_mxfp4[..., : x.shape[-1] // 2]

    mxfp4_shape = list(x_shape)
    mxfp4_shape = tuple(mxfp4_shape[:-1] + [mxfp4_shape[-1] // 2])
    x_mxfp4 = x_mxfp4.reshape(mxfp4_shape)
    return x_mxfp4, bs_e8m0

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4005_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor fused_quant(torch::Tensor inp, torch::Tensor weight, torch::Tensor residual, double eps);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_quant", &fused_quant);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

#pragma clang fp contract(off)

__device__ __forceinline__ unsigned encode4(float x) {
    unsigned bits = __float_as_uint(x);
    int e = (bits >> 23) & 255;
    unsigned m = bits & 0x7fffff;
    if (e < 127) {
        int shift = 126 - e;
        m = shift >= 32 ? 0u : ((0x400000u | (m >> 1)) >> shift);
    }
    e = (e > 126 ? e : 126) - 126;
    unsigned q = (((unsigned(e) << 2) | (m >> 21)) + 1) >> 1;
    return ((bits >> 28) & 8) | (q < 7 ? q : 7);
}

template<int K>
__global__ void fused_row(const float* a, const float* w, const float* r,
                          unsigned char* out, int n, float eps,
                          int64_t as0, int64_t as1, int64_t rs0,
                          int64_t rs1, int64_t ws) {
    __shared__ float partial[256];
    int t = threadIdx.x;
    int row = blockIdx.x;
    a += row * as0;
    r += row * rs0;
    int nb = (n + 31) / 32;
    out += int64_t(row) * (n / 2 + nb);
    float saved[K ? K : 1];
    float sum = 0.0f;
    if constexpr (K > 0) {
        #pragma unroll
        for (int k = 0; k < K; ++k) {
            int j = t + 256 * k;
            saved[k] = 0.0f;
            if (j < n) {
                float s = a[j * as1] + r[j * rs1];
                saved[k] = s;
                float square = s * s;
                sum = sum + square;
            }
        }
    } else {
        for (int j = t; j < n; j += 256) {
            float s = a[j * as1] + r[j * rs1];
            float square = s * s;
            sum = sum + square;
        }
    }
    partial[t] = sum;
    __syncthreads();
    for (int d = 128; d >= 64; d >>= 1) {
        if (t < d) partial[t] = partial[t] + partial[t + d];
        __syncthreads();
    }
    float v = 0.0f;
    if (t < 32) v = partial[t] + partial[t + 32];
    for (int d = 16; d; d >>= 1) {
        float shuffled_value = __shfl_down(v, d, 32);
        if (t < d) v = v + shuffled_value;
    }
    if (t == 0) partial[0] = v;
    __syncthreads();
    float mean = partial[0] / float(n);
    float factor = rsqrtf(mean + eps);
    int lane = t & 31;
    auto quantize = [&](int j, float s) {
        float x = 0.0f;
        if (j < n) {
            float normalized = s * factor;
            x = normalized * w[j * ws];
        }
        float am = fabsf(x);
        for (int d = 16; d; d >>= 1)
            am = fmaxf(am, __shfl_xor(am, d, 32));
        unsigned rounded = (__float_as_uint(am) + 0x200000u) & 0xff800000u;
        int e = int((rounded >> 23) & 255) - 129;
        e = e < -127 ? -127 : (e > 127 ? 127 : e);
        float scale = ldexpf(1.0f, -e);
        unsigned code = encode4(x * scale);
        unsigned odd = __shfl_down(code, 1, 32);
        if (!(lane & 1) && j < n) out[j / 2] = code | (odd << 4);
        if (lane == 0 && j < n) out[n / 2 + j / 32] = e + 127;
    };
    if constexpr (K > 0) {
        #pragma unroll
        for (int k = 0; k < K; ++k) {
            if (256 * k < n) quantize(256 * k + t, saved[k]);
        }
    } else {
        for (int base = 0; base < n; base += 256) {
            int j = base + t;
            float s = 0.0f;
            if (j < n) s = a[j * as1] + r[j * rs1];
            quantize(j, s);
        }
    }
}

torch::Tensor fused_quant(torch::Tensor inp, torch::Tensor weight, torch::Tensor residual, double eps) {
    TORCH_CHECK(inp.is_cuda() && weight.is_cuda() && residual.is_cuda(), "GPU inputs required");
    TORCH_CHECK(inp.scalar_type() == at::kFloat && weight.scalar_type() == at::kFloat && residual.scalar_type() == at::kFloat, "float32 inputs required");
    TORCH_CHECK(inp.dim() == 2 && residual.sizes() == inp.sizes(), "invalid input shape");
    TORCH_CHECK(weight.dim() == 1 && weight.numel() == inp.size(1), "invalid weight shape");
    TORCH_CHECK(inp.device() == residual.device() && inp.device() == weight.device(), "device mismatch");
    c10::cuda::CUDAGuard guard(inp.device());
    int64_t m = inp.size(0), n = inp.size(1);
    TORCH_CHECK(n >= 2 && n % 2 == 0, "even row width required");
    auto out = torch::empty({m, n / 2 + (n + 31) / 32}, inp.options().dtype(at::kByte));
    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    #define LAUNCH(K) fused_row<K><<<dim3(m), dim3(256), 0, stream>>>(inp.data_ptr<float>(), weight.data_ptr<float>(), residual.data_ptr<float>(), out.data_ptr<unsigned char>(), n, float(eps), inp.stride(0), inp.stride(1), residual.stride(0), residual.stride(1), weight.stride(0))
    if (n <= 256) { LAUNCH(1); }
    else if (n <= 512) { LAUNCH(2); }
    else if (n <= 1024) { LAUNCH(4); }
    else if (n <= 2048) { LAUNCH(8); }
    else { LAUNCH(0); }
    #undef LAUNCH
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "fused_quant launch failed: ", hipGetErrorString(err));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Fused residual add + RMSNorm + MXFP4 dynamic quantization (mxfp4 GEMM
    preprocessing).

    Mathematical definition (all intermediates in float32; inputs are randn in
    the bfloat16/float16 value range):
      1. s = inp1 + res1                                     element-wise add
      2. norm[m, j] = s[m, j] * rsqrt( (1/N1) * sum_j s[m, j]^2 + eps ) * weight1[j]
         eps = 1e-6, normalized along the last dimension
      3. MXFP4 dynamic quantization of every row of norm in 32-element blocks
         (definition below), yielding packed e2m1 code words (2 per byte) and
         e8m0 block scale bytes.

    MXFP4 quantization (block size fixed at 32 along the last dimension; a
    trailing block shorter than 32 zero padded and taking part):
      a. amax = max |x| (inside the block, padding included)
      b. round amax up to a power of two: interpret the IEEE754 bit pattern of
         amax as int32, add 0x200000, bitwise-AND with 0xFF800000, then
         reinterpret as float32 (unchanged when amax is already a power of two,
         otherwise it goes up to the next power of two)
      c. e = clamp( floor(log2(rounded amax)) - 2, -127, 127 )
      d. scale byte = e + 127 (uint8 e8m0 encoding)
      e. q = x * 2^(-e), rounded to the e2m1 code table
         {0, +-0.5, +-1, +-1.5, +-2, +-3, +-4, +-6}: round-half-up (0.5 rounds
         up), saturating to +-6 beyond the range; the equivalent bit-level form
         is ((E<<2 | M>>21) + 1) >> 1 on the fp32 bit pattern, then min(x, 7),
         with bit31 as the sign bit
      f. packing: the 2i-th and the (2i+1)-th code words share one byte, the
         even index occupying the low 4 bits

    Input/output specification:
      inp1    (M, N1)  bfloat16/float16  main input
      weight1 (N1,)    same as inp1      RMSNorm weight
      res1    (M, N1)  same as inp1      residual
      out     (M, N1//2 + ceil(N1/32)) uint8, single-tensor output contract:
              out[:, :N1//2]        packed e2m1 code words (2 per byte, even
                                    indices in the low 4 bits)
              out[:, N1//2:]        e8m0 block scale bytes (ceil(N1/32) per row)
      Constraints: M >= 1; N1 is even and N1 >= 2.
      Boundary behaviour: an all-zero block has amax=0, handled as
      log2(0)=-inf, so after the clamp e=-127, the scale byte is 0 and the code
      words are 0.

    Implementation constraints (violations are scored as failures):
      - The core computation of RMSNorm and quantization (amax/scale
        computation, e2m1 rounding, packing) must be completed inside the
        submitted file; calling torch.nn.functional.rms_norm /
        torch.nn.RMSNorm is forbidden, as is using torch built-in float4/mxfp4
        quantization or conversion APIs (including torch.float4_e2m1fn_x2,
        torch.quantize_per_tensor and other ready-made quantization
        operators), and wrapping or modifying any third-party operator
        library's existing implementation.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate computation uses float32; the output is uint8, and both
        the code words and the scale bytes must be bit-exact against the
        reference implementation (exact match, no tolerance).
      - The evaluator casts every input to fp32 before calling forward
        (bfloat16/float16 values are exact in fp32); just compute with those
        values directly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-path residual + RMSNorm + MXFP4 dynamic quantization
    (block size 32, even rounding), without the downstream GEMM main
    computation.
    """
    def __init__(self, dtype: str = "bfloat16", eps: float = 1e-6):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.dtype = getattr(torch, dtype)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, inp1, weight1, res1):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().fused_quant(inp1, weight1, res1, self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Normalization is performed inside fused_quant.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Codes and scales are written directly to the final tensor.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return out
        # <<<END_IMPROVE>>>
