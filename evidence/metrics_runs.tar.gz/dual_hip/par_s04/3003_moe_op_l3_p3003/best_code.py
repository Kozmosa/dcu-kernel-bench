import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor routed_gemm(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("routed_gemm", &routed_gemm);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

struct Layout {
    int64_t a0,a1,b0,b1,b2,w0,w1,s0,e0;
    int64_t slots,N,K,topk;
};

template<class T>
__global__ void grouped_kernel(const T* A, const T* B, const float* W,
    const int* sorted, const int* experts, const int* padded, T* C, Layout d) {
    constexpr int KT = 32;
    const int64_t base = int64_t(blockIdx.x)*32;
    if (base >= padded[0]) return;
    const int e = experts[(base/64)*d.e0];
    const int tid = threadIdx.x;
    const int r = tid/32, c = tid%32;
    const int64_t nbase = int64_t(blockIdx.y)*32;
    __shared__ float as[32][KT];
    __shared__ float bs[KT][33];
    __shared__ int ids[32];
    __shared__ int64_t a_offsets[32];
    __shared__ float route_weights[32];
    if (tid < 32) {
        int p = sorted[(base+tid)*d.s0];
        ids[tid] = p;
        if (p >= 0 && p < d.slots) {
            int64_t slot = int64_t(p);
            a_offsets[tid] = (slot/d.topk)*d.a0;
            route_weights[tid] = W[(slot/d.topk)*d.w0+(slot%d.topk)*d.w1];
        } else {
            a_offsets[tid] = 0;
            route_weights[tid] = 0.0f;
        }
    }
    __syncthreads();
    float x=0.0f, y=0.0f, z=0.0f, v=0.0f;
    for (int64_t kb=0; kb<d.K; kb+=KT) {
        if (sizeof(T)==2 && d.a1==1) {
            for (int i=tid; i<32*(KT/2); i+=256) {
                int row=i/(KT/2), k=2*(i%(KT/2));
                int p=ids[row];
                float a0=0.0f, a1=0.0f;
                if (p>=0 && p<d.slots && kb+k<d.K) {
                    const T* ptr=A+a_offsets[row]+kb+k;
                    if (kb+k+1<d.K && (reinterpret_cast<uintptr_t>(ptr)&3)==0) {
                        if constexpr (sizeof(T)==2) {
                            uint32_t packed;
                            __builtin_memcpy(&packed, __builtin_assume_aligned(ptr,4),4);
                            T values[2];
                            __builtin_memcpy(values,&packed,4);
                            a0=float(values[0]);
                            a1=float(values[1]);
                        }
                    } else {
                        a0=float(ptr[0]);
                        if (kb+k+1<d.K) a1=float(ptr[1]);
                    }
                }
                as[row][k]=a0;
                as[row][k+1]=a1;
            }
        } else {
            for (int i=tid; i<32*KT; i+=256) {
                int row=i/KT, k=i%KT;
                int p=ids[row];
                as[row][k] = (p>=0 && p<d.slots && kb+k<d.K)
                    ? float(A[a_offsets[row]+(kb+k)*d.a1]) : 0.0f;
            }
        }
        for (int i=tid; i<32*KT; i+=256) {
            int col=i/KT, k=i%KT;
            bs[k][col] = (nbase+col<d.N && kb+k<d.K)
                ? float(B[int64_t(e)*d.b0+(nbase+col)*d.b1+(kb+k)*d.b2]) : 0.0f;
        }
        __syncthreads();
        #pragma unroll
        for (int k=0; k<KT; ++k) {
            float b=bs[k][c];
            x=fmaf(as[r][k],b,x);
            y=fmaf(as[r+8][k],b,y);
            z=fmaf(as[r+16][k],b,z);
            v=fmaf(as[r+24][k],b,v);
        }
        __syncthreads();
    }
    if (nbase+c<d.N) {
        int p=ids[r];
        if (p>=0 && p<d.slots)
            C[int64_t(p)*d.N+nbase+c]=T(x*route_weights[r]);
        p=ids[r+8];
        if (p>=0 && p<d.slots)
            C[int64_t(p)*d.N+nbase+c]=T(y*route_weights[r+8]);
        p=ids[r+16];
        if (p>=0 && p<d.slots)
            C[int64_t(p)*d.N+nbase+c]=T(z*route_weights[r+16]);
        p=ids[r+24];
        if (p>=0 && p<d.slots)
            C[int64_t(p)*d.N+nbase+c]=T(v*route_weights[r+24]);
    }
}

torch::Tensor routed_gemm(torch::Tensor A, torch::Tensor B, torch::Tensor W,
    torch::Tensor I, torch::Tensor S, torch::Tensor E, torch::Tensor P) {
    TORCH_CHECK(A.is_cuda(), "A must be on GPU");
    c10::cuda::CUDAGuard guard(A.device());
    for (const auto& t : {B,W,I,S,E,P})
        TORCH_CHECK(t.device()==A.device(), "Inputs must share a device");
    TORCH_CHECK(A.dim()==2 && B.dim()==3 && I.dim()==2 && W.dim()==2,
        "Invalid input dimensions");
    TORCH_CHECK(A.scalar_type()==at::kHalf || A.scalar_type()==at::kBFloat16 || A.scalar_type()==at::kFloat,
        "Expected fp16, bf16, or fp32");
    TORCH_CHECK(B.scalar_type()==A.scalar_type() && W.scalar_type()==at::kFloat,
        "Invalid floating dtypes");
    TORCH_CHECK(S.scalar_type()==at::kInt && E.scalar_type()==at::kInt && P.scalar_type()==at::kInt && I.scalar_type()==at::kInt,
        "Expected int32 router metadata");
    TORCH_CHECK(S.dim()==1 && E.dim()==1 && P.numel()==1, "Invalid metadata dimensions");
    int64_t M=A.size(0), K=A.size(1), N=B.size(1), topk=I.size(1);
    TORCH_CHECK(topk>0 && topk<=8 && B.size(2)==K && I.size(0)==M && W.size(0)==M && W.size(1)==topk,
        "Incompatible shapes");
    auto C=torch::empty({M,topk,N}, A.options());
    if (C.numel()==0) return C;
    Layout d{A.stride(0),A.stride(1),B.stride(0),B.stride(1),B.stride(2),
        W.stride(0),W.stride(1),S.stride(0),E.stride(0),M*topk,N,K,topk};
    dim3 grid((S.numel()+31)/32,(N+31)/32);
    auto stream=at::cuda::getCurrentCUDAStream();
    if (A.scalar_type()==at::kHalf) {
        grouped_kernel<at::Half><<<grid,256,0,stream>>>(A.data_ptr<at::Half>(), B.data_ptr<at::Half>(), W.data_ptr<float>(), S.data_ptr<int>(), E.data_ptr<int>(), P.data_ptr<int>(), C.data_ptr<at::Half>(),d);
    } else if (A.scalar_type()==at::kBFloat16) {
        grouped_kernel<at::BFloat16><<<grid,256,0,stream>>>(A.data_ptr<at::BFloat16>(), B.data_ptr<at::BFloat16>(), W.data_ptr<float>(), S.data_ptr<int>(), E.data_ptr<int>(), P.data_ptr<int>(), C.data_ptr<at::BFloat16>(),d);
    } else {
        grouped_kernel<float><<<grid,256,0,stream>>>(A.data_ptr<float>(), B.data_ptr<float>(), W.data_ptr<float>(), S.data_ptr<int>(), E.data_ptr<int>(), P.data_ptr<int>(), C.data_ptr<float>(),d);
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return C;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    MoE (Mixture-of-Experts) routed grouped GEMM: non-quantized weights, with
    routing weighting.

    Each token's feature vector A[m] (K dimensions) is dispatched by the routing
    table topk_ids to top_k of the num_experts experts; expert e owns the weight
    matrix B[e] (N x K). For each token m and its j-th routing slot (write
    e = topk_ids[m, j]), the output is defined as

        C[m, j, n] = topk_weights[m, j] * sum_k A[m, k] * B[e, n, k]

    i.e. grouped GEMM followed by a per-slot multiply by the routing weight;
    intermediate accumulation is float32 and the output is cast back to the
    input dtype. Every (m, j) slot hits a legal expert inside [0, num_experts),
    so no output is undefined.

    The inputs also carry the block-aligned layout of grouped GEMM (produced by
    the upstream router; fetching data through it is exactly equivalent to
    computing the formula above directly):
      - sorted_token_ids: int32, length EM = M*top_k + num_experts*(block_m-1),
        with block_m always 64 in this task. Number the slots flat as
        p = m*top_k + j, regroup them by ascending expert id, and pad each group
        up to a multiple of block_m; the intra-group padding positions and the
        array tail hold the sentinel value M*top_k (that is num_valid_tokens;
        offs_token >= it means padding and produces no output).
      - expert_ids: int32, length M*top_k + num_experts; the expert id owning
        block t (covering sorted_token_ids[t*block_m : (t+1)*block_m]), values
        in [0, num_experts), no -1; positions past the number of blocks implied
        by num_tokens_post_padded are sentinel fill and must not be read.
      - num_tokens_post_padded: int32 scalar (length 1), the valid length of
        sorted_token_ids (intra-block padding included), always a multiple of
        block_m.
    The kernel's BLOCK_SIZE_M must divide block_m (that is, be a factor of 64)
    so that every program block sees a single expert.

    Input/output specification:
        A                       (M, K)             float16/bfloat16
        B                       (E, N, K)          same as A (E = num_experts)
        topk_weights            (M, top_k)         float32
        topk_ids                (M, top_k)         int32
        sorted_token_ids        (EM,)              int32
        expert_ids              (M*top_k + E,)     int32
        num_tokens_post_padded  (1,)               int32
        returns C               (M, top_k, N)      dtype same as A

    Implementation constraints (violations are scored as failures):
        - Core computation (layout-driven data fetch + grouped GEMM + weighted
          routing write-out) must be done in a HIP kernel inside the
          submitted file; calling torch.matmul / torch.mm / torch.bmm /
          torch.baddbmm / torch.addmm / torch.einsum /
          torch.nn.functional.linear or any precompiled operator library for
          any matrix multiply is forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate accumulation; the output is cast back to
          the input dtype.
        - Sentinel padding slots must not contaminate any valid output.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: non-quantized fp16/bf16 weights and activations (no w8a8 / int4 /
    mxfp4 quantization), no fused activation (SiLU/GELU etc.), no bias,
    top_k <= 8, num_experts <= 256.
    """
    def __init__(self, num_experts: int, top_k: int):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.num_experts = num_experts
        self.top_k = top_k
        # <<<END_IMPROVE>>>

    def forward(self, A, B, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().routed_gemm(
            A, B, topk_weights,
            topk_ids.to(dtype=torch.int32),
            sorted_token_ids.to(dtype=torch.int32),
            expert_ids.to(dtype=torch.int32),
            num_tokens_post_padded.to(dtype=torch.int32),
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        sorted_token_ids = sorted_token_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        expert_ids = expert_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens_post_padded = num_tokens_post_padded.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = A.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        E, N, _ = B.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        a = A.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        b = B.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        w = topk_weights.to(torch.float32).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.zeros(M, top_k, N, dtype=torch.float32, device=A.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        flat_out = out.view(M * top_k, N)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        a_rp = a.repeat_interleave(top_k, dim=0)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        flat_ids = topk_ids.reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        for e in range(E):
            mask = flat_ids == e
            if bool(mask.any()):
                flat_out[mask] = (a_rp[mask] @ b[e].t()) * w[mask][:, None]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return out.to(A.dtype)
        # <<<END_IMPROVE>>>
