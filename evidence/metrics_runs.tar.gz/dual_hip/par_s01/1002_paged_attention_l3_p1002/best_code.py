import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void paged_attention_out(torch::Tensor query, torch::Tensor key_cache, torch::Tensor value_cache, torch::Tensor block_tables, torch::Tensor seq_lens, torch::Tensor out, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention_out", &paged_attention_out);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

struct AttentionLayout {
    int64_t q[3], k[4], v[4], o[3], bt[2], ls;
    int B, H, D, HK, bs;
};

template<typename T, int C>
__global__ void paged_online(const T* query, const T* key, const T* value,
                             const int64_t* tables, const int32_t* lengths,
                             T* output, AttentionLayout p, float scale) {
    int lane = threadIdx.x & 63;
    int head = blockIdx.x * 4 + threadIdx.x / 64;
    if (head >= p.B * p.H) return;
    int s = head / p.H, h = head % p.H;
    int kh = h / (p.H / p.HK);
    int n = lengths[(int64_t)s * p.ls];
    float q[C], acc[C];
    #pragma unroll
    for (int i=0; i<C; ++i) {
        int d = lane + i*64;
        q[i] = d < p.D ? float(query[s*p.q[0]+h*p.q[1]+d*p.q[2]]) * scale : 0.f;
        acc[i] = 0.f;
    }
    float m = -INFINITY, z = 0.f;
    for (int logical_page=0, token_base=0; token_base<n; ++logical_page, token_base+=p.bs) {
        int64_t page = tables[s*p.bt[0]+logical_page*p.bt[1]];
        int64_t key_base = page*p.k[0]+kh*p.k[1];
        int64_t value_base = page*p.v[0]+kh*p.v[1];
        int valid_tokens = p.bs < n-token_base ? p.bs : n-token_base;
        int token_offset=0;
        if constexpr (C <= 2) {
            constexpr int TOKEN_TILE = C == 1 ? 4 : 2;
            for (; token_offset+TOKEN_TILE<=valid_tokens; token_offset+=TOKEN_TILE) {
                float keys[TOKEN_TILE][C], values[TOKEN_TILE][C];
                #pragma unroll
                for (int t=0; t<TOKEN_TILE; ++t) {
                    int64_t ko = key_base+(token_offset+t)*p.k[2];
                    int64_t vo = value_base+(token_offset+t)*p.v[2];
                    #pragma unroll
                    for (int i=0; i<C; ++i) {
                        int d = lane+i*64;
                        keys[t][i] = d < p.D ? float(key[ko+d*p.k[3]]) : 0.f;
                        values[t][i] = d < p.D ? float(value[vo+d*p.v[3]]) : 0.f;
                    }
                }
                #pragma unroll
                for (int t=0; t<TOKEN_TILE; ++t) {
                    float score = 0.f;
                    #pragma unroll
                    for (int i=0; i<C; ++i) {
                        int d = lane+i*64;
                        if (d < p.D) score += q[i]*keys[t][i];
                    }
                    #pragma unroll
                    for (int offset=32; offset>0; offset/=2)
                        score += __shfl_xor(score, offset, 64);
                    float nm = fmaxf(m, score);
                    bool raises_max = score > m;
                    float delta = raises_max ? m - score : score - m;
                    float e = expf(delta);
                    float a = raises_max ? e : 1.f;
                    float b = raises_max ? 1.f : e;
                    z = a*z+b;
                    #pragma unroll
                    for (int i=0; i<C; ++i) {
                        int d = lane+i*64;
                        if (d < p.D) acc[i] = a*acc[i]+b*values[t][i];
                    }
                    m = nm;
                }
            }
        }
        for (; token_offset<valid_tokens; ++token_offset) {
            int64_t ko = key_base+token_offset*p.k[2];
            int64_t vo = value_base+token_offset*p.v[2];
            float score = 0.f;
            #pragma unroll
            for (int i=0; i<C; ++i) {
                int d = lane+i*64;
                if (d < p.D) score += q[i]*float(key[ko+d*p.k[3]]);
            }
            // The unused placeholder is eliminated for larger specializations.
            float value_regs[C <= 2 ? C : 1];
            if constexpr (C <= 2) {
                #pragma unroll
                for (int i=0; i<C; ++i) {
                    int d = lane+i*64;
                    value_regs[i] = d < p.D ? float(value[vo+d*p.v[3]]) : 0.f;
                }
            }
            #pragma unroll
            for (int offset=32; offset>0; offset/=2)
                score += __shfl_xor(score, offset, 64);
            float nm = fmaxf(m, score);
            bool raises_max = score > m;
            float delta = raises_max ? m - score : score - m;
            float e = expf(delta);
            float a = raises_max ? e : 1.f;
            float b = raises_max ? 1.f : e;
            z = a*z+b;
            #pragma unroll
            for (int i=0; i<C; ++i) {
                int d = lane+i*64;
                if constexpr (C <= 2) {
                    if (d < p.D) acc[i] = a*acc[i]+b*value_regs[i];
                } else {
                    if (d < p.D) acc[i] = a*acc[i]+b*float(value[vo+d*p.v[3]]);
                }
            }
            m = nm;
        }
    }
    #pragma unroll
    for (int i=0; i<C; ++i) {
        int d = lane+i*64;
        if (d < p.D) output[s*p.o[0]+h*p.o[1]+d*p.o[2]] = T(z > 0.f ? acc[i]/z : 0.f);
    }
}

#define RUN(C) paged_online<scalar_t,C><<<grid,block,0,stream>>>(q,k,v,bt,ls,o,p,float(scale))

void paged_attention_out(torch::Tensor query, torch::Tensor key_cache, torch::Tensor value_cache,
                         torch::Tensor block_tables, torch::Tensor seq_lens, torch::Tensor out, double scale) {
    c10::cuda::CUDAGuard guard(query.device());
    AttentionLayout p;
    p.B=query.size(0); p.H=query.size(1); p.D=query.size(2);
    p.HK=key_cache.size(1); p.bs=key_cache.size(2);
    for(int i=0;i<3;++i) { p.q[i]=query.stride(i); p.o[i]=out.stride(i); }
    for(int i=0;i<4;++i) { p.k[i]=key_cache.stride(i); p.v[i]=value_cache.stride(i); }
    p.bt[0]=block_tables.stride(0); p.bt[1]=block_tables.stride(1); p.ls=seq_lens.stride(0);
    TORCH_CHECK(p.D <= 4096, "Unsupported head dimension");
    if (p.B*p.H == 0) return;
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, query.scalar_type(), "paged_online", [&] {
        const scalar_t* q=query.data_ptr<scalar_t>();
        const scalar_t* k=key_cache.data_ptr<scalar_t>();
        const scalar_t* v=value_cache.data_ptr<scalar_t>();
        const int64_t* bt=block_tables.data_ptr<int64_t>();
        const int32_t* ls=seq_lens.data_ptr<int32_t>();
        scalar_t* o=out.data_ptr<scalar_t>();
        dim3 grid((p.B*p.H+3)/4), block(256);
        if(p.D<=64) { RUN(1); }
        else if(p.D<=128) { RUN(2); }
        else if(p.D<=256) { RUN(4); }
        else if(p.D<=512) { RUN(8); }
        else if(p.D<=1024) { RUN(16); }
        else if(p.D<=2048) { RUN(32); }
        else { RUN(64); }
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
#undef RUN
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Paged attention in the decode phase (single-token query), supporting both
    MHA and GQA.

    The KV cache is stored page-wise with a fixed block_size in the physical block
    pools key_cache / value_cache, and each sequence addresses them indirectly
    through the physical block ids in block_tables; the KV length that actually
    participates in attention for each sequence is given by seq_lens[s], while the
    remaining slots in the pool hold garbage data and must not participate in the
    computation. For query head h of sequence s (whose KV head is
    h // query_group_size):
      logits[l] = scale * <query[s,h,:], key_cache[bt[s,l//bs], h_kv, l%bs, :]>
      p = softmax(logits[0:seq_lens[s]])
      out[s,h,:] = sum_l p[l] * value_cache[bt[s,l//bs], h_kv, l%bs, :]
    The softmax uses an online (numerically stable) formulation; intermediates are
    accumulated in float32 and the output is cast back to the input dtype.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        aiter / torch.matmul / torch.bmm / torch.einsum / torch.softmax is
        forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output back to the input
        dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-token decode, non-quantized KV, no ALiBi, no sliding window.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        block_tables = block_tables.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        H_KV = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        bs = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _pyramidkernel_get_extension().paged_attention_out(query, key_cache, value_cache, block_tables, seq_lens, out, self.scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out
        # <<<END_IMPROVE>>>
