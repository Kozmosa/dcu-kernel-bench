import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3010_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor select_rows(torch::Tensor x, int64_t k);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) { m.def("select_rows", &select_rows); }
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

struct Pair { float v; int i; };
__device__ __forceinline__ Pair better(Pair a, Pair b) {
    return b.i >= 0 && (a.i < 0 || b.v > a.v || (b.v == a.v && b.i < a.i)) ? b : a;
}
__device__ __forceinline__ Pair wave_max(Pair a) {
    for (int d = warpSize / 2; d; d /= 2) {
        Pair b = {__shfl_down(a.v, d), __shfl_down(a.i, d)};
        a = better(a, b);
    }
    return a;
}
template<int N>
__global__ void short_rows8(const float* x, float* out, int m, int64_t rows) {
    int lane = threadIdx.x % warpSize;
    int64_t row = (int64_t)blockIdx.x * (blockDim.x / warpSize) + threadIdx.x / warpSize;
    if (row >= rows) return;
    Pair r[N];
    #pragma unroll
    for (int j = 0; j < N; ++j) {
        int col = lane + j * warpSize;
        r[j] = col < m ? Pair{x[row*m+col], col} : Pair{0.0f, -1};
    }
    #pragma unroll
    for (int q = 0; q < 8; ++q) {
        Pair a = {0.0f, -1};
        #pragma unroll
        for (int j = 0; j < N; ++j) a = better(a, r[j]);
        a = wave_max(a);
        a.v = __shfl(a.v, 0);
        a.i = __shfl(a.i, 0);
        if (lane == 0) {
            out[row*16+q] = a.v;
            out[row*16+8+q] = (float)a.i;
        }
        #pragma unroll
        for (int j = 0; j < N; ++j) if (r[j].i == a.i) r[j].i = -1;
    }
}
__device__ __forceinline__ Pair block_max(Pair a, Pair* s) {
    int t = threadIdx.x, lane = t % warpSize, w = t / warpSize;
    a = wave_max(a);
    if (lane == 0) s[w] = a;
    __syncthreads();
    if (w == 0) {
        a = lane < blockDim.x / warpSize ? s[lane] : Pair{0.0f, -1};
        for (int d = (blockDim.x / warpSize) / 2; d; d /= 2) {
            Pair b = {__shfl_down(a.v, d), __shfl_down(a.i, d)};
            a = better(a, b);
        }
        if (lane == 0) s[8] = a;
    }
    __syncthreads();
    // The next invocation writes only disjoint partial slots before its first
    // barrier, so all threads read this winner before s[8] can be overwritten.
    return s[8];
}
__global__ void chunks8(const float* x, float* vals, int* ids, float* out, int m, int chunks) {
    __shared__ Pair shared[9];
    int row = blockIdx.x / chunks, chunk = blockIdx.x % chunks;
    Pair r[8];
    #pragma unroll
    for (int j = 0; j < 8; ++j) {
        int col = chunk * 2048 + threadIdx.x + j * 256;
        r[j] = col < m ? Pair{x[(int64_t)row*m+col], col} : Pair{0.0f, -1};
    }
    Pair head = {0.0f, -1};
    #pragma unroll
    for (int j = 0; j < 8; ++j) head = better(head, r[j]);
    #pragma unroll
    for (int q = 0; q < 8; ++q) {
        Pair a = block_max(head, shared);
        if (threadIdx.x == 0) {
            if (chunks == 1) {
                out[(int64_t)row*16+q] = a.v;
                out[(int64_t)row*16+8+q] = (float)a.i;
            } else {
                int64_t pos = (int64_t)blockIdx.x*8+q;
                vals[pos] = a.v; ids[pos] = a.i;
            }
        }
        if (q < 7 && head.i >= 0 && head.i == a.i) {
            #pragma unroll
            for (int j = 0; j < 8; ++j) if (r[j].i == a.i) r[j].i = -1;
            head = {0.0f, -1};
            #pragma unroll
            for (int j = 0; j < 8; ++j) head = better(head, r[j]);
        }
    }
}
// The same scan handles the compact candidate list and arbitrary-k rows.
__global__ void scan_rows(const float* x, const int* ids, float* out, int m, int k) {
    __shared__ Pair shared[9];
    int row = blockIdx.x;
    if (ids != nullptr && k == 8 && m <= 1024) {
        Pair r[4];
        #pragma unroll
        for (int j = 0; j < 4; ++j) {
            int col = threadIdx.x + j * 256;
            int64_t p = (int64_t)row*m + col;
            r[j] = col < m ? Pair{x[p], ids[p]} : Pair{0.0f, -1};
        }
        Pair head = {0.0f, -1};
        #pragma unroll
        for (int j = 0; j < 4; ++j) head = better(head, r[j]);
        #pragma unroll
        for (int q = 0; q < 8; ++q) {
            Pair a = block_max(head, shared);
            if (threadIdx.x == 0) {
                out[(int64_t)row*2*k+q] = a.v;
                out[(int64_t)row*2*k+k+q] = (float)a.i;
            }
            if (q < 7 && head.i >= 0 && head.i == a.i) {
                #pragma unroll
                for (int j = 0; j < 4; ++j) if (r[j].i == a.i) r[j].i = -1;
                head = {0.0f, -1};
                #pragma unroll
                for (int j = 0; j < 4; ++j) head = better(head, r[j]);
            }
        }
        return;
    }
    float previous = 0.0f;
    for (int q = 0; q < k; ++q) {
        Pair a = {0.0f, -1};
        for (int col = threadIdx.x; col < m; col += blockDim.x) {
            int64_t p = (int64_t)row*m+col;
            float v = x[p];
            int id = ids ? ids[p] : col;
            if (id >= 0 && (q == 0 || v < previous)) a = better(a, Pair{v, id});
        }
        a = block_max(a, shared);
        if (threadIdx.x == 0) {
            out[(int64_t)row*2*k+q] = a.v;
            out[(int64_t)row*2*k+k+q] = (float)a.i;
        }
        previous = a.v;
    }
}
torch::Tensor select_rows(torch::Tensor x, int64_t k) {
    TORCH_CHECK(x.is_cuda() && x.scalar_type() == torch::kFloat32 && x.is_contiguous() && x.dim() == 2, "expected contiguous device fp32 matrix");
    int64_t b = x.size(0), m = x.size(1);
    TORCH_CHECK(k >= 1 && k <= m && m < (1LL<<24), "invalid dimensions");
    c10::cuda::CUDAGuard guard(x.device());
    auto stream = at::cuda::getCurrentCUDAStream();
    auto out = torch::empty({b, 2*k}, x.options());
    if (k == 8 && m <= 256) {
        hipDeviceProp_t props;
        TORCH_CHECK(hipGetDeviceProperties(&props, x.get_device()) == hipSuccess, "device properties unavailable");
        int width = props.warpSize;
        if (width == 32 || width == 64) {
            int waves = 256 / width;
            int64_t blocks = (b + waves - 1) / waves;
            if (width == 64) {
                short_rows8<4><<<blocks,256,0,stream>>>(x.data_ptr<float>(), out.data_ptr<float>(), m, b);
            } else {
                short_rows8<8><<<blocks,256,0,stream>>>(x.data_ptr<float>(), out.data_ptr<float>(), m, b);
            }
            return out;
        }
    }
    if (k == 8) {
        int chunks = (m + 2047) / 2048;
        if (chunks == 1) {
            chunks8<<<b,256,0,stream>>>(x.data_ptr<float>(), nullptr, nullptr, out.data_ptr<float>(), m, chunks);
        } else {
            auto vals = torch::empty({b, (int64_t)chunks*8}, x.options());
            auto ids = torch::empty({b, (int64_t)chunks*8}, x.options().dtype(torch::kInt32));
            chunks8<<<b*chunks,256,0,stream>>>(x.data_ptr<float>(), vals.data_ptr<float>(), ids.data_ptr<int>(), out.data_ptr<float>(), m, chunks);
            scan_rows<<<b,256,0,stream>>>(vals.data_ptr<float>(), ids.data_ptr<int>(), out.data_ptr<float>(), chunks*8, 8);
        }
    } else {
        scan_rows<<<b,256,0,stream>>>(x.data_ptr<float>(), nullptr, out.data_ptr<float>(), m, k);
    }
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    In-row Top-K selection: for every row of a 2-D score matrix take the k
    largest values (strictly descending) together with their original column
    indices. This operator is the selection stage of MoE gating, where top-k
    routing is applied to the expert logits.

    Operator semantics: the input x has shape (B, M) and, independently for every
    row b:
        (values[b, :], indices[b, :]) = TopK(x[b, :], k)
    values[b, :] are the k largest elements of x[b, :] in strictly descending
    order; indices[b, j] is the column index of values[b, j] inside that row
    (0 <= indices[b, j] < M, distinct within a row), that is out[b, k + j]
    satisfies x[b, out[b, k + j]] == out[b, j]. Mathematically this equals a full
    descending sort of each row followed by taking the first k values and their
    original column positions. Boundary behaviour: k = 1 degenerates to the row
    maximum and its argmax; k = M degenerates to a descending argsort of the whole
    row; with M = 1 the output is that row's only element and index 0. The
    evaluation inputs guarantee that the elements of each row are mutually
    unequal (built as a random permutation of a set of distinct values), so the
    Top-K result is uniquely determined -- the tie order of equal values is not
    part of this task's semantics.

    Implementation path hints (free choice):
      - short rows (M <= 1024): a single kernel selecting the maximum round by
        round -- each round takes the current maximum and the column index of its
        first occurrence, writes them out and then masks that position with the
        smallest float32 value, for exactly k rounds;
      - long rows (M > 1024): two stages -- cut the row into fixed-length chunks,
        run a local Top-K per chunk to obtain chunk_num*k candidates (values plus
        global column indices), then merge-sort the candidates and take the first
        k.

    Input/output specification:
        x   (B, M) float32 (the evaluator casts all inputs to fp32 before passing
            them in), contiguous, row elements mutually unequal; B >= 1,
            M >= 1 and < 2^24 (column indices are exactly representable in the
            fp32 packing), non powers of two allowed; the task scale domain is
            M in [16, 131072].
        k   constructor hyperparameter (passed via __init__), 1 <= k <= M.
        out (B, 2*k) a single float32 tensor (evaluation protocol: single-tensor
            output):
            out[:, :k]   = values (strictly descending, a bit-exact copy of the
                           input values)
            out[:, k:]   = indices (integer column indices, < 2^24, exactly
                           representable in fp32)
        The output is a pure selection result (no arithmetic), so any single bit
        of deviation is a semantic error.

    Implementation constraints (violations are scored as failures):
      - The core Top-K selection (scan / tiling / merge) must be done with a
        HIP kernel inside the submitted file, with both values and indices
        written by the kernel; numeric comparison happens in float32.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - The first k output columns must be strictly descending; the last k
        columns must be the original column indices (not chunk-local indices and
        not sort ranks).

    Disallowed list: aiter / torch.topk / torch.sort / torch.argsort /
    torch.kthvalue / torch.mode, plus the Tensor method forms of the shortcuts
    above .topk( / .sort( / .argsort( / .kthvalue( -- calling a selection
    operator directly and doing a full sort to take the first k are the same
    shortcut, so any appearance in any form fails (Triton primitives are
    unrestricted).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, k: int = 8):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert k >= 1, "k must be >= 1"
        self.k = int(k)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        x = x.to(torch.float32).contiguous()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        out = _pyramidkernel_get_extension().select_rows(x, self.k)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        return out
        # <<<END_IMPROVE>>>
