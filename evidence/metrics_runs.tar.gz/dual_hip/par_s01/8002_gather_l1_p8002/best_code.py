import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l1_p8002_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor gather_forward(torch::Tensor data, torch::Tensor indices, int64_t axis, bool gather_elements);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("gather_forward", &gather_forward, "HIP gather forward");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/hip/HIPContext.h>
#include <c10/util/BFloat16.h>
#include <cstdint>
#include <climits>

namespace {

template <typename scalar_t, typename index_t, typename address_t, bool Elements>
__global__ void gather_kernel(const scalar_t* __restrict__ data,
                              const index_t* __restrict__ indices,
                              scalar_t* __restrict__ out,
                              address_t total,
                              address_t outer,
                              address_t out_axis,
                              address_t inner,
                              address_t data_axis) {
    address_t p = static_cast<address_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    address_t stride = static_cast<address_t>(blockDim.x) * gridDim.x;
    for (; p < total; p += stride) {
        address_t outer_pos = p / (out_axis * inner);
        address_t rem = p - outer_pos * out_axis * inner;
        address_t axis_pos = rem / inner;
        address_t inner_pos = rem - axis_pos * inner;
        address_t selected = Elements ? static_cast<address_t>(indices[p])
                                     : static_cast<address_t>(indices[axis_pos]);
        address_t source = (outer_pos * data_axis + selected) * inner + inner_pos;
        out[p] = data[source];
    }
}

template <typename scalar_t, typename index_t, bool Elements>
void launch_address(const scalar_t* src, const index_t* idx, scalar_t* dst,
                    int blocks, hipStream_t stream, int64_t total,
                    int64_t outer, int64_t out_axis, int64_t inner,
                    int64_t data_axis, bool narrow) {
    if (narrow) {
        hipLaunchKernelGGL((gather_kernel<scalar_t, index_t, uint32_t, Elements>), dim3(blocks), dim3(256), 0, stream,
                           src, idx, dst, static_cast<uint32_t>(total), static_cast<uint32_t>(outer),
                           static_cast<uint32_t>(out_axis), static_cast<uint32_t>(inner),
                           static_cast<uint32_t>(data_axis));
    } else {
        hipLaunchKernelGGL((gather_kernel<scalar_t, index_t, int64_t, Elements>), dim3(blocks), dim3(256), 0, stream,
                           src, idx, dst, static_cast<int64_t>(total), static_cast<int64_t>(outer),
                           static_cast<int64_t>(out_axis), static_cast<int64_t>(inner),
                           static_cast<int64_t>(data_axis));
    }
}

template <typename scalar_t>
void launch_data(torch::Tensor data, torch::Tensor indices, torch::Tensor out,
                 int64_t outer, int64_t out_axis, int64_t inner,
                 int64_t data_axis, bool elements) {
    int64_t total = out.numel();
    int blocks = static_cast<int>(std::min<int64_t>((total + 255) / 256, 65535));
    if (blocks < 1) blocks = 1;
    if (blocks > 65535) blocks = 65535;
    hipStream_t stream = at::hip::getCurrentHIPStream(data.device().index());
    const scalar_t* src = data.data_ptr<scalar_t>();
    scalar_t* dst = out.data_ptr<scalar_t>();
    bool narrow = data.numel() <= INT32_MAX && total <= INT32_MAX;
    if (indices.scalar_type() == at::kInt) {
        if (elements) {
            launch_address<scalar_t, int32_t, true>(src, indices.data_ptr<int32_t>(), dst, blocks, stream,
                           total, outer, out_axis, inner, data_axis, narrow);
        } else {
            launch_address<scalar_t, int32_t, false>(src, indices.data_ptr<int32_t>(), dst, blocks, stream,
                           total, outer, out_axis, inner, data_axis, narrow);
        }
    } else if (indices.scalar_type() == at::kLong) {
        if (elements) {
            launch_address<scalar_t, int64_t, true>(src, indices.data_ptr<int64_t>(), dst, blocks, stream,
                           total, outer, out_axis, inner, data_axis, narrow);
        } else {
            launch_address<scalar_t, int64_t, false>(src, indices.data_ptr<int64_t>(), dst, blocks, stream,
                           total, outer, out_axis, inner, data_axis, narrow);
        }
    } else {
        if (elements) {
            launch_address<scalar_t, float, true>(src, indices.data_ptr<float>(), dst, blocks, stream,
                           total, outer, out_axis, inner, data_axis, narrow);
        } else {
            launch_address<scalar_t, float, false>(src, indices.data_ptr<float>(), dst, blocks, stream,
                           total, outer, out_axis, inner, data_axis, narrow);
        }
    }
}

}

torch::Tensor gather_forward(torch::Tensor data, torch::Tensor indices, int64_t axis, bool gather_elements) {
    TORCH_CHECK(data.is_contiguous(), "data must be contiguous");
    TORCH_CHECK(indices.is_contiguous(), "indices must be contiguous");
    TORCH_CHECK(data.is_cuda(), "data must be on accelerator");
    int64_t ndim = data.dim();
    TORCH_CHECK(ndim > 0, "data must have at least one dimension");
    axis %= ndim;
    if (axis < 0) axis += ndim;

    int64_t data_axis = data.size(axis);
    int64_t out_axis = gather_elements ? indices.size(axis) : indices.numel();
    int64_t outer = 1;
    for (int64_t i = 0; i < axis; ++i) outer *= data.size(i);
    int64_t inner = 1;
    for (int64_t i = axis + 1; i < ndim; ++i) inner *= data.size(i);

    std::vector<int64_t> shape;
    if (gather_elements) {
        shape.assign(indices.sizes().begin(), indices.sizes().end());
    } else {
        shape.assign(data.sizes().begin(), data.sizes().end());
        shape[axis] = out_axis;
    }
    auto out = torch::empty(shape, data.options());
    AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16, data.scalar_type(), "hip_gather", [&] {
        launch_data<scalar_t>(data, indices, out, outer, out_axis, inner, data_axis, gather_elements);
    });
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Gather / GatherElements: the index-movement family that selects elements
    along a given axis by integer index.

    The __init__ parameter `variant` selects one of two paths; their semantics
    are defined as follows:
        "gather" (select along an axis): `indices` is a 1-D integer vector of
            arbitrary length K;
            out[i_0, ..., i_{axis-1}, j, i_{axis+1}, ...] =
                data[i_0, ..., i_{axis-1}, indices[j], i_{axis+1}, ...]
            i.e. indices[j] picks one whole slice along dimension `axis` at a
            time; the output shape equals the data shape with dimension `axis`
            replaced by K.
        "gather_elements" (element-wise selection with a same-shaped index):
            `indices` has the same rank as data, with every dimension equal to
            data except dimension `axis` (whose length K may differ from data);
            out[i_0, ..., i_{n-1}] = data[i_0, ..., m, ..., i_{n-1}] where
            m = indices[i_0, ..., i_{n-1}] -- each output element takes its own
            subscript along `axis`; the output shape equals the indices shape.
    The difference: gather's index is a 1-D vector that decides how a whole
    slice along `axis` is selected at once; gather_elements' index has the same
    shape as the output and specifies the subscript along `axis` per element.
    The __init__ parameter `axis` sets the selection dimension (torch
    convention: non-negative counts from 0, negative counts from the end),
    defaulting to 1.

    Numeric contract: this operator is pure index movement with no arithmetic.
    A correct implementation produces an output bit-identical to the selected
    elements of the input (bit patterns preserved; no dtype conversion, no
    numeric operation).

    Input/output specification:
        data    float32 / float16 / bfloat16, contiguous, ndim in [1, 4],
                every dimension >= 1, total element count <= 2^23; values are
                ordinary randn magnitude (no inf/NaN)
        indices an integer tensor: for variant="gather" an int64 1-D tensor
                (length K >= 1); for variant="gather_elements" an int32 tensor
                with the same rank as data (shape constraints above); every
                index value lies in [0, data.shape[axis]) -- the input contains
                no out-of-range index
        out     a single tensor, same dtype as data, contiguous: for gather its
                shape is the data shape with dimension `axis` replaced by K;
                for gather_elements its shape is the indices shape. forward must
                return a single tensor (the evaluator compares .shape /
                allclose on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (indices are small non-negative integers < 2^24 and are exactly
        representable in fp32, so they are recovered losslessly; fp16/bf16 ->
        fp32 is also lossless). The offline final audit passes inputs natively
        in their declared dtype -- the implementation must be correct for both.

    Boundary behaviour: K=1, K different from data.shape[axis], an axis of
    length 1, non-power-of-two / prime lengths, and repeated indices hitting the
    same element must all be handled correctly; a negative `axis` follows the
    torch convention.

    Implementation constraints (violations are scored as failures):
        - The core computation (index expansion / address computation plus
          load/store at those addresses) must be completed with a HIP kernel
          inside the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Pure-movement contract: the output is bit-identical to the selected
          elements of data (including float16 / bfloat16 bit patterns); no
          numeric transformation may be introduced.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.gather / .gather( / torch.index_select /
    .index_select( / torch.take_along_dim / .take_along_dim( /
    torch.take( / .take( (including the Tensor.take method form) /
    torch.embedding / nn.Embedding / .embedding( / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "gather", axis: int = 1):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("gather", "gather_elements"), "variant must be one of gather / gather_elements"
        self.variant = variant
        self.axis = int(axis)
        # <<<END_IMPROVE>>>

    def forward(self, data, indices):
        # <<<IMPROVE:forward_stmt_1>>>
        ndim = data.dim()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        axis = self.axis % ndim
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        idx = indices
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        if self.variant == "gather_elements":
                    return _pyramidkernel_get_extension().gather_forward(data, idx, axis, True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        return _pyramidkernel_get_extension().gather_forward(data, idx, axis, False)
        # <<<END_IMPROVE>>>
