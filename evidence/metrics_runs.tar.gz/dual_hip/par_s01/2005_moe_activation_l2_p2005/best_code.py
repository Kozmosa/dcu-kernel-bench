import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2005_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor moe_activation(torch::Tensor x, std::string name, double alpha, double limit, bool scaled, bool limited);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_activation", &moe_activation);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cmath>
#include <cstdint>
#include <climits>

template <typename IndexT, bool HotScaledChunked = false>
__global__ void moe_kernel(const float* __restrict__ x, float* __restrict__ y, IndexT count, IndexT n, int mode, float alpha, float limit, bool scaled, bool limited) {
    IndexT i = static_cast<IndexT>(blockIdx.x) * static_cast<IndexT>(blockDim.x) + static_cast<IndexT>(threadIdx.x);
    if (i >= count) return;

    if (HotScaledChunked) {
        IndexT p = (i / n) * (static_cast<IndexT>(2) * n) + i % n;
        float g = fminf(x[p], 7.0f);
        float u = fminf(fmaxf(x[p + n], -7.0f), 7.0f);
        float z = 1.702f * g;
        y[i] = (g * (1.0f / (1.0f + expf(-z)))) * (u + 1.0f);
        return;
    }

    bool gated = mode < 5;
    IndexT p = i;
    if (gated) p = mode == 4 ? 2*i : (i/n)*(2*n) + i%n;
    float g = x[p];
    float u = gated ? x[p + (mode == 4 ? 1 : n)] : 1.0f;
    float v;
    if (mode == 0 || mode == 4) {
        if (limited || mode == 4) {
            g = fminf(g, limit);
            u = fminf(fmaxf(u, -limit), limit);
        }
        bool scale = scaled || mode == 4;
        float z = scale ? alpha*g : g;
        v = (g * (1.0f / (1.0f + expf(-z)))) * (scale ? u + 1.0f : u);
    } else if (mode == 3) {
        v = fminf(g * (1.0f / (1.0f + expf(-g))), limit) * fminf(fmaxf(u, -limit), limit);
    } else if (mode == 1 || mode == 6) {
        v = (0.5f*g) * (1.0f + erff(g*0.7071067811865476f)) * u;
    } else if (mode == 2 || mode == 7) {
        float cubic = ((0.044715f*g)*g)*g;
        float inner = 0.7978845608028654f * (g + cubic);
        v = (0.5f*g) * (1.0f + tanhf(inner)) * u;
    } else if (mode == 5) {
        v = g * (1.0f / (1.0f + expf(-g)));
    } else {
        float r = fmaxf(g, 0.0f);
        v = r*r;
    }
    y[i] = v;
}

__device__ __forceinline__ float moe_hot_lane(float g, float u) {
    g = fminf(g, 7.0f);
    u = fminf(fmaxf(u, -7.0f), 7.0f);
    float z = 1.702f * g;
    return (g * (1.0f / (1.0f + expf(-z)))) * (u + 1.0f);
}

template <typename IndexT>
__global__ void moe_hot_float4(const float4* __restrict__ x, float4* __restrict__ y, IndexT count4, IndexT n4) {
    IndexT i = static_cast<IndexT>(blockIdx.x) * static_cast<IndexT>(blockDim.x) + static_cast<IndexT>(threadIdx.x);
    if (i >= count4) return;
    IndexT p = (i / n4) * (static_cast<IndexT>(2) * n4) + i % n4;
    float4 g = x[p];
    float4 u = x[p + n4];
    float4 v;
    v.x = moe_hot_lane(g.x, u.x);
    v.y = moe_hot_lane(g.y, u.y);
    v.z = moe_hot_lane(g.z, u.z);
    v.w = moe_hot_lane(g.w, u.w);
    y[i] = v;
}

torch::Tensor moe_activation(torch::Tensor x, std::string name, double alpha, double limit, bool scaled, bool limited) {
    TORCH_CHECK(x.is_cuda() && x.is_contiguous() && x.scalar_type() == at::kFloat, "expected contiguous GPU float32 input");
    TORCH_CHECK(x.dim() == 2, "expected 2D input");
    c10::cuda::CUDAGuard guard(x.device());
    int mode = -1;
    if (name == "silu") mode = 0;
    else if (name == "gelu") mode = 1;
    else if (name == "gelu_tanh") mode = 2;
    else if (name == "swiglustep") mode = 3;
    else if (name == "swiglu_interleaved") mode = 4;
    else if (name == "silu_no_mul") mode = 5;
    else if (name == "gelu_no_mul") mode = 6;
    else if (name == "gelu_tanh_no_mul") mode = 7;
    else if (name == "relu2") mode = 8;
    TORCH_CHECK(mode >= 0, "unknown activation");
    TORCH_CHECK(mode >= 5 || x.size(1)%2 == 0, "gated input width must be even");
    int64_t n = mode < 5 ? x.size(1)/2 : x.size(1);
    auto y = torch::empty({x.size(0), n}, x.options());
    int64_t count = y.numel();
    if (count) {
        auto stream = at::cuda::getCurrentCUDAStream();
        int block_size = count < 8192 ? 128 : 256;
        bool hot_scaled_chunked = mode == 0 && scaled && limited && static_cast<float>(alpha) == 1.702f && static_cast<float>(limit) == 7.0f;
        bool vector_hot = hot_scaled_chunked && count % 4 == 0 && n % 4 == 0 &&
            reinterpret_cast<uintptr_t>(x.data_ptr<float>()) % 16 == 0 &&
            reinterpret_cast<uintptr_t>(y.data_ptr<float>()) % 16 == 0;
        if (x.numel() <= static_cast<int64_t>(INT32_MAX) && count <= static_cast<int64_t>(INT32_MAX) - 255) {
            if (vector_hot) {
                moe_hot_float4<int32_t><<<(count/4 + block_size - 1)/block_size, block_size, 0, stream>>>(reinterpret_cast<const float4*>(x.data_ptr<float>()), reinterpret_cast<float4*>(y.data_ptr<float>()), static_cast<int32_t>(count/4), static_cast<int32_t>(n/4));
            } else if (hot_scaled_chunked) {
                moe_kernel<int32_t, true><<<(count + block_size - 1)/block_size, block_size, 0, stream>>>(x.data_ptr<float>(), y.data_ptr<float>(), static_cast<int32_t>(count), static_cast<int32_t>(n), mode, (float)alpha, (float)limit, scaled, limited);
            } else {
                moe_kernel<int32_t, false><<<(count + block_size - 1)/block_size, block_size, 0, stream>>>(x.data_ptr<float>(), y.data_ptr<float>(), static_cast<int32_t>(count), static_cast<int32_t>(n), mode, (float)alpha, (float)limit, scaled, limited);
            }
        } else {
            if (vector_hot) {
                moe_hot_float4<int64_t><<<(count/4 + block_size - 1)/block_size, block_size, 0, stream>>>(reinterpret_cast<const float4*>(x.data_ptr<float>()), reinterpret_cast<float4*>(y.data_ptr<float>()), count/4, n/4);
            } else if (hot_scaled_chunked) {
                moe_kernel<int64_t, true><<<(count + block_size - 1)/block_size, block_size, 0, stream>>>(x.data_ptr<float>(), y.data_ptr<float>(), count, n, mode, (float)alpha, (float)limit, scaled, limited);
            } else {
                moe_kernel<int64_t, false><<<(count + block_size - 1)/block_size, block_size, 0, stream>>>(x.data_ptr<float>(), y.data_ptr<float>(), count, n, mode, (float)alpha, (float)limit, scaled, limited);
            }
        }
        TORCH_CHECK(hipGetLastError() == hipSuccess, "activation kernel launch failed");
    }
    return y;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    MoE FFN activation variant family: gated activations (SwiGLU family
    variants) and non-gated element-wise activations, dispatched by the __init__
    parameters activation / alpha / limit.

    All computation runs in float32 and the output is cast back to the input dtype.
    Define
        SiLU(u)      = u * sigmoid(u)
        GELU(u)      = 0.5 * u * (1 + erf(u * 0.7071067811865476))
        GELU_tanh(u) = 0.5 * u * (1 + tanh(0.7978845608028654
                                           * (u + 0.044715 * u^3)))
        ReLU2(u)     = max(u, 0)^2
    sigmoid / erf / tanh are all evaluated as float32 math functions.

    [gated variants] The input x has shape (M, 2N) and the output (M, N). Two data
    layouts:
        chunked (default) : gate = x[:, :N], up = x[:, N:]
        interleaved       : gate = x[:, 0::2] (even columns), up = x[:, 1::2] (odd
                            columns)
    Write the clamped quantities as gate' = min(gate, limit) (upper bound only) and
    up' = clamp(up, -limit, limit) (symmetric clamping); the output of each variant
    is:
        activation="silu", alpha=None, limit=None:
            out = SiLU(gate) * up                        (standard SwiGLU)
        activation="silu", alpha=None, limit=L:
            out = SiLU(gate') * up'                       (clamped SwiGLU)
        activation="silu", alpha=A, limit=L (A and L must be given together):
            out = gate' * sigmoid(A * gate') * (up' + 1)  (scaled clamped gate)
        activation="gelu" (does not accept alpha / limit):
            out = GELU(gate) * up
        activation="gelu_tanh" (does not accept alpha / limit):
            out = GELU_tanh(gate) * up
        activation="swiglustep" (limit defaults to 7.0, does not accept alpha):
            out = clamp(SiLU(gate), max=limit) * up'      (SiLU first, then the
                                                           upper clamp)
        activation="swiglu_interleaved" (interleaved layout; alpha defaults to
        1.702, limit defaults to 7.0):
            out = gate' * sigmoid(alpha * gate') * (up' + 1)

    [non-gated variants] The input x has shape (M, N) and the output (M, N);
    element-wise activation, alpha / limit are ignored:
        activation="silu_no_mul"      : out = SiLU(x)
        activation="gelu_no_mul"      : out = GELU(x)
        activation="gelu_tanh_no_mul" : out = GELU_tanh(x)
        activation="relu2"            : out = ReLU2(x)

    Boundary behaviour: clamping of gate is upper-bound only (nothing is clamped on
    the negative side) while clamping of up is symmetric; the clamping is applied
    before the activation, except for swiglustep, which computes SiLU first and then
    clamps the result on the upper side. Illegal parameter combinations (an unknown
    variant name; gelu / gelu_tanh with alpha or limit; swiglustep with alpha; silu
    given alpha but not limit) are rejected at construction time.

    Input/output specification:
        x    float16 / bfloat16 (M, n), contiguous, M >= 1; the gated variants
             require n to be even (N = n/2 has no alignment constraint: non-powers
             of two and sizes below the common block size are allowed); the
             non-gated variants accept any n >= 1. The evaluator casts the input to
             fp32 before passing it in; fp16/bf16 -> fp32 is lossless.
        out  same dtype as x; shape (M, n/2) for the gated variants and (M, n) for
             the non-gated ones.
        The input value range is the usual randn magnitude (no inf/NaN).

    Implementation constraints (violations are scored as failures):
        - The core computation (chunked / interleaved data selection, clamping,
          activation, gated multiply) must be completed with a HIP kernel inside
          the submitted file; intermediates are always float32.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Use float32 for intermediate accumulation; cast the output back to the
          input dtype.

    (4) Forbidden list and target hardware:
    - Calling ATen shortcuts such as torch.nn.functional.silu /
      torch.nn.functional.gelu / torch.nn.SiLU / torch.nn.GELU / torch.sigmoid /
      torch.erf / torch.tanh / torch.relu / torch.clamp to complete this task's
      computation directly is forbidden; the authoritative forbidden list is the
      task.yaml forbidden list (it covers the source operator library and other
      closed-source acceleration libraries; the final static audit does substring
      matching on the code outside docstrings / comments);
    - Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, activation: str = "silu", alpha=None, limit=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        gated = ("silu", "gelu", "gelu_tanh", "swiglustep", "swiglu_interleaved")
        nomul = ("silu_no_mul", "gelu_no_mul", "gelu_tanh_no_mul", "relu2")
        name = str(activation).lower()
        assert name in gated or name in nomul, (
            "activation must be one of " + "/".join(gated + nomul) + " variants")
        if name in ("gelu", "gelu_tanh"):
            assert alpha is None and limit is None, "gelu / gelu_tanh do not accept alpha / limit"
        if name == "swiglustep":
            assert alpha is None, "swiglustep does not accept alpha"
        if name == "silu" and alpha is not None:
            assert limit is not None, "silu must set limit as well when alpha is set"
        if name == "swiglustep" and limit is None:
            limit = 7.0
        if name == "swiglu_interleaved":
            alpha = 1.702 if alpha is None else alpha
            limit = 7.0 if limit is None else limit
        self.activation = name
        self.is_gated = name in gated
        self.alpha = None if alpha is None else float(alpha)
        self.limit = None if limit is None else float(limit)
        # <<<END_IMPROVE>>>

    def forward(self, x):
        # <<<IMPROVE:forward_stmt_1>>>
        xf = x.to(torch.float32).contiguous()
        assert xf.dim() == 2, "the input must be a 2D (M, n) tensor"
        if self.is_gated:
            assert xf.shape[-1] % 2 == 0, "the gated variants require the last dimension n to be even"
        return _pyramidkernel_get_extension().moe_activation(
            xf,
            self.activation,
            0.0 if self.alpha is None else self.alpha,
            0.0 if self.limit is None else self.limit,
            self.alpha is not None,
            self.limit is not None,
        ).to(x.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        assert xf.dim() == 2, "the input must be a 2D (M, n) tensor"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # Non-gated computation is performed in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert xf.shape[-1] % 2 == 0, "the gated variants require the last dimension n to be even"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        half = xf.shape[-1] // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        interleaved = self.activation == "swiglu_interleaved"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        gate = xf[:, 0::2] if interleaved else xf[:, :half]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        up = xf[:, 1::2] if interleaved else xf[:, half:]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Post-activation limiting is performed in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # Scaled gated activation is performed in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Limited gated activation is performed in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # Standard gated activation is performed in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # Exact GELU is performed in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # Tanh GELU is performed in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # Interleaved activation is performed in HIP.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # The fused result has already been returned.
        # <<<END_IMPROVE>>>
