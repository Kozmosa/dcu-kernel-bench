import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5005_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void spconv_fprop(torch::Tensor xf, torch::Tensor wf, torch::Tensor pairs, torch::Tensor counts, torch::Tensor out);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("spconv_fprop", &spconv_fprop);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <cstdint>

__global__ void gathered_conv(const float* __restrict__ x,
                              const float* __restrict__ w,
                              const int64_t* __restrict__ pairs,
                              const int64_t* __restrict__ counts,
                              float* __restrict__ out,
                              int64_t n, int64_t ci, int64_t co, int64_t kv) {
    const int t = threadIdx.x;
    const int64_t k = blockIdx.z;
    const int64_t base_j = int64_t(blockIdx.x) * 16;
    const int64_t base_o = int64_t(blockIdx.y) * 32;
    const int64_t valid = counts[k];
    if (base_j >= valid) return;
    __shared__ float a[16][32];
    __shared__ float b[32][32];
    const int row = t / 16;
    const int col = t % 16;
    const int r0 = t / 32;
    const int r1 = r0 + 8;
    const int64_t idx0 = base_j + r0 < valid ? pairs[k * n + base_j + r0] : 0;
    const int64_t idx1 = base_j + r1 < valid ? pairs[k * n + base_j + r1] : 0;
    float sum0 = 0.0f, sum1 = 0.0f;
    for (int64_t start = 0; start < ci; start += 32) {
        for (int q = t; q < 512; q += 256) {
            int r = q / 32, i = q % 32;
            int64_t j = base_j + r;
            float v = 0.0f;
            if (j < valid && start + i < ci) {
                int64_t idx = q < 256 ? idx0 : idx1;
                v = x[idx * ci + start + i];
            }
            a[r][i] = v;
        }
        for (int q = t; q < 1024; q += 256) {
            int o = q / 32, i = q % 32;
            float v = 0.0f;
            if (base_o + o < co && start + i < ci)
                v = w[((base_o + o) * kv + k) * ci + start + i];
            b[i][o ^ i] = v;
        }
        __syncthreads();
        #pragma unroll
        for (int i = 0; i < 32; ++i) {
            float v = a[row][i];
            sum0 = fmaf(v, b[i][col ^ i], sum0);
            sum1 = fmaf(v, b[i][(col + 16) ^ i], sum1);
        }
        __syncthreads();
    }
    if (base_j + row < valid) {
        int64_t dst = pairs[(kv + k) * n + base_j + row];
        if (base_o + col < co)
            atomicAdd(out + dst * co + base_o + col, sum0);
        if (base_o + col + 16 < co)
            atomicAdd(out + dst * co + base_o + col + 16, sum1);
    }
}

void spconv_fprop(torch::Tensor xf, torch::Tensor wf, torch::Tensor pairs,
                  torch::Tensor counts, torch::Tensor out) {
    c10::cuda::CUDAGuard guard(xf.device());
    const int64_t n = xf.size(0), ci = xf.size(1);
    const int64_t co = wf.size(0), kv = wf.size(2);
    auto stream = c10::cuda::getCurrentCUDAStream(xf.get_device());
    dim3 grid((n + 15) / 16, (co + 31) / 32, kv);
    hipLaunchKernelGGL(gathered_conv, grid, dim3(256), 0, stream.stream(),
                      xf.data_ptr<float>(), wf.data_ptr<float>(),
                      pairs.data_ptr<int64_t>(), counts.data_ptr<int64_t>(),
                      out.data_ptr<float>(), n, ci, co, kv);
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "gathered_conv launch failed: ", hipGetErrorString(err));
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Sparse convolution forward (the gathered form spconv_fprop): a per
    kernel-offset gather-GEMM-scatter forward over the sparse active points,
    driven by an index-pair table (spconv style).

    Semantic definition (out is first initialized to all zeros, then
    accumulated by the formula below):
        for each kernel offset k in [0, kv):
            n_k = indice_num_per_loc[k]
            for each j in [0, n_k):
                in_idx  = indice_pairs[0, k, j]      # input row index in [0, n)
                out_idx = indice_pairs[1, k, j]      # output row index in [0, num_act_out)
                out[out_idx, :] += features[in_idx, :] @ W[:, :, k].T
    i.e. for each index pair, gather the input row and matrix-multiply it with
    the weight matrix of offset k ((n_k, c_in) @ (c_in, c_out)), then
    scatter-accumulate by the output row index into out. The same output row may
    be hit by any number of index pairs (duplicates are allowed within the same
    k), and all of them accumulate with +=.

    The filters layout mapping (must be respected; it comes from the sample's
    as_strided rearrangement): let F be the contiguous (c_out, c_in, kv) tensor
    of the input; the library interprets its storage with strides
    (c_in*kv, 1, c_in), and the mathematical weight W and F satisfy:
        W[o, i, k] = F.reshape(c_out, kv, c_in)[o, k, i]
    which is equivalent to W = F.reshape(c_out, kv, c_in).permute(0, 2, 1)
    (still shaped (c_out, c_in, kv), a pure reinterpretation view for
    contiguous input); the weight matrix of kernel offset k is W[:, :, k],
    shaped (c_out, c_in).

    Boundary behaviour: kernel offsets with n_k = 0 are skipped entirely; when
    all n_k = 0, out stays all-zero; kv = 1 degenerates to a single-offset
    gather-scatter; num_act_out and n are independent of each other (either may
    be the larger one). Index-pair table entries with j >= n_k are padding
    garbage (they may hold any value, including duplicated valid row indices)
    and must be masked out according to indice_num_per_loc -- they must never be
    read into the computation.

    Input/output specification:
        features           float32 / float16 / bfloat16 (n, c_in), contiguous
        filters            same dtype as features (c_out, c_in, kv), contiguous
        indice_pairs       int32 (2, kv, n), contiguous
        indice_num_per_loc int32 (kv,), contiguous
        num_act_out        0-dim integer tensor (the online evaluator casts all
                           input tensors to fp32: integer indices are exact up
                           to 2^24 and are recovered with int(); the shape
                           domain of this task guarantees indices <= 2^24)
        out                a single tensor, same dtype as features
                           (num_act_out, c_out). This operator is inherently
                           single-output, with no multi-output packing segments.
    Dimension domain: n, c_in, c_out, kv, num_act_out >= 1, non-powers-of-two
    allowed; indice_num_per_loc[k] in [0, n]. Input values are ordinary randn
    magnitude (no inf/NaN).

    Implementation constraints (violations are scored as failures):
        - The core computation (gathering by index pair, the matrix
          multiplication with W[:, :, k], the scatter accumulation by output row
          index) must be done with a HIP kernel inside the submitted file; ATen
          is only allowed for non-core operations such as dtype recovery / shape
          cleanup.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate in float32 throughout (fp16/bf16 inputs are first cast
          losslessly to fp32), then cast the result back to the dtype of
          features; padding table entries must not take part in the computation
          (including out-of-bounds reads).
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.sparse / torch.sparse_coo_tensor /
    torch.sparse_csr_tensor / torch.sparse_csc_tensor / torch.sparse_mm /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear / index_add_ /
    torch.index_add / index_put / torch.index_put / scatter_add_ /
    .scatter_( / torch.scatter / segment_reduce / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, features, filters, indice_pairs, indice_num_per_loc, num_act_out):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        num_act_out = int(num_act_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        c_out, c_in, kv = filters.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        dt = features.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        xf = features.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        wf = filters.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        pairs = indice_pairs.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        counts = indice_num_per_loc.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        out = torch.zeros(num_act_out, c_out, dtype=torch.float32,
                          device=features.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _pyramidkernel_get_extension().spconv_fprop(xf, wf, pairs, counts, out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return out.to(dt)
        # <<<END_IMPROVE>>>
