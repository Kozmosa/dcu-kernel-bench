import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1029_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor paged_decode(torch::Tensor q, torch::Tensor key_cache,
                           torch::Tensor value_cache, torch::Tensor page_tables,
                           torch::Tensor seq_lens, int64_t page_size,
                           double scale);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_decode", &paged_decode, "Fused paged decode attention (HIP)");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <hip/hip_runtime.h>
#include <cmath>
#include <cstdint>

template <typename scalar_t>
__global__ void paged_decode_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ key_cache,
    const scalar_t* __restrict__ value_cache,
    const int32_t* __restrict__ page_tables,
    const int32_t* __restrict__ seq_lens,
    scalar_t* __restrict__ out,
    int B, int Hq, int Hkv, int Dqk, int Dv,
    int page_size, int table_stride, float scale) {
    int bh = blockIdx.x;
    int b = bh / Hq;
    int h = bh - b * Hq;
    if (b >= B) return;

    extern __shared__ float smem[];
    const bool register_values = Dv <= blockDim.x;
    float* accum = register_values ? nullptr : smem;
    float* partial = register_values ? smem : smem + Dv;
    float* cached_q = partial + blockDim.x;
    __shared__ float running_m;
    __shared__ float running_z;

    float reg_accum = 0.0f;
    if (!register_values) {
        for (int c = threadIdx.x; c < Dv; c += blockDim.x)
            accum[c] = 0.0f;
    }
    if (threadIdx.x == 0) {
        running_m = -INFINITY;
        running_z = 0.0f;
    }
    __syncthreads();

    int len = seq_lens[b];
    int group = Hq / Hkv;
    int kvh = h / group;
    const scalar_t* qh = q + ((int64_t)b * Hq + h) * Dqk;
    for (int d = threadIdx.x; d < Dqk; d += blockDim.x)
        cached_q[d] = static_cast<float>(qh[d]);
    __syncthreads();

    for (int l = 0; l < len; ++l) {
        int logical_page = l / page_size;
        int slot = l - logical_page * page_size;
        int physical_page = page_tables[(int64_t)b * table_stride + logical_page];
        int flat_slot = physical_page * page_size + slot;
        const scalar_t* kh = key_cache + ((int64_t)flat_slot * Hkv + kvh) * Dqk;
        const scalar_t* vh = value_cache + ((int64_t)flat_slot * Hkv + kvh) * Dv;

        float dot = 0.0f;
        for (int d = threadIdx.x; d < Dqk; d += blockDim.x)
            dot += cached_q[d] * static_cast<float>(kh[d]);
        int lane = threadIdx.x % warpSize;
        int wave = threadIdx.x / warpSize;
        for (int step = warpSize / 2; step > 0; step >>= 1)
            dot += __shfl_down(dot, step, warpSize);
        if (lane == 0)
            partial[wave] = dot;
        __syncthreads();
        if (wave == 0) {
            float wave_sum = lane < blockDim.x / warpSize ? partial[lane] : 0.0f;
            for (int step = warpSize / 2; step > 0; step >>= 1)
                wave_sum += __shfl_down(wave_sum, step, warpSize);
            if (lane == 0) {
                float logit = wave_sum * scale;
                float new_m = running_m > logit ? running_m : logit;
                float alpha = isfinite(running_m) ? expf(running_m - new_m) : 0.0f;
                float beta = expf(logit - new_m);
                running_z = alpha * running_z + beta;
                running_m = new_m;
                partial[0] = beta;
                partial[1] = alpha;
            }
        }
        __syncthreads();
        float beta = partial[0];
        float alpha = partial[1];
        if (register_values) {
            if (threadIdx.x < Dv)
                reg_accum = alpha * reg_accum + beta * static_cast<float>(vh[threadIdx.x]);
        } else {
            for (int c = threadIdx.x; c < Dv; c += blockDim.x)
                accum[c] = alpha * accum[c] + beta * static_cast<float>(vh[c]);
            __syncthreads();
        }
    }

    __syncthreads();
    float denom = running_z;
    if (register_values) {
        if (threadIdx.x < Dv)
            out[((int64_t)b * Hq + h) * Dv + threadIdx.x] = static_cast<scalar_t>(reg_accum / denom);
    } else {
        for (int c = threadIdx.x; c < Dv; c += blockDim.x)
            out[((int64_t)b * Hq + h) * Dv + c] = static_cast<scalar_t>(accum[c] / denom);
    }
}

torch::Tensor paged_decode(torch::Tensor q, torch::Tensor key_cache,
                           torch::Tensor value_cache, torch::Tensor page_tables,
                           torch::Tensor seq_lens, int64_t page_size,
                           double scale) {
    TORCH_CHECK(q.is_cuda(), "q must be on the accelerator");
    TORCH_CHECK(key_cache.is_cuda() && value_cache.is_cuda(), "KV caches must be on the accelerator");
    TORCH_CHECK(page_tables.is_cuda() && seq_lens.is_cuda(), "metadata must be on the accelerator");
    TORCH_CHECK(q.dim() == 3 && key_cache.dim() == 4 && value_cache.dim() == 4, "invalid tensor ranks");
    TORCH_CHECK(q.scalar_type() == at::kFloat || q.scalar_type() == at::kHalf || q.scalar_type() == at::kBFloat16, "q must be fp32, fp16, or bf16");
    TORCH_CHECK(key_cache.scalar_type() == q.scalar_type() && value_cache.scalar_type() == q.scalar_type(), "dtype mismatch");
    TORCH_CHECK(key_cache.size(1) == page_size, "page size mismatch");
    TORCH_CHECK(q.size(2) == key_cache.size(3), "QK dimension mismatch");
    TORCH_CHECK(q.size(0) == page_tables.size(0) && q.size(0) == seq_lens.size(0), "batch mismatch");
    TORCH_CHECK(q.size(1) % key_cache.size(2) == 0, "query heads must divide into KV heads");

    q = q.contiguous();
    key_cache = key_cache.contiguous();
    value_cache = value_cache.contiguous();
    page_tables = page_tables.to(at::kInt).contiguous();
    seq_lens = seq_lens.to(at::kInt).contiguous();
    auto out = torch::empty({q.size(0), q.size(1), value_cache.size(3)}, q.options());

    int threads = (q.size(2) == 192 && value_cache.size(3) == 128) ? 192 : 256;
    bool register_values = value_cache.size(3) <= threads;
    int64_t shared_floats = (register_values ? 0 : value_cache.size(3)) + threads + q.size(2);
    int64_t shared_bytes = shared_floats * sizeof(float);
    dim3 grid((unsigned)(q.size(0) * q.size(1)));
    auto stream = at::cuda::getDefaultCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16, q.scalar_type(), "paged_decode_kernel", [&] {
        paged_decode_kernel<scalar_t><<<grid, threads, shared_bytes, stream>>>(
            q.data_ptr<scalar_t>(), key_cache.data_ptr<scalar_t>(), value_cache.data_ptr<scalar_t>(),
            page_tables.data_ptr<int32_t>(), seq_lens.data_ptr<int32_t>(), out.data_ptr<scalar_t>(),
            (int)q.size(0), (int)q.size(1), (int)key_cache.size(2), (int)q.size(2),
            (int)value_cache.size(3), (int)page_size, (int)page_tables.size(1), (float)scale);
    });
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Decode-stage attention (single-token query) with paged KV.

    The KV cache is paged at page_size granularity: slot s of physical page p in
    key_cache / value_cache corresponds to flat slot number p * page_size + s.
    Sequence b is addressed indirectly through page_tables, and its l-th KV token
    (0 <= l < seq_lens[b]) lives in slot l % page_size of physical page
    page_tables[b, l // page_size]; slots in the page pool that are not
    referenced are garbage data and must not affect the output. Query head h
    corresponds to KV head h // query_group_size
    (query_group_size = num_q_heads // num_kv_heads, equal to 1 means MHA, equal
    to num_q_heads means MQA). For every sequence b and every query head h:
      logits[l] = scale * <q[b,h,:head_dim_qk],
                            key_flat[slot(b,l), h//group, :head_dim_qk]>
      p[l]      = exp(logits[l] - max(logits)) / sum(exp(logits - max(logits)))
      out[b,h,:head_dim_v] = sum_l p[l] * value_flat[slot(b,l), h//group, :head_dim_v]
    where key_flat / value_flat is the [num_pages*page_size, H_KV, D] flat view of
    the page pool, scale defaults to 1/sqrt(head_dim_qk), and the softmax must be
    numerically stable.

    Any implementation that is numerically equivalent within the tolerance is
    acceptable; how the work is parallelized is **not** a scoring criterion.

    Boundary behaviour:
      - Only the first seq_lens[b] KV tokens participate in the computation;
        seq_lens[b] >= 1 (an empty sequence is undefined).
      - page_size >= 1 is an arbitrary value (with page_size == 1 the page_tables
        are simply a per-token slot table).
      - head_dim_qk and head_dim_v may differ, and non-power-of-2 is allowed (for
        example 192/128, 576/512); the channels short of a power of 2 are handled
        by masking, so no out-of-bounds access occurs.
      - The page pool may be larger than what is actually used; page_tables
        entries beyond ceil(seq_lens[b]/page_size) point at valid but garbage
        pages that do not belong to this sequence.

    Inputs:
      q           [num_seqs, num_q_heads, head_dim_qk]  fp16/bf16 -- the query of
                  one new token per batch
      key_cache   [num_pages, page_size, num_kv_heads, head_dim_qk]
      value_cache [num_pages, page_size, num_kv_heads, head_dim_v]
      page_tables [num_seqs, max_pages_per_seq] int32 -- logical page -> physical page id
      seq_lens    [num_seqs] int32 -- the actually valid KV length of each sequence
    Output:
      out [num_seqs, num_q_heads, head_dim_v], dtype same as q.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV / cross-slice reduction) must
        be completed inside the submitted file; calling external attention
        operator libraries such as scaled_dot_product_attention / sdpa /
        flash_attn, as well as torch.matmul / torch.bmm / torch.einsum /
        torch.softmax, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to
        the input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single-token decode, non-quantized KV, no logit_cap clamping, no
    ALiBi, no sliding window.
    """
    def __init__(self, page_size: int, head_dim_qk: int, head_dim_v: int, num_kv_splits: int = 8, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.page_size = int(page_size)
        self.head_dim_qk = int(head_dim_qk)
        self.head_dim_v = int(head_dim_v)
        self.num_kv_splits = int(num_kv_splits)
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim_qk)
        # <<<END_IMPROVE>>>

    def forward(self, q, key_cache, value_cache, page_tables, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().paged_decode(q, key_cache, value_cache, page_tables, seq_lens, self.page_size, self.scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        B, H_Q, D_QK = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_pages, page_size, H_KV, _ = key_cache.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        D_V = value_cache.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = H_Q // H_KV
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert H_Q == H_KV * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert page_size == self.page_size, "the key_cache page size does not match the initialized page_size"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        key_flat = key_cache.view(num_pages * page_size, H_KV, D_QK)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        value_flat = value_cache.view(num_pages * page_size, H_KV, D_V)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.empty(B, H_Q, D_V, dtype=q.dtype, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        for b in range(B):
            seq_len = int(seq_lens[b])
            offs = torch.arange(seq_len, device=q.device)
            slots = page_tables[b, offs // page_size] * page_size + offs % page_size

            # Gather this sequence's K/V through the page table: [seq_len, H_KV, D],
            # cast up to float32 after the gather
            k = key_flat[slots].to(torch.float32)
            v = value_flat[slots].to(torch.float32)

            # GQA: the K/V of one KV head are replicated to the contiguous group of query heads
            if group > 1:
                k = k.repeat_interleave(group, dim=1)   # [seq_len, H_Q, D_QK]
                v = v.repeat_interleave(group, dim=1)   # [seq_len, H_Q, D_V]

            qf = q[b].to(torch.float32) * self.scale     # [H_Q, D_QK]
            logits = torch.einsum("hd,lhd->hl", qf, k)   # [H_Q, seq_len]
            probs = torch.softmax(logits, dim=-1)
            out[b] = torch.einsum("hl,lhd->hd", probs, v).to(q.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return out
        # <<<END_IMPROVE>>>
