import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p7001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor ctc_forward_hip(torch::Tensor probs, torch::Tensor labels, torch::Tensor label_lengths, torch::Tensor input_lengths, int64_t blank);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("ctc_forward_hip", &ctc_forward_hip);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cmath>

__device__ __forceinline__ float ctc_lse(float a, float b, float c) {
    float m = fmaxf(a, fmaxf(b, c));
    if (m == -INFINITY) return m;
    return m + logf(expf(a-m) + expf(b-m) + expf(c-m));
}

// One block owns a whole sequence. Every state loop is strided, and every
// barrier is reached by all lanes, including lanes with no assigned state.
__global__ void ctc_sequence(const float* p, const int64_t* labels,
                             const int64_t* lengths, const int64_t* times,
                             float* history, float* emissions, float* rolling, float* out,
                             int T, int N, int C, int blank, int shared_limit) {
    int n = blockIdx.x;
    int lane = threadIdx.x;
    int L = (int)lengths[n], S = 2*L+1, tb = (int)times[n];
    int64_t offset = 0;
    for (int i=0; i<n; ++i) offset += lengths[i];
    int64_t state_offset = 2*offset+n;
    const int64_t* target = labels+offset;
    extern __shared__ float smem[];
    float* r0 = S <= shared_limit ? smem : rolling+2*state_offset;
    float* r1 = r0+S;
    float* alpha = history+(int64_t)T*state_offset;
    float* emission = emissions+(int64_t)T*state_offset;
    float* grad = out+N+(int64_t)n*T*C;
    for (int64_t i=lane; i<(int64_t)T*C; i+=blockDim.x) grad[i]=0.0f;
    for (int s=lane; s<S; s+=blockDim.x) {
        int k = (s&1) ? (int)target[s/2] : blank;
        float e = logf(p[(int64_t)n*C+k]);
        emission[s]=e;
        float v = s<2 ? e : -INFINITY;
        r0[s]=v;
        alpha[s]=v;
    }
    __syncthreads();
    float* prev=r0;
    float* curr=r1;
    for (int t=1; t<tb; ++t) {
        for (int s=lane; s<S; s+=blockDim.x) {
            int k = (s&1) ? (int)target[s/2] : blank;
            bool skip = (s&1) && s>=2 && target[s/2]!=target[s/2-1];
            float v = ctc_lse(prev[s], s>0 ? prev[s-1] : -INFINITY,
                              skip ? prev[s-2] : -INFINITY);
            float e = logf(p[((int64_t)t*N+n)*C+k]);
            emission[(int64_t)t*S+s]=e;
            v += e;
            curr[s]=v;
            alpha[(int64_t)t*S+s]=v;
        }
        __syncthreads();
        float* swap=prev; prev=curr; curr=swap;
    }
    float z=ctc_lse(prev[S-1], S>1 ? prev[S-2] : -INFINITY, -INFINITY);
    if (lane==0) out[n]=-z;
    // Finish reading the terminal alpha row before reusing rolling storage.
    __syncthreads();
    prev=r0;
    curr=r1;
    for (int t=tb-1; t>=0; --t) {
        for (int s=lane; s<S; s+=blockDim.x) {
            int k=(s&1) ? (int)target[s/2] : blank;
            float b;
            if (t==tb-1) {
                b=s>=S-2 ? 0.0f : -INFINITY;
            } else {
                bool skip=(s&1) && s+2<S && target[s/2]!=target[s/2+1];
                b=ctc_lse(prev[s], s+1<S ? prev[s+1] : -INFINITY,
                          skip ? prev[s+2] : -INFINITY);
            }
            curr[s]=b+emission[(int64_t)t*S+s];
            float posterior=expf((alpha[(int64_t)t*S+s]+b)-z);
            atomicAdd(grad+(int64_t)t*C+k, -posterior);
        }
        __syncthreads();
        float* swap=prev; prev=curr; curr=swap;
    }
    for (int64_t i=lane; i<(int64_t)tb*C; i+=blockDim.x) {
        int t=i/C, k=i%C;
        grad[i] /= p[((int64_t)t*N+n)*C+k];
    }
}

torch::Tensor ctc_forward_hip(torch::Tensor probs, torch::Tensor labels,
                             torch::Tensor label_lengths, torch::Tensor input_lengths,
                             int64_t blank) {
    TORCH_CHECK(probs.is_cuda(), "probs must be on a HIP device");
    c10::cuda::CUDAGuard guard(probs.device());
    auto p=probs.to(torch::kFloat32).contiguous();
    auto lab=labels.to(probs.device(), torch::kLong).contiguous();
    auto len=label_lengths.to(probs.device(), torch::kLong).contiguous();
    auto tim=input_lengths.to(probs.device(), torch::kLong).contiguous();
    int T=p.size(0), N=p.size(1), C=p.size(2);
    int64_t total_states=2*lab.numel()+N;
    auto history=torch::empty({(int64_t)T*total_states}, p.options());
    auto emissions=torch::empty({(int64_t)T*total_states}, p.options());
    auto rolling=torch::empty({2*total_states}, p.options());
    auto output=torch::empty({(int64_t)N+(int64_t)N*T*C}, p.options());
    int shared_limit=(int)std::min<int64_t>(2048, 2*std::min<int64_t>(T,lab.numel())+1);
    auto stream=at::cuda::getCurrentCUDAStream();
    if (N>0) {
        ctc_sequence<<<N,256,2*shared_limit*sizeof(float),stream>>>(
            p.data_ptr<float>(), lab.data_ptr<int64_t>(), len.data_ptr<int64_t>(),
            tim.data_ptr<int64_t>(), history.data_ptr<float>(), emissions.data_ptr<float>(), rolling.data_ptr<float>(),
            output.data_ptr<float>(), T,N,C,(int)blank,shared_limit);
        auto err=hipGetLastError();
        TORCH_CHECK(err==hipSuccess, "CTC HIP launch failed: ", hipGetErrorString(err));
    }
    return output.to(probs.scalar_type());
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    CTC (Connectionist Temporal Classification) forward loss: one forward pass
    produces both the per-sequence CTC loss and the gradient with respect to the
    input probabilities. The input probs holds **probabilities**, not logits
    (equivalent to the production library's apply_softmax=False convention: take
    the log of probs directly, no softmax), positive every frame along the class
    dimension and summing to 1; the blank class id is given by a hyperparameter
    (always 0 in the generation domain).

    Layout and input contract (time-major inputs):
      probs          (T, N, C) floating-point probability tensor, T=max_time,
                     N=batch, C=num_classes
      labels         (sum(label_lengths),) integer, the flattened label sequences
                     concatenated in batch order; label values lie in [0, C-1]
                     and are not equal to blank ([1, C-1] in the generation
                     domain)
      label_lengths  (N,) integer, target length of each sequence
      input_lengths  (N,) integer, number of valid input frames of each sequence
                     (1 <= input_lengths[n] <= T)
    Mathematical definition (for each sequence n, write Tb=input_lengths[n], the
    target l_1..l_L (L=label_lengths[n]) and the extended state sequence
    ext = [b, l_1, b, l_2, ..., b, l_L, b] (blank inserted before and after and
    between every two labels), S = 2L+1 states, s = 0..S-1; every recurrence runs
    in log space in float32, with -inf meaning unreachable):
      forward variable alpha (shape (Tb, S)):
        alpha[0,0] = log p[0, blank]; alpha[0,1] = log p[0, ext[1]] (S>1);
        everything else -inf
        alpha[t,s] = log p[t, ext[s]] + LSE( alpha[t-1,s], alpha[t-1,s-1],
                     alpha[t-1,s-2] (only when ext[s] != blank and
                     ext[s] != ext[s-2]) )
      backward variable beta (symmetric; beta does not include the emission of
      the current frame, so that alpha+beta counts every emission factor exactly
      once along each complete alignment path through state s):
        beta[Tb-1,S-1] = beta[Tb-1,S-2] = 0 (S>1), everything else -inf
        beta[t,s] = LSE( log p[t+1,ext[s]] + beta[t+1,s],
                         log p[t+1,ext[s+1]] + beta[t+1,s+1],
                         log p[t+1,ext[s+2]] + beta[t+1,s+2]
                         (the last term only when ext[s] != blank and
                         ext[s] != ext[s+2]) )
      losses[n] = -log Z, Z = LSE( alpha[Tb-1,S-1], alpha[Tb-1,S-2] )
        (the probability sum over all legal alignment paths; the reduction is the
        per-sequence 'none')
      gamma[t,s] = exp( alpha[t,s] + beta[t,s] - log Z )
      gradients[n,t,k] = d losses[n] / d probs[n,t,k]
        = -(1 / p[t,k]) * sum_{s: ext[s]=k} gamma[t,s], t < Tb; 0 for t >= Tb
    forward returns **a single 1-D tensor** out (dtype same as probs, the
    single-tensor packing protocol):
      out[0:N]         = losses (N entries)
      out[N : N+N*T*C] = gradients flattened in (N, T, C) row-major order
    Boundary behaviour:
      - the generation domain guarantees probs strictly positive (the softmax
        convention), labels without consecutive repeats and L <= Tb, so Z is
        finite with no inf/NaN; losses are on the order of <= T*ln(C), which fp16
        can represent.
      - the alpha/beta of unreachable states are -inf and the matching gamma is 0.
      - the gradient is defined with respect to the probability input (not the
        log probability): the chain factor 1/p[t,k] is already part of the
        definition.

    Input/output specification:
      probs          float32 / float16 / bfloat16 (T, N, C), contiguous
      labels / label_lengths / input_lengths   integer (...,), contiguous
      out            a single 1-D tensor, same dtype as probs, length N + N*T*C
      The evaluator casts all inputs to fp32 before passing them in (integer
      tensors must be restored to long by the implementation; their integer
      values are losslessly representable in fp32).

    Implementation constraints (violations are scored as failures):
      - Core computation (log probabilities, the alpha/beta forward-backward
        recurrence, gradient assembly) must be done with a HIP kernel inside
        the submitted file.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Intermediate computation happens in float32 (cast probs to fp32 first,
        then take the log); the output is cast back to the probs dtype and then
        concatenated into a single tensor per the packing protocol above.
      - forward returns the single tensor out (the evaluator compares a single
        output).

    Disallowed list: aiter / torch.nn.functional.ctc_loss / torch.ctc_loss /
    F.ctc_loss / torch.nn.CTCLoss / torch.ops.aten.ctc_loss /
    torch.ops.aten._ctc_loss / aten.ctc_loss / .ctc_loss( (including every
    library-level one-step CTC primitive) / warpctc / warp_ctc / torch.autograd
    and .backward() (automatic differentiation must not be used to obtain the
    gradient).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: single blank, reduction='none' (per-sequence loss plus the full
    gradient), the input is already a probability (no apply_softmax branch), and
    there are no empty target sequences.
    """
    def __init__(self, blank: int = 0):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.blank = int(blank)
        # <<<END_IMPROVE>>>

    def forward(self, probs, labels, label_lengths, input_lengths):
        # <<<IMPROVE:forward_stmt_1>>>
        labels = labels.to(device=probs.device, dtype=torch.long).contiguous()
        label_lengths = label_lengths.to(device=probs.device, dtype=torch.long).contiguous()
        input_lengths = input_lengths.to(device=probs.device, dtype=torch.long).contiguous()
        return _pyramidkernel_get_extension().ctc_forward_hip(
            probs.contiguous(), labels, label_lengths, input_lengths, self.blank
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        label_lengths = label_lengths.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        input_lengths = input_lengths.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        pf = probs.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        max_time, batch, num_classes = pf.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        logp = torch.log(pf)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        losses = torch.empty(batch, dtype=torch.float32, device=pf.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        grads = torch.zeros(batch, max_time, num_classes, dtype=torch.float32, device=pf.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        offset = 0
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return _pyramidkernel_get_extension().ctc_forward_hip(
            probs.contiguous(), labels, label_lengths, input_lengths, self.blank
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        losses = losses.to(probs.dtype).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        grads = grads.to(probs.dtype).reshape(-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return torch.cat((losses, grads))
        # <<<END_IMPROVE>>>

    def _ctc_one(self, logp_b, p_b, target, tb, num_classes, max_time):
        # Single-sequence log-space forward-backward: logp_b / p_b are the (T, C)
        # fp32 log probabilities / probabilities, target is (L,) long, tb is the
        # number of valid frames; returns (loss_n, grad_n) with grad_n of shape
        # (max_time, C), always 0 outside the valid frames
        C = num_classes
        L = target.numel()
        S = 2 * L + 1
        neg_inf = float("-inf")
        # device=dev is required: every intermediate tensor built inside this
        # function must live on the same device as logp_b/p_b, which are already
        # on it; omitting device raises "Expected all tensors to be on the same
        # device" on CUDA/DCU (it works on CPU, so local unit tests cannot catch
        # it)
        dev = logp_b.device

        ext = torch.empty(S, dtype=torch.long, device=dev)
        ext[0::2] = self.blank
        ext[1::2] = target

        lp_ext = logp_b[:tb, ext]                      # (tb, S)
        alpha = torch.full((tb, S), neg_inf, dtype=torch.float32, device=dev)
        beta = torch.full((tb, S), neg_inf, dtype=torch.float32, device=dev)

        # Forward recurrence (stepping over the time dimension, the state
        # dimension vectorized as a whole)
        alpha[0, 0] = lp_ext[0, 0]
        alpha[0, 1] = lp_ext[0, 1]
        for t in range(1, tb):
            prev = alpha[t - 1]
            left = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            left[1:] = prev[:-1]
            jump = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            jump[2:] = prev[:-2]
            ok = (ext[2:] != self.blank) & (ext[2:] != ext[:-2])
            jump[2:] = torch.where(ok, jump[2:], torch.full((S - 2,), neg_inf, dtype=torch.float32, device=dev))
            alpha[t] = lp_ext[t] + torch.logsumexp(torch.stack((prev, left, jump)), dim=0)

        # Backward recurrence (beta excludes the current frame's emission:
        # alpha+beta counts every emission factor exactly once along a complete
        # path through state s, so gamma is the state posterior)
        beta[tb - 1, S - 1] = 0.0
        beta[tb - 1, S - 2] = 0.0
        for t in range(tb - 2, -1, -1):
            nxt = beta[t + 1] + lp_ext[t + 1]
            right = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            right[:-1] = nxt[1:]
            jump = torch.full((S,), neg_inf, dtype=torch.float32, device=dev)
            jump[:-2] = nxt[2:]
            ok = (ext[:-2] != self.blank) & (ext[:-2] != ext[2:])
            jump[:-2] = torch.where(ok, jump[:-2], torch.full((S - 2,), neg_inf, dtype=torch.float32, device=dev))
            beta[t] = torch.logsumexp(torch.stack((nxt, right, jump)), dim=0)

        log_z = torch.logsumexp(alpha[tb - 1] + beta[tb - 1], dim=0)
        gamma = torch.exp(alpha + beta - log_z)        # (tb, S) state posterior

        # dL/dp[t,k] = -(1/p[t,k]) * sum_{s: ext[s]=k} gamma[t,s]
        grad = torch.zeros(tb, C, dtype=torch.float32, device=dev)
        grad.index_add_(1, ext, -gamma)
        grad = grad / p_b[:tb]                         # divide by p (probs is strictly positive)

        grad_full = torch.zeros(max_time, C, dtype=torch.float32, device=dev)
        grad_full[:tb] = grad
        return -log_z, grad_full
