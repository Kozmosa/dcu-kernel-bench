import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1031_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor deform_attention_forward(torch::Tensor value, torch::Tensor spatial_shapes, torch::Tensor level_start_index, torch::Tensor sampling_locations, torch::Tensor attention_weights);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("deform_attention_forward", &deform_attention_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cmath>
#include <cstdint>

__device__ __forceinline__ int64_t read_index(const void* ptr, bool is_long, int64_t i) {
    return is_long ? static_cast<const int64_t*>(ptr)[i] : static_cast<int64_t>(static_cast<const float*>(ptr)[i]);
}

template<typename T>
__global__ void singleton_kernel(const T* __restrict__ value,
                                 const void* shapes, bool shapes_long,
                                 const void* starts, bool starts_long,
                                 const T* __restrict__ loc, T* __restrict__ out,
                                 int64_t rows, int64_t Q, int64_t K,
                                 int64_t heads, int64_t D) {
    #pragma clang fp contract(off)
    for (int64_t j = static_cast<int64_t>(blockIdx.x)*128 + threadIdx.x;
         j < rows*D; j += static_cast<int64_t>(gridDim.x)*128) {
        const int64_t row = j/D, d = j%D;
        const int64_t n = row/(Q*heads), h = row%heads;
        const int64_t H = read_index(shapes, shapes_long, 0);
        const int64_t W = read_index(shapes, shapes_long, 1);
        const int64_t base = read_index(starts, starts_long, 0);
        const float x = static_cast<float>(loc[2*row]) * static_cast<float>(W);
        const float y = static_cast<float>(loc[2*row+1]) * static_cast<float>(H);
        const int64_t ix = static_cast<int64_t>(floorf(x));
        const int64_t iy = static_cast<int64_t>(floorf(y));
        const float fx = x - static_cast<float>(ix);
        const float fy = y - static_cast<float>(iy);
        const float c0 = (1.0f-fy)*(1.0f-fx);
        const float c1 = (1.0f-fy)*fx;
        const float c2 = fy*(1.0f-fx);
        const float c3 = fy*fx;
        float v0 = 0.0f, v1 = 0.0f, v2 = 0.0f, v3 = 0.0f;
        if (iy >= 0 && iy < H && ix >= 0 && ix < W)
            v0 = static_cast<float>(value[((n*K+base+iy*W+ix)*heads+h)*D+d]);
        if (iy >= 0 && iy < H && ix+1 >= 0 && ix+1 < W)
            v1 = static_cast<float>(value[((n*K+base+iy*W+ix+1)*heads+h)*D+d]);
        if (iy+1 >= 0 && iy+1 < H && ix >= 0 && ix < W)
            v2 = static_cast<float>(value[((n*K+base+(iy+1)*W+ix)*heads+h)*D+d]);
        if (iy+1 >= 0 && iy+1 < H && ix+1 >= 0 && ix+1 < W)
            v3 = static_cast<float>(value[((n*K+base+(iy+1)*W+ix+1)*heads+h)*D+d]);
        const float sampled = ((v0*c0 + v1*c1) + v2*c2) + v3*c3;
        out[j] = static_cast<T>(sampled);
    }
}

template<typename T, int C>
__global__ void deform_kernel(const T* __restrict__ value,
                              const void* shapes, bool shapes_long,
                              const void* starts, bool starts_long,
                              const T* __restrict__ loc,
                              const T* __restrict__ scores,
                              T* __restrict__ out,
                              int64_t rows, int64_t Q, int64_t K,
                              int64_t heads, int64_t D,
                              int64_t L, int64_t P, int64_t tiles) {
    #pragma clang fp contract(off)
    __shared__ float reduction[128];
    const int t = threadIdx.x;
    const int64_t S = L * P;
    for (int64_t job = blockIdx.x; job < rows * tiles; job += gridDim.x) {
        const int64_t row = job / tiles;
        const int64_t d0 = (job % tiles) * (128*C) + t;
        const int64_t n = row / (Q * heads);
        const int64_t h = row % heads;
        const int64_t score_base = row * S;
        float mx = 0.0f;
        float denom = 1.0f;
        if (S > 1 && S <= 8) {
            if (t == 0) {
                float maximum = -INFINITY;
                for (int64_t i = 0; i < S; ++i)
                    maximum = fmaxf(maximum, static_cast<float>(scores[score_base + i]));
                float sum = 0.0f;
                for (int64_t i = 0; i < S; ++i)
                    sum += expf(static_cast<float>(scores[score_base + i]) - maximum);
                reduction[0] = maximum;
                reduction[1] = sum;
            }
            __syncthreads();
            mx = reduction[0];
            denom = reduction[1];
        } else if (S > 8) {
            mx = -INFINITY;
            for (int64_t i = t; i < S; i += 128)
                mx = fmaxf(mx, static_cast<float>(scores[score_base + i]));
            reduction[t] = mx;
            __syncthreads();
            for (int step = 64; step; step >>= 1) {
                if (t < step) reduction[t] = fmaxf(reduction[t], reduction[t + step]);
                __syncthreads();
            }
            mx = reduction[0];
            __syncthreads();
            float sum = 0.0f;
            for (int64_t i = t; i < S; i += 128)
                sum += expf(static_cast<float>(scores[score_base + i]) - mx);
            reduction[t] = sum;
            __syncthreads();
            for (int step = 64; step; step >>= 1) {
                if (t < step) reduction[t] += reduction[t + step];
                __syncthreads();
            }
            denom = reduction[0];
        }
        if (d0 < D) {
            float acc[C] = {};
            for (int64_t l = 0; l < L; ++l) {
                const int64_t H = read_index(shapes, shapes_long, 2*l);
                const int64_t W = read_index(shapes, shapes_long, 2*l+1);
                const int64_t base = read_index(starts, starts_long, l);
                for (int64_t p = 0; p < P; ++p) {
                    const int64_t i = score_base + l*P + p;
                    const float x = static_cast<float>(loc[2*i]) * static_cast<float>(W);
                    const float y = static_cast<float>(loc[2*i+1]) * static_cast<float>(H);
                    const int64_t ix = static_cast<int64_t>(floorf(x));
                    const int64_t iy = static_cast<int64_t>(floorf(y));
                    const float fx = x - static_cast<float>(ix);
                    const float fy = y - static_cast<float>(iy);
                    const float c0 = (1.0f-fy)*(1.0f-fx);
                    const float c1 = (1.0f-fy)*fx;
                    const float c2 = fy*(1.0f-fx);
                    const float c3 = fy*fx;
                    const bool b0 = iy >= 0 && iy < H && ix >= 0 && ix < W;
                    const bool b1 = iy >= 0 && iy < H && ix+1 >= 0 && ix+1 < W;
                    const bool b2 = iy+1 >= 0 && iy+1 < H && ix >= 0 && ix < W;
                    const bool b3 = iy+1 >= 0 && iy+1 < H && ix+1 >= 0 && ix+1 < W;
                    const float weight = S == 1 ? 1.0f : expf(static_cast<float>(scores[i])-mx)/denom;
                    #pragma unroll
                    for (int c = 0; c < C; ++c) {
                        const int64_t d = d0 + 128*c;
                        if (d < D) {
                            float v0 = 0.0f, v1 = 0.0f, v2 = 0.0f, v3 = 0.0f;
                            if (b0)
                                v0 = static_cast<float>(value[((n*K+base+iy*W+ix)*heads+h)*D+d]);
                            if (b1)
                                v1 = static_cast<float>(value[((n*K+base+iy*W+ix+1)*heads+h)*D+d]);
                            if (b2)
                                v2 = static_cast<float>(value[((n*K+base+(iy+1)*W+ix)*heads+h)*D+d]);
                            if (b3)
                                v3 = static_cast<float>(value[((n*K+base+(iy+1)*W+ix+1)*heads+h)*D+d]);
                            const float sampled = ((v0*c0 + v1*c1) + v2*c2) + v3*c3;
                            acc[c] = acc[c] + weight*sampled;
                        }
                    }
                }
            }
            #pragma unroll
            for (int c = 0; c < C; ++c) {
                const int64_t d = d0 + 128*c;
                if (d < D) out[row*D+d] = static_cast<T>(acc[c]);
            }
        }
        __syncthreads();
    }
}

torch::Tensor deform_attention_forward(torch::Tensor value, torch::Tensor spatial_shapes,
                                      torch::Tensor level_start_index, torch::Tensor sampling_locations,
                                      torch::Tensor attention_weights) {
    TORCH_CHECK(value.is_cuda(), "value must be on GPU");
    c10::cuda::CUDAGuard guard(value.device());
    for (const auto& x : {value, spatial_shapes, level_start_index, sampling_locations, attention_weights}) {
        TORCH_CHECK(x.device() == value.device() && x.is_contiguous(), "inputs must be contiguous on the same device");
    }
    TORCH_CHECK(value.scalar_type() == at::kFloat || value.scalar_type() == at::kHalf, "unsupported value dtype");
    TORCH_CHECK(sampling_locations.scalar_type() == value.scalar_type() && attention_weights.scalar_type() == value.scalar_type(), "data dtypes must match");
    TORCH_CHECK(spatial_shapes.scalar_type() == at::kLong || spatial_shapes.scalar_type() == at::kFloat, "unsupported shapes dtype");
    TORCH_CHECK(level_start_index.scalar_type() == at::kLong || level_start_index.scalar_type() == at::kFloat, "unsupported offsets dtype");
    TORCH_CHECK(value.dim() == 4 && spatial_shapes.dim() == 2 && spatial_shapes.size(1) == 2, "invalid value or shapes rank");
    TORCH_CHECK(sampling_locations.dim() == 6 && attention_weights.dim() == 5, "invalid sampling rank");
    const int64_t N=value.size(0), K=value.size(1), heads=value.size(2), D=value.size(3);
    const int64_t L=spatial_shapes.size(0), Q=sampling_locations.size(1), P=sampling_locations.size(4);
    TORCH_CHECK(N>0 && K>0 && heads>0 && D>0 && L>0 && Q>0 && P>0, "dimensions must be positive");
    TORCH_CHECK(level_start_index.dim()==1 && level_start_index.numel()==L, "invalid level offsets");
    TORCH_CHECK(sampling_locations.size(0)==N && sampling_locations.size(2)==heads && sampling_locations.size(3)==L && sampling_locations.size(5)==2, "invalid location shape");
    TORCH_CHECK(attention_weights.size(0)==N && attention_weights.size(1)==Q && attention_weights.size(2)==heads && attention_weights.size(3)==L && attention_weights.size(4)==P, "invalid weight shape");
    auto out = torch::empty({N,Q,heads*D}, value.options());
    const int64_t rows=N*Q*heads, tiles=(D+127)/128;
    const unsigned blocks=static_cast<unsigned>(std::min<int64_t>(rows*tiles, 65535));
    auto stream=at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND_HALF(value.scalar_type(), "deform_attention_forward", [&] {
        if (L == 1 && P == 1) {
            const unsigned singleton_blocks=static_cast<unsigned>(std::min<int64_t>((rows*D+127)/128,65535));
            singleton_kernel<scalar_t><<<singleton_blocks,128,0,stream>>>(
                value.data_ptr<scalar_t>(), spatial_shapes.data_ptr(), spatial_shapes.scalar_type()==at::kLong,
                level_start_index.data_ptr(), level_start_index.scalar_type()==at::kLong,
                sampling_locations.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), rows,Q,K,heads,D);
        } else if (D >= 256) {
            const int64_t wide_tiles = (D+255)/256;
            const unsigned wide_blocks = static_cast<unsigned>(std::min<int64_t>(rows*wide_tiles,65535));
            deform_kernel<scalar_t,2><<<wide_blocks,128,0,stream>>>(
                value.data_ptr<scalar_t>(), spatial_shapes.data_ptr(), spatial_shapes.scalar_type()==at::kLong,
                level_start_index.data_ptr(), level_start_index.scalar_type()==at::kLong,
                sampling_locations.data_ptr<scalar_t>(), attention_weights.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(), rows,Q,K,heads,D,L,P,wide_tiles);
        } else {
            deform_kernel<scalar_t,1><<<blocks,128,0,stream>>>(
                value.data_ptr<scalar_t>(), spatial_shapes.data_ptr(), spatial_shapes.scalar_type()==at::kLong,
                level_start_index.data_ptr(), level_start_index.scalar_type()==at::kLong,
                sampling_locations.data_ptr<scalar_t>(), attention_weights.data_ptr<scalar_t>(),
                out.data_ptr<scalar_t>(), rows,Q,K,heads,D,L,P,tiles);
        }
    });
    const hipError_t error = hipGetLastError();
    TORCH_CHECK(error == hipSuccess, "deform attention launch failed: ", hipGetErrorString(error));
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """Multi-Scale Deformable Attention forward: value sampling + hand-written
    bilinear interpolation + softmax normalization of the sampling weights.

    Semantics (all intermediate computation in float32): value (N, n_keys, heads,
    D) is the concatenation of the multi-scale feature levels -- level l
    contributes spatial_shapes[l] = (H_l, W_l) keys, laid out inside the level in
    row-major order (H first, then W) over
    [level_start_index[l], level_start_index[l] + H_l*W_l), where
    level_start_index must be the prefix sum of the per-level H_l*W_l (first
    element 0) and n_keys = sum_l H_l*W_l. sampling_locations
    (N, Q, heads, L, P, 2) gives the normalized coordinates of every
    (batch, query, head) at every sampling point of every level, with the last
    dimension being (x, y): channel 0 runs along W and channel 1 along H (the
    generation domain is [0,1)), so the actual sampling coordinates are
        loc_x = x * W_l,  loc_y = y * H_l
    The sampled value goes through four-corner bilinear interpolation:
        ix0 = floor(loc_x), iy0 = floor(loc_y), fx = loc_x - ix0, fy = loc_y - iy0
        the weights of the four corners (iy0,ix0), (iy0,ix0+1), (iy0+1,ix0),
        (iy0+1,ix0+1) are, in that order,
        (1-fy)(1-fx), (1-fy)fx, fy(1-fx), fy*fx
    When a corner's row or column is out of range (< 0 or > dim-1) that corner
    contributes 0 while the other corners are weighted as usual -- i.e. zero
    padding semantics, with no clamp / nearest-neighbour pull-back anywhere in the
    computation; when the coordinates are entirely out of range the sampled value
    is 0.
    attention_weights (N, Q, heads, L, P) are non-negative unnormalized scores:
    first flatten (levels x points) into one dimension and run a numerically
    stable softmax (max subtraction) to normalize them into convex-combination
    weights, then take the weighted sum against the interpolated value of each
    sampling point:
        out[n, q, h*D + d] = sum_{l, p} w[n,q,h,l,p] * bilinear(value_l)[n,q,h,p,d]
    The output is the single tensor out (N, Q, heads*D), cast back to the value
    dtype (naturally a single output, no multi-output packing). When L*P = 1 the
    softmax weights are identically 1.

    Input/output specification (all tensors contiguous):
      value              float32 / float16 (N, n_keys, heads, D)
      spatial_shapes     int64 (L, 2), each row (H_l, W_l), H_l / W_l >= 1
      level_start_index  int64 (L,), prefix sum of the per-level key counts
      sampling_locations same dtype as value (N, Q, heads, L, P, 2), generation domain [0,1)
      attention_weights  same dtype as value (N, Q, heads, L, P), non-negative
      out                single tensor, same dtype as value (N, Q, heads*D)
      every dimension is an arbitrary positive integer (including 1, non-powers
      of 2, and non-16-aligned sizes; a single-level single-pixel (H_l, W_l) =
      (1, 1), and 1xN / Nx1 thin-strip levels are all legal boundaries). The
      evaluator casts every input to fp32 before passing it in (lossless for both
      the low precision and the int64 indices -- an index value <= 2^24 is exactly
      representable in fp32), so the implementation must restore
      spatial_shapes / level_start_index to integer indices before using them.

    Implementation constraints (violations are scored as failures):
      - The core computation (coordinate expansion, four-corner bilinear
        interpolation, softmax normalization of the weights, and the cross-level
        cross-point weighted reduction) must be hand-written as a HIP kernel
        inside the submitted file.
      - The softmax, the interpolation and the weighted reduction are done in
        float32, and the output is cast back to the value dtype.
      - forward returns the single tensor out (N, Q, heads*D) (the evaluator
        compares a single output).
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden list: torchvision (including ready-made deformable attention /
    deformable convolution primitives such as torchvision.ops.ms_deform_attn),
    mmcv, miopen, hipdnn, aiter,
    torch.nn.functional.grid_sample (F.grid_sample),
    torch.nn.functional.interpolate (F.interpolate), torch.matmul /
    torch.bmm / torch.mm / torch.einsum / torch.tensordot,
    torch.softmax / torch.nn.functional.softmax (F.softmax).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, value, spatial_shapes, level_start_index, sampling_locations, attention_weights):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().deform_attention_forward(value, spatial_shapes, level_start_index, sampling_locations, attention_weights)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        level_start_index = level_start_index.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        n, n_keys, num_heads, d = value.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        n_levels = spatial_shapes.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_queries = sampling_locations.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        n_points = sampling_locations.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert sampling_locations.dim() == 6 \
            and sampling_locations.shape[2] == num_heads \
            and sampling_locations.shape[3] == n_levels \
            and sampling_locations.shape[5] == 2, \
            "sampling_locations must be (N, Q, heads, L, P, 2)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert attention_weights.shape == (n, n_queries, num_heads, n_levels, n_points), \
            "attention_weights must be (N, Q, heads, L, P)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert value.shape[1] == int(spatial_shapes.prod(dim=1).sum()), \
            "dimension 1 of value must equal the sum of the per-level H_l*W_l"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        vf = value.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        loc = sampling_locations.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        wf = attention_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        wf = wf.reshape(n, n_queries, num_heads, n_levels * n_points)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        wf = torch.softmax(wf, dim=-1).view(n, n_queries, num_heads, n_levels, n_points)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        n_idx = torch.arange(n, device=vf.device).view(n, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        h_idx = torch.arange(num_heads, device=vf.device).view(1, 1, num_heads)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        out = torch.zeros(n, n_queries, num_heads, d,
                          dtype=torch.float32, device=vf.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        for l in range(n_levels):
            h_l = int(spatial_shapes[l, 0])
            w_l = int(spatial_shapes[l, 1])
            base = int(level_start_index[l])
            v_l = vf[:, base: base + h_l * w_l]       # (n, H_l*W_l, heads, d)

            # normalized coordinates x level size -> real-valued sampling
            # coordinates (channel 0 along W, channel 1 along H)
            sx = loc[:, :, :, l, :, 0] * float(w_l)   # (n, q, heads, P)
            sy = loc[:, :, :, l, :, 1] * float(h_l)
            ix0 = torch.floor(sx).to(torch.long)
            iy0 = torch.floor(sy).to(torch.long)
            fx = sx - ix0.to(torch.float32)
            fy = sy - iy0.to(torch.float32)

            def corner(iy, ix, wgt):
                # Single-corner sampling: an out-of-range corner contributes 0
                # (zero padding semantics); the clamp only guards the index
                # against going out of range and is cancelled by the 0 weight
                valid = ((iy >= 0) & (iy <= h_l - 1)
                         & (ix >= 0) & (ix <= w_l - 1)).to(torch.float32)
                flat = iy.clamp(0, h_l - 1) * w_l + ix.clamp(0, w_l - 1)
                vals = v_l[n_idx, flat, h_idx]        # (n, q, heads, P, d)
                return vals * (valid * wgt).unsqueeze(-1)

            for p in range(n_points):
                iy0p, ix0p = iy0[..., p], ix0[..., p]      # (n, q, heads)
                fyp, fxp = fy[..., p], fx[..., p]
                sampled = (corner(iy0p, ix0p, (1.0 - fyp) * (1.0 - fxp))
                           + corner(iy0p, ix0p + 1, (1.0 - fyp) * fxp)
                           + corner(iy0p + 1, ix0p, fyp * (1.0 - fxp))
                           + corner(iy0p + 1, ix0p + 1, fyp * fxp))
                out = out + wf[:, :, :, l, p].unsqueeze(-1) * sampled
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        return out.view(n, n_queries, num_heads * d).to(value.dtype)
        # <<<END_IMPROVE>>>
