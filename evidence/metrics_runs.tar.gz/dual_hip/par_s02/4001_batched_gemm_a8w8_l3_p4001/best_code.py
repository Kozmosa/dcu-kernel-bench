import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4001_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor batched_gemm(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, bool, bool);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("batched_gemm", &batched_gemm);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <type_traits>
#include <cstdint>

template<class O, class X, class W, bool FULL_TILES, bool VECTOR_LOAD = false>
__global__ void tiled_gemm(const X* __restrict__ x, const W* __restrict__ w, const float* __restrict__ xs, const float* __restrict__ ws,
                           const void* __restrict__ bias, O* __restrict__ out, int64_t M, int64_t N, int64_t K,
                           int64_t mt, int64_t nt, bool bf, bool use_bias) {
    __shared__ float a[32][65];
    __shared__ float b[32][65];
    int t = threadIdx.x;
    int r = t / 16, c = t % 16;
    int64_t batch = int64_t(blockIdx.x) / (mt * nt);
    int64_t tile = int64_t(blockIdx.x) % (mt * nt);
    int64_t m0 = (tile / nt) * 32, n0 = (tile % nt) * 32;
    float acc[2][2] = {{0.f, 0.f}, {0.f, 0.f}};
    for (int64_t base = 0; base < K; base += 64) {
        if constexpr (VECTOR_LOAD) {
            static_assert(FULL_TILES && std::is_same<X,float>::value && std::is_same<W,float>::value);
            for (int g = t; g < 512; g += 256) {
                int row = g / 16, k = 4 * (g % 16);
                float4 av = *reinterpret_cast<const float4*>(x + (batch*M+m0+row)*K+base+k);
                float4 bv = *reinterpret_cast<const float4*>(w + (batch*N+n0+row)*K+base+k);
                a[row][k] = av.x;
                a[row][k+1] = av.y;
                a[row][k+2] = av.z;
                a[row][k+3] = av.w;
                b[row][k] = bv.x;
                b[row][k+1] = bv.y;
                b[row][k+2] = bv.z;
                b[row][k+3] = bv.w;
            }
        } else {
            for (int j = t; j < 2048; j += 256) {
                int row = j / 64, k = j % 64;
                if constexpr (FULL_TILES) {
                    a[row][k] = float(x[(batch*M+m0+row)*K+base+k]);
                    b[row][k] = float(w[(batch*N+n0+row)*K+base+k]);
                } else {
                    a[row][k] = m0 + row < M && base + k < K ? float(x[(batch*M+m0+row)*K+base+k]) : 0.f;
                    b[row][k] = n0 + row < N && base + k < K ? float(w[(batch*N+n0+row)*K+base+k]) : 0.f;
                }
            }
        }
        __syncthreads();
        #pragma unroll
        for (int k = 0; k < 64; ++k) {
            float a0 = a[r][k], a1 = a[r+16][k];
            float b0 = b[c][k], b1 = b[c+16][k];
            acc[0][0] = fmaf(a0,b0,acc[0][0]);
            acc[0][1] = fmaf(a0,b1,acc[0][1]);
            acc[1][0] = fmaf(a1,b0,acc[1][0]);
            acc[1][1] = fmaf(a1,b1,acc[1][1]);
        }
        __syncthreads();
    }
    #pragma unroll
    for (int i=0;i<2;++i) {
        #pragma unroll
        for (int j=0;j<2;++j) {
            int64_t m=m0+r+16*i, n=n0+c+16*j;
            if (m<M && n<N) {
                float v = (acc[i][j] * xs[batch*M+m]) * ws[batch*N+n];
                O rounded = O(v);
                if (use_bias) {
                    O bv = bf ? O(static_cast<const float*>(bias)[batch*N+n]) : static_cast<const O*>(bias)[batch*N+n];
                    rounded = O(float(rounded) + float(bv));
                }
                out[(batch*M+m)*N+n] = rounded;
            }
        }
    }
}

template<class O, class X, class W>
void launch_typed(torch::Tensor x, torch::Tensor w, torch::Tensor xs, torch::Tensor ws,
                  const void* bp, torch::Tensor out, int64_t B, int64_t M, int64_t N, int64_t K,
                  int64_t mt, int64_t nt, bool bf, bool use_bias, hipStream_t stream) {
    if (M%32==0 && N%32==0 && K%64==0) {
        if constexpr (std::is_same<X,float>::value && std::is_same<W,float>::value) {
            if ((reinterpret_cast<std::uintptr_t>(x.data_ptr<X>()) % 16 == 0) &&
                (reinterpret_cast<std::uintptr_t>(w.data_ptr<W>()) % 16 == 0)) {
                tiled_gemm<O,X,W,true,true><<<B*mt*nt,256,0,stream>>>(x.data_ptr<X>(),w.data_ptr<W>(),xs.data_ptr<float>(),ws.data_ptr<float>(),bp,out.data_ptr<O>(),M,N,K,mt,nt,bf,use_bias);
                return;
            }
        }
        tiled_gemm<O,X,W,true><<<B*mt*nt,256,0,stream>>>(x.data_ptr<X>(),w.data_ptr<W>(),xs.data_ptr<float>(),ws.data_ptr<float>(),bp,out.data_ptr<O>(),M,N,K,mt,nt,bf,use_bias);
    } else
        tiled_gemm<O,X,W,false><<<B*mt*nt,256,0,stream>>>(x.data_ptr<X>(),w.data_ptr<W>(),xs.data_ptr<float>(),ws.data_ptr<float>(),bp,out.data_ptr<O>(),M,N,K,mt,nt,bf,use_bias);
}

template<class O>
void dispatch_typed(torch::Tensor x, torch::Tensor w, torch::Tensor xs, torch::Tensor ws,
                    const void* bp, torch::Tensor out, int64_t B, int64_t M, int64_t N, int64_t K,
                    int64_t mt, int64_t nt, bool bf, bool use_bias, hipStream_t stream) {
    if (x.scalar_type()==at::kFloat) {
        if (w.scalar_type()==at::kFloat)
            launch_typed<O,float,float>(x,w,xs,ws,bp,out,B,M,N,K,mt,nt,bf,use_bias,stream);
        else
            launch_typed<O,float,int8_t>(x,w,xs,ws,bp,out,B,M,N,K,mt,nt,bf,use_bias,stream);
    } else {
        if (w.scalar_type()==at::kFloat)
            launch_typed<O,int8_t,float>(x,w,xs,ws,bp,out,B,M,N,K,mt,nt,bf,use_bias,stream);
        else
            launch_typed<O,int8_t,int8_t>(x,w,xs,ws,bp,out,B,M,N,K,mt,nt,bf,use_bias,stream);
    }
}

torch::Tensor batched_gemm(torch::Tensor x, torch::Tensor w, torch::Tensor xs, torch::Tensor ws,
                           torch::Tensor bias, bool use_bias, bool bfloat) {
    TORCH_CHECK(x.is_cuda() && w.device()==x.device() && xs.device()==x.device() && ws.device()==x.device(), "expected tensors on one GPU");
    c10::cuda::CUDAGuard guard(x.device());
    TORCH_CHECK(x.dim()==3 && w.dim()==3, "expected rank three operands");
    int64_t B=x.size(0), M=x.size(1), K=x.size(2), N=w.size(1);
    TORCH_CHECK(B>0 && M>0 && N>0 && K>0 && w.size(0)==B && w.size(2)==K, "invalid GEMM dimensions");
    TORCH_CHECK((x.scalar_type()==at::kFloat || x.scalar_type()==at::kChar) && (w.scalar_type()==at::kFloat || w.scalar_type()==at::kChar), "expected float or int8 code words");
    TORCH_CHECK(xs.scalar_type()==at::kFloat && ws.scalar_type()==at::kFloat && xs.numel()==B*M && ws.numel()==B*N, "invalid scales");
    auto dtype=bfloat ? at::kBFloat16 : at::kHalf;
    if (use_bias) {
        TORCH_CHECK(bias.device()==x.device() && bias.numel()==B*N && (bias.scalar_type()==at::kFloat || bias.scalar_type()==dtype), "invalid bias");
        bias=bias.contiguous();
    }
    x=x.contiguous(); w=w.contiguous(); xs=xs.contiguous(); ws=ws.contiguous();
    auto out=torch::empty({B,M,N}, x.options().dtype(dtype));
    int64_t mt=(M+31)/32, nt=(N+31)/32;
    TORCH_CHECK(B*mt*nt<=2147483647LL, "grid too large");
    auto stream=at::cuda::getCurrentCUDAStream();
    const void* bp=use_bias ? bias.data_ptr() : nullptr;
    bool bf=use_bias && bias.scalar_type()==at::kFloat;
    if (bfloat) {
        dispatch_typed<at::BFloat16>(x,w,xs,ws,bp,out,B,M,N,K,mt,nt,bf,use_bias,stream);
    } else {
        dispatch_typed<at::Half>(x,w,xs,ws,bp,out,B,M,N,K,mt,nt,bf,use_bias,stream);
    }
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Batch-dimension int8 quantized GEMM: int8 activations x int8 weights, with an
    outer-product scale applied for dequantization.

    Computed independently for every matrix in the batch (mathematical definition):
      acc[b, m, n] = sum_k xq[b, m, k] * wq[b, n, k]          (float32 accumulation)
      out[b, m, n] = acc[b, m, n] * xs[b, m, 0] * ws[b, 0, n] (+ bias[b, 0, n])

    i.e. out[b] = xq[b] @ wq[b]^T followed by dequantization. wq is stored
    row-major as (B, N, K), so the computation is equivalent to a transposed GEMM
    (row n of the weight is one output-channel column). xs is the per-token scale:
    one value per row of the M dimension, (B, M, 1) float32; ws is the per-channel
    scale: one value per column of the N dimension, (B, 1, N) float32; their outer
    product is the (B, M, N) dequantization matrix. bias (B, 1, N) is optional and
    has the same dtype as the output; with bias the quantized-GEMM kernel fusion
    order applies: the float32 scaled result is first cast to the output dtype, then
    the bias is added.

    Input/output specification:
      xq      int8       (B, M, K)   activation code words
      wq      int8       (B, N, K)   weight code words (row-major, transposed-GEMM
                                     equivalent)
      xs      float32    (B, M, 1)   per-token scale
      ws      float32    (B, 1, N)   per-channel scale
      bias    output dtype (B, 1, N) optional; when use_bias=False a placeholder
                                     tensor is passed and ignored
      out     output dtype (B, M, N) the dtype is set by __init__'s out_dtype
                                     (bfloat16 / float16), B/M/N/K >= 1

    Implementation constraints (violations are scored as failures):
      - The core computation (the int8 GEMM accumulation) must be completed inside
        the submitted file; calling torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / torch._int_mm / F.linear /
        functional.linear is forbidden, as is calling any ready-made operator
        library or closed-source kernel wrapper to complete this computation
        directly.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Accumulate intermediates in float32; cast the output to out_dtype.
      - The evaluator casts all inputs to fp32 before calling forward; the code
        words are small integers in [-20, 20) and the bias values come from
        low-precision quantization, all exactly representable in fp32, so
        .to(torch.int8) / .to(out_dtype) at the entry point recovers them
        losslessly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: TN layout (x row-major (B,M,K), w row-major (B,N,K)), no split-K;
    B/M/N/K are any values >= 1 with no alignment requirement; the accumulation
    runs in float32 and must agree with the reference fp32 GEMM within tolerance.
    """
    def __init__(self, use_bias: bool = True, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.use_bias = bool(use_bias)
        self.out_dtype = getattr(torch, out_dtype)
        # <<<END_IMPROVE>>>

    def forward(self, xq, wq, x_scale, w_scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().batched_gemm(xq, wq, x_scale, w_scale, bias, self.use_bias, self.out_dtype == torch.bfloat16)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        wq = wq.to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        bias = bias.to(self.out_dtype) if self.use_bias else None
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        B, M, K = xq.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        N = wq.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert K == wq.shape[2], "xq and wq must agree on the K dimension"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        a = xq.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        b = wq.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        acc = torch.matmul(a, b.transpose(1, 2))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        acc = acc * x_scale
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        acc = acc * w_scale
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        acc = acc.to(self.out_dtype) if self.use_bias else acc
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        acc = acc + bias if self.use_bias else acc
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        return acc.to(self.out_dtype)
        # <<<END_IMPROVE>>>
