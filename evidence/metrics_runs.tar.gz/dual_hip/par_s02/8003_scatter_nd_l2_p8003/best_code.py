import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p8003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor nd_write(torch::Tensor data, torch::Tensor indices, torch::Tensor updates);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("nd_write", &nd_write);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <algorithm>
#include <cstdint>

struct NDMeta {
    int rank;
    int64_t strides[6];
};

template<class T>
__global__ void move_payload(const T* src, T* dst, int64_t n) {
    for (int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         i < n; i += int64_t(blockDim.x) * gridDim.x) {
        dst[i] = src[i];
    }
}

template<class T, class I, int R>
__global__ void write_payload(const I* indices, const T* updates, T* out,
                              int64_t k, NDMeta meta) {
    for (int64_t row = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
         row < k; row += int64_t(blockDim.x) * gridDim.x) {
        int64_t offset = 0;
        if (R == 1) {
            offset = static_cast<int64_t>(indices[row]);
        } else {
            #pragma unroll
            for (int d = 0; d < R; ++d) {
                offset += static_cast<int64_t>(indices[row * R + d]) * meta.strides[d];
            }
        }
        out[offset] = updates[row];
    }
}

template<class T, class I>
void launch_write(const I* indices, const T* updates, T* out,
                  int64_t k, NDMeta meta, int write_blocks, hipStream_t stream) {
    switch (meta.rank) {
        case 1: write_payload<T, I, 1><<<write_blocks, 256, 0, stream>>>(indices, updates, out, k, meta); break;
        case 2: write_payload<T, I, 2><<<write_blocks, 256, 0, stream>>>(indices, updates, out, k, meta); break;
        case 3: write_payload<T, I, 3><<<write_blocks, 256, 0, stream>>>(indices, updates, out, k, meta); break;
        case 4: write_payload<T, I, 4><<<write_blocks, 256, 0, stream>>>(indices, updates, out, k, meta); break;
        case 5: write_payload<T, I, 5><<<write_blocks, 256, 0, stream>>>(indices, updates, out, k, meta); break;
        case 6: write_payload<T, I, 6><<<write_blocks, 256, 0, stream>>>(indices, updates, out, k, meta); break;
    }
}

template<class T>
void run_movement(torch::Tensor data, torch::Tensor indices, torch::Tensor updates,
                  torch::Tensor out, NDMeta meta, hipStream_t stream) {
    int64_t n = data.numel(), k = updates.numel();
    int copy_blocks = static_cast<int>(std::min<int64_t>((n + 255) / 256, 4096));
    int write_blocks = static_cast<int>(std::min<int64_t>((k + 255) / 256, 4096));
    const T* src = reinterpret_cast<const T*>(data.data_ptr());
    const T* vals = reinterpret_cast<const T*>(updates.data_ptr());
    T* dst = reinterpret_cast<T*>(out.data_ptr());
    if (k < n) {
        move_payload<T><<<copy_blocks, 256, 0, stream>>>(src, dst, n);
        TORCH_CHECK(hipGetLastError() == hipSuccess, "Payload copy launch failed");
    }
    if (indices.scalar_type() == at::kLong) {
        launch_write<T, int64_t>(
            indices.data_ptr<int64_t>(), vals, dst, k, meta, write_blocks, stream);
    } else {
        launch_write<T, float>(
            indices.data_ptr<float>(), vals, dst, k, meta, write_blocks, stream);
    }
    TORCH_CHECK(hipGetLastError() == hipSuccess, "Payload write launch failed");
}

torch::Tensor nd_write(torch::Tensor data, torch::Tensor indices, torch::Tensor updates) {
    TORCH_CHECK(data.is_cuda() && indices.is_cuda() && updates.is_cuda(), "GPU tensors required");
    TORCH_CHECK(data.device() == indices.device() && data.device() == updates.device(), "Device mismatch");
    TORCH_CHECK(data.is_contiguous() && indices.is_contiguous() && updates.is_contiguous(), "Contiguous tensors required");
    TORCH_CHECK(data.dim() >= 1 && data.dim() <= 6, "Unsupported rank");
    TORCH_CHECK(indices.scalar_type() == at::kLong || indices.scalar_type() == at::kFloat, "Unsupported coordinate dtype");
    TORCH_CHECK(data.scalar_type() == updates.scalar_type(), "Payload dtype mismatch");
    TORCH_CHECK(data.scalar_type() == at::kFloat || data.scalar_type() == at::kHalf || data.scalar_type() == at::kBFloat16, "Unsupported payload dtype");
    c10::cuda::CUDAGuard guard(data.device());
    auto out = torch::empty_like(data);
    NDMeta meta{};
    meta.rank = data.dim();
    int64_t stride = 1;
    for (int d = meta.rank - 1; d >= 0; --d) {
        meta.strides[d] = stride;
        stride *= data.size(d);
    }
    hipStream_t stream = at::cuda::getCurrentCUDAStream();
    if (data.scalar_type() == at::kFloat) {
        run_movement<uint32_t>(data, indices, updates, out, meta, stream);
    } else {
        run_movement<uint16_t>(data, indices, updates, out, meta, stream);
    }
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    ScatterND: the index-write family that overwrites positions of `data`
    with `updates` according to integer index tuples.

    Semantics: data has shape (S_0, ..., S_{r-1}) where r is its rank; indices is
    an int64 tensor of shape (K, r) -- each row is a full coordinate tuple that
    picks exactly one position in data; updates has shape (K,) and the same dtype
    as data. The output out has the same shape and dtype as data:
        out[indices[k,0], ..., indices[k,r-1]] = updates[k]
            (hit positions: overwritten, the original value is discarded and
             replaced by the corresponding element of updates)
        all other positions out[i_0, ..., i_{r-1}] = data[i_0, ..., i_{r-1}]
            (misses: the original value is preserved bit-for-bit)
    The write semantics is overwrite, not accumulate; the K coordinate tuples are
    pairwise distinct (the generator samples without replacement), so every data
    element is written at most once. Which write wins for duplicate coordinate
    tuples is undefined behaviour (mainstream frameworks leave the write order
    for duplicate indices undefined either way), and duplicate tuples are outside
    this task's input domain -- the implementation need not define behaviour for
    them, and must not let deduplication / sorting or any other preprocessing
    change the overwrite result for distinct tuples.

    Input/output specification:
        data    float32 / float16 / bfloat16, contiguous, ndim in [1, 6],
                every dimension >= 1, total element count <= 2^23; values are
                ordinary randn magnitude (no inf/NaN)
        indices int64 (K, r) with r = data rank, 1 <= K <= the total element
                count of data; every index value lies in [0, S_d) and the K
                coordinate tuples are pairwise distinct
        updates same dtype as data, shape (K,), contiguous
        out     a single tensor, same shape / dtype as data, contiguous -- this
                operator is naturally single-output, so no multi-output packing is
                needed. forward must return a single tensor (the evaluator
                compares .shape / allclose on a single output).
        The online evaluator casts all inputs to fp32 before calling forward
        (indices are small non-negative integers < 2^24 and exactly
        representable in fp32, so they are recovered losslessly; fp16/bf16 ->
        fp32 is also lossless). The offline final audit passes inputs natively in
        their declared dtype -- the implementation must be correct for both.

    Boundary behaviour: K=1, K equal to the total element count of data (a full
    permutation, every element written), ndim=1 (indices shaped (K, 1)), and
    shapes with non-power-of-two / prime lengths or axes of length 1 must all be
    handled correctly; the output must be a fresh tensor and must not modify
    data / indices / updates in place.

    Implementation constraints (violations are scored as failures):
        - The core computation (r-dimensional coordinate -> linear offset address
          computation, reading updates, and moving the original values out for
          miss positions) must be completed with a HIP kernel inside the
          submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Pure-movement contract: miss positions match data bit-for-bit and hit
          positions match updates bit-for-bit (bit patterns preserved); no
          numeric transformation may be introduced.
        - forward returns the single tensor `out` (the evaluator compares a
          single output).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torch.scatter / .scatter( / .scatter_( / scatter_add / scatter_reduce /
    index_put / torch.put( / .put_( / index_copy / torch_scatter / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, data, indices, updates):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().nd_write(data, indices, updates)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        return out
        # <<<END_IMPROVE>>>
