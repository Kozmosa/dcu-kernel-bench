import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1010_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void paged_attention_out(torch::Tensor query, torch::Tensor key, torch::Tensor value, torch::Tensor key_cache, torch::Tensor value_cache, torch::Tensor block_tables, torch::Tensor query_start_loc, torch::Tensor seq_lens, torch::Tensor out, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention_out", &paged_attention_out);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

template<class T, int FixedD>
__global__ void paged_kernel(const T* q, const T* k, const T* v,
                            const T* kc, const T* vc, const int* bt,
                            const int* starts, const int* lens, T* out,
                            int H, int KH, int runtimeD, int BS, int NB,
                            int B, float scale) {
    const int D = FixedD ? FixedD : runtimeD;
    int token = blockIdx.x, h = blockIdx.y, tid = threadIdx.x;
    int lo = 0, hi = B + 1;
    while (lo < hi) {
        int mid = (lo + hi) / 2;
        if (starts[mid] <= token) lo = mid + 1;
        else hi = mid;
    }
    int b = lo - 1;
    int start = starts[b];
    int ctx = lens[b] - (starts[b + 1] - start);
    int end = ctx + token - start + 1;
    int kh = h / (H / KH);

    extern __shared__ float storage[];
    float* qs = storage;
    float* acc = storage + D;
    float running_acc = 0.0f;

    __shared__ float logits[32], probs[32];
    __shared__ float maximum, denom, rescale;
    __shared__ int tile_prefix[32];
    __shared__ int tile_physical[32];
    __shared__ int tile_slot[32];
    __shared__ int tile_new_offset[32];

    for (int d = tid; d < D; d += 256) {
        qs[d] = float(q[((int64_t)token * H + h) * D + d]);
        if (FixedD != 128) acc[d] = 0.0f;
    }
    if (tid == 0) {
        maximum = -INFINITY;
        denom = 0.0f;
    }
    __syncthreads();

    for (int base = 0; base < end; base += 32) {
        int r = tid / 8, lane = tid % 8, pos = base + r;
        int prefix = 0, physical = 0, slot = 0, new_offset = 0;
        if (lane == 0) {
            if (pos < end) {
                if (pos < ctx) {
                    prefix = 1;
                    physical = bt[(int64_t)b * NB + pos / BS];
                    slot = pos % BS;
                } else {
                    new_offset = start + pos - ctx;
                }
            }
            tile_prefix[r] = prefix;
            tile_physical[r] = physical;
            tile_slot[r] = slot;
            tile_new_offset[r] = new_offset;
        }
        prefix = __shfl(prefix, 0, 8);
        physical = __shfl(physical, 0, 8);
        slot = __shfl(slot, 0, 8);
        new_offset = __shfl(new_offset, 0, 8);

        float dot = 0.0f;
        if (pos < end) {
            if (prefix) {
                for (int d = lane; d < D; d += 8) {
                    int64_t offset = (((int64_t)physical * KH + kh) * (D / 8) + d / 8) * BS * 8 + slot * 8 + d % 8;
                    dot += qs[d] * float(kc[offset]);
                }
            } else {
                int64_t offset = ((int64_t)new_offset * KH + kh) * D;
                for (int d = lane; d < D; d += 8)
                    dot += qs[d] * float(k[offset + d]);
            }
        }
        for (int delta = 4; delta; delta >>= 1)
            dot += __shfl_down(dot, delta, 8);
        if (lane == 0) logits[r] = pos < end ? dot * scale : -INFINITY;
        __syncthreads();

        if (tid == 0) {
            float m = maximum;
            for (int i = 0; i < 32; ++i) m = fmaxf(m, logits[i]);
            float a = expf(maximum - m);
            float sum = denom * a;
            for (int i = 0; i < 32; ++i) {
                float p = expf(logits[i] - m);
                probs[i] = p;
                sum += p;
            }
            maximum = m;
            denom = sum;
            rescale = a;
        }
        __syncthreads();

        for (int d = tid; d < D; d += 256) {
            float z = (FixedD == 128 ? running_acc : acc[d]) * rescale;
            for (int i = 0; i < 32 && base + i < end; ++i) {
                float val;
                if (tile_prefix[i]) {
                    val = float(vc[(((int64_t)tile_physical[i] * KH + kh) * D + d) * BS + tile_slot[i]]);
                } else {
                    val = float(v[((int64_t)tile_new_offset[i] * KH + kh) * D + d]);
                }
                z += probs[i] * val;
            }
            if (FixedD == 128) running_acc = z;
            else acc[d] = z;
        }
        __syncthreads();
    }

    for (int d = tid; d < D; d += 256)
        out[((int64_t)token * H + h) * D + d] = T((FixedD == 128 ? running_acc : acc[d]) / denom);
}

void paged_attention_out(torch::Tensor query, torch::Tensor key, torch::Tensor value,
                         torch::Tensor key_cache, torch::Tensor value_cache,
                         torch::Tensor block_tables, torch::Tensor query_start_loc,
                         torch::Tensor seq_lens, torch::Tensor out, double scale) {
    c10::cuda::CUDAGuard guard(query.device());
    for (const auto& t : {query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens, out}) {
        TORCH_CHECK(t.is_cuda() && t.is_contiguous(), "Expected contiguous device tensors");
    }
    int N = query.size(0), H = query.size(1), D = query.size(2);
    int KH = key.size(1), BS = value_cache.size(3);
    TORCH_CHECK(D % 8 == 0 && H % KH == 0, "Invalid head dimensions");
    if (!N) return;
    auto stream = at::cuda::getCurrentCUDAStream();
    dim3 grid(N, H);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, query.scalar_type(), "paged_attention", [&] {
        if (D == 128) {
            paged_kernel<scalar_t, 128><<<grid, 256, D * sizeof(float), stream>>>(query.data_ptr<scalar_t>(), key.data_ptr<scalar_t>(), value.data_ptr<scalar_t>(), key_cache.data_ptr<scalar_t>(), value_cache.data_ptr<scalar_t>(), block_tables.data_ptr<int>(), query_start_loc.data_ptr<int>(), seq_lens.data_ptr<int>(), out.data_ptr<scalar_t>(), H, KH, D, BS, block_tables.size(1), seq_lens.numel(), float(scale));
        } else {
            paged_kernel<scalar_t, 0><<<grid, 256, 2 * D * sizeof(float), stream>>>(query.data_ptr<scalar_t>(), key.data_ptr<scalar_t>(), value.data_ptr<scalar_t>(), key_cache.data_ptr<scalar_t>(), value_cache.data_ptr<scalar_t>(), block_tables.data_ptr<int>(), query_start_loc.data_ptr<int>(), seq_lens.data_ptr<int>(), out.data_ptr<scalar_t>(), H, KH, D, BS, block_tables.size(1), seq_lens.numel(), float(scale));
        }
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Chunked prefill / decode mixed-batch attention over a paged KV cache (MHA and GQA, causal mask).

    The batch holds num_seqs sequences running in parallel; sequence b computes
    query_len[b] = query_start_loc[b+1] - query_start_loc[b] new query tokens
    this round, and the per-sequence slices are packed back to back along the
    token dimension according to query_start_loc (no padding). Sequence b
    currently has total length seq_lens[b], of which the first
    ctx_len[b] = seq_lens[b] - query_len[b] tokens are already-admitted prefix
    K/V that live only in the paged KV cache; the K/V of this round's new tokens
    are given separately and explicitly as key / value (consistent with the
    corresponding cache slots). A sequence with query_len[b] == 1 is decode,
    > 1 is chunked prefill, and the two kinds may be mixed in the same batch.

    Paged layout: the physical block pool has num_blocks blocks, each holding
    block_size token slots; block_tables[b] is that sequence's "logical block ->
    physical block number" table, covering the whole seq_lens[b] (including this
    round's new tokens). K uses a channel-packed layout: K[tok, h, d] lives at
    key_cache[pblk, h, d // x, tok % block_size, d % x] (x = 8, head_size is a
    multiple of 8); V is value_cache[pblk, h, d, tok % block_size]. Blocks of the
    pool that no block table references, and slots past a sequence's valid
    length, hold garbage data (magnitudes up to +/-10) and must not take part in
    the computation.

    For query head h of sequence b (its KV head is h // query_group_size, where
    query_group_size = num_heads / num_kv_heads) and its j-th new token (absolute
    position within the sequence pos = ctx_len[b] + j):

      logits[l] = scale * <query[pos, h, :], K[l]>,  l = 0 .. seq_lens[b]-1
      causal mask: logits at positions l > pos are set to -inf
      p[l] = exp(logits[l] - max_l logits) / sum_l' exp(logits[l'] - max_l logits)
      out[pos, h, :] = sum_l p[l] * V[l]

    The first ctx_len[b] K / V tokens come from the paged cache (indirectly
    addressed through the block table), the remaining query_len[b] come from
    key / value. softmax uses an online (numerically stable) implementation,
    intermediate accumulation is in float32, and the output is cast back to the
    input dtype.

    Input/output specification (forward parameter order):
      query           [num_tokens, num_heads, head_size]          fp16/bf16
      key             [num_tokens, num_kv_heads, head_size]       same as query
      value           [num_tokens, num_kv_heads, head_size]       same as query
      key_cache       [num_blocks, num_kv_heads, head_size//8, block_size, 8]  same as query
      value_cache     [num_blocks, num_kv_heads, head_size, block_size]        same as query
      block_tables    [num_seqs, max_blocks_per_seq]              int32
      query_start_loc [num_seqs+1] int32 (prefix sum of query_len, first element 0)
      seq_lens        [num_seqs] int32
      output out      [num_tokens, num_heads, head_size], dtype matches query.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be done inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn
        / torch.matmul / torch.bmm / torch.einsum / torch.softmax is forbidden
        (the complete forbidden list is defined by the task configuration's
        forbidden field).
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: chunked prefill/decode mixed batch, non-quantized KV, no ALiBi,
    no sliding window.
    """
    def __init__(self, head_size: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_size)
        # <<<END_IMPROVE>>>

    def forward(self, query, key, value, key_cache, value_cache, block_tables, query_start_loc, seq_lens):
        # <<<IMPROVE:forward_stmt_1>>>
        block_tables = block_tables.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        query_start_loc = query_start_loc.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens, num_heads, head_size = query.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        num_kv_heads = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        block_size = value_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        x = key_cache.shape[4]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        group = num_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert num_heads == num_kv_heads * group, "num_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(query)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _pyramidkernel_get_extension().paged_attention_out(
            query, key, value, key_cache, value_cache, block_tables,
            query_start_loc, seq_lens, out, self.scale)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
