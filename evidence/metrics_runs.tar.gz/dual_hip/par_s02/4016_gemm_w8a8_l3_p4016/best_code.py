import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p4016_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

// Add pybind exports for custom CUDA entrypoints here.
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>

// Add CUDA kernels and exported wrapper functions here.
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    int8 block-quantized GEMM (quantized activations x quantized weights,
    dequantized with block scales).

    Mathematical definition: given the int8 activation code words A (M,K), the
    int8 weight code words B (N,K), the activation per-token-group scale
    As (M, ceil(K/128)) and the weight 128x128 block scale
    Bs (ceil(N/128), ceil(K/128)) (all float32), dequantize first and then do
    the matrix multiply:
      Af[m,k] = A[m,k] * As[m, floor(k/128)]
      Bf[n,k] = B[n,k] * Bs[floor(n/128), floor(k/128)]
      out[m,n] = sum_k Af[m,k] * Bf[n,k]    (float32 accumulation, i.e. Af @ Bf^T)
    The equivalent compute order for block quantization: take an int8 dot
    product per 128-element group along K first (exactly accumulable in int32),
    then multiply by that group's As[m,g] * Bs[n_blk,g] and sum in float32 --
    equal to the expression above within float32 precision. The output is cast
    to the out_dtype passed to __init__.
    Boundary behaviour: when K or N is not divisible by 128 the floor index
    simply extends naturally -- a tail group/block covers only the valid
    elements (out-of-range elements do not take part in the accumulation), and
    the group counts of As/Bs are given by ceil(.../128).

    Input/output specification:
      aq      int8    (M, K)                 activation code words, row-major
      bq      int8    (N, K)                 weight code words, row-major (output channels on rows)
      a_scale float32 (M, ceil(K/128))       per-token scale, one group per 128 elements
      b_scale float32 (ceil(N/128), ceil(K/128))   weight 128x128 block scale
      out     out_dtype (M, N)              bfloat16 / float16
      M/N/K >= 1, all allow non-powers of two and a tail not aligned to 128.

    Implementation constraints (violations are scored as failures):
      - The core computation (int8 GEMM accumulation and the scale multiply)
        must be completed inside the submitted file, and calling library-level
        matrix-multiply shortcuts such as torch.matmul / torch.bmm / torch.mm /
        torch.addmm / torch.einsum / torch._int_mm / F.linear /
        functional.linear, or the other entries on the task set's static-audit
        forbidden list, is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation (int8 products can be
        accumulated exactly in int32 first, then converted to float32); the
        output is cast to out_dtype.
      - The evaluator casts every input to fp32 before calling forward; the
        int8 code-word range [-128,127] and the fp32 scales are both exactly
        representable, so .to(torch.int8) / .to(torch.float32) at the entry
        point recover them losslessly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: block shape fixed at [128,128], A is 2D (M,K), no bias, no
    splitK; the output is bfloat16 / float16.
    """
    def __init__(self, out_dtype: str = "bfloat16"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.out_dtype = getattr(torch, out_dtype)
        self.block_n = 128
        self.block_k = 128
        # <<<END_IMPROVE>>>

    def forward(self, aq, bq, a_scale, b_scale):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        aq = aq.to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        bq = bq.to(torch.int8)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        a_scale = a_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        b_scale = b_scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = aq.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        N = bq.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert K == bq.shape[1], "the K dimension of aq and bq must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        a = aq.to(torch.float32) * a_scale.repeat_interleave(self.block_k, dim=1)[:, :K]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        b_exp = (
            b_scale.repeat_interleave(self.block_n, dim=0)[:N]
            .repeat_interleave(self.block_k, dim=1)[:, :K]
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        b = bq.to(torch.float32) * b_exp
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        out = torch.matmul(a, b.t())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out.to(self.out_dtype)
        # <<<END_IMPROVE>>>
