import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5006_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor spconv_bwd(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, bool);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("spconv_bwd", &spconv_bwd);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <algorithm>

template <typename PairT, typename CountT>
__global__ void dg_kernel(const float* w, const float* y, const PairT* p,
                          const CountT* counts, float* dx,
                          int64_t n, int64_t ci, int64_t co, int64_t kv) {
    int64_t total = kv*n*ci;
    for (int64_t t = (int64_t)blockIdx.x*blockDim.x+threadIdx.x;
         t < total; t += (int64_t)gridDim.x*blockDim.x) {
        int64_t i = t%ci, j = (t/ci)%n, k = t/(ci*n);
        if (j >= static_cast<int>(counts[k])) continue;
        int64_t a = static_cast<int>(p[k*n+j]);
        int64_t b = static_cast<int>(p[kv*n+k*n+j]);
        float v = 0.0f;
        int64_t o = 0;
        for (; o + 7 < co; o += 8) {
            v = fmaf(y[b*co+o],     w[(o*kv+k)*ci+i],     v);
            v = fmaf(y[b*co+o+1],   w[((o+1)*kv+k)*ci+i], v);
            v = fmaf(y[b*co+o+2],   w[((o+2)*kv+k)*ci+i], v);
            v = fmaf(y[b*co+o+3],   w[((o+3)*kv+k)*ci+i], v);
            v = fmaf(y[b*co+o+4],   w[((o+4)*kv+k)*ci+i], v);
            v = fmaf(y[b*co+o+5],   w[((o+5)*kv+k)*ci+i], v);
            v = fmaf(y[b*co+o+6],   w[((o+6)*kv+k)*ci+i], v);
            v = fmaf(y[b*co+o+7],   w[((o+7)*kv+k)*ci+i], v);
        }
        for (; o < co; ++o)
            v = fmaf(y[b*co+o], w[(o*kv+k)*ci+i], v);
        atomicAdd(dx+a*ci+i, v);
    }
}

__global__ void wg_kernel(const float* x, const float* y, const int* p,
                          const int* counts, float* dw,
                          int64_t n, int64_t ci, int64_t co, int64_t kv) {
    int64_t total = co*kv*ci;
    for (int64_t t = (int64_t)blockIdx.x*blockDim.x+threadIdx.x;
         t < total; t += (int64_t)gridDim.x*blockDim.x) {
        int64_t i=t%ci, k=(t/ci)%kv, o=t/(ci*kv);
        float v=0.0f;
        for (int64_t j=0; j<counts[k]; ++j) {
            int64_t a=p[k*n+j], b=p[kv*n+k*n+j];
            v=fmaf(y[b*co+o], x[a*ci+i], v);
        }
        dw[t]=v;
    }
}

template <typename PairT, typename CountT>
void launch_dg(int blocks, hipStream_t stream, torch::Tensor w, torch::Tensor y,
               torch::Tensor p, torch::Tensor c, torch::Tensor result,
               int64_t n, int64_t ci, int64_t co, int64_t kv) {
    dg_kernel<PairT, CountT><<<blocks,256,0,stream>>>(w.data_ptr<float>(),y.data_ptr<float>(),p.data_ptr<PairT>(),c.data_ptr<CountT>(),result.data_ptr<float>(),n,ci,co,kv);
}

torch::Tensor spconv_bwd(torch::Tensor features, torch::Tensor filters,
                          torch::Tensor out_bp, torch::Tensor pairs,
                          torch::Tensor counts, bool dgrad) {
    c10::cuda::CUDAGuard guard(features.device());
    auto stream = c10::cuda::getCurrentCUDAStream(features.get_device()).stream();
    int64_t n=features.size(0), ci=filters.size(1), co=filters.size(0), kv=filters.size(2);
    auto y=out_bp.to(torch::kFloat32).contiguous();
    auto opts=features.options().dtype(torch::kFloat32);
    torch::Tensor result;
    if (dgrad) {
        auto p=(pairs.scalar_type()==torch::kFloat32 || pairs.scalar_type()==torch::kInt32)
            ? pairs.contiguous() : pairs.to(torch::kInt32).contiguous();
        auto c=(counts.scalar_type()==torch::kFloat32 || counts.scalar_type()==torch::kInt32)
            ? counts.contiguous() : counts.to(torch::kInt32).contiguous();
        auto w=filters.to(torch::kFloat32).contiguous();
        result=torch::zeros({n,ci},opts);
        int blocks=(int)std::min<int64_t>((kv*n*ci+255)/256,65535);
        if (p.scalar_type()==torch::kFloat32) {
            if (c.scalar_type()==torch::kFloat32)
                launch_dg<float,float>(blocks,stream,w,y,p,c,result,n,ci,co,kv);
            else
                launch_dg<float,int>(blocks,stream,w,y,p,c,result,n,ci,co,kv);
        } else {
            if (c.scalar_type()==torch::kFloat32)
                launch_dg<int,float>(blocks,stream,w,y,p,c,result,n,ci,co,kv);
            else
                launch_dg<int,int>(blocks,stream,w,y,p,c,result,n,ci,co,kv);
        }
    } else {
        auto p=pairs.to(torch::kInt32).contiguous();
        auto c=counts.to(torch::kInt32).contiguous();
        auto x=features.to(torch::kFloat32).contiguous();
        result=torch::empty({co,ci,kv},opts);
        int blocks=(int)std::min<int64_t>((co*kv*ci+255)/256,65535);
        wg_kernel<<<blocks,256,0,stream>>>(x.data_ptr<float>(),y.data_ptr<float>(),p.data_ptr<int>(),c.data_ptr<int>(),result.data_ptr<float>(),n,ci,co,kv);
    }
    auto err=hipGetLastError();
    TORCH_CHECK(err==hipSuccess, "HIP launch failed: ", hipGetErrorString(err));
    return result.to(features.scalar_type());
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Sparse convolution backward (gathered form spconv): dgrad (gradient with
    respect to the input features) and wgrad (gradient with respect to the
    weight buffer); it is the exact adjoint of the sparse convolution forward
    (gather-GEMM-scatter).

    Forward semantics (the sole authority for this task's convention; out is
    first initialized to all zeros, then accumulated by the formula below):
        for each kernel offset k in [0, kv):
            n_k = indice_num_per_loc[k]
            for each j in [0, n_k):
                in_idx  = indice_pairs[0, k, j]      # input row index in [0, n)
                out_idx = indice_pairs[1, k, j]      # output row index in [0, num_act_out)
                out[out_idx, :] += features[in_idx, :] @ W[:, :, k].T
    i.e. for each index pair, gather the input row and matrix-multiply it with
    the weight matrix of offset k ((n_k, c_in) @ (c_in, c_out)), then
    scatter-accumulate by the output row index into out.
    The mathematical weight W and the contiguous filters tensor F satisfy the
    layout mapping:
        W[o, i, k] = F.reshape(c_out, kv, c_in)[o, k, i]
    (equivalent to W = F.reshape(c_out, kv, c_in).permute(0, 2, 1), still shaped
    (c_out, c_in, kv)).

    Given the upstream gradient out_bp = dL/dy (shape (num_act_out, c_out)), the
    two directions are defined as the adjoint of that forward with respect to
    features / filters:
        dgrad: dx[in_idx, :] += out_bp[out_idx, :] @ W[:, :, k], output
               (n, c_in), i.e. dL/dfeatures;
        wgrad: dW_math[:, :, k] += out_bp[out_idx, :, None] *
               features[in_idx, None, :] (accumulated per index pair), output as
               the weight gradient dF (c_out, c_in, kv) interpreted with the same
               layout mapping as filters:
               dF.reshape(c_out, kv, c_in)[o, k, i] = dW_math[o, i, k],
               stored contiguously.
    The __init__ parameter variant selects which direction is returned:
        "dgrad": returns dx; here the values of features do not take part in the
                 output (shape convention only);
        "wgrad": returns dF; here the values of filters do not take part in the
                 output (shape convention only).
    forward(features, filters, out_bp, indice_pairs, indice_num_per_loc) has a
    fixed five-input signature; both directions are inherently single-tensor
    outputs (no concatenation packing).

    Boundary behaviour: kernel offsets with n_k = 0 are skipped entirely; when
    all n_k = 0 the output is all-zero; kv = 1 degenerates to a single offset;
    num_act_out and n are independent of each other (either may be the larger
    one). Index-pair table entries with j >= indice_num_per_loc[k] are padding
    garbage (they may hold any value, including duplicated valid row indices)
    and must be masked out according to indice_num_per_loc -- they must never be
    read into the computation. The same input/output row may be hit by any number
    of index pairs (duplicates are allowed within the same k), and all of them
    accumulate with +=.

    Input/output specification:
        features           float32 / float16 / bfloat16 (n, c_in), contiguous
        filters            same dtype as features (c_out, c_in, kv), contiguous
        out_bp             same dtype as features (num_act_out, c_out),
                           contiguous
        indice_pairs       int32 (2, kv, n), contiguous
        indice_num_per_loc int32 (kv,), contiguous
        out                a single tensor, same dtype as features: (n, c_in) for
                           dgrad, (c_out, c_in, kv) for wgrad
        Dimension domain: n, c_in, c_out, kv, num_act_out >= 1, non-powers-of-two
        allowed; indice_num_per_loc[k] in [0, n]; row indices <= 2^24. Input
        values are ordinary randn magnitude (no inf/NaN). The evaluator casts all
        input tensors to fp32 before the call (integer indices are exact up to
        2^24 and are recovered with int()/long()).

    Implementation constraints (violations are scored as failures):
        - The core computation must be done with a HIP kernel inside the
          submitted file: the scatter accumulation of dgrad (the out_bp rows
          transformed by W[:, :, k] and then scatter-accumulated by in_idx) or
          the per-index-pair outer-product correlation accumulation of wgrad;
          falling back to combinations of torch gather / matmul / scatter or to
          autograd is forbidden.
        - The __init__ and forward signatures of ModelNew must not be changed;
          forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).
        - Numeric contract: accumulate in float32 throughout (fp16/bf16 inputs
          are first cast losslessly to fp32), then cast the result back to the
          dtype of features; padding table entries must not take part in the
          computation (including out-of-bounds reads).

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    aiter / torch.sparse / torch.sparse_coo_tensor /
    torch.sparse_csr_tensor / torch.sparse_csc_tensor / torch.sparse_mm /
    torch.matmul / .matmul( / torch.mm / torch.bmm / torch.addmm /
    torch.baddbmm / torch.einsum / torch.tensordot /
    torch.nn.functional.linear / torch.nn.Linear /
    index_add (including every spelling .index_add( / index_add_ /
    torch.index_add) / index_put / torch.index_put / scatter_add (including
    scatter_add_) / .scatter_( / torch.scatter / scatter_reduce /
    segment_reduce / torch.gather / index_select / torch.take / torch.sum /
    torch.ops.aten / torch.autograd / .backward( / as_strided;
    the closed-source libraries MIOpen / hipDNN / cuDNN / rocBLAS / hipBLASLt
    are forbidden as well (global blacklist).
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "dgrad"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dgrad", "wgrad"), "variant must be either dgrad or wgrad"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, features, filters, out_bp, indice_pairs, indice_num_per_loc):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().spconv_bwd(features, filters, out_bp, indice_pairs, indice_num_per_loc, self.variant == "dgrad")
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # <<<END_IMPROVE>>>
