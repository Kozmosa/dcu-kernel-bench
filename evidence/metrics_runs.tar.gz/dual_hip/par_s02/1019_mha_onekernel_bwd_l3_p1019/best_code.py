import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1019_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void mha_backward_out(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, double, bool);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("mha_backward_out", &mha_backward_out);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

 template<class T> struct View4 {
  T* p;
  int64_t s0,s1,s2,s3;
  __device__ T& at(int b,int i,int h,int d) const {
    return p[b*s0+i*s1+h*s2+d*s3];
  }
};
template<class T> View4<T> view(torch::Tensor t) {
  return {t.data_ptr<T>(),t.stride(0),t.stride(1),t.stride(2),t.stride(3)};
}
__device__ float sum_wave(float x) {
  for(int s=warpSize/2;s>0;s/=2) x += __shfl_xor(x,s,warpSize);
  return x;
}
__device__ __forceinline__ void sum_wave2(float& a,float& b) {
  for(int s=warpSize/2;s>0;s/=2) {
    float ta=__shfl_xor(a,s,warpSize);
    float tb=__shfl_xor(b,s,warpSize);
    a+=ta;
    b+=tb;
  }
}
__device__ __forceinline__ void sum_wave3(float& a,float& b,float& c) {
  for(int s=warpSize/2;s>0;s/=2) {
    float ta=__shfl_xor(a,s,warpSize);
    float tb=__shfl_xor(b,s,warpSize);
    float tc=__shfl_xor(c,s,warpSize);
    a+=ta;
    b+=tb;
    c+=tc;
  }
}
template<class T, int SLOTS, bool CAUSAL, bool FULL_D64=false> __global__ void backward_kernel(
    View4<T> q,View4<T> k,View4<T> v,View4<T> o,View4<T> grad,
    const float* lse,int64_t ls0,int64_t ls1,int64_t ls2,
    View4<T> dq,View4<float> dk,View4<float> dv,
    int M,int N,int G,int D,float scale) {
  int j=blockIdx.x,hk=blockIdx.y,b=blockIdx.z,lane=threadIdx.x;
  const int offset=M-N;
  const bool query_long=offset>=0;
  int begin=0;
  if(CAUSAL) {
    if(query_long) begin=j+offset;
    else begin=max(0,j+offset);
  }
  float kr[SLOTS]={},vr[SLOTS]={},ak[SLOTS]={},av[SLOTS]={};
  #pragma unroll
  for(int t=0;t<SLOTS;++t) {
    int d=lane+t*warpSize;
    if(FULL_D64 || d<D) {kr[t]=float(k.at(b,j,hk,d));vr[t]=float(v.at(b,j,hk,d));}
  }
  for(int gh=0;gh<G;++gh) {
    int h=hk*G+gh;
    for(int i=begin;i<M;++i) {
      float qr[SLOTS]={},gr[SLOTS]={};
      float score=0,dp=0,delta=0;
      #pragma unroll
      for(int t=0;t<SLOTS;++t) {
        int d=lane+t*warpSize;
        if(FULL_D64 || d<D) {
          qr[t]=float(q.at(b,i,h,d)); gr[t]=float(grad.at(b,i,h,d));
          score+=qr[t]*kr[t]; dp+=gr[t]*vr[t];
          delta+=float(o.at(b,i,h,d))*gr[t];
        }
      }
      sum_wave3(score,dp,delta);
      float p=expf(scale*score-lse[b*ls0+h*ls1+i*ls2]);
      float ds=p*(dp-delta);
      #pragma unroll
      for(int t=0;t<SLOTS;++t) {ak[t]+=ds*qr[t];av[t]+=p*gr[t];}
    }
  }
  #pragma unroll
  for(int t=0;t<SLOTS;++t) {
    int d=lane+t*warpSize;
    if(FULL_D64 || d<D) {dk.at(b,j,hk,d)=scale*ak[t];dv.at(b,j,hk,d)=av[t];}
  }
  for(int r=j;r<M*G;r+=N) {
    int i=r%M,h=hk*G+r/M;
    int end=N;
    if(CAUSAL) {
      if(query_long) end=max(0,i-offset+1);
      else end=i-offset+1;
    }
    if(CAUSAL && end==0) {
      #pragma unroll
      for(int t=0;t<SLOTS;++t) {
        int d=lane+t*warpSize;
        if(FULL_D64 || d<D) dq.at(b,i,h,d)=T(0);
      }
      continue;
    }
    float qr[SLOTS]={},gr[SLOTS]={},aq[SLOTS]={};
    float delta=0;
    #pragma unroll
    for(int t=0;t<SLOTS;++t) {
      int d=lane+t*warpSize;
      if(FULL_D64 || d<D) {
        qr[t]=float(q.at(b,i,h,d));gr[t]=float(grad.at(b,i,h,d));
        delta+=float(o.at(b,i,h,d))*gr[t];
      }
    }
    delta=sum_wave(delta);
    float row_lse=lse[b*ls0+h*ls1+i*ls2];
    for(int jj=0;jj<end;++jj) {
      float keys[SLOTS]={};float score=0,dp=0;
      #pragma unroll
      for(int t=0;t<SLOTS;++t) {
        int d=lane+t*warpSize;
        if(FULL_D64 || d<D) {
          keys[t]=float(k.at(b,jj,hk,d));
          score+=qr[t]*keys[t];dp+=gr[t]*float(v.at(b,jj,hk,d));
        }
      }
      sum_wave2(score,dp);
      float ds=expf(scale*score-row_lse)*(dp-delta);
      #pragma unroll
      for(int t=0;t<SLOTS;++t) aq[t]+=ds*keys[t];
    }
    #pragma unroll
    for(int t=0;t<SLOTS;++t) {
      int d=lane+t*warpSize;
      if(FULL_D64 || d<D) dq.at(b,i,h,d)=T(scale*aq[t]);
    }
  }
}
void mha_backward_out(torch::Tensor q,torch::Tensor k,torch::Tensor v,
    torch::Tensor o,torch::Tensor lse,torch::Tensor grad,
    torch::Tensor dq,torch::Tensor dk,torch::Tensor dv,double scale,bool causal) {
  c10::cuda::CUDAGuard guard(q.device());
  TORCH_CHECK(q.size(3)>0 && q.size(3)<=256,"unsupported head dimension");
  int B=q.size(0),M=q.size(1),N=k.size(1),HK=k.size(2),G=q.size(2)/HK,D=q.size(3);
  hipDeviceProp_t prop;
  auto err=hipGetDeviceProperties(&prop,q.get_device());
  TORCH_CHECK(err==hipSuccess,hipGetErrorString(err));
  auto stream=at::cuda::getCurrentCUDAStream();
  int slots=(D+prop.warpSize-1)/prop.warpSize;
  #define LAUNCH_CAUSAL(S,C,F) backward_kernel<scalar_t,S,C,F><<<dim3(N,HK,B),(F ? 64 : prop.warpSize),0,stream>>>( \
      view<scalar_t>(q),view<scalar_t>(k),view<scalar_t>(v),view<scalar_t>(o),view<scalar_t>(grad), \
      lse.data_ptr<float>(),lse.stride(0),lse.stride(1),lse.stride(2), \
      view<scalar_t>(dq),view<float>(dk),view<float>(dv),M,N,G,D,float(scale))
  #define LAUNCH_SLOTS(S) do { if(causal) { LAUNCH_CAUSAL(S,true,false); } else { LAUNCH_CAUSAL(S,false,false); } } while(0)
  AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,at::ScalarType::BFloat16,q.scalar_type(),"mha_backward_out",[&] {
    if(D==64 && prop.warpSize==64) {
      if(causal) { LAUNCH_CAUSAL(1,true,true); }
      else { LAUNCH_CAUSAL(1,false,true); }
    } else {
      switch(slots) {
        case 1: LAUNCH_SLOTS(1); break;
        case 2: LAUNCH_SLOTS(2); break;
        case 3: LAUNCH_SLOTS(3); break;
        case 4: LAUNCH_SLOTS(4); break;
        case 5: LAUNCH_SLOTS(5); break;
        case 6: LAUNCH_SLOTS(6); break;
        case 7: LAUNCH_SLOTS(7); break;
        case 8: LAUNCH_SLOTS(8); break;
        default: TORCH_CHECK(false,"unsupported lane extent");
      }
    }
  });
  #undef LAUNCH_SLOTS
  #undef LAUNCH_CAUSAL
  err=hipGetLastError();
  TORCH_CHECK(err==hipSuccess,hipGetErrorString(err));
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    FlashAttention backward (one-kernel form): given the forward output o and the
    per-row log-sum-exp statistics lse, compute the gradients (dq, dk, dv) from
    (q, k, v, o, lse, do); dK/dV and dQ are produced inside the same kernel
    (dK/dV first, dQ after).

    Mathematical definition (let g = num_q_heads // num_kv_heads and the scaled
    score be s[b,h,i,j] = sm_scale * <q[b,i,h,:], k[b,j,h//g,:]>,
    with sm_scale defaulting to 1/sqrt(head_dim)):
      keep[b,i,j] = (j <= i + seqlen_k - seqlen_q) when causal=1 (bottom-right
                    aligned), always true when causal=0
      p[b,h,i,j]   = exp(s[b,h,i,j] - lse[b,h,i]), and masked positions (keep=0) are always 0
      delta[b,h,i] = sum_d o[b,i,h,d] * do[b,i,h,d]   (computed from the given o)
      dp[b,h,i,j]  = <do[b,i,h,:], v[b,j,h//g,:]>
      ds[b,h,i,j]  = p[b,h,i,j] * (dp[b,h,i,j] - delta[b,h,i])
      dv[b,j,h_k,d] = sum_{h = h_k*g .. h_k*g+g-1} sum_i p[b,h,i,j] * do[b,i,h,d]
      dk[b,j,h_k,d] = sm_scale * sum_{h in the same group} sum_i ds[b,h,i,j] * q[b,i,h,d]
      dq[b,i,h,d]   = sm_scale * sum_j ds[b,h,i,j] * k[b,j,h//g,d]
    Note that dK/dQ are multiplied by sm_scale at the end while dV is not; delta
    uses the input o (not the ideal forward output).
    Boundary behaviour: when causal=1 and i < seqlen_q - seqlen_k the row is fully
    masked -- p/ds are always 0, the dq row is all 0, and it contributes nothing to
    dk/dv (the task input convention sets o=0 and lse=0 for those rows).

    Input/output specification:
      q, o, do  [batch, seqlen_q, num_q_heads, head_dim] float16/bfloat16
      k, v      [batch, seqlen_k, num_kv_heads, head_dim] same dtype as q
      lse       [batch, num_q_heads, seqlen_q] float32 -- natural-log log-sum-exp of
                the scaled scores (0 for fully masked rows)
      returns a single 1-D tensor packed (multi-output packing protocol):
      packed = cat([dq flattened, dk flattened, dv flattened]) (each segment is
      first cast back to the input dtype, then converted to float32)
      where dq has the same shape as q and dk/dv the same shape as k; the total
      length of packed is
      (batch*seqlen_q*num_q_heads + 2*batch*seqlen_k*num_kv_heads) * head_dim.
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
      (GQA; equal means MHA); 1 <= head_dim <= 256 (need not be a power of 2);
      1 <= seqlen_q, seqlen_k; o and lse are the self-consistent forward statistics
      of (q, k, v) (guaranteed by the task's input generator).

    Implementation constraints (violations are scored as failures):
      - The core computation (all matrix multiplies and elementwise operations of
        delta / p / ds / dV / dK / dQ) must be done inside the submitted file;
        calling scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax is forbidden, and so are
        automatic-differentiation shortcuts such as torch.autograd /
        autograd.grad / .backward(.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - forward must return a single 1-D float32 tensor following the packing
        protocol above (compute dq/dk/dv internally first, then flatten and
        concatenate each).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: dense fixed-length (non-varlen), non-quantized inputs, no dropout /
    ALiBi / bias / fp8; causal and non-causal are selected by __init__'s causal
    switch.
    """
    def __init__(self, head_dim: int, causal: int, scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.head_dim = int(head_dim)
        self.causal = bool(int(causal))
        self.sm_scale = float(scale) if scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, o, lse, do):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        B, M, H_Q, D = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        _, N, H_K, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        group = H_Q // H_K
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert H_Q == H_K * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        causal = bool(self.causal)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dq = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        dk = torch.zeros(B, N, H_K, D, dtype=torch.float32, device=q.device)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        dv = torch.zeros_like(dk)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        _pyramidkernel_get_extension().mha_backward_out(
            q, k, v, o, lse, do, dq, dk, dv, self.sm_scale, causal
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return torch.cat([
            dq.reshape(-1).to(k.dtype).to(torch.float32),
            dk.reshape(-1).to(k.dtype).to(torch.float32),
            dv.reshape(-1).to(v.dtype).to(torch.float32),
        ])
        # <<<END_IMPROVE>>>
