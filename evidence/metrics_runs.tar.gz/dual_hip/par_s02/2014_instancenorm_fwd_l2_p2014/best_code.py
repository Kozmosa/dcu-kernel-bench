import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2014_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor instancenorm_fwd(torch::Tensor x, torch::Tensor scale, torch::Tensor bias, double eps);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("instancenorm_fwd", &instancenorm_fwd, "InstanceNorm forward (HIP)");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>

namespace {

__device__ __forceinline__ float block_sum(float value, float* scratch) {
    const int tid = static_cast<int>(threadIdx.x);
    const int lane = tid % warpSize;
    const int wave = tid / warpSize;
    for (int offset = warpSize / 2; offset > 0; offset >>= 1) {
        value += __shfl_down(value, offset, warpSize);
    }
    if (lane == 0) scratch[wave] = value;
    __syncthreads();
    const int waves = (static_cast<int>(blockDim.x) + warpSize - 1) / warpSize;
    if (wave == 0) {
        value = (lane < waves) ? scratch[lane] : 0.0f;
        for (int offset = warpSize / 2; offset > 0; offset >>= 1) {
            value += __shfl_down(value, offset, warpSize);
        }
        if (lane == 0) scratch[0] = value;
    }
    __syncthreads();
    return scratch[0];
}

template <typename scalar_t, int CAP>
__global__ void instancenorm_retained_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ scale,
    const scalar_t* __restrict__ bias,
    scalar_t* __restrict__ out,
    int64_t planes,
    int64_t hw,
    int64_t channels,
    float eps) {
    __shared__ float reduction[256];
    const int tid = static_cast<int>(threadIdx.x);
    const int64_t plane = static_cast<int64_t>(blockIdx.x);
    if (plane >= planes) return;
    const int64_t base = plane * hw;
    const int64_t c = plane % channels;
    float values[CAP];
    int64_t indices[CAP];
    float sum = 0.0f;
#pragma unroll
    for (int k = 0; k < CAP; ++k) {
        const int64_t idx = static_cast<int64_t>(tid) + static_cast<int64_t>(k) * blockDim.x;
        indices[k] = idx;
        if (idx < hw) {
            const float v = static_cast<float>(x[base + idx]);
            values[k] = v;
            sum += v;
        } else {
            values[k] = 0.0f;
        }
    }
    const float total = block_sum(sum, reduction);
    const float mean = total / static_cast<float>(hw);
    float sq = 0.0f;
#pragma unroll
    for (int k = 0; k < CAP; ++k) {
        if (indices[k] < hw) {
            const float centered = values[k] - mean;
            sq += centered * centered;
        }
    }
    const float sq_total = block_sum(sq, reduction);
    const float inv_std = rsqrtf(sq_total / static_cast<float>(hw) + eps);
    const float s = static_cast<float>(scale[c]);
    const float b = static_cast<float>(bias[c]);
#pragma unroll
    for (int k = 0; k < CAP; ++k) {
        if (indices[k] < hw) {
            const float result = (values[k] - mean) * inv_std * s + b;
            out[base + indices[k]] = static_cast<scalar_t>(result);
        }
    }
}

template <typename scalar_t>
__global__ void instancenorm_kernel(
    const scalar_t* __restrict__ x,
    const scalar_t* __restrict__ scale,
    const scalar_t* __restrict__ bias,
    scalar_t* __restrict__ out,
    int64_t planes,
    int64_t hw,
    int64_t channels,
    float eps) {
    __shared__ float reduction[256];
    const int tid = static_cast<int>(threadIdx.x);
    const int64_t plane = static_cast<int64_t>(blockIdx.x);
    if (plane >= planes) return;
    const int64_t c = plane % channels;
    const int64_t base = plane * hw;
    float sum = 0.0f;
#pragma unroll 4
    for (int64_t i = tid; i < hw; i += blockDim.x) sum += static_cast<float>(x[base + i]);
    const float total = block_sum(sum, reduction);
    const float mean = total / static_cast<float>(hw);
    float sq = 0.0f;
#pragma unroll 4
    for (int64_t i = tid; i < hw; i += blockDim.x) {
        const float v = static_cast<float>(x[base + i]) - mean;
        sq += v * v;
    }
    const float sq_total = block_sum(sq, reduction);
    const float inv_std = rsqrtf(sq_total / static_cast<float>(hw) + eps);
    const float s = static_cast<float>(scale[c]);
    const float b = static_cast<float>(bias[c]);
#pragma unroll 4
    for (int64_t i = tid; i < hw; i += blockDim.x) {
        const float v = (static_cast<float>(x[base + i]) - mean) * inv_std * s + b;
        out[base + i] = static_cast<scalar_t>(v);
    }
}

} // namespace

torch::Tensor instancenorm_fwd(torch::Tensor x, torch::Tensor scale, torch::Tensor bias, double eps) {
    TORCH_CHECK(x.is_cuda(), "x must be a CUDA/HIP tensor");
    TORCH_CHECK(x.is_contiguous(), "x must be contiguous");
    TORCH_CHECK(scale.is_contiguous() && bias.is_contiguous(), "affine tensors must be contiguous");
    TORCH_CHECK(x.dim() == 4, "x must be NCHW");
    TORCH_CHECK(x.scalar_type() == scale.scalar_type() && x.scalar_type() == bias.scalar_type(), "dtype mismatch");
    const int64_t n = x.size(0);
    const int64_t c = x.size(1);
    const int64_t hw = x.size(2) * x.size(3);
    const int64_t planes = n * c;
    auto out = torch::empty_like(x);
    auto stream = at::cuda::getCurrentCUDAStream(x.get_device());
    AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16, x.scalar_type(), "instancenorm_fwd_hip", [&] {
        if (hw <= 256) {
            hipLaunchKernelGGL((instancenorm_retained_kernel<scalar_t, 4>), dim3(static_cast<unsigned int>(planes)), dim3(256), 0, stream.stream(), x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), planes, hw, c, static_cast<float>(eps));
        } else if (hw <= 512) {
            hipLaunchKernelGGL((instancenorm_retained_kernel<scalar_t, 8>), dim3(static_cast<unsigned int>(planes)), dim3(256), 0, stream.stream(), x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), planes, hw, c, static_cast<float>(eps));
        } else if (hw <= 1024) {
            hipLaunchKernelGGL((instancenorm_retained_kernel<scalar_t, 16>), dim3(static_cast<unsigned int>(planes)), dim3(256), 0, stream.stream(), x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), planes, hw, c, static_cast<float>(eps));
        } else if (hw <= 2048) {
            hipLaunchKernelGGL((instancenorm_retained_kernel<scalar_t, 32>), dim3(static_cast<unsigned int>(planes)), dim3(256), 0, stream.stream(), x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), planes, hw, c, static_cast<float>(eps));
        } else {
            hipLaunchKernelGGL((instancenorm_kernel<scalar_t>), dim3(static_cast<unsigned int>(planes)), dim3(256), 0, stream.stream(), x.data_ptr<scalar_t>(), scale.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), planes, hw, c, static_cast<float>(eps));
        }
    });
    TORCH_CHECK(hipGetLastError() == hipSuccess, "InstanceNorm HIP kernel launch failed");
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    InstanceNorm forward pass: per-(N,C) spatial-statistics normalization plus
    per-channel affine (single variant).

    The input x (N, C, H, W) is NCHW contiguous; scale / bias are the (1, C, 1, 1)
    per-channel affine parameters, broadcast along the channel dimension; eps
    defaults to 1e-5. Statistics are taken over the spatial dimensions (H, W) for
    every (n, c) plane (HW = H*W elements per plane), in float32:
        mean_nc    = sum_{h,w} x[n,c,h,w] / HW                  (biased mean)
        var_nc     = sum_{h,w} (x[n,c,h,w] - mean_nc)^2 / HW    (biased variance)
        inv_std_nc = 1 / sqrt(var_nc + eps)
        y[n,c,h,w] = scale[c] * (x[n,c,h,w] - mean_nc) * inv_std_nc + bias[c]
    Instance norm has no train / inference semantic difference: the normalization
    statistics always come from the input itself. The convention is biased (divide
    by HW rather than HW-1), and eps sits inside the rsqrt (its only purpose is the
    division-by-zero guard; it takes part in no unbiased correction).

    Boundary behaviour: when HW == 1 (a single spatial element) var = 0 and
    x - mean = 0, so inv_std = 1/sqrt(eps) and y = bias (eps guarantees no division
    by zero); N/C/H/W are arbitrary (including 1, non-powers-of-two, and unaligned
    sizes); a large HW requires a blocked reduction, and out-of-range elements at
    the row tail must not participate in the statistics.

    Input/output specification:
        x     float32 / float16 / bfloat16 (N, C, H, W), contiguous,
              N/C/H/W >= 1
        scale same dtype as x, (1, C, 1, 1), contiguous
        bias  same dtype as x, (1, C, 1, 1), contiguous
        out   a single tensor, y itself: (N, C, H, W) with the same dtype as x
              (statistics and affine run in float32 intermediates, then cast back
              to the x dtype); no packing
        The inputs are ordinary randn/rand magnitude (no inf/NaN); the evaluator
        casts all inputs to fp32 before calling forward (fp16/bf16 -> fp32 is
        lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the per-(N,C) spatial reduction statistics, rsqrt,
          and the per-channel affine) must be completed with a HIP kernel inside
          the submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt and affine all run in float32 intermediates; y is
          cast back to the x dtype.
        - forward returns the single tensor `out` (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden list: torch.nn.InstanceNorm1d / torch.nn.InstanceNorm2d /
    torch.nn.InstanceNorm3d / torch.nn.functional.instance_norm /
    F.instance_norm / torch.instance_norm / native_instance_norm /
    torch.nn.GroupNorm / nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm /
    torch.nn.BatchNorm1d / torch.nn.BatchNorm2d / torch.nn.BatchNorm3d /
    torch.nn.SyncBatchNorm / torch.nn.functional.batch_norm /
    F.batch_norm / torch.batch_norm / torch.native_batch_norm /
    miopen / hipdnn.
    (GroupNorm with num_groups=C and BatchNorm via a (1, N*C, H, W) reshape both
    complete this task's core computation in a single step, so they are forbidden
    alongside the instance_norm family.)
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert eps > 0, "eps must be positive"
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        out = _pyramidkernel_get_extension().instancenorm_fwd(x, scale, bias, self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        # Statistics are computed by the fused HIP kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        return out
        # <<<END_IMPROVE>>>
