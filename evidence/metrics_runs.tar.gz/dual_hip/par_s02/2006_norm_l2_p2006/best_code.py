import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2006_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor fused_residual_norm(torch::Tensor x, torch::Tensor residual, torch::Tensor weight, torch::Tensor bias, double eps);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_residual_norm", &fused_residual_norm);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <type_traits>
#include <cstdint>

__device__ float reduce_sum(float v, float* scratch) {
    int t = threadIdx.x;
    scratch[t] = v;
    __syncthreads();
    for (int stride = 128; stride > 0; stride >>= 1) {
        if (t < stride) scratch[t] += scratch[t + stride];
        __syncthreads();
    }
    float result = scratch[0];
    __syncthreads();
    return result;
}

template <typename T, int Capacity>
__global__ void residual_norm_kernel(const T* x, const T* residual,
                                     const T* weight, const T* bias,
                                     T* out, int64_t n, float eps) {
    __shared__ float scratch[256];
    int64_t row = blockIdx.x;
    int64_t base = row * n;
    int64_t dst = row * (2 * n);
    if constexpr (std::is_same<T, float>::value && Capacity >= 4) {
        uintptr_t alignment = reinterpret_cast<uintptr_t>(x + base)
                            | reinterpret_cast<uintptr_t>(residual + base)
                            | reinterpret_cast<uintptr_t>(weight)
                            | reinterpret_cast<uintptr_t>(bias)
                            | reinterpret_cast<uintptr_t>(out + dst)
                            | reinterpret_cast<uintptr_t>(out + dst + n);
        if ((alignment & 15) == 0 && (n & 3) == 0) {
            float cached[Capacity];
            float sum = 0.0f;
            #pragma unroll
            for (int k = 0; k < Capacity; k += 4) {
                int64_t j = 4 * threadIdx.x + 256 * k;
                if (j + 3 < n) {
                    float4 a = *reinterpret_cast<const float4*>(x + base + j);
                    float4 b = *reinterpret_cast<const float4*>(residual + base + j);
                    float4 s = make_float4(static_cast<T>(a.x + b.x), static_cast<T>(a.y + b.y), static_cast<T>(a.z + b.z), static_cast<T>(a.w + b.w));
                    *reinterpret_cast<float4*>(out + dst + n + j) = s;
                    cached[k] = s.x;
                    cached[k+1] = s.y;
                    cached[k+2] = s.z;
                    cached[k+3] = s.w;
                    sum += s.x;
                    sum += s.y;
                    sum += s.z;
                    sum += s.w;
                }
            }
            float mean = reduce_sum(sum, scratch) / static_cast<float>(n);
            float squares = 0.0f;
            #pragma unroll
            for (int k = 0; k < Capacity; ++k) {
                int64_t j = 4 * threadIdx.x + 256 * (k & ~3) + (k & 3);
                if (j < n) {
                    float d = cached[k] - mean;
                    volatile float sq = d * d;
                    squares += sq;
                }
            }
            float var = reduce_sum(squares, scratch) / static_cast<float>(n);
            float rstd = rsqrtf(var + eps);
            #pragma unroll
            for (int k = 0; k < Capacity; k += 4) {
                int64_t j = 4 * threadIdx.x + 256 * k;
                if (j + 3 < n) {
                    float4 w = *reinterpret_cast<const float4*>(weight + j);
                    float4 b = *reinterpret_cast<const float4*>(bias + j);
                    volatile float sx = ((cached[k] - mean) * rstd) * w.x;
                    volatile float sy = ((cached[k+1] - mean) * rstd) * w.y;
                    volatile float sz = ((cached[k+2] - mean) * rstd) * w.z;
                    volatile float sw = ((cached[k+3] - mean) * rstd) * w.w;
                    *reinterpret_cast<float4*>(out + dst + j) = make_float4(sx + b.x, sy + b.y, sz + b.z, sw + b.w);
                }
            }
            return;
        }
    }
    if (Capacity > 0) {
        float cached[Capacity > 0 ? Capacity : 1];
        float sum = 0.0f;
        #pragma unroll
        for (int k = 0; k < Capacity; ++k) {
            int64_t j = threadIdx.x + 256 * k;
            if (j < n) {
                T s = static_cast<T>(static_cast<float>(x[base+j]) + static_cast<float>(residual[base+j]));
                out[dst+n+j] = s;
                cached[k] = static_cast<float>(s);
                sum += cached[k];
            }
        }
        float mean = reduce_sum(sum, scratch) / static_cast<float>(n);
        float squares = 0.0f;
        #pragma unroll
        for (int k = 0; k < Capacity; ++k) {
            int64_t j = threadIdx.x + 256 * k;
            if (j < n) {
                float d = cached[k] - mean;
                volatile float sq = d * d;
                squares += sq;
            }
        }
        float var = reduce_sum(squares, scratch) / static_cast<float>(n);
        float rstd = rsqrtf(var + eps);
        #pragma unroll
        for (int k = 0; k < Capacity; ++k) {
            int64_t j = threadIdx.x + 256 * k;
            if (j < n) {
                float normalized = (cached[k] - mean) * rstd;
                volatile float scaled = normalized * static_cast<float>(weight[j]);
                out[dst+j] = static_cast<T>(scaled + static_cast<float>(bias[j]));
            }
        }
        return;
    }
    float sum = 0.0f;
    for (int64_t j = threadIdx.x; j < n; j += 256) {
        T s = static_cast<T>(static_cast<float>(x[base+j]) + static_cast<float>(residual[base+j]));
        out[dst+n+j] = s;
        sum += static_cast<float>(s);
    }
    float mean = reduce_sum(sum, scratch) / static_cast<float>(n);
    float squares = 0.0f;
    for (int64_t j = threadIdx.x; j < n; j += 256) {
        float d = static_cast<float>(out[dst+n+j]) - mean;
        volatile float sq = d * d;
        squares += sq;
    }
    float var = reduce_sum(squares, scratch) / static_cast<float>(n);
    float rstd = rsqrtf(var + eps);
    for (int64_t j = threadIdx.x; j < n; j += 256) {
        float normalized = (static_cast<float>(out[dst+n+j]) - mean) * rstd;
        volatile float scaled = normalized * static_cast<float>(weight[j]);
        out[dst+j] = static_cast<T>(scaled + static_cast<float>(bias[j]));
    }
}

#define LAUNCH_CAPACITY(C) hipLaunchKernelGGL((residual_norm_kernel<scalar_t, C>), dim3(m), dim3(256), 0, stream.stream(), x.data_ptr<scalar_t>(), residual.data_ptr<scalar_t>(), weight.data_ptr<scalar_t>(), bias.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), n, static_cast<float>(eps))

torch::Tensor fused_residual_norm(torch::Tensor x, torch::Tensor residual,
                                  torch::Tensor weight, torch::Tensor bias, double eps) {
    c10::cuda::CUDAGuard guard(x.device());
    int64_t m = x.size(0), n = x.size(1);
    auto out = torch::empty({m, 2*n}, x.options());
    auto stream = at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(), "fused_residual_norm", [&] {
        if (n <= 256) { LAUNCH_CAPACITY(1); }
        else if (n <= 512) { LAUNCH_CAPACITY(2); }
        else if (n <= 1024) { LAUNCH_CAPACITY(4); }
        else if (n <= 2048) { LAUNCH_CAPACITY(8); }
        else if (n <= 4096) { LAUNCH_CAPACITY(16); }
        else if (n <= 8192) { LAUNCH_CAPACITY(32); }
        else { LAUNCH_CAPACITY(0); }
    });
    hipError_t err = hipGetLastError();
    TORCH_CHECK(err == hipSuccess, "residual norm launch failed: ", hipGetErrorString(err));
    return out;
}
#undef LAUNCH_CAPACITY
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Forward pass of residual-fused LayerNorm (fused add LayerNorm).

    The inputs x and residual are added element-wise to form the residual sum s
    (the addition happens in float32, then s is rounded back to the input dtype
    for storage); LayerNorm is then applied to the last dimension of s together
    with an affine transform (everything evaluated in float32):
        mean_i  = (1/N) * sum_j s[i, j]
        var_i   = (1/N) * sum_j (s[i, j] - mean_i)^2      (biased variance)
        rstd_i  = 1 / sqrt(var_i + eps)                   (eps comes from __init__)
        y[i, j] = (s[i, j] - mean_i) * rstd_i * weight[j] + bias[j]
    The statistics are taken over s as rounded back to the input dtype; y is
    finally rounded back to the input dtype as well.
    Boundary behaviour: N is any positive integer (including 1, non-power-of-two,
    and very long rows), columns outside the mask do not participate in the
    statistics; when var = 0, eps keeps rstd finite; the inputs contain no
    inf/NaN.

    The output is a single tensor out (M, 2N) with the same dtype as the inputs:
        out[:, :N] = y           the LayerNorm output
        out[:, N:] = s           residual_out (the residual sum rounded to the input dtype)

    Input/output specification:
        x        (M, N)  float16 / bfloat16 / float32, contiguous, M >= 1, N >= 1
        residual (M, N)  same as x
        weight   (N,)    same as x (per-channel scale)
        bias     (N,)    same as x (per-channel shift)
        (the evaluator casts the inputs to fp32 before calling forward;
         fp16/bf16 -> fp32 is lossless)

    Implementation constraints (violations are scored as failures):
        - The core computation (residual add, mean/var statistics, normalization,
          affine transform) must be completed with a HIP kernel inside the
          submitted file.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - Accumulate intermediates in float32; both y and residual_out are
          rounded back to the input dtype.

    Forbidden list: torch.nn.functional.layer_norm / torch.layer_norm /
    torch.nn.LayerNorm.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, residual, weight, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().fused_residual_norm(x, residual, weight, bias, self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        x = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        residual = residual.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        w = weight.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        b = bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        residual_out = (x + residual).to(dt)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        z = residual_out.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        mean = z.mean(dim=-1, keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        var = (z - mean).pow(2).mean(dim=-1, keepdim=True)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        rstd = torch.rsqrt(var + self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        y = ((z - mean) * rstd) * w + b
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        y = y.to(dt)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return torch.cat([y, residual_out], dim=-1)
        # <<<END_IMPROVE>>>
