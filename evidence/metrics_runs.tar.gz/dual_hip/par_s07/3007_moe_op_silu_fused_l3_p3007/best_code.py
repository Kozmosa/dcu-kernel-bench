import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3007_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor moe_fused_forward(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, int64_t, int64_t, int64_t, int64_t, int64_t, bool, bool, int64_t, int64_t);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("moe_fused_forward", &moe_fused_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/util/Float8_e4m3fn.h>
#include <c10/util/Float8_e4m3fnuz.h>

__device__ __forceinline__ float read_value(const void* p, int64_t i, int t) {
    switch(t) {
        case 0: return static_cast<const float*>(p)[i];
        case 1: return float(static_cast<const c10::Half*>(p)[i]);
        case 2: return float(static_cast<const c10::BFloat16*>(p)[i]);
        case 3: return float(static_cast<const c10::Float8_e4m3fn*>(p)[i]);
        default: return float(static_cast<const c10::Float8_e4m3fnuz*>(p)[i]);
    }
}
int dtype_code(torch::Tensor t) {
    switch(t.scalar_type()) {
        case at::kFloat: return 0;
        case at::kHalf: return 1;
        case at::kBFloat16: return 2;
        case at::ScalarType::Float8_e4m3fn: return 3;
        case at::ScalarType::Float8_e4m3fnuz: return 4;
        default: TORCH_CHECK(false, "Unsupported dtype");
    }
    return 0;
}

template<bool QUANT, bool WEIGHT, bool DIRECT_FLOAT = false>
__global__ void fused_moe(const void* __restrict__ a, const void* __restrict__ b, const float* __restrict__ as, const float* __restrict__ bs,
                          const void* __restrict__ w, const int64_t* __restrict__ ids, void* __restrict__ out,
                          int64_t R, int N, int K, int tk, int bn, int bk, int abtype, int wt) {
    // Four independent 64-lane reductions per block, with contiguous K loads.
    int lane = threadIdx.x % 64;
    int64_t index = int64_t(blockIdx.x) * 4 + threadIdx.x / 64;
    if(index >= R * N) return;
    int64_t r = index / N;
    int col = index % N;
    int64_t m = r / tk, e = ids[r];
    float gate = 0.0f, up = 0.0f;
    if constexpr (DIRECT_FLOAT && !QUANT) {
        int k = lane;
        for(; k + 64 < K; k += 128) {
            float av0 = static_cast<const float*>(a)[m*K+k];
            float gv0 = static_cast<const float*>(b)[(e*2*N+col)*K+k];
            float uv0 = static_cast<const float*>(b)[(e*2*N+N+col)*K+k];
            float av1 = static_cast<const float*>(a)[m*K+k+64];
            float gv1 = static_cast<const float*>(b)[(e*2*N+col)*K+k+64];
            float uv1 = static_cast<const float*>(b)[(e*2*N+N+col)*K+k+64];
            gate = fmaf(av0, gv0, gate);
            up = fmaf(av0, uv0, up);
            gate = fmaf(av1, gv1, gate);
            up = fmaf(av1, uv1, up);
        }
        if(k < K) {
            float av = static_cast<const float*>(a)[m*K+k];
            float gv = static_cast<const float*>(b)[(e*2*N+col)*K+k];
            float uv = static_cast<const float*>(b)[(e*2*N+N+col)*K+k];
            gate = fmaf(av, gv, gate);
            up = fmaf(av, uv, up);
        }
    } else {
        for(int k = lane; k < K; k += 64) {
            float av, gv, uv;
            if constexpr (DIRECT_FLOAT) {
                av = static_cast<const float*>(a)[m*K+k];
                gv = static_cast<const float*>(b)[(e*2*N+col)*K+k];
                uv = static_cast<const float*>(b)[(e*2*N+N+col)*K+k];
            } else {
                av = read_value(a, m*K+k, abtype);
                gv = read_value(b, (e*2*N+col)*K+k, abtype);
                uv = read_value(b, (e*2*N+N+col)*K+k, abtype);
            }
            if(QUANT) {
                int kb = k/bk, blocks = K/bk;
                av *= as[m*blocks+kb];
                gv *= bs[(e*(2*N/bn)+col/bn)*blocks+kb];
                uv *= bs[(e*(2*N/bn)+(N+col)/bn)*blocks+kb];
            }
            gate = fmaf(av, gv, gate);
            up = fmaf(av, uv, up);
        }
    }
    #pragma unroll
    for(int d = 32; d > 0; d >>= 1) {
        gate += __shfl_down(gate, d, 64);
        up += __shfl_down(up, d, 64);
    }
    if(lane == 0) {
        if(WEIGHT) {
            float rw;
            if constexpr (DIRECT_FLOAT) {
                rw = static_cast<const float*>(w)[r];
            } else {
                rw = read_value(w, r, wt);
            }
            gate *= rw;
            up *= rw;
        }
        float value = (gate / (1.0f + expf(-gate))) * up;
        if(wt == 0) static_cast<float*>(out)[index] = value;
        else if(wt == 1) static_cast<c10::Half*>(out)[index] = c10::Half(value);
        else static_cast<c10::BFloat16*>(out)[index] = c10::BFloat16(value);
    }
}

template<bool WEIGHT>
__global__ void fused_moe_pair(const void* __restrict__ a, const void* __restrict__ b, const float* __restrict__ as, const float* __restrict__ bs,
                             const void* __restrict__ w, const int64_t* __restrict__ ids, void* __restrict__ out,
                             int64_t R, int N, int K, int tk, int bn, int bk, int abtype, int wt) {
    int lane = threadIdx.x % 64;
    int tiles_per_row = (N+3)/4;
    int64_t tile = int64_t(blockIdx.x)*4 + threadIdx.x/64;
    if(tile >= R*tiles_per_row) return;
    int64_t r = tile/tiles_per_row;
    int col = 4*(tile%tiles_per_row);
    int64_t m = r/tk, e = ids[r];
    const float* aa = static_cast<const float*>(a) + m*K;
    const float* gg = static_cast<const float*>(b) + (e*2*N+col)*K;
    const float* uu = gg + int64_t(N)*K;
    float gate[4] = {}, up[4] = {};
    int k = lane;
    for(; k+64 < K; k += 128) {
        float av0 = aa[k], av1 = aa[k+64];
        #pragma unroll
        for(int c = 0; c < 4; ++c) {
            if(col+c < N) {
                gate[c] = fmaf(av0, gg[c*K+k], gate[c]);
                up[c] = fmaf(av0, uu[c*K+k], up[c]);
                gate[c] = fmaf(av1, gg[c*K+k+64], gate[c]);
                up[c] = fmaf(av1, uu[c*K+k+64], up[c]);
            }
        }
    }
    if(k < K) {
        float av = aa[k];
        #pragma unroll
        for(int c = 0; c < 4; ++c) {
            if(col+c < N) {
                gate[c] = fmaf(av, gg[c*K+k], gate[c]);
                up[c] = fmaf(av, uu[c*K+k], up[c]);
            }
        }
    }
    #pragma unroll
    for(int d = 32; d > 0; d >>= 1) {
        #pragma unroll
        for(int c = 0; c < 4; ++c) {
            gate[c] += __shfl_down(gate[c], d, 64);
            up[c] += __shfl_down(up[c], d, 64);
        }
    }
    if(lane == 0) {
        if constexpr (WEIGHT) {
            float rw = static_cast<const float*>(w)[r];
            #pragma unroll
            for(int c = 0; c < 4; ++c) {
                gate[c] *= rw; up[c] *= rw;
            }
        }
        #pragma unroll
        for(int c = 0; c < 4; ++c) {
            if(col+c < N)
                static_cast<float*>(out)[r*N+col+c] = (gate[c]/(1.0f+expf(-gate[c])))*up[c];
        }
    }
}

torch::Tensor moe_fused_forward(torch::Tensor A, torch::Tensor B, torch::Tensor AS, torch::Tensor BS,
                               torch::Tensor W, torch::Tensor ids, int64_t M, int64_t K, int64_t E,
                               int64_t N, int64_t tk, bool weighted, bool quant, int64_t bn, int64_t bk) {
    c10::cuda::CUDAGuard guard(A.device());
    A = A.contiguous(); B = B.contiguous(); W = W.contiguous(); ids = ids.contiguous();
    TORCH_CHECK(A.scalar_type() == B.scalar_type(), "A/B dtype mismatch");
    if(quant) {
        TORCH_CHECK(K % bk == 0 && (2*N) % bn == 0, "Invalid quantization blocks");
        AS = AS.contiguous(); BS = BS.contiguous();
    }
    auto out = torch::empty({M*tk, N}, W.options());
    int atype = dtype_code(A), wtype = dtype_code(W);
    TORCH_CHECK(wtype <= 2, "Unsupported output dtype");
    const float* ap = quant ? AS.data_ptr<float>() : nullptr;
    const float* bp = quant ? BS.data_ptr<float>() : nullptr;
    auto stream = at::cuda::getCurrentCUDAStream();
    dim3 grid((M*tk*N+3)/4), block(256);
    #define LAUNCH(Q,WGT,DF) hipLaunchKernelGGL((fused_moe<Q,WGT,DF>), grid, block, 0, stream, A.data_ptr(), B.data_ptr(), ap, bp, W.data_ptr(), ids.data_ptr<int64_t>(), out.data_ptr(), M*tk, N, K, tk, bn, bk, atype, wtype)
    #define LAUNCH_PAIR(WGT) hipLaunchKernelGGL((fused_moe_pair<WGT>), pair_grid, block, 0, stream, A.data_ptr(), B.data_ptr(), ap, bp, W.data_ptr(), ids.data_ptr<int64_t>(), out.data_ptr(), M*tk, N, K, tk, bn, bk, atype, wtype)
    if(!quant && atype == 0 && wtype == 0 && N >= 2) {
        dim3 pair_grid((M*tk*((N+3)/4)+3)/4);
        if(weighted) { LAUNCH_PAIR(true); } else { LAUNCH_PAIR(false); }
    } else if(quant) {
        if(weighted) { LAUNCH(true,true,false); } else { LAUNCH(true,false,false); }
    } else if(atype == 0 && wtype == 0) {
        if(weighted) { LAUNCH(false,true,true); } else { LAUNCH(false,false,true); }
    } else {
        if(weighted) { LAUNCH(false,true,false); } else { LAUNCH(false,false,false); }
    }
    #undef LAUNCH_PAIR
    #undef LAUNCH
    TORCH_CHECK(hipGetLastError() == hipSuccess, "Fused MoE launch failed");
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    SiLU-and-multiply fused into the epilogue of an MoE (Mixture of Experts)
    single-layer expert FFN grouped GEMM: one kernel performs the grouped matrix
    multiply of tokens against expert weights, the routing weight weighting and
    the SwiGLU-style activation together, so no intermediate activation is
    materialized.

    Operator semantics: given
        A             activations (M, K)
        B             expert weights (E, 2N, K), the transposed weight matrix of
                      the e-th expert
        topk_ids      routing result (M, top_k), elements in [0, E), distinct
                      within a row
        topk_weights  routing weights (M, top_k), always positive within a row,
                      no normalization needed
        and the three scheduling tensors precomputed from topk_ids by the
        upstream alignment operator
        sorted_token_ids / expert_ids / num_tokens_post_padded (see the input
        specification).
    For each token m and its j-th selected expert e = topk_ids[m, j]:
        x[m, j, :] = A[m, :] @ B[e, :, :]^T          in R^{2N}
        if mul_routed_weight = True: x[m, j, :] *= topk_weights[m, j]
        out[m*top_k + j, i] = SiLU(x[m, j, i]) * x[m, j, N + i],  i in [0, N)
    where SiLU(u) = u / (1 + exp(-u)) = u * sigmoid(u). The 2N output dimensions
    of B use the chunked gating layout: the first N rows are gate and the last N
    rows are up (distinct from the interleaved layout). Every row of the output
    (M*top_k, N) is written by exactly one expert (routing guarantees that every
    row has an owner).

    fp8 block-quantized mode: with quant="fp8_block", A / B are float8_e4m3 code
    words taking part in the same math after dequantization:
        A_deq[m, k]  = A[m, k]  * A_scale[m,  k // block_k]
        B_deq[e, j, k] = B[e, j, k] * B_scale[e, j // block_n, k // block_k]
    This mode requires K % block_k == 0 and 2N % block_n == 0 (no scale tail
    block). With quant="dense", A / B are the raw weights and A_scale / B_scale
    are ignored one-element placeholder tensors.

    Boundary behaviour:
      - slots in sorted_token_ids whose value is >= M*top_k are alignment padding
        sentinels: they take no part in the computation and produce no output
        row; expert_ids is valid only inside the first ceil(num_tokens_post_padded
        / block_size_m) blocks (the valid prefix takes values in [0, E), with no
        cross-card -1 sentinel, and the tail holds unconsumed fill values).
      - an expert selected by no token does not read its B rows.
      - the three scheduling tensors and topk_ids are mutually redundant (all
        derived from the same topk_ids); the core scheduling may use either
        information source, but the output must match the math defined above in
        terms of topk_ids.

    Input/output specification:
        A            (M, K)    float16/bfloat16 (e4m3 code words in fp8_block
                               mode)
        B            (E, 2N, K) same as A (e4m3 code words in fp8_block mode)
        A_scale      (M, K//block_k) float32 ((1,) placeholder in dense mode)
        B_scale      (E, 2N//block_n, K//block_k) float32 ((1,) placeholder in
                     dense mode)
        topk_weights (M, top_k) float16/bfloat16, same dtype as the output
        topk_ids     (M, top_k) int64
        sorted_token_ids (M*top_k + E*(block_size_m-1),) int32
        expert_ids   (M*top_k + E,) int32
        num_tokens_post_padded (1,) int32
        out          (M*top_k, N), dtype same as topk_weights.
        M, K, E, top_k, block_size_m >= 1; 2N is even; input magnitudes are the
        usual randn/rand scale with no inf/NaN. The evaluator casts all inputs
        to fp32 before passing them in (integer types restore exactly,
        fp16/bf16/fp8 -> fp32 is lossless), so when topk_weights is fp32 the
        output is fp32 as well.

    Implementation constraints (violations are scored as failures):
      - Core computation (the grouped GEMM, fp8 dequantization, the routing
        weight multiply, the SiLU-and-multiply epilogue) must be done with a
        HIP kernel inside the submitted file, with intermediate accumulation
        always float32 and the output cast back to the dtype of topk_weights.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Materializing the intermediate activation (the 2N-wide GEMM result) to
        device memory and then activating it is forbidden -- the whole point of
        this operator is epilogue fusion, so the activation is done in place
        block by block.

    Disallowed list: torch.matmul / torch.bmm / torch.einsum /
    torch._scaled_mm / torch.nn.functional.silu / torch.SiLU / torch.sigmoid.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, mul_routed_weight=True, quant="dense", block_n=128, block_k=128):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert quant in ("dense", "fp8_block"), "quant must be one of dense / fp8_block"
        assert block_n >= 1 and block_k >= 1, "block_n / block_k must be >= 1"
        self.mul_routed_weight = bool(mul_routed_weight)
        self.quant = quant
        self.block_n = int(block_n)
        self.block_k = int(block_k)
        # <<<END_IMPROVE>>>

    def forward(self, A, B, A_scale, B_scale, topk_weights, topk_ids, sorted_token_ids, expert_ids, num_tokens_post_padded):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        topk_ids = topk_ids.to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        sorted_token_ids = sorted_token_ids.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        expert_ids = expert_ids.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_tokens_post_padded = num_tokens_post_padded.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        M, K = A.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        E, N2, _ = B.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert N2 % 2 == 0, "the 2N output dimension of B must be even"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        N = N2 // 2
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        top_k = topk_ids.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out_dtype = topk_weights.dtype
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _ = (sorted_token_ids, expert_ids, num_tokens_post_padded)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        a = A
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        b = B
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        if self.quant == "fp8_block":
            bk, bn = self.block_k, self.block_n
            assert K % bk == 0 and N2 % bn == 0
            assert A_scale.shape == (M, K // bk), "A_scale shape should be (M, K//block_k)"
            assert B_scale.shape == (E, N2 // bn, K // bk), "B_scale shape should be (E, 2N//block_n, K//block_k)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        tw = topk_weights.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        out = _pyramidkernel_get_extension().moe_fused_forward(a, b, A_scale, B_scale, topk_weights, topk_ids, M, K, E, N, top_k, self.mul_routed_weight, self.quant == "fp8_block", self.block_n, self.block_k)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # The fused HIP epilogue has already produced every output row.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        return out.to(out_dtype)
        # <<<END_IMPROVE>>>
