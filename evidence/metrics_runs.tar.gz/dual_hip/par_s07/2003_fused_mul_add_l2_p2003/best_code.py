import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

torch::Tensor fused_forward(torch::Tensor x, c10::optional<torch::Tensor> a, c10::optional<torch::Tensor> b, float av, float bv);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_forward", &fused_forward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <cstdint>

template <typename T>
struct alignas(sizeof(T) * 2) pair_storage {
    T first;
    T second;
};

template <typename T, int A, int B>
__global__ void fused_kernel(const T* x, const T* a, const T* b,
                             T* out, int64_t n, float av, float bv) {
#pragma clang fp contract(off)
    if constexpr (A == 1) av = static_cast<float>(a[0]);
    if constexpr (B == 1) bv = static_cast<float>(b[0]);

    const int64_t tid = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const int64_t stride = static_cast<int64_t>(blockDim.x) * gridDim.x;

    bool packed_ok = (n >= 2) &&
        ((reinterpret_cast<uintptr_t>(x) % (sizeof(T) * 2)) == 0) &&
        ((reinterpret_cast<uintptr_t>(out) % (sizeof(T) * 2)) == 0);
    if constexpr (A == 2) {
        packed_ok = packed_ok &&
            ((reinterpret_cast<uintptr_t>(a) % (sizeof(T) * 2)) == 0);
    }
    if constexpr (B == 2) {
        packed_ok = packed_ok &&
            ((reinterpret_cast<uintptr_t>(b) % (sizeof(T) * 2)) == 0);
    }

    if (packed_ok) {
        using pair_t = pair_storage<T>;
        const pair_t* xp = reinterpret_cast<const pair_t*>(x);
        pair_t* op = reinterpret_cast<pair_t*>(out);
        const pair_t* ap = reinterpret_cast<const pair_t*>(a);
        const pair_t* bp = reinterpret_cast<const pair_t*>(b);
        const int64_t pairs = n >> 1;
        const int64_t pair_stride = stride;
        for (int64_t p = tid; p < pairs; p += pair_stride) {
            const pair_t xv = xp[p];
            float x0 = static_cast<float>(xv.first);
            float x1 = static_cast<float>(xv.second);
            float a0 = av;
            float a1 = av;
            float b0 = bv;
            float b1 = bv;
            if constexpr (A == 2) {
                const pair_t q = ap[p];
                a0 = static_cast<float>(q.first);
                a1 = static_cast<float>(q.second);
            }
            if constexpr (B == 2) {
                const pair_t q = bp[p];
                b0 = static_cast<float>(q.first);
                b1 = static_cast<float>(q.second);
            }
            float product0 = a0 * x0;
            float product1 = a1 * x1;
            pair_t result;
            result.first = static_cast<T>(product0 + b0);
            result.second = static_cast<T>(product1 + b1);
            op[p] = result;
        }
        if (tid == 0 && (n & 1)) {
            const int64_t i = n - 1;
            float ai = av;
            float bi = bv;
            if constexpr (A == 2) ai = static_cast<float>(a[i]);
            if constexpr (B == 2) bi = static_cast<float>(b[i]);
            float xi = static_cast<float>(x[i]);
            float product = ai * xi;
            out[i] = static_cast<T>(product + bi);
        }
        return;
    }

    for (int64_t i = tid; i < n; i += stride) {
        float ai = av;
        float bi = bv;
        if constexpr (A == 2) ai = static_cast<float>(a[i]);
        if constexpr (B == 2) bi = static_cast<float>(b[i]);
        float xi = static_cast<float>(x[i]);
        float product = ai * xi;
        float result = product + bi;
        out[i] = static_cast<T>(result);
    }
}

#define LAUNCH_MODE(A, B) fused_kernel<scalar_t, A, B><<<blocks, 256, 0, stream>>>(x.data_ptr<scalar_t>(), ap, bp, out.data_ptr<scalar_t>(), n, av, bv)
#define DISPATCH_B(A) do { \
    if (b_mode == 0) { LAUNCH_MODE(A, 0); } \
    else if (b_mode == 1) { LAUNCH_MODE(A, 1); } \
    else { LAUNCH_MODE(A, 2); } \
} while (0)

torch::Tensor fused_forward(torch::Tensor x, c10::optional<torch::Tensor> a,
                           c10::optional<torch::Tensor> b, float av, float bv) {
    c10::cuda::CUDAGuard guard(x.device());
    auto out = torch::empty_like(x);
    int64_t n = x.numel();
    if (n == 0) return out;
    int a_mode = !a.has_value() ? 0 : (a->numel() == 1 ? 1 : 2);
    int b_mode = !b.has_value() ? 0 : (b->numel() == 1 ? 1 : 2);
    auto stream = at::cuda::getCurrentCUDAStream(x.get_device());
    const int64_t needed_blocks = (n + 255) / 256;
    const unsigned int blocks = static_cast<unsigned int>(needed_blocks > 4096 ? 4096 : needed_blocks);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16,
                                   x.scalar_type(), "fused_forward", [&] {
        const scalar_t* ap = a.has_value() ? a->data_ptr<scalar_t>() : nullptr;
        const scalar_t* bp = b.has_value() ? b->data_ptr<scalar_t>() : nullptr;
        if (a_mode == 0) { DISPATCH_B(0); }
        else if (a_mode == 1) { DISPATCH_B(1); }
        else { DISPATCH_B(2); }
    });
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}
#undef DISPATCH_B
#undef LAUNCH_MODE
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Element-wise fused multiply-add: out = a * x + b.

    (1) Operator semantics: for every element i of x,
    out[i] = a_i * x[i] + b_i. a and b each independently take one of the
    following three forms (any combination is allowed, e.g. a a scalar while b is a
    same-shape tensor):
      1. a Python float / int scalar: a_i = a (the value is broadcast to every
         element of x);
      2. a single-element tensor (numel == 1, any shape, e.g. (1,)): a_i = its only
         element (broadcast);
      3. a tensor with the same shape as x (numel == x.numel()): a_i = the
         corresponding element of a.
    x is a floating-point tensor of arbitrary rank and shape (including
    non-powers-of-two and prime sizes). Intermediate computation runs in float32
    (x / a / b are first promoted to float32, then multiplied and added), and the
    final result is cast back to the dtype of x. Boundary behaviour: this operator
    has no integer tensor inputs and no indexing/length-like semantics; when a and
    b are both scalars the output still has the same shape as x.

    (2) Input/output specification:
      - x: float16 / bfloat16 / float32 tensor, arbitrary shape, contiguous;
      - a, b: one of the three forms above; when a tensor, contiguous with the
        same dtype as x;
      - returns: a new tensor with the same shape and dtype as x (out-of-place; no
        input may be overwritten in place).

    (3) Implementation constraints (violations are scored as failures):
      - The core computation (the multiply-add) must be completed inside the
        submitted file with a self-written HIP kernel: a single kernel and a
        single read-compute-write pass; splitting it into a multiply kernel followed
        by an add kernel is forbidden;
      - When a / b is a scalar or a single-element tensor it must take part in the
        kernel as a broadcast argument and must not be materialized into a
        temporary big tensor with the same shape as x;
      - The __init__ and forward signatures of ModelNew must not be changed;
      - Use float32 for intermediate computation; cast the output back to the dtype
        of x.

    (4) Forbidden list and target hardware:
      - Directly completing this task's computation with ATen shortcuts is
        forbidden: torch.addcmul (including the .addcmul / .addcmul_ methods),
        torch.add, torch.mul, and tensor methods with their in-place forms such as
        .add( / .mul( / .add_( / .mul_; calling a same-functionality entry point
        provided by any precompiled operator library is also forbidden (the final
        static audit does substring matching on the code outside
        docstrings/comments);
      - Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        # <<<END_IMPROVE>>>

    def forward(self, x, a, b):
        # <<<IMPROVE:forward_stmt_1>>>
        a_tensor = a if isinstance(a, torch.Tensor) else None
        b_tensor = b if isinstance(b, torch.Tensor) else None
        a_value = 0.0 if a_tensor is not None else float(a)
        b_value = 0.0 if b_tensor is not None else float(b)
        return _pyramidkernel_get_extension().fused_forward(x, a_tensor, b_tensor, a_value, b_value)
        # <<<END_IMPROVE>>>
