import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p2011_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor batchnorm_backward(torch::Tensor dy, torch::Tensor x, torch::Tensor scale, torch::Tensor mean, torch::Tensor inv, bool parameter_only);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("batchnorm_backward", &batchnorm_backward);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <climits>
#include <cstdint>

__device__ void reduce_pair(float a, float b, float* sa, float* sb) {
    int t = threadIdx.x;
    sa[t] = a;
    sb[t] = b;
    __syncthreads();
    for (int d = 128; d; d >>= 1) {
        if (t < d) {
            sa[t] += sa[t + d];
            sb[t] += sb[t + d];
        }
        __syncthreads();
    }
}

template<bool ALIGNED, class T, class I>
__global__ void partial_kernel(const T* dy, const T* x, const float* mean,
                               const float* inv, float* p, I S, I C, I M, I K) {
    I c = I(blockIdx.x) / K;
    I tile = I(blockIdx.x) % K;
    float a = 0.0f;
    float b = 0.0f;
    I base = I(0);
    if (ALIGNED) {
        I j0 = tile * I(1024);
        base = (j0 / S) * C * S + c * S + j0 % S;
    }
    #pragma unroll 4
    for (int k = 0; k < 4; ++k) {
        I j = tile * I(1024) + I(threadIdx.x) + I(k * 256);
        if (j < M) {
            I i;
            if (ALIGNED) {
                i = base + I(threadIdx.x) + I(k * 256);
            } else {
                i = (j / S) * C * S + c * S + j % S;
            }
            float g = float(dy[i]);
            float h = (float(x[i]) - mean[c]) * inv[c];
            a += g * h;
            b += g;
        }
    }
    __shared__ float sa[256], sb[256];
    reduce_pair(a, b, sa, sb);
    if (threadIdx.x == 0) {
        p[c * K + tile] = sa[0];
        p[C * K + c * K + tile] = sb[0];
    }
}

template<class T, class I>
__global__ void sums_kernel(const float* p, float* sums, T* out,
                            I C, I K, bool param) {
    I c = I(blockIdx.x);
    float a = 0.0f;
    float b = 0.0f;
    for (I k = I(threadIdx.x); k < K; k += I(256)) {
        a += p[c * K + k];
        b += p[C * K + c * K + k];
    }
    __shared__ float sa[256], sb[256];
    reduce_pair(a, b, sa, sb);
    if (threadIdx.x == 0) {
        if (param) {
            out[c] = T(sa[0]);
            out[C + c] = T(sb[0]);
        } else {
            sums[c] = sa[0];
            sums[C + c] = sb[0];
        }
    }
}

template<class T, class I>
__global__ void dx_kernel(const T* dy, const T* x, const T* scale,
                          const float* mean, const float* inv,
                          const float* sums, T* out, I S, I C, I M, I total) {
    I i = I(blockIdx.x) * I(256) + I(threadIdx.x);
    if (i < total) {
        I c = (i / S) % C;
        float h = (float(x[i]) - mean[c]) * inv[c];
        float v = (float(M) * float(dy[i]) - sums[C + c]) - h * sums[c];
        out[i] = T((float(scale[c]) * inv[c] / float(M)) * v);
    }
}

template<class I>
__global__ void dx_vector_kernel(const float* dy, const float* x, const float* scale,
                                 const float* mean, const float* inv,
                                 const float* sums, float* out, I S, I C, I M, I total) {
    I q = I(blockIdx.x) * I(256) + I(threadIdx.x);
    if (q < total / I(4)) {
        I i = I(4) * q;
        I c = (i / S) % C;
        float4 g = reinterpret_cast<const float4*>(dy)[q];
        float4 v = reinterpret_cast<const float4*>(x)[q];
        float mu = mean[c], iv = inv[c];
        float a = sums[c], b = sums[C + c];
        float factor = scale[c] * iv / float(M);
        float4 r;
        r.x = factor * ((float(M) * g.x - b) - ((v.x - mu) * iv) * a);
        r.y = factor * ((float(M) * g.y - b) - ((v.y - mu) * iv) * a);
        r.z = factor * ((float(M) * g.z - b) - ((v.z - mu) * iv) * a);
        r.w = factor * ((float(M) * g.w - b) - ((v.w - mu) * iv) * a);
        reinterpret_cast<float4*>(out)[q] = r;
    }
}

torch::Tensor batchnorm_backward(torch::Tensor dy, torch::Tensor x,
                                 torch::Tensor scale, torch::Tensor mean,
                                 torch::Tensor inv, bool parameter_only) {
    c10::cuda::CUDAGuard guard(x.device());
    int64_t C = x.size(1);
    int64_t S = x.size(2) * x.size(3);
    int64_t M = x.size(0) * S;
    int64_t K = (M + 1023) / 1024;
    auto out = parameter_only ? torch::empty({2 * C}, x.options())
                              : torch::empty_like(x);
    auto partial = torch::empty({2 * C * K}, x.options().dtype(torch::kFloat32));
    auto sums = torch::empty({2 * C}, x.options().dtype(torch::kFloat32));
    auto stream = at::cuda::getCurrentCUDAStream();
    bool narrow = x.numel() <= INT_MAX && C * S <= INT_MAX && M <= INT_MAX
                  && C * K <= INT_MAX && 2 * C * K <= INT_MAX
                  && M <= int64_t(INT_MAX) - 1023
                  && K <= int64_t(INT_MAX) - 255
                  && x.numel() <= int64_t(INT_MAX) - 255;
    bool aligned = (S % 1024) == 0;
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,
                                    at::ScalarType::BFloat16,
                                    x.scalar_type(), "bn_backward_hip", [&] {
        auto launch = [&](auto index_tag) {
            using I = decltype(index_tag);
            if (aligned) {
                partial_kernel<true, scalar_t, I><<<C * K, 256, 0, stream>>>(
                    dy.data_ptr<scalar_t>(), x.data_ptr<scalar_t>(),
                    mean.data_ptr<float>(), inv.data_ptr<float>(),
                    partial.data_ptr<float>(), I(S), I(C), I(M), I(K));
            } else {
                partial_kernel<false, scalar_t, I><<<C * K, 256, 0, stream>>>(
                    dy.data_ptr<scalar_t>(), x.data_ptr<scalar_t>(),
                    mean.data_ptr<float>(), inv.data_ptr<float>(),
                    partial.data_ptr<float>(), I(S), I(C), I(M), I(K));
            }
            C10_CUDA_KERNEL_LAUNCH_CHECK();
            sums_kernel<scalar_t, I><<<C, 256, 0, stream>>>(
                partial.data_ptr<float>(), sums.data_ptr<float>(),
                out.data_ptr<scalar_t>(), I(C), I(K), parameter_only);
            C10_CUDA_KERNEL_LAUNCH_CHECK();
            if (!parameter_only) {
                if (x.scalar_type() == at::ScalarType::Float && S % 4 == 0
                    && reinterpret_cast<uintptr_t>(dy.data_ptr()) % 16 == 0
                    && reinterpret_cast<uintptr_t>(x.data_ptr()) % 16 == 0
                    && reinterpret_cast<uintptr_t>(out.data_ptr()) % 16 == 0) {
                    dx_vector_kernel<I><<<(x.numel() / 4 + 255) / 256, 256, 0, stream>>>(
                        dy.data_ptr<float>(), x.data_ptr<float>(),
                        scale.data_ptr<float>(), mean.data_ptr<float>(),
                        inv.data_ptr<float>(), sums.data_ptr<float>(),
                        out.data_ptr<float>(), I(S), I(C), I(M), I(x.numel()));
                } else {
                    dx_kernel<scalar_t, I><<<(x.numel() + 255) / 256, 256, 0, stream>>>(
                        dy.data_ptr<scalar_t>(), x.data_ptr<scalar_t>(),
                        scale.data_ptr<scalar_t>(), mean.data_ptr<float>(),
                        inv.data_ptr<float>(), sums.data_ptr<float>(),
                        out.data_ptr<scalar_t>(), I(S), I(C), I(M), I(x.numel()));
                }
                C10_CUDA_KERNEL_LAUNCH_CHECK();
            }
        };
        if (narrow) {
            launch(int(0));
        } else {
            launch(int64_t(0));
        }
    });
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    BatchNorm training backward: given the upstream gradient dy, the input x of
    the training forward, the saved statistics (saved_mean / saved_inv_variance) and
    the scale parameter, compute the gradients of the normalized forward
        y = scale * xhat + bias,  xhat = (x - saved_mean) * saved_inv_variance
    The __init__ argument variant selects which gradients are returned:
        "dx"           : returns only the data gradient dx, shape (N, C, H, W), same
                         dtype as x;
        "dgamma_dbeta" : returns only the parameter gradients; dgamma and dbeta are
                         each (1, C, 1, 1) and are emitted as a single 1-D tensor
                         (2*C,) following the "one-dimensional concatenation packing
                         protocol": the first C elements are dgamma (flattened in
                         row-major order) and the last C are dbeta.
    Both variants share the same forward signature; the return value is always a
    single tensor (the evaluator compares a single output). Mathematical definition
    (float32 intermediate computation throughout, m = N*H*W elements per channel):
        xhat         = (x - saved_mean) * saved_inv_variance
        dgamma[c]    = sum_{n,h,w} dy * xhat          (summed per channel)
        dbeta[c]     = sum_{n,h,w} dy                 (summed per channel)
        dx           = (scale * saved_inv_variance / m)
                       * (m*dy - dbeta - xhat * dgamma)
    saved_mean / saved_inv_variance are consumed verbatim as the given values: they
    are the statistics saved by the training forward (inv_variance = 1/sqrt(biased
    variance + eps); eps was already absorbed in the forward, and the backward math
    itself contains no eps) and may be any positive numbers unrelated to the true
    statistics of x -- the given values must be used directly, and recomputing the
    statistics from x is forbidden. saved_inv_variance is always positive.

    Input/output specification (NCHW, contiguous):
        dy                 float32 / float16 / bfloat16 (N, C, H, W)
        x                  same dtype as dy (N, C, H, W)
        scale              same dtype as dy (1, C, 1, 1)
        saved_mean         float32 (1, C, 1, 1) (the statistics are always float32,
                           independent of the input dtype)
        saved_inv_variance float32 (1, C, 1, 1), its elements are always positive
        out                single tensor: (N, C, H, W) with the same dtype as dy for
                           dx; (2*C,) with the same dtype as dy for dgamma_dbeta (the
                           first C are dgamma and the last C are dbeta, both computed
                           in float32 and then cast)
        The evaluator casts all inputs to fp32 before passing them in (fp16/bf16 ->
        fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (xhat reconstruction, the two channel reductions, and
          the element-wise chained multiply-add of dx) must be completed inside the
          submitted file with a HIP kernel; a channel reduction of any size (m =
          N*H*W may exceed the capacity of a single block) must be handled correctly
          with mask / tiling (block-wise) reductions, leaving out no element of the
          channel.
        - Computing the gradients through torch.autograd / autograd.grad /
          .backward() is forbidden, as is calling the batch_norm primitive family or
          any closed-source library primitive (MIOpen / hipDNN and the like).
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The reductions and the intermediate computation run in float32; the output
          is cast back to the input dtype; the packing order of dgamma_dbeta is fixed
          as the dgamma segment first and the dbeta segment last.

    Boundary behaviour: N, C, H and W may all be 1 (m may be 1, in which case
    dx = scale * inv_var * (dy - dy*xhat^2)); non-powers of two and unaligned
    dimensions are allowed; the statistics shape is always (1, C, 1, 1); the input
    value range is the usual randn magnitude (no inf/NaN).
    Forbidden: aiter / torch.batch_norm / torch.native_batch_norm /
    torch.nn.functional.batch_norm / F.batch_norm / torch.nn.BatchNorm1d /
    torch.nn.BatchNorm2d / torch.nn.BatchNorm3d /
    torch.ops.aten.batch_norm / torch.ops.aten.native_batch_norm /
    autograd / .backward(.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "dx"):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("dx", "dgamma_dbeta"), "variant must be one of dx / dgamma_dbeta"
        self.variant = variant
        # <<<END_IMPROVE>>>

    def forward(self, dy, x, scale, saved_mean, saved_inv_variance):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().batchnorm_backward(dy, x, scale, saved_mean, saved_inv_variance, self.variant == "dgamma_dbeta")
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        mean = saved_mean.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        inv_var = saved_inv_variance.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        xhat = (xf - mean) * inv_var
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dgamma_c = (dyf * xhat).sum(dim=(0, 2, 3))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        dbeta_c = dyf.sum(dim=(0, 2, 3))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        if self.variant == "dgamma_dbeta":
            # single-tensor packing: the dgamma segment first and the dbeta segment
            # last, each flattened in row-major order
            return torch.cat([dgamma_c.to(x.dtype).reshape(-1),
                              dbeta_c.to(x.dtype).reshape(-1)])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        m = x.shape[0] * x.shape[2] * x.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        scalef = scale.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        dx = (scalef * inv_var / m) * (m * dyf - dbeta_c.reshape_as(scalef)
                                       - xhat * dgamma_c.reshape_as(scalef))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return dx.to(x.dtype)
        # <<<END_IMPROVE>>>
