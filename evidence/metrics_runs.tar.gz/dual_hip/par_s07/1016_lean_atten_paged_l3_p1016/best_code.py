import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1016_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
void paged_attention_out(torch::Tensor q, torch::Tensor k, torch::Tensor v, torch::Tensor tables, torch::Tensor counts, torch::Tensor out, int64_t page, double scale);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("paged_attention_out", &paged_attention_out);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

struct Strides3 { int64_t h, r, d; };
static Strides3 strides3(const torch::Tensor& x) {
    return {x.stride(0), x.stride(1), x.stride(2)};
}

template<typename T, int D>
__global__ void paged_online(const T* q, const T* k, const T* v,
                            const int* tables, const int* counts, T* out,
                            Strides3 qs, Strides3 ks, Strides3 vs, Strides3 os,
                            int64_t th, int64_t tr, int64_t cs, float scale) {
    int lane = threadIdx.x & 63;
    int h = blockIdx.z;
    int b = blockIdx.y;
    int query = b * 16 + blockIdx.x * 4 + threadIdx.x / 64;
    constexpr int N = (D + 63) / 64;
    float qr[N], acc[N];
    #pragma unroll
    for (int t = 0; t < N; ++t) {
        int d = lane + 64*t;
        qr[t] = d < D ? float(q[h*qs.h + query*qs.r + d*qs.d]) : 0.0f;
        acc[t] = 0.0f;
    }
    float m = -INFINITY, l = 0.0f;
    int start = b ? counts[(b-1)*cs] : 0;
    int end = counts[b*cs];
    for (int p = start; p < end; ++p) {
        int physical = tables[h*th + p*tr];
        if constexpr (D == 64) {
            const T* kp = k + int64_t(h)*ks.h + int64_t(physical)*64*ks.r + int64_t(lane)*ks.d;
            const T* vp = v + int64_t(h)*vs.h + int64_t(physical)*64*vs.r + int64_t(lane)*vs.d;
            for (int j = 0; j < 64; j += 4) {
                float kr[4], vr[4];
                #pragma unroll
                for (int s = 0; s < 4; ++s) {
                    kr[s] = float(kp[int64_t(s)*ks.r]);
                    vr[s] = float(vp[int64_t(s)*vs.r]);
                }
                kp += 4*ks.r;
                vp += 4*vs.r;
                #pragma unroll
                for (int s = 0; s < 4; ++s) {
                    float score = 0.0f;
                    score += qr[0] * kr[s];
                    #pragma unroll
                    for (int offset = 32; offset > 0; offset >>= 1)
                        score += __shfl_xor(score, offset, 64);
                    score *= scale;
                    float delta = score - m;
                    float e = __expf(-fabsf(delta));
                    bool raises_max = score > m;
                    float alpha = raises_max ? e : 1.0f;
                    float beta = raises_max ? 1.0f : e;
                    float nm = fmaxf(m, score);
                    l = alpha*l + beta;
                    acc[0] = alpha*acc[0] + beta*vr[s];
                    m = nm;
                }
            }
        } else {
            for (int j = 0; j < 64; ++j) {
                int64_t row = int64_t(physical)*64 + j;
                float score = 0.0f;
                #pragma unroll
                for (int t = 0; t < N; ++t) {
                    int d = lane + 64*t;
                    if (d < D) score += qr[t] * float(k[h*ks.h + row*ks.r + d*ks.d]);
                }
                #pragma unroll
                for (int offset = 32; offset > 0; offset >>= 1)
                    score += __shfl_xor(score, offset, 64);
                score *= scale;
                float delta = score - m;
                float e = __expf(-fabsf(delta));
                bool raises_max = score > m;
                float alpha = raises_max ? e : 1.0f;
                float beta = raises_max ? 1.0f : e;
                float nm = fmaxf(m, score);
                l = alpha*l + beta;
                #pragma unroll
                for (int t = 0; t < N; ++t) {
                    int d = lane + 64*t;
                    if (d < D) acc[t] = alpha*acc[t] + beta*float(v[h*vs.h + row*vs.r + d*vs.d]);
                }
                m = nm;
            }
        }
    }
    #pragma unroll
    for (int t = 0; t < N; ++t) {
        int d = lane + 64*t;
        if (d < D) out[h*os.h + query*os.r + d*os.d] = T(acc[t]/l);
    }
}

template<typename T>
void launch_paged(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                  torch::Tensor tables, torch::Tensor counts, torch::Tensor out, float scale) {
    dim3 grid(4, counts.numel(), q.size(0));
    auto stream = at::cuda::getCurrentCUDAStream();
    #define LAUNCH(D) paged_online<T,D><<<grid,256,0,stream>>>(q.data_ptr<T>(), k.data_ptr<T>(), v.data_ptr<T>(), tables.data_ptr<int>(), counts.data_ptr<int>(), out.data_ptr<T>(), strides3(q), strides3(k), strides3(v), strides3(out), tables.stride(0), tables.stride(1), counts.stride(0), scale)
    switch (q.size(2)) {
        case 16: LAUNCH(16); break;
        case 32: LAUNCH(32); break;
        case 64: LAUNCH(64); break;
        case 128: LAUNCH(128); break;
        case 256: LAUNCH(256); break;
        default: TORCH_CHECK(false, "Unsupported head dimension");
    }
    #undef LAUNCH
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

void paged_attention_out(torch::Tensor q, torch::Tensor k, torch::Tensor v,
                         torch::Tensor tables, torch::Tensor counts, torch::Tensor out,
                         int64_t page, double scale) {
    TORCH_CHECK(q.is_cuda(), "Expected GPU tensors");
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(page == 64, "page_size must be 64");
    TORCH_CHECK(q.dim()==3 && k.dim()==3 && v.dim()==3 && out.dim()==3, "Invalid tensor rank");
    TORCH_CHECK(tables.dim()==2 && counts.dim()==1 && counts.numel()>0, "Invalid paging metadata");
    for (const auto& x : {k, v, tables, counts, out})
        TORCH_CHECK(x.device()==q.device(), "Device mismatch");
    TORCH_CHECK(tables.scalar_type()==at::kInt && counts.scalar_type()==at::kInt, "Paging metadata must be int32");
    TORCH_CHECK(k.scalar_type()==q.scalar_type() && v.scalar_type()==q.scalar_type() && out.scalar_type()==q.scalar_type(), "Dtype mismatch");
    TORCH_CHECK(out.sizes()==q.sizes() && k.sizes()==v.sizes(), "Shape mismatch");
    TORCH_CHECK(q.size(0)==k.size(0) && tables.size(0)==q.size(0) && q.size(2)==k.size(2), "Head mismatch");
    TORCH_CHECK(q.size(1)==counts.numel()*16 && k.size(1)%64==0, "Invalid query or pool length");
    if (q.scalar_type()==at::kHalf)
        launch_paged<at::Half>(q,k,v,tables,counts,out,float(scale));
    else if (q.scalar_type()==at::kBFloat16)
        launch_paged<at::BFloat16>(q,k,v,tables,counts,out,float(scale));
    else if (q.scalar_type()==at::kFloat)
        launch_paged<float>(q,k,v,tables,counts,out,float(scale));
    else TORCH_CHECK(false, "Expected fp16, bf16 or fp32");
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Batched decode attention over a paged KV cache: ragged batch, 16 queries per
    request, one independent physical block table per head, and blocks of the
    physical pool that nothing references are garbage data.

    The KV cache is paged with a fixed page_size: the h-th head slice of k / v
    (shape [total_kv_len, head_size]) is split into total_kv_len / page_size
    physical blocks; the block table of head h, kv_block_tables[h], lists in order
    the physical block ids referenced by each request, where the blocks
    referenced by request b are
      kv_block_tables[h, batch_num_block_n[b-1] : batch_num_block_n[b]]
    (starting at 0 for b=0; batch_num_block_n is the cumulative sum of the
    per-request block counts, and its last element is the total number of used
    blocks total_used_blocks). Physical blocks that no table entry references are
    garbage data and must not take part in the computation.

    Mathematical definition: let s_b be the starting block offset of request b
    (0 for b=0, otherwise s_b = batch_num_block_n[b-1]); its logical KV length is
    L_b = block count * page_size, and logical position j maps to physical row
    row(j) = kv_block_tables[h, s_b + j // page_size] * page_size + j % page_size.
    For every head h and request b (query row range [b*n_ctx_q, (b+1)*n_ctx_q)):
      scores[i, j] = sm_scale * <q[h, b*n_ctx_q+i, :], k[h, row(j), :]>
      p[i, :] = softmax_j(scores[i, :])
      out[h, b*n_ctx_q+i, :] = sum_j p[i, j] * v[h, row(j), :]
    softmax uses a numerically stable (online) implementation, intermediate
    accumulation is in float32, and the output is cast back to the input dtype.
    Boundary behaviour: every request's KV length is a positive integer multiple
    of page_size (a partially filled tail block is outside the task scope), so the
    softmax denominator is always positive; requests and heads do not affect each
    other.

    Input/output specification:
      q                 [num_heads, n_ctx_q * batch, head_size] float16/bfloat16
      k, v              [num_heads, total_kv_len, head_size] same dtype as q (physical block pool)
      kv_block_tables   [num_heads, total_used_blocks] int32 (0-based physical block ids,
                        values < total_kv_len / page_size)
      batch_num_block_n [batch] int32, cumulative sum of the per-request block counts, monotonically increasing
      out               [num_heads, n_ctx_q * batch, head_size] same dtype as q
    Global-domain constraints: head_size in {16, 32, 64, 128, 256}; page_size is
    fixed at 64; n_ctx_q = 16 (the decode form is fixed); each request's KV length
    is a positive integer multiple of page_size and >= page_size;
    num_kv_heads == num_q_heads (MHA, no GQA).

    Implementation constraints (violations are scored as failures):
      - The core computation (paged KV gathering / QK^T / softmax / PV) must be
        done inside the submitted file; calling external attention operator
        libraries such as scaled_dot_product_attention / sdpa / flash_attn, and
        torch.matmul / torch.bmm / torch.mm / torch.baddbmm / torch.einsum /
        torch.softmax (including ATen-equivalent shortcuts such as F.softmax,
        Tensor.matmul and the @ operator) is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast the output back to the
        input dtype.
      - The scheduling strategy (persistent single kernel or a regular grid) is
        free to choose; only semantic correctness and performance are assessed.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: ragged-batch decode, non-quantized fp16/bf16, no causal mask, no
    ALiBi/sliding window, no GQA.
    """
    def __init__(self, head_size: int, page_size: int = 64, sm_scale=0.5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.head_size = int(head_size)
        self.page_size = int(page_size)
        self.sm_scale = float(sm_scale)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, kv_block_tables, batch_num_block_n):
        # <<<IMPROVE:forward_stmt_1>>>
        kv_block_tables = kv_block_tables.to(device=q.device, dtype=torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        batch_num_block_n = batch_num_block_n.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        num_heads, m_total, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        batch = int(batch_num_block_n.numel())
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        n_ctx_q = m_total // batch
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        page = self.page_size
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert num_heads == k.shape[0] == v.shape[0], "the head counts of q/k/v must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert k.shape[1] == v.shape[1], "the KV pool lengths of k/v must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        # Page offsets are generated inside the HIP kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        out = torch.empty_like(q)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        _pyramidkernel_get_extension().paged_attention_out(
            q, k, v, kv_block_tables, batch_num_block_n, out,
            self.page_size, self.sm_scale,
        )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        return out
        # <<<END_IMPROVE>>>
