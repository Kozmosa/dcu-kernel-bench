import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p5003_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor deform_forward(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, bool);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) { m.def("deform_forward", &deform_forward); }
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

 template<class T>
__device__ float corner_load(const T* x, int y, int z, int H, int W) {
    return y >= 0 && y < H && z >= 0 && z < W ? float(x[(int64_t)y*W+z]) : 0.0f;
}
template<class T, bool Mod>
__global__ void sample_kernel(const T* x, const T* off, const T* mask, float* samples,
    int64_t total, int C, int H, int W, int R, int S, int L, int OW,
    int sh, int sw, int ph, int pw, int dh, int dw) {
    int l=blockIdx.x*256+threadIdx.x;
    if (l >= L) return;
    int64_t row=blockIdx.y;
    int G=(C+1)/2;
    int p=row%(R*S);
    int cg=(row/(R*S))%G;
    int n=row/((int64_t)G*R*S);
    int64_t o=((int64_t)n*2*R*S+2*p)*L+l;
    float y=float((l/OW)*sh-ph+(p/S)*dh)+float(off[o]);
    float z=float((l%OW)*sw-pw+(p%S)*dw)+float(off[o+L]);
    int iy=(int)floorf(y), iz=(int)floorf(z);
    float fy=y-iy, fx=z-iz;
    float wa=(1-fy)*(1-fx), wb=(1-fy)*fx;
    float wd=fy*(1-fx), we=fy*fx;
    bool va=iy>=0 && iy<H && iz>=0 && iz<W;
    bool vb=iy>=0 && iy<H && iz+1>=0 && iz+1<W;
    bool vd=iy+1>=0 && iy+1<H && iz>=0 && iz<W;
    bool ve=iy+1>=0 && iy+1<H && iz+1>=0 && iz+1<W;
    float m=1.0f;
    if (Mod) m=float(mask[((int64_t)n*R*S+p)*L+l]);
    #pragma unroll
    for(int j=0;j<2;j++) {
        int c=2*cg+j;
        if(c>=C) continue;
        const T* base=x+((int64_t)n*C+c)*H*W;
        float a=(va?float(base[(int64_t)iy*W+iz]):0.0f)*wa;
        float b=(vb?float(base[(int64_t)iy*W+iz+1]):0.0f)*wb;
        float d=(vd?float(base[((int64_t)iy+1)*W+iz]):0.0f)*wd;
        float e=(ve?float(base[((int64_t)iy+1)*W+iz+1]):0.0f)*we;
        float v=((a+b)+d)+e;
        if (Mod) v *= m;
        samples[(((int64_t)n*C+c)*(R*S)+p)*L+l]=v;
    }
}
template<class T>
__global__ void reduce_kernel(const float* samples, const T* weight, const T* bias, T* out, int D, int L, int K) {
    __shared__ float ws[16][16];
    __shared__ float vs[16][64];
    int t=threadIdx.x, lane=t%64, group=t/64;
    int l=blockIdx.x*64+lane, k0=blockIdx.y*16, n=blockIdx.z;
    float acc[4]={0,0,0,0};
    for(int q=0;q<D;q+=16) {
        int wk=k0+t/16, wd=q+t%16;
        ws[t/16][t%16]=(wk<K && wd<D)?float(weight[(int64_t)wk*D+wd]):0.0f;
        #pragma unroll
        for(int j=0;j<4;j++) {
            int r=group+j*4;
            vs[r][lane]=(q+r<D && l<L)?samples[((int64_t)n*D+q+r)*L+l]:0.0f;
        }
        __syncthreads();
        #pragma unroll
        for(int r=0;r<16;r++) {
            float v=vs[r][lane];
            #pragma unroll
            for(int j=0;j<4;j++) acc[j]=fmaf(ws[group+j*4][r],v,acc[j]);
        }
        __syncthreads();
    }
    #pragma unroll
    for(int j=0;j<4;j++) {
        int k=k0+group+j*4;
        if(k<K && l<L) out[((int64_t)n*K+k)*L+l]=T(acc[j]+float(bias[k]));
    }
}
torch::Tensor deform_forward(torch::Tensor x, torch::Tensor offset, torch::Tensor weight, torch::Tensor bias, torch::Tensor mask,
 int64_t sh, int64_t sw, int64_t ph, int64_t pw, int64_t dh, int64_t dw, bool mod) {
    TORCH_CHECK(x.is_cuda() && x.dim()==4 && weight.dim()==4, "Expected device NCHW tensors");
    c10::cuda::CUDAGuard guard(x.device());
    TORCH_CHECK(sh>0 && sw>0 && dh>0 && dw>0, "Invalid stride or dilation");
    int N=x.size(0), C=x.size(1), H=x.size(2), W=x.size(3);
    int K=weight.size(0), R=weight.size(2), S=weight.size(3);
    int OH=(H+2*ph-dh*(R-1)-1)/sh+1, OW=(W+2*pw-dw*(S-1)-1)/sw+1;
    TORCH_CHECK(OH>0 && OW>0 && weight.size(1)==C, "Invalid dimensions");
    TORCH_CHECK(offset.sizes()==at::IntArrayRef({N,2*R*S,OH,OW}) && mask.sizes()==at::IntArrayRef({N,R*S,OH,OW}) && bias.numel()==K, "Invalid offset, mask or bias shape");
    for(const auto& v : {x,offset,weight,bias,mask}) {
        TORCH_CHECK(v.device()==x.device() && v.scalar_type()==x.scalar_type() && v.is_contiguous(), "Tensor layout or type mismatch");
    }
    int D=C*R*S, L=OH*OW;
    auto samples=torch::empty({N,D,L},x.options().dtype(torch::kFloat32));
    auto out=torch::empty({N,K,OH,OW},x.options());
    auto stream=at::cuda::getCurrentCUDAStream();
    int64_t total=(int64_t)N*D*L;
    if(N==0 || K==0) return out;
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half,at::ScalarType::BFloat16,x.scalar_type(),"deform_forward",[&] {
        if(total) {
            if(mod) {
                sample_kernel<scalar_t,true><<<dim3((L+255)/256,N*((C+1)/2)*R*S),256,0,stream>>>(x.data_ptr<scalar_t>(),offset.data_ptr<scalar_t>(),mask.data_ptr<scalar_t>(),samples.data_ptr<float>(),total,C,H,W,R,S,L,OW,sh,sw,ph,pw,dh,dw);
            } else {
                sample_kernel<scalar_t,false><<<dim3((L+255)/256,N*((C+1)/2)*R*S),256,0,stream>>>(x.data_ptr<scalar_t>(),offset.data_ptr<scalar_t>(),mask.data_ptr<scalar_t>(),samples.data_ptr<float>(),total,C,H,W,R,S,L,OW,sh,sw,ph,pw,dh,dw);
            }
            C10_CUDA_KERNEL_LAUNCH_CHECK();
        }
        reduce_kernel<scalar_t><<<dim3((L+63)/64,(K+15)/16,N),256,0,stream>>>(samples.data_ptr<float>(),weight.data_ptr<scalar_t>(),bias.data_ptr<scalar_t>(),out.data_ptr<scalar_t>(),D,L,K);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    });
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Deformable 2D convolution forward (Deformable Convolution): sampling grid
    plus a handwritten bilinear interpolation.

    Semantics (NCHW, all intermediate computation in float32):
      For each output position (oi, oj) and kernel position p = i*S + j
      (i in [0,R), j in [0,S), row-major), the base sampling coordinate given by
      the regular convolutional receptive field is
          y0 = oi * stride_h + i * dilation_h - padding_h
          x0 = oj * stride_w + j * dilation_w - padding_w
      After adding the per-(output position x kernel position) offsets, the
      input map is sampled at real-valued coordinates with bilinear
      interpolation:
          yc = y0 + offset[n, 2*p,     oi, oj]     # even channel = y offset
          xc = x0 + offset[n, 2*p + 1, oi, oj]     # odd channel = x offset
          v(n, c, p, oi, oj) = bilinear(input map, yc, xc)
      The __init__ parameter variant selects one of the two paths:
          "modulated" (default, modulated form): the sampled value is
              additionally multiplied by the per-position modulation mask
              v *= mask[n, p, oi, oj]
          "plain" (mask-free form): mask does not take part in the computation
              (its contents are arbitrary, possibly garbage data).
      The output is a single tensor:
          out[n, k, oi, oj] = bias[k]
                              + sum_{c, p} v(n, c, p, oi, oj) * weight[k, c, i, j]
      After the computation it is cast back to the input dtype.

    Bilinear interpolation definition (point-wise identical to mainstream
    deformable convolution operators):
      Let iy = floor(yc), ix = floor(xc), wy = yc - iy, wx = xc - ix, and take
      the four corners (iy, ix), (iy, ix+1), (iy+1, ix), (iy+1, ix+1) with
      weights (1-wy)(1-wx), (1-wy)wx, wy(1-wx), wy*wx respectively; when either
      the row or the column of a corner is out of range (< 0 or > dim-1) that
      corner contributes 0 while the remaining corners are weighted as usual --
      i.e. zero-fill semantics: a partially out-of-range coordinate is still
      weighted by the remaining valid corners, and when it is entirely out of
      range (yc <= -1, outside the yc >= H-1 boundary band, etc.) the sampled
      value is 0. No clamp / nearest-neighbour pull-back is done anywhere.

    Input/output specification (all tensors contiguous, NCHW layout):
      x        float32 / float16 / bfloat16 (N, C, H, W)
      offset   same dtype as x (N, 2*R*S, H_out, W_out): 2 channels per kernel
               position (even channel = y offset, odd channel = x offset,
               p = i*S + j row-major)
      weight   same dtype as x (K, C, R, S)
      bias     same dtype as x (K,)
      mask     same dtype as x (N, R*S, H_out, W_out) (ignored when
               variant="plain")
      out      a single tensor, same dtype as x (N, K, H_out, W_out)
      H_out = (H + 2*padding_h - dilation_h*(R-1) - 1) // stride_h + 1, likewise
      for W_out. The evaluator casts all inputs to fp32 before the call
      (low-precision inputs are lossless).

    Implementation constraints (violations are scored as failures):
      - The core computation (sampling-grid construction, bilinear-interpolation
        sampling, mask modulation, the weighted reduction against weight) must
        be handwritten with a HIP kernel inside the submitted file.
      - forward returns the single tensor out (the evaluator compares a single
        output).
      - Interpolation and the weighted reduction are computed in float32, with
        the output cast back to the input dtype.
      - The __init__ and forward signatures of ModelNew must not be changed.

    Forbidden (static audit strips docstrings and comments, then does literal
    substring matching):
    torchvision (including torchvision.ops.deform_conv2d) /
    torch.nn.functional.conv2d (F.conv2d) / torch.nn.Conv2d /
    torch.nn.functional.grid_sample (F.grid_sample) /
    torch.nn.functional.unfold (F.unfold) / torch.matmul / torch.bmm /
    torch.mm / torch.einsum / torch.tensordot / miopen / hipdnn / aiter.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "modulated", stride=(1, 1), padding=(1, 1), dilation=(1, 1)):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("modulated", "plain"), "variant must be either modulated or plain"
        self.variant = variant
        self.stride = (int(stride[0]), int(stride[1]))
        self.padding = (int(padding[0]), int(padding[1]))
        self.dilation = (int(dilation[0]), int(dilation[1]))
        # <<<END_IMPROVE>>>

    def forward(self, x, offset, weight, bias, mask):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().deform_forward(x, offset, weight, bias, mask, self.stride[0], self.stride[1], self.padding[0], self.padding[1], self.dilation[0], self.dilation[1], self.variant == 'modulated')
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        k_out = weight.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        r, s = weight.shape[2], weight.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        sh, sw = self.stride
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        ph, pw = self.padding
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        dh, dw = self.dilation
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        h_out = (h + 2 * ph - (dh * (r - 1) + 1)) // sh + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        w_out = (w + 2 * pw - (dw * (s - 1) + 1)) // sw + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert offset.shape[1] == 2 * r * s and mask.shape[1] == r * s, \
            "the channel counts of offset/mask must be 2*R*S / R*S"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert offset.shape[2] == h_out and offset.shape[3] == w_out \
            and mask.shape[2] == h_out and mask.shape[3] == w_out, \
            "the spatial sizes of offset/mask must be (H_out, W_out)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        off = offset.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        wf = weight.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        bf = bias.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        dev = xf.device
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        base_y = (torch.arange(h_out, dtype=torch.float32, device=dev) * sh - ph).view(1, 1, h_out, 1) \
            + torch.arange(r, dtype=torch.float32, device=dev).view(r, 1, 1, 1) * dh
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        base_x = (torch.arange(w_out, dtype=torch.float32, device=dev) * sw - pw).view(1, 1, 1, w_out) \
            + torch.arange(s, dtype=torch.float32, device=dev).view(1, s, 1, 1) * dw
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        y_coord = (base_y + off[:, 0::2].reshape(n, r, s, h_out, w_out))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        x_coord = (base_x + off[:, 1::2].reshape(n, r, s, h_out, w_out))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        y_coord = y_coord.reshape(n, r * s, h_out, w_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        x_coord = x_coord.reshape(n, r * s, h_out, w_out)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        iy0 = torch.floor(y_coord).to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        ix0 = torch.floor(x_coord).to(torch.long)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        wy = y_coord - iy0.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        wx = x_coord - ix0.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_26>>>
        iy1 = iy0 + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_27>>>
        ix1 = ix0 + 1
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_28>>>
        n_idx = torch.arange(n, device=xf.device).view(n, 1, 1, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_29>>>
        c_idx = torch.arange(c, device=xf.device).view(1, c, 1, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_30>>>
        def corner(iy, ix, wgt):
            # Single-corner sampling: the weight of an out-of-range corner is
            # set to 0; clamp only guards the index (cancelled by the times-0)
            valid = ((iy >= 0) & (iy <= h - 1) & (ix >= 0) & (ix <= w - 1)).to(torch.float32)
            vals = xf[n_idx, c_idx, iy.clamp(0, h - 1).unsqueeze(1),
                      ix.clamp(0, w - 1).unsqueeze(1)]
            return vals * valid.unsqueeze(1) * wgt.unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_31>>>
        sampled = (corner(iy0, ix0, (1.0 - wy) * (1.0 - wx))
                   + corner(iy0, ix1, (1.0 - wy) * wx)
                   + corner(iy1, ix0, wy * (1.0 - wx))
                   + corner(iy1, ix1, wy * wx))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_32>>>
        if self.variant == "modulated":
            sampled = sampled * mask.to(torch.float32).unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_33>>>
        raise RuntimeError('Inactive baseline path')
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_34>>>
        y = y + bf.view(1, k_out, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_35>>>
        return y.view(n, k_out, h_out, w_out).to(x.dtype)
        # <<<END_IMPROVE>>>
