import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1030_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <cstdint>

torch::Tensor unified_attention(torch::Tensor query, torch::Tensor key_cache,
    torch::Tensor value_cache, torch::Tensor block_tables, torch::Tensor seq_lens,
    torch::Tensor cu_seqlens_q, torch::Tensor sinks, double scale,
    int64_t sliding_window, double softcap, bool use_sinks);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("unified_attention", &unified_attention);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/hip/HIPStream.h>
#include <c10/hip/HIPGuard.h>
#include <ATen/Dispatch.h>
#include <ATen/AccumulateType.h>
#include <cmath>
#include <cstdint>

static __device__ __forceinline__ int64_t read_meta(const void* p, int kind, int64_t i) {
    if (kind == 0) return static_cast<int64_t>(reinterpret_cast<const int32_t*>(p)[i]);
    if (kind == 1) return static_cast<int64_t>(reinterpret_cast<const int64_t*>(p)[i]);
    return static_cast<int64_t>(reinterpret_cast<const float*>(p)[i]);
}

template <typename scalar_t>
__global__ void unified_attention_kernel(
    const scalar_t* __restrict__ q,
    const scalar_t* __restrict__ kcache,
    const scalar_t* __restrict__ vcache,
    const void* __restrict__ tables,
    const void* __restrict__ seqlens,
    const void* __restrict__ cuq,
    const scalar_t* __restrict__ sinks,
    scalar_t* __restrict__ out,
    int table_kind, int seqlen_kind, int cuq_kind,
    int total_q, int num_seqs, int num_q_heads, int num_kv_heads,
    int head_size, int block_size, int max_blocks,
    float scale, int sliding_window, float softcap, bool use_sinks) {
    int row = static_cast<int>(blockIdx.x);
    int head = static_cast<int>(blockIdx.y);
    if (row >= total_q || head >= num_q_heads) return;
    __shared__ float shared_max;
    __shared__ float shared_denom;
    __shared__ float cached_weights[64];
    __shared__ int64_t cached_offsets[64];

    int lo = 0;
    int hi = num_seqs;
    while (lo < hi) {
        int mid = (lo + hi) >> 1;
        int64_t end = read_meta(cuq, cuq_kind, mid + 1);
        if (end <= row) lo = mid + 1;
        else hi = mid;
    }
    int seq = lo;
    if (seq >= num_seqs) return;
    int64_t seq_start = read_meta(cuq, cuq_kind, seq);
    int64_t seq_end = read_meta(cuq, cuq_kind, seq + 1);
    int q_len = static_cast<int>(seq_end - seq_start);
    int kv_len = static_cast<int>(read_meta(seqlens, seqlen_kind, seq));
    int i = row - static_cast<int>(seq_start);
    int t = kv_len - q_len + i;
    int first = 0;
    if (sliding_window > 0) first = max(0, t - sliding_window + 1);
    int last = min(t, kv_len - 1);
    bool cache_weights = last - first + 1 <= 64;
    int group = num_q_heads / num_kv_heads;
    int kv_head = head / group;

    if (cache_weights) {
        for (int u = threadIdx.x; u < last - first + 1; u += blockDim.x) {
            int j = first + u;
            int block = static_cast<int>(read_meta(tables, table_kind,
                static_cast<int64_t>(seq) * max_blocks + j / block_size));
            int slot = j % block_size;
            int64_t offset = (((int64_t)block * block_size + slot) * num_kv_heads + kv_head) * head_size;
            cached_offsets[u] = offset;
            const scalar_t* kp = kcache + offset;
            const scalar_t* qp = q + ((int64_t)row * num_q_heads + head) * head_size;
            float dot = 0.0f;
            for (int d = 0; d < head_size; ++d) dot += static_cast<float>(qp[d]) * static_cast<float>(kp[d]);
            float z = dot * scale;
            if (softcap > 0.0f) z = softcap * tanhf(z / softcap);
            cached_weights[u] = z;
        }
    }
    __syncthreads();

    if (cache_weights) {
        if (threadIdx.x < warpSize) {
            int lane = threadIdx.x;
            int count = last - first + 1;
            float z0 = lane < count ? cached_weights[lane] : -INFINITY;
            int u1 = lane + warpSize;
            float z1 = u1 < count ? cached_weights[u1] : -INFINITY;
            float sink = -INFINITY;
            if (lane == 0 && use_sinks) {
                sink = static_cast<float>(sinks[head]);
                if (softcap > 0.0f) sink = softcap * tanhf(sink / softcap);
            }
            float m = fmaxf(fmaxf(z0, z1), sink);
            for (int offset = warpSize / 2; offset > 0; offset >>= 1)
                m = fmaxf(m, __shfl_xor(m, offset, warpSize));
            float w0 = lane < count ? expf(z0 - m) : 0.0f;
            float w1 = u1 < count ? expf(z1 - m) : 0.0f;
            float denom = w0 + w1;
            if (lane == 0 && use_sinks) denom += expf(sink - m);
            for (int offset = warpSize / 2; offset > 0; offset >>= 1)
                denom += __shfl_xor(denom, offset, warpSize);
            if (lane < count) cached_weights[lane] = w0 / denom;
            if (u1 < count) cached_weights[u1] = w1 / denom;
            if (lane == 0) {
                shared_max = m;
                shared_denom = denom;
            }
        }
    } else if (threadIdx.x == 0) {
        float m = -INFINITY;
        if (use_sinks) {
            float z = static_cast<float>(sinks[head]);
            if (softcap > 0.0f) z = softcap * tanhf(z / softcap);
            m = z;
        }
        for (int j = first; j <= last; ++j) {
            float z;
            if (cache_weights) {
                z = cached_weights[j - first];
            } else {
                int block = static_cast<int>(read_meta(tables, table_kind,
                    static_cast<int64_t>(seq) * max_blocks + j / block_size));
                int slot = j % block_size;
                const scalar_t* kp = kcache + (((int64_t)block * block_size + slot) * num_kv_heads + kv_head) * head_size;
                const scalar_t* qp = q + ((int64_t)row * num_q_heads + head) * head_size;
                float dot = 0.0f;
                for (int d = 0; d < head_size; ++d) dot += static_cast<float>(qp[d]) * static_cast<float>(kp[d]);
                z = dot * scale;
                if (softcap > 0.0f) z = softcap * tanhf(z / softcap);
            }
            if (z > m) m = z;
        }
        shared_max = m;
        __threadfence_block();
        float denom = 0.0f;
        if (use_sinks) {
            float z = static_cast<float>(sinks[head]);
            if (softcap > 0.0f) z = softcap * tanhf(z / softcap);
            denom += expf(z - m);
        }
        for (int j = first; j <= last; ++j) {
            float z;
            if (cache_weights) {
                z = cached_weights[j - first];
            } else {
                int block = static_cast<int>(read_meta(tables, table_kind,
                    static_cast<int64_t>(seq) * max_blocks + j / block_size));
                int slot = j % block_size;
                const scalar_t* kp = kcache + (((int64_t)block * block_size + slot) * num_kv_heads + kv_head) * head_size;
                const scalar_t* qp = q + ((int64_t)row * num_q_heads + head) * head_size;
                float dot = 0.0f;
                for (int d = 0; d < head_size; ++d) dot += static_cast<float>(qp[d]) * static_cast<float>(kp[d]);
                z = dot * scale;
                if (softcap > 0.0f) z = softcap * tanhf(z / softcap);
            }
            float weight = expf(z - m);
            if (cache_weights) cached_weights[j - first] = weight;
            denom += weight;
        }
        shared_denom = denom;
        if (cache_weights) {
            for (int j = first; j <= last; ++j) cached_weights[j - first] /= denom;
        }
    }
    __syncthreads();

    const scalar_t* qp = q + ((int64_t)row * num_q_heads + head) * head_size;
    for (int d = threadIdx.x; d < head_size; d += blockDim.x) {
        float acc = 0.0f;
        for (int j = first; j <= last; ++j) {
            int64_t offset;
            if (cache_weights) {
                offset = cached_offsets[j - first];
            } else {
                int block = static_cast<int>(read_meta(tables, table_kind,
                    static_cast<int64_t>(seq) * max_blocks + j / block_size));
                int slot = j % block_size;
                offset = (((int64_t)block * block_size + slot) * num_kv_heads + kv_head) * head_size;
            }
            const scalar_t* vp = vcache + offset;
            float w;
            if (cache_weights) {
                w = cached_weights[j - first];
            } else {
                const scalar_t* kp = kcache + offset;
                float dot = 0.0f;
                for (int kd = 0; kd < head_size; ++kd) dot += static_cast<float>(qp[kd]) * static_cast<float>(kp[kd]);
                float z = dot * scale;
                if (softcap > 0.0f) z = softcap * tanhf(z / softcap);
                w = expf(z - shared_max) / shared_denom;
            }
            acc += w * static_cast<float>(vp[d]);
        }
        out[((int64_t)row * num_q_heads + head) * head_size + d] = static_cast<scalar_t>(acc);
    }
}

template <typename scalar_t>
static void launch_unified_attention(
    const torch::Tensor& query, const torch::Tensor& key_cache,
    const torch::Tensor& value_cache, const torch::Tensor& block_tables,
    const torch::Tensor& seq_lens, const torch::Tensor& cu_seqlens_q,
    const torch::Tensor& sinks, torch::Tensor& out,
    float scale, int sliding_window, float softcap, bool use_sinks) {
    int table_kind = block_tables.scalar_type() == at::kInt ? 0 : (block_tables.scalar_type() == at::kLong ? 1 : 2);
    int seqlen_kind = seq_lens.scalar_type() == at::kInt ? 0 : (seq_lens.scalar_type() == at::kLong ? 1 : 2);
    int cuq_kind = cu_seqlens_q.scalar_type() == at::kInt ? 0 : (cu_seqlens_q.scalar_type() == at::kLong ? 1 : 2);
    int total_q = query.size(0);
    if (total_q == 0) return;
    dim3 grid(total_q, query.size(1));
    dim3 block(256);
    hipStream_t stream = c10::hip::getCurrentHIPStream().stream();
    hipLaunchKernelGGL(unified_attention_kernel<scalar_t>, grid, block, 0, stream,
        query.data_ptr<scalar_t>(), key_cache.data_ptr<scalar_t>(), value_cache.data_ptr<scalar_t>(),
        block_tables.data_ptr(), seq_lens.data_ptr(), cu_seqlens_q.data_ptr(),
        use_sinks ? sinks.data_ptr<scalar_t>() : nullptr,
        out.data_ptr<scalar_t>(), table_kind, seqlen_kind, cuq_kind, total_q, seq_lens.size(0),
        query.size(1), key_cache.size(2), query.size(2), key_cache.size(1), block_tables.size(1),
        scale, sliding_window, softcap, use_sinks);
    TORCH_CHECK(hipGetLastError() == hipSuccess, "unified attention kernel launch failed");
}

torch::Tensor unified_attention(
    torch::Tensor query, torch::Tensor key_cache, torch::Tensor value_cache,
    torch::Tensor block_tables, torch::Tensor seq_lens, torch::Tensor cu_seqlens_q,
    torch::Tensor sinks, double scale, int64_t sliding_window, double softcap, bool use_sinks) {
    TORCH_CHECK(query.device().is_cuda(), "attention tensors must be on the accelerator");
    c10::hip::HIPGuard guard(query.get_device());
    TORCH_CHECK(query.is_contiguous() && key_cache.is_contiguous() && value_cache.is_contiguous(), "attention tensors must be contiguous");
    TORCH_CHECK(key_cache.device() == query.device() && value_cache.device() == query.device(), "Q/K/V device mismatch");
    TORCH_CHECK(query.scalar_type() == key_cache.scalar_type() && query.scalar_type() == value_cache.scalar_type(), "Q/K/V dtype mismatch");
    TORCH_CHECK(query.size(1) % key_cache.size(2) == 0, "query heads must divide evenly into KV heads");
    for (const auto& meta : {block_tables, seq_lens, cu_seqlens_q}) {
        TORCH_CHECK(meta.scalar_type() == at::kInt || meta.scalar_type() == at::kLong || meta.scalar_type() == at::kFloat,
                    "metadata must be int32, int64, or float32");
        TORCH_CHECK(meta.is_contiguous() && meta.device() == query.device(), "metadata must be contiguous and on the query device");
    }
    if (use_sinks) {
        TORCH_CHECK(sinks.scalar_type() == query.scalar_type() && sinks.device() == query.device() && sinks.is_contiguous(), "sink dtype/device/layout mismatch");
    }
    auto out = torch::empty_like(query);
    AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16, query.scalar_type(), "unified_attention", [&] {
        launch_unified_attention<scalar_t>(query, key_cache, value_cache, block_tables, seq_lens, cu_seqlens_q, sinks, out,
            static_cast<float>(scale), static_cast<int>(sliding_window), static_cast<float>(softcap), use_sinks);
    });
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Unified variable-length attention: paged attention with prefill and decode sequences mixed.

    The num_seqs sequences in the batch share one packed query tensor: the
    queries of sequence s are stored contiguously in the row range
    [cu_seqlens_q[s], cu_seqlens_q[s+1]), q_s = cu_seqlens_q[s+1] -
    cu_seqlens_q[s] rows in total (q_s == 1 is a decode sequence, q_s > 1 is a
    prefill sequence, and the two may be mixed arbitrarily within the batch); the
    KV length of that sequence is kv_s = seq_lens[s], and kv_s >= q_s is
    guaranteed. The KV is not stored contiguously but addressed page-wise: the
    physical address of logical token position j (0 <= j < kv_s) is
      key_cache[block_tables[s, j // block_size], j % block_size, g, :]
      value_cache[block_tables[s, j // block_size], j % block_size, g, :]
    where g is the KV head index. Slots in the physical block pool that are not
    referenced are garbage data and must not participate in the computation; only
    the first ceil(kv_s / block_size) entries of each row of block_tables are
    valid.

    For the i-th query of sequence s (0 <= i < q_s, with in-KV-sequence absolute
    position T = kv_s - q_s + i and row index r = cu_seqlens_q[s] + i) and query
    head h (the corresponding KV head is g = h // query_group_size,
    query_group_size = num_q_heads // num_kv_heads):
      logits[j] = scale * <query[r, h, :], K_phys(j, g, :)>
                  scale defaults to 1 / sqrt(head_size)
      visibility (causal, query right-aligned against the KV): j <= T; if
      sliding_window > 0, additionally T - j < sliding_window (the left window edge)
      if use_sinks=True: one extra virtual sink column is introduced whose logit
      is always sinks[h] and whose value is always the zero vector, and which is
      never masked
      if softcap > 0: all logits (including the sink column) first go through
      c * tanh(logit / c) (c = softcap), and only then the mask and the softmax
      p = softmax(visible logits)
      out[r, h, :] = sum_j p[j] * V_phys(j, g, :)   (the sink column contributes the zero vector)
    The causal right alignment guarantees that every query sees at least its own
    position, so the softmax denominator is always > 0.

    Input/output specification (evaluation dtype is float16 / bfloat16, all
    tensors contiguous):
      query         eval dtype (total_q, num_q_heads, head_size)
                    total_q = cu_seqlens_q[-1]
      key_cache     eval dtype (num_blocks, block_size, num_kv_heads, head_size)
      value_cache   eval dtype, same shape as key_cache
      block_tables  int32 (num_seqs, max_blocks_per_seq) logical block -> physical block id
      seq_lens      int32 (num_seqs) valid KV length kv_s of each sequence (>= q_s)
      cu_seqlens_q  int32 (num_seqs + 1) prefix sum of the query lengths, first element 0
      sinks         eval dtype (num_q_heads) per-head sink logit
                    (ignored when use_sinks=False)
      returns out   eval dtype (total_q, num_q_heads, head_size), aligned with the query rows

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / softmax / PV) must be completed inside the
        submitted file; calling scaled_dot_product_attention / sdpa / flash_attn /
        flex_attention / aiter / torch.matmul / torch.bmm / torch.einsum /
        torch.softmax is forbidden.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; the output is cast back to the
        input dtype.
      - The evaluator casts every input tensor to fp32 before calling forward;
        block table ids, sequence lengths and the position prefix sums are small
        integers that fp32 represents exactly, so .to(torch.int32) /
        .to(torch.long) at the entry recovers them losslessly.

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: paged KV + prefill/decode mixed ragged batch + GQA + causal right
    alignment + sliding window + logit softcap + attention sinks; no ALiBi, no
    query-query bias, no multimodal bidirectional prefix, no fp8 quantized KV with
    dequantization scales -- those variants are left as separate follow-up tasks.
    """
    def __init__(self, head_size: int, sliding_window: int = 0, softcap: float = 0.0, use_sinks: bool = True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.scale = 1.0 / math.sqrt(head_size)
        self.sliding_window = int(sliding_window)
        self.softcap = float(softcap)
        self.use_sinks = bool(use_sinks)
        # <<<END_IMPROVE>>>

    def forward(self, query, key_cache, value_cache, block_tables, seq_lens, cu_seqlens_q, sinks):
        # <<<IMPROVE:forward_stmt_1>>>
        return _pyramidkernel_get_extension().unified_attention(
                    query, key_cache, value_cache, block_tables, seq_lens, cu_seqlens_q,
                    sinks, self.scale, self.sliding_window, self.softcap, self.use_sinks,
                )
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        seq_lens = seq_lens.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        cu_seqlens_q = cu_seqlens_q.to(torch.int32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        num_seqs = seq_lens.shape[0]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        block_size = key_cache.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        num_kv_heads = key_cache.shape[2]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        head_size = key_cache.shape[3]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        num_q_heads = query.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        group = num_q_heads // num_kv_heads
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        assert num_q_heads == num_kv_heads * group, \
            "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        outputs = []
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        for s in range(num_seqs):
            start = int(cu_seqlens_q[s])
            q_len = int(cu_seqlens_q[s + 1]) - start
            kv_len = int(seq_lens[s])

            q = query[start:start + q_len].to(torch.float32) * self.scale

            # Collect this sequence's K/V through the block table:
            # [nblk, bs, H_KV, D] -> [kv_len, H_KV, D]
            num_kv_blocks = (kv_len + block_size - 1) // block_size
            physical = block_tables[s, :num_kv_blocks]
            k = key_cache[physical].reshape(
                num_kv_blocks * block_size, num_kv_heads, head_size
            )[:kv_len].to(torch.float32)
            v = value_cache[physical].reshape(
                num_kv_blocks * block_size, num_kv_heads, head_size
            )[:kv_len].to(torch.float32)

            # GQA: the K/V of one KV head are replicated to every query head in the group
            if group > 1:
                k = k.repeat_interleave(group, dim=1)   # [kv_len, H_Q, D]
                v = v.repeat_interleave(group, dim=1)

            attn = torch.einsum("qhd,khd->hqk", q, k)   # [H_Q, q_len, kv_len]

            if self.use_sinks:
                # sink column: the logit is always sinks[h], the value is always the zero vector
                sink_logits = sinks[:num_q_heads].to(torch.float32)[:, None, None]
                sink_logits = sink_logits.expand(-1, q_len, 1)
                attn = torch.cat([sink_logits, attn], dim=-1)
                v = torch.cat([torch.zeros(1, num_q_heads, head_size,
                                           dtype=v.dtype, device=v.device),
                               v], dim=0)

            # causal mask (query right-aligned against the KV): j - i >
            # kv_len - q_len is invisible
            mask = torch.triu(torch.ones(q_len, kv_len, dtype=torch.bool,
                                         device=attn.device),
                              diagonal=kv_len - q_len + 1)
            if self.sliding_window > 0:
                sw_mask = ~torch.triu(
                    torch.ones(q_len, kv_len, dtype=torch.bool,
                               device=attn.device),
                    diagonal=kv_len - (q_len + self.sliding_window) + 1)
                mask = mask | sw_mask
            if self.softcap > 0:
                attn = self.softcap * torch.tanh(attn / self.softcap)
            if self.use_sinks:
                mask = torch.cat([torch.zeros(q_len, 1, dtype=torch.bool,
                                              device=mask.device), mask], dim=-1)

            attn = attn.masked_fill(mask, float("-inf"))
            attn = torch.softmax(attn, dim=-1)
            outputs.append(torch.einsum("hqk,khd->qhd", attn, v))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        return torch.cat(outputs, dim=0).to(query.dtype)
        # <<<END_IMPROVE>>>
