import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p3009_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>

at::Tensor routing(const at::Tensor& x, const at::Tensor& w, bool fused);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("routing", &routing, "Fused sigmoid top-1 MoE routing");
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/hip/HIPStream.h>
#include <c10/core/DeviceGuard.h>
#include <cmath>
#include <cstdint>
#include <type_traits>

namespace {

template <typename scalar_t, bool VectorLoads>
__global__ void routing_kernel(const scalar_t* __restrict__ x,
                               const scalar_t* __restrict__ w,
                               float* __restrict__ out,
                               int M, int K, int N, int fused) {
    constexpr int ROWS = 16;
    constexpr int KT = 32;
    constexpr int NT = 64;
    const int tid = static_cast<int>(threadIdx.x);
    const int lane = tid & 63;
    const int local_row = tid >> 6;
    const int token_base = static_cast<int>(blockIdx.x) * ROWS;

    __shared__ float xs[ROWS][KT];
    __shared__ float ws[KT][NT];
    __shared__ float candidate_score[ROWS][NT];
    __shared__ int candidate_id[ROWS][NT];

    float best_score[4] = {-1.0f, -1.0f, -1.0f, -1.0f};
    int best_id[4] = {0x7fffffff, 0x7fffffff, 0x7fffffff, 0x7fffffff};

    for (int nb = 0; nb < N; nb += NT) {
        for (int kb = 0; kb < K; kb += KT) {
            for (int i = tid; i < ROWS * KT; i += blockDim.x) {
                const int r = i / KT;
                const int k = i - r * KT;
                const int gr = token_base + r;
                const int gk = kb + k;
                float v = 0.0f;
                if (gr < M && gk < K) {
                    if constexpr (VectorLoads && std::is_same<scalar_t, float>::value) {
                        if ((k & 3) == 0 && k + 3 < KT && gk + 3 < K &&
                            (reinterpret_cast<std::uintptr_t>(x + static_cast<int64_t>(gr) * K + gk) & 15u) == 0) {
                            const float4 q = *reinterpret_cast<const float4*>(x + static_cast<int64_t>(gr) * K + gk);
                            xs[r][k] = q.x;
                            if (k + 1 < KT) xs[r][k + 1] = q.y;
                            if (k + 2 < KT) xs[r][k + 2] = q.z;
                            if (k + 3 < KT) xs[r][k + 3] = q.w;
                            continue;
                        }
                    }
                    v = static_cast<float>(x[static_cast<int64_t>(gr) * K + gk]);
                }
                xs[r][k] = v;
            }
            for (int i = tid; i < KT * NT; i += blockDim.x) {
                const int k = i / NT;
                const int n = i - k * NT;
                const int gk = kb + k;
                const int gn = nb + n;
                float v = 0.0f;
                if (gk < K && gn < N) {
                    if constexpr (VectorLoads && std::is_same<scalar_t, float>::value) {
                        if ((n & 3) == 0 && n + 3 < NT && gn + 3 < N &&
                            (reinterpret_cast<std::uintptr_t>(w + static_cast<int64_t>(gk) * N + gn) & 15u) == 0) {
                            const float4 q = *reinterpret_cast<const float4*>(w + static_cast<int64_t>(gk) * N + gn);
                            ws[k][n] = q.x;
                            if (n + 1 < NT) ws[k][n + 1] = q.y;
                            if (n + 2 < NT) ws[k][n + 2] = q.z;
                            if (n + 3 < NT) ws[k][n + 3] = q.w;
                            continue;
                        }
                    }
                    v = static_cast<float>(w[static_cast<int64_t>(gk) * N + gn]);
                }
                ws[k][n] = v;
            }
            __syncthreads();

            if (local_row < ROWS) {
                float acc[4] = {0.0f, 0.0f, 0.0f, 0.0f};
                for (int k = 0; k < KT; ++k) {
                    const float xv = xs[local_row][k];
                    const int n0 = lane * 4;
                    acc[0] = fmaf(xv, ws[k][n0], acc[0]);
                    acc[1] = fmaf(xv, ws[k][n0 + 1], acc[1]);
                    acc[2] = fmaf(xv, ws[k][n0 + 2], acc[2]);
                    acc[3] = fmaf(xv, ws[k][n0 + 3], acc[3]);
                }
                const int row = token_base + local_row;
                if (row < M) {
                    for (int j = 0; j < 4; ++j) {
                        const int n = nb + lane * 4 + j;
                        if (n < N) {
                            const float z = acc[j];
                            const float s = 1.0f / (1.0f + expf(-z));
                            if (s > best_score[j] || (s == best_score[j] && n < best_id[j])) {
                                best_score[j] = s;
                                best_id[j] = n;
                            }
                        }
                    }
                }
            }
            __syncthreads();
        }

        if (local_row < ROWS) {
            const int row = token_base + local_row;
            if (row < M) {
                for (int j = 0; j < 4; ++j) {
                    const int n = nb + lane * 4 + j;
                    candidate_score[local_row][lane * 4 + j] = best_score[j];
                    candidate_id[local_row][lane * 4 + j] = best_id[j];
                }
            }
        }
        __syncthreads();
    }

    if (local_row < ROWS && lane == 0) {
        const int row = token_base + local_row;
        if (row < M) {
            float score = -1.0f;
            int id = 0;
            for (int n = 0; n < N; ++n) {
                const float s = candidate_score[local_row][n];
                if (s > score || (s == score && n < id)) {
                    score = s;
                    id = n;
                }
            }
            const int C = 1 + fused;
            float* dst = out + static_cast<int64_t>(row) * (2 * C);
            dst[0] = static_cast<float>(id);
            dst[C] = score;
            if (fused) {
                dst[1] = static_cast<float>(N);
                dst[C + 1] = 1.0f;
            }
        }
    }
}

} // namespace

at::Tensor routing(const at::Tensor& x, const at::Tensor& w, bool fused) {
    TORCH_CHECK(x.is_cuda() && w.is_cuda(), "routing expects HIP tensors");
    TORCH_CHECK(x.dim() == 2 && w.dim() == 2, "routing expects 2-D tensors");
    TORCH_CHECK(x.scalar_type() == w.scalar_type(), "x and w dtypes must match");
    TORCH_CHECK(x.is_contiguous() && w.is_contiguous(), "x and w must be contiguous");
    const int M = static_cast<int>(x.size(0));
    const int K = static_cast<int>(x.size(1));
    const int N = static_cast<int>(w.size(1));
    TORCH_CHECK(K == w.size(0), "incompatible routing dimensions");
    const int C = 1 + (fused ? 1 : 0);
    auto out = at::empty({M, 2 * C}, x.options().dtype(at::kFloat));
    const dim3 grid((M + 15) / 16);
    const dim3 block(1024);
    auto stream = c10::hip::getCurrentHIPStream().stream();
    if (x.scalar_type() == at::kFloat) {
        routing_kernel<float, true><<<grid, block, 0, stream>>>(x.data_ptr<float>(), w.data_ptr<float>(), out.data_ptr<float>(), M, K, N, fused ? 1 : 0);
    } else {
        AT_DISPATCH_FLOATING_TYPES_AND2(at::kHalf, at::kBFloat16, x.scalar_type(), "routing_hip", [&] {
            routing_kernel<scalar_t, false><<<grid, block, 0, stream>>>(x.data_ptr<scalar_t>(), w.data_ptr<scalar_t>(), out.data_ptr<float>(), M, K, N, fused ? 1 : 0);
        });
    }
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Sigmoid top-1 routing of MoE (Mixture of Experts) gating: pick the expert
    with the highest routing score for each token out of N experts (top_k is
    always 1).

    Operator semantics: given the gating input x ([M, K], M tokens and K gating
    features) and the routing weight w ([K, N], one column per expert), for each
    token m and expert n:
        score[m, n] = sigmoid( sum_k x[m, k] * w[k, n] )
        sigmoid(z)  = 1 / (1 + exp(-z))
    top-1 routing output:
        topk_ids[m]     = argmax_n score[m, n], ties resolved to the smallest
                          expert index
        topk_weights[m] = max_n score[m, n]
    The inner product (matrix multiply) is evaluated with float32 accumulation;
    with top_k = 1 the normalization coefficient is always 1, so the weight is
    the raw sigmoid score and there is no need to divide by a sum.

    Fused shared expert column: with fused_shared_experts=True one fixed shared
    expert column is appended after the top-1 result -- the id column gets N
    (= the number of experts, outside the real expert id range) and the weight
    column gets 1.0. With False nothing is appended and the output has a single
    column.

    Input/output specification:
        x   [M, K] float16/bfloat16, contiguous; M/K/N >= 1, non powers of two
            allowed
        w   [K, N] same dtype as x, contiguous
        output  a single float32 tensor [M, 2*C], C = 1 + fused_shared_experts:
            out[:, :C] = the integers of topk_ids represented in fp32 (< 2^24,
                         exact)
            out[:, C:] = topk_weights (fp32 sigmoid scores; the fused column is
                         always 1.0)
        The evaluator casts all inputs to fp32 before passing them in (all
        inputs of this operator are floating point, so this is lossless).

    Implementation constraints (violations are scored as failures):
      - Core computation (the block-wise x * w matrix multiply, sigmoid, the
        top-1 selection and tie-break, writing back the fused shared expert
        column) must be done in a HIP kernel inside the submitted file; the
        official implementation fully fuses everything into a single kernel (the
        score matrix is never materialized), splitting it into several Triton
        kernels is not scored as a failure, but calling ATen shortcuts is.
      - Accumulation inside the matrix multiply is always float32 (inputs may be
        fp16/bf16/fp32).
      - The output is strictly float32 per the single-tensor packing protocol
        above.
      - The __init__ and forward signatures of ModelNew must not be changed.

    Disallowed list: aiter / torch.matmul / torch.bmm / torch.einsum /
    torch.nn.functional.linear / torch.topk / torch.argmax / torch.sigmoid.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, fused_shared_experts: bool = True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.fused_shared_experts = bool(fused_shared_experts)
        # <<<END_IMPROVE>>>

    def forward(self, x, w):
        # <<<IMPROVE:forward_stmt_1>>>
        # Baseline fallback keeps the official PyTorch forward path.
        # After implementing CUDA_CPP_SRC / CUDA_CU_SRC, call _pyramidkernel_get_extension().your_entrypoint(...).
        assert x.dim() == 2 and w.dim() == 2, "x / w must be 2-D tensors"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        M, K = x.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        Kb, N = w.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert K == Kb, "the last dimension of x must equal the number of rows of w"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        scores = torch.sigmoid(
            torch.matmul(x.to(torch.float32), w.to(torch.float32)))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        top1_weights, top1_ids = torch.max(scores, dim=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        ids = top1_ids.to(torch.int32).unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        weights = top1_weights.unsqueeze(1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        if self.fused_shared_experts:
            # Fused shared expert column: append N to the ids (the expert count,
            # outside the real expert range) and 1.0 to the weights
            ids = torch.cat([ids, torch.full((M, 1), N, dtype=torch.int32, device=ids.device)], dim=1)
            weights = torch.cat([weights, torch.ones((M, 1), dtype=torch.float32, device=weights.device)], dim=1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        return torch.cat([ids.to(torch.float32), weights.to(torch.float32)], dim=1)
        # <<<END_IMPROVE>>>
