import math
import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l3_p1017_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
#include <vector>

std::vector<torch::Tensor> mha_forward(torch::Tensor q, torch::Tensor k, torch::Tensor v, torch::Tensor causal, torch::Tensor slopes, double scale);

auto mha_forward_binding(torch::Tensor q, torch::Tensor k, torch::Tensor v, torch::Tensor causal, torch::Tensor slopes, double scale) {
    return mha_forward(q, k, v, causal, slopes, scale);
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mha_forward", &mha_forward_binding);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <vector>

struct Strides4 { int64_t b, s, h, d; };
static Strides4 strides4(const torch::Tensor& t) {
    return {t.stride(0), t.stride(1), t.stride(2), t.stride(3)};
}

template<class T, int StaticD = 0>
__global__ void attention_kernel(const T* q, const T* k, const T* v,
    const int* causal, int host_causal, const float* slopes,
    T* out, float* lse, int Sq, int Sk, int Hq, int Hk, int runtime_D,
    Strides4 qs, Strides4 ks, Strides4 vs, int64_t sb, int64_t sh, float scale) {
    const int D = StaticD != 0 ? StaticD : runtime_D;
    const int tid = threadIdx.x;
    const int i = blockIdx.x % Sq;
    const int h = (blockIdx.x / Sq) % Hq;
    const int b = blockIdx.x / (Sq * Hq);
    const int kh = h / (Hq / Hk);
    const int end = (causal ? *causal : host_causal) ? min(Sk, i + Sk - Sq + 1) : Sk;
    const int64_t oi = ((int64_t(b) * Sq + i) * Hq + h) * D;
    const int64_t li = (int64_t(b) * Hq + h) * Sq + i;
    if (end <= 0) {
        for (int d = tid; d < D; d += 128) out[oi+d] = T(0.0f);
        if (tid == 0) lse[li] = 0.0f;
        return;
    }
    __shared__ float query[256];
    __shared__ float weights[32];
    __shared__ float maximum, denom, rescale;
    for (int d = tid; d < D; d += 128)
        query[d] = float(q[b*qs.b + i*qs.s + h*qs.h + d*qs.d]);
    if (tid == 0) { maximum = -INFINITY; denom = 0.0f; }
    __syncthreads();
    float a0 = 0.0f, a1 = 0.0f;
    const float slope = slopes[b*sb + h*sh];
    for (int base = 0; base < end; base += 32) {
        const int j = base + tid / 4;
        const int lane = tid % 4;
        float dot = 0.0f;
        if (j < end) {
            const int64_t ki = b*ks.b + j*ks.s + kh*ks.h;
            if constexpr (StaticD == 64) {
                #pragma unroll
                for (int t = 0; t < 16; ++t) {
                    const int d = lane + 4*t;
                    dot += query[d] * float(k[ki + d*ks.d]);
                }
            } else {
                for (int d = lane; d < D; d += 4)
                    dot += query[d] * float(k[ki + d*ks.d]);
            }
        }
        float pair = dot + __shfl_xor(dot, 1, 4);
        float sum = pair + __shfl_xor(pair, 2, 4);
        if (lane == 0) {
            weights[tid / 4] = j < end
                ? scale*sum - slope*fabsf(float(i+Sk-Sq-j))
                : -INFINITY;
        }
        __syncthreads();
        if (tid < 32) {
            const float score = weights[tid];
            float m = score;
            #pragma unroll
            for (int offset = 16; offset > 0; offset >>= 1)
                m = fmaxf(m, __shfl_xor(m, offset, 32));
            m = fmaxf(maximum, m);
            const float p = base + tid < end ? expf(score - m) : 0.0f;
            weights[tid] = p;
            float s = p;
            #pragma unroll
            for (int offset = 16; offset > 0; offset >>= 1)
                s += __shfl_xor(s, offset, 32);
            if (tid == 0) {
                rescale = expf(maximum - m);
                denom = denom * rescale + s;
                maximum = m;
            }
        }
        __syncthreads();
        a0 *= rescale;
        a1 *= rescale;
        const int count = min(32, end-base);
        for (int t = 0; t < count; ++t) {
            const int64_t vi = b*vs.b + (base+t)*vs.s + kh*vs.h;
            float p = weights[t];
            if (tid < D) a0 += p * float(v[vi + tid*vs.d]);
            if (tid+128 < D) a1 += p * float(v[vi + (tid+128)*vs.d]);
        }
        __syncthreads();
    }
    if (tid < D) out[oi+tid] = T(a0 / denom);
    if (tid+128 < D) out[oi+tid+128] = T(a1 / denom);
    if (tid == 0) lse[li] = maximum + logf(denom);
}

std::vector<torch::Tensor> mha_forward(torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor causal, torch::Tensor slopes, double scale) {
    TORCH_CHECK(q.is_cuda() && k.device() == q.device() && v.device() == q.device(), "QKV must share a GPU");
    c10::cuda::CUDAGuard guard(q.device());
    TORCH_CHECK(q.dim()==4 && k.dim()==4 && v.dim()==4, "QKV must be rank four");
    TORCH_CHECK(q.scalar_type()==at::kHalf || q.scalar_type()==at::kBFloat16 || q.scalar_type()==at::kFloat, "expected fp16, bf16 or fp32");
    TORCH_CHECK(k.scalar_type()==q.scalar_type() && v.scalar_type()==q.scalar_type(), "dtype mismatch");
    const int B=q.size(0), Sq=q.size(1), Hq=q.size(2), D=q.size(3);
    const int Sk=k.size(1), Hk=k.size(2);
    TORCH_CHECK(Sq>0 && Sk>0 && Hk>0 && Hq>0 && Hq%Hk==0 && D>0 && D<=256, "invalid dimensions");
    TORCH_CHECK(k.size(0)==B && k.size(3)==D && v.sizes()==k.sizes(), "KV shape mismatch");
    TORCH_CHECK(slopes.device()==q.device() && slopes.scalar_type()==at::kFloat && slopes.dim()==2 && slopes.size(0)==B && slopes.size(1)==Hq, "invalid slopes");
    TORCH_CHECK(causal.numel()==1, "causal must be scalar");
    const int* cp=nullptr;
    int hc=0;
    if (causal.is_cuda()) {
        TORCH_CHECK(causal.device()==q.device() && causal.scalar_type()==at::kInt, "GPU causal must be int32 on Q device");
        cp=causal.data_ptr<int>();
    } else {
        hc=causal.item<int>();
        TORCH_CHECK(hc==0 || hc==1, "causal must be zero or one");
    }
    auto out=torch::empty({B,Sq,Hq,D},q.options());
    auto lse=torch::empty({B,Hq,Sq},q.options().dtype(at::kFloat));
    if (B == 0) return {out,lse};
    auto stream=at::cuda::getCurrentCUDAStream();
    AT_DISPATCH_SWITCH(q.scalar_type(), "attention_hip",
        AT_DISPATCH_CASE(at::ScalarType::Half, [&] {
            if (D == 64)
                attention_kernel<scalar_t,64><<<B*Hq*Sq,128,0,stream>>>(q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),cp,hc,slopes.data_ptr<float>(),out.data_ptr<scalar_t>(),lse.data_ptr<float>(),Sq,Sk,Hq,Hk,D,strides4(q),strides4(k),strides4(v),slopes.stride(0),slopes.stride(1),float(scale));
            else
                attention_kernel<scalar_t,0><<<B*Hq*Sq,128,0,stream>>>(q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),cp,hc,slopes.data_ptr<float>(),out.data_ptr<scalar_t>(),lse.data_ptr<float>(),Sq,Sk,Hq,Hk,D,strides4(q),strides4(k),strides4(v),slopes.stride(0),slopes.stride(1),float(scale));
        })
        AT_DISPATCH_CASE(at::ScalarType::BFloat16, [&] {
            if (D == 64)
                attention_kernel<scalar_t,64><<<B*Hq*Sq,128,0,stream>>>(q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),cp,hc,slopes.data_ptr<float>(),out.data_ptr<scalar_t>(),lse.data_ptr<float>(),Sq,Sk,Hq,Hk,D,strides4(q),strides4(k),strides4(v),slopes.stride(0),slopes.stride(1),float(scale));
            else
                attention_kernel<scalar_t,0><<<B*Hq*Sq,128,0,stream>>>(q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),cp,hc,slopes.data_ptr<float>(),out.data_ptr<scalar_t>(),lse.data_ptr<float>(),Sq,Sk,Hq,Hk,D,strides4(q),strides4(k),strides4(v),slopes.stride(0),slopes.stride(1),float(scale));
        })
        AT_DISPATCH_CASE(at::ScalarType::Float, [&] {
            if (D == 64)
                attention_kernel<scalar_t,64><<<B*Hq*Sq,128,0,stream>>>(q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),cp,hc,slopes.data_ptr<float>(),out.data_ptr<scalar_t>(),lse.data_ptr<float>(),Sq,Sk,Hq,Hk,D,strides4(q),strides4(k),strides4(v),slopes.stride(0),slopes.stride(1),float(scale));
            else
                attention_kernel<scalar_t,0><<<B*Hq*Sq,128,0,stream>>>(q.data_ptr<scalar_t>(),k.data_ptr<scalar_t>(),v.data_ptr<scalar_t>(),cp,hc,slopes.data_ptr<float>(),out.data_ptr<scalar_t>(),lse.data_ptr<float>(),Sq,Sk,Hq,Hk,D,strides4(q),strides4(k),strides4(v),slopes.stride(0),slopes.stride(1),float(scale));
        })
    );
    auto err=hipGetLastError();
    TORCH_CHECK(err==hipSuccess, "attention launch failed: ", hipGetErrorString(err));
    return {out,lse};
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    Dense (padded 4D batch) FlashAttention forward: scaled dot-product attention
    with softmax, bottom-right-aligned causal mask, ALiBi positional bias,
    MHA/GQA, returning both the output and the per-row log-sum-exp (LSE).

    Mathematical definition (for batch element b, query head h, query position i,
    key position j, g = num_q_heads // num_kv_heads, query head h maps to KV head
    h // g):
      score[b,h,i,j] = sm_scale * <q[b,i,h,:], k[b,j,h//g,:]>
                       - alibi_slopes[b,h] * |i + seqlen_k - seqlen_q - j|
      With causal=1 the bottom-right-aligned causal mask is applied: positions
      j > i + seqlen_k - seqlen_q are set to -inf (i.e. query i only attends to
      keys j <= i + seqlen_k - seqlen_q); with causal=0 no mask is applied at all.
      The ALiBi bias is applied in both causal and non-causal mode; all-zero
      slopes are equivalent to no ALiBi.
      p[b,h,i,:] = softmax_j(score[b,h,i,:])   (numerically stable online form)
      out[b,i,h,:] = sum_j p[b,h,i,j] * v[b,j,h//g,:]
      lse[b,h,i] = ln( sum_j exp(score[b,h,i,j]) )   (natural logarithm)
    softmax/accumulation are done in float32, out is cast back to the input dtype,
    lse is float32.
    Boundary behaviour: with causal=1 and seqlen_q > seqlen_k, rows
    i < seqlen_q - seqlen_k are masked out entirely -- those rows have out = 0 and
    lse = 0 (not -inf).

    Input/output specification:
      q            [batch, seqlen_q, num_q_heads, head_dim]   float16/bfloat16
      k, v         [batch, seqlen_k, num_kv_heads, head_dim]  same dtype as q
      causal       0-dim int32 tensor, 1=causal mask, 0=no mask
      alibi_slopes [batch, num_q_heads] float32, elements >= 0 (all zeros = no ALiBi)
      Returns a single 1-D tensor packed (multi-output packing protocol):
      packed = cat([out.reshape(-1).to(float32), lse.reshape(-1)])
      where out [batch, seqlen_q, num_q_heads, head_dim] (computed in the input
      dtype, then cast to float32 for the concatenation) and lse
      [batch, num_q_heads, seqlen_q] float32; total length of packed =
      batch * seqlen_q * num_q_heads * (head_dim + 1).
    Global-domain constraints: num_q_heads is an integer multiple of num_kv_heads
    (equal means MHA, otherwise GQA); 1 <= seqlen_q, 1 <= seqlen_k (any
    combination, including seqlen_q > seqlen_k); 1 <= head_dim <= 256.

    Implementation constraints (violations are scored as failures):
      - The core computation (QK^T / ALiBi bias / causal mask / softmax / PV / LSE)
        must be completed inside the submitted file; calling ready-made attention /
        matrix-multiplication / softmax routines is forbidden:
        scaled_dot_product_attention / sdpa / flash_attn / torch.matmul /
        torch.bmm / torch.einsum / torch.softmax / torch.logsumexp, as is any
        synonymous wrapper from a third-party operator library.
      - The __init__ and forward signatures of ModelNew must not be changed.
      - Use float32 for intermediate accumulation; cast out back to the input
        dtype, keep lse in float32.
      - forward must return a single 1-D float32 tensor following the packing
        protocol above (compute out and lse internally first, then flatten and
        concatenate them).

    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    Task scope: dense 4D forward, non-quantized inputs, no bias, no dropout, no
    sliding window.
    """
    def __init__(self, head_dim: int, sm_scale=None):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.sm_scale = float(sm_scale) if sm_scale is not None else 1.0 / math.sqrt(head_dim)
        # <<<END_IMPROVE>>>

    def forward(self, q, k, v, causal, alibi_slopes):
        # <<<IMPROVE:forward_stmt_1>>>
        if not torch.is_tensor(causal):
            causal = torch.tensor(causal, dtype=torch.int32)
        elif causal.is_cuda:
            causal = causal.to(device=q.device, dtype=torch.int32)
        out, lse = _pyramidkernel_get_extension().mha_forward(
            q, k, v, causal, alibi_slopes, self.sm_scale
        )
        return torch.cat([out.reshape(-1).to(torch.float32), lse.reshape(-1)])
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        is_causal = bool(int(causal.to(torch.int32)))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        alibi_slopes = alibi_slopes.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        batch, seqlen_q, nheads_q, head_dim = q.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        _, seqlen_k, nheads_k, _ = k.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        group = nheads_q // nheads_k
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert nheads_q == nheads_k * group, "num_q_heads must be an integer multiple of num_kv_heads"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        qf = q.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        kf = k.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        vf = v.to(torch.float32).permute(0, 2, 1, 3)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        scores = torch.matmul(qf, kf.repeat_interleave(group, dim=1).transpose(-2, -1))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        scores = scores * self.sm_scale
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        pos_q = torch.arange(seqlen_q, device=q.device, dtype=torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        pos_k = torch.arange(seqlen_k, device=q.device, dtype=torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        relative = (pos_q[:, None] + (seqlen_k - seqlen_q)) - pos_k[None, :]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        scores = scores - alibi_slopes[:, :, None, None] * relative.abs()
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        if is_causal:
            # Bottom-right-aligned causal mask: j > i + (Sk - Sq) becomes -inf
            causal_mask = torch.triu(
                torch.ones(seqlen_q, seqlen_k, dtype=torch.bool, device=q.device),
                diagonal=seqlen_k - seqlen_q + 1,
            )
            scores = scores.masked_fill(causal_mask, float("-inf"))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        lse = torch.logsumexp(scores, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        fully_masked = torch.isinf(lse) & (lse < 0)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        lse = torch.where(fully_masked, torch.zeros_like(lse), lse)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        probs = torch.softmax(scores, dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        acc = torch.matmul(probs, vf.repeat_interleave(group, dim=1))
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        acc = torch.where(fully_masked[:, :, :, None], torch.zeros_like(acc), acc)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        out = acc.permute(0, 2, 1, 3).to(q.dtype)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        return torch.cat([out.reshape(-1).to(torch.float32), lse.reshape(-1)])
        # <<<END_IMPROVE>>>
