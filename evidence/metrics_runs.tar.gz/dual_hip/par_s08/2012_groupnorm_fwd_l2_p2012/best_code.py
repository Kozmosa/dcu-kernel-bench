import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2012_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor groupnorm_fwd(torch::Tensor x, torch::Tensor scale, torch::Tensor bias, int64_t groups, double eps, bool swish);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("groupnorm_fwd", &groupnorm_fwd);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

__device__ float block_sum(float v, float* buf) {
    int t = threadIdx.x;
    int lane = t % warpSize;
    int wave = t / warpSize;
    int waves = blockDim.x / warpSize;
    for (int offset = warpSize / 2; offset > 0; offset >>= 1)
        v += __shfl_down(v, offset, warpSize);
    if (lane == 0) buf[wave] = v;
    __syncthreads();
    float total = 0.0f;
    if (wave == 0) {
        total = (lane < waves) ? buf[lane] : 0.0f;
        for (int offset = warpSize / 2; offset > 0; offset >>= 1)
            total += __shfl_down(total, offset, warpSize);
        if (lane == 0) buf[0] = total;
    }
    __syncthreads();
    float r = buf[0];
    __syncthreads();
    return r;
}

template<typename T, bool FuseOutput>
__global__ void gn_stats(const T* x, const T* scale, const T* bias, float* out,
                         int64_t D, int64_t total, int64_t rows,
                         int64_t spatial, int64_t channels, float eps, bool swish) {
    __shared__ float buf[256];
    int64_t row = blockIdx.x;
    int64_t base = row * D;
    float sum = 0.0f;
    for (int64_t j = threadIdx.x; j < D; j += blockDim.x) sum += float(x[base+j]);
    float mean = block_sum(sum, buf) / float(D);
    float sq = 0.0f;
    for (int64_t j = threadIdx.x; j < D; j += blockDim.x) {
        float d = float(x[base+j]) - mean;
        sq += d*d;
    }
    float var = block_sum(sq, buf) / float(D);
    float inv = rsqrtf(var + eps);
    if (threadIdx.x == 0) {
        out[total+row] = mean;
        out[total+rows+row] = inv;
    }
    if (FuseOutput) {
        for (int64_t j = threadIdx.x; j < D; j += blockDim.x) {
            int64_t i = base + j;
            int64_t c = (i / spatial) % channels;
            float v = (float(x[i]) - mean) * inv;
            v = __fmul_rn(v, float(scale[c]));
            v = __fadd_rn(v, float(bias[c]));
            if (swish) v = v * (1.0f / (1.0f + expf(-v)));
            out[i] = v;
        }
    }
}

// Two tiled passes ensure variance is accumulated about the final group mean.
template<typename T, bool Variance>
__global__ void gn_partial(const T* x, const float* out, float* partial, int64_t D, int64_t total, int64_t tiles) {
    __shared__ float buf[256];
    int64_t row = int64_t(blockIdx.x)/tiles;
    int64_t tile = int64_t(blockIdx.x)%tiles;
    int64_t end = (tile+1)*4096;
    if (end>D) end=D;
    float mean = Variance ? out[total+row] : 0.0f;
    float sum=0.0f;
    for (int64_t j=tile*4096+threadIdx.x; j<end; j+=256) {
        float v=float(x[row*D+j]);
        if (Variance) { v-=mean; v=v*v; }
        sum+=v;
    }
    sum=block_sum(sum,buf);
    if (threadIdx.x==0) partial[row*tiles+tile]=sum;
}

template<bool Variance>
__global__ void gn_finish(const float* partial, float* out, int64_t D, int64_t total, int64_t rows, int64_t tiles, float eps) {
    __shared__ float buf[256];
    int64_t row=blockIdx.x;
    float sum=0.0f;
    for (int64_t j=threadIdx.x; j<tiles; j+=blockDim.x) sum+=partial[row*tiles+j];
    float value=block_sum(sum,buf)/float(D);
    if (threadIdx.x==0) {
        if (Variance) out[total+rows+row]=rsqrtf(value+eps);
        else out[total+row]=value;
    }
}

template<typename T>
__global__ void gn_output(const T* x, const T* scale, const T* bias, float* out, int64_t total, int64_t D, int64_t rows, int64_t spatial, int64_t channels, bool swish) {
    int64_t i = int64_t(blockIdx.x)*256 + threadIdx.x;
    if (i < total) {
        int64_t row = i/D;
        int64_t c = (i/spatial)%channels;
        float v = (float(x[i])-out[total+row])*out[total+rows+row];
        v = __fmul_rn(v, float(scale[c]));
        v = __fadd_rn(v, float(bias[c]));
        if (swish) v = v * (1.0f/(1.0f+expf(-v)));
        out[i] = v;
    }
}

template<typename T>
__global__ void gn_output_spatial(const T* x, const T* scale, const T* bias,
                                  float* out, int64_t total, int64_t rows,
                                  int64_t spatial, int64_t channels,
                                  int64_t groups, bool swish) {
    int64_t tiles_per_channel = (spatial + 1023) / 1024;
    int64_t nc = int64_t(blockIdx.x) / tiles_per_channel;
    int64_t tile = int64_t(blockIdx.x) % tiles_per_channel;
    int64_t c = nc % channels;
    int64_t n = nc / channels;
    int64_t row = n * groups + c / (channels / groups);
    float sc = float(scale[c]);
    float bc = float(bias[c]);
    float mean = out[total + row];
    float inv = out[total + rows + row];
    for (int k = 0; k < 4; ++k) {
        int64_t p = tile * 1024 + int64_t(threadIdx.x) + int64_t(k) * 256;
        if (p < spatial) {
            int64_t i = nc * spatial + p;
            float v = (float(x[i]) - mean) * inv;
            v = __fmul_rn(v, sc);
            v = __fadd_rn(v, bc);
            if (swish) v = v * (1.0f/(1.0f+expf(-v)));
            out[i] = v;
        }
    }
}

torch::Tensor groupnorm_fwd(torch::Tensor x, torch::Tensor scale, torch::Tensor bias, int64_t groups, double eps, bool swish) {
    TORCH_CHECK(x.is_cuda() && x.dim()==4 && x.is_contiguous(), "expected contiguous GPU NCHW input");
    c10::cuda::CUDAGuard guard(x.device());
    int64_t C=x.size(1), spatial=x.size(2)*x.size(3);
    TORCH_CHECK(groups>0 && groups<=C && C%groups==0, "invalid groups");
    TORCH_CHECK(scale.is_contiguous() && bias.is_contiguous() && scale.numel()==C && bias.numel()==C, "invalid affine parameters");
    TORCH_CHECK(scale.scalar_type()==x.scalar_type() && bias.scalar_type()==x.scalar_type(), "dtype mismatch");
    int64_t total=x.numel(), rows=x.size(0)*groups, D=(C/groups)*spatial;
    auto out=torch::empty({total+2*rows}, x.options().dtype(torch::kFloat32));
    auto stream=at::cuda::getCurrentCUDAStream();
    int threads=64;
    while (threads<D && threads<256) threads*=2;
    int64_t tiles=(D+4095)/4096;
    torch::Tensor partial;
    if (D>16384) partial=torch::empty({rows*tiles},out.options());
    AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, x.scalar_type(), "gn_forward", [&] {
        if (D<=4096) {
            gn_stats<scalar_t,true><<<rows,threads,0,stream>>>(x.data_ptr<scalar_t>(),scale.data_ptr<scalar_t>(),bias.data_ptr<scalar_t>(),out.data_ptr<float>(),D,total,rows,spatial,C,float(eps),swish);
        } else if (D<=16384) {
            gn_stats<scalar_t,false><<<rows,threads,0,stream>>>(x.data_ptr<scalar_t>(),scale.data_ptr<scalar_t>(),bias.data_ptr<scalar_t>(),out.data_ptr<float>(),D,total,rows,spatial,C,float(eps),swish);
            if (spatial >= 1024) {
                int64_t output_tiles = (spatial + 1023) / 1024;
                gn_output_spatial<scalar_t><<<x.size(0)*C*output_tiles,256,0,stream>>>(x.data_ptr<scalar_t>(),scale.data_ptr<scalar_t>(),bias.data_ptr<scalar_t>(),out.data_ptr<float>(),total,rows,spatial,C,groups,swish);
            } else {
                gn_output<scalar_t><<<(total+255)/256,256,0,stream>>>(x.data_ptr<scalar_t>(),scale.data_ptr<scalar_t>(),bias.data_ptr<scalar_t>(),out.data_ptr<float>(),total,D,rows,spatial,C,swish);
            }
        } else {
            int finish_threads=64;
            while (finish_threads<tiles && finish_threads<256) finish_threads*=2;
            gn_partial<scalar_t,false><<<rows*tiles,256,0,stream>>>(x.data_ptr<scalar_t>(),out.data_ptr<float>(),partial.data_ptr<float>(),D,total,tiles);
            gn_finish<false><<<rows,finish_threads,0,stream>>>(partial.data_ptr<float>(),out.data_ptr<float>(),D,total,rows,tiles,float(eps));
            gn_partial<scalar_t,true><<<rows*tiles,256,0,stream>>>(x.data_ptr<scalar_t>(),out.data_ptr<float>(),partial.data_ptr<float>(),D,total,tiles);
            gn_finish<true><<<rows,finish_threads,0,stream>>>(partial.data_ptr<float>(),out.data_ptr<float>(),D,total,rows,tiles,float(eps));
            if (spatial >= 1024) {
                int64_t output_tiles = (spatial + 1023) / 1024;
                gn_output_spatial<scalar_t><<<x.size(0)*C*output_tiles,256,0,stream>>>(x.data_ptr<scalar_t>(),scale.data_ptr<scalar_t>(),bias.data_ptr<scalar_t>(),out.data_ptr<float>(),total,rows,spatial,C,groups,swish);
            } else {
                gn_output<scalar_t><<<(total+255)/256,256,0,stream>>>(x.data_ptr<scalar_t>(),scale.data_ptr<scalar_t>(),bias.data_ptr<scalar_t>(),out.data_ptr<float>(),total,D,rows,spatial,C,swish);
            }
        }
    });
    return out;
}
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    GroupNorm forward family: standard GroupNorm and the GroupNorm+Swish fusion.

    The input is x (N, C, H, W), NCHW contiguous; scale / bias are the (C,)
    per-channel affine parameters; the __init__ argument groups = G (dividing C,
    1 <= G <= C) splits the channels into G groups, with channel c belonging to
    group c // (C//G); eps defaults to 1e-5. The normalization statistics are
    computed per (n, g) group: x[n] is split along the channel dimension into G
    segments (group g occupies the channels [g*(C//G), (g+1)*(C//G)), and the number
    of elements in a group is D = (C//G)*H*W), in float32:
        mean_ng     = sum_D x / D                      (biased mean)
        var_ng      = sum_D (x - mean_ng)^2 / D        (biased variance)
        inv_var_ng  = 1 / sqrt(var_ng + eps)
        gn[n,c,h,w] = (x[n,c,h,w] - mean_ng) * inv_var_ng * scale[c] + bias[c]
                      (where the group index is g = c // (C//G))
    The __init__ argument variant selects one of two paths:
        "groupnorm"      : y = gn
        "groupnorm_swish": y = gn * sigmoid(gn) (Swish / SiLU)
    Both variants also emit the per-group statistics mean and inv_var (one entry per
    (n, g), (N, G) layout, float32).

    Boundary behaviour: when the in-group variance is 0 (e.g. D == 1, a single
    element in the group) inv_var = 1/sqrt(eps) (eps guarantees no division by zero)
    and gn = bias; G=1 is full-channel normalization and G=C is per-channel
    normalization, both of which are legal; N/C/H/W are arbitrary (including 1,
    non-powers of two and unaligned), a large in-group D needs a tiling (block-wise)
    reduction, and out-of-range elements at the row tail must not take part in the
    statistics.

    Single-tensor output protocol (forward must return a single tensor; the evaluator
    compares a single output):
    Returns a one-dimensional float32 packed tensor of length N*C*H*W + 2*N*G, with
    three segments packed back to back in order (half-open intervals; each segment is
    float32, reshaped with reshape(-1) and torch.cat'ed):
        [0,               N*C*H*W)           y
        [N*C*H*W,         N*C*H*W + N*G)     mean    ((N, G) flattened row-major)
        [N*C*H*W + N*G,   N*C*H*W + 2*N*G)   inv_var ((N, G) flattened row-major)
    The output is always float32: the y segment is not quantized to a lower
    precision; fp16/bf16 is only the input quantization level (the input is provided
    in that dtype and then cast to float32 to take part in the whole computation).

    Input/output specification:
        x      float32 / float16 / bfloat16 (N, C, H, W), contiguous, N/C/H/W >= 1
        scale  same dtype as x, (C,), contiguous
        bias   same dtype as x, (C,), contiguous
        out    one-dimensional float32 of length N*C*H*W + 2*N*G (the three-segment
               packing protocol above)
        The inputs are the usual randn magnitude (no inf/NaN); the evaluator casts
        all inputs to fp32 before passing them in (fp16/bf16 -> fp32 is lossless).

    Implementation constraints (violations are scored as failures):
        - The core computation (the in-group mean / biased var reduction, rsqrt, the
          per-channel affine, and Swish) must be completed inside the submitted file
          with a HIP kernel.
        - The __init__ and forward signatures of ModelNew must not be changed.
        - The statistics, rsqrt, the affine and Swish all use float32 intermediates;
          all three output segments are float32.
        - forward returns the single tensor out (the evaluator compares
          shape/dtype/allclose on a single output).

    Forbidden: torch.nn.GroupNorm / torch.nn.functional.group_norm /
    F.group_norm / torch.group_norm / native_group_norm / miopen / hipdnn.
    Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, variant: str = "groupnorm", groups: int = 2, eps: float = 1e-5):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        assert variant in ("groupnorm", "groupnorm_swish"), "variant must be one of groupnorm / groupnorm_swish"
        assert int(groups) >= 1, "groups must be a positive integer"
        assert eps > 0, "eps must be positive"
        self.variant = variant
        self.groups = int(groups)
        self.eps = float(eps)
        # <<<END_IMPROVE>>>

    def forward(self, x, scale, bias):
        # <<<IMPROVE:forward_stmt_1>>>
        assert x.ndim == 4
        n, c, h, w = x.shape
        assert min(n, c, h, w) >= 1
        assert 1 <= self.groups <= c and c % self.groups == 0
        return _pyramidkernel_get_extension().groupnorm_fwd(x, scale, bias, int(self.groups), float(self.eps), self.variant == "groupnorm_swish")
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        g = self.groups
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        rep = c // g
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        assert 1 <= g <= c and c % g == 0, "groups must divide the number of channels and 1 <= groups <= C"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        xf = x.to(torch.float32)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        xg = xf.reshape(n, g, -1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        mean = xg.mean(dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        var = (xg - mean.unsqueeze(-1)).pow(2).mean(dim=-1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        inv_var = torch.rsqrt(var + self.eps)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        mean_c = mean.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        inv_c = inv_var.repeat_interleave(rep, dim=1).reshape(n, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        sf = scale.to(torch.float32).reshape(1, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        bf = bias.to(torch.float32).reshape(1, c, 1, 1)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        gn = (xf - mean_c) * inv_c * sf + bf
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        y = gn * torch.sigmoid(gn) if self.variant == "groupnorm_swish" else gn
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        return torch.cat([y.reshape(-1), mean.reshape(-1), inv_var.reshape(-1)])
        # <<<END_IMPROVE>>>
