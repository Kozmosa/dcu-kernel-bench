import torch
import torch.nn as nn
import hashlib
from torch.utils.cpp_extension import load_inline

_PyramidKernel_EXTENSION = None

def _pyramidkernel_strip_anchor_markers(source: str) -> str:
    cleaned_lines = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith('# <<<IMPROVE:') or stripped.startswith('# <<<END_IMPROVE>>>'):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def _pyramidkernel_extension_name() -> str:
    digest = hashlib.sha1((_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC) + _pyramidkernel_strip_anchor_markers(CUDA_CU_SRC)).encode('utf-8')).hexdigest()[:12]
    return f'pyramidkernel_cuda_l2_p2004_{digest}'

def _pyramidkernel_get_extension():
    global _PyramidKernel_EXTENSION
    if _PyramidKernel_EXTENSION is None:
        _PyramidKernel_EXTENSION = load_inline(
            name=_pyramidkernel_extension_name(),
            cpp_sources=_pyramidkernel_strip_anchor_markers(CUDA_CPP_SRC),
            cuda_sources=_pyramidkernel_strip_anchor_markers(CUDA_CU_SRC),
            functions=None,
            extra_cflags=['-O3'],
            extra_cuda_cflags=['-O3'] + ([] if getattr(torch.version, 'hip', None) else ['--use_fast_math']),
            with_cuda=True,
            verbose=False,
        )
    return _PyramidKernel_EXTENSION

# <<<IMPROVE:user_helpers>>>
# <<<END_IMPROVE>>>

CUDA_CPP_SRC = r"""
# <<<IMPROVE:cuda_cpp>>>
#include <torch/extension.h>
torch::Tensor fused_qk(torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, bool, bool);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fused_qk", &fused_qk);
}
# <<<END_IMPROVE>>>
"""

CUDA_CU_SRC = r"""
# <<<IMPROVE:cuda_cu>>>
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAException.h>

__device__ int64_t read_position(const void* p, int type, int64_t b) {
    switch (type) {
        case 0: return static_cast<const int64_t*>(p)[b];
        case 1: return (int64_t)static_cast<const float*>(p)[b];
        case 2: return (int64_t)(float)static_cast<const at::Half*>(p)[b];
        case 3: return (int64_t)(float)static_cast<const at::BFloat16*>(p)[b];
        case 4: return (int64_t)static_cast<const double*>(p)[b];
        default: return static_cast<const int32_t*>(p)[b];
    }
}

template<class T, bool ROPE, bool NEOX, bool FULL_WIDTH>
__global__ void qk_kernel(const T* qn, const T* qp, const T* kn, const T* kp,
                          const void* pos, int pt, const T* c, const T* s, T* out,
                          int64_t qh, int64_t kh, int64_t dn, int64_t dp, int64_t df) {
    #pragma clang fp contract(off)
    int64_t row = blockIdx.x;
    int64_t b = row / (qh + kh), h = row % (qh + kh);
    bool isq = h < qh;
    int64_t src = isq ? b * qh + h : b * kh + h - qh;
    const T* n = (isq ? qn : kn) + src * dn;
    const T* p = (isq ? qp : kp) + src * dp;
    T* o = out + row * (dn + dp);
    if (sizeof(T) == 2 && dn % 8 == 0 &&
        (reinterpret_cast<uintptr_t>(n) & 15) == 0 &&
        (reinterpret_cast<uintptr_t>(o) & 15) == 0) {
        const uint4* nv = reinterpret_cast<const uint4*>(n);
        uint4* ov = reinterpret_cast<uint4*>(o);
        for (int64_t i = threadIdx.x; i < dn / 8; i += blockDim.x)
            ov[i] = nv[i];
        for (int64_t i = (dn / 8) * 8 + threadIdx.x; i < dn; i += blockDim.x)
            o[i] = n[i];
    } else {
        for (int64_t i = threadIdx.x; i < dn; i += blockDim.x)
            o[i] = n[i];
    }
    o += dn;
    if constexpr (!ROPE) {
        for (int64_t i = threadIdx.x; i < dp; i += blockDim.x)
            o[i] = p[i];
        return;
    }
    int64_t base = read_position(pos, pt, b) * df;
    for (int64_t j = threadIdx.x; j < dp / 2; j += blockDim.x) {
        int64_t i0 = NEOX ? j : 2*j;
        int64_t i1 = NEOX ? j + dp/2 : 2*j+1;
        float c0, s0, c1, s1;
        if constexpr (FULL_WIDTH) {
            c0 = (float)c[base + i0];
            s0 = (float)s[base + i0];
            c1 = (float)c[base + i1];
            s1 = (float)s[base + i1];
        } else {
            c0 = (float)c[base + j];
            s0 = (float)s[base + j];
            c1 = c0;
            s1 = s0;
        }
        float x0 = (float)p[i0], x1 = (float)p[i1];
        float a = x0 * c0;
        float z = (-x1) * s0;
        float v = x1 * c1;
        float w = x0 * s1;
        o[i0] = T(a + z);
        o[i1] = T(v + w);
    }
}

#define QK_LAUNCH(R, N, F) \
    qk_kernel<scalar_t, R, N, F><<<b * (qh + kh), 128, 0, stream.stream()>>>( \
        qn.data_ptr<scalar_t>(), qp.data_ptr<scalar_t>(), kn.data_ptr<scalar_t>(), kp.data_ptr<scalar_t>(), \
        pos.data_ptr(), pt, cos.data_ptr<scalar_t>(), sin.data_ptr<scalar_t>(), out.data_ptr<scalar_t>(), \
        qh, kh, dn, dp, df)

torch::Tensor fused_qk(torch::Tensor qn, torch::Tensor qp, torch::Tensor kn, torch::Tensor kp,
                       torch::Tensor pos, torch::Tensor cos, torch::Tensor sin, bool neox, bool rope) {
    c10::cuda::CUDAGuard guard(qn.device());
    int64_t b = qn.size(0), qh = qn.size(1), kh = kn.size(1);
    int64_t dn = qn.size(2), dp = qp.size(2), df = cos.size(-1);
    auto out = torch::empty({b, qh + kh, dn + dp}, qn.options());
    int pt = 0;
    if (rope) {
        switch (pos.scalar_type()) {
            case at::kLong: pt = 0; break;
            case at::kFloat: pt = 1; break;
            case at::kHalf: pt = 2; break;
            case at::kBFloat16: pt = 3; break;
            case at::kDouble: pt = 4; break;
            case at::kInt: pt = 5; break;
            default: TORCH_CHECK(false, "Unsupported position dtype");
        }
    }
    auto stream = c10::cuda::getCurrentCUDAStream(qn.get_device());
    if (b * (qh + kh) != 0) {
        AT_DISPATCH_FLOATING_TYPES_AND2(at::ScalarType::Half, at::ScalarType::BFloat16, qn.scalar_type(), "qk_fused", [&] {
            if (!rope) {
                QK_LAUNCH(false, false, false);
            } else if (neox) {
                if (df == dp) { QK_LAUNCH(true, true, true); }
                else { QK_LAUNCH(true, true, false); }
            } else {
                if (df == dp) { QK_LAUNCH(true, false, true); }
                else { QK_LAUNCH(true, false, false); }
            }
        });
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    return out;
}
#undef QK_LAUNCH
# <<<END_IMPROVE>>>
"""

class ModelNew(nn.Module):
    """
    MLA-style QK preprocessing fused operator: rotary position embedding (RoPE)
    on the pe segment plus nope/pe concatenation.

    (1) Operator semantics (mathematical definition and boundary behaviour):
    The Q side takes q_nope [B, QH, D_nope] and q_pe [B, QH, D_pe]; the K side takes
    k_nope [B, KH, D_nope] and k_pe [B, KH, D_pe]. QH must be an integer multiple of
    KH (GQA; write QH_PER_KH = QH // KH) and D_pe must be even. The output is packed
    into a single tensor out [B, QH + KH, D_nope + D_pe]: along the head dimension
    the first QH rows are the Q result and the last KH rows are the K result (each
    KV head is computed and written back only once, i.e. the GQA deduplicated
    write-back semantics).

    The nope segment is copied verbatim: out[:, :QH, :D_nope] = q_nope,
    out[:, QH:, :D_nope] = k_nope. The pe segment (x means q_pe or k_pe, promoted to
    float32 before the computation):
    - apply_rope=False (pure concatenation mode): out[..., D_nope:] = x copied
      verbatim; pos / cos / sin are ignored;
    - apply_rope=True (rope mode): for each batch b take c = cos[pos[b]] and
      s = sin[pos[b]] (width d_freq; d_freq == D_pe is the full-width table,
      d_freq == D_pe//2 is the first-half reuse table), and expand to width D_pe
      according to the rotation style:
        full width: c~ = c;
        first-half reuse + NEOX: c~ = [c, c] (the whole segment repeated once; both
          halves share the same frequency);
        first-half reuse + GPTJ: c~ = [c0, c0, c1, c1, ...] (every element repeated
          twice back to back).
      rotate_half(x) is defined as:
        NEOX (is_neox=True): rotate_half(x)[i] = -x[i + D_pe//2]
          (i < D_pe//2), = x[i - D_pe//2] (i >= D_pe//2);
        GPTJ (is_neox=False): rotate_half(x)[2j] = -x[2j+1],
          rotate_half(x)[2j+1] = x[2j].
      pe segment output = x * c~ + rotate_half(x) * s~, cast back to the input dtype.
    Boundary behaviour: pos[b] is in [0, max_pos) (out of range is undefined
    behaviour); this operator is a memory-bound preprocessing step and computes no
    attention score; the nope segment and the pe segment in pure concatenation mode
    are verbatim copies and must match bit-for-bit; the whole forward is out-of-place
    and must not overwrite any input in place.

    (2) Input/output specification:
    - q_nope / q_pe / k_nope / k_pe: float16 / bfloat16, contiguous, shapes as above
      (QH == KH * QH_PER_KH, one shared batch for all four tensors);
    - pos: int64, [B], one position index per batch (it is cast to floating point
      under the evaluation precision and restored to integer losslessly at the
      entry);
    - cos / sin: same dtype as the data, [max_pos, d_freq], contiguous, used only
      through the row-style indexing cos[pos[b], d];
    - returns: out [B, QH + KH, D_nope + D_pe] with the same dtype as q_nope;
    - hyper-parameters (__init__): is_neox -- True selects the NEOX rotation style /
      False selects GPTJ; apply_rope -- True rotates the pe segment / False pure
      concatenation.

    (3) Implementation constraints (violations are scored as failures):
    - The core computation (row indexing of cos/sin by position, rotation of the pe
      segment, the nope/pe concatenated write-back, and the K-side deduplication
      under GQA) must be completed inside the submitted file with a self-written
      HIP kernel: a single kernel (one launch) with a single
      read-compute-write pass;
    - The __init__ and forward signatures of ModelNew must not be changed;
    - Use float32 for intermediate computation; cast the output back to the input
      dtype.

    (4) Forbidden list and target hardware:
    - Calling ATen shortcuts such as torch.cat / torch.concat (including the tensor
      method .cat) or index_select to complete this task's computation directly is
      forbidden; the authoritative forbidden list is the task.yaml forbidden list
      (it covers the source operator library and other closed-source acceleration
      libraries; the final static audit does substring matching on the code outside
      docstrings / comments);
    - Target hardware: Hygon DCU (gfx936/gfx938). Implementation language: HIP (compiled by hipcc; write inside the CUDA_CU_SRC / CUDA_CPP_SRC anchor regions; device code must include <hip/hip_runtime.h> -- <cuda_runtime.h> is not available on this machine).
    """
    def __init__(self, is_neox: bool = True, apply_rope: bool = True):
        super().__init__()
        # <<<IMPROVE:init_body>>>
        self.is_neox = bool(is_neox)
        self.apply_rope = bool(apply_rope)
        # <<<END_IMPROVE>>>

    def forward(self, q_nope, q_pe, k_nope, k_pe, pos, cos, sin):
        # <<<IMPROVE:forward_stmt_1>>>
        # Positions are decoded inside the HIP kernel.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_2>>>
        B, QH, D_nope = q_nope.shape
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_3>>>
        KH = k_nope.shape[1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_4>>>
        D_pe = q_pe.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_5>>>
        assert q_pe.shape[0] == B and k_nope.shape[0] == k_pe.shape[0] == B, "the batch dimension must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_6>>>
        assert q_pe.shape[1] == QH and k_pe.shape[1] == KH, "the head counts of Q and K must each match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_7>>>
        assert k_nope.shape[2] == D_nope and k_pe.shape[2] == D_pe, "the D_nope and D_pe of q and k must match"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_8>>>
        assert QH % KH == 0, "QH must be an integer multiple of KH (GQA)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_9>>>
        assert D_pe % 2 == 0, "D_pe must be even (half-width rotation)"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_10>>>
        # The extension allocates the final output.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_11>>>
        # Q copies are fused.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_12>>>
        # K copies are fused.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_13>>>
        d_freq = cos.shape[-1]
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_14>>>
        if self.apply_rope:
            assert d_freq in (D_pe, D_pe // 2), "the cos/sin width must be D_pe or D_pe//2"
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_15>>>
        # Frequency rows are read on device.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_16>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_17>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_18>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_19>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_20>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_21>>>
        # Rotation pairs are owned by individual kernel threads.
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_22>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_23>>>
        out = _pyramidkernel_get_extension().fused_qk(q_nope, q_pe, k_nope, k_pe, pos, cos, sin, self.is_neox, self.apply_rope)
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_24>>>
        # <<<END_IMPROVE>>>
        # <<<IMPROVE:forward_stmt_25>>>
        return out
        # <<<END_IMPROVE>>>
